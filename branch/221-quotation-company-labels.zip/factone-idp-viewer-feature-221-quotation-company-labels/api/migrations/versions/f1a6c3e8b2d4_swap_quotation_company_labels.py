"""見積書のシードの発行元・宛先のラベルと表示有無を入れ替える

見積書は自社が発行し、宛先が取引先になる。注文書に合わせた共通 8 項目のラベルのままだと、
発行元（SenderCompanyName）が「取引先」、宛先（ReceiverCompanyName）が「自社名」で非表示になり、
逆に見える。default テナントの quotation / quotation_di だけ、2 項目のラベルと表示有無を入れ替える（#221）。
キーと説明は変えない。表示する項目は、シードの他の項目と同じく visible を持たない。

Revision ID: f1a6c3e8b2d4
Revises: c4f8a2e6d9b1
Create Date: 2026-11-05 12:00:00.000000

"""

from collections.abc import Sequence

from alembic import op

revision: str = "f1a6c3e8b2d4"
down_revision: str | None = "c4f8a2e6d9b1"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _relabel(hidden: str, shown: str) -> None:
    """hidden を「自社名」・非表示に、shown を「取引先」・表示にする。"""
    op.execute(
        f"""
        UPDATE document_type_configs SET fields = (
            SELECT jsonb_agg(CASE f ->> 'key'
                WHEN '{hidden}' THEN f || '{{"label": "自社名", "visible": false}}'
                WHEN '{shown}' THEN (f - 'visible') || '{{"label": "取引先"}}'
                ELSE f END ORDER BY i)
            FROM jsonb_array_elements(fields) WITH ORDINALITY AS t(f, i))
        WHERE tenant_id = 'default' AND type_code IN ('quotation', 'quotation_di')
        """
    )


def upgrade() -> None:
    _relabel(hidden="SenderCompanyName", shown="ReceiverCompanyName")


def downgrade() -> None:
    _relabel(hidden="ReceiverCompanyName", shown="SenderCompanyName")
