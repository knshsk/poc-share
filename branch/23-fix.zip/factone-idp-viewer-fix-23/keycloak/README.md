# Keycloak構成管理

Keycloakのrealm定義をconfig-as-codeで管理するディレクトリです。

## 暫定運用ルール

realm設計（realm分離 or 単一realm+テナントクレーム）は未確定（Q-IDPV-12）のため、確定までは本READMEの暫定運用のみとします。realm設計ドキュメントは確定後に `docs/architecture/` へ作成します。

- **realm定義JSON（`realm/` 配下）を構成管理の正とします。** Keycloak管理コンソールでの手動変更は永続化せず、変更はJSONを編集して再投入します。
- 投入方法: 起動時の `--import-realm` で `realm/` 配下のJSONが自動投入されます（ローカルは `compose.yaml`、Azureも同方式の予定）。
- 既存realmがある場合、`--import-realm` は既定でスキップされます。定義変更を反映するには realm を削除して再起動するか、ローカルではデータボリュームを初期化してください（手順は `docs/develop-guide/local-stack.md`）。

## シークレット非含有ルール

- **realm JSONにシークレット（クライアントシークレット・パスワード等）を含めないでください。**
- **Keycloakのrealmインポートは環境変数置換を行いません**（プレースホルダ文字列がそのまま値になります）。パスワード・クライアントシークレット等の実行時設定が必要な項目は、起動後に `kcadm` を使うスクリプトで設定します（`scripts/local-stack/apply-keycloak-secrets.sh`）。
- 現在のrealm定義:
  - realm本体
  - publicクライアント `factone-viewer`（SPA用。PKCE S256必須・audienceマッパー）
  - confidentialクライアント `factone-integration`（外部システム連携用M2M。client credentials grant・audienceマッパー。シークレットはインポート対象外）
  - テストユーザー `testuser`（パスワードはインポート対象外）
  - ロール・テナント関連は未確定事項の解消後に拡充します。
