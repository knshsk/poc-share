# デプロイ手順

デプロイ手順の正は `scripts/` のスクリプトです。本ドキュメントは前提条件・使い方・トラブルシュートのみを記載します。

## コアインフラ（DI・Blob・PostgreSQL・Key Vault）

### 前提条件

- Azure CLI（`az`）がインストール済みで、対象サブスクリプションへ `az login` 済みであること
- サブスクリプションに対しリソースグループ作成・デプロイ権限があること

### 使い方

```bash
FACTONE_POSTGRES_ADMIN_PASSWORD='<管理者パスワード>' ./scripts/deploy-infra.sh
```

- 第1引数: リソースグループ名（既定: `factone-poc-rg`）
- 第2引数: リージョン（既定: `japaneast`）

作成されるリソース: Document Intelligence（S0）、Blob Storage（`documents` コンテナ）、PostgreSQL Flexible Server（B1ms）、Key Vault（管理者パスワードを `postgres-admin-password` シークレットとして格納）。

### トラブルシュート

- `FACTONE_POSTGRES_ADMIN_PASSWORD` 未設定エラー → 環境変数を設定して再実行してください（PostgreSQLのパスワードポリシーは8文字以上・英大小数字を含む）
- 未ログインエラー → `az login` 後に再実行してください
- 名前衝突エラー → リソース名にはリソースグループ由来の一意サフィックスが付くため通常発生しません。別リソースグループ名を指定すると別の一意名で作成されます

### リソース削除

検証後にリソースを削除する場合はリソースグループごと削除します。

```bash
az group delete --name factone-poc-rg
```

**再デプロイ時の注意:** Key Vault と Document Intelligence は削除後もソフトデリート状態で名前が90日間予約されます。リソース名はリソースグループ名由来の一意サフィックスを含むため、同名リソースグループへ再デプロイすると名前が衝突します。再デプロイ前にパージしてください。

```bash
az keyvault purge --name <Key Vault名>
```

```bash
az cognitiveservices account purge --name <DI名> --resource-group <リソースグループ名> --location japaneast
```

（別のリソースグループ名でデプロイし直す場合、サフィックスが変わるためパージ不要）

### 補足

- Container Apps・ACR・Keycloak のデプロイは別スクリプトとして今後追加予定
- ネットワーク隔離（VNet+Private Endpoint）はPoCでは行いません（本番化時にモジュール単位で後付け）
