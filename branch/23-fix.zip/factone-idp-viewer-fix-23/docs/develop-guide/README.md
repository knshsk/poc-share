# 開発者向けガイド

環境構築・開発手順・運用手順に関する開発者向け資料を格納するディレクトリです。

## ドキュメント一覧（読み順）

1. [wsl-setup.md](wsl-setup.md) — WSL開発環境構築（WSL2+Ubuntu 24.04、プロキシ設定、Podman導入。マシンごとに1回）
2. [local-stack.md](local-stack.md) — ローカル開発スタックの起動・停止・初期化（日常操作）
3. [api.md](api.md) — バックエンドAPIのセットアップ・起動・テスト実行（uv+FastAPI）
4. [viewer.md](viewer.md) — フロントエンドのセットアップ・起動・テスト実行（Vite+Vue）
5. [quality.md](quality.md) — 品質ゲート（pre-commitセットアップ・lint・型検査）
6. [auth.md](auth.md) — ローカル認証動作手順（Keycloakログイン・API認証確認）
7. [deploy.md](deploy.md) — Azureデプロイ（前提条件・使い方。手順の正は `scripts/`）

- ローカル開発環境の構築手順（WSL2+Podman、ローカルスタック起動）を扱います。
- デプロイ手順は `scripts/` のスクリプトが正であり、ここには前提条件・使い方・トラブルシュートのみを記述します（手順詳細の二重管理を避けるため）。
- `samples/` のサンプルPDF作成規約（実データ由来禁止・ダミー値規則）もここに定めます。
