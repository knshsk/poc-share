// FactONE IDP/Viewer コアインフラ（PoC・単一環境）
// リソースグループスコープ。デプロイは scripts/deploy-infra.sh を使用してください。
// ネットワーク隔離なし（パブリックエンドポイント＋サービス側制御）。
// 将来のVNet+Private Endpoint導入時はモジュール単位でネットワーク層を後付けする。

@description('環境名。リソース名の一部に使用（名前長制約のため4文字以内）')
@maxLength(4)
param environmentName string = 'poc'

@description('デプロイ先リージョン')
param location string = resourceGroup().location

@description('PostgreSQL管理者ユーザー名')
param postgresAdminLogin string

@description('PostgreSQL管理者パスワード（Key Vaultにも格納される）')
@secure()
param postgresAdminPassword string

// グローバル一意性が必要なリソース名に付与するサフィックス
var uniqueSuffix = uniqueString(resourceGroup().id)

module storage 'modules/storage.bicep' = {
  name: 'storage'
  params: {
    location: location
    storageAccountName: 'factone${environmentName}${take(uniqueSuffix, 8)}'
  }
}

module postgresql 'modules/postgresql.bicep' = {
  name: 'postgresql'
  params: {
    location: location
    serverName: 'factone-${environmentName}-pg-${uniqueSuffix}'
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
  }
}

module keyVault 'modules/keyvault.bicep' = {
  name: 'keyvault'
  params: {
    location: location
    keyVaultName: 'factone-${environmentName}-kv-${take(uniqueSuffix, 6)}'
    postgresAdminPassword: postgresAdminPassword
  }
}

module documentIntelligence 'modules/document-intelligence.bicep' = {
  name: 'document-intelligence'
  params: {
    location: location
    accountName: 'factone-${environmentName}-di-${uniqueSuffix}'
  }
}

output storageAccountName string = storage.outputs.storageAccountName
output postgresServerFqdn string = postgresql.outputs.serverFqdn
output keyVaultName string = keyVault.outputs.keyVaultName
output documentIntelligenceEndpoint string = documentIntelligence.outputs.endpoint
