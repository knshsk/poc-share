<script setup lang="ts">
import { onMounted, ref } from 'vue'

import { apiClient } from '../api/client'
import PageSvg from './PageSvg.vue'

interface PageInfo {
  width: number
  height: number
}

// 呼出パラメータの文書IDのみを受領する（案件ID・ルートIDは要求しない）
const documentId = ref(
  new URLSearchParams(window.location.search).get('document_id') ?? '',
)
const pages = ref<PageInfo[]>([])
const errorMessage = ref<string | null>(null)

async function loadDocument(): Promise<void> {
  errorMessage.value = null
  pages.value = []
  if (!documentId.value) return

  const { data, error } = await apiClient.GET(
    '/api/documents/{document_id}/pages',
    {
      params: { path: { document_id: documentId.value } },
    },
  )
  if (error || !data) {
    errorMessage.value = '文書を取得できませんでした'
    return
  }
  pages.value = data.pages
}

async function downloadOriginal(): Promise<void> {
  const { data, error } = await apiClient.GET(
    '/api/documents/{document_id}/pdf',
    {
      params: { path: { document_id: documentId.value } },
      parseAs: 'blob',
    },
  )
  if (error || !data) {
    errorMessage.value = '原本を取得できませんでした'
    return
  }
  const url = URL.createObjectURL(data)
  const link = document.createElement('a')
  link.href = url
  link.download = `${documentId.value}.pdf`
  link.click()
  URL.revokeObjectURL(url)
}

onMounted(() => {
  if (documentId.value) void loadDocument()
})
</script>

<template>
  <div>
    <v-text-field
      v-model="documentId"
      label="文書ID"
      density="compact"
      class="mb-2"
    />
    <v-btn class="mr-2" @click="loadDocument">表示</v-btn>
    <v-btn :disabled="pages.length === 0" @click="downloadOriginal"
      >原本DL</v-btn
    >
    <p v-if="errorMessage" class="text-error">{{ errorMessage }}</p>
    <div v-for="(page, index) in pages" :key="index" class="my-4">
      <PageSvg
        :document-id="documentId"
        :page="index + 1"
        :width="page.width"
        :height="page.height"
      />
    </div>
  </div>
</template>
