import {
  InMemoryWebStorage,
  UserManager,
  WebStorageStateStore,
} from 'oidc-client-ts'
import { defineStore } from 'pinia'
import { ref } from 'vue'

// アクセストークンはメモリ保持（localStorage等へ永続化しない）
function createUserManager(): UserManager {
  return new UserManager({
    authority:
      import.meta.env.VITE_OIDC_AUTHORITY ??
      'http://localhost:8080/realms/factone',
    client_id: import.meta.env.VITE_OIDC_CLIENT_ID ?? 'factone-viewer',
    redirect_uri: `${window.location.origin}/callback`,
    post_logout_redirect_uri: window.location.origin,
    scope: 'openid',
    userStore: new WebStorageStateStore({ store: new InMemoryWebStorage() }),
  })
}

export const useAuthStore = defineStore('auth', () => {
  const userManager = createUserManager()
  const accessToken = ref<string | null>(null)
  const username = ref<string | null>(null)
  const isAuthenticated = ref(false)

  async function login(): Promise<void> {
    await userManager.signinRedirect()
  }

  async function handleCallback(): Promise<void> {
    const user = await userManager.signinCallback()
    if (user) {
      accessToken.value = user.access_token
      username.value = user.profile?.preferred_username ?? null
      isAuthenticated.value = true
    }
  }

  async function logout(): Promise<void> {
    accessToken.value = null
    username.value = null
    isAuthenticated.value = false
    await userManager.signoutRedirect()
  }

  return {
    accessToken,
    username,
    isAuthenticated,
    login,
    handleCallback,
    logout,
  }
})
