"""データモデル定義。設計はdocs/data-model/を参照。"""

import enum
from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class DocumentType(enum.StrEnum):
    """文書種別。

    単一テーブル+種別列は統合モデル採否が未確定のための仮置き。
    値の追加はここに列挙値を足し、CHECK制約を張り替えるマイグレーションを作成する。
    """

    QUOTE = "quote"
    ORDER_PROJECT = "order_project"
    ORDER_ROUTE = "order_route"


class Document(Base):
    """文書メタデータ。文書IDは呼出側採番（COM-01）で、SaaS内では採番しない。"""

    __tablename__ = "documents"
    __table_args__ = (
        CheckConstraint(
            "document_type IN ('quote', 'order_project', 'order_route')",
            name="ck_documents_document_type",
        ),
    )

    document_id: Mapped[str] = mapped_column(String(255), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(255))
    document_type: Mapped[str] = mapped_column(String(50))
    blob_ref: Mapped[str] = mapped_column(String(1024))
    content_sha256: Mapped[str] = mapped_column(String(64))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
