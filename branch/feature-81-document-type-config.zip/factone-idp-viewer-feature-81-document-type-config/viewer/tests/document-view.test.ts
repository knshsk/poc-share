import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// API呼出はapiClient経由のためモックする（画面はレイアウトとパネル組込が検証対象）
// 文書種別は閲覧URLパネルの表示ゲートに使う（既定: 見積）
let documentType = 'quote'
const getMock = vi.fn()

function defaultGetImplementation(path: string) {
  if (path === '/api/documents/{document_id}') {
    return Promise.resolve({
      data: {
        document_id: 'doc-1',
        tenant_id: 'tenant-1',
        document_type: documentType,
        content_sha256: 'x'.repeat(64),
        received_at: '2026-08-01T00:00:00Z',
      },
      error: undefined,
    })
  }
  if (path === '/api/documents/{document_id}/view-urls') {
    return Promise.resolve({ data: [], error: undefined })
  }
  if (path === '/api/documents/{document_id}/pages') {
    return Promise.resolve({
      data: { document_id: 'doc-1', pages: [{ width: 8.5, height: 11 }] },
      error: undefined,
    })
  }
  if (path === '/api/documents/{document_id}/pages/{page}/image') {
    return Promise.resolve({ data: new Blob(), error: undefined })
  }
  return Promise.resolve({
    data: { document_id: 'doc-1', runs: [] },
    error: undefined,
  })
}

vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return vi.fn()
    },
  },
}))

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import DocumentView from '../src/views/DocumentView.vue'

function mountView() {
  return mount(DocumentView, {
    global: { plugins: [createAppVuetify(), createPinia()] },
  })
}

describe('DocumentView', () => {
  beforeEach(() => {
    documentType = 'quote'
    getMock.mockReset()
    getMock.mockImplementation(defaultGetImplementation)
  })

  // 文書表示時に作業パネルが文書ID・種別を引き渡されて組み込まれることを確認する
  it('文書表示時にWorkPanelを表示する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mountView()
    await flushPromises()

    const panel = wrapper.findComponent(WorkPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('documentId')).toBe('doc-1')
    expect(panel.props('documentType')).toBe('quote')
  })

  // 文書未表示（文書ID未入力）ではパネルを表示しないことを確認する
  it('文書未表示ではWorkPanelを表示しない', () => {
    window.history.replaceState(null, '', '/')

    const wrapper = mountView()

    expect(wrapper.findComponent(WorkPanel).exists()).toBe(false)
  })

  // 注文書種別がWorkPanelへ渡ることを確認する
  // （閲覧URLタブの表示ゲート自体はwork-panel.test.tsが担保。ADR-0002）
  it('注文書種別ではWorkPanelにorder種別が渡る', async () => {
    documentType = 'order_project'
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mountView()
    await flushPromises()

    const panel = wrapper.findComponent(WorkPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('documentType')).toBe('order_project')
  })

  // 文書ID未指定時は入力欄付きempty stateを表示することを確認する
  it('文書ID未指定時はempty stateを表示する', () => {
    window.history.replaceState(null, '', '/')

    const wrapper = mountView()

    expect(wrapper.find('[data-testid="document-id-input"]').exists()).toBe(
      true,
    )
    expect(wrapper.text()).toContain('文書IDを指定して起動してください')
  })

  // 文書取得失敗時はエラーstateと再試行ボタンを表示することを確認する
  it('文書取得失敗時はエラーと再試行を表示する', async () => {
    getMock.mockImplementation(() =>
      Promise.resolve({ data: undefined, error: { detail: 'x' } }),
    )
    window.history.replaceState(null, '', '?document_id=doc-x')

    const wrapper = mountView()
    await flushPromises()

    expect(wrapper.get('[data-testid="document-error"]').text()).toContain(
      '文書を取得できませんでした',
    )
    expect(wrapper.find('[data-testid="document-retry"]').exists()).toBe(true)
  })

  // 表示成功時にDocumentCanvasへページとIDが渡ることを確認する
  it('表示成功時にDocumentCanvasを表示する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mountView()
    await flushPromises()

    const canvas = wrapper.findComponent(DocumentCanvas)
    expect(canvas.exists()).toBe(true)
    expect(canvas.props('documentId')).toBe('doc-1')
    expect(canvas.props('pages')).toHaveLength(1)
  })
})
