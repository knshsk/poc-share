"""IDP抽出結果の組立・正規化・確信度分離のテスト。"""

from typing import Any

import pytest

from app.services.document_type_config import FieldDef, FieldType, PatternDef
from app.services.engine import LayoutTable, LayoutTableCell, LeafResult, Region
from app.services.idp_extraction import (
    CellCorrection,
    UnknownCorrectionTarget,
    apply_corrections,
    build_fields,
    layout_tables_to_json,
    match_patterns,
)

ORDER_FIELDS = (
    FieldDef(key="customer_code", label="得意先コード", type=FieldType.STRING),
    FieldDef(key="item_code", label="品目コード", type=FieldType.STRING),
    FieldDef(key="quantity", label="数量", type=FieldType.NUMBER),
    FieldDef(key="delivery_date", label="納期", type=FieldType.DATE),
    FieldDef(key="unit_price", label="単価", type=FieldType.NUMBER),
)


class TestBuildFields:
    def test_separates_raw_normalized_and_confidence(self) -> None:
        results = {
            "customer_code": LeafResult(value="C-9001", confidence=0.98),
            "item_code": LeafResult(value="P-9001", confidence=0.95),
            "quantity": LeafResult(value="2", confidence=0.99),
            "delivery_date": LeafResult(value="2026-10-30", confidence=0.97),
            "unit_price": LeafResult(value="500,000", confidence=0.96),
        }
        built = build_fields(ORDER_FIELDS, results)
        assert built["unit_price"]["value"] == "500,000"
        assert built["unit_price"]["normalized_value"] == 500000
        assert built["unit_price"]["confidence"] == 0.96

    def test_normalizes_number_fields_by_type(self) -> None:
        fields = (FieldDef(key="anything", label="任意", type=FieldType.NUMBER),)
        results = {"anything": LeafResult(value="1,200", confidence=0.9)}
        built = build_fields(fields, results)
        assert built["anything"]["normalized_value"] == 1200

    def test_normalizes_slash_date_to_iso_by_type(self) -> None:
        fields = (FieldDef(key="some_date", label="日付", type=FieldType.DATE),)
        results = {"some_date": LeafResult(value="2026/10/30", confidence=0.9)}
        built = build_fields(fields, results)
        assert built["some_date"]["normalized_value"] == "2026-10-30"

    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            ("￥74,800", 74800),
            ("¥74,800円", 74800),
            ("７４，８００", 74800),
            ("1 250 000", 1250000),
            ("-12", -12),
            ("12.5", None),
            ("約120万", None),
        ],
    )
    def test_number_accepts_currency_and_fullwidth(
        self, value: str, expected: int | None
    ) -> None:
        fields = (FieldDef(key="amount", label="金額", type=FieldType.NUMBER),)
        results = {"amount": LeafResult(value=value, confidence=0.9)}
        assert build_fields(fields, results)["amount"]["normalized_value"] == expected

    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            ("2026-09-04", "2026-09-04"),
            ("2026/9/4", "2026-09-04"),
            ("2026.09.04", "2026-09-04"),
            ("2026年9月4日", "2026-09-04"),
            ("２０２６年９月４日", "2026-09-04"),
            ("令和 8年 9月 4日", "2026-09-04"),
            ("令和元年5月1日", "2019-05-01"),
            ("平成31年4月30日", "2019-04-30"),
            ("昭和64年1月7日", "1989-01-07"),
            ("R8.9.4", "2026-09-04"),
            ("H30/1/2", "2018-01-02"),
            ("2026-02-30", None),
            ("令和8年13月1日", None),
            ("9/4", None),
            ("月末", None),
        ],
    )
    def test_date_accepts_japanese_formats(
        self, value: str, expected: str | None
    ) -> None:
        fields = (FieldDef(key="d", label="日付", type=FieldType.DATE),)
        results = {"d": LeafResult(value=value, confidence=0.9)}
        assert build_fields(fields, results)["d"]["normalized_value"] == expected

    def test_string_field_passes_through(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"code": LeafResult(value="A-001", confidence=0.9)}
        built = build_fields(fields, results)
        assert built["code"]["normalized_value"] == "A-001"

    def test_unparseable_number_keeps_raw_and_nulls_normalized(self) -> None:
        fields = (FieldDef(key="quantity", label="数量", type=FieldType.NUMBER),)
        results = {"quantity": LeafResult(value="二個", confidence=0.4)}
        built = build_fields(fields, results)
        assert built["quantity"]["value"] == "二個"
        assert built["quantity"]["normalized_value"] is None
        assert built["quantity"]["confidence"] == 0.4

    def test_unparseable_date_keeps_raw_and_nulls_normalized(self) -> None:
        fields = (FieldDef(key="delivery_date", label="納期", type=FieldType.DATE),)
        results = {"delivery_date": LeafResult(value="月末", confidence=0.3)}
        built = build_fields(fields, results)
        assert built["delivery_date"]["value"] == "月末"
        assert built["delivery_date"]["normalized_value"] is None

    def test_missing_field_yields_none_for_all_views(self) -> None:
        # 必須項目未抽出: 生値・正規化値・確信度すべてNoneで項目自体は返す
        built = build_fields(ORDER_FIELDS, {})
        assert built["customer_code"]["value"] is None
        assert built["customer_code"]["normalized_value"] is None
        assert built["customer_code"]["confidence"] is None

    def test_extra_fields_outside_defs_are_ignored(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"unexpected": LeafResult(value="x", confidence=0.5)}
        built = build_fields(fields, results)
        assert "unexpected" not in built

    def test_regions_follow_bounding_region_of_each_field(self) -> None:
        # 領域ありは {page_number, polygon}、領域なし・値なしは None。キーは定義全件
        fields = (
            FieldDef(key="code", label="コード", type=FieldType.STRING),
            FieldDef(key="amount", label="金額", type=FieldType.NUMBER),
            FieldDef(key="missing", label="未抽出", type=FieldType.STRING),
        )
        results = {
            "code": LeafResult(
                value="A-1",
                confidence=0.9,
                region=Region(page_number=1, polygon=(1.0, 2.0, 3.0, 2.0)),
            ),
            "amount": LeafResult(value="100", confidence=0.8),
        }
        built = build_fields(fields, results)
        assert {k: v["region"] for k, v in built.items()} == {
            "code": {"page_number": 1, "polygon": [1.0, 2.0, 3.0, 2.0]},
            "amount": None,
            "missing": None,
        }

    def test_region_is_none_when_value_is_none(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {
            "code": LeafResult(
                value=None,
                confidence=None,
                region=Region(page_number=1, polygon=(1.0, 2.0)),
            )
        }
        assert build_fields(fields, results)["code"]["region"] is None

    def test_label_is_snapshotted_from_schema(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"code": LeafResult(value="A-1", confidence=0.9)}
        assert build_fields(fields, results) == {
            "code": {
                "label": "コード",
                "value": "A-1",
                "normalized_value": "A-1",
                "confidence": 0.9,
                "region": None,
            }
        }


class TestLayoutTablesToJson:
    def test_serializes_tables_without_interpretation(self) -> None:
        # 意味付けせずJSON化する（明細特定・項目対応はSaaS責務外）
        tables = (
            LayoutTable(
                row_count=1,
                column_count=2,
                cells=(
                    LayoutTableCell(
                        row_index=0,
                        column_index=0,
                        content="品目",
                        kind="columnHeader",
                        page_number=1,
                        polygon=(1.0, 2.0),
                    ),
                    LayoutTableCell(
                        row_index=0,
                        column_index=1,
                        content="数量",
                        kind=None,
                        page_number=None,
                        polygon=None,
                    ),
                ),
            ),
        )
        assert layout_tables_to_json(tables) == [
            {
                "row_count": 1,
                "column_count": 2,
                "cells": [
                    {
                        "row_index": 0,
                        "column_index": 0,
                        "content": "品目",
                        "kind": "columnHeader",
                        "page_number": 1,
                        "polygon": [1.0, 2.0],
                        "row_span": 1,
                        "column_span": 1,
                    },
                    {
                        "row_index": 0,
                        "column_index": 1,
                        "content": "数量",
                        "kind": None,
                        "page_number": None,
                        "polygon": None,
                        "row_span": 1,
                        "column_span": 1,
                    },
                ],
            }
        ]

    def test_empty_tables_yield_empty_list(self) -> None:
        assert layout_tables_to_json(()) == []


TCODE = PatternDef(key="TCode", label="登録番号", regex=r"T\d{13}")
QUOTATION_NO = PatternDef(key="QuotationNo", label="見積番号", regex=r"Q-\d{6}")


class TestMatchPatterns:
    def test_returns_all_matches_in_order_with_duplicates(self) -> None:
        # 同一文字列が複数箇所にあれば出現回数分返す（重複除去しない）
        content = (
            "登録番号 T1234567890123\n明細...\nフッタ T1234567890123 T9876543210987"
        )
        result = match_patterns((TCODE,), content)
        assert result == {
            "TCode": {
                "label": "登録番号",
                "regex": r"T\d{13}",
                "values": ["T1234567890123", "T1234567890123", "T9876543210987"],
            }
        }

    def test_multiple_patterns_keep_definition_order(self) -> None:
        content = "見積 Q-000123 / T1234567890123"
        result = match_patterns((TCODE, QUOTATION_NO), content)
        assert list(result) == ["TCode", "QuotationNo"]
        assert result["QuotationNo"]["values"] == ["Q-000123"]

    def test_no_match_keeps_key_with_empty_values(self) -> None:
        result = match_patterns((QUOTATION_NO,), "見積番号なし")
        assert result == {
            "QuotationNo": {"label": "見積番号", "regex": r"Q-\d{6}", "values": []}
        }

    def test_empty_content_yields_empty_values(self) -> None:
        assert match_patterns((TCODE,), "")["TCode"]["values"] == []

    def test_no_patterns_yields_empty_dict(self) -> None:
        assert match_patterns((), "T1234567890123") == {}

    def test_zero_length_matches_are_dropped(self) -> None:
        # `\d*` は文字位置ごとに空文字に一致する。空文字は情報を持たず肥大するため除外
        pattern = PatternDef(key="Digits", label="数字", regex=r"\d*")
        result = match_patterns((pattern,), "ab12cd345")
        assert result["Digits"]["values"] == ["12", "345"]


BASE_FIELDS: dict[str, dict[str, object]] = {
    "TotalAmount": {
        "label": "合計金額",
        "value": "1,200,000",
        "normalized_value": 1200000,
        "confidence": 0.96,
        "region": {"page_number": 1, "polygon": [6.8, 2.9, 7.3, 2.9]},
    },
    "DeliveryDate": {
        "label": "納品期限",
        "value": "2026-10-30",
        "normalized_value": "2026-10-30",
        "confidence": 0.97,
        "region": None,
    },
    "Note": {
        "label": "備考",
        "value": None,
        "normalized_value": None,
        "confidence": None,
        "region": None,
    },
}
BASE_TABLES: list[dict[str, object]] = [
    {
        "row_count": 2,
        "column_count": 1,
        "cells": [
            {
                "row_index": 0,
                "column_index": 0,
                "content": "品目",
                "kind": "columnHeader",
                "page_number": 1,
                "polygon": [1.0, 2.0, 3.0, 2.0],
                "row_span": 1,
                "column_span": 1,
            },
            {
                "row_index": 1,
                "column_index": 0,
                "content": "P-9001",
                "kind": None,
                "page_number": 1,
                "polygon": [1.0, 3.0, 3.0, 3.0],
                "row_span": 1,
                "column_span": 1,
            },
        ],
    }
]
FIELD_TYPES = {
    "TotalAmount": FieldType.NUMBER,
    "DeliveryDate": FieldType.DATE,
    "Note": FieldType.STRING,
}


def _apply(
    fields: dict[str, str | None] | None = None,
    cells: tuple[CellCorrection, ...] = (),
    field_types: dict[str, FieldType] | None = None,
) -> Any:
    return apply_corrections(
        BASE_FIELDS,
        BASE_TABLES,
        fields or {},
        cells,
        FIELD_TYPES if field_types is None else field_types,
    )


class TestApplyCorrections:
    def test_changed_field_is_renormalized_and_confidence_nulled(self) -> None:
        """変更キーは現行型で再正規化され確信度が null、ラベルと領域は base を維持する。"""
        result = _apply({"TotalAmount": "1,250,000"})

        assert result.fields == {
            **BASE_FIELDS,
            "TotalAmount": {
                **BASE_FIELDS["TotalAmount"],
                "value": "1,250,000",
                "normalized_value": 1250000,
                "confidence": None,
            },
        }
        assert result.layout_tables == BASE_TABLES

    def test_null_field_clears_value_and_normalized(self) -> None:
        leaf = _apply({"DeliveryDate": None}).fields["DeliveryDate"]

        assert leaf["value"] is None
        assert leaf["normalized_value"] is None
        assert leaf["confidence"] is None

    def test_unparseable_value_keeps_value_and_nulls_normalized(self) -> None:
        leaf = _apply({"TotalAmount": "約120万"}).fields["TotalAmount"]

        assert leaf["value"] == "約120万"
        assert leaf["normalized_value"] is None

    def test_key_missing_from_config_is_treated_as_string(self) -> None:
        """設定に無いキー（設定変更後）は string として正規化なしで保存する。"""
        leaf = _apply({"TotalAmount": "1,250,000"}, field_types={}).fields[
            "TotalAmount"
        ]

        assert leaf["normalized_value"] == "1,250,000"

    def test_cell_content_is_replaced_keeping_structure(self) -> None:
        result = _apply(cells=(CellCorrection(0, 1, 0, "P-9002"),))

        assert result.layout_tables[0]["cells"][1] == {
            **BASE_TABLES[0]["cells"][1],  # type: ignore[index]
            "content": "P-9002",
        }
        assert result.layout_tables[0]["cells"][0] == BASE_TABLES[0]["cells"][0]  # type: ignore[index]
        assert result.fields == BASE_FIELDS

    def test_base_inputs_are_not_mutated(self) -> None:
        _apply({"TotalAmount": "1"}, cells=(CellCorrection(0, 1, 0, "X"),))

        assert BASE_FIELDS["TotalAmount"]["value"] == "1,200,000"
        assert BASE_FIELDS["TotalAmount"]["confidence"] == 0.96
        assert BASE_TABLES[0]["cells"][1]["content"] == "P-9001"  # type: ignore[index]

    def test_unknown_field_key_raises(self) -> None:
        with pytest.raises(UnknownCorrectionTarget, match="Unknown field key: Bogus"):
            _apply({"Bogus": "x"})

    def test_unknown_table_index_raises(self) -> None:
        with pytest.raises(UnknownCorrectionTarget, match="Unknown table cell"):
            _apply(cells=(CellCorrection(1, 0, 0, "x"),))

    def test_unknown_cell_coordinate_raises(self) -> None:
        with pytest.raises(UnknownCorrectionTarget, match="Unknown table cell"):
            _apply(cells=(CellCorrection(0, 1, 1, "x"),))
