"""idp_runs の並列 5 列を fields にまとめ、DI 固有の列をエンジン非依存にする

raw_fields / normalized_fields / confidence / field_labels / field_regions を、
項目キー → {label, value, normalized_value, confidence, region} の fields 1 列にまとめる。
tables は layout_tables に改名し、di_api_version / di_model_id は engine / engine_info に
置き換える（ADR-0029）。既存の行の engine は azure-di になる。失敗した行は fields /
engine_info が NULL のまま。

downgrade は DI の行を元の列へ戻す。ラベル列が NULL だった旧い成功行は、
{key: null} のラベル列として戻る（表示上はどちらもキーで代用され、差は出ない）。
array 型の値を持つ行（実装 B 以降）は旧スキーマで表現できないため、戻せない。

Revision ID: b6d2f9a4c8e1
Revises: a1e5c8f2d7b4
Create Date: 2026-10-09 12:30:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "b6d2f9a4c8e1"
down_revision: str | None = "a1e5c8f2d7b4"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # 既存の行に値を入れるための一時的な既定値。以降の行はアプリが必ず入れる
    op.add_column(
        "idp_runs",
        sa.Column(
            "engine", sa.String(length=20), nullable=False, server_default="azure-di"
        ),
    )
    op.alter_column("idp_runs", "engine", server_default=None)
    op.add_column("idp_runs", sa.Column("engine_info", JSONB(), nullable=True))
    op.add_column("idp_runs", sa.Column("fields", JSONB(), nullable=True))
    op.alter_column("idp_runs", "tables", new_column_name="layout_tables")
    op.execute(
        """
        UPDATE idp_runs SET fields = COALESCE((
            SELECT jsonb_object_agg(k, jsonb_build_object(
                'label', field_labels -> k,
                'value', raw_fields -> k,
                'normalized_value', normalized_fields -> k,
                'confidence', confidence -> k,
                'region', field_regions -> k))
            FROM jsonb_object_keys(raw_fields) AS k), '{}'::jsonb)
        WHERE raw_fields IS NOT NULL
        """
    )
    op.execute(
        """
        UPDATE idp_runs SET engine_info = jsonb_build_object(
            'api_version', di_api_version, 'model_id', di_model_id)
        WHERE di_api_version IS NOT NULL OR di_model_id IS NOT NULL
        """
    )
    op.drop_column("idp_runs", "raw_fields")
    op.drop_column("idp_runs", "normalized_fields")
    op.drop_column("idp_runs", "confidence")
    op.drop_column("idp_runs", "field_labels")
    op.drop_column("idp_runs", "field_regions")
    op.drop_column("idp_runs", "di_api_version")
    op.drop_column("idp_runs", "di_model_id")


def downgrade() -> None:
    op.add_column("idp_runs", sa.Column("raw_fields", JSONB(), nullable=True))
    op.add_column("idp_runs", sa.Column("normalized_fields", JSONB(), nullable=True))
    op.add_column("idp_runs", sa.Column("confidence", JSONB(), nullable=True))
    op.add_column("idp_runs", sa.Column("field_labels", JSONB(), nullable=True))
    op.add_column("idp_runs", sa.Column("field_regions", JSONB(), nullable=True))
    op.add_column(
        "idp_runs", sa.Column("di_api_version", sa.String(length=20), nullable=True)
    )
    op.add_column(
        "idp_runs", sa.Column("di_model_id", sa.String(length=100), nullable=True)
    )
    op.execute(
        """
        UPDATE idp_runs SET
            raw_fields = COALESCE((SELECT jsonb_object_agg(k, fields -> k -> 'value')
                FROM jsonb_object_keys(fields) AS k), '{}'::jsonb),
            normalized_fields = COALESCE((SELECT jsonb_object_agg(k, fields -> k -> 'normalized_value')
                FROM jsonb_object_keys(fields) AS k), '{}'::jsonb),
            confidence = COALESCE((SELECT jsonb_object_agg(k, fields -> k -> 'confidence')
                FROM jsonb_object_keys(fields) AS k), '{}'::jsonb),
            field_labels = COALESCE((SELECT jsonb_object_agg(k, fields -> k -> 'label')
                FROM jsonb_object_keys(fields) AS k), '{}'::jsonb),
            field_regions = COALESCE((SELECT jsonb_object_agg(k, fields -> k -> 'region')
                FROM jsonb_object_keys(fields) AS k), '{}'::jsonb)
        WHERE fields IS NOT NULL
        """
    )
    op.execute(
        """
        UPDATE idp_runs SET di_api_version = engine_info ->> 'api_version',
            di_model_id = engine_info ->> 'model_id'
        WHERE engine_info IS NOT NULL
        """
    )
    op.alter_column("idp_runs", "layout_tables", new_column_name="tables")
    op.drop_column("idp_runs", "fields")
    op.drop_column("idp_runs", "engine_info")
    op.drop_column("idp_runs", "engine")
