"""抽出エンジンの境界（エンジンに依存しない入出力）。

各エンジンのアダプタ（di.py など）が DocumentAnalyzer を実装し、文書種別設定のスキーマを
自分の形へ翻訳する。座標はインチ（Viewer の SVG viewBox と同じ座標系）にそろえて返す。
"""

import enum
from dataclasses import dataclass
from typing import Protocol

from app.services.document_type_config import FieldDef


class EngineName(enum.StrEnum):
    """文書種別設定で選ぶ抽出エンジン。"""

    AZURE_DI = "azure-di"


@dataclass(frozen=True)
class Region:
    """読取領域。polygon はインチ単位の頂点列。"""

    page_number: int
    polygon: tuple[float, ...]


@dataclass(frozen=True)
class LeafResult:
    """1 つの値の読取結果。value はエンジンが読んだ原文で、未抽出は None。"""

    value: str | None
    confidence: float | None
    region: Region | None = None


@dataclass(frozen=True)
class LayoutTableCell:
    """レイアウト認識のテーブルセル。座標は元応答に無い場合 None。span は省略時 1（結合なし）。"""

    row_index: int
    column_index: int
    content: str
    kind: str | None
    page_number: int | None
    polygon: tuple[float, ...] | None
    row_span: int = 1
    column_span: int = 1


@dataclass(frozen=True)
class LayoutTable:
    """レイアウト認識のテーブル（補助出力）。意味付けは行わず認識結果を素通しする。"""

    row_count: int
    column_count: int
    cells: tuple[LayoutTableCell, ...]


@dataclass(frozen=True)
class SchemaOwner:
    """スキーマの持ち主。スキーマの事前登録が要るエンジンが、登録物の名前や掃除の目印に使う。"""

    tenant_id: str
    type_code: str


@dataclass(frozen=True)
class AnalysisResult:
    """解析結果。アダプタからコアへ渡す内部の値で、API の応答ではない。

    fields は項目キーごとの読取結果（スキーマに無いキーはコアが捨てる）。content は全文テキスト
    （正規表現パターンの対象）。engine_info はエンジン固有のメタ情報。raw_response は生応答の
    本文 bytes で、コアが Blob に無変換で保存する（ADR-0019）。
    """

    fields: dict[str, LeafResult]
    layout_tables: tuple[LayoutTable, ...]
    content: str
    engine_info: dict[str, str | None]
    raw_response: bytes


class EngineError(Exception):
    """抽出エンジン呼出の失敗（タイムアウト・サービス障害・未設定）。"""


class DocumentAnalyzer(Protocol):
    """PDF 解析の境界。schema の項目を抽出し、レイアウト認識のテーブルと全文も返す。"""

    def analyze(
        self, pdf: bytes, schema: tuple[FieldDef, ...], schema_owner: SchemaOwner
    ) -> AnalysisResult: ...
