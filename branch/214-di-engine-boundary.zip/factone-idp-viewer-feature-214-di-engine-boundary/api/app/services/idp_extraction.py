"""IDP抽出結果の組立・正規化・修正適用。

エンジンが読んだ原文（生値）・確信度と、自前の規則で作る正規化値を、項目ごとの葉にまとめる
（idp_runs.fields の形）。対象フィールドと型は文書種別設定（document_type_configs）由来の
FieldDefで受け取る。全文テキストへの正規表現マッチ（PatternDef）も本モジュールで行う。
"""

import copy
import re
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import date
from typing import cast

from app.services.document_type_config import FieldDef, FieldType, PatternDef
from app.services.engine import LayoutTable, LeafResult

# 正規化規則はクライアント viewer/src/utils/normalize.ts と同一に保つ
_NUMBER_NOISE = re.compile(r"[¥円,、\s]")
# 和暦（元号 / R H S 略記 + 1〜2桁 or 元）or 西暦 4 桁。区切りは - / . 年月日 で末尾の日は任意。空白許容
_DATE = re.compile(
    r"^(?:(?P<era>令和|平成|昭和|[RHS])\s*(?P<ey>\d{1,2}|元)|(?P<y>\d{4}))\s*[-/.年]"
    r"\s*(?P<m>\d{1,2})\s*[-/.月]\s*(?P<d>\d{1,2})\s*日?$"
)
_ERA_BASE = {"令和": 2018, "R": 2018, "平成": 1988, "H": 1988, "昭和": 1925, "S": 1925}


def _normalize(field_type: FieldType, value: str) -> str | int | None:
    value = unicodedata.normalize("NFKC", value)
    if field_type is FieldType.NUMBER:
        try:
            return int(_NUMBER_NOISE.sub("", value))
        except ValueError:
            return None
    if field_type is FieldType.DATE:
        m = _DATE.match(value.strip())
        if m is None:
            return None
        if m["era"]:
            year = _ERA_BASE[m["era"]] + (1 if m["ey"] == "元" else int(m["ey"]))
        else:
            year = int(m["y"])
        try:
            return date(year, int(m["m"]), int(m["d"])).isoformat()
        except ValueError:
            return None
    return value


def layout_tables_to_json(
    tables: tuple[LayoutTable, ...],
) -> list[dict[str, object]]:
    """レイアウト認識のテーブルをJSON化する。意味付け・正規化は行わない。"""
    serialized = []
    for table in tables:
        data = asdict(table)
        data["cells"] = [
            {**cell, "polygon": list(cell["polygon"]) if cell["polygon"] else None}
            for cell in data["cells"]
        ]
        serialized.append(data)
    return serialized


def build_fields(
    schema: Sequence[FieldDef], results: Mapping[str, LeafResult]
) -> dict[str, dict[str, object]]:
    """スキーマの項目ごとに、ラベル・生値・正規化値・確信度・読取領域をまとめる。

    未抽出の項目もキーを残して値を None にする。スキーマに無いキーの結果は捨てる。
    領域は値があるときだけ持つ。
    """
    fields: dict[str, dict[str, object]] = {}
    for field in schema:
        result = results.get(field.key) or LeafResult(value=None, confidence=None)
        value = result.value
        region = result.region if value is not None else None
        fields[field.key] = {
            "label": field.label,
            "value": value,
            "normalized_value": None
            if value is None
            else _normalize(field.type, value),
            "confidence": result.confidence,
            "region": None
            if region is None
            else {"page_number": region.page_number, "polygon": list(region.polygon)},
        }
    return fields


def match_patterns(
    patterns: Sequence[PatternDef], content: str
) -> dict[str, dict[str, object]]:
    """全文テキストに各パターンを適用し、出現順・重複ありの全一致を返す。

    値は一致全体（group 0）。0件でもキーを残す。実行時点のlabel/regexを同梱し、
    設定変更後も当時の条件を再現できるようにする。regexは設定登録時に検証済み。
    長さ0の一致は含めない（`\\d*` 等が文字位置ごとに空文字を生む肥大防止）。
    """
    return {
        p.key: {
            "label": p.label,
            "regex": p.regex,
            "values": [m.group(0) for m in re.finditer(p.regex, content) if m.group(0)],
        }
        for p in patterns
    }


class UnknownCorrectionTarget(ValueError):
    """修正対象のキー・セル座標が base に存在しない。"""


@dataclass(frozen=True)
class CellCorrection:
    """テーブルセルの修正。座標は 0 始まり。"""

    table_index: int
    row_index: int
    column_index: int
    content: str


@dataclass(frozen=True)
class CorrectedValues:
    """base に修正を当てた後の項目値・レイアウトのテーブル。"""

    fields: dict[str, dict[str, object]]
    layout_tables: list[dict[str, object]]


def apply_corrections(
    base_fields: Mapping[str, Mapping[str, object]],
    base_tables: Sequence[Mapping[str, object]],
    fields: Mapping[str, str | None],
    layout_table_cells: Sequence[CellCorrection],
    field_types: Mapping[str, FieldType],
) -> CorrectedValues:
    """差分（fields / layout_table_cells）を base にマージする。

    変更キーは現在の設定型で再正規化し（設定に無いキーは string）、確信度は null にする。
    ラベルと読取領域は base の値を残す。テーブルは構造を維持して content だけ差し替える。
    base に無いキー・座標は UnknownCorrectionTarget。base の引数は変更しない。
    """
    merged = {key: dict(leaf) for key, leaf in base_fields.items()}
    for key, value in fields.items():
        leaf = merged.get(key)
        if leaf is None:
            raise UnknownCorrectionTarget(f"Unknown field key: {key}")
        field_type = field_types.get(key, FieldType.STRING)
        leaf["value"] = value
        leaf["normalized_value"] = (
            None if value is None else _normalize(field_type, value)
        )
        leaf["confidence"] = None

    tables = copy.deepcopy([dict(t) for t in base_tables])
    for cell in layout_table_cells:
        target = _find_cell(tables, cell)
        if target is None:
            raise UnknownCorrectionTarget(
                f"Unknown table cell: {cell.table_index}/{cell.row_index}/{cell.column_index}"
            )
        target["content"] = cell.content
    return CorrectedValues(fields=merged, layout_tables=tables)


def _find_cell(
    tables: list[dict[str, object]], cell: CellCorrection
) -> dict[str, object] | None:
    if not 0 <= cell.table_index < len(tables):
        return None
    cells = cast(list[dict[str, object]], tables[cell.table_index]["cells"])
    return next(
        (
            c
            for c in cells
            if c["row_index"] == cell.row_index
            and c["column_index"] == cell.column_index
        ),
        None,
    )
