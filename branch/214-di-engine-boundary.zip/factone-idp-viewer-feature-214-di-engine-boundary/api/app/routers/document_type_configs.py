"""文書種別設定のCRUD API。

テナントスコープは JWT の tenant_id クレーム（CurrentUser.tenant_id）。
type_codeのリネーム・PATCHは非対応（設計specの意図的な非対応を参照）。
"""

import re
from datetime import datetime
from typing import Annotated, Literal

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, field_validator, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import Document, DocumentTypeConfig
from app.services.di import MAX_QUERY_FIELDS
from app.services.document_type_config import get_config
from app.services.engine import EngineName

router = APIRouter(responses=problem_responses(401, 403, 422))

_CODE_PATTERN = r"^[A-Za-z0-9_]{1,50}$"
# NUL は PostgreSQL の text / jsonb に格納できないため拒否する（改行・TAB などは受け付ける）
_NO_NUL_PATTERN = r"^[^\x00]*$"


class FieldDefPayload(BaseModel):
    key: str = Field(pattern=_CODE_PATTERN)
    label: str = Field(min_length=1, max_length=100, pattern=_NO_NUL_PATTERN)
    type: Literal["string", "number", "date"]
    # Viewerの読み取り結果表示に含めるか（#91）。falseでも抽出・保存・API返却は行う
    visible: bool = True
    # エンジンへ渡す項目の説明（上限は CU の 1024 文字に合わせる）。DI は使わない
    description: str | None = Field(
        default=None, min_length=1, max_length=1024, pattern=_NO_NUL_PATTERN
    )


class PatternDefPayload(BaseModel):
    key: str = Field(pattern=_CODE_PATTERN)
    label: str = Field(min_length=1, max_length=100, pattern=_NO_NUL_PATTERN)
    # ponytail: Python re にタイムアウトが無く、破滅的バックトラックはIDP実行を長時間化する。
    # PoCでは長さ上限とコンパイル検証のみ。本番前に re2 等バックトラックしないエンジンへ差替
    regex: str = Field(min_length=1, max_length=512, pattern=_NO_NUL_PATTERN)

    @field_validator("regex")
    @classmethod
    def regex_must_compile(cls, value: str) -> str:
        try:
            re.compile(value)
        except re.error as exc:
            raise ValueError(f"invalid regex: {exc}") from exc
        return value


class DocumentTypeConfigBody(BaseModel):
    display_name: str = Field(min_length=1, max_length=100, pattern=_NO_NUL_PATTERN)
    shareable: bool
    # 抽出エンジン（ADR-0029）。PUT は全置換のため、省略すると azure-di に戻る
    engine: EngineName = EngineName.AZURE_DI
    fields: list[FieldDefPayload] = Field(min_length=1)
    # DI全文テキストへの正規表現マッチ（#107）。省略可
    patterns: list[PatternDefPayload] = Field(default_factory=list)

    @field_validator("fields", "patterns")
    @classmethod
    def keys_must_be_unique(
        cls, value: list[FieldDefPayload] | list[PatternDefPayload]
    ) -> list[FieldDefPayload] | list[PatternDefPayload]:
        keys = [item.key for item in value]
        if len(keys) != len(set(keys)):
            raise ValueError("keys must be unique")
        return value

    @model_validator(mode="after")
    def _fit_engine(self) -> DocumentTypeConfigBody:
        """選んだエンジンで扱えるスキーマかを検査する（違反は 422 validation-error）。"""
        if self.engine is EngineName.AZURE_DI and len(self.fields) > MAX_QUERY_FIELDS:
            raise ValueError(
                f"azure-di accepts at most {MAX_QUERY_FIELDS} fields (Query Fields limit)"
            )
        return self


class DocumentTypeConfigCreate(DocumentTypeConfigBody):
    type_code: str = Field(pattern=_CODE_PATTERN)


class DocumentTypeConfigResponse(BaseModel):
    type_code: str
    display_name: str
    shareable: bool
    engine: EngineName
    fields: list[FieldDefPayload]
    patterns: list[PatternDefPayload]
    created_at: datetime
    updated_at: datetime


def _to_response(config: DocumentTypeConfig) -> DocumentTypeConfigResponse:
    return DocumentTypeConfigResponse(
        type_code=config.type_code,
        display_name=config.display_name,
        shareable=config.shareable,
        engine=EngineName(config.engine),
        fields=[FieldDefPayload.model_validate(f) for f in config.fields],
        patterns=[PatternDefPayload.model_validate(p) for p in config.patterns],
        created_at=config.created_at,
        updated_at=config.updated_at,
    )


def _get_or_404(session: Session, tenant_id: str, type_code: str) -> DocumentTypeConfig:
    config = get_config(session, tenant_id, type_code)
    if config is None:
        raise ProblemException(
            404, "document-type-not-found", "Document type not found"
        )
    return config


@router.get(
    "/api/v1/config/document-types",
    response_model=list[DocumentTypeConfigResponse],
)
def list_configs(
    user: CurrentUser,
    session: Annotated[Session, Depends(get_db_session)],
) -> list[DocumentTypeConfigResponse]:
    configs = (
        session.execute(
            select(DocumentTypeConfig)
            .where(DocumentTypeConfig.tenant_id == user.tenant_id)
            .order_by(DocumentTypeConfig.type_code)
        )
        .scalars()
        .all()
    )
    return [_to_response(c) for c in configs]


@router.post(
    "/api/v1/config/document-types",
    response_model=DocumentTypeConfigResponse,
    status_code=201,
    responses=problem_responses(409),
)
def create_config(
    user: CurrentUser,
    payload: DocumentTypeConfigCreate,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentTypeConfigResponse:
    tenant_id = user.tenant_id
    if get_config(session, tenant_id, payload.type_code) is not None:
        raise ProblemException(
            409, "document-type-exists", "Document type already exists"
        )
    config = DocumentTypeConfig(
        tenant_id=tenant_id,
        type_code=payload.type_code,
        display_name=payload.display_name,
        shareable=payload.shareable,
        engine=payload.engine.value,
        fields=[f.model_dump() for f in payload.fields],
        patterns=[p.model_dump() for p in payload.patterns],
    )
    session.add(config)
    session.commit()
    return _to_response(config)


@router.get(
    "/api/v1/config/document-types/{type_code}",
    response_model=DocumentTypeConfigResponse,
    responses=problem_responses(404),
)
def get_config_endpoint(
    user: CurrentUser,
    type_code: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentTypeConfigResponse:
    return _to_response(_get_or_404(session, user.tenant_id, type_code))


@router.put(
    "/api/v1/config/document-types/{type_code}",
    response_model=DocumentTypeConfigResponse,
    responses=problem_responses(404),
)
def update_config(
    user: CurrentUser,
    type_code: str,
    payload: DocumentTypeConfigBody,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentTypeConfigResponse:
    config = _get_or_404(session, user.tenant_id, type_code)
    config.display_name = payload.display_name
    config.shareable = payload.shareable
    config.engine = payload.engine.value
    config.fields = [f.model_dump() for f in payload.fields]
    config.patterns = [p.model_dump() for p in payload.patterns]
    session.commit()
    return _to_response(config)


@router.delete(
    "/api/v1/config/document-types/{type_code}",
    status_code=204,
    responses=problem_responses(404, 409),
)
def delete_config(
    user: CurrentUser,
    type_code: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> None:
    tenant_id = user.tenant_id
    config = _get_or_404(session, tenant_id, type_code)
    in_use = session.execute(
        select(Document.id)
        .where(
            Document.tenant_id == tenant_id,
            Document.document_type == type_code,
        )
        .limit(1)
    ).first()
    if in_use is not None:
        raise ProblemException(
            409,
            "document-type-in-use",
            "Document type is in use and cannot be deleted",
        )
    session.delete(config)
    session.commit()
