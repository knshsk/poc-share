import js from '@eslint/js'
import prettierConfig from 'eslint-config-prettier'
import pluginVue from 'eslint-plugin-vue'
import tseslint from 'typescript-eslint'

export default tseslint.config(
  { ignores: ['dist/', 'node_modules/'] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  ...pluginVue.configs['flat/recommended'],
  {
    files: ['**/*.vue'],
    languageOptions: {
      parserOptions: {
        // .vue ファイルの <script lang="ts"> をTypeScriptとして解析する
        parser: tseslint.parser,
      },
    },
  },
  // フォーマットはPrettierに委譲するため、競合するスタイル系ルールを無効化
  prettierConfig,
)
