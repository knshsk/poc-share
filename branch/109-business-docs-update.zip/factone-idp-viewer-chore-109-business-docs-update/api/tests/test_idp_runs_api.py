"""IDP実行APIの統合テスト（実PostgreSQLコンテナ接続）。

事前に `podman compose up -d postgres` が必要。
共有フィクスチャ（doc_client・fake_analyzer等）は conftest.py を参照。
"""

from typing import Any

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text

from app.services.di import DiError, DiTable, DiTableCell
from tests.conftest import FakeDocumentAnalyzer
from tests.test_documents_api import post_document

ORDER_RESULTS = {
    "SenderCompanyName": ("株式会社サンプル商事", 0.98),
    "PurchaseOrderId": ("PO-2026-9101", 0.95),
    "DeliveryDate": ("2026-10-30", 0.97),
    "TotalAmount": ("1,200,000", 0.96),
}

ORDER_TABLES = (
    DiTable(
        row_count=2,
        column_count=2,
        cells=(
            DiTableCell(
                row_index=0,
                column_index=0,
                content="品目",
                kind="columnHeader",
                page_number=1,
                polygon=(1.0, 2.0, 3.0, 2.0),
            ),
            DiTableCell(
                row_index=1,
                column_index=0,
                content="P-9001",
                kind=None,
                page_number=1,
                polygon=(1.0, 3.0, 3.0, 3.0),
            ),
        ),
    ),
    DiTable(row_count=1, column_count=1, cells=()),
)


def run_idp(client: TestClient, document_id: str = "doc-001") -> Any:
    return client.post(f"/api/v1/documents/{document_id}/idp-runs")


def test_first_run_returns_extraction_with_confidence(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """初回実行が201となり、生値・正規化値・確信度が項目別に返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    body = response.json()
    assert body["document_id"] == "doc-001"
    assert body["run_type"] == "initial"
    assert body["status"] == "succeeded"
    assert body["raw_fields"]["TotalAmount"] == "1,200,000"
    assert body["normalized_fields"]["TotalAmount"] == 1200000
    assert body["confidence"]["TotalAmount"] == 0.96
    assert body["error_info"] is None
    assert body["run_id"]
    assert body["executed_at"]


def test_rerun_is_distinguished_and_appended(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """再実行がrerunとして区別され、履歴が上書きされず追記されることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    first = run_idp(doc_client)
    second = run_idp(doc_client)

    assert first.json()["run_type"] == "initial"
    assert second.json()["run_type"] == "rerun"
    assert first.json()["run_id"] != second.json()["run_id"]

    listing = doc_client.get("/api/v1/documents/doc-001/idp-runs")
    assert listing.status_code == 200
    runs = listing.json()["runs"]
    assert len(runs) == 2
    assert [run["run_type"] for run in runs] == ["initial", "rerun"]


def test_run_on_unknown_document_returns_404(doc_client: TestClient) -> None:
    response = run_idp(doc_client, document_id="no-such-doc")
    assert response.status_code == 404


def test_di_failure_returns_502_and_records_failed_run(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """DI障害時に502となり、失敗実行がエラー情報付きで履歴に記録されることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 502
    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert len(runs) == 1
    assert runs[0]["status"] == "failed"
    assert runs[0]["error_info"] == "service unavailable"
    assert runs[0]["raw_fields"] is None


def test_failed_run_then_success_counts_as_rerun(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行も履歴に数え、次の実行はrerunとなることを確認する。"""
    fake_analyzer.error = DiError("timeout")
    post_document(doc_client, document_type="purchase_order")
    run_idp(doc_client)

    fake_analyzer.error = None
    fake_analyzer.results = ORDER_RESULTS
    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["run_type"] == "rerun"


def test_run_requires_authentication(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    post_document(doc_client, document_type="purchase_order")
    doc_client.headers.pop("Authorization")

    assert run_idp(doc_client).status_code == 401
    assert doc_client.get("/api/v1/documents/doc-001/idp-runs").status_code == 401


def test_list_runs_on_unknown_document_returns_404(doc_client: TestClient) -> None:
    response = doc_client.get("/api/v1/documents/no-such-doc/idp-runs")
    assert response.status_code == 404


def test_analyzer_receives_query_fields_for_document_type(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """文書種別に対応するクエリセットでDIが呼ばれることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="quotation")

    run_idp(doc_client)

    assert fake_analyzer.calls
    _, query_fields = fake_analyzer.calls[0]
    assert "QuotationId" in query_fields
    assert "PurchaseOrderId" not in query_fields


def test_run_returns_all_recognized_tables(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """認識されたテーブル領域（明細仮）が全件、実行応答と履歴の両方に返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.tables = ORDER_TABLES
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    tables = response.json()["tables"]
    assert len(tables) == 2
    header = tables[0]["cells"][0]
    assert tables[0]["row_count"] == 2
    assert tables[0]["column_count"] == 2
    assert header["content"] == "品目"
    assert header["kind"] == "columnHeader"
    assert header["page_number"] == 1
    assert header["polygon"] == [1.0, 2.0, 3.0, 2.0]

    listed = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert listed[0]["tables"] == tables


def test_run_without_tables_returns_empty_list(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """成功実行でテーブル未検出の場合は空配列（Noneではない）を確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["tables"] == []


def test_failed_run_has_no_tables(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はtablesがNoneであることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    run_idp(doc_client)

    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert runs[0]["tables"] is None


def test_query_fields_come_from_config(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """設定を書き換えると次回実行のquery_fieldsに反映されることを確認する。"""
    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "special_field", "label": "特殊項目", "type": "string"}],
        },
    )
    post_document(doc_client, document_id="idp-cfg-1", document_type="quotation")
    fake_analyzer.results = {"special_field": ("value-1", 0.9)}
    response = run_idp(doc_client, "idp-cfg-1")
    assert response.status_code == 201
    assert fake_analyzer.calls[-1][1] == ("special_field",)
    assert response.json()["raw_fields"] == {"special_field": "value-1"}


def test_run_returns_field_labels_snapshot(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """成功実行の応答と履歴に実行時点のラベル（key→label）が返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    labels = response.json()["field_labels"]
    assert labels["TotalAmount"] == "合計金額"
    assert labels["DeliveryDate"] == "納品期限"

    listed = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert listed[0]["field_labels"] == labels


def test_field_labels_keep_run_time_value_after_config_change(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """設定のラベル変更後も過去実行は実行時点のラベルを保持することを確認する。"""
    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
        },
    )
    post_document(doc_client, document_id="idp-lbl-1", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9)}
    run_idp(doc_client, "idp-lbl-1")

    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "総額", "type": "number"}],
        },
    )
    run_idp(doc_client, "idp-lbl-1")

    runs = doc_client.get("/api/v1/documents/idp-lbl-1/idp-runs").json()["runs"]
    assert runs[0]["field_labels"] == {"amount": "金額"}
    assert runs[1]["field_labels"] == {"amount": "総額"}


def test_failed_run_has_no_field_labels(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はfield_labelsがNoneであることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    run_idp(doc_client)

    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert runs[0]["field_labels"] is None


def test_unregistered_document_type_returns_409(
    doc_client: TestClient, test_database_url: str
) -> None:
    """設定削除後の残存文書の実行は409（削除保護があるため通常発生しないが防御的に）。"""
    post_document(doc_client, document_id="idp-cfg-2", document_type="quotation")
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(
            text("DELETE FROM document_type_configs WHERE type_code = 'quotation'")
        )
        conn.commit()
    engine.dispose()
    response = run_idp(doc_client, "idp-cfg-2")
    assert response.status_code == 409


def _put_quotation_with_tcode(client: TestClient) -> None:
    client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
            "patterns": [{"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}],
        },
    )


def test_run_returns_pattern_matches_in_order_with_duplicates(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """全文中のTコードを出現順・重複ありで返し、履歴にも同じ内容が保存されることを確認する。"""
    _put_quotation_with_tcode(doc_client)
    post_document(doc_client, document_id="idp-pat-1", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9)}
    fake_analyzer.content = "登録番号 T1234567890123\n合計 100\nT1234567890123"

    response = run_idp(doc_client, "idp-pat-1")

    assert response.status_code == 201
    expected = {
        "TCode": {
            "label": "登録番号",
            "regex": r"T\d{13}",
            "values": ["T1234567890123", "T1234567890123"],
        }
    }
    assert response.json()["pattern_matches"] == expected
    runs = doc_client.get("/api/v1/documents/idp-pat-1/idp-runs").json()["runs"]
    assert runs[0]["pattern_matches"] == expected


def test_run_without_patterns_returns_empty_dict(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """パターン未設定の種別（テストシードは patterns なし）では空dictを返すことを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.content = "T1234567890123"
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["pattern_matches"] == {}


def test_pattern_matches_keep_run_time_regex_after_config_change(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """設定のregex変更後も過去実行は実行時点のregexと結果を保持することを確認する。"""
    _put_quotation_with_tcode(doc_client)
    post_document(doc_client, document_id="idp-pat-2", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9)}
    fake_analyzer.content = "T1234567890123 Q-000001"
    run_idp(doc_client, "idp-pat-2")

    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
            "patterns": [
                {"key": "QuotationNo", "label": "見積番号", "regex": r"Q-\d{6}"}
            ],
        },
    )
    run_idp(doc_client, "idp-pat-2")

    runs = doc_client.get("/api/v1/documents/idp-pat-2/idp-runs").json()["runs"]
    assert list(runs[0]["pattern_matches"]) == ["TCode"]
    assert runs[1]["pattern_matches"] == {
        "QuotationNo": {
            "label": "見積番号",
            "regex": r"Q-\d{6}",
            "values": ["Q-000001"],
        }
    }


def test_failed_run_has_no_pattern_matches(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はpattern_matchesがNoneであることを確認する。"""
    _put_quotation_with_tcode(doc_client)
    post_document(doc_client, document_id="idp-pat-3", document_type="quotation")
    fake_analyzer.error = DiError("service unavailable")

    run_idp(doc_client, "idp-pat-3")

    runs = doc_client.get("/api/v1/documents/idp-pat-3/idp-runs").json()["runs"]
    assert runs[0]["pattern_matches"] is None
