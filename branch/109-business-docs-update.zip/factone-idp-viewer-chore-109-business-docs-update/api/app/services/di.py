"""Document Intelligenceの境界アダプタ。

外部サービス（Azure Document Intelligence）への依存をProtocolで分離し、
テストではフェイクに差し替える。prebuilt-layout+Query Fieldsで項目指定抽出を行う。
"""

import io
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class QueryFieldResult:
    """Query Fieldsの項目別抽出結果（生値と確信度）。"""

    value: str | None
    confidence: float | None


@dataclass(frozen=True)
class DiTableCell:
    """テーブルセル。座標（page_number・polygon）は元応答に無い場合None。"""

    row_index: int
    column_index: int
    content: str
    kind: str | None
    page_number: int | None
    polygon: tuple[float, ...] | None


@dataclass(frozen=True)
class DiTable:
    """DIが認識したテーブル領域（明細仮）。意味付けは行わず認識結果を素通しする。"""

    row_count: int
    column_count: int
    cells: tuple[DiTableCell, ...]


def extract_tables(tables: object) -> tuple[DiTable, ...]:
    """layout応答のtablesをDiTableへ変換する。複数認識時は全件返す。"""
    extracted: list[DiTable] = []
    for table in tables or []:  # type: ignore[attr-defined]
        cells = []
        for cell in table.cells or []:
            region = (cell.bounding_regions or [None])[0]
            cells.append(
                DiTableCell(
                    row_index=cell.row_index,
                    column_index=cell.column_index,
                    content=cell.content,
                    kind=cell.kind,
                    page_number=region.page_number if region else None,
                    polygon=tuple(region.polygon) if region else None,
                )
            )
        extracted.append(
            DiTable(
                row_count=table.row_count,
                column_count=table.column_count,
                cells=tuple(cells),
            )
        )
    return tuple(extracted)


@dataclass(frozen=True)
class AnalysisResult:
    """解析結果。Query Fields抽出値・認識テーブル領域（明細仮）・全文テキストを保持する。"""

    fields: dict[str, QueryFieldResult]
    tables: tuple[DiTable, ...]
    # 読み順で連結した全文テキスト。正規表現パターンマッチの対象
    content: str = ""


class DiError(Exception):
    """Document Intelligence呼出の失敗（タイムアウト・サービス障害・未設定）。"""


class DocumentAnalyzer(Protocol):
    """PDF解析の境界。query_fieldsで指定した項目の抽出結果とテーブル領域を返す。"""

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult: ...


class UnconfiguredAnalyzer:
    """接続先未設定時のプレースホルダ（ローカル開発でDI未設定のまま起動可能にする）。"""

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult:
        raise DiError("Document Intelligence endpoint is not configured")


class AzureDocumentAnalyzer:
    """Azure Document Intelligence実装（prebuilt-layout+Query Fields）。

    api_key未設定時はManaged ID（DefaultAzureCredential）で認証する。
    """

    def __init__(self, endpoint: str, api_key: str, timeout_seconds: int) -> None:
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        from azure.core.credentials import AzureKeyCredential

        credential: object
        if api_key:
            credential = AzureKeyCredential(api_key)
        else:
            from azure.identity import DefaultAzureCredential

            credential = DefaultAzureCredential()
        self._client = DocumentIntelligenceClient(endpoint, credential)
        self._timeout_seconds = timeout_seconds

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult:
        from azure.ai.documentintelligence.models import DocumentAnalysisFeature
        from azure.core.exceptions import AzureError

        try:
            poller = self._client.begin_analyze_document(
                "prebuilt-layout",
                io.BytesIO(pdf),
                content_type="application/pdf",
                features=[DocumentAnalysisFeature.QUERY_FIELDS],
                query_fields=list(query_fields),
            )
            result = poller.result(timeout=self._timeout_seconds)
        except AzureError as exc:
            raise DiError(str(exc)) from exc

        extracted: dict[str, QueryFieldResult] = {}
        for document in result.documents or []:
            for name, field in (document.fields or {}).items():
                extracted[name] = QueryFieldResult(
                    value=field.content, confidence=field.confidence
                )
        return AnalysisResult(
            fields=extracted,
            tables=extract_tables(result.tables),
            content=result.content or "",
        )


def create_document_analyzer(
    endpoint: str, api_key: str, timeout_seconds: int
) -> DocumentAnalyzer:
    if endpoint:
        return AzureDocumentAnalyzer(endpoint, api_key, timeout_seconds)
    return UnconfiguredAnalyzer()
