<script setup lang="ts">
import { PhSignOut, PhUserCircle } from '@phosphor-icons/vue'

import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
</script>

<template>
  <v-app-bar flat border density="comfortable" color="surface">
    <template #prepend>
      <span class="app-logo text-primary">FactONE Viewer</span>
    </template>

    <!-- 文書コンテキスト（文書IDバッジ・種別チップ）はPhase 2で追加 -->

    <template #append>
      <v-menu location="bottom end">
        <template #activator="{ props: menuProps }">
          <v-btn
            v-bind="menuProps"
            variant="text"
            data-testid="user-menu"
            class="text-none"
          >
            <PhUserCircle :size="20" class="mr-1" />
            {{ auth.username ?? '' }}
          </v-btn>
        </template>
        <v-list density="compact">
          <v-list-item data-testid="logout" @click="auth.logout">
            <template #prepend>
              <PhSignOut :size="18" class="mr-2" />
            </template>
            <v-list-item-title>ログアウト</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </template>
  </v-app-bar>
</template>

<style scoped>
.app-logo {
  font-weight: 700;
  font-size: 1rem;
  letter-spacing: 0.02em;
}
</style>
