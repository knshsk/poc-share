import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// 実行API呼出はapiClient経由のためモックする（パネルは操作と表示分岐が検証対象）
const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
}))

import WorkPanel from '../src/components/WorkPanel.vue'
import { useDraftStore } from '../src/stores/draft'
import { useHighlightStore } from '../src/stores/highlight'

const succeededRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-08-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  raw_fields: { order_no: 'A-001', total_amount: '1,000' },
  normalized_fields: { order_no: 'A-001', total_amount: 1000 },
  confidence: { order_no: 0.98, total_amount: 0.75 },
  field_labels: null,
  field_regions: null,
  tables: [],
  pattern_matches: {},
  corrections: null,
}

const failedRun = {
  ...succeededRun,
  run_id: '22222222-2222-2222-2222-222222222222',
  run_type: 'rerun',
  status: 'failed',
  executed_at: '2026-08-02T00:00:00Z',
  raw_fields: null,
  normalized_fields: null,
  confidence: null,
  tables: null,
  pattern_matches: null,
  error_info: 'DI request failed',
}

const correctedRun = {
  ...succeededRun,
  run_id: '33333333-3333-3333-3333-333333333333',
  run_type: 'corrected',
  executed_at: '2026-08-03T00:00:00Z',
  base_run_id: succeededRun.run_id,
  corrected_by: 'testuser',
  raw_fields: { order_no: 'A-002', total_amount: '1,000' },
  confidence: { order_no: null, total_amount: 0.75 },
  corrections: { fields: { order_no: 'A-002' }, table_cells: [] },
}

type RunLike = typeof succeededRun | typeof failedRun | typeof correctedRun
type FieldDef = {
  key: string
  label: string
  type: 'string' | 'number' | 'date'
  visible: boolean
}

// 一覧はサマリ（項目値・テーブルを含まない）、詳細は run_id で個別取得する現行APIを模す
function toSummary(run: RunLike) {
  return {
    run_id: run.run_id,
    document_id: run.document_id,
    run_type: run.run_type,
    status: run.status,
    executed_at: run.executed_at,
    base_run_id: run.base_run_id,
    corrected_by: run.corrected_by,
    di_api_version: run.di_api_version,
    di_model_id: run.di_model_id,
    error_info: run.error_info,
  }
}

function mockRuns(runs: RunLike[]): void {
  getMock.mockImplementation(
    (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return Promise.resolve({
          data: { document_id: 'doc-1', runs: runs.map(toSummary) },
          error: undefined,
        })
      }
      if (path === '/api/v1/documents/{document_id}/idp-runs/{run_id}') {
        const run = runs.find((r) => r.run_id === options?.params?.path?.run_id)
        return Promise.resolve(
          run
            ? { data: run, error: undefined }
            : { data: undefined, error: { status: 404 } },
        )
      }
      return Promise.resolve({ data: undefined, error: undefined })
    },
  )
}

function mountPanel(
  shareable = false,
  fieldDefs: FieldDef[] = [],
  attachTo?: HTMLElement,
) {
  return mount(WorkPanel, {
    props: { documentId: 'doc-1', shareable, fieldDefs },
    global: { plugins: [createAppVuetify()] },
    attachTo,
  })
}

function fieldInputs(wrapper: ReturnType<typeof mountPanel>) {
  return wrapper.findAll('[data-testid="field-input"] input')
}

async function openHistory(wrapper: ReturnType<typeof mountPanel>) {
  await wrapper.get('[data-testid="tab-history"]').trigger('click')
  await flushPromises()
  return wrapper.findAll('[data-testid="run-row"]')
}

// ダイアログ・スナックバーはbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  setActivePinia(createPinia())
  getMock.mockReset()
  postMock.mockReset()
  mockRuns([])
})

describe('WorkPanel', () => {
  // 文書表示時に一覧を自動取得し、最新実行の詳細を個別取得して表示することを確認する
  it('マウント時に一覧を取得し、最新実行の詳細を個別取得して表示する', async () => {
    // サーバ応答は実行日時昇順。最新（末尾のfailedRun）を初期選択し、詳細APIで取得する
    mockRuns([succeededRun, failedRun])

    const wrapper = mountPanel()
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1', run_id: failedRun.run_id } },
      }),
    )
    // 最新=failedRunのためエラー情報が表示され、アクションバーは出ない
    expect(wrapper.get('[data-testid="run-error"]').text()).toContain(
      'DI request failed',
    )
    expect(wrapper.find('[data-testid="confirm-corrections"]').exists()).toBe(
      false,
    )
    expect(getMock.mock.calls.map(([path]) => path)).toEqual([
      '/api/v1/documents/{document_id}/idp-runs',
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
    ])
  })

  // 成功実行選択時、ラベル・値（入力欄）・確信度が表示され、チップに区分と日時が出ることを確認する
  it('成功実行の項目・確信度・選択中チップを表示する', async () => {
    mockRuns([succeededRun])

    const wrapper = mountPanel(false, [
      { key: 'order_no', label: '注文番号', type: 'string', visible: true },
    ])
    await flushPromises()

    const text = wrapper.text()
    expect(text).toContain('order_no')
    expect(text).toContain('total_amount')
    expect(text).toContain('98%')
    expect(text).toContain('75%')
    const inputs = fieldInputs(wrapper)
    expect((inputs[0]!.element as HTMLInputElement).value).toBe('A-001')
    expect((inputs[1]!.element as HTMLInputElement).value).toBe('1,000')
    expect(wrapper.get('[data-testid="selected-run-chip"]').text()).toContain(
      '初回',
    )
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 0件',
    )
    expect(
      wrapper.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeDefined()
    expect(
      wrapper.get('[data-testid="discard-draft"]').attributes('disabled'),
    ).toBeDefined()
  })

  // IDP実行ボタンでPOSTし、応答結果が表示・履歴追加されることを確認する
  it('IDP実行ボタンでPOSTし結果を表示する', async () => {
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    expect(wrapper.text()).toContain('order_no')
    expect(wrapper.text()).toContain('98%')
    expect(await openHistory(wrapper)).toHaveLength(1)
  })

  // 実行失敗（API呼出エラー）時にエラーメッセージが表示されることを確認する
  it('POST失敗時にエラーメッセージを表示する', async () => {
    postMock.mockResolvedValue({
      data: undefined,
      error: { detail: 'Document analysis failed' },
    })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('IDP実行に失敗しました')
  })

  // 実行API呼出自体が失敗（ネットワークエラー等でPromiseがreject）した場合もエラーメッセージを表示する
  it('IDP実行がネットワークエラーで失敗した場合エラーメッセージを表示する', async () => {
    postMock.mockRejectedValue(new Error('network'))

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('IDP実行に失敗しました')
  })

  // 一覧取得中にIDP実行が完了した場合、遅れて届く一覧応答で選択・表示中の実行を上書きしないことを確認する
  it('一覧取得中にIDP実行が完了した場合は実行結果の選択を維持する', async () => {
    let resolveList: (value: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return new Promise((resolve) => {
          resolveList = resolve
        })
      }
      return Promise.resolve({ data: undefined, error: undefined })
    })
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    resolveList({
      data: { document_id: 'doc-1', runs: [toSummary(failedRun)] },
      error: undefined,
    })
    await flushPromises()

    expect(fieldInputs(wrapper)).toHaveLength(2)
    expect(wrapper.find('[data-testid="run-error"]').exists()).toBe(false)
    expect(await openHistory(wrapper)).toHaveLength(2)
  })

  // 履歴行選択で当該実行の結果へ表示が切り替わる。履歴は区分「初回/再実行/修正」と修正者を表示する
  it('履歴行選択で該当実行の結果を表示し、履歴に区分と修正者を表示する', async () => {
    mockRuns([succeededRun, failedRun, correctedRun])

    const wrapper = mountPanel()
    await flushPromises()

    const rows = await openHistory(wrapper)
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('修正')
    expect(rows[0]!.text()).toContain('testuser')
    expect(rows[1]!.text()).toContain('再実行')
    expect(rows[1]!.text()).toContain('失敗')
    expect(rows[2]!.text()).toContain('初回')
    expect(wrapper.text()).not.toContain('prebuilt-layout')
    expect(wrapper.text()).not.toContain('2024-11-30')

    await rows[2]!.trigger('click')
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1', run_id: succeededRun.run_id } },
      }),
    )
    expect((fieldInputs(wrapper)[0]!.element as HTMLInputElement).value).toBe(
      'A-001',
    )
  })

  // 修正行を選択するとチップが「修正 · 日時 · 修正者」になり、保存済み修正に修正済みマークが付く
  it('修正行のチップと修正済みマークを表示する', async () => {
    mockRuns([succeededRun, correctedRun])

    const wrapper = mountPanel()
    await flushPromises()

    const chip = wrapper.get('[data-testid="selected-run-chip"]')
    expect(chip.text()).toContain('修正')
    expect(chip.text()).toContain('testuser')
    expect(wrapper.findAll('[data-testid="corrected-mark"]')).toHaveLength(1)
  })

  // 確信度が3段階の色トークンでバー表示されることを確認する
  it('確信度バーを3段階の色で表示する', async () => {
    mockRuns([succeededRun])

    const wrapper = mountPanel()
    await flushPromises()

    const bars = wrapper.findAll('[data-testid="confidence-bar"]')
    expect(bars).toHaveLength(2)
    // order_no: 0.98 -> success / total_amount: 0.75 -> error
    expect(bars[0]!.classes().join(' ')).toContain('text-success')
    expect(bars[1]!.classes().join(' ')).toContain('text-error')
  })

  // 項目名は実行時ラベル（field_labels）を表示し、無い項目はキー名フォールバックすることを確認する
  it('field_labelsのラベルを項目名表示しキー名フォールバックする', async () => {
    mockRuns([{ ...succeededRun, field_labels: { order_no: '注文番号' } }])

    const wrapper = mountPanel()
    await flushPromises()

    const text = wrapper.text()
    expect(text).toContain('注文番号')
    expect(text).not.toContain('order_no')
    expect(text).toContain('total_amount')
  })

  // 設定でvisible=falseの項目は読み取り結果に表示しないことを確認する（#91）
  it('visible=falseの項目を読み取り結果から除外する', async () => {
    mockRuns([succeededRun])

    const wrapper = mountPanel(false, [
      {
        key: 'total_amount',
        label: '合計金額',
        type: 'number',
        visible: false,
      },
      { key: 'not_in_run', label: 'x', type: 'string', visible: false },
    ])
    await flushPromises()

    expect(wrapper.findAll('[data-testid="field-row"]')).toHaveLength(1)
    expect(wrapper.text()).toContain('order_no')
    expect(wrapper.text()).not.toContain('total_amount')
  })

  // 閲覧URLタブは設定のshareableで表示制御することを確認する（#81・ADR-0002）
  it('shareable=trueで閲覧URLタブを表示し、falseでは表示しない', async () => {
    const notShareable = mountPanel(false)
    await flushPromises()
    expect(notShareable.find('[data-testid="tab-urls"]').exists()).toBe(false)

    const shareable = mountPanel(true)
    await flushPromises()
    expect(shareable.find('[data-testid="tab-urls"]').exists()).toBe(true)
  })

  // 詳細取得の失敗時はエラーメッセージを表示することを確認する
  it('詳細取得に失敗するとエラーメッセージを表示する', async () => {
    getMock.mockImplementation((path: string) =>
      Promise.resolve(
        path === '/api/v1/documents/{document_id}/idp-runs'
          ? {
              data: { document_id: 'doc-1', runs: [toSummary(succeededRun)] },
              error: undefined,
            }
          : { data: undefined, error: { status: 500 } },
      ),
    )

    const wrapper = mountPanel()
    await flushPromises()

    expect(wrapper.text()).toContain('実行結果を取得できませんでした')
  })

  // 取得済みの詳細は再選択時に再取得しないことを確認する
  it('取得済みの詳細はキャッシュし再取得しない', async () => {
    mockRuns([succeededRun, failedRun])
    const wrapper = mountPanel()
    await flushPromises()

    let rows = await openHistory(wrapper)
    await rows[1]!.trigger('click')
    await flushPromises()
    rows = await openHistory(wrapper)
    await rows[0]!.trigger('click')
    await flushPromises()

    const detailCalls = getMock.mock.calls.filter(
      ([path]) => path === '/api/v1/documents/{document_id}/idp-runs/{run_id}',
    )
    expect(detailCalls).toHaveLength(2)
  })

  // 応答待ちの間に別の実行を選択した場合、遅れて届いた古い応答で表示を上書きしないことを確認する
  it('応答待ち中に別の実行を選択した場合は古い応答を表示しない', async () => {
    let resolveDetail: (value: unknown) => void = () => {}
    getMock.mockImplementation(
      (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
        if (path === '/api/v1/documents/{document_id}/idp-runs') {
          return Promise.resolve({
            data: {
              document_id: 'doc-1',
              runs: [succeededRun, failedRun].map(toSummary),
            },
            error: undefined,
          })
        }
        if (options?.params?.path?.run_id === succeededRun.run_id) {
          return new Promise((resolve) => {
            resolveDetail = resolve
          })
        }
        return Promise.resolve({ data: failedRun, error: undefined })
      },
    )

    const wrapper = mountPanel()
    await flushPromises()

    let rows = await openHistory(wrapper)
    await rows[1]!.trigger('click')
    rows = await openHistory(wrapper)
    await rows[0]!.trigger('click')
    await flushPromises()

    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()

    expect(wrapper.text()).toContain('DI request failed')
    expect(fieldInputs(wrapper)).toHaveLength(0)
  })

  // IDP実行の応答後に、それ以前に要求した詳細取得の応答が届いても上書きしないことを確認する（#114 持ち越し）
  it('IDP実行後に遅れて届いた詳細応答で表示を上書きしない', async () => {
    let resolveDetail: (value: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return Promise.resolve({
          data: { document_id: 'doc-1', runs: [toSummary(succeededRun)] },
          error: undefined,
        })
      }
      return new Promise((resolve) => {
        resolveDetail = resolve
      })
    })
    postMock.mockResolvedValue({ data: failedRun, error: undefined })

    const wrapper = mountPanel()
    await flushPromises()
    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()
    expect(wrapper.text()).toContain('DI request failed')

    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()

    expect(wrapper.text()).toContain('DI request failed')
    expect(fieldInputs(wrapper)).toHaveLength(0)
  })

  // 編集で件数が増えて確定・破棄が有効になり、破棄で下書きが消えることを確認する
  it('編集で変更件数が増え、破棄で元に戻る', async () => {
    mockRuns([succeededRun])
    const wrapper = mountPanel()
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 1件',
    )
    expect(
      wrapper.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeUndefined()

    await wrapper.get('[data-testid="discard-draft"]').trigger('click')
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 0件',
    )
    expect((fieldInputs(wrapper)[0]!.element as HTMLInputElement).value).toBe(
      'A-001',
    )
  })

  // 確定で差分ボディをPOSTし、応答の修正行を選択・履歴追加し、下書きをリセットしてスナックバーを出す
  it('確定で差分をPOSTし、応答の修正行を選択して履歴へ追加する', async () => {
    mockRuns([succeededRun])
    postMock.mockResolvedValue({ data: correctedRun, error: undefined })
    const wrapper = mountPanel()
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections',
      expect.objectContaining({
        params: {
          path: { document_id: 'doc-1', run_id: succeededRun.run_id },
        },
        body: { fields: { order_no: 'A-002' }, table_cells: [] },
      }),
    )
    expect(wrapper.get('[data-testid="selected-run-chip"]').text()).toContain(
      '修正',
    )
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 0件',
    )
    expect(useDraftStore().dirty).toBe(false)
    expect(document.body.textContent).toContain('修正を保存しました')
    const rows = await openHistory(wrapper)
    expect(rows).toHaveLength(2)
    expect(rows[0]!.text()).toContain('修正')
  })

  // 確定失敗時はエラー表示し、下書きは保持する
  it('確定に失敗するとエラーを表示し下書きを保持する', async () => {
    mockRuns([succeededRun])
    postMock.mockResolvedValue({ data: undefined, error: { status: 422 } })
    const wrapper = mountPanel()
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('修正の保存に失敗しました')
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 1件',
    )
  })

  // 保存中は確定ボタンを無効化する（loadingはポインタ操作のみ抑止しEnterで二重送信し得るため）
  it('保存中は確定ボタンを無効化し二重送信しない', async () => {
    mockRuns([succeededRun])
    postMock.mockImplementation(() => new Promise(() => {}))
    const wrapper = mountPanel()
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    await flushPromises()

    expect(
      wrapper.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeDefined()
    expect(postMock).toHaveBeenCalledTimes(1)

    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    await flushPromises()
    expect(postMock).toHaveBeenCalledTimes(1)
  })

  // 未保存の変更がある状態での履歴選択は確認ダイアログを挟み、キャンセルで維持・破棄して続行で切替
  it('未保存の変更があるときの履歴選択は確認ダイアログを挟む', async () => {
    mockRuns([succeededRun, failedRun])
    const wrapper = mountPanel()
    await flushPromises()
    let rows = await openHistory(wrapper)
    await rows[1]!.trigger('click')
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    rows = await openHistory(wrapper)
    await rows[0]!.trigger('click')
    await flushPromises()

    const dialog = document.querySelector('[data-testid="discard-dialog"]')
    expect(dialog?.textContent).toContain('未保存の変更を破棄しますか？')
    // ダイアログのアクセシブル名はタイトル要素（aria-labelledby）
    const titleId = document
      .querySelector('[role="dialog"]')
      ?.getAttribute('aria-labelledby')
    expect(titleId).toBeTruthy()
    expect(document.getElementById(titleId!)?.textContent).toContain(
      '未保存の変更を破棄しますか？',
    )
    ;(
      document.querySelector('[data-testid="discard-cancel"]') as HTMLElement
    ).click()
    await flushPromises()
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 1件',
    )
    expect(wrapper.find('[data-testid="run-error"]').exists()).toBe(false)

    rows = await openHistory(wrapper)
    await rows[0]!.trigger('click')
    await flushPromises()
    ;(
      document.querySelector('[data-testid="discard-proceed"]') as HTMLElement
    ).click()
    await flushPromises()
    expect(wrapper.get('[data-testid="run-error"]').text()).toContain(
      'DI request failed',
    )
    expect(useDraftStore().dirty).toBe(false)
  })

  // 未保存の変更があるときのIDP実行も確認ダイアログを挟み、破棄して続行でPOSTされる
  it('未保存の変更があるときのIDP実行は確認ダイアログを挟む', async () => {
    mockRuns([succeededRun])
    postMock.mockResolvedValue({ data: failedRun, error: undefined })
    const wrapper = mountPanel()
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()
    expect(postMock).not.toHaveBeenCalled()
    ;(
      document.querySelector('[data-testid="discard-proceed"]') as HTMLElement
    ).click()
    await flushPromises()

    expect(postMock).toHaveBeenCalledTimes(1)
    expect(wrapper.text()).toContain('DI request failed')
  })

  // 未保存の変更があるときはブラウザ離脱に標準警告を出す（beforeunload）
  it('未保存の変更があるときbeforeunloadで警告する', async () => {
    mockRuns([succeededRun])
    const wrapper = mountPanel()
    await flushPromises()

    const clean = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(clean)
    expect(clean.defaultPrevented).toBe(false)

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    const dirty = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(dirty)
    expect(dirty.defaultPrevented).toBe(true)

    wrapper.unmount()
    const after = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(after)
    expect(after.defaultPrevented).toBe(false)
  })

  // アンマウント時に保留中の確認操作（guard）を取り消し、居残ったpendingが後続guardを解除不能にしないことを確認する
  it('アンマウント時に保留中の確認操作を取り消す', async () => {
    mockRuns([succeededRun, failedRun])
    const wrapper = mountPanel()
    await flushPromises()

    let rows = await openHistory(wrapper)
    await rows[1]!.trigger('click')
    await flushPromises()

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    rows = await openHistory(wrapper)
    await rows[0]!.trigger('click')
    await flushPromises()

    expect(useDraftStore().pending).not.toBeNull()

    wrapper.unmount()

    expect(useDraftStore().pending).toBeNull()
  })

  // 選択中の実行をキャンバス（矩形描画）へ渡すため、選択が変わるたびに update:selectedRun を emit する
  it('選択中の実行が変わるとupdate:selectedRunをemitする', async () => {
    mockRuns([succeededRun, failedRun])
    postMock.mockResolvedValue({ data: correctedRun, error: undefined })
    const wrapper = mountPanel()
    await flushPromises()

    const emitted = () => wrapper.emitted('update:selectedRun') ?? []
    expect(emitted().at(-1)?.[0]).toMatchObject({ run_id: failedRun.run_id })

    const rows = await openHistory(wrapper)
    await rows[1]!.trigger('click')
    await flushPromises()
    expect(emitted().at(-1)?.[0]).toMatchObject({ run_id: succeededRun.run_id })

    await fieldInputs(wrapper)[0]!.setValue('A-002')
    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    await flushPromises()
    expect(emitted().at(-1)?.[0]).toMatchObject({ run_id: correctedRun.run_id })
  })

  // キャンバス側クリック（paneFocus 要求）で読取結果タブへ切り替える
  it('paneFocus要求で読取結果タブへ切り替える', async () => {
    mockRuns([succeededRun])
    const wrapper = mountPanel()
    await flushPromises()
    await openHistory(wrapper)
    expect(wrapper.get('[data-testid="tab-history"]').classes()).toContain(
      'v-tab--selected',
    )

    useHighlightStore().selectFromCanvas('field:order_no')
    await flushPromises()

    expect(wrapper.get('[data-testid="tab-result"]').classes()).toContain(
      'v-tab--selected',
    )
    expect(wrapper.get('[data-testid="tab-history"]').classes()).not.toContain(
      'v-tab--selected',
    )
  })

  // 実行履歴タブ表示中でも読取結果タブの ResultEditor は保持され（v-show）、
  // 矩形クリックによる paneFocus 要求が取りこぼされず入力欄へフォーカスされることを確認する
  it('実行履歴タブ表示中のpaneFocus要求でも該当入力欄へフォーカスする', async () => {
    mockRuns([succeededRun])
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountPanel(false, [], host)
    try {
      await flushPromises()
      await openHistory(wrapper)

      useHighlightStore().selectFromCanvas('field:order_no')
      await flushPromises()
      await flushPromises()

      const input = fieldInputs(wrapper)[0]!.element
      expect(document.activeElement).toBe(input)
    } finally {
      wrapper.unmount()
      host.remove()
      // @ts-expect-error jsdom に無いメソッドを差し込んだ後始末
      delete Element.prototype.scrollIntoView
    }
  })

  // 履歴選択・IDP実行で選択を解除する（照合対象が変わるため）
  it('履歴選択とIDP実行でhighlightを解除する', async () => {
    mockRuns([succeededRun, failedRun])
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })
    const wrapper = mountPanel()
    await flushPromises()
    const highlight = useHighlightStore()

    highlight.selectFromPane('field:order_no')
    const rows = await openHistory(wrapper)
    await rows[1]!.trigger('click')
    await flushPromises()
    expect(highlight.activeId).toBeNull()

    highlight.selectFromPane('field:order_no')
    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()
    expect(highlight.activeId).toBeNull()
  })
})
