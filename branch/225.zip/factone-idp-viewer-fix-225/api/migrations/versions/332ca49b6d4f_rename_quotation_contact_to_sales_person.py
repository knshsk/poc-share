"""見積書のシードの担当者の項目を、取引先担当者から営業担当者に改める

見積書に載る担当者は、見積書を発行した自社の営業担当者である。default テナントの quotation /
quotation_di の CustomerContactPersonName（取引先担当者）を、並び順を変えずに SalesPersonName
（営業担当者）に書き換える。quotation（CU）の説明も発行元の営業担当者を指すように改め、
quotation_di には今までどおり説明を付けない（#225）。注文書の種別と既存の実行結果は変えない。

Revision ID: 332ca49b6d4f
Revises: f1a6c3e8b2d4
Create Date: 2026-11-06 12:00:00.000000

"""

import json
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "332ca49b6d4f"
down_revision: str | None = "f1a6c3e8b2d4"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CONTACT = {"key": "CustomerContactPersonName", "label": "取引先担当者"}
_SALES = {"key": "SalesPersonName", "label": "営業担当者"}
_CONTACT_DESCRIPTION = "Name of the contact person at the addressee company."
_SALES_DESCRIPTION = (
    "Name of the sales person in charge at the company that issued this quotation."
)


def _replace(type_code: str, key: str, patch: dict[str, str]) -> None:
    """type_code の項目 key に patch を重ねる（並び順は保つ）。"""
    op.execute(
        sa.text(
            "UPDATE document_type_configs SET fields = ("
            "SELECT jsonb_agg(CASE WHEN f ->> 'key' = :key "
            "THEN f || CAST(:patch AS jsonb) ELSE f END ORDER BY i) "
            "FROM jsonb_array_elements(fields) WITH ORDINALITY AS t(f, i)) "
            "WHERE tenant_id = 'default' AND type_code = :code"
        ).bindparams(
            key=key, patch=json.dumps(patch, ensure_ascii=False), code=type_code
        )
    )


def upgrade() -> None:
    _replace(
        "quotation", _CONTACT["key"], {**_SALES, "description": _SALES_DESCRIPTION}
    )
    _replace("quotation_di", _CONTACT["key"], _SALES)


def downgrade() -> None:
    _replace(
        "quotation", _SALES["key"], {**_CONTACT, "description": _CONTACT_DESCRIPTION}
    )
    _replace("quotation_di", _SALES["key"], _CONTACT)
