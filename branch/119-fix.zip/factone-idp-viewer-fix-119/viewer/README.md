# FactONE IDP/Viewer フロントエンド

Vue 3 + Vuetify + Pinia 製の SPA。ディレクトリ構成は [create-vue](https://github.com/vuejs/create-vue) が生成するタイプベース（種類別）構造に準拠しています。

## ディレクトリ構成

```
viewer/
├── src/                   # アプリケーション本体
│   ├── main.ts            # エントリポイント。アプリ生成とプラグイン登録のみ
│   ├── App.vue            # ルートコンポーネント。認証状態に応じたビュー切り替え
│   ├── api/               # API クライアント
│   │   ├── client.ts      # openapi-fetch クライアント（認証ヘッダー付与）
│   │   └── schema.d.ts    # OpenAPI から自動生成した型（手動編集禁止）
│   ├── assets/            # グローバル CSS・静的アセット
│   │   └── main.css       # フォント定義・アプリ全体の基本スタイル
│   ├── components/        # 再利用可能な UI 部品
│   │   ├── AppHeader.vue      # アプリバー（ロゴ・文書コンテキスト・ユーザメニュー）
│   │   ├── DocumentCanvas.vue # ページ表示＋ナビ/ズーム（幅・高さ・全体フィット）＋読取矩形のキャンバス
│   │   ├── DocumentRegisterForm.vue # 文書登録フォーム（定型外フロー向け・empty stateのダイアログ内）
│   │   ├── PageSvg.vue        # ページ画像 + 読取矩形オーバーレイ（ID・選択中・クリック）
│   │   ├── ResultEditor.vue   # 読取結果タブ本体（キー項目 / キー項目候補 / グリッドの3区分と編集）
│   │   ├── ViewUrlPanel.vue   # 閲覧用 URL 発行・管理（WorkPanel のタブ内）
│   │   └── WorkPanel.vue      # 作業パネル（読取結果・実行履歴・閲覧 URL のタブ、修正の確定・破棄）
│   ├── views/             # 画面単位のコンポーネント
│   │   ├── DocumentView.vue   # ドキュメント閲覧画面（認証あり）
│   │   └── PublicView.vue     # 公開閲覧画面（閲覧トークン）
│   ├── stores/            # Pinia ストア
│   │   ├── auth.ts        # 認証状態（OIDC トークン管理）
│   │   ├── document.ts    # 文書コンテキスト（ID・種別・項目定義）
│   │   ├── draft.ts       # 読取結果の下書き差分と未保存ガード
│   │   └── highlight.ts   # キャンバス⇄右ペインの相互ハイライト状態
│   ├── plugins/           # プラグイン設定
│   │   └── vuetify.ts     # Vuetify テーマ（カラートークンの唯一の定義箇所）・アイコン設定
│   └── utils/             # 表示フォーマッタ等の純粋関数
│       ├── download.ts    # Content-Disposition からファイル名決定（原本DL用）
│       ├── format.ts      # 確信度・日時フォーマッタ
│       ├── normalize.ts   # 正規化ヒント（サーバの _normalize と同規則）
│       ├── runs.ts        # 実行結果 JSON 列の型付けと区分ラベル
│       └── zoom.ts        # キャンバスのフィット倍率計算
├── tests/                 # Vitest テスト（setup.ts が共通セットアップ）
├── public/                # そのまま配信される静的ファイル
├── index.html             # SPA エントリ HTML
├── vite.config.ts         # Vite ビルド設定
├── vitest.config.ts       # Vitest テスト設定
├── eslint.config.ts       # ESLint 設定
├── tsconfig.json          # TypeScript 設定（app / node に分割）
└── package.json           # 依存管理は npm
```

## 各ディレクトリの責務と配置指針

新しいモジュールをどこに置くか・どこを編集するかの判断基準です。

### `views/` — 画面

- 1 つの画面（URL やアプリ状態に対応する表示単位）を構成するコンポーネントを置く層。データ取得と画面全体のレイアウトを担当します
- **新しい画面を追加するとき**: ここに新規ファイルを作成し、`App.vue` の切り替えロジックに組み込みます

### `components/` — UI 部品

- 複数の画面から使われる、または画面から切り出した再利用可能な UI 部品を置く層。データは原則 props で受け取り、画面全体の状態には依存させません
- **画面の一部を部品化するとき**: ここに新規ファイルを作成し、`views/` から import します

### `stores/` — 状態管理

- Pinia ストアを置く層。複数コンポーネントで共有する状態はここに集約します
- **共有状態を追加するとき**: ここに新規ファイルを作成します。単一コンポーネント内で完結する状態はコンポーネントの `ref` で持ちます

### `api/` — API クライアント

- バックエンド API との通信を置く層です
- `schema.d.ts` は OpenAPI 定義からの自動生成物のため手動編集しません。**API 契約が変わったときは `npm run generate:api` で再生成**し、差分をコミットします（pre-commit の差分チェック対象）

### `plugins/` — プラグイン設定

- Vue プラグイン（Vuetify 等）の生成・設定を置く層。`main.ts` から登録します

### `src/` 直下

- `main.ts`: エントリポイント。アプリ生成とプラグイン登録のみを行い、ビジネスロジックは書きません
- `App.vue`: ルートコンポーネント。表示するビューの切り替えのみを担当し、画面の中身は `views/` に置きます

## 起動・テスト

```
npm run dev            # 開発サーバー起動
npm run test           # テスト
npm run build          # 型チェック + ビルド
npm run lint           # lint
npm run generate:api   # OpenAPI エクスポート + TS 型再生成
```
