import { mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

// 画像取得はapiClient経由のためモックする（コンポーネントは座標系整合が検証対象）
const getMock = vi
  .fn()
  .mockResolvedValue({ data: new Blob(), error: undefined })
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
}))

import PageSvg from '../src/components/PageSvg.vue'

// jsdomに存在しないIntersectionObserverのスタブ。trigger()で交差通知を模擬する
class IntersectionObserverStub {
  static instances: IntersectionObserverStub[] = []
  disconnected = false
  private readonly callback: IntersectionObserverCallback

  constructor(callback: IntersectionObserverCallback) {
    this.callback = callback
    IntersectionObserverStub.instances.push(this)
  }

  observe(): void {}
  disconnect(): void {
    this.disconnected = true
  }

  trigger(isIntersecting: boolean): void {
    this.callback(
      [{ isIntersecting } as IntersectionObserverEntry],
      this as unknown as IntersectionObserver,
    )
  }
}

const flush = (): Promise<void> => new Promise((resolve) => setTimeout(resolve))

describe('PageSvg', () => {
  beforeEach(() => {
    getMock.mockClear()
    IntersectionObserverStub.instances = []
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  // viewBoxがDI座標系（インチ単位のページ寸法）と一致することを確認する
  it('viewBoxをページ寸法（インチ）で設定する', () => {
    const wrapper = mount(PageSvg, {
      props: { documentId: 'doc-1', page: 1, width: 8.5, height: 11 },
    })

    const svg = wrapper.find('svg')
    expect(svg.attributes('viewBox')).toBe('0 0 8.5 11')
  })

  // DI polygonの矩形がインチ座標のまま無変換でrect要素になることを確認する
  it('読取矩形をDI座標のままrect描画する', () => {
    const wrapper = mount(PageSvg, {
      props: {
        documentId: 'doc-1',
        page: 1,
        width: 8.5,
        height: 11,
        rects: [
          {
            id: 'field:a',
            kind: 'field',
            x: 1.0,
            y: 2.5,
            width: 3.0,
            height: 0.25,
          },
        ],
      },
    })

    const rect = wrapper.find('rect')
    expect(rect.attributes('x')).toBe('1')
    expect(rect.attributes('y')).toBe('2.5')
    expect(rect.attributes('width')).toBe('3')
    expect(rect.attributes('height')).toBe('0.25')
  })

  // token指定時は無認証の閲覧URL用エンドポイントから画像を取得することを確認する
  // （IntersectionObserver未定義＝jsdom既定では即時取得にフォールバックする）
  it('token指定時は/view系エンドポイントを呼ぶ（IntersectionObserver未定義時は即時取得）', async () => {
    mount(PageSvg, {
      props: { token: 'tok-abc', page: 2, width: 8.5, height: 11 },
    })
    await flush()

    expect(getMock).toHaveBeenCalledTimes(1)
    expect(getMock).toHaveBeenCalledWith(
      '/view/{token}/pages/{page}/image',
      expect.objectContaining({
        params: { path: { token: 'tok-abc', page: 2 } },
      }),
    )
  })

  // 表示領域に入るまで画像取得せず、入った時に1回だけ取得することを確認する
  // （閲覧URL経由ではこの取得がpage_view記録になるため、未表示ページを取得してはならない）
  it('表示領域に入るまで画像を取得せず、入った時に1回だけ取得する', async () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    mount(PageSvg, {
      props: { token: 'tok-abc', page: 3, width: 8.5, height: 11 },
    })
    await flush()

    expect(getMock).not.toHaveBeenCalled()
    expect(IntersectionObserverStub.instances).toHaveLength(1)
    const observer = IntersectionObserverStub.instances[0]
    if (!observer) throw new Error('observer not created')

    observer.trigger(false)
    await flush()
    expect(getMock).not.toHaveBeenCalled()

    observer.trigger(true)
    await flush()
    expect(getMock).toHaveBeenCalledTimes(1)
    expect(observer.disconnected).toBe(true)

    // 取得後の再交差では再取得しない
    observer.trigger(true)
    await flush()
    expect(getMock).toHaveBeenCalledTimes(1)
  })

  // アンマウント時に監視を解除することを確認する（未表示のまま離脱した場合の取得抑止）
  it('アンマウント時にIntersectionObserverを解除する', async () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    const wrapper = mount(PageSvg, {
      props: { token: 'tok-abc', page: 1, width: 8.5, height: 11 },
    })
    await flush()

    wrapper.unmount()

    expect(IntersectionObserverStub.instances[0]?.disconnected).toBe(true)
    expect(getMock).not.toHaveBeenCalled()
  })

  // fetch中にアンマウントされた場合、blob URLを作らないことを確認する（リーク防止）
  it('fetch完了前にアンマウントされた場合はblob URLを作らない', async () => {
    // jsdomにURL.createObjectURLが存在しないためvi.fn()を仮設し、afterEachで元に戻す
    const createObjectURLMock = vi.fn().mockReturnValue('blob:mock')
    URL.createObjectURL = createObjectURLMock
    let resolveFetch: (value: {
      data: Blob
      error: undefined
    }) => void = () => {}
    getMock.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          resolveFetch = resolve
        }),
    )

    const wrapper = mount(PageSvg, {
      props: { token: 'tok-abc', page: 1, width: 8.5, height: 11 },
    })
    await flush()

    wrapper.unmount()
    resolveFetch({ data: new Blob(), error: undefined })
    await flush()

    expect(createObjectURLMock).not.toHaveBeenCalled()
    // @ts-expect-error jsdomに存在しないプロパティを仮設したため削除して戻す
    delete URL.createObjectURL
  })

  // 矩形は ID 付きで、種別クラス（field は破線・cell は実線）と選択中クラスを持ち、クリックで ID を emit する
  it('矩形にIDと種別・選択中クラスを付け、クリックでIDをemitする', async () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    const wrapper = mount(PageSvg, {
      props: {
        documentId: 'doc-1',
        page: 1,
        width: 8.5,
        height: 11,
        rects: [
          { id: 'cell:0:1:0', kind: 'cell', x: 1, y: 3, width: 2, height: 0.5 },
          {
            id: 'field:TotalAmount',
            kind: 'field',
            x: 6.8,
            y: 2.9,
            width: 0.5,
            height: 0.2,
          },
        ],
        activeId: 'field:TotalAmount',
      },
    })

    const rects = wrapper.findAll('rect')
    expect(rects).toHaveLength(2)
    expect(rects[0]!.attributes('data-rect-id')).toBe('cell:0:1:0')
    expect(rects[0]!.classes()).toContain('overlay-rect--cell')
    expect(rects[0]!.classes()).not.toContain('overlay-rect--active')
    expect(rects[1]!.classes()).toContain('overlay-rect--field')
    expect(rects[1]!.classes()).toContain('overlay-rect--active')

    await rects[0]!.trigger('click')
    expect(wrapper.emitted('rectClick')).toEqual([['cell:0:1:0']])
  })

  it('activeId 未指定・rects 未指定でも描画できる', () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    const wrapper = mount(PageSvg, {
      props: { documentId: 'doc-1', page: 1, width: 8.5, height: 11 },
    })
    expect(wrapper.findAll('rect')).toHaveLength(0)
  })
})
