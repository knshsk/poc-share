import { describe, expect, it } from 'vitest'

import { normalizationHint, normalizeValue } from '../src/utils/normalize'

// サーバ側 idp_extraction._normalize と同じ規則（number: カンマ除去して整数、date: / → - で ISO 日付）
describe('normalizeValue', () => {
  it('number はカンマを除いて整数化し、整数でなければ null', () => {
    expect(normalizeValue('number', '1,250,000')).toBe(1250000)
    expect(normalizeValue('number', ' -12 ')).toBe(-12)
    expect(normalizeValue('number', '12.5')).toBeNull()
    expect(normalizeValue('number', '約120万')).toBeNull()
  })

  it('date は / を - に置換した ISO 日付を返し、不正な日付は null', () => {
    expect(normalizeValue('date', '2026/10/30')).toBe('2026-10-30')
    expect(normalizeValue('date', '2026-10-30')).toBe('2026-10-30')
    expect(normalizeValue('date', '2026-02-30')).toBeNull()
    expect(normalizeValue('date', '2026-1-2')).toBeNull()
    expect(normalizeValue('date', '10/30')).toBeNull()
    expect(normalizeValue('date', ' 2026-01-02')).toBeNull()
  })

  it('string はそのまま', () => {
    expect(normalizeValue('string', ' abc ')).toBe(' abc ')
  })
})

describe('normalizationHint', () => {
  it('string と空欄はヒントなし', () => {
    expect(normalizationHint('string', 'x')).toBeNull()
    expect(normalizationHint('number', '')).toBeNull()
  })

  it('解釈できる値は正規化値、できない値は型別の注意文を返す', () => {
    expect(normalizationHint('number', '1,000')).toEqual({
      ok: true,
      text: '正規化値 1000',
    })
    expect(normalizationHint('number', 'abc')).toEqual({
      ok: false,
      text: '数値として解釈できません',
    })
    expect(normalizationHint('date', '2026/01/02')).toEqual({
      ok: true,
      text: '正規化値 2026-01-02',
    })
    expect(normalizationHint('date', '来月')).toEqual({
      ok: false,
      text: '日付として解釈できません',
    })
  })
})
