import { describe, expect, it } from 'vitest'

import {
  cellId,
  fieldId,
  overlayRectsByPage,
  polygonToRect,
  type IdpRun,
} from '../src/utils/runs'

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  raw_fields: {
    TotalAmount: '1,200,000',
    Note: null,
    Hidden: 'x',
    NoRegion: 'y',
  },
  normalized_fields: null,
  confidence: null,
  field_labels: null,
  field_regions: {
    TotalAmount: {
      page_number: 1,
      polygon: [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1],
    },
    Note: { page_number: 1, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
    Hidden: { page_number: 1, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
    NoRegion: null,
  },
  tables: [
    {
      row_count: 2,
      column_count: 1,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          content: 'h',
          kind: 'columnHeader',
          page_number: 1,
          polygon: [1, 2, 3, 2, 3, 2.5, 1, 2.5],
        },
        {
          row_index: 1,
          column_index: 0,
          content: 'v',
          kind: null,
          page_number: 2,
          polygon: [1, 3, 3, 3, 3, 3.5, 1, 3.5],
        },
      ],
    },
    {
      row_count: 1,
      column_count: 1,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          content: 'n',
          kind: null,
          page_number: null,
          polygon: null,
        },
      ],
    },
  ],
  pattern_matches: null,
  corrections: null,
}

describe('ID', () => {
  it('field/cell の ID を組み立てる', () => {
    expect(fieldId('TotalAmount')).toBe('field:TotalAmount')
    expect(cellId(0, 2, 3)).toBe('cell:0:2:3')
  })
})

describe('polygonToRect', () => {
  // DI polygon（x,y の交互配列・インチ）を外接矩形に変換する。座標は無変換
  it('polygon の外接矩形を返す', () => {
    expect(polygonToRect([6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1])).toEqual({
      x: 6.8,
      y: 2.9,
      width: expect.closeTo(0.5, 6),
      height: expect.closeTo(0.2, 6),
    })
  })

  it('傾いた四角形でも min/max で囲む', () => {
    expect(polygonToRect([1, 0, 2, 1, 1, 2, 0, 1])).toEqual({
      x: 0,
      y: 0,
      width: 2,
      height: 2,
    })
  })
})

describe('overlayRectsByPage', () => {
  // セル = polygon あり全件、キー項目 = 領域あり・visible・raw 非 null。セルを先、キー項目を後。ページ番号で分ける
  it('成功実行からページごとの矩形を生成する', () => {
    const byPage = overlayRectsByPage(run, new Set(['Hidden']))

    expect([...byPage.keys()].sort()).toEqual([1, 2])
    expect(byPage.get(1)?.map((r) => r.id)).toEqual([
      'cell:0:0:0',
      'field:TotalAmount',
    ])
    expect(byPage.get(1)?.[0]).toEqual({
      id: 'cell:0:0:0',
      kind: 'cell',
      x: 1,
      y: 2,
      width: 2,
      height: 0.5,
    })
    expect(byPage.get(1)?.[1]).toEqual({
      id: 'field:TotalAmount',
      kind: 'field',
      x: 6.8,
      y: 2.9,
      width: expect.closeTo(0.5, 6),
      height: expect.closeTo(0.2, 6),
    })
    expect(byPage.get(2)?.map((r) => r.id)).toEqual(['cell:0:1:0'])
  })

  // polygon が退化（4未満）しているセルは Math.min(...[]) が Infinity にならないよう除外する
  it('polygonが退化したセルは矩形化しない', () => {
    const degenerate: IdpRun = {
      ...run,
      field_regions: null,
      tables: [
        {
          row_count: 1,
          column_count: 1,
          cells: [
            {
              row_index: 0,
              column_index: 0,
              content: 'n',
              kind: null,
              page_number: 1,
              polygon: [],
            },
          ],
        },
      ],
    }
    expect(overlayRectsByPage(degenerate, new Set()).size).toBe(0)
  })

  it('失敗実行・未選択は空', () => {
    expect(overlayRectsByPage(null, new Set()).size).toBe(0)
    expect(
      overlayRectsByPage(
        { ...run, status: 'failed', tables: null, field_regions: null },
        new Set(),
      ).size,
    ).toBe(0)
  })
})
