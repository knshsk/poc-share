import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

// 画像取得はapiClient経由のためモックする（キャンバスはナビ・ズーム操作が検証対象）
const getMock = vi
  .fn()
  .mockResolvedValue({ data: new Blob(), error: undefined })
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
}))

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import PageSvg from '../src/components/PageSvg.vue'
import { createAppVuetify } from '../src/plugins/vuetify'
import { useHighlightStore } from '../src/stores/highlight'
import type { IdpRun } from '../src/utils/runs'

type FieldDef = {
  key: string
  label: string
  type: 'string' | 'number' | 'date'
  visible: boolean
}

const pages = [
  { width: 8.5, height: 11 },
  { width: 8.5, height: 11 },
  { width: 8.5, height: 11 },
]

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: null,
  di_model_id: null,
  error_info: null,
  raw_fields: { TotalAmount: '1', Hidden: 'x' },
  normalized_fields: null,
  confidence: null,
  field_labels: null,
  field_regions: {
    TotalAmount: { page_number: 2, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
    Hidden: { page_number: 1, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
  },
  tables: [
    {
      row_count: 1,
      column_count: 1,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          content: 'c',
          kind: null,
          page_number: 1,
          polygon: [3, 3, 4, 3, 4, 4, 3, 4],
        },
      ],
    },
  ],
  pattern_matches: null,
  corrections: null,
}

function mountCanvas(
  extra: { run?: IdpRun | null; fieldDefs?: FieldDef[] } = {},
) {
  return mount(DocumentCanvas, {
    props: { documentId: 'doc-1', pages, ...extra },
    global: { plugins: [createAppVuetify()] },
  })
}

// jsdom は要素サイズを持たないため、スクローラの clientWidth / clientHeight を差し替える
function setScrollerSize(
  wrapper: ReturnType<typeof mountCanvas>,
  clientWidth: number,
  clientHeight: number,
): void {
  const el = wrapper.get('.canvas-scroller').element
  Object.defineProperty(el, 'clientWidth', {
    value: clientWidth,
    configurable: true,
  })
  Object.defineProperty(el, 'clientHeight', {
    value: clientHeight,
    configurable: true,
  })
}

function isActive(
  wrapper: ReturnType<typeof mountCanvas>,
  testId: string,
): boolean {
  return wrapper.get(`[data-testid="${testId}"]`).classes('v-btn--active')
}

describe('DocumentCanvas', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  // 全ページ分のPageSvgを描画することを確認する
  it('全ページを描画しページ表示を出す', () => {
    const wrapper = mountCanvas()
    expect(wrapper.findAllComponents(PageSvg)).toHaveLength(3)
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('1 / 3')
  })

  // 次/前ページボタンで表示中ページが移動し、境界でクランプされることを確認する
  it('次/前ページで表示中ページが移動する', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="canvas-next"]').trigger('click')
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('2 / 3')
    await wrapper.get('[data-testid="canvas-prev"]').trigger('click')
    await wrapper.get('[data-testid="canvas-prev"]').trigger('click')
    // 1ページ目より前へは行かない（ボタンはdisabledになりクリックは無効）
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('1 / 3')
  })

  // ズームは25%刻み・25〜200%でクランプされ、幅合わせで100%へ戻ることを確認する
  it('ズームと幅合わせが機能する', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('125%')
    await wrapper.get('[data-testid="canvas-fit-width"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')
    // 下限クランプ（100→75→50→25→25）
    const zoomOut = wrapper.get('[data-testid="canvas-zoom-out"]')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('25%')
  })

  // 初期表示は全体表示（page）。jsdom ではサイズ計測不能のため倍率は 100% に倒れる
  it('初期モードは全体表示で、±操作で手動（非選択）になる', async () => {
    const wrapper = mountCanvas()
    expect(isActive(wrapper, 'canvas-fit-page')).toBe(true)
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')

    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(isActive(wrapper, 'canvas-fit-page')).toBe(false)
    expect(isActive(wrapper, 'canvas-fit-width')).toBe(false)
    expect(isActive(wrapper, 'canvas-fit-height')).toBe(false)
  })

  // 高さ合わせ・全体表示はスクローラの実寸から倍率を計算し、25〜200% に制限されないことを確認する
  it('高さ合わせと全体表示がスクローラの寸法から倍率を計算する', async () => {
    const wrapper = mountCanvas()
    // 内寸幅 1000px、可視高さ 2200px → 1ページ幅 1700px → 170%
    setScrollerSize(wrapper, 1048, 2274)

    await wrapper.get('[data-testid="canvas-fit-height"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('170%')
    expect(isActive(wrapper, 'canvas-fit-height')).toBe(true)

    await wrapper.get('[data-testid="canvas-fit-page"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')
    expect(isActive(wrapper, 'canvas-fit-page')).toBe(true)

    // 可視高さ 1100px → 850px / 1000px → 85%（page も 100 未満なのでそのまま）
    setScrollerSize(wrapper, 1048, 1174)
    await wrapper.get('[data-testid="canvas-fit-page"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('85%')

    // 可視高さ 10px → 1%（フィット値は 25% の下限に縛られない）
    setScrollerSize(wrapper, 1048, 84)
    await wrapper.get('[data-testid="canvas-fit-height"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('1%')
  })

  // ±はフィット値（25の倍数でない）から次の25の倍数へスナップし、下限は25%に丸めることを確認する
  it('±はフィット値から25の倍数へスナップする', async () => {
    const wrapper = mountCanvas()
    setScrollerSize(wrapper, 1048, 1174)
    await wrapper.get('[data-testid="canvas-fit-page"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('85%')

    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')
    await wrapper.get('[data-testid="canvas-zoom-out"]').trigger('click')
    await wrapper.get('[data-testid="canvas-zoom-out"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('50%')

    // 1%（下限未満のフィット値）からは縮小不可・拡大で 25% へ
    setScrollerSize(wrapper, 1048, 84)
    await wrapper.get('[data-testid="canvas-fit-height"]').trigger('click')
    expect(
      wrapper.get('[data-testid="canvas-zoom-out"]').attributes('disabled'),
    ).toBeDefined()
    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('25%')
  })

  // 原本DLボタンがイベントを発火することを確認する
  it('原本DLボタンでdownloadOriginalをemitする', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="download-original"]').trigger('click')
    expect(wrapper.emitted('downloadOriginal')).toHaveLength(1)
  })

  // 選択中の成功実行から矩形を作り、page_number ごとに該当ページの PageSvg へ渡す。visible=false は除外
  it('選択中実行の矩形をページごとにPageSvgへ渡す', () => {
    const wrapper = mountCanvas({
      run,
      fieldDefs: [
        { key: 'Hidden', label: 'h', type: 'string', visible: false },
      ],
    })
    const svgs = wrapper.findAllComponents(PageSvg)
    expect(svgs[0]!.props('rects')?.map((r) => r.id)).toEqual(['cell:0:0:0'])
    expect(svgs[1]!.props('rects')?.map((r) => r.id)).toEqual([
      'field:TotalAmount',
    ])
    expect(svgs[2]!.props('rects')).toEqual([])
  })

  it('失敗実行・未選択では矩形を渡さない', () => {
    expect(
      mountCanvas({
        run: { ...run, status: 'failed', tables: null, field_regions: null },
      })
        .findAllComponents(PageSvg)
        .every((svg) => svg.props('rects')?.length === 0),
    ).toBe(true)
    expect(
      mountCanvas({ run: null })
        .findAllComponents(PageSvg)
        .every((svg) => svg.props('rects')?.length === 0),
    ).toBe(true)
  })

  // 矩形クリック → highlight ストアへ（activeId + ペインへのフォーカス要求）。activeId は PageSvg へ渡る
  it('矩形クリックでhighlightストアを更新し、activeIdをPageSvgへ渡す', async () => {
    const wrapper = mountCanvas({ run })
    const highlight = useHighlightStore()

    await wrapper.get('[data-rect-id="cell:0:0:0"]').trigger('click')

    expect(highlight.activeId).toBe('cell:0:0:0')
    expect(highlight.paneFocus).toEqual({ id: 'cell:0:0:0', seq: 1 })
    await wrapper.vm.$nextTick()
    expect(wrapper.findAllComponents(PageSvg)[0]!.props('activeId')).toBe(
      'cell:0:0:0',
    )
  })

  // ペイン側からの要求で該当矩形を表示範囲へスクロールする（jsdom には scrollIntoView が無いため差し込む）
  it('canvasScroll要求で該当矩形をscrollIntoViewする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const wrapper = mountCanvas({ run })
    const highlight = useHighlightStore()

    highlight.selectFromPane('field:TotalAmount')
    await wrapper.vm.$nextTick()
    await wrapper.vm.$nextTick()

    expect(scrollSpy).toHaveBeenCalledTimes(1)
    expect(scrollSpy.mock.instances[0]).toBe(
      wrapper.get('[data-rect-id="field:TotalAmount"]').element,
    )
    expect(scrollSpy).toHaveBeenCalledWith(
      expect.objectContaining({ block: 'center', inline: 'center' }),
    )
  })

  afterEach(() => {
    // @ts-expect-error jsdom に無いメソッドを差し込んだテストの後始末
    delete Element.prototype.scrollIntoView
  })
})
