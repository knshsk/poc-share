import type { components } from '../api/schema'

export type FieldType = components['schemas']['FieldDefPayload']['type']

// サーバ側 idp_extraction._normalize と同じ規則をクライアントで再現する（入力中の注意喚起用。判定はサーバが正）
// number: カンマ除去して整数（Python の int() 相当）。date: / を - に置換して YYYY-MM-DD（date.fromisoformat 相当）
export function normalizeValue(
  type: FieldType,
  value: string,
): string | number | null {
  if (type === 'number') {
    const s = value.replace(/,/g, '').trim()
    return /^[+-]?\d+$/.test(s) ? Number(s) : null
  }
  if (type === 'date') {
    const s = value.replace(/\//g, '-')
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null
    const d = new Date(`${s}T00:00:00Z`)
    return Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s
      ? null
      : s
  }
  return value
}

// 入力欄の下に出す行内ヒント。string 型・空欄は出さない
export function normalizationHint(
  type: FieldType,
  value: string,
): { ok: boolean; text: string } | null {
  if (type === 'string' || value === '') return null
  const normalized = normalizeValue(type, value)
  if (normalized == null) {
    return {
      ok: false,
      text:
        type === 'number'
          ? '数値として解釈できません'
          : '日付として解釈できません',
    }
  }
  return { ok: true, text: `正規化値 ${normalized}` }
}
