<script setup lang="ts">
// 右ペイン: IDP実行 / 選択中結果チップ / タブ（読取結果・実行履歴・閲覧URL）/ 下部アクションバー（変更件数・破棄・確定）
import { PhArrowsClockwise } from '@phosphor-icons/vue'
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import type { FieldDef } from '../stores/document'
import { useDraftStore } from '../stores/draft'
import { useHighlightStore } from '../stores/highlight'
import { formatDateTime } from '../utils/format'
import { RUN_TYPE_LABEL, type IdpRun, type IdpRunSummary } from '../utils/runs'
import ResultEditor from './ResultEditor.vue'
import ViewUrlPanel from './ViewUrlPanel.vue'

// shareable: 文書種別設定（document_type_configs）の共有可否。閲覧URLタブの表示ゲート
// fieldDefs: 文書種別設定の項目定義。visible=false の除外と正規化ヒントの型に使う（#91・#117）
const props = defineProps<{
  documentId: string
  shareable: boolean
  fieldDefs: FieldDef[]
}>()

// 選択中の実行をキャンバス（矩形描画）へ渡す。所有は WorkPanel のまま（一覧・詳細取得・キャッシュ）
const emit = defineEmits<{ 'update:selectedRun': [IdpRun | null] }>()

const draft = useDraftStore()
const highlight = useHighlightStore()
const activeTab = ref<'result' | 'history' | 'urls'>('result')
// 履歴は一覧API（サマリ）を表示用に実行日時降順で保持する（サーバ応答は昇順）
const runs = ref<IdpRunSummary[]>([])
// 選択中実行の詳細。一覧には項目値・テーブルが無いため run_id ごとに詳細APIで取得し、行は不変なのでキャッシュする
const selectedRun = ref<IdpRun | null>(null)
const details = new Map<string, IdpRun>()
// 応答待ち中の run_id。応答受信時に選択が変わっていれば古い応答は捨てる
let pendingRunId: string | null = null
const executing = ref(false)
const saving = ref(false)
const loadingRuns = ref(false)
const errorMessage = ref<string | null>(null)
const savedSnackbar = ref(false)

const selectedChip = computed(() => {
  const run = selectedRun.value
  if (!run) return null
  const parts = [RUN_TYPE_LABEL[run.run_type], formatDateTime(run.executed_at)]
  if (run.corrected_by) parts.push(run.corrected_by)
  return parts.join(' · ')
})

const showActions = computed(
  () =>
    activeTab.value === 'result' && selectedRun.value?.status === 'succeeded',
)

function showRun(run: IdpRun): void {
  highlight.clear()
  details.set(run.run_id, run)
  selectedRun.value = run
  pendingRunId = run.run_id
  activeTab.value = 'result'
}

async function selectRun(runId: string): Promise<void> {
  highlight.clear()
  activeTab.value = 'result'
  errorMessage.value = null
  pendingRunId = runId
  const cached = details.get(runId)
  if (cached) {
    selectedRun.value = cached
    return
  }
  try {
    const { data, error } = await apiClient.GET(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
      {
        params: { path: { document_id: props.documentId, run_id: runId } },
      },
    )
    // 応答待ちの間に別の実行が選択された場合は古い応答を捨てる（後勝ちの誤表示防止）
    if (pendingRunId !== runId) return
    if (error || !data) {
      errorMessage.value = '実行結果を取得できませんでした'
      return
    }
    details.set(runId, data)
    selectedRun.value = data
  } catch {
    if (pendingRunId !== runId) return
    errorMessage.value = '実行結果を取得できませんでした'
  }
}

async function loadRuns(): Promise<void> {
  errorMessage.value = null
  runs.value = []
  selectedRun.value = null
  details.clear()
  pendingRunId = null
  draft.reset()
  if (!props.documentId) return

  loadingRuns.value = true
  let latestRunId: string | undefined
  try {
    const { data, error } = await apiClient.GET(
      '/api/v1/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = '実行履歴を取得できませんでした'
      return
    }
    // 一覧取得中にIDP実行・確定が完了した場合（showRunがpendingRunIdを設定済み）、
    // その選択・表示済みの実行を一覧の書き戻しで消さない。一覧はその実行を先頭に残しマージする
    if (pendingRunId !== null) {
      const listIds = new Set(data.runs.map((r) => r.run_id))
      runs.value = [
        ...runs.value.filter((r) => !listIds.has(r.run_id)),
        ...[...data.runs].reverse(),
      ]
      return
    }
    runs.value = [...data.runs].reverse()
    latestRunId = runs.value[0]?.run_id
  } catch {
    errorMessage.value = '実行履歴を取得できませんでした'
    return
  } finally {
    // 一覧のスケルトンは一覧取得のみを覆う。以降の初期選択待ちで
    // 後続のIDP実行応答（executeIdp）の表示を隠さないようここで解除する（#114 持ち越し）
    loadingRuns.value = false
  }
  if (latestRunId) await selectRun(latestRunId)
}

async function executeIdp(): Promise<void> {
  errorMessage.value = null
  executing.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/v1/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = 'IDP実行に失敗しました'
      return
    }
    // 実行応答は詳細と同形。そのままキャッシュし選択状態にする（遅れて届く詳細応答は pendingRunId 不一致で捨てる）
    runs.value = [data, ...runs.value]
    showRun(data)
  } catch {
    errorMessage.value = 'IDP実行に失敗しました'
  } finally {
    executing.value = false
  }
}

// 確定: 差分を base（選択中の実行）に対して POST し、応答の corrected 行を選択・履歴追加する
async function confirmCorrections(): Promise<void> {
  const base = selectedRun.value
  if (!base || !draft.dirty) return
  errorMessage.value = null
  saving.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections',
      {
        params: {
          path: { document_id: props.documentId, run_id: base.run_id },
        },
        body: draft.toCorrections(),
      },
    )
    if (error || !data) {
      errorMessage.value = '修正の保存に失敗しました'
      return
    }
    runs.value = [data, ...runs.value]
    showRun(data)
    draft.reset()
    savedSnackbar.value = true
  } catch {
    errorMessage.value = '修正の保存に失敗しました'
  } finally {
    saving.value = false
  }
}

// 未保存の変更がある状態での履歴選択 / IDP実行は確認ダイアログを挟む（draft.guard）
// タブ切替自体はガード対象外: 選択行為が読取結果タブへ戻す意図を持つため、
// ダイアログ表示中も直前の結果とアクションバーが見えた状態を保つ
function onSelectRun(runId: string): void {
  activeTab.value = 'result'
  draft.guard(() => void selectRun(runId))
}

function onExecuteIdp(): void {
  draft.guard(() => void executeIdp())
}

// ブラウザ離脱時の標準警告（文言はブラウザ固定）
function onBeforeUnload(event: BeforeUnloadEvent): void {
  if (!draft.dirty) return
  event.preventDefault()
  event.returnValue = ''
}

onMounted(() => {
  window.addEventListener('beforeunload', onBeforeUnload)
  void loadRuns()
})
onUnmounted(() => {
  window.removeEventListener('beforeunload', onBeforeUnload)
  // パネル消滅時に保留中の確認操作（履歴選択/IDP実行のguard）を取り消し、居残ったpendingで後続guardが解除不能になるのを防ぐ
  draft.cancel()
})
watch(
  () => props.documentId,
  () => void loadRuns(),
)
watch(selectedRun, (run) => emit('update:selectedRun', run), {
  immediate: true,
})
// キャンバス側クリックで読取結果タブへ（入力欄のスクロール・フォーカスは ResultEditor が行う）
watch(
  () => highlight.paneFocus,
  (request) => {
    if (request) activeTab.value = 'result'
  },
)
</script>

<template>
  <div class="work-panel">
    <div class="panel-head">
      <!-- IDP実行はタブ非依存で常置（K5-5/R1-5の再項目化導線）。右に選択中結果のチップ -->
      <div class="d-flex align-center ga-2 mb-2">
        <v-btn
          color="primary"
          data-testid="execute-idp"
          :loading="executing"
          :disabled="executing || !documentId"
          @click="onExecuteIdp"
        >
          <PhArrowsClockwise :size="16" class="mr-1" />
          IDP実行
        </v-btn>
        <v-chip
          v-if="selectedChip"
          size="small"
          variant="tonal"
          :color="selectedRun?.run_type === 'corrected' ? 'primary' : undefined"
          class="font-mono"
          data-testid="selected-run-chip"
        >
          {{ selectedChip }}
        </v-chip>
      </div>
      <v-alert
        v-if="errorMessage"
        type="error"
        density="compact"
        variant="tonal"
        class="mb-2"
      >
        {{ errorMessage }}
      </v-alert>

      <v-tabs v-model="activeTab" density="compact" color="primary">
        <v-tab value="result" data-testid="tab-result">読取結果</v-tab>
        <v-tab value="history" data-testid="tab-history">実行履歴</v-tab>
        <v-tab v-if="props.shareable" value="urls" data-testid="tab-urls">
          閲覧URL
        </v-tab>
      </v-tabs>
    </div>

    <div class="panel-body">
      <v-tabs-window v-model="activeTab">
        <v-tabs-window-item value="result">
          <v-skeleton-loader
            v-if="loadingRuns"
            type="list-item@3"
            class="pa-3"
          />
          <template v-else-if="selectedRun">
            <ResultEditor
              v-if="selectedRun.status === 'succeeded'"
              :key="selectedRun.run_id"
              :run="selectedRun"
              :field-defs="fieldDefs"
            />
            <v-alert
              v-else
              type="error"
              variant="tonal"
              density="compact"
              class="ma-3"
              data-testid="run-error"
            >
              実行失敗: {{ selectedRun.error_info ?? '不明なエラー' }}
            </v-alert>
          </template>
          <p v-else class="text-secondary text-body-2 pa-3">
            実行結果がありません
          </p>
        </v-tabs-window-item>

        <v-tabs-window-item value="history">
          <v-list density="compact">
            <v-list-item
              v-for="run in runs"
              :key="run.run_id"
              data-testid="run-row"
              :active="run.run_id === selectedRun?.run_id"
              @click="onSelectRun(run.run_id)"
            >
              <v-list-item-title class="font-mono text-body-2">
                {{ formatDateTime(run.executed_at) }}
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ RUN_TYPE_LABEL[run.run_type] }}
                <template v-if="run.corrected_by"
                  >（{{ run.corrected_by }}）</template
                >
                ・
                <span
                  :class="
                    run.status === 'succeeded' ? 'text-success' : 'text-error'
                  "
                >
                  {{ run.status === 'succeeded' ? '成功' : '失敗' }}
                </span>
              </v-list-item-subtitle>
            </v-list-item>
          </v-list>
          <p v-if="runs.length === 0" class="text-secondary text-body-2 pa-3">
            実行履歴がありません
          </p>
        </v-tabs-window-item>

        <v-tabs-window-item v-if="props.shareable" value="urls" class="pa-3">
          <ViewUrlPanel :document-id="documentId" />
        </v-tabs-window-item>
      </v-tabs-window>
    </div>

    <!-- 下部固定のアクションバー: 読取結果タブ・成功実行選択時のみ。確定・破棄は変更ありのときだけ有効 -->
    <div v-if="showActions" class="panel-actions">
      <span
        class="text-body-2"
        :class="
          draft.dirty ? 'text-primary font-weight-medium' : 'text-secondary'
        "
        data-testid="change-count"
      >
        変更 {{ draft.count }}件
      </span>
      <v-spacer />
      <v-btn
        variant="text"
        size="small"
        :disabled="!draft.dirty || saving"
        data-testid="discard-draft"
        @click="draft.reset()"
      >
        破棄
      </v-btn>
      <v-btn
        color="primary"
        variant="flat"
        size="small"
        :disabled="!draft.dirty || saving"
        :loading="saving"
        data-testid="confirm-corrections"
        @click="confirmCorrections"
      >
        確定
      </v-btn>
    </div>

    <v-dialog
      :model-value="draft.pending !== null"
      max-width="400"
      @update:model-value="draft.cancel()"
    >
      <v-card data-testid="discard-dialog">
        <v-card-title class="text-body-1"
          >未保存の変更を破棄しますか？</v-card-title
        >
        <v-card-text class="text-body-2 text-secondary">
          変更 {{ draft.count }}件が確定されていません。続行すると失われます。
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn data-testid="discard-cancel" @click="draft.cancel()">
            キャンセル
          </v-btn>
          <v-btn
            color="error"
            variant="flat"
            data-testid="discard-proceed"
            @click="draft.proceed()"
          >
            破棄して続行
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar
      v-model="savedSnackbar"
      :timeout="2500"
      color="success"
      variant="tonal"
      data-testid="correction-saved"
    >
      修正を保存しました
    </v-snackbar>
  </div>
</template>

<style scoped>
.work-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.panel-head {
  padding: 12px 12px 0;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.panel-body {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
}

.panel-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-top: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
  background: rgb(var(--v-theme-surface));
}
</style>
