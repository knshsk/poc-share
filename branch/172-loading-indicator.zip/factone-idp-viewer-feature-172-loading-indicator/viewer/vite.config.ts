import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

// ビルド出力の index.html で、Vite が head に入れる CSS の <link> を </body> の直前へ移す。
// head の stylesheet は届くまで画面全体の描画を止めるため、そのままでは起動スプラッシュ（index.html）が
// CSS の到着まで描かれない。body 内の stylesheet はそれより前の要素（スプラッシュ）の描画を止めない一方、
// parser が作った stylesheet は位置に関わらず module script の実行を待たせる（HTML 仕様の
// script-blocking style sheet）ので、Vue は CSS の適用後に起動する（スタイル無しの画面は出ない）
export function moveStylesheetsToBody(html: string): string {
  const links = html.match(/<link\b[^>]*\brel="stylesheet"[^>]*>/g) ?? []
  if (links.length === 0) return html
  const rest = links.reduce((out, link) => out.replace(link, ''), html)
  return rest.replace('</body>', `${links.join('\n')}\n</body>`)
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    vue(),
    {
      name: 'stylesheet-to-body',
      apply: 'build',
      transformIndexHtml: { order: 'post', handler: moveStylesheetsToBody },
    },
  ],
  server: {
    // ローカル開発時もAPIを同一オリジンで呼ぶ（本番のContainer Apps同居配信と同構成）
    proxy: {
      '/api': 'http://localhost:8000',
      // /view/{token} はSPAのページ、/view/{token}/pages|pdf 配下はAPI
      '^/view/[^/]+/(pages|pdf)': 'http://localhost:8000',
    },
  },
})
