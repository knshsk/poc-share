<script setup lang="ts">
// 読取結果タブの本体: キー項目 / 候補値 / 表の 3 区分。キー項目は KeyFieldList、表は ResultTable が描画する。
// ここは区分の開閉・候補値（読取専用）・キャンバスからのフォーカス要求の処理だけを持つ
import { computed, nextTick, ref, watch } from 'vue'

import type { EditorVm } from '../mediator/vm'
import { scrollBehavior } from '../utils/motion'
import { cellKey, visibleFieldKeys } from '../utils/runs'
import KeyFieldList from './KeyFieldList.vue'
import ResultTable from './ResultTable.vue'

const props = defineProps<{ vm: EditorVm }>()

const root = ref<HTMLElement | null>(null)
// 初期は全区分展開（区分の開閉は描画パラメータなので View が持つ）
const openSections = ref([0, 1, 2])

// キャンバス側クリック → 該当入力欄へスクロール＋フォーカス（読取結果タブへの切替は Mediator が行う）
watch(
  () => props.vm.focusRequest,
  async (request) => {
    if (!request) return
    // 折りたたみ中の区分は開いてからフォーカスする（display:none では focus/scrollIntoView が効かない）
    const section = request.id.startsWith('cell:') ? 2 : 0
    const opened = !openSections.value.includes(section)
    if (opened) openSections.value.push(section)
    // 畳まれた空行のセルは、同じ tick で ResultTable が塊を展開してから DOM に現れる
    await nextTick()
    const input = root.value?.querySelector<HTMLInputElement>(
      `[data-target-id="${CSS.escape(request.id)}"] input`,
    )
    if (!input) return
    const reveal = (): void =>
      input.scrollIntoView?.({ block: 'center', behavior: scrollBehavior() })
    reveal()
    input.focus({ preventScroll: true })
    // 区分を開いた直後は展開トランジションの途中で位置が定まらない。終わってからもう一度表示範囲へ入れる
    // （子孫の transitionend も bubble してくるので、区分の本文自身のものだけを拾う）
    const panel = opened ? input.closest('.v-expansion-panel-text') : null
    if (!panel) return
    const done = (e: Event): void => {
      if (e.target !== panel) return
      panel.removeEventListener('transitionend', done)
      reveal()
    }
    panel.addEventListener('transitionend', done)
  },
)

const fieldCount = computed(
  () => visibleFieldKeys(props.vm.run, props.vm.fieldDefs).length,
)

const patternMatches = computed(() => props.vm.run.pattern_matches ?? {})
const tables = computed(() => props.vm.run.tables ?? [])

// 保存済みの人手修正があるセル（cellKey "t:r:c"）。corrections は根の機械実行に対する累積差分
const correctedCells = computed(
  () =>
    new Set(
      (props.vm.run.corrections?.table_cells ?? []).map((x) =>
        cellKey(x.table_index, x.row_index, x.column_index),
      ),
    ),
)
</script>

<template>
  <div ref="root">
    <v-expansion-panels
      v-model="openSections"
      multiple
      variant="accordion"
      elevation="0"
      class="sections"
    >
      <!-- キー項目: Query Fields -->
      <v-expansion-panel :value="0" data-testid="section-fields">
        <v-expansion-panel-title>
          <span class="font-weight-medium">キー項目</span>
          <span class="text-body-small text-secondary ml-2"
            >{{ fieldCount }}件</span
          >
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          <KeyFieldList :vm="vm" />
        </v-expansion-panel-text>
      </v-expansion-panel>

      <!-- 候補値: 正規表現パターン一致（読取専用） -->
      <v-expansion-panel :value="1" data-testid="section-candidates">
        <v-expansion-panel-title>
          <span class="font-weight-medium">候補値</span>
          <span class="text-body-small text-secondary ml-2"
            >{{ Object.keys(patternMatches).length }}件</span
          >
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          <!-- 値の表示なのでチップではなく読取専用の入力欄（選択・コピー可）。並びはキー項目と同じ列構成 -->
          <div
            v-for="(match, key) in patternMatches"
            :key="key"
            class="candidate-row"
            data-testid="candidate-row"
          >
            <span class="candidate-label text-body-small text-secondary">{{
              match.label
            }}</span>
            <div class="candidate-values">
              <v-text-field
                v-for="(value, i) in match.values"
                :key="i"
                :model-value="value"
                readonly
                hide-details
                :aria-label="`${match.label}の候補値`"
                data-testid="candidate-value"
              />
              <span
                v-if="match.values.length === 0"
                class="text-body-small text-secondary"
                >一致なし</span
              >
            </div>
          </div>
        </v-expansion-panel-text>
      </v-expansion-panel>

      <!-- 表: DI 認識テーブル -->
      <v-expansion-panel :value="2" data-testid="section-grid">
        <v-expansion-panel-title>
          <span class="font-weight-medium">表</span>
          <span class="text-body-small text-secondary ml-2"
            >{{ tables.length }}件</span
          >
        </v-expansion-panel-title>
        <!-- eager: 畳んでも ResultTable を unmount しない。lazy のままだと区分を開き直すたびに
             ResultTable が新規 mount され、非 immediate の watch(focusRequest) が発火せず、
             畳んだ空行の塊をキャンバスからのフォーカス要求で展開できなくなる -->
        <v-expansion-panel-text eager>
          <ResultTable
            v-for="(table, t) in tables"
            :key="t"
            :table="table"
            :table-index="t"
            :draft-cells="vm.draftCells"
            :corrected-cells="correctedCells"
            :active-id="vm.activeId"
            :focus-request="vm.focusRequest"
          />
          <p v-if="tables.length === 0" class="text-body-small text-secondary">
            テーブル未検出
          </p>
        </v-expansion-panel-text>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<style scoped>
.sections :deep(.v-expansion-panel-title) {
  min-height: 40px;
  padding: 0 12px;
}

.sections :deep(.v-expansion-panel-text__wrapper) {
  padding: 4px 12px 12px;
}

/* 候補値: キー項目と同じ列構成（ラベル | 欄 | 状態ぶんの空き） */
.candidate-row {
  display: grid;
  grid-template-columns: 112px minmax(0, 1fr) 84px;
  gap: 2px 8px;
  padding: 4px 0;
}

.candidate-label {
  padding-top: 8px;
  overflow-wrap: anywhere;
}

.candidate-values {
  display: grid;
  gap: 4px;
  align-content: center;
  min-height: 36px;
}

/* 読取専用: キャンバス色の地 + 等幅 */
.candidate-row :deep(.v-field) {
  background: rgb(var(--v-theme-canvas));
}

.candidate-row :deep(.v-field__input) {
  font-family: var(--font-mono);
  font-size: 0.8125rem;
  min-height: 36px;
  padding-top: 6px;
  padding-bottom: 6px;
}
</style>
