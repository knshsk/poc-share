<script setup lang="ts">
// 読取結果タブのキー項目（Query Fields）。行 = ラベル | 入力 | 状態。入力は Mediator へ bubble するだけ
import { PhPencilSimple, PhWarning } from '@phosphor-icons/vue'
import { computed, useId } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { EditorVm } from '../mediator/vm'
import { fieldStatus } from '../utils/fieldStatus'
import { normalizationHint } from '../utils/normalize'
import {
  CORRECTION_MAX_LENGTH,
  fieldId,
  originalValue,
  visibleFieldKeys,
} from '../utils/runs'

const props = defineProps<{ vm: EditorVm }>()

const bubble = useBubble()
// 状態・読取値・ヒントの要素 id の接頭辞（aria-describedby 用。キーは id に使えない文字を含み得るため index で振る）
const uid = useId()

const rows = computed(() => {
  const { run, fieldDefs, draftFields, activeId } = props.vm
  const typeOf = new Map(fieldDefs.map((f) => [f.key, f.type] as const))
  return visibleFieldKeys(run, fieldDefs).map((key, i) => {
    const field = run.fields?.[key]
    const original = originalValue(run, key)
    const value =
      key in draftFields ? (draftFields[key] ?? '') : (original ?? '')
    // 読取値が入力欄の元値と異なるときだけ補足表示する
    const raw =
      (field?.value ?? null) !== original ? (field?.value ?? null) : null
    // 設定に無いキー（設定変更後）は string 扱い
    const hint = normalizationHint(typeOf.get(key) ?? 'string', value)
    const status = fieldStatus({
      draft: key in draftFields,
      corrected: key in (run.corrections?.fields ?? {}),
      value: field?.value ?? null,
      confidence: field?.confidence ?? null,
    })
    const ids = {
      status: `${uid}-status-${i}`,
      raw: `${uid}-raw-${i}`,
      hint: `${uid}-hint-${i}`,
    }
    return {
      key,
      id: fieldId(key),
      label: field?.label ?? key,
      value,
      placeholder: field?.value == null ? '（値なし）' : undefined,
      raw,
      hint,
      status,
      active: activeId === fieldId(key),
      ids,
      describedBy:
        [status.text && ids.status, raw != null && ids.raw, hint && ids.hint]
          .filter(Boolean)
          .join(' ') || undefined,
    }
  })
})
</script>

<template>
  <div>
    <div
      v-for="row in rows"
      :key="row.key"
      class="field-row"
      data-testid="field-row"
    >
      <span class="field-label text-body-small text-secondary">{{
        row.label
      }}</span>
      <div
        class="field-input"
        :class="{
          'target--active': row.active,
          'input--draft': row.status.kind === 'draft',
        }"
        :data-target-id="row.id"
      >
        <v-text-field
          :model-value="row.value"
          hide-details
          :placeholder="row.placeholder"
          :aria-label="row.label"
          :aria-describedby="row.describedBy"
          :aria-current="row.active ? 'true' : undefined"
          :maxlength="CORRECTION_MAX_LENGTH"
          data-testid="field-input"
          @update:model-value="
            (v: string) =>
              bubble({ type: 'fieldInput', key: row.key, value: v })
          "
          @focus="bubble({ type: 'targetFocus', id: row.id })"
        />
        <div
          v-if="row.raw != null"
          :id="row.ids.raw"
          class="text-body-small text-secondary mt-1"
          data-testid="raw-value"
        >
          読取値 {{ row.raw }}
        </div>
        <div
          v-if="row.hint"
          :id="row.ids.hint"
          class="text-body-small mt-1 d-flex align-center ga-1"
          :class="row.hint.ok ? 'text-secondary font-mono' : 'text-warning'"
          data-testid="normalization-hint"
        >
          <PhWarning v-if="!row.hint.ok" :size="14" aria-hidden="true" />
          {{ row.hint.text }}
        </div>
      </div>
      <span
        :id="row.ids.status"
        class="field-status text-body-small"
        :class="`field-status--${row.status.kind}`"
        data-testid="field-status"
      >
        <PhWarning
          v-if="row.status.kind === 'low'"
          :size="14"
          aria-hidden="true"
        />
        <PhPencilSimple
          v-if="row.status.kind === 'corrected'"
          :size="14"
          aria-hidden="true"
        />
        {{ row.status.text }}
      </span>
    </div>
  </div>
</template>

<style scoped>
/* 行 = ラベル | 入力 | 状態。読取値・ヒントは入力の下に出る */
.field-row {
  display: grid;
  grid-template-columns: 112px minmax(0, 1fr) 84px;
  gap: 2px 8px;
  padding: 4px 0;
}

.field-label {
  padding-top: 8px;
  overflow-wrap: anywhere;
}

.field-input {
  min-width: 0;
}

.field-status {
  display: inline-flex;
  align-items: center;
  justify-content: flex-end;
  gap: 2px;
  height: 36px;
  white-space: nowrap;
}

.field-status--ok,
.field-status--empty {
  color: rgb(var(--v-theme-secondary));
}

.field-status--low {
  color: rgb(var(--v-theme-warning));
  font-weight: 500;
}

.field-status--corrected,
.field-status--draft {
  color: rgb(var(--v-theme-primary));
}

.field-status--draft {
  font-weight: 500;
}

.field-row :deep(.v-field__input) {
  font-size: 0.875rem;
  min-height: 36px;
  padding-top: 6px;
  padding-bottom: 6px;
}

/* 未保存の下書き: 入力欄に薄い塗り（保存済みの修正は状態表示だけ） */
.input--draft :deep(.v-field) {
  background: rgba(var(--v-theme-primary), 0.08);
}

/* キャンバスと連動して選択中: 主色の 2px 枠（塗りは使わず、下書きの塗りと両立させる）。フォーカスが外れても維持する */
.target--active :deep(.v-field) {
  box-shadow: inset 0 0 0 2px rgb(var(--v-theme-primary));
}
</style>
