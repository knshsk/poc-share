import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { describe, expect, it } from 'vitest'

// Vuetify 4 のタイポグラフィクラスは MD3 名（text-body-small 等）だけ。Vuetify 3 までの旧名（text-caption 等）・
// text-button・レスポンシブ接頭辞（text-md-h6 等）・MD3 名の typo（text-body-mid 等）は定義が無く、
// 書いても無言で効かない（16px 継承になる）ため、混入をここで検出する
const LEGACY =
  /\btext-(?:(?:sm|md|lg|xl|xxl)-)?(?:caption|button|overline|h[1-6]|subtitle-[12]|(?:display|headline|title|body|label)-(?!(?:large|medium|small)\b)[\w-]*)/

const srcDir = join(import.meta.dirname, '../src')
const mainCss = readFileSync(join(srcDir, 'assets/main.css'), 'utf8')
const mainTs = readFileSync(join(srcDir, 'main.ts'), 'utf8')

describe('タイポグラフィクラス', () => {
  it('Vuetify 3 までの旧クラス名を使っていない', () => {
    const hits = readdirSync(srcDir, { recursive: true, encoding: 'utf8' })
      .filter((file) => /\.(vue|ts)$/.test(file))
      .flatMap((file) =>
        readFileSync(join(srcDir, file), 'utf8')
          .split('\n')
          .flatMap((line, i) =>
            LEGACY.test(line) ? [`${file}:${i + 1}: ${line.trim()}`] : [],
          ),
      )
    expect(hits).toEqual([])
  })

  it('LEGACY は旧名・text-button・レスポンシブ接頭辞・MD3 名の typo に一致し、正しい MD3 名には一致しない', () => {
    for (const cls of [
      'text-caption',
      'text-md-h6',
      'text-body-mid',
      'text-button',
    ]) {
      expect(LEGACY.test(cls)).toBe(true)
    }
    for (const cls of [
      'text-body-medium',
      'text-title-large',
      'text-medium-emphasis',
      'text-none',
    ]) {
      expect(LEGACY.test(cls)).toBe(false)
    }
  })

  // --v-font-body が消えると MD3 クラスの箇所とオーバーレイが無言で Roboto に戻る
  it('main.css が --v-font-body を定義している', () => {
    expect(mainCss).toMatch(/^\s*--v-font-body:\s*\S/m)
  })

  // 日本語フォールバックが無いと、キー項目の正規化値のヒント・候補値に含まれる仮名・漢字が環境依存の
  // 和文フォント（generic monospace）に落ちる
  it('main.css の --font-mono が IBM Plex Sans JP にフォールバックする', () => {
    expect(mainCss).toMatch(/--font-mono:[^;]*'IBM Plex Sans JP'/)
  })

  // レイヤーに入れないと、この reset は Vuetify の mt-*/mb-*（vuetify-utilities レイヤー）に無言で負ける
  it('main.css が @layer app-reset 内で p の margin を 0 にしている', () => {
    expect(mainCss).toMatch(
      /@layer app-reset\s*{\s*p\s*{\s*margin:\s*0;?\s*}\s*}/,
    )
  })

  // app-reset がレイヤーに入っていても、main.css の import が vuetify より後だとレイヤーの登録順が
  // 逆転し、app-reset が最上位（最優先）レイヤーになって Vuetify の他のレイヤーに勝ってしまう
  it('main.ts で main.css の import が vuetify プラグインの import より前にある', () => {
    expect(mainTs.indexOf('./assets/main.css')).toBeLessThan(
      mainTs.indexOf('./plugins/vuetify'),
    )
  })
})
