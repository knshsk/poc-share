"""文書表示API（メタデータ・ページ画像・原本PDF配信）の統合テスト。

有効なPDFはpypdfium2で実行時生成し、破損PDFは tests/fixtures/broken.pdf を使用する。
"""

from pathlib import Path

import pypdfium2 as pdfium
import pytest
from fastapi.testclient import TestClient

FIXTURES = Path(__file__).parent / "fixtures"

# US Letter: 612x792ポイント = 8.5x11インチ
LETTER_WIDTH_PT = 612
LETTER_HEIGHT_PT = 792


@pytest.fixture(scope="module")
def valid_pdf() -> bytes:
    import io

    doc = pdfium.PdfDocument.new()
    doc.new_page(LETTER_WIDTH_PT, LETTER_HEIGHT_PT)
    doc.new_page(LETTER_WIDTH_PT, LETTER_HEIGHT_PT)
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def register(client: TestClient, document_id: str, content: bytes) -> None:
    response = client.post(
        "/api/documents",
        data={"document_id": document_id, "document_type": "quote"},
        files={"file": ("doc.pdf", content, "application/pdf")},
    )
    assert response.status_code == 201


def test_get_document_metadata(doc_client: TestClient, valid_pdf: bytes) -> None:
    """登録済み文書のメタデータが取得できることを確認する。"""
    register(doc_client, "doc-meta", valid_pdf)

    response = doc_client.get("/api/documents/doc-meta")

    assert response.status_code == 200
    assert response.json()["document_id"] == "doc-meta"
    assert response.json()["document_type"] == "quote"


def test_get_unknown_document_returns_404(doc_client: TestClient) -> None:
    """存在しない文書IDのメタデータ取得が404となることを確認する。"""
    response = doc_client.get("/api/documents/no-such-doc")

    assert response.status_code == 404


def test_get_pages_returns_count_and_sizes_in_inches(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """ページ一覧がページ数と各ページ寸法（インチ単位）を返すことを確認する。

    DI座標系（インチ）とSVG viewBoxを整合させるための座標系変換（ポイント→インチ）を検証する。
    """
    register(doc_client, "doc-pages", valid_pdf)

    response = doc_client.get("/api/documents/doc-pages/pages")

    assert response.status_code == 200
    body = response.json()
    assert body["page_count"] == 2
    assert body["pages"][0]["width"] == pytest.approx(8.5)
    assert body["pages"][0]["height"] == pytest.approx(11.0)


def test_get_page_image_returns_png(doc_client: TestClient, valid_pdf: bytes) -> None:
    """ページ画像がPNGで配信されることを確認する。"""
    register(doc_client, "doc-img", valid_pdf)

    response = doc_client.get("/api/documents/doc-img/pages/1/image")

    assert response.status_code == 200
    assert response.headers["content-type"] == "image/png"
    assert response.content.startswith(b"\x89PNG")


def test_get_page_image_out_of_range_returns_404(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """範囲外ページの画像要求が404となることを確認する。"""
    register(doc_client, "doc-range", valid_pdf)

    assert doc_client.get("/api/documents/doc-range/pages/3/image").status_code == 404
    assert doc_client.get("/api/documents/doc-range/pages/0/image").status_code == 404


def test_get_original_pdf(doc_client: TestClient, valid_pdf: bytes) -> None:
    """原本PDFがそのまま配信されることを確認する。"""
    register(doc_client, "doc-dl", valid_pdf)

    response = doc_client.get("/api/documents/doc-dl/pdf")

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content == valid_pdf


def test_broken_pdf_returns_500_with_detail(doc_client: TestClient) -> None:
    """破損PDFのページ処理が明示的なエラー応答となることを確認する。"""
    broken = (FIXTURES / "broken.pdf").read_bytes()
    register(doc_client, "doc-broken", broken)

    response = doc_client.get("/api/documents/doc-broken/pages")

    assert response.status_code == 500
    assert response.json()["detail"] == "Failed to process PDF"
    assert response.json()["type"] == "/errors/pdf-processing-failed"


def test_viewer_endpoints_require_auth(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """表示系エンドポイントがトークンなしで401となることを確認する。"""
    register(doc_client, "doc-auth", valid_pdf)
    doc_client.headers.pop("Authorization")

    assert doc_client.get("/api/documents/doc-auth").status_code == 401
    assert doc_client.get("/api/documents/doc-auth/pages").status_code == 401
    assert doc_client.get("/api/documents/doc-auth/pages/1/image").status_code == 401
    assert doc_client.get("/api/documents/doc-auth/pdf").status_code == 401
