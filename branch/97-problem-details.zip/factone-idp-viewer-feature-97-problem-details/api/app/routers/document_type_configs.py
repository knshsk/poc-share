"""文書種別設定のCRUD API。

テナントスコープはsettings.tenant_id（リクエストからのテナント解決は別Issue）。
type_codeのリネーム・PATCHは非対応（設計specの意図的な非対応を参照）。
"""

from datetime import datetime
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.config import Settings
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import Document, DocumentTypeConfig
from app.services.document_type_config import get_config

router = APIRouter(responses=problem_responses(401, 422))

_CODE_PATTERN = r"^[a-z0-9_]{1,50}$"


class FieldDefPayload(BaseModel):
    key: str = Field(pattern=_CODE_PATTERN)
    label: str = Field(min_length=1, max_length=100)
    type: Literal["string", "number", "date"]
    # Viewerの読み取り結果表示に含めるか（#91）。falseでも抽出・保存・API返却は行う
    visible: bool = True


class DocumentTypeConfigBody(BaseModel):
    display_name: str = Field(min_length=1, max_length=100)
    shareable: bool
    fields: list[FieldDefPayload] = Field(min_length=1)

    @field_validator("fields")
    @classmethod
    def keys_must_be_unique(cls, value: list[FieldDefPayload]) -> list[FieldDefPayload]:
        keys = [f.key for f in value]
        if len(keys) != len(set(keys)):
            raise ValueError("field keys must be unique")
        return value


class DocumentTypeConfigCreate(DocumentTypeConfigBody):
    type_code: str = Field(pattern=_CODE_PATTERN)


class DocumentTypeConfigResponse(BaseModel):
    type_code: str
    display_name: str
    shareable: bool
    fields: list[FieldDefPayload]
    created_at: datetime
    updated_at: datetime


def _to_response(config: DocumentTypeConfig) -> DocumentTypeConfigResponse:
    return DocumentTypeConfigResponse(
        type_code=config.type_code,
        display_name=config.display_name,
        shareable=config.shareable,
        fields=[FieldDefPayload.model_validate(f) for f in config.fields],
        created_at=config.created_at,
        updated_at=config.updated_at,
    )


def _tenant_id(request: Request) -> str:
    settings: Settings = request.app.state.settings
    return settings.tenant_id


def _get_or_404(session: Session, tenant_id: str, type_code: str) -> DocumentTypeConfig:
    config = get_config(session, tenant_id, type_code)
    if config is None:
        raise ProblemException(
            404, "document-type-not-found", "Document type not found"
        )
    return config


@router.get(
    "/api/config/document-types",
    response_model=list[DocumentTypeConfigResponse],
)
def list_configs(
    request: Request,
    _user: CurrentUser,
    session: Annotated[Session, Depends(get_db_session)],
) -> list[DocumentTypeConfigResponse]:
    configs = (
        session.execute(
            select(DocumentTypeConfig)
            .where(DocumentTypeConfig.tenant_id == _tenant_id(request))
            .order_by(DocumentTypeConfig.type_code)
        )
        .scalars()
        .all()
    )
    return [_to_response(c) for c in configs]


@router.post(
    "/api/config/document-types",
    response_model=DocumentTypeConfigResponse,
    status_code=201,
    responses=problem_responses(409),
)
def create_config(
    request: Request,
    _user: CurrentUser,
    payload: DocumentTypeConfigCreate,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentTypeConfigResponse:
    tenant_id = _tenant_id(request)
    if get_config(session, tenant_id, payload.type_code) is not None:
        raise ProblemException(
            409, "document-type-exists", "Document type already exists"
        )
    config = DocumentTypeConfig(
        tenant_id=tenant_id,
        type_code=payload.type_code,
        display_name=payload.display_name,
        shareable=payload.shareable,
        fields=[f.model_dump() for f in payload.fields],
    )
    session.add(config)
    session.commit()
    return _to_response(config)


@router.get(
    "/api/config/document-types/{type_code}",
    response_model=DocumentTypeConfigResponse,
    responses=problem_responses(404),
)
def get_config_endpoint(
    request: Request,
    _user: CurrentUser,
    type_code: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentTypeConfigResponse:
    return _to_response(_get_or_404(session, _tenant_id(request), type_code))


@router.put(
    "/api/config/document-types/{type_code}",
    response_model=DocumentTypeConfigResponse,
    responses=problem_responses(404),
)
def update_config(
    request: Request,
    _user: CurrentUser,
    type_code: str,
    payload: DocumentTypeConfigBody,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentTypeConfigResponse:
    config = _get_or_404(session, _tenant_id(request), type_code)
    config.display_name = payload.display_name
    config.shareable = payload.shareable
    config.fields = [f.model_dump() for f in payload.fields]
    session.commit()
    return _to_response(config)


@router.delete(
    "/api/config/document-types/{type_code}",
    status_code=204,
    responses=problem_responses(404, 409),
)
def delete_config(
    request: Request,
    _user: CurrentUser,
    type_code: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> None:
    tenant_id = _tenant_id(request)
    config = _get_or_404(session, tenant_id, type_code)
    in_use = session.execute(
        select(Document.document_id)
        .where(
            Document.tenant_id == tenant_id,
            Document.document_type == type_code,
        )
        .limit(1)
    ).first()
    if in_use is not None:
        raise ProblemException(
            409,
            "document-type-in-use",
            "Document type is in use and cannot be deleted",
        )
    session.delete(config)
    session.commit()
