"""PDFレンダリングの境界アダプタ（pypdfium2）。

ページ寸法はインチ単位で返す。Document Intelligenceのpolygon座標系（インチ）と
SVG viewBoxを無変換で整合させるための基準（座標系整合の決定に基づく）。
"""

import io
from dataclasses import dataclass
from typing import Protocol

import pypdfium2 as pdfium

POINTS_PER_INCH = 72
# オンデマンド変換の描画解像度（150dpi相当）
RENDER_SCALE = 150 / POINTS_PER_INCH


class PdfProcessingError(Exception):
    """破損PDF等、PDFとして処理できない場合の例外。"""


@dataclass(frozen=True)
class PageSize:
    """ページ寸法（インチ単位）。"""

    width: float
    height: float


class PdfRenderer(Protocol):
    """PDFレンダリングの境界。"""

    def get_page_sizes(self, pdf: bytes) -> list[PageSize]: ...

    def render_page_png(self, pdf: bytes, page_index: int) -> bytes: ...


class PdfiumRenderer:
    """pypdfium2によるページ情報取得・PNG変換。"""

    def get_page_sizes(self, pdf: bytes) -> list[PageSize]:
        doc = self._open(pdf)
        try:
            sizes = []
            for index in range(len(doc)):
                width_pt, height_pt = doc.get_page_size(index)
                sizes.append(
                    PageSize(
                        width=width_pt / POINTS_PER_INCH,
                        height=height_pt / POINTS_PER_INCH,
                    )
                )
            return sizes
        finally:
            doc.close()

    def render_page_png(self, pdf: bytes, page_index: int) -> bytes:
        doc = self._open(pdf)
        try:
            if not 0 <= page_index < len(doc):
                raise IndexError(page_index)
            page = doc[page_index]
            bitmap = page.render(scale=RENDER_SCALE)
            image = bitmap.to_pil()
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
            return buffer.getvalue()
        except pdfium.PdfiumError as exc:
            raise PdfProcessingError(str(exc)) from exc
        finally:
            doc.close()

    def _open(self, pdf: bytes) -> pdfium.PdfDocument:
        try:
            doc = pdfium.PdfDocument(pdf)
            # 破損検出のためページ数取得まで行う
            len(doc)
            return doc
        except pdfium.PdfiumError as exc:
            raise PdfProcessingError(str(exc)) from exc
