"""Document Intelligenceの境界アダプタ。

外部サービス（Azure Document Intelligence）への依存をProtocolで分離し、
テストではフェイクに差し替える。prebuilt-layout+Query Fieldsで項目指定抽出を行う。
"""

import io
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class QueryFieldResult:
    """Query Fieldsの項目別抽出結果（生値と確信度）。"""

    value: str | None
    confidence: float | None


class DiError(Exception):
    """Document Intelligence呼出の失敗（タイムアウト・サービス障害・未設定）。"""


class DocumentAnalyzer(Protocol):
    """PDF解析の境界。query_fieldsで指定した項目の抽出結果を返す。"""

    def analyze(
        self, pdf: bytes, query_fields: tuple[str, ...]
    ) -> dict[str, QueryFieldResult]: ...


class UnconfiguredAnalyzer:
    """接続先未設定時のプレースホルダ（ローカル開発でDI未設定のまま起動可能にする）。"""

    def analyze(
        self, pdf: bytes, query_fields: tuple[str, ...]
    ) -> dict[str, QueryFieldResult]:
        raise DiError("Document Intelligence endpoint is not configured")


class AzureDocumentAnalyzer:
    """Azure Document Intelligence実装（prebuilt-layout+Query Fields）。

    api_key未設定時はManaged ID（DefaultAzureCredential）で認証する。
    """

    def __init__(self, endpoint: str, api_key: str, timeout_seconds: int) -> None:
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        from azure.core.credentials import AzureKeyCredential

        credential: object
        if api_key:
            credential = AzureKeyCredential(api_key)
        else:
            from azure.identity import DefaultAzureCredential

            credential = DefaultAzureCredential()
        self._client = DocumentIntelligenceClient(endpoint, credential)
        self._timeout_seconds = timeout_seconds

    def analyze(
        self, pdf: bytes, query_fields: tuple[str, ...]
    ) -> dict[str, QueryFieldResult]:
        from azure.ai.documentintelligence.models import DocumentAnalysisFeature
        from azure.core.exceptions import AzureError

        try:
            poller = self._client.begin_analyze_document(
                "prebuilt-layout",
                io.BytesIO(pdf),
                content_type="application/pdf",
                features=[DocumentAnalysisFeature.QUERY_FIELDS],
                query_fields=list(query_fields),
            )
            result = poller.result(timeout=self._timeout_seconds)
        except AzureError as exc:
            raise DiError(str(exc)) from exc

        extracted: dict[str, QueryFieldResult] = {}
        for document in result.documents or []:
            for name, field in (document.fields or {}).items():
                extracted[name] = QueryFieldResult(
                    value=field.content, confidence=field.confidence
                )
        return extracted


def create_document_analyzer(
    endpoint: str, api_key: str, timeout_seconds: int
) -> DocumentAnalyzer:
    if endpoint:
        return AzureDocumentAnalyzer(endpoint, api_key, timeout_seconds)
    return UnconfiguredAnalyzer()
