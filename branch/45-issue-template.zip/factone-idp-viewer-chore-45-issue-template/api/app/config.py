from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# ローカル設定はリポジトリルートの .env に集約する（cwd非依存）。
# コンテナ等でファイルが存在しない場合は無視され、環境変数のみで動作する
_REPO_ROOT_ENV = Path(__file__).resolve().parents[2] / ".env"


class Settings(BaseSettings):
    """アプリケーション設定。環境変数（FACTONE_ プレフィックス）とルート .env から読み込む。"""

    # extra="ignore": ルート .env にはcompose用変数（POSTGRES_*等）が同居するため、
    # FACTONE_ プレフィックス外のキーを無視する
    model_config = SettingsConfigDict(
        env_prefix="FACTONE_", env_file=_REPO_ROOT_ENV, extra="ignore"
    )

    app_name: str = "factone-api"

    # OIDC（Keycloak）設定。既定値はローカル開発スタック向け
    oidc_issuer: str = "http://localhost:8080/realms/factone"
    oidc_audience: str = "factone-api"

    @property
    def oidc_jwks_url(self) -> str:
        return f"{self.oidc_issuer}/protocol/openid-connect/certs"

    # データベース接続。既定値はローカル開発スタック向け
    database_url: str = (
        "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone"
    )

    # Blob保存先。azure利用時はaccount_url・containerを設定、localは保存ディレクトリ
    blob_backend: str = "local"  # "local" | "azure"
    blob_local_dir: str = ".blob-data"
    blob_account_url: str = ""
    blob_container: str = "documents"

    # テナント識別子（仮置き: 認可設計確定までリクエストによらず固定値）
    tenant_id: str = "default"

    # Document Intelligence接続。endpoint未設定時は実行APIが502を返す。
    # api_key未設定時はManaged ID認証。タイムアウトは処理時間目標確定までの仮置き
    di_endpoint: str = ""
    di_api_key: str = ""
    di_timeout_seconds: int = 120

    # フロント同居配信: viewerビルド成果物のディレクトリ（存在する場合のみ配信）
    static_dir: str = "static"

    # 閲覧URL設定。既定有効期限は業務要件確定までの仮置き（90日）
    view_url_default_ttl_days: int = 90
    # 無効トークン試行のレート制限（IP単位・固定窓）
    view_url_max_failures: int = 10
    view_url_failure_window_seconds: int = 60
