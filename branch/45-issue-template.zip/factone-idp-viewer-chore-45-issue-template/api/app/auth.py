"""JWT検証（Keycloak発行のアクセストークン）。

検証のみを担い、認可（ロール・テナント・文書アクセス）は未確定事項の解消後に拡張する。
鍵取得は境界アダプタ（KeySource）として分離し、テストでは静的鍵に差し替える。
"""

from dataclasses import dataclass
from typing import Annotated, Any, Protocol

import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.config import Settings

ALLOWED_ALGORITHMS = ["RS256"]


class KeySource(Protocol):
    """トークン署名検証鍵の取得境界。"""

    def get_verification_key(self, token: str) -> Any: ...


class JwksKeySource:
    """KeycloakのJWKSエンドポイントから検証鍵を取得する（キャッシュはPyJWKClientが担う）。"""

    def __init__(self, jwks_url: str) -> None:
        self._client = jwt.PyJWKClient(jwks_url)

    def get_verification_key(self, token: str) -> Any:
        return self._client.get_signing_key_from_jwt(token).key


class StaticKeySource:
    """固定の公開鍵を返す（テスト・検証用）。"""

    def __init__(self, key: Any) -> None:
        self._key = key

    def get_verification_key(self, token: str) -> Any:
        return self._key


@dataclass(frozen=True)
class AuthenticatedUser:
    sub: str
    username: str


_bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    request: Request,
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(_bearer_scheme)
    ],
) -> AuthenticatedUser:
    if credentials is None:
        raise HTTPException(
            status_code=401,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    settings: Settings = request.app.state.settings
    key_source: KeySource = request.app.state.key_source
    token = credentials.credentials

    try:
        key = key_source.get_verification_key(token)
        claims = jwt.decode(
            token,
            key=key,
            algorithms=ALLOWED_ALGORITHMS,
            issuer=settings.oidc_issuer,
            audience=settings.oidc_audience,
            options={"require": ["exp", "iss", "aud", "sub"]},
        )
    except jwt.PyJWTError as exc:
        raise HTTPException(
            status_code=401,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    return AuthenticatedUser(
        sub=claims["sub"], username=claims.get("preferred_username", "")
    )


CurrentUser = Annotated[AuthenticatedUser, Depends(get_current_user)]
