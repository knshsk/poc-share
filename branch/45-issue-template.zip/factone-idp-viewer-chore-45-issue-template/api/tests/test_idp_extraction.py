"""IDP抽出結果のパース・正規化・確信度分離のテスト。"""

from app.di import QueryFieldResult
from app.idp_extraction import QUERY_FIELDS, parse_analysis
from app.models import DocumentType


class TestQueryFields:
    def test_order_types_have_minimum_extraction_fields(self) -> None:
        # 注文書の最低抽出項目: 得意先コード・品目コード・数量・納期・単価
        required = {
            "customer_code",
            "item_code",
            "quantity",
            "delivery_date",
            "unit_price",
        }
        for doc_type in (DocumentType.ORDER_PROJECT, DocumentType.ORDER_ROUTE):
            assert required <= set(QUERY_FIELDS[doc_type])

    def test_all_document_types_have_query_fields(self) -> None:
        for doc_type in DocumentType:
            assert QUERY_FIELDS[doc_type]


class TestParseAnalysis:
    def test_separates_raw_normalized_and_confidence(self) -> None:
        results = {
            "customer_code": QueryFieldResult(value="C-9001", confidence=0.98),
            "item_code": QueryFieldResult(value="P-9001", confidence=0.95),
            "quantity": QueryFieldResult(value="2", confidence=0.99),
            "delivery_date": QueryFieldResult(value="2026-10-30", confidence=0.97),
            "unit_price": QueryFieldResult(value="500,000", confidence=0.96),
        }
        parsed = parse_analysis(DocumentType.ORDER_PROJECT, results)
        assert parsed.raw["unit_price"] == "500,000"
        assert parsed.normalized["unit_price"] == 500000
        assert parsed.confidence["unit_price"] == 0.96

    def test_normalizes_numeric_fields(self) -> None:
        results = {
            "quantity": QueryFieldResult(value="100", confidence=0.9),
            "unit_price": QueryFieldResult(value="1,200", confidence=0.9),
        }
        parsed = parse_analysis(DocumentType.ORDER_ROUTE, results)
        assert parsed.normalized["quantity"] == 100
        assert parsed.normalized["unit_price"] == 1200

    def test_normalizes_slash_date_to_iso(self) -> None:
        results = {
            "delivery_date": QueryFieldResult(value="2026/10/30", confidence=0.9),
        }
        parsed = parse_analysis(DocumentType.ORDER_PROJECT, results)
        assert parsed.normalized["delivery_date"] == "2026-10-30"

    def test_missing_field_yields_none_for_all_views(self) -> None:
        # 必須項目未抽出: 生値・正規化値・確信度すべてNoneで項目自体は返す
        parsed = parse_analysis(DocumentType.ORDER_PROJECT, {})
        assert parsed.raw["customer_code"] is None
        assert parsed.normalized["customer_code"] is None
        assert parsed.confidence["customer_code"] is None

    def test_unparseable_number_keeps_raw_and_nulls_normalized(self) -> None:
        results = {
            "quantity": QueryFieldResult(value="二個", confidence=0.4),
        }
        parsed = parse_analysis(DocumentType.ORDER_PROJECT, results)
        assert parsed.raw["quantity"] == "二個"
        assert parsed.normalized["quantity"] is None
        assert parsed.confidence["quantity"] == 0.4

    def test_unparseable_date_keeps_raw_and_nulls_normalized(self) -> None:
        results = {
            "delivery_date": QueryFieldResult(value="月末", confidence=0.3),
        }
        parsed = parse_analysis(DocumentType.ORDER_PROJECT, results)
        assert parsed.raw["delivery_date"] == "月末"
        assert parsed.normalized["delivery_date"] is None

    def test_extra_fields_outside_query_set_are_ignored(self) -> None:
        results = {
            "unexpected": QueryFieldResult(value="x", confidence=0.5),
        }
        parsed = parse_analysis(DocumentType.QUOTE, results)
        assert "unexpected" not in parsed.raw

    def test_quote_normalizes_total_amount(self) -> None:
        results = {
            "total_amount": QueryFieldResult(value="1,200,000", confidence=0.92),
        }
        parsed = parse_analysis(DocumentType.QUOTE, results)
        assert parsed.normalized["total_amount"] == 1200000
