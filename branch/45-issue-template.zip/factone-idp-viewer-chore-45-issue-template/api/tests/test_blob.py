from pathlib import Path

from app.blob import LocalFileBlobStorage


def test_local_blob_saves_file_under_base_dir(tmp_path: Path) -> None:
    """LocalFileBlobStorageが基点ディレクトリ配下へファイルを保存することを確認する。"""
    storage = LocalFileBlobStorage(tmp_path)

    storage.save("default/doc-001.pdf", b"%PDF-1.7 data")

    saved = tmp_path / "default" / "doc-001.pdf"
    assert saved.read_bytes() == b"%PDF-1.7 data"
