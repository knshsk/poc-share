"""FastAPIアプリのOpenAPIスキーマをJSONファイルへエクスポートする。

使い方: uv run python scripts/export_openapi.py <出力先パス>
"""

import json
import sys
from pathlib import Path

from app.main import create_app


def export(out_path: Path) -> None:
    schema = create_app().openapi()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(schema, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    export(Path(sys.argv[1]))
