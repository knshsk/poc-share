"""create idp runs table

Revision ID: c41d8a92e510
Revises: ba5635f93256
Create Date: 2026-08-25 18:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "c41d8a92e510"
down_revision: str | None = "ba5635f93256"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "idp_runs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("document_id", sa.String(length=255), nullable=False),
        sa.Column("run_type", sa.String(length=20), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("executed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("raw_fields", JSONB(), nullable=True),
        sa.Column("normalized_fields", JSONB(), nullable=True),
        sa.Column("confidence", JSONB(), nullable=True),
        sa.Column("error_info", sa.String(length=2048), nullable=True),
        sa.CheckConstraint(
            "run_type IN ('initial', 'rerun')", name="ck_idp_runs_run_type"
        ),
        sa.CheckConstraint(
            "status IN ('succeeded', 'failed')", name="ck_idp_runs_status"
        ),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["documents.document_id"],
        ),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("idp_runs")
