"""create view events table

Revision ID: ba5635f93256
Revises: 7f1a76df0bf7
Create Date: 2026-08-25 13:17:14.706885

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "ba5635f93256"
down_revision: str | None = "7f1a76df0bf7"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "view_events",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("document_id", sa.String(length=255), nullable=False),
        sa.Column("view_token_id", sa.Uuid(), nullable=False),
        sa.Column("event_type", sa.String(length=20), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("client_ip", sa.String(length=64), nullable=False),
        sa.Column("user_agent", sa.String(length=512), nullable=False),
        sa.CheckConstraint(
            "event_type IN ('view', 'download')", name="ck_view_events_event_type"
        ),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["documents.document_id"],
        ),
        sa.ForeignKeyConstraint(
            ["view_token_id"],
            ["view_tokens.id"],
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "document_id",
            "occurred_at",
            "event_type",
            name="uq_view_events_idempotency",
        ),
    )


def downgrade() -> None:
    op.drop_table("view_events")
