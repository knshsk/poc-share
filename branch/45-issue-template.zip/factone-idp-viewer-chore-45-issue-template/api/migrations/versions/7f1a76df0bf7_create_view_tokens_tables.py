"""create view tokens tables

Revision ID: 7f1a76df0bf7
Revises: 16cc4d7664d6
Create Date: 2026-08-25 12:49:18.049599

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "7f1a76df0bf7"
down_revision: str | None = "16cc4d7664d6"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "view_access_failures",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("token_fragment", sa.String(length=8), nullable=False),
        sa.Column("client_ip", sa.String(length=64), nullable=False),
        sa.Column(
            "occurred_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "view_tokens",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("token_hash", sa.String(length=64), nullable=False),
        sa.Column("document_id", sa.String(length=255), nullable=False),
        sa.Column(
            "issued_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked", sa.Boolean(), nullable=False),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["documents.document_id"],
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("token_hash"),
    )


def downgrade() -> None:
    op.drop_table("view_tokens")
    op.drop_table("view_access_failures")
