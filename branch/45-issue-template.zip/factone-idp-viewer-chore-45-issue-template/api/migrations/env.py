from alembic import context
from sqlalchemy import create_engine

from app.config import Settings
from app.models import Base

target_metadata = Base.metadata


def _database_url() -> str:
    # テスト・CLIからの上書きを許可（config.attributes または -x database_url=...）
    override = context.config.attributes.get("database_url")
    if override:
        return str(override)
    x_args = context.get_x_argument(as_dictionary=True)
    return x_args.get("database_url") or Settings().database_url


def run_migrations_offline() -> None:
    context.configure(
        url=_database_url(),
        target_metadata=target_metadata,
        literal_binds=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = create_engine(_database_url())
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
