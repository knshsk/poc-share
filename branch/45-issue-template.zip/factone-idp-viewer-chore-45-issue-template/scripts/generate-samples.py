# /// script
# requires-python = ">=3.12"
# dependencies = ["reportlab"]
# ///
"""検証用サンプルPDFの生成スクリプト。

使い方: uv run scripts/generate-samples.py
出力: samples/ 配下に3種（見積・注文書(案件型)・注文書(ルート型)）

サンプルは本スクリプトからの生成のみとし、手作業での作成・実データからの
転記は行わない（作成規約は docs/develop-guide/samples.md を参照）。
値はすべて規約に定めたダミー体系（C-9xxx / P-9xxx / 架空社名）を使用する。

日本語フォント（IPAexゴシック）は初回実行時に自動ダウンロードし、
~/.cache/factone-samples/ にキャッシュする（フォントはリポジトリに含めない）。
"""

import io
import urllib.request
import zipfile
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

SAMPLES_DIR = Path(__file__).resolve().parent.parent / "samples"
FONT = "IPAexGothic"
FONT_CACHE = Path.home() / ".cache" / "factone-samples" / "ipaexg.ttf"
FONT_URL = "https://moji.or.jp/wp-content/ipafont/IPAexfont/ipaexg00401.zip"

TITLE_STYLE = ParagraphStyle("title", fontName=FONT, fontSize=18, spaceAfter=8)
BODY_STYLE = ParagraphStyle("body", fontName=FONT, fontSize=10, leading=16)

TABLE_STYLE = TableStyle(
    [
        ("FONT", (0, 0), (-1, -1), FONT, 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
        ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke),
        ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
    ]
)


def ensure_font() -> None:
    """IPAexゴシックを取得して登録する（キャッシュ済みなら再利用）。"""
    if not FONT_CACHE.exists():
        print(f"フォントをダウンロード中: {FONT_URL}")
        FONT_CACHE.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(FONT_URL) as response:
            archive = zipfile.ZipFile(io.BytesIO(response.read()))
        ttf_name = next(n for n in archive.namelist() if n.endswith("ipaexg.ttf"))
        FONT_CACHE.write_bytes(archive.read(ttf_name))
    pdfmetrics.registerFont(TTFont(FONT, str(FONT_CACHE)))


def build(
    filename: str, title: str, doc_no: str, intro: str, rows: list[list[str]]
) -> None:
    doc = SimpleDocTemplate(
        str(SAMPLES_DIR / filename),
        pagesize=A4,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
    )
    header = [
        Paragraph(title, TITLE_STYLE),
        Paragraph(f"文書番号: {doc_no}", BODY_STYLE),
        Paragraph("発行日: 2026-08-01", BODY_STYLE),
        Paragraph("宛先: 株式会社サンプル商事 御中", BODY_STYLE),
        Paragraph("発行元: 架空工業株式会社", BODY_STYLE),
        Spacer(1, 6 * mm),
        Paragraph(intro, BODY_STYLE),
        Spacer(1, 4 * mm),
    ]
    table = Table(
        rows, colWidths=[35 * mm, 45 * mm, 25 * mm, 30 * mm, 30 * mm], style=TABLE_STYLE
    )
    doc.build([*header, table])


def main() -> None:
    SAMPLES_DIR.mkdir(exist_ok=True)

    build(
        "quote-001.pdf",
        "御見積書",
        "Q-2026-9001",
        "下記の通りお見積り申し上げます。",
        [
            ["得意先コード", "品目", "数量", "単価", "金額"],
            ["C-9001", "サンプル装置A（P-9001）", "2", "500,000", "1,000,000"],
            ["C-9001", "設置作業一式（P-9002）", "1", "200,000", "200,000"],
            ["", "", "", "合計", "1,200,000"],
        ],
    )

    build(
        "order-project-001.pdf",
        "注文書",
        "PO-2026-9101",
        "下記の通り注文いたします（個別案件）。",
        [
            ["得意先コード", "品目コード", "数量", "納期", "単価"],
            ["C-9001", "P-9001", "2", "2026-10-30", "500,000"],
            ["C-9001", "P-9002", "1", "2026-11-15", "200,000"],
        ],
    )

    build(
        "order-route-001.pdf",
        "注文書",
        "PO-2026-9201",
        "下記の通り注文いたします（定常発注）。",
        [
            ["得意先コード", "品目コード", "数量", "納期", "単価"],
            ["C-9002", "P-9101", "100", "2026-09-10", "1,200"],
            ["C-9002", "P-9102", "50", "2026-09-10", "3,400"],
        ],
    )

    print(f"生成完了: {SAMPLES_DIR}")


if __name__ == "__main__":
    ensure_font()
    main()
