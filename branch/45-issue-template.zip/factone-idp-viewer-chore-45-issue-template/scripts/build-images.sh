#!/usr/bin/env bash
# コンテナイメージのビルドスクリプト（az acr build。ローカルコンテナ基盤不要）
#
#   ./scripts/build-images.sh [リソースグループ名] [タグ]
#
# api・keycloak両イメージをリポジトリルートをコンテキストにビルドする。

set -euo pipefail

RESOURCE_GROUP="${1:-factone-poc-rg}"
TAG="${2:-latest}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${SCRIPT_DIR}/.."

if ! az account show >/dev/null 2>&1; then
  echo "エラー: Azureへ未ログインです。az login を実行してください" >&2
  exit 1
fi

REGISTRY=$(az acr list --resource-group "${RESOURCE_GROUP}" --query '[0].name' -o tsv)
if [[ -z "${REGISTRY}" ]]; then
  echo "エラー: リソースグループ ${RESOURCE_GROUP} にACRが見つかりません（先に deploy-infra.sh を実行）" >&2
  exit 1
fi

# ViewerのOIDC設定（ビルド時焼き込み）: KeycloakのFQDNをEnvironmentから解決する
# Environment未作成（コア未デプロイ）の場合は空になり、ローカル既定値でビルドされる
DEFAULT_DOMAIN=$(az containerapp env list --resource-group "${RESOURCE_GROUP}" --query '[0].properties.defaultDomain' -o tsv 2>/dev/null || true)
OIDC_AUTHORITY=""
if [[ -n "${DEFAULT_DOMAIN}" ]]; then
  OIDC_AUTHORITY="https://factone-poc-keycloak.${DEFAULT_DOMAIN}/realms/factone"
  echo "Viewer OIDC authority: ${OIDC_AUTHORITY}"
else
  echo "警告: Container Apps Environmentが見つからないため、ViewerはローカルURL既定値でビルドされます" >&2
fi

echo "ビルド: factone-api:${TAG}"
az acr build --registry "${REGISTRY}" \
  --image "factone-api:${TAG}" \
  --file "${REPO_ROOT}/api/Containerfile" \
  --build-arg "VITE_OIDC_AUTHORITY=${OIDC_AUTHORITY}" \
  "${REPO_ROOT}"

echo "ビルド: factone-keycloak:${TAG}"
az acr build --registry "${REGISTRY}" \
  --image "factone-keycloak:${TAG}" \
  --file "${REPO_ROOT}/keycloak/Containerfile" \
  "${REPO_ROOT}"

echo "完了: ${REGISTRY}.azurecr.io / factone-api:${TAG}, factone-keycloak:${TAG}"
