#!/usr/bin/env bash
# Keycloakのシークレット類を設定するスクリプト
#
# realm JSONにはシークレットを含めない運用のため、以下はインポート対象外とし、
# スタック起動後に本スクリプトで設定する（Keycloakのrealmインポートは環境変数置換を
# 行わないため、プレースホルダ方式は使えない）。
#
#   - テストユーザー（testuser）のパスワード
#   - M2M連携クライアント（factone-integration）のクライアントシークレット
#
# 使い方: リポジトリルートで ./scripts/local-stack/apply-keycloak-secrets.sh
# 値は .env の KC_TEST_USER_PASSWORD / KC_INTEGRATION_CLIENT_SECRET を使用する。

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${SCRIPT_DIR}/../.."
CONTAINER="${KEYCLOAK_CONTAINER:-factone-idp-viewer_keycloak_1}"
KCADM="/opt/keycloak/bin/kcadm.sh"

# .env から必要な変数を読み込む
if [[ ! -f "${REPO_ROOT}/.env" ]]; then
  echo "エラー: .env がありません。.env.example をコピーして作成してください" >&2
  exit 1
fi
set -a
# shellcheck source=/dev/null
source "${REPO_ROOT}/.env"
set +a

for var in KC_BOOTSTRAP_ADMIN_USERNAME KC_BOOTSTRAP_ADMIN_PASSWORD KC_TEST_USER_PASSWORD KC_INTEGRATION_CLIENT_SECRET; do
  if [[ -z "${!var:-}" ]]; then
    echo "エラー: .env に ${var} を設定してください" >&2
    exit 1
  fi
done

# コンテナ内のkcadmで管理者ログイン
podman exec "${CONTAINER}" "${KCADM}" config credentials \
  --server http://localhost:8080 --realm master \
  --user "${KC_BOOTSTRAP_ADMIN_USERNAME}" --password "${KC_BOOTSTRAP_ADMIN_PASSWORD}"

# テストユーザーのパスワード設定
podman exec "${CONTAINER}" "${KCADM}" set-password \
  -r factone --username testuser --new-password "${KC_TEST_USER_PASSWORD}"

# M2M連携クライアントのシークレット設定
CLIENT_UUID=$(podman exec "${CONTAINER}" "${KCADM}" get clients \
  -r factone -q clientId=factone-integration --fields id --format csv --noquotes)
if [[ -z "${CLIENT_UUID}" ]]; then
  echo "エラー: クライアント factone-integration が見つかりません" >&2
  exit 1
fi
podman exec "${CONTAINER}" "${KCADM}" update "clients/${CLIENT_UUID}" \
  -r factone -s "secret=${KC_INTEGRATION_CLIENT_SECRET}"

echo "完了: testuser のパスワードと factone-integration のシークレットを設定しました"
