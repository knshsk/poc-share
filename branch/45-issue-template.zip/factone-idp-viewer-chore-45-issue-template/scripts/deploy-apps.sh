#!/usr/bin/env bash
# アプリ層（API・Keycloak Container Apps）のデプロイスクリプト
#
#   FACTONE_POSTGRES_ADMIN_PASSWORD=<DB管理者パスワード> \
#   FACTONE_KEYCLOAK_ADMIN_PASSWORD=<Keycloak管理者パスワード> \
#   ./scripts/deploy-apps.sh [リソースグループ名] [タグ]
#
# 前提: deploy-infra.sh（コア）と build-images.sh（イメージ）が実行済みであること。

set -euo pipefail

RESOURCE_GROUP="${1:-factone-poc-rg}"
TAG="${2:-latest}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BICEP_DIR="${SCRIPT_DIR}/../bicep"

for var in FACTONE_POSTGRES_ADMIN_PASSWORD FACTONE_KEYCLOAK_ADMIN_PASSWORD; do
  if [[ -z "${!var:-}" ]]; then
    echo "エラー: 環境変数 ${var} を設定してください" >&2
    exit 1
  fi
done

if ! az account show >/dev/null 2>&1; then
  echo "エラー: Azureへ未ログインです。az login を実行してください" >&2
  exit 1
fi

REGISTRY_SERVER=$(az acr list --resource-group "${RESOURCE_GROUP}" --query '[0].loginServer' -o tsv)
if [[ -z "${REGISTRY_SERVER}" ]]; then
  echo "エラー: リソースグループ ${RESOURCE_GROUP} にACRが見つかりません" >&2
  exit 1
fi

echo "アプリ層デプロイ実行（イメージタグ: ${TAG}）"
az deployment group create \
  --resource-group "${RESOURCE_GROUP}" \
  --template-file "${BICEP_DIR}/main.bicep" \
  --parameters "${BICEP_DIR}/main.bicepparam" \
  --parameters \
    apiImage="${REGISTRY_SERVER}/factone-api:${TAG}" \
    keycloakImage="${REGISTRY_SERVER}/factone-keycloak:${TAG}" \
    keycloakAdminPassword="${FACTONE_KEYCLOAK_ADMIN_PASSWORD}" \
  --query 'properties.outputs.{api:apiFqdn.value, keycloak:keycloakFqdn.value}' \
  --output table

echo "完了"
