#!/usr/bin/env bash
# シェルスクリプト（*.sh）に git 上の実行権限（100755）が付いているか検査する。
# pre-commit から呼ばれ、対象ファイルパスが引数で渡される。
# Windows等のファイルシステムに依存しないよう、実ファイルのモードではなく git index のモードを見る。
set -euo pipefail

status=0
for file in "$@"; do
  mode=$(git ls-files --stage -- "$file" | awk '{print $1}')
  # 未ステージの新規ファイルは mode が空になるためスキップ（pre-commit はステージ済みのみ渡す想定）
  if [ -n "$mode" ] && [ "$mode" != "100755" ]; then
    echo "実行権限がありません: $file (mode=$mode)"
    echo "  修正: chmod 755 $file && git add $file"
    echo "  （実行ビットを反映できない環境では: git update-index --chmod=+x $file）"
    status=1
  fi
done
exit $status
