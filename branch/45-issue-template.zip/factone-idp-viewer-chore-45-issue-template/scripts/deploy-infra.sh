#!/usr/bin/env bash
# コアインフラ（DI・Blob・PostgreSQL・Key Vault）のデプロイスクリプト
# 使い方: docs/develop-guide/deploy.md を参照してください。
#
#   FACTONE_POSTGRES_ADMIN_PASSWORD=<パスワード> ./scripts/deploy-infra.sh [リソースグループ名] [リージョン]

set -euo pipefail

RESOURCE_GROUP="${1:-factone-poc-rg}"
LOCATION="${2:-japaneast}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BICEP_DIR="${SCRIPT_DIR}/../bicep"

if [[ -z "${FACTONE_POSTGRES_ADMIN_PASSWORD:-}" ]]; then
  echo "エラー: 環境変数 FACTONE_POSTGRES_ADMIN_PASSWORD を設定してください" >&2
  exit 1
fi

if ! az account show >/dev/null 2>&1; then
  echo "エラー: Azureへ未ログインです。az login を実行してください" >&2
  exit 1
fi

echo "リソースグループ作成: ${RESOURCE_GROUP} (${LOCATION})"
az group create --name "${RESOURCE_GROUP}" --location "${LOCATION}" --output none

echo "Bicepデプロイ実行"
az deployment group create \
  --resource-group "${RESOURCE_GROUP}" \
  --template-file "${BICEP_DIR}/main.bicep" \
  --parameters "${BICEP_DIR}/main.bicepparam" \
  --output table

echo "完了"
