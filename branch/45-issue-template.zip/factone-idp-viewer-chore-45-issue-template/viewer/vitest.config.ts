import { defineConfig, mergeConfig } from 'vitest/config'
import viteConfig from './vite.config'

export default mergeConfig(
  viteConfig,
  defineConfig({
    test: {
      environment: 'jsdom',
      setupFiles: ['tests/setup.ts'],
      // Vuetifyはコンパイル済みでない形式で配布されるため、テスト時もインライン変換する
      server: {
        deps: {
          inline: ['vuetify'],
        },
      },
    },
  }),
)
