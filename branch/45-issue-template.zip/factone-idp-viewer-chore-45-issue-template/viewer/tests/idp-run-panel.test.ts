import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// 実行API呼出はapiClient経由のためモックする（パネルは操作と表示分岐が検証対象）
const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
}))

import IdpRunPanel from '../src/viewer/IdpRunPanel.vue'

const succeededRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-08-01T00:00:00Z',
  raw_fields: { order_no: 'A-001' },
  normalized_fields: { order_no: 'A-001', total_amount: 1000 },
  confidence: { order_no: 0.98, total_amount: 0.75 },
  error_info: null,
}

const failedRun = {
  run_id: '22222222-2222-2222-2222-222222222222',
  document_id: 'doc-1',
  run_type: 'rerun',
  status: 'failed',
  executed_at: '2026-08-02T00:00:00Z',
  raw_fields: null,
  normalized_fields: null,
  confidence: null,
  error_info: 'DI request failed',
}

function mountPanel() {
  return mount(IdpRunPanel, {
    props: { documentId: 'doc-1' },
    global: { plugins: [createAppVuetify()] },
  })
}

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
  getMock.mockResolvedValue({
    data: { document_id: 'doc-1', runs: [] },
    error: undefined,
  })
})

describe('IdpRunPanel', () => {
  // 文書表示時に履歴を自動取得し、最新実行の項目化結果と確信度を表示することを確認する
  it('マウント時に履歴取得し最新実行の結果と確信度を表示する', async () => {
    // サーバ応答は実行日時昇順。最新（failedRunより前のsucceededRunでなく末尾）を初期選択する
    getMock.mockResolvedValue({
      data: { document_id: 'doc-1', runs: [succeededRun, failedRun] },
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/documents/{document_id}/idp-runs',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1' } },
      }),
    )
    // 最新=failedRunのためエラー情報が表示される
    expect(wrapper.text()).toContain('DI request failed')
  })

  // 成功実行選択時、項目名・値・確信度が一覧表示されることを確認する
  it('成功実行の項目化結果と確信度を項目別に表示する', async () => {
    getMock.mockResolvedValue({
      data: { document_id: 'doc-1', runs: [succeededRun] },
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()

    const text = wrapper.text()
    expect(text).toContain('order_no')
    expect(text).toContain('A-001')
    expect(text).toContain('total_amount')
    expect(text).toContain('1000')
    // 確信度は%表示
    expect(text).toContain('98%')
    expect(text).toContain('75%')
  })

  // IDP実行ボタンでPOSTし、応答結果が表示・履歴追加されることを確認する
  it('IDP実行ボタンでPOSTし結果を表示する', async () => {
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/documents/{document_id}/idp-runs',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1' } },
      }),
    )
    expect(wrapper.text()).toContain('order_no')
    expect(wrapper.text()).toContain('98%')
    // 履歴一覧に1件追加される
    expect(wrapper.findAll('[data-testid="run-row"]')).toHaveLength(1)
  })

  // 実行失敗（API呼出エラー）時にエラーメッセージが表示されることを確認する
  it('POST失敗時にエラーメッセージを表示する', async () => {
    postMock.mockResolvedValue({
      data: undefined,
      error: { detail: 'Document analysis failed' },
    })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('IDP実行に失敗しました')
  })

  // 履歴行選択で当該実行の結果へ表示が切り替わることを確認する
  it('履歴行選択で該当実行の結果を表示する', async () => {
    getMock.mockResolvedValue({
      data: { document_id: 'doc-1', runs: [succeededRun, failedRun] },
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()

    // 初期表示は最新（failedRun）。過去行（succeededRun）を選択する
    const rows = wrapper.findAll('[data-testid="run-row"]')
    expect(rows).toHaveLength(2)
    await rows[1]!.trigger('click')

    expect(wrapper.text()).toContain('order_no')
    expect(wrapper.text()).toContain('98%')
  })
})
