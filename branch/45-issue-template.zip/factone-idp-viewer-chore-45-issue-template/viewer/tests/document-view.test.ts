import { flushPromises, mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// API呼出はapiClient経由のためモックする（画面はパネル組込が検証対象）
const getMock = vi.fn().mockImplementation((path: string) => {
  if (path === '/api/documents/{document_id}/pages') {
    return Promise.resolve({
      data: { document_id: 'doc-1', pages: [{ width: 8.5, height: 11 }] },
      error: undefined,
    })
  }
  if (path === '/api/documents/{document_id}/pages/{page}/image') {
    return Promise.resolve({ data: new Blob(), error: undefined })
  }
  return Promise.resolve({
    data: { document_id: 'doc-1', runs: [] },
    error: undefined,
  })
})
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return vi.fn()
    },
  },
}))

import DocumentView from '../src/viewer/DocumentView.vue'
import IdpRunPanel from '../src/viewer/IdpRunPanel.vue'

describe('DocumentView', () => {
  // 文書表示時にIDP実行パネルが文書IDを引き渡されて組み込まれることを確認する
  it('文書表示時にIdpRunPanelを表示する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mount(DocumentView, {
      global: { plugins: [createAppVuetify()] },
    })
    await flushPromises()

    const panel = wrapper.findComponent(IdpRunPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('documentId')).toBe('doc-1')
  })

  // 文書未表示（文書ID未入力）ではパネルを表示しないことを確認する
  it('文書未表示ではIdpRunPanelを表示しない', () => {
    window.history.replaceState(null, '', '/')

    const wrapper = mount(DocumentView, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.findComponent(IdpRunPanel).exists()).toBe(false)
  })
})
