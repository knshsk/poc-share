import { mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { describe, expect, it } from 'vitest'

import App from '../src/App.vue'
import { createAppVuetify } from '../src/plugins/vuetify'

describe('App', () => {
  // Vuetify・Piniaを組み込んだAppがレンダリングされ、アプリ名が表示されることを確認する
  it('アプリ名を表示する', () => {
    const wrapper = mount(App, {
      global: {
        plugins: [createAppVuetify(), createPinia()],
      },
    })

    expect(wrapper.text()).toContain('FactONE Viewer')
  })
})
