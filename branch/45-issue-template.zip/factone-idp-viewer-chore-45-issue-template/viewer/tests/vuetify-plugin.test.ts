import { mount } from '@vue/test-utils'
import { defineComponent } from 'vue'
import { describe, expect, it } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// Vuetifyコンポーネントが実要素として解決されることを確認する回帰テスト。
// 未登録だと <v-text-field> 等が未知要素として素通しされ、画面が素のHTMLになる。
describe('Vuetifyプラグイン設定', () => {
  it('v-text-fieldがinput要素として描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-text-field label="文書ID" /></v-app>',
    })

    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.find('input').exists()).toBe(true)
  })

  it('v-btnがbutton要素として描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-btn>表示</v-btn></v-app>',
    })

    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.find('button').exists()).toBe(true)
  })
})
