import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const signinRedirect = vi.fn()
const signinCallback = vi.fn()
const signoutRedirect = vi.fn()

vi.mock('oidc-client-ts', () => ({
  UserManager: class {
    signinRedirect = signinRedirect
    signinCallback = signinCallback
    signoutRedirect = signoutRedirect
  },
  WebStorageStateStore: class {},
  InMemoryWebStorage: class {},
}))

import { useAuthStore } from '../src/auth/store'

describe('認証ストア', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  // 初期状態では未認証であることを確認する
  it('初期状態は未認証', () => {
    const store = useAuthStore()

    expect(store.isAuthenticated).toBe(false)
    expect(store.accessToken).toBeNull()
  })

  // login() がKeycloakへのリダイレクトを開始することを確認する
  it('login()でsigninRedirectが呼ばれる', async () => {
    const store = useAuthStore()

    await store.login()

    expect(signinRedirect).toHaveBeenCalledOnce()
  })

  // コールバック処理後に認証済みとなり、トークン・ユーザー名を保持することを確認する
  it('handleCallback()でユーザー情報とトークンを保持する', async () => {
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: { preferred_username: 'testuser' },
    })
    const store = useAuthStore()

    await store.handleCallback()

    expect(store.isAuthenticated).toBe(true)
    expect(store.accessToken).toBe('token-abc')
    expect(store.username).toBe('testuser')
  })

  // logout() でローカル状態が破棄されリダイレクトが開始されることを確認する
  it('logout()で状態破棄とsignoutRedirectが行われる', async () => {
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: { preferred_username: 'testuser' },
    })
    const store = useAuthStore()
    await store.handleCallback()

    await store.logout()

    expect(store.isAuthenticated).toBe(false)
    expect(store.accessToken).toBeNull()
    expect(signoutRedirect).toHaveBeenCalledOnce()
  })
})
