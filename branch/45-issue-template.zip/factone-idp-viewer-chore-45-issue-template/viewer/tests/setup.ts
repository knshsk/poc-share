// jsdomに存在しないResizeObserverをVuetifyのレイアウトコンポーネントが要求するため補う
class ResizeObserverStub {
  observe(): void {}
  unobserve(): void {}
  disconnect(): void {}
}

globalThis.ResizeObserver =
  ResizeObserverStub as unknown as typeof ResizeObserver
