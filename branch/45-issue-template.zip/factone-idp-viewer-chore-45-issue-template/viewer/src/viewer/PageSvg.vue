<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'

import { apiClient } from '../api/client'

// 読取矩形（DI座標系＝インチ単位。polygonの外接矩形を想定）
export interface OverlayRect {
  x: number
  y: number
  width: number
  height: number
}

const props = defineProps<{
  // 認証済み表示は documentId、閲覧URL経由（無認証）は token を指定する
  documentId?: string
  token?: string
  page: number
  width: number
  height: number
  rects?: OverlayRect[]
}>()

const imageUrl = ref<string | null>(null)

async function fetchImage(): Promise<Blob | null> {
  if (props.token) {
    const { data, error } = await apiClient.GET(
      '/view/{token}/pages/{page}/image',
      {
        params: { path: { token: props.token, page: props.page } },
        parseAs: 'blob',
      },
    )
    return error ? null : data
  }
  if (props.documentId) {
    const { data, error } = await apiClient.GET(
      '/api/documents/{document_id}/pages/{page}/image',
      {
        params: { path: { document_id: props.documentId, page: props.page } },
        parseAs: 'blob',
      },
    )
    return error ? null : data
  }
  return null
}

onMounted(async () => {
  // 画像はAPIプロキシ配信のため、fetchしてblob URLで表示する
  const data = await fetchImage()
  if (data) {
    imageUrl.value = URL.createObjectURL(data)
  }
})

onUnmounted(() => {
  if (imageUrl.value) URL.revokeObjectURL(imageUrl.value)
})
</script>

<template>
  <!-- viewBoxをDI座標系（インチ）に合わせ、rect座標を無変換で使えるようにする -->
  <svg
    :viewBox="`0 0 ${width} ${height}`"
    xmlns="http://www.w3.org/2000/svg"
    class="page-svg"
  >
    <image
      v-if="imageUrl"
      :href="imageUrl"
      :width="width"
      :height="height"
      x="0"
      y="0"
    />
    <rect
      v-for="(rect, index) in rects ?? []"
      :key="index"
      :x="rect.x"
      :y="rect.y"
      :width="rect.width"
      :height="rect.height"
      class="overlay-rect"
    />
  </svg>
</template>

<style scoped>
.page-svg {
  width: 100%;
  height: auto;
  display: block;
  border: 1px solid #ccc;
}

.overlay-rect {
  fill: rgba(33, 150, 243, 0.2);
  stroke: #2196f3;
  stroke-width: 0.02;
}
</style>
