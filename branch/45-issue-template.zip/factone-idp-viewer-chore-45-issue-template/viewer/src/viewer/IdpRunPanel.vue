<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import type { components } from '../api/schema'

type IdpRun = components['schemas']['IdpRunResponse']

const props = defineProps<{
  documentId: string
}>()

// 履歴は表示用に実行日時降順で保持する（サーバ応答は昇順）
const runs = ref<IdpRun[]>([])
const selectedRunId = ref<string | null>(null)
const executing = ref(false)
const errorMessage = ref<string | null>(null)

function selectedRun(): IdpRun | null {
  return runs.value.find((run) => run.run_id === selectedRunId.value) ?? null
}

async function loadRuns(): Promise<void> {
  errorMessage.value = null
  runs.value = []
  selectedRunId.value = null
  if (!props.documentId) return

  const { data, error } = await apiClient.GET(
    '/api/documents/{document_id}/idp-runs',
    {
      params: { path: { document_id: props.documentId } },
    },
  )
  if (error || !data) {
    errorMessage.value = '実行履歴を取得できませんでした'
    return
  }
  runs.value = [...data.runs].reverse()
  selectedRunId.value = runs.value[0]?.run_id ?? null
}

async function executeIdp(): Promise<void> {
  errorMessage.value = null
  executing.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = 'IDP実行に失敗しました'
      return
    }
    runs.value = [data, ...runs.value]
    selectedRunId.value = data.run_id
  } finally {
    executing.value = false
  }
}

function formatConfidence(value: number | null | undefined): string {
  if (value == null) return '-'
  return `${Math.round(value * 100)}%`
}

function formatExecutedAt(value: string): string {
  return new Date(value).toLocaleString()
}

onMounted(() => void loadRuns())
watch(
  () => props.documentId,
  () => void loadRuns(),
)
</script>

<template>
  <div>
    <div class="d-flex align-center mb-2">
      <v-btn
        data-testid="execute-idp"
        :loading="executing"
        :disabled="executing || !documentId"
        @click="executeIdp"
      >
        IDP実行
      </v-btn>
      <span v-if="errorMessage" class="text-error ml-4">{{
        errorMessage
      }}</span>
    </div>

    <template v-if="selectedRun()">
      <template v-if="selectedRun()!.status === 'succeeded'">
        <v-table density="compact" data-testid="run-result">
          <thead>
            <tr>
              <th>項目</th>
              <th>値</th>
              <th>確信度</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(value, key) in selectedRun()!.normalized_fields ?? {}"
              :key="key"
            >
              <td>{{ key }}</td>
              <td>{{ value ?? '-' }}</td>
              <td>{{ formatConfidence(selectedRun()!.confidence?.[key]) }}</td>
            </tr>
          </tbody>
        </v-table>
      </template>
      <p v-else class="text-error" data-testid="run-error">
        実行失敗: {{ selectedRun()!.error_info ?? '不明なエラー' }}
      </p>
    </template>

    <v-table v-if="runs.length > 0" density="compact" class="mt-4">
      <thead>
        <tr>
          <th>実行日時</th>
          <th>実行区分</th>
          <th>ステータス</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="run in runs"
          :key="run.run_id"
          data-testid="run-row"
          :class="{ 'bg-grey-lighten-3': run.run_id === selectedRunId }"
          style="cursor: pointer"
          @click="selectedRunId = run.run_id"
        >
          <td>{{ formatExecutedAt(run.executed_at) }}</td>
          <td>{{ run.run_type === 'initial' ? '初回' : '再実行' }}</td>
          <td>{{ run.status === 'succeeded' ? '成功' : '失敗' }}</td>
        </tr>
      </tbody>
    </v-table>
  </div>
</template>
