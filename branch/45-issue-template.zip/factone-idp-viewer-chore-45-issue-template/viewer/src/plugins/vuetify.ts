import 'vuetify/styles'

import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

// components/directivesを登録しないと<v-btn>等が未知要素として素通し描画される
export function createAppVuetify() {
  return createVuetify({ components, directives })
}
