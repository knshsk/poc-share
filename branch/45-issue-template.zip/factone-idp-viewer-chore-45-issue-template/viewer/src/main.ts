import { createPinia } from 'pinia'
import { createApp } from 'vue'

import App from './App.vue'
import { createAppVuetify } from './plugins/vuetify'

createApp(App).use(createPinia()).use(createAppVuetify()).mount('#app')
