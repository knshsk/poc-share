import js from '@eslint/js'
import prettierConfig from 'eslint-config-prettier'
import pluginVue from 'eslint-plugin-vue'
import tseslint from 'typescript-eslint'

export default tseslint.config(
  { ignores: ['dist/', 'node_modules/', 'src/api/schema.d.ts'] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  ...pluginVue.configs['flat/recommended'],
  {
    files: ['**/*.vue'],
    languageOptions: {
      parserOptions: {
        // .vue ファイルの <script lang="ts"> をTypeScriptとして解析する
        parser: tseslint.parser,
      },
    },
    rules: {
      // ブラウザグローバル（window等）の未定義検査はvue-tsc（TypeScript）に委譲
      'no-undef': 'off',
    },
  },
  {
    files: ['tests/**'],
    rules: {
      // テストでは検証用の小さなコンポーネントを同一ファイルに複数定義する
      'vue/one-component-per-file': 'off',
    },
  },
  // フォーマットはPrettierに委譲するため、競合するスタイル系ルールを無効化
  prettierConfig,
)
