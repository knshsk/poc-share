import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue()],
  server: {
    // ローカル開発時もAPIを同一オリジンで呼ぶ（本番のContainer Apps同居配信と同構成）
    proxy: {
      '/api': 'http://localhost:8000',
      // /view/{token} はSPAのページ、/view/{token}/pages|pdf 配下はAPI
      '^/view/[^/]+/(pages|pdf)': 'http://localhost:8000',
    },
  },
})
