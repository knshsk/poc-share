---
status: accepted
date: 2026-08-25
---

# フロントエンドをContainer Apps同居で配信する

## 背景

Viewer（Vue SPA）の配信方式として、Azure Static Web Apps（SWA）を使うかAPIコンテナに同居させるかの選定が必要だった。認証基盤はKeycloak採用が決定済み（ADR-0006）で、Power AutomateはIDP APIを直接呼び出す。

## 決定

FastAPIからViewerビルド成果物を配信するContainer Apps同居配信とする（コンテナ1本の最小構成。実装はSPAフォールバック付きのcatch-allルートによる静的ファイル配信）。コンテナビルドはマルチステージ構成でViewerビルド成果物をPython実行イメージへ同梱する。

採用理由:

- 単一オリジンとなりCORS管理が不要
- 全経路（ブラウザ・Power Automate）がJWT検証一本で通り、認証モデルが単純
- デプロイ単位が1つで済む
- 将来VNet+PE隔離を採用する場合も構成が変わらない

## 検討した代替案

- Static Web Apps無料プラン — カスタムOIDC不可（Standardのみ）でKeycloakと組めず認証面の利点がゼロ。別オリジンとなりCORS管理も必要なため却下
- SWA Standard+カスタムOIDC（Easy Auth）+リンクバックエンド — 認証実装量は最小（トークン非露出をEasy Authで獲得）だが、(1) Power AutomateのAPI直接呼出と`x-ms-client-principal`ヘッダ信頼モデルが併存して認証経路が二重化し、ingressをSWA専用に閉じられず偽装対策が別途必要 (2) SWAはVNetに参加できず将来の隔離採用時に不成立 (3) 相乗り先環境の構成と不整合の可能性 — のため却下

## 影響

- 静的配信の性能・責務分離が必要になった場合は、同一Environment内の配信コンテナ分離へ発展させる
- コンテナビルドのコンテキストはリポジトリルートとし、`api/Containerfile`から`viewer/`・`api/`両方を参照する
