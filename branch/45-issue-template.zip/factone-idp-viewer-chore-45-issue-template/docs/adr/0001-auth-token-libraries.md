---
status: accepted
date: 2026-08-25
---

# 認証トークン処理ライブラリにPyJWTとoidc-client-tsを採用

## 背景

認証統合（ViewerのOIDC/PKCEログインとAPIのJWT検証）の実装にあたり、トークン処理ライブラリの選定が必要になった。認証方式はKeycloak+OIDC、ブラウザ側はSPA+認可コードフロー+PKCE、APIはJWT検証のみを担う構成が決定済みである。

## 決定

- API（Python/FastAPI）のJWT検証には **PyJWT** を採用する。
- Viewer（Vue SPA）のOIDCクライアントには **oidc-client-ts** を採用する。
- いずれも実装着手時点の最新安定版を使用する。

採用理由:

- PyJWT: JWT検証のデファクトで活発にメンテされている。`PyJWKClient` によるJWKS取得・キャッシュが標準装備で、Keycloak公開鍵での署名検証がライブラリ内で完結する。APIが小さく検証パラメータ（issuer / audience / exp）が明示的で、セキュリティレビューが容易。「APIはJWT検証のみ」というスコープに過不足なく一致する。
- oidc-client-ts: 標準OIDC準拠でIdPに依存しない。旧定番oidc-clientの公式後継で、認可コードフロー+PKCE・refresh token rotationに対応し、決定済みの認証方式と一致する。フレームワーク非依存のためPiniaストアに素直に統合できる。

## 検討した代替案

- python-jose（API） — メンテ停滞、2024年にアルゴリズム混同・DoSのCVE。実質非推奨のため却下
- Authlib（API） — 高品質だがOAuthサーバ/クライアント機能を含む統合ライブラリで、JWT検証のみの用途には過剰なため却下
- joserfc（API） — 設計は良いが採用実績・エコシステム成熟度でPyJWTに劣後するため却下
- python-keycloak（API） — Keycloak admin API操作が主目的で、トークン検証だけに使うと不要な結合が生じるため却下
- keycloak-js（Viewer） — Keycloak専用でサーバーバージョンと密結合の傾向があり、IdP中立性の方針と整合しないため却下
- Vue向けOIDCラッパー各種（Viewer） — メンテが薄く、実質oidc-client系のラッパーで層が増えるだけのため却下

## 影響

- Keycloak固有機能（セッション管理連携等）はライブラリからは使わない。必要になった場合は標準OIDCの範囲で実現するか、本決定を見直す
- oidc-client-tsはトークンをブラウザ側で扱うため、XSS耐性はBFF方式に劣る（BFF自作の却下はブラウザ側認証方式のADRで扱う）。本番化時の強化オプションとして再評価する
- PyJWTのJWKSキャッシュ動作（更新頻度・失効時の挙動）はKeycloak鍵ローテーション運用を決める際に確認する
