---
status: accepted
date: 2026-08-25
---

# ブラウザ側認証はSPA+OIDC/PKCEとしBFFを設けない

## 背景

Keycloak採用（ADR-0006）を受け、ブラウザ側の認証実装方式の選定が必要になった。トークンをブラウザに渡すSPA直接方式と、トークンをサーバ側に隠すBFF（Backend for Frontend）方式が候補になった。

## 決定

Vueアプリが`oidc-client-ts`でKeycloakと認可コードフロー+PKCEを実行するSPA方式とする。

- アクセストークンはメモリ保持（短寿命+refresh token rotation）
- API呼出は`Authorization: Bearer`ヘッダ
- FastAPIはJWT検証のみを担い、ステートレスを維持する

採用理由: 実装量が最小で、全経路（ブラウザ・Power Automate）がJWT検証一本で通り認証モデルが単純になる。

## 検討した代替案

- BFF自作 — トークン非露出（XSS耐性）では優るが、セッション管理・CSRF対策・トークン更新の自作コストが大きい。またクッキー系とJWT系の認証二本立てとなり、フロント配信でSWA Standard案を却下したのと同じ構図（認証経路の二重化）になるため却下

## 影響

- XSS耐性はBFF方式に劣る。本番化時の強化オプションとしてBFF導入を再評価する
- トークン処理ライブラリの選定はADR-0001（PyJWT・oidc-client-ts）を参照
