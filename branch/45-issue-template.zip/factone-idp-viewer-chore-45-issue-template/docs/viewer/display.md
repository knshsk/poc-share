# 文書表示（ページ画像+SVGオーバーレイ）

文書ID指定でのPDF表示の実現方式。決定済みの「ページ画像+SVGオーバーレイ方式」の実装仕様を記載する。

## 構成

- PDFの各ページをAPI側でPNGに変換（pypdfium2・150dpi・オンデマンド変換）し、APIプロキシ配信する
- Viewerは `<svg>` の `image` 要素としてページ画像を表示し、読取矩形を同一SVG内の `rect` で重畳する
- Blobは全面非公開のため、画像・原本PDFともAPI経由でfetchし、blob URLで表示・DLする

## 座標系整合

Document Intelligenceのpolygon座標（ページ単位・インチ）とSVGを無変換で整合させる。

- `GET /api/documents/{id}/pages` がページ寸法を**インチ単位**で返す（ポイント値÷72）
- SVGの `viewBox` を `0 0 {幅インチ} {高さインチ}` に設定
- これによりDIのpolygon座標をそのまま `rect` の座標に使える（変換ロジック不要）
- PNGの描画解像度（150dpi）はviewBoxと独立しており、表示品質のみに影響する

## エンドポイント

| パス | 内容 |
| --- | --- |
| `GET /api/documents/{document_id}` | 文書メタデータ |
| `GET /api/documents/{document_id}/pages` | ページ数+各ページ寸法（インチ） |
| `GET /api/documents/{document_id}/pages/{page}/image` | ページPNG（pageは1始まり） |
| `GET /api/documents/{document_id}/pdf` | 原本PDF（DL用） |

- すべてJWT必須。存在しない文書ID・テナント不一致は404（存在を秘匿）
- 破損PDFは500+`Failed to process PDF`
- URLに拡張子を含めない（形式はContent-Typeが正。将来の形式変更・追加はヘッダ/クエリで対応）

## 実装ノート

- 変換タイミングはオンデマンド開始（決定済み）。性能問題が顕在化したら取込時の事前変換へ移行
- 読取矩形（`PageSvg` の `rects` prop）はDI連携実装後にデータが供給される。現時点は器のみ
- 閲覧・DLイベント記録は本方式の配信経路（APIプロキシ）上に後続で追加する
