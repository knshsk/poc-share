// Key Vault（シークレット管理。アクセスはRBAC認可）

@description('Key Vault名（グローバル一意・24文字以内）')
@maxLength(24)
param keyVaultName string

param location string

@description('PostgreSQL管理者パスワード（シークレットとして格納）')
@secure()
param postgresAdminPassword string

resource keyVault 'Microsoft.KeyVault/vaults@2024-11-01' = {
  name: keyVaultName
  location: location
  properties: {
    sku: {
      family: 'A'
      name: 'standard'
    }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
    publicNetworkAccess: 'Enabled'
  }
}

resource postgresPasswordSecret 'Microsoft.KeyVault/vaults/secrets@2024-11-01' = {
  parent: keyVault
  name: 'postgres-admin-password'
  properties: {
    value: postgresAdminPassword
  }
}

output keyVaultName string = keyVault.name
