// Blob Storage（文書PDF・変換画像の保管）
// アクセスはAPIのManaged ID経由のみ（完全プロキシ方式）。匿名アクセス無効・TLS強制。

@description('ストレージアカウント名（グローバル一意・小文字英数24文字以内）')
@maxLength(24)
param storageAccountName string

param location string

resource storageAccount 'Microsoft.Storage/storageAccounts@2024-01-01' = {
  name: storageAccountName
  location: location
  kind: 'StorageV2'
  sku: {
    name: 'Standard_LRS'
  }
  properties: {
    allowBlobPublicAccess: false
    minimumTlsVersion: 'TLS1_2'
    supportsHttpsTrafficOnly: true
    // ネットワーク隔離なしの決定に基づきパブリックエンドポイントを維持（認証で保護）
    publicNetworkAccess: 'Enabled'
  }
}

resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2024-01-01' = {
  parent: storageAccount
  name: 'default'
}

// 文書PDF格納用コンテナ
resource documentsContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2024-01-01' = {
  parent: blobService
  name: 'documents'
  properties: {
    publicAccess: 'None'
  }
}

output storageAccountName string = storageAccount.name
