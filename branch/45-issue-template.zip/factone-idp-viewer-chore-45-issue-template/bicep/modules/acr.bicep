// Azure Container Registry（イメージ保管。ビルドは az acr build）

@description('レジストリ名（グローバル一意・英数のみ）')
param registryName string

param location string

resource registry 'Microsoft.ContainerRegistry/registries@2025-04-01' = {
  name: registryName
  location: location
  sku: {
    name: 'Basic'
  }
  properties: {
    // pullはマネージドIDのAcrPullロールで行う
    adminUserEnabled: false
  }
}

output registryName string = registry.name
output loginServer string = registry.properties.loginServer
