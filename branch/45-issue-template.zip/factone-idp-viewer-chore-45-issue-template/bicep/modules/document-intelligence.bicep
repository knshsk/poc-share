// Azure AI Document Intelligence（証憑の文字化・項目化）

@description('アカウント名（エンドポイントのサブドメインに使用・グローバル一意）')
param accountName string

param location string

resource account 'Microsoft.CognitiveServices/accounts@2025-06-01' = {
  name: accountName
  location: location
  kind: 'FormRecognizer'
  sku: {
    name: 'S0'
  }
  properties: {
    customSubDomainName: accountName
    publicNetworkAccess: 'Enabled'
  }
}

output endpoint string = account.properties.endpoint
