// Keycloak（Container Apps相乗り・realm焼き込みイメージ）
// DBは共用PostgreSQL内の別DB。PoC割切りとして管理者ユーザーで接続する
// （本番化時は専用DBユーザーへ分離）。

@description('アプリ名')
param appName string

param location string
param environmentId string

@description('リビジョンサフィックス（デプロイごとに変更し、同名タグでも再プル・新リビジョンを強制する）')
param revisionSuffix string

@description('コンテナイメージ（realm焼き込み済み）')
param image string

param registryServer string

@description('ユーザー割当マネージドIDのリソースID')
param identityId string

@description('PostgreSQLサーバFQDN')
param postgresFqdn string

@description('DB管理者ユーザー名')
param dbUser string

@secure()
param dbPassword string

@description('ブートストラップ管理者ユーザー名')
param adminUser string

@secure()
param adminPassword string

@description('公開ホスト名（Container AppsのFQDN。KC_HOSTNAMEに使用）')
param hostname string

resource keycloakApp 'Microsoft.App/containerApps@2025-01-01' = {
  name: appName
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identityId}': {}
    }
  }
  properties: {
    managedEnvironmentId: environmentId
    configuration: {
      ingress: {
        external: true
        targetPort: 8080
      }
      registries: [
        {
          server: registryServer
          identity: identityId
        }
      ]
      secrets: [
        { name: 'db-password', value: dbPassword }
        { name: 'admin-password', value: adminPassword }
      ]
    }
    template: {
      revisionSuffix: revisionSuffix
      containers: [
        {
          name: 'keycloak'
          image: image
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: [
            // KC_DBはイメージビルド時に確定済み（keycloak/Containerfileのkc.sh build）
            // 本番モード（start）はhostname必須。Container AppsのFQDNを設定する
            { name: 'KC_HOSTNAME', value: 'https://${hostname}' }
            {
              name: 'KC_DB_URL'
              value: 'jdbc:postgresql://${postgresFqdn}:5432/keycloak?sslmode=require'
            }
            { name: 'KC_DB_USERNAME', value: dbUser }
            { name: 'KC_DB_PASSWORD', secretRef: 'db-password' }
            { name: 'KC_BOOTSTRAP_ADMIN_USERNAME', value: adminUser }
            { name: 'KC_BOOTSTRAP_ADMIN_PASSWORD', secretRef: 'admin-password' }
            // Container Appsのingress（TLS終端）配下で動かすための設定
            { name: 'KC_PROXY_HEADERS', value: 'xforwarded' }
            { name: 'KC_HTTP_ENABLED', value: 'true' }
          ]
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 1
      }
    }
  }
}

output fqdn string = keycloakApp.properties.configuration.ingress.fqdn
