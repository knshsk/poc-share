// API本体のContainer App（フロント同居配信）
// システム割当マネージドIDでBlob・Document Intelligence・Key Vault・ACRへアクセスする
// （ロール付与は modules/app-roles.bicep）。

@description('アプリ名')
param appName string

param location string
param environmentId string

@description('リビジョンサフィックス（デプロイごとに変更し、同名タグでも再プル・新リビジョンを強制する）')
param revisionSuffix string

@description('コンテナイメージ（例: {acr}.azurecr.io/factone-api:tag）')
param image string

@description('ACRログインサーバ（マネージドIDでのpull用）')
param registryServer string

@description('PostgreSQL接続文字列（シークレット）')
@secure()
param databaseUrl string

@description('KeycloakのOIDC issuer URL')
param oidcIssuer string

@description('BlobストレージのアカウントURL')
param blobAccountUrl string

@description('Document IntelligenceのエンドポイントURL')
param diEndpoint string

@description('ユーザー割当マネージドIDのリソースID')
param identityId string

@description('ユーザー割当マネージドIDのクライアントID（DefaultAzureCredentialの選択用）')
param identityClientId string

resource apiApp 'Microsoft.App/containerApps@2025-01-01' = {
  name: appName
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identityId}': {}
    }
  }
  properties: {
    managedEnvironmentId: environmentId
    configuration: {
      ingress: {
        external: true
        targetPort: 8000
      }
      registries: [
        {
          server: registryServer
          identity: identityId
        }
      ]
      secrets: [
        {
          name: 'database-url'
          value: databaseUrl
        }
      ]
    }
    template: {
      revisionSuffix: revisionSuffix
      containers: [
        {
          name: 'api'
          image: image
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: [
            { name: 'FACTONE_DATABASE_URL', secretRef: 'database-url' }
            { name: 'FACTONE_OIDC_ISSUER', value: oidcIssuer }
            { name: 'FACTONE_BLOB_BACKEND', value: 'azure' }
            { name: 'FACTONE_BLOB_ACCOUNT_URL', value: blobAccountUrl }
            // APIキーは設定せずManaged ID認証を使用する
            { name: 'FACTONE_DI_ENDPOINT', value: diEndpoint }
            // ユーザー割当IDをDefaultAzureCredentialに使わせる
            { name: 'AZURE_CLIENT_ID', value: identityClientId }
          ]
          probes: [
            {
              type: 'Readiness'
              httpGet: {
                path: '/health'
                port: 8000
              }
            }
          ]
        }
      ]
      scale: {
        // インメモリのレート制限・単一レプリカ前提の処理があるためPoCは1固定
        minReplicas: 1
        maxReplicas: 1
      }
    }
  }
}

output fqdn string = apiApp.properties.configuration.ingress.fqdn
