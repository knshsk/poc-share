// アプリ用ユーザー割当マネージドID
// システム割当ではなくユーザー割当を使う理由: ACRプルにはアプリ作成前のロール付与が
// 必要であり、システム割当（アプリ作成時に生成）では順序が成立しないため。

@description('API用ID名')
param apiIdentityName string

@description('Keycloak用ID名')
param keycloakIdentityName string

param location string

resource apiIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2024-11-30' = {
  name: apiIdentityName
  location: location
}

resource keycloakIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2024-11-30' = {
  name: keycloakIdentityName
  location: location
}

output apiIdentityId string = apiIdentity.id
output apiPrincipalId string = apiIdentity.properties.principalId
output apiClientId string = apiIdentity.properties.clientId
output keycloakIdentityId string = keycloakIdentity.id
output keycloakPrincipalId string = keycloakIdentity.properties.principalId
