// PostgreSQL Flexible Server（アプリ用DB。Keycloak用DBも同一サーバ内別DBとして後続で追加）

@description('サーバ名（グローバル一意）')
param serverName string

param location string

param administratorLogin string

@secure()
param administratorLoginPassword string

resource server 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' = {
  name: serverName
  location: location
  sku: {
    name: 'Standard_B1ms'
    tier: 'Burstable'
  }
  properties: {
    version: '17'
    administratorLogin: administratorLogin
    administratorLoginPassword: administratorLoginPassword
    storage: {
      storageSizeGB: 32
    }
    backup: {
      // PoCのため最小構成（本番水準のバックアップ・DRは対象外）
      backupRetentionDays: 7
      geoRedundantBackup: 'Disabled'
    }
  }
}

// Azure内サービス（Container Apps等）からの接続を許可
// Container Apps(Consumption)のアウトバウンドIPが非固定のため広い規則を許容（PoC限定判断）
resource allowAzureServices 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2024-08-01' = {
  parent: server
  name: 'AllowAllAzureServicesAndResourcesWithinAzureIps'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

// アプリ用DB
resource factoneDb 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: server
  name: 'factone'
}

// Keycloak用DB（共用サーバ内別DB）
resource keycloakDb 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: server
  name: 'keycloak'
}

output serverFqdn string = server.properties.fullyQualifiedDomainName
