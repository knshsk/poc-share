using 'main.bicep'

param environmentName = 'poc'
param postgresAdminLogin = 'factone'

// パスワードはコミットしない。デプロイ時に環境変数から注入する（scripts/deploy-infra.sh参照）
param postgresAdminPassword = readEnvironmentVariable('FACTONE_POSTGRES_ADMIN_PASSWORD')
