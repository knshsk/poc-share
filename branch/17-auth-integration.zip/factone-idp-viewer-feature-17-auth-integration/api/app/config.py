from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """アプリケーション設定。環境変数（FACTONE_ プレフィックス）と .env から読み込む。"""

    model_config = SettingsConfigDict(env_prefix="FACTONE_", env_file=".env")

    app_name: str = "factone-api"

    # OIDC（Keycloak）設定。既定値はローカル開発スタック向け
    oidc_issuer: str = "http://localhost:8080/realms/factone"
    oidc_audience: str = "factone-api"

    @property
    def oidc_jwks_url(self) -> str:
        return f"{self.oidc_issuer}/protocol/openid-connect/certs"
