from fastapi import FastAPI

from app.auth import CurrentUser, JwksKeySource, KeySource
from app.config import Settings


def create_app(
    settings: Settings | None = None, key_source: KeySource | None = None
) -> FastAPI:
    settings = settings or Settings()
    key_source = key_source or JwksKeySource(settings.oidc_jwks_url)

    app = FastAPI(title=settings.app_name)
    app.state.settings = settings
    app.state.key_source = key_source

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/api/me")
    def me(user: CurrentUser) -> dict[str, str]:
        return {"sub": user.sub, "username": user.username}

    return app
