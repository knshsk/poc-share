#!/usr/bin/env bash
# 開発用テストユーザーのパスワードを設定するスクリプト
#
# realm JSONにはシークレットを含めない運用のため、パスワードはインポート対象外とし、
# スタック起動後に本スクリプトで設定する（Keycloakのrealmインポートは環境変数置換を
# 行わないため、プレースホルダ方式は使えない）。
#
# 使い方: リポジトリルートで ./scripts/local-stack/set-test-user-password.sh
# パスワードは .env の KC_TEST_USER_PASSWORD を使用する。

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${SCRIPT_DIR}/../.."
CONTAINER="${KEYCLOAK_CONTAINER:-factone-idp-viewer_keycloak_1}"

# .env から必要な変数を読み込む
if [[ ! -f "${REPO_ROOT}/.env" ]]; then
  echo "エラー: .env がありません。.env.example をコピーして作成してください" >&2
  exit 1
fi
set -a
# shellcheck source=/dev/null
source "${REPO_ROOT}/.env"
set +a

for var in KC_BOOTSTRAP_ADMIN_USERNAME KC_BOOTSTRAP_ADMIN_PASSWORD KC_TEST_USER_PASSWORD; do
  if [[ -z "${!var:-}" ]]; then
    echo "エラー: .env に ${var} を設定してください" >&2
    exit 1
  fi
done

# コンテナ内のkcadmで管理者ログイン→テストユーザーのパスワード設定
podman exec "${CONTAINER}" /opt/keycloak/bin/kcadm.sh config credentials \
  --server http://localhost:8080 --realm master \
  --user "${KC_BOOTSTRAP_ADMIN_USERNAME}" --password "${KC_BOOTSTRAP_ADMIN_PASSWORD}"

podman exec "${CONTAINER}" /opt/keycloak/bin/kcadm.sh set-password \
  -r factone --username testuser --new-password "${KC_TEST_USER_PASSWORD}"

echo "完了: testuser のパスワードを設定しました"
