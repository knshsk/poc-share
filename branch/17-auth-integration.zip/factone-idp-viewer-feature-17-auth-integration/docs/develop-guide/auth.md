# ローカル認証動作手順

Keycloakを使った認証付きの動作確認手順です。前提として [local-stack.md](local-stack.md)・[api.md](api.md)・[viewer.md](viewer.md) のセットアップが完了していること。

## 1. ローカルスタック起動とテストユーザー設定

```bash
podman compose up -d
```

初回起動（またはボリューム初期化後）は、realmインポート完了を待ってからテストユーザーのパスワードを設定します。

```bash
./scripts/local-stack/set-test-user-password.sh
```

パスワードは `.env` の `KC_TEST_USER_PASSWORD` が使われます。realm定義JSONにはパスワードを含めない運用のため、このスクリプトでの設定が必要です（Keycloakのrealmインポートは環境変数置換を行いません）。

## 2. API・Viewer起動

```bash
cd api
uv run uvicorn --factory app.main:create_app --reload
```

```bash
cd viewer
npm run dev
```

## 3. 動作確認

1. `http://localhost:5173/` を開く
2. 「ログイン」→ Keycloakのログイン画面で `testuser` / `.env` のパスワードを入力
3. ログイン後「API呼出」→ `/api/me` の応答（sub・username）が表示される
4. 「ログアウト」で未認証状態に戻る

## 構成メモ

- 認証フロー: 認可コードフロー+PKCE（S256必須）。クライアントは `factone-viewer`（public）
- アクセストークン: Viewer側でメモリ保持（永続化なし）。API呼出時に `Authorization: Bearer` 付与
- API側検証: 署名（KeycloakのJWKS）・issuer・audience（`factone-api`）・有効期限
- ローカルのAPI呼出はVite devプロキシ（`/api` → `localhost:8000`）で同一オリジン化
- 設定の上書き: API側は環境変数 `FACTONE_OIDC_ISSUER` / `FACTONE_OIDC_AUDIENCE`、Viewer側は `VITE_OIDC_AUTHORITY` / `VITE_OIDC_CLIENT_ID`
- テナント識別・ロール・文書アクセス認可は未実装（未確定事項の解消後に対応）
