# Keycloak構成管理

Keycloakのrealm定義をconfig-as-codeで管理するディレクトリ。

## 運用ルール

realm設計は「単一realm`factone` + アクセストークンの`tenant_id`クレーム」で確定した（[ADR-0020](../docs/adr/0020-single-realm-tenant-claim.md)、[docs/architecture/auth.md](../docs/architecture/auth.md)）。テナントの作成・無効化は、リポジトリルートの`scripts/tenant.sh`（[docs/develop-guide/tenant.md](../docs/develop-guide/tenant.md)）で行う。

`realm/`配下のrealm定義JSONを構成管理の正とする。Keycloak管理コンソールでの手動変更はJSONに反映されず、realmの再作成時に失われる。そのため、変更はJSONを編集して再投入する。

起動時の`--import-realm`によって、`realm/`配下のJSONが自動投入される。ローカルではリポジトリルートの`compose.yaml`でマウントし、Azureではこのディレクトリの`Containerfile`でイメージへ焼き込む。いずれも同一の定義を使う。

既存のrealmがある場合、`--import-realm`は既定でスキップされる。定義の変更を反映するには、realmを削除して再起動するか、ローカルではデータボリュームを初期化する。ローカルでデータボリュームを初期化する手順は、`docs/develop-guide/local-stack.md`にある。

## シークレット非含有ルール

realm JSONにシークレット（クライアントシークレット・パスワード等）を含めない。Keycloakのrealmインポートは環境変数置換を行わず、プレースホルダ文字列がそのまま値になる。パスワード・クライアントシークレット等の実行時設定が必要な項目は、起動後に設定する。ローカルでは、リポジトリルートの`scripts/local-stack/apply-keycloak-secrets.sh`が`kcadm`で設定する。Azureでは、同じ操作をコンテナ内の`kcadm`で手動で行う（[docs/develop-guide/deploy.md](../docs/develop-guide/deploy.md)）。

現在のrealm定義は次のとおり。

| 対象 | 内容 |
| --- | --- |
| realm本体 | ユーザープロファイルに属性`tenant_id`を宣言する。編集は管理者のみ |
| publicクライアント`factone-viewer` | SPA用。PKCE S256必須、audienceマッパー、ユーザー属性`tenant_id`をクレーム`tenant_id`に載せるマッパー |
| confidentialクライアント`factone-integration` | テナント`default`の外部システム連携用M2M。client credentials grant、audienceマッパー、hardcoded claim`tenant_id=default`。シークレットはインポート対象外 |
| テストユーザー`testuser` | 属性`tenant_id=default`。パスワードはインポート対象外 |

テナント追加時のクライアント`factone-integration-<tenant_id>`とユーザーは、シークレット非含有ルールのため、realm定義に含めず`scripts/tenant.sh`で作る。

ロールは未確定事項の解消後に拡充する。
