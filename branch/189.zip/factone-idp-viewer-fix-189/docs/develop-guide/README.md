# 開発者向けガイド

環境構築・開発手順・運用手順に関する開発者向け資料を格納するディレクトリ。

## 文書一覧

表は読み順に並べている。

| 文書 | 内容 |
| --- | --- |
| [wsl-setup.md](wsl-setup.md) | WSL開発環境の構築（WSL2+Ubuntu 24.04、プロキシ設定、Podman導入）。マシンごとに1回行う |
| [local-stack.md](local-stack.md) | ローカル開発スタックの起動・停止・初期化。日常操作 |
| [api.md](api.md) | バックエンドAPIのセットアップ・起動・テスト実行（uv+FastAPI） |
| [viewer.md](viewer.md) | フロントエンドのセットアップ・起動・テスト実行（Vite+Vue） |
| [quality.md](quality.md) | 品質ゲート（pre-commitセットアップ・lint・型検査） |
| [auth.md](auth.md) | ローカル認証の動作手順（Keycloakログイン・API認証確認） |
| [deploy.md](deploy.md) | Azureデプロイ（前提条件・使い方）。手順の正は`scripts/` |
| [tenant.md](tenant.md) | テナント運用。`scripts/tenant.sh`による作成・ユーザー追加・無効化と、文書種別の初期登録 |
| [samples.md](samples.md) | サンプルPDF作成規約（実データ由来禁止・ダミー値規則・生成手順） |

このディレクトリは、ローカル開発環境の構築手順（WSL2+Podman、ローカルスタック起動）を扱う。デプロイ手順の正は`scripts/`のスクリプトで、[deploy.md](deploy.md)には前提条件・使い方・トラブルシュートだけを記述する。手順詳細を二重に管理するのを避けるためである。`samples/`のサンプルPDF作成規約（実データ由来禁止・ダミー値規則）も、ここに定める。
