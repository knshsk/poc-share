# テナント運用（作成・ユーザー追加・無効化）

テナントの追加と無効化を`scripts/tenant.sh`で行う手順。本稼働時は社内SaaSのKeycloakに統合する予定のため、本スクリプトは統合までの間に本リポジトリのrealm`factone`を運用する最小限の手段である。テナント管理API・管理画面は持たない。

設計は[architecture/auth.md](../architecture/auth.md)の「テナント解決」と[ADR-0020](../adr/0020-single-realm-tenant-claim.md)を参照。

## 前提条件

ローカルスタックが起動していること（[local-stack.md](local-stack.md)）。`kcadm`は、ローカルのKeycloakコンテナ内のものを使う。

管理者資格情報は、`.env`の`KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD`を使う。同じ変数を環境変数で渡すと、`.env`より環境変数が優先される。

Azureのrealmを操作する場合は、`KC_SERVER=https://<Keycloak の FQDN>`とAzure側の管理者パスワード（`deploy-apps.sh`の`FACTONE_KEYCLOAK_ADMIN_PASSWORD`）を環境変数で渡す。ローカルコンテナ内の`kcadm`がリモートに接続する。

```bash
KC_SERVER=https://factone-poc-keycloak.example.azurecontainerapps.io KC_BOOTSTRAP_ADMIN_USERNAME=admin KC_BOOTSTRAP_ADMIN_PASSWORD='<パスワード>' ./scripts/tenant.sh create acme
```

## テナントID

テナントIDの形式は`^[a-z0-9][a-z0-9-]{0,62}$`。Blobパス・クライアントID・URLに使うため、小文字英数字とハイフンに限る。`default`はrealm定義で管理する既定テナントで、本スクリプトでは扱えない。

## 1. テナント作成

```bash
./scripts/tenant.sh create <tenant_id>
```

confidentialクライアント`factone-integration-<tenant_id>`を作る。このクライアントは、service accountsだけを有効にし、audienceマッパーとhardcoded claim（`tenant_id=<tenant_id>`）を持つ。

クライアントシークレットは標準出力にだけ出る。ファイルには残さないので、テナントの連携システムへ安全な経路で渡す。同名のクライアントがあればエラー終了するため、冪等ではない。文書種別は投入しない。次節で登録する。

## 2. 文書種別の登録

テナントのM2Mトークンで文書種別設定APIを呼ぶ。トークンはclient credentials grantで取る。

```bash
TOKEN=$(curl -s -d 'grant_type=client_credentials&client_id=factone-integration-<tenant_id>&client_secret=<シークレット>' http://localhost:8080/realms/factone/protocol/openid-connect/token | python3 -c 'import sys,json; print(json.load(sys.stdin)["access_token"])')
```

取得したトークンで、文書種別を登録する。

```bash
curl -s -X POST http://localhost:8000/api/v1/config/document-types -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"type_code":"quotation","display_name":"見積書","shareable":true,"fields":[{"key":"QuotationNo","label":"見積番号","type":"string"},{"key":"TotalAmount","label":"合計金額","type":"number"},{"key":"IssueDate","label":"発行日","type":"date"}]}'
```

種別ごとの項目は[data-model/document-type-configs.md](../data-model/document-type-configs.md)を参照。

## 3. ユーザー追加（Viewer利用者）

```bash
KC_NEW_USER_PASSWORD='<初期パスワード>' ./scripts/tenant.sh add-user <tenant_id> <username> <email>
```

ユーザーは、属性`tenant_id=<tenant_id>`を付けて作る。1ユーザーは1テナントにだけ所属する。初期パスワードは一時パスワードで、初回ログイン時に変更を強制する。既存のユーザー名を指定した場合と、テナントが未作成（`create`未実行）の場合は、エラー終了する。

## 4. 無効化・再有効化

無効化と再有効化は、それぞれ次のコマンドで行う。

```bash
./scripts/tenant.sh disable <tenant_id>
```

```bash
./scripts/tenant.sh enable <tenant_id>
```

どちらのコマンドも、クライアント`factone-integration-<tenant_id>`と、属性`tenant_id=<tenant_id>`を持つ全ユーザーの`enabled`を切り替える。文書・Blob・文書種別設定は削除しない。物理削除は運用判断が必要なため対象外とする。

閲覧者はテナントの認証と無関係なため、閲覧URLは失効しない。閲覧URLを止める場合は、文書ごとに一括失効API`POST /api/v1/documents/{document_id}/view-urls/revoke-all`を呼ぶ。

## 動作確認（作成から無効化まで）

1. `create`でクライアントを作り、client credentialsでトークンを取って`tenant_id`クレームを確認する。
2. 2節の手順で文書種別を1つ登録し、`GET /api/v1/config/document-types`に出ることを確認する。
3. `POST /api/v1/documents`で文書を登録し、`tenant_id`が応答に入ることを確認する。
4. `disable`後にトークン取得が401になることを確認する。
5. `enable`で戻す。

## トラブルシュート

| 症状 | 確認・対処 |
| --- | --- |
| `エラー: クライアント ... が見つかりません` | `create`前に`disable` / `enable`を呼んでいる。または、`KC_SERVER`の接続先が違う。 |
| `kcadm`の`HTTP 401` | 管理者資格情報が違う。Azureは、`deploy-apps.sh`実行時のパスワードを使う。 |
| 作ったユーザーでログインできるのにAPIが403 `tenant-unresolved`を返す | 使っているKeycloakデータのrealmに、`tenant_id`属性・マッパーが無い。[local-stack.md](local-stack.md)の初期化を行う。Azureは、[deploy.md](deploy.md)のrealm再インポートを行う。 |
