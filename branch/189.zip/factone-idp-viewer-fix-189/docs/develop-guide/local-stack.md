# ローカル開発スタック起動手順

ローカル開発で使うKeycloakとPostgreSQLを、コンテナで起動する手順。

## 前提条件

[wsl-setup.md](wsl-setup.md)の環境構築（WSL2+Ubuntu 24.04、プロキシ設定、Podman導入）が完了していること。

## 初回セットアップ

リポジトリルートで環境変数ファイルを作成する。

```bash
cp .env.example .env
```

`.env`の値のうち`changeme-`で始まるものを、ローカル用の任意の値に書き換える。`.env`はGitの管理対象外。

## 起動

```bash
podman compose up -d
```

コンテナは次の順に起動する。

1. PostgreSQLが起動する。
2. PostgreSQLのヘルスチェック通過後に、Keycloakが起動する。

初回起動時は、Keycloak用DB・ユーザーの作成（`scripts/local-stack/init-keycloak-db.sh`）と、realm定義の投入が自動で実行される。realm定義は`keycloak/realm/factone.json`を`--import-realm`で投入する。

## 接続先

| サービス | URL / 接続先 | 認証情報 |
| --- | --- | --- |
| Keycloak管理コンソール | http://localhost:8080 | `.env`の`KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD` |
| PostgreSQL（アプリ用DB） | localhost:5432 / DB名`factone` | `.env`の`POSTGRES_USER` / `POSTGRES_PASSWORD` |
| PostgreSQL（Keycloak用DB） | localhost:5432 / DB名`keycloak` | `.env`の`KEYCLOAK_DB_USER` / `KEYCLOAK_DB_PASSWORD` |

## 停止

```bash
podman compose down
```

データ（PostgreSQLボリューム）は保持される。

## 初期化（データ削除）

realm定義の変更を反映したいときや環境を作り直したいときは、ボリュームごと削除して再起動する。

> **警告:** 以下のコマンドはローカルPostgreSQLの全データ（アプリ用DB・Keycloak用DBの両方）を削除する。取り消しはできない。

```bash
podman compose down -v
```

その後、`podman compose up -d`で再作成される。

## トラブルシュート

| 症状 | 確認・対処 |
| --- | --- |
| Keycloakが起動しない | `podman compose logs keycloak`を確認する。DB接続エラーのときは、PostgreSQLのヘルスチェック状態を`podman compose ps`で確認する。 |
| realm定義の変更が反映されない | 既存のrealmがあると、`--import-realm`はスキップされる。上記「初期化」を実施する。 |
| ログインできるのにAPIが403 `tenant-unresolved`を返す | 使っているKeycloakデータのrealmに、`tenant_id`属性・マッパーが無い。上記「初期化」を実施してrealmを再投入する。 |
| `.env`の変更が反映されない | コンテナの再作成が必要。`podman compose up -d --force-recreate`を実行する。ただし、DB系の資格情報は初回起動時にデータボリュームへ焼き込まれるため、変更するときは初期化が必要。 |
