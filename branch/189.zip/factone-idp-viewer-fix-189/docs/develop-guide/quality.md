# 品質ゲート

lint・format・型検査はpre-commitに一元化している。コミット時に自動実行されるほか、手動で全体実行もできる。

## 対象ツール

API（`api/`）には、ruff（lint・format）とmypy（型検査・strict）を使う。Viewer（`viewer/`）には、eslint（lint）とprettier（format）を使う。

シェルスクリプト（`*.sh`）には、実行権限チェック（`scripts/check-script-permissions.sh`）に加えて、shellcheck（構文・落とし穴の静的検査）を使う。実行権限チェックは、git上のモードが`100755`でないとコミットを拒否する。新規スクリプトは`chmod 755`してからコミットする。

設定は、ruffとmypyが`api/pyproject.toml`、eslintが`viewer/eslint.config.ts`、prettierが`viewer/.prettierrc.json`にある。

## セットアップ（開発者ごとに1回）

前提として、uvとNode.jsがインストール済みであること（[api.md](api.md)・[viewer.md](viewer.md)を参照）。

```bash
uv tool install pre-commit
```

```bash
cd /path/to/factone-idp-viewer
pre-commit install
```

以降、`git commit`のたびに変更ファイルへ自動でチェックが走る。

## 手動実行

全ファイルを対象にチェックする場合は、次のコマンドを使う。

```bash
pre-commit run --all-files
```

将来CIを導入する際も、このコマンドを同一の入口として使う。

## テスト

テストはpre-commitに含めない。コミットごとに実行するのは過剰なためである。APIのテストは、次のコマンドで実行する。

```bash
cd api && uv run pytest
```

Viewerのテストは、次のコマンドで実行する。

```bash
cd viewer && npm run test
```

## トラブルシュート

`mypy`や`eslint`のフックが失敗するときは、依存が未同期の可能性がある。`cd api && uv sync`・`cd viewer && npm install`を実行する。

フックはLinux（WSL2）のシェル上で、`uv`・`npm`がPATHにあることを前提とする。
