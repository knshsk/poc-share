# デプロイ手順

デプロイ手順の正は`scripts/`のスクリプト。本ドキュメントは前提条件・使い方・トラブルシュートだけを記載する。

## コアインフラ

### 前提条件

Azure CLI（`az`）がインストール済みで、対象サブスクリプションへ`az login`済みであること。また、サブスクリプションに対して、リソースグループの作成とデプロイの権限があること。

### 使い方

```bash
FACTONE_POSTGRES_ADMIN_PASSWORD='<管理者パスワード>' ./scripts/deploy-infra.sh
```

スクリプトの引数は次のとおり。

| 引数 | 内容 | 既定 |
| --- | --- | --- |
| 第1引数 | リソースグループ名 | `factone-poc-rg` |
| 第2引数 | リージョン | `japaneast` |

作成されるリソースは次のとおり。

| リソース | 内容 |
| --- | --- |
| Document Intelligence | S0 |
| Blob Storage | `documents`コンテナ |
| PostgreSQL Flexible Server | B1ms。DB`factone`と`keycloak` |
| Key Vault | 管理者パスワードを`postgres-admin-password`シークレットとして格納する |
| Container Registry | Basic。`build-images.sh`のビルド先 |
| Container Apps Environment | Log Analyticsワークスペースを伴う |
| ユーザー割当Managed ID | API用とKeycloak用の2つ |
| ロール割当 | API用IDにBlob・DI・Key Vault・ACRへのアクセス権、Keycloak用IDにACRのpull権限 |

APIとKeycloakのContainer Appsは、ここでは作らない。

### トラブルシュート

| 症状 | 確認・対処 |
| --- | --- |
| `FACTONE_POSTGRES_ADMIN_PASSWORD`未設定エラー | 環境変数を設定して再実行する。PostgreSQLのパスワードポリシーは、8文字以上で英大小数字を含む。 |
| 未ログインエラー | `az login`後に再実行する。 |
| 名前衝突エラー | リソース名にはリソースグループ由来の一意サフィックスが付くため、通常は発生しない。別のリソースグループ名を指定すると、別の一意名で作成される。 |

## アプリ層（Container Apps）

コアインフラの構築後に、次の順で実行する。

### 1. イメージビルド（ACRクラウドビルド）

```bash
./scripts/build-images.sh
```

このスクリプトは、`api/Containerfile`と`keycloak/Containerfile`をビルドする。`api/Containerfile`はマルチステージで、viewerをビルドしてからPython実行イメージへ同梱する。`keycloak/Containerfile`は、公式イメージにrealm定義を焼き込む。

スクリプトの引数は次のとおり。

| 引数 | 内容 | 既定 |
| --- | --- | --- |
| 第1引数 | リソースグループ名 | `factone-poc-rg` |
| 第2引数 | タグ | `latest` |

### 2. アプリデプロイ

```bash
FACTONE_POSTGRES_ADMIN_PASSWORD='<DB管理者パスワード>' FACTONE_KEYCLOAK_ADMIN_PASSWORD='<Keycloak管理者パスワード>' ./scripts/deploy-apps.sh
```

スクリプトの引数は次のとおり。タグには、`build-images.sh`でビルドしたイメージのタグを指定する。

| 引数 | 内容 | 既定 |
| --- | --- | --- |
| 第1引数 | リソースグループ名 | `factone-poc-rg` |
| 第2引数 | タグ | `latest` |

APIとKeycloakのContainer Appsを作成する。APIはフロントを同居配信し、ユーザー割当Managed IDでBlob・DI・Key Vault・ACRへアクセスする。Keycloakは、共用のPostgreSQL内の別DBを使う。出力にAPI・KeycloakのFQDNが表示される。

### デプロイ後の手動設定

#### Keycloakシークレット類の設定

realm定義JSONはシークレットを含めない運用のため、インポート直後は、テストユーザー（testuser）のパスワードと、M2M連携クライアント（factone-integration）のクライアントシークレットが未設定になっている。ローカルの`apply-keycloak-secrets.sh`に相当する操作を、コンテナ内の`kcadm`で実施する。realmを再インポートした場合も、再実施が必要になる。

1. Keycloakコンテナへ接続する。

```bash
az containerapp exec --name factone-poc-keycloak --resource-group factone-poc-rg --command bash
```

2. コンテナ内で管理者ログインする。パスワードには、`deploy-apps.sh`実行時に`FACTONE_KEYCLOAK_ADMIN_PASSWORD`へ設定した値を使う。

```bash
/opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 --realm master --user admin --password '<Keycloak管理者パスワード>'
```

3. テストユーザーのパスワードを設定する。

```bash
/opt/keycloak/bin/kcadm.sh set-password -r factone --username testuser --new-password '<テストユーザーのパスワード>'
```

4. M2M連携クライアントのシークレットを設定する。

```bash
CLIENT_ID=$(/opt/keycloak/bin/kcadm.sh get clients -r factone -q clientId=factone-integration --fields id --format csv --noquotes) && /opt/keycloak/bin/kcadm.sh update "clients/$CLIENT_ID" -r factone -s secret='<クライアントシークレット>'
```

5. SPAクライアントのリダイレクトURIへ、AzureのURLを追加する。realm定義にはローカルURLしかないためである。`<APIのFQDN>`には、`deploy-apps.sh`の出力のapi列の値を入れる。

```bash
VIEWER_ID=$(/opt/keycloak/bin/kcadm.sh get clients -r factone -q clientId=factone-viewer --fields id --format csv --noquotes) && /opt/keycloak/bin/kcadm.sh update "clients/$VIEWER_ID" -r factone -s 'redirectUris=["http://localhost:5173/*","https://<APIのFQDN>/*"]' -s 'webOrigins=["http://localhost:5173","https://<APIのFQDN>"]' -s 'attributes."post.logout.redirect.uris"=http://localhost:5173/*##https://<APIのFQDN>/*'
```

補足として、`az containerapp exec`は対話を前提とし、スクリプトによる自動化に向かない。デプロイを繰り返す運用に入る場合は、Admin REST APIを使ったスクリプト化を検討する。

稼働中のrealmに`tenant_id`属性・マッパーが無い環境では、APIが403 `tenant-unresolved`を返す。再インポートには、イメージに焼き込んだrealm定義を使う。そのため、現在のrealm定義でビルドしたイメージを、`build-images.sh`と`deploy-apps.sh`で先にデプロイしておく。`--import-realm`は既存のrealmをスキップするので、デプロイ後にKeycloak管理コンソールでrealm`factone`を削除し、Container Appを再起動して再インポートする。そのうえで、上記の手順（シークレット設定とリダイレクトURI追加）をやり直す。テナント追加で作ったクライアント・ユーザーも消えるので、`scripts/tenant.sh`で再作成する（[tenant.md](tenant.md)）。

#### ViewerのOIDC設定（イメージビルド時焼き込み）

Viteの環境変数（`VITE_OIDC_AUTHORITY`等）は、ビルド時にバンドルへ焼き込まれる。`build-images.sh`がContainer Apps EnvironmentからKeycloakのFQDNを解決し、ビルド引数として渡す。そのため、**コアインフラのデプロイ後にイメージをビルド**する。コアインフラより先に実行すると、ACRが見つからずエラー終了する。Container Apps Environmentが見つからないときは、警告を出したうえでローカルURL既定値で焼き込む。

#### 既知の制約

realm定義の恒久的なAzure URL対応は、環境URL確定後のrealm JSON更新またはスクリプト化で整理する。この対応は、上記の手順5の解消にあたる。

### リソース削除

検証後にリソースを削除する場合は、リソースグループごと削除する。

```bash
az group delete --name factone-poc-rg
```

**再デプロイ時の注意:** Key VaultとDocument Intelligenceは、削除後もソフトデリート状態で名前が90日間予約される。リソース名はリソースグループ名由来の一意サフィックスを含むため、同名のリソースグループへ再デプロイすると名前が衝突する。再デプロイ前にパージする。

```bash
az keyvault purge --name <Key Vault名>
```

```bash
az cognitiveservices account purge --name <DI名> --resource-group <リソースグループ名> --location japaneast
```

`japaneast`は`deploy-infra.sh`の既定のリージョン。第2引数で別のリージョンを指定してデプロイした場合は、そのリージョンを`--location`に指定する。

別のリソースグループ名でデプロイし直す場合は、サフィックスが変わるため、パージは不要になる。

### ネットワーク隔離

ネットワーク隔離（VNet+Private Endpoint）はPoCでは行わない。本番化時にモジュール単位で後付けする（ADR-0007）。
