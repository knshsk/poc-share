# 閲覧・DLイベント（view_events）

閲覧URL経由の閲覧・ダウンロードの記録。追記型で、更新・削除はしない。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | |
| document_pk | uuid | NOT NULL・FK(documents.id) | 対象文書（内部ID）。**案件IDは保持しない**。案件IDは外部連携側が文書IDから解決する |
| view_token_id | uuid | NOT NULL・FK(view_tokens) | どの閲覧URL経由か。発行台帳と紐付ける |
| event_type | varchar(20) | NOT NULL・CHECK | `view`（文書を開いた）/ `download`（原本DL）/ `page_view`（ページ表示） |
| occurred_at | timestamptz | NOT NULL | 発生日時（配信時にサーバで記録） |
| client_ip | varchar(64) | NOT NULL | 端末情報 |
| user_agent | varchar(512) | NOT NULL | 端末情報 |
| page | integer | NULL・CHECK | 表示されたページ番号（1始まり）。`page_view`のみ値を持ち、`view` / `download`はNULL |

UNIQUE(document_pk, occurred_at, event_type)は、冪等キー（文書の内部IDとイベント発生日時と種別）のDB制約である。衝突したときは挿入をスキップする。配信は成功させ、記録の重複だけを防ぐ。

`page`はキーに含めない。NULLを含む複合UNIQUEにすると、`view` / `download`の冪等性が保てなくなるためである。同一文書・同一マイクロ秒で`page_view`が衝突することは、事実上発生しない。

CHECK ck_view_events_page（`(event_type = 'page_view') = (page IS NOT NULL)`）は、種別と`page`列の整合をDB制約で担保する。

## 記録ポイント

APIプロキシ配信が唯一の関門であるという決定に基づき、公開閲覧経路の配信が成功したときにのみ記録する。

| 経路 | イベント |
| --- | --- |
| `GET /view/{token}/pages`成功 | view（文書を開いた=1閲覧） |
| `GET /view/{token}/pages/{page}/image`成功 | page_view（`page`付き）。Viewerは表示領域に入ったページだけ画像を取得するため、取得の成功をページ表示とみなす（[ADR-0015](../adr/0015-page-view-event.md)） |
| `GET /view/{token}/pdf`成功 | download |
| 無効トークン・存在しないページ番号のアクセス | 記録しない。無効トークンは失敗記録`view_access_failures`側に残る |
| 社内（認証済み）表示 | **記録しない**。ルート型注文書を含め、社内閲覧イベントは履歴化しない（ADR-0012） |

「ページを表示した」は、ページが表示領域に1pxでも入り、画像が取得されたことと定義する。スクロールで通過した場合や部分表示も1閲覧として数え、滞在時間は測らない。同一表示中の再表示では画像を再取得しないため、再記録されない。リロードや再訪では新たに記録される。「何ページ目まで確認したか」は、連携側が`page_view`の`max(page)`を集計して得る。

## 取得（外部連携IF-04）

`GET /api/v1/view-events?since=<日時>`（JWT必須）が、Power Automateなどの外部連携に向けた正式な契約である（[ADR-0013](../adr/0013-view-event-delta-feed.md)）。

取得方式はREST pullで、文書を横断して差分を取得する。日次バッチで、連携側が前回取得した最終の`occurred_at`を`since`に指定する。

`since`は境界を含む（`occurred_at >= since`）。境界上の重複は、DataDelivery登録の冪等キー（文書IDとイベント発生日時）を使って連携側が排除する。`since`を省略すると全件を返す。

応答では、全文書のイベントを`occurred_at`の昇順で返し、同時刻は`id`順に並べる。ページネーションはない。PoCの日次規模を前提とし、テナントはJWTで絞る。件数が増えたときはカーソル方式へ見直す。

応答項目は`id` / `document_id` / `event_type` / `occurred_at` / `client_ip` / `user_agent` / `page`。`page`は`page_view`のみ値を持ち、他は`null`になる。`view_token_id`は内部管理値のため応答に含めない。文書IDから案件IDへの解決は連携側の責務である。`page_view`は無条件にフィードへ含まれ、種別による除外フィルタはない。

認証には、KeycloakのM2Mクライアント（client credentials）で取得したアクセストークンを利用できる。`since`が日時として解釈できない場合は422、イベントが未発生の場合は空リストを返す。

文書ID単位の個別照会には、`GET /api/v1/documents/{document_id}/events`を使う。応答項目は、`document_id`を除いて上記と同じ。
