# 全体設計ドキュメント

モジュールを横断する全体像（L1）と、モジュールごとの構成（L2）。

## 文書一覧

| 文書 | 内容 |
| --- | --- |
| [overview.md](overview.md) | L1。システム文脈・コンポーネント構成・主要ユースケース・データの流れ |
| [api.md](api.md) | L2。APIのレイヤ構成・リソース・IDP実行の内部フロー |
| [viewer.md](viewer.md) | L2。画面・コンポーネント・状態管理 |
| [auth.md](auth.md) | L2。認証経路・JWT検証・Keycloak realm |
| [view-url.md](view-url.md) | L2。閲覧URLのライフサイクル・公開閲覧・イベント |

## 記述方針

L2文書は「役割 / 構成 / 主要処理の流れ / 外部依存・設定 / 関連ドキュメント」の5節で書く。

図はMermaidで描き、構成図は`flowchart`、処理の流れは`sequenceDiagram`を使う。図と本文で同じ情報を二重に書かない。

テナント固有の外部システム名は書かず、外部は役割名で表す。

Keycloakは単一realmで、テナントは`tenant_id`クレームで表す（[ADR-0020](../adr/0020-single-realm-tenant-claim.md)）。仕様は[auth.md](auth.md)に書く。
