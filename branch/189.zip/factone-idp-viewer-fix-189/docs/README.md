# docs

設計・開発に関するドキュメント。初めて読む場合は次の順に読む。

## 読み順

リポジトリを初めて見るなら、全体像（L1）から読み始める。

| 段階 | 文書 | 内容 |
| --- | --- | --- |
| PoC要件（L0） | [business/](business/README.md)、[requirements/](requirements/README.md) | 本PoCでテナントがどう使うか。業務フロー・機能要件・対象外事項 |
| 全体像（L1） | [architecture/overview.md](architecture/overview.md) | マルチテナントSaaSとしてのIDP/Viewerの構成と主要ユースケース |
| モジュール構成（L2） | [architecture/](architecture/README.md)（API・Viewer・認証・閲覧URL）、[azure/](azure/README.md) | 各モジュールの構成・主要処理・外部依存 |
| 詳細仕様（L3） | [data-model/](data-model/README.md)、[api/](api/README.md)、[viewer/](viewer/README.md) | テーブル定義・API契約・画面部品 |

層を横断する文書は次のとおり。

| 文書 | 内容 |
| --- | --- |
| [adr/](adr/README.md) | 決定の経緯・却下案。設計文書には確定事項のみを書き、経緯はここに記録する |
| [develop-guide/](develop-guide/README.md) | 環境構築・起動・テスト・デプロイの手順 |

L0〜L3は抽象度の段階を表す。L0は「このPoCで何をするか」、L1は「システム全体が何でできているか」を扱う。L2は「各モジュールがどう動くか」、L3は「個々の定義と契約」を扱う。

L1/L2には、PoCの題材であるテナント固有の外部システム名を書かない。外部の主体はテナント利用者・外部連携システム・閲覧者という役割名で表し、固有の利用形態はL0に閉じる。KeycloakやAzure Document Intelligenceなど、本システムの構成要素である製品名は書く。

## ディレクトリ一覧

| ディレクトリ | 層 | 内容 |
| --- | --- | --- |
| `business/` | L0 | 業務フロー・業務要件・PoC対象外事項 |
| `requirements/` | L0 | IDP/Viewerの機能要件（業務ドキュメントからの導出） |
| `architecture/` | L1/L2 | 全体像と、モジュールを横断する構成（API・Viewer・認証・閲覧URL） |
| `azure/` | L2 | Azure上のリソース構成と各サービスの設計 |
| `data-model/` | L3 | テーブル定義とリレーション |
| `api/` | L3 | API契約（OpenAPIエクスポート・バージョニング・エラー応答） |
| `viewer/` | L3 | Viewerの画面設計 |
| `adr/` | 横断 | Architecture Decision Record |
| `develop-guide/` | 横断 | 開発者向け手順 |
