---
status: accepted
date: 2026-09-17
---

# ViewerをRoot階層 + Passive View + Chain of Responsibility + ステートマシンMediatorで構成する

## 背景

Viewerは10コンポーネントと4つのPiniaストアから成り、API呼出（17箇所）・状態フラグ（25個）・非同期のレース裁定が6コンポーネントに散在していた。`WorkPanel`は、一覧・詳細取得・キャッシュ・未保存ガード・`beforeunload`を受け持つ事実上のコントローラになっていた。

木を横断する連携は、ストア経由で暗黙化していた。`draft.guard`を発火するのは`AppHeader`と`WorkPanel`で、解決ダイアログは`WorkPanel`にあった。`highlight`の連番付き要求は、3コンポーネントが`watch`していた。

画面遷移では、`App.vue`のパス分岐と`document.documentId / loadedDocumentId`の二相が、暗黙のステートマシンを成していた。どの状態でどの操作を受けるかを、コードから読み取れなかった。

## 決定

全コンポーネントを、`Root.vue`を頂点とする1本の階層に置く（`Root → AppHeader / LoginView / PublicView / DocumentView → …`）。

各コンポーネントは、MVPのPassive Viewとする。入力は自分用のViewModel型1つを`vm` propで受け、親が部分を子へ渡す。出力は`useBubble()`が返す`bubble(event)`だけとする。描画だけに関わる状態（ズーム・スクロール位置・区分の開閉・送信前のフォーム入力値）はViewが持つ。API呼出・`URL.createObjectURL`・clipboard・`history`・`window`イベントは、Viewに持たせない。

操作は、Chain of Responsibilityで階層を上へバブリングさせる。`useBubble(handle?)`は、`provide/inject`で直近の祖先の`bubble`を受け取る。自ノードの`handle`が`true`を返せばそこで停止し、それ以外は親へ委譲する。`Root`は、Mediatorの`dispatch`を鎖の終点としてprovideする。

Mediator（`viewer/src/mediator/`）は、ステートマシンとして振る舞う。12の状態（`booting / login / callback / public / start / registering / loadingDocument / documentError / document / executing / saving / confirmDiscard`）と、イベント型を主キーにした遷移表`{ in: State[], run }`を持つ。`in`に現状態が無いイベントは、何もせずに捨てる（裁定）。

API応答とOIDCの完了は、内部の完了イベントとしてMediatorが自分へdispatchする。状態遷移は、完了イベントの側で同期的に行う。古い応答は2段で捨てる。1段目は状態が`in`の外にある場合、2段目はスコープ（`documentId` / `token` / `runId`）が一致しない場合である。確認ダイアログ（`confirmDiscard`）の表示中も、APIの完了イベントは受ける（`SETTLING`）。

ViewModelはスライスごとの`computed`で組み、変化した部分だけ参照が変わるようにする。これにより、draftの入力でキャンバスは再描画されない。

Piniaは撤去する。4つのストアは、Mediatorのモデルと`auth/oidc.ts`（`oidc-client-ts`のラッパ）に吸収する。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| Piniaストアを残してMediatorを足す | `draft.guard` / `highlight`をイベント化したストアが残り、Viewからストアを読む経路とvmの二重経路になる |
| emitsの明示中継 | 鎖がテンプレートに見える利点はあるが、階層数 × 子数の再emitが要る |
| DOM `CustomEvent`のバブリング | Vuetifyのdialog / menu / snackbarはbodyへTeleportされ、DOMの祖先関係が切れるため、Rootに届かない |
| XState等のステートマシンライブラリ | 12状態・49イベントの規模に対して、依存の追加が過剰。イベント主キーの表と`in`ガードで足りる |
| readonlyのモデルをinjectしてViewが読む | 中継は要らなくなるが、Viewがモデルを直接読むSupervising Controllerになり、Passive Viewから外れる |
| 単一PiniaストアをMediatorにする | devtoolsで状態を追えるが、Viewから`useMediator()`を呼べてしまい、Passive Viewを構造的に強制できない |

## 影響

Viewのテストは、`vm`を与えてDOMを検証し、操作はprovideしたスパイへの`bubble`呼出で検証する。挙動（レース・失敗・未保存ガード）のテストは、Mediatorの単体テスト（`tests/mediator-*.test.ts`）に集約する。

裁定によって、従来と挙動が変わる点がある。`executing` / `saving`中の履歴選択・文書切替・再実行は無視する。従来はボタンを無効化するだけで、履歴のクリックとヘッダからの切替は通っていた。`beforeunload`の警告は`Root`が常時登録し、`vm.dirty`で判定する。ヘッダで表示中と同じ文書IDを再入力すると、再取得する。loadingDocument / registering中のヘッダからの文書切替は無視する。旧実装は、取得中でも切り替えていた。

新しい操作を足すときは、`mediator/events.ts`にイベントを追加し、`handlers/`に`{ in, run }`を書く。必要なら`vm.ts`に表示項目を足し、それからViewを書く。ViewにはAPI呼出やストア参照を書かない。

Vue devtoolsでストアの状態を見ることはできなくなる。必要なら、`Root`の`vm`をdevtoolsのコンポーネントstateから見る。
