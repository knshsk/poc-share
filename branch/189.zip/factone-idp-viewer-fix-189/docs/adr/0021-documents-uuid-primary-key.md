---
status: accepted
date: 2026-09-15
---

# documentsの主キーを内部UUIDにし(tenant_id, document_id)を一意にする

## 背景

`documents.document_id`は呼出側が採番する文字列で、単独の主キーだった。テナントごとに採番体系が異なるため、複数テナントを収容すると、同じ`document_id`が別のテナントから登録されうる。子テーブル（`view_tokens` / `view_events` / `idp_runs`）は、`document_id`への外部キーを持っていた。

## 決定

`documents`に内部UUIDの主キー`id`を追加し、`(tenant_id, document_id)`をUNIQUE（`uq_documents_tenant_document`）にする。子テーブルの外部キーは`document_pk UUID → documents.id`に張り替え、`view_events`の冪等キーも`(document_pk, occurred_at, event_type)`にする。APIのURLは引き続き`document_id`を使う。テナントはJWTから取り、`(tenant_id, document_id)`で文書を引く。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| 複合主キー`(tenant_id, document_id)` | 子テーブル3本の外部キーが複合になり、結合・挿入の記述がすべて2列になる |
| 文書IDをテナント跨ぎで全体一意にする | 呼出側に採番の制約を押し付ける。テナント間で採番体系を揃えられない |

## 影響

応答の`document_id`は、relationship経由（`run.document.document_id`等）で返し、応答の形は変えない。子テーブルには`tenant_id`を持たせず、テナントによる絞り込みは`documents`とのJOINで行う。

マイグレーションのdowngradeは、テナント間で同じ`document_id`が存在すると、旧主キーを再作成できずに失敗する。
