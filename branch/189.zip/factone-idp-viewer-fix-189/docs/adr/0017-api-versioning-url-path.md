---
status: accepted
date: 2026-09-09
---

# APIバージョンはURLパス（/api/v1）で表し、メジャーのみを破壊的変更時に上げる

## 背景

APIにはバージョンの概念がなく、全ルートが`/api/**`に直接置かれていた。APIは外部呼出元（Power Automate）とViewerが依存する契約であり、将来の破壊的変更を既存利用者に影響なく行う余地が必要だった。現時点で`/api/**`を呼ぶ外部利用者は存在せず、URL変更のコストはゼロである。

## 決定

認証ありAPIを`/api/v1/**`に配置し、バージョンはURLパスで表す。顧客向け閲覧URL`/view/{token}/**`と、ヘルスチェック`/health`には版を付けない。閲覧URLはメール等で顧客に渡すブラウザURLで、不透明トークンURLが永続的に安定していることに価値がある（ADR-0011）。閲覧URLはAPI契約ではない。

版はメジャーのみ（`v1`, `v2`）とし、破壊的変更を行うときに限り上げる。破壊的変更とは、レスポンスのフィールドの削除・改名・型変更・意味変更、リクエストの必須化、エンドポイントの削除・パス変更を指す。追加的変更は同一版内で行う。追加的変更とは、フィールド・エンドポイント・エラーcode・任意パラメータの追加を指す。

破壊的変更時は`/api/v2/**`を並行公開し、`/api/v1/**`の廃止期限を`docs/api/README.md`に明記する。`Deprecation` / `Sunset`ヘッダ等の機械可読な廃止通知は、その時点で検討する。旧`/api/**`への互換ルートやリダイレクトは作らない。

実装は、デコレータにフルパスをリテラルで記述する既存パターンを踏襲する。`include_router(prefix=)`や定数化は行わない。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| ヘッダ方式（`Accept: application/vnd.factone.v1+json` / `X-API-Version`） | Power Automateでは全アクションに手動でヘッダを付ける必要があり、忘れると気づかないうちに既定版へ落ちる。OpenAPIで版の差分を表現しづらく、ヘッダに依存したルーティング分岐も要る |
| クエリ方式（`?version=1`） | 省略時の挙動が曖昧で、キャッシュキーに混入する。OpenAPI上で全パスにパラメータが散在する |
| 版なし（追加的変更のみで進化し、必要時に導入） | 利用者ゼロの今なら移行コストはゼロである。後から`/api`を`/api/v1`に変えると、外部契約の変更になり高コストになる |
| 日付版（`2026-09-09`）や`v1.1` | PoC規模では版の乱立を招くだけで、得るものがない |

## 影響

Viewerと、今後接続するPower Automateは`/api/v1/**`を呼ぶ。OpenAPIのパスに版が含まれるため、契約上自明である。

v2が発生した時は、ルート定義が版ごとに重複する。重複は並行期間中のみ許容し、v1の廃止で解消する。

OpenAPIの`info.version`はアプリの版であり、契約の版ではない。契約の版はパスの`v1`のみである。SPA配信の`api/`判定とVite proxyの`/api`は、`api/v1/`を包含するため変更していない。

## 追記（2026-09-14）

外部利用者（Power Automate・WalkMe）が接続するまでは、v1内での破壊的変更を許容する。外部利用者がいない間は移行コストがゼロであり、v2を並行公開する運用コストの方が大きいためである。適用した変更は、この節の表に列挙する。最初の外部利用者が接続した時点でこの例外は失効し、本ADRの決定どおり破壊的変更はv2で行う。

| 日付 | 変更内容 | 関連ADR |
| --- | --- | --- |
| 2026-09-14 | `GET /api/v1/documents/{document_id}/idp-runs`の一覧項目から`raw_fields` / `normalized_fields` / `confidence` / `field_labels` / `field_regions` / `tables` / `pattern_matches`を除き、サマリ項目のみとした。詳細は`GET …/idp-runs/{run_id}`で取得する。 | なし |
| 2026-09-15 | 認証ありAPIでアクセストークンの`tenant_id`クレームを必須とした。クレームが欠落・不正な場合は403 `tenant-unresolved`を返す。あわせて文書IDの一意性をグローバルからテナント内に変え、`document_id`に`/` `\`を含む値と`.` `..`を422で拒否する。閲覧URLを1件失効する操作では、他テナントの管理IDを指定すると404になる。 | [ADR-0020](0020-single-realm-tenant-claim.md)、[ADR-0021](0021-documents-uuid-primary-key.md) |
| 2026-09-17 | `IdpRunResponse`の`raw_fields` / `normalized_fields` / `confidence` / `field_labels` / `field_regions`を`fields[key].{value, normalized_value, confidence}`に統合した。`fields[key].label` / `fields[key].region` / `tables[].cells[].polygon` / `corrections`は、クエリ`verbose=true`のときだけ返す。この指定はViewer向けで、既定の応答は外部連携向けとして座標を含まない。また、`tables[].cells[]`に`row_span` / `column_span`を追加した。 | [ADR-0022](0022-idp-run-response-single-schema-verbose.md) |
| 2026-10-03 | 文書登録で、`document_id`に制御文字（Unicodeの一般カテゴリCc）か双方向制御文字（Bidi_Control）を含む値を422で拒否する。原本ファイル名は、これらの文字を除いて保存する。 | [ADR-0026](0026-control-characters-in-input.md) |
| 2026-10-04 | 文書登録で、先頭が`%PDF`でもPDFとして開けないファイルを、422 `invalid-pdf`で拒否する。壊れたPDFや、閲覧パスワード付きのPDFが当たる。 | なし |
