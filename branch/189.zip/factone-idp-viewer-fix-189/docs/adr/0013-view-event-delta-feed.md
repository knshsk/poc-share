---
status: accepted
date: 2026-08-28
---

# 閲覧イベントの差分取得は横断フィード（since境界包含）で提供する

## 背景

業務フローK3-9では、Power Automateが日次バッチで閲覧ログを差分取得し、文書IDから案件IDを解決してDataDeliveryへ登録する。既存の取得IF（`GET /api/documents/{document_id}/events`）は、文書ID指定・全件返却のみだった。連携側には、対象文書IDの一覧を知る手段も、差分を指定する手段もなかった。

## 決定

文書横断の差分取得エンドポイント`GET /api/view-events?since=<日時>`を追加する（JWT必須）。

`since`は境界包含（`occurred_at >= since`）とする。境界上の重複取得は許容し、取りこぼしゼロを優先する。重複は、DataDelivery登録の冪等キー（文書IDとイベント発生日時）で連携側が排除する。

応答は`occurred_at`昇順（同時刻は`id`順）とし、`id`・`document_id`・`event_type`・`occurred_at`・`client_ip`・`user_agent`を返す。`view_token_id`は内部管理値のため含めない。

`since`省略時は全件を返す。連携側は前回取得の最終`occurred_at`を透かし（watermark）として保持し、次回の`since`に用いる。既存の文書ID単位エンドポイントは、個別照会用として存続する。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| 文書ID単位取得の維持＋連携側での文書ID一覧管理 | Power Automateが独自の状態管理（採番済み文書IDの台帳）を持つ必要があり、文書数に比例した呼出も発生する |
| カーソル／ページネーション付きフィード | PoCのイベント規模（日次・単一テナント）では過剰 |
| `since`境界排他（`>`） | 同一時刻に複数イベントが発生した場合に取りこぼす |

## 影響

境界包含のため、連携側で重複が発生しうる。重複がDataDelivery登録の冪等キーで排除される前提を、連携仕様に含める。ページネーションがないため、イベント件数が日次バッチで扱えない規模になった場合は、カーソル方式への見直しが必要になる。

応答に全文書のイベントが含まれるため、マルチテナント本実装時はテナント分離の検証が必要である（PoCでは単一テナント・`tenant_id`絞込のみ）。（2026-09-15: JWTの`tenant_id`で絞る実装とクロステナントテスト`api/tests/test_tenant_isolation.py`を追加。[ADR-0020](0020-single-realm-tenant-claim.md)）
