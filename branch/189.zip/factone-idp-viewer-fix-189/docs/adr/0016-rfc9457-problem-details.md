---
status: accepted
date: 2026-09-09
---

# APIのエラー応答をRFC 9457（Problem Details）に統一する

## 背景

APIのエラー応答は、各所で`HTTPException(status_code, detail)`を直接送出し、FastAPI既定の`{"detail": "..."}`形式で返していた。OpenAPIには422以外の4xx/5xxが記載されていなかった。外部呼出元（Power Automate等）は、エラー種別を`detail`の文字列でしか判別できなかった。外部公開契約として、エラー種別を機械判別可能にし、契約書（OpenAPI）に固定する必要があった。

## 決定

全エラー応答をRFC 9457（Problem Details for HTTP APIs）に準拠させる。`Content-Type: application/problem+json`で、`{type, title, status, detail}`を返す。

`type`は`/errors/<code>`形式の相対URIとする。codeは発生箇所ごとの固有名（例: `document-not-found`, `document-type-in-use`）で、HTTPステータス単位ではない。相対URIにするのは、ドメインに依存せず、将来同じパスで説明ページを配信できる余地を残すためである。

`title`はcodeから機械的に導出し（`document-not-found` → `Document not found`）、対応表を持たない。`detail`は発生箇所の文言で、従来の`detail`をそのまま継承する。拡張メンバは422検証エラーの`errors`（`loc` / `msg` / `type`）のみとし、`instance`は使わない。

未捕捉例外は500 `internal-error`とする。`detail`は固定文言とし、例外の内容を本文に出さない。閲覧トークンが無効な時とSPA配信外のパスは、存在を秘匿するため汎用の`not-found`を維持する。

実装にはライブラリを追加しない。`app/core/problem.py`の例外ハンドラ3本（`HTTPException` / `RequestValidationError` / `Exception`）と、`ProblemException`で実装する。OpenAPIには、ルーター／ルートの`responses=`で全4xx/5xxを`Problem`スキーマとして明記する。FastAPI既定の`HTTPValidationError`は契約から除く。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| `fastapi-problem`等のライブラリ導入 | ハンドラ3本で足りる量に依存を追加することになる。`type` URIや拡張メンバの制御も、ライブラリの流儀に縛られる |
| `HTTPException`を温存し、status → typeの自動変換のみ行う | 固有コードの方針と矛盾し、`detail`の文面でしか判別できない |
| `type`を`urn:factone:error:<code>`や`about:blank` + 拡張`code`にする | 説明ページを配信する余地がなく、RFCの意図（typeで種別を識別）からも外れる |

## 影響

外部呼出元は、`detail`の文字列ではなく`type`でエラー種別を判別する。既存の`{"detail"}`の参照は、`detail`フィールドを継承することで互換を保つ。

エラー種別を追加する際は、固有のcodeを命名し、該当ルートの`responses=`にステータスを追加してOpenAPIを再生成する。code一覧は`docs/api/README.md`で保守する。

`Content-Type`は`application/json`から`application/problem+json`に変わる。メディアタイプを厳密に判定するクライアントは、追随が必要である。422検証エラーの`errors`は`loc` / `msg` / `type`のみとし、FastAPI既定応答が含めていた`input`（送信値の反響）は返さなくなる。
