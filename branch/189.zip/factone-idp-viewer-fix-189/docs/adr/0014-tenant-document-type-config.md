---
status: accepted
date: 2026-09-01
---

# 文書種別をテナント別の設定値（document_type_configs）に移行する

## 背景

文書種別（Query Fields・閲覧URL発行可否）は、`DocumentType` enumとDBのCHECK制約、`QUERY_FIELDS`のハードコードで固定されていた。マルチテナントSaaSとしては、テナントごとに異なる文書種別を扱う必要がある。コードに埋め込む方式では、テナント別の差分を表現できない。

## 決定

文書種別を、`document_type_configs`テーブルのテナント別設定に移行する。テーブルはtenant_id + type_codeで一意とする。種別ごとに表示名・閲覧URL発行可否（`shareable`）・抽出フィールド定義（key / label / typeを持つJSONB配列）を保持し、CRUD API（`/api/config/document-types`）で管理する。

`DocumentType` enumとCHECK制約は廃止する。種別コードは自由値とし、アプリ層が設定テーブルを参照して検証する。正規化はフィールドの`type`（string / number / date）に従って行う。

ADR-0002の「注文書は閲覧URL発行禁止」という判断自体は維持する。この判断は、シードデータのデフォルト値（order_*はshareable=false）として引き継ぐ。強制の所在は、enum + CHECK制約から設定値へ移る。列名は、用途を顧客向けに限定しない`shareable`とした。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| 正規化2テーブル（document_types + document_type_fields） | フィールド単独のクエリ・参照の要件がなく、コード量だけが増える（YAGNI） |
| テナント単位の一括JSONB | 種別単位の削除保護と部分更新が、すべてアプリロジックになる。粒度が粗い |
| enumを維持し、フィールドのみ設定化する | 種別コード自体をテナントごとに変えられず、要件を満たさない |

## 影響

種別の整合性の保証は、DB制約からアプリ層の検証へ移る。アプリ層は、登録時には422、IDP実行時には409を返す。使用中の種別、つまりdocumentsに参照行がある種別の削除は、409で保護する。フィールド定義の更新は自由にできる。過去のIDP実行ログは実行時点の結果をJSONBで保持済みのため、更新の影響を受けない。

テナントの解決は、現状`settings.tenant_id`の固定のままである。リクエストからテナントを解決する仕組みを導入するときは、設定参照のスコープをそのまま利用できる。なお、2026-09-15に[ADR-0020](0020-single-realm-tenant-claim.md)でJWTクレームによる解決へ移行済みである。

設定CRUDの認可は、既存の認証（CurrentUser）のみとする。ロール別の制御が必要になった時点で見直す。
