---
status: accepted
date: 2026-09-17
---

# IDP実行結果の応答を単一スキーマとし、Viewer向け付加情報は`verbose`パラメータで追加する

## 背景

IDP実行結果（`IdpRunResponse`）は、外部連携システム（Power Automate・CRM等）とViewerの両方が取得する。Viewerは、キャンバスのハイライトに読取領域とセル座標を、修正UIに人手差分（`corrections`）を使う。これらは外部システムには不要で、応答を肥大させる。

また、項目値が`raw_fields` / `normalized_fields` / `confidence` / `field_labels` / `field_regions`の並列dictに分かれており、同じキーを何度も引く必要があった。外部連携システムは未接続で、v1内の破壊的変更を許容できる期間にある（ADR-0017）。

## 決定

応答は単一スキーマとし、項目値は`fields[key] = {value, normalized_value, confidence}`に統合する。

`IdpRunResponse`を返す4エンドポイント（実行・最新・詳細・修正）に、クエリ`verbose`（既定`false`）を付ける。`verbose=true`は同じスキーマにキーを追加するだけで、値の形は変えない。追加するキーは`fields[key].label` / `fields[key].region` / `tables[].cells[].polygon` / `corrections`である。verboseでない応答では、これらのキー自体を省略する。

`pattern_matches`は座標を含まず小さいため、現行の形（`label` / `regex` / `values`）を維持する。セルの`content`は、修正リクエストと同じ名前を保つ。

DB列は変更せず、応答の組立で変換する。テーブルセルについては、`row_span` / `column_span`を新たに抽出する。抽出を始める前に保存された行は、応答で1に補完する。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| 外部向け・Viewer向けの別エンドポイント | 契約が2本になり、修正APIなど詳細を返す経路ごとに対を作る必要がある。同期のコストが増える |
| `include=regions,corrections`のような項目選択 | 必要な区分は「外部向け」「Viewer向け」の2種のみで、選択肢の組合せの分だけテストと文書が過剰になる。必要になった時点で`verbose`から拡張できる |
| `Accept`ヘッダによる表現切替 | クライアント（openapi-fetch）とOpenAPI生成での扱いが煩雑で、ブラウザから確認しづらい |
| 応答の形状を変えず、座標だけ省く | 並列dictの読みにくさが残る。破壊的変更を許容できる今しか統合の機会がないため、統合を選んだ |

## 影響

本変更はv1内の破壊的変更であり、[ADR-0017](0017-api-versioning-url-path.md)の追記に記録している。Viewerは同じPRで追従する。

Viewerは、詳細取得・実行・修正の応答を`verbose=true`で受ける必要がある。付け忘れると、ハイライトと修正済みマークが出ない。型の上ではoptionalのため、付け忘れを検知できない。

verboseでない時のキーの省略は、`response_model_exclude_unset`に依存する。応答の組立でverbose専用キーを既定値に頼ると、キーが省略されてしまう。そのため、明示的にセットする規約を`_to_response`に置く。

`row_span` / `column_span`のViewer側の描画（結合セルの矩形拡張・グリッドの結合表示）は未対応である。必要になった時点で対応する。
