---
status: accepted
date: 2026-08-25
---

# ブラウザ側認証はSPA+OIDC/PKCEとしBFFを設けない

## 背景

Keycloak採用（ADR-0006）を受け、ブラウザ側の認証実装方式を選ぶ必要が生じた。候補は、トークンをブラウザに渡すSPA直接方式と、トークンをサーバ側に隠すBFF（Backend for Frontend）方式である。

## 決定

Vueアプリが`oidc-client-ts`でKeycloakと認可コードフロー+PKCEを実行する、SPA方式とする。アクセストークンはメモリに保持し、短寿命+refresh token rotationとする。API呼出は`Authorization: Bearer`ヘッダで行う。FastAPIはJWT検証のみを担い、ステートレスを維持する。

採用理由は、実装量が最小であることと、全経路（ブラウザ・Power Automate）がJWT検証一本で通って認証モデルが単純になることである。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| BFF自作 | トークン非露出（XSS耐性）では優るが、セッション管理・CSRF対策・トークン更新の自作コストが大きい。また、クッキー系とJWT系の認証が二本立てとなる。これは、フロント配信でSWA Standard案を却下したのと同じ構図（認証経路の二重化）である |

## 影響

XSS耐性はBFF方式に劣る。本番化時の強化オプションとして、BFF導入を再評価する。トークン処理ライブラリの選定は、ADR-0001（PyJWT・oidc-client-ts）を参照する。
