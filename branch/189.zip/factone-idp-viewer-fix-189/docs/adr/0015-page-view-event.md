---
status: accepted
date: 2026-09-08
---

# ページ単位の閲覧イベント（page_view）を画像取得時に記録する

## 背景

閲覧ログ（view_events）は、閲覧用URL経由で文書を開いた事実（`view`）と原本DL（`download`）のみを記録していた。取引先に見積PDFを開示した際に「何ページ目まで確認したか」を把握したいという業務ニーズがあった。そのため、ページ単位の閲覧事実を記録し、外部へ提供する必要が生じた。

従来のViewerは、全ページの画像をマウント時に一括取得していた。そのため、サーバ側の画像リクエストは「実際に表示されたページ」を表しておらず、Viewer側を変更しなければ判定できなかった。

## 決定

ページ単位の閲覧イベント`page_view`を新設し、`view_events`に`page`列（integer NULL、1始まり）を追加する。`view` / `download`は`page`を持たない。種別と列の整合は、CHECK制約`(event_type = 'page_view') = (page IS NOT NULL)`で担保する。

Viewerの`PageSvg`は、IntersectionObserverによる遅延読込に変更する。表示領域に1pxでも入った時に、1回だけ画像を取得する。`GET /view/{token}/pages/{page}/image`の配信に成功した時に、`page_view`を記録する。専用の可視通知エンドポイントは設けない。

冪等キー`UNIQUE(document_id, occurred_at, event_type)`は変更しない。NULLを含む複合UNIQUEは`view` / `download`の冪等性を壊すため、`page`をキーに含めない。同一文書・同一マイクロ秒での`page_view`の衝突は事実上発生しない。衝突した時は、既存どおり挿入をスキップする。

外部連携IF-04（`/api/view-events`、`/api/documents/{id}/events`）の応答には`page: integer | null`を追加し、`page_view`を無条件に含める。除外フィルタは設けない。

社内（認証済み）表示を記録しない方針（ADR-0012）は変更しない。`PageSvg`は社内表示と共用のため、社内側も遅延読込になるが、記録の対象にはならない。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| `view`行に到達最大ページ（max_page）を後から更新する | 追記型ログの原則（ADR-0005）に反する |
| セッション終了時に到達最大ページを1件だけ記録する | 離脱時のbeacon送信の信頼性に依存し、タブを閉じた場合に取りこぼす |
| 可視判定beacon（`POST /view/{token}/pages/{page}/viewed`）を新設する | 画像取得と記録を分離できるが、エンドポイント・型・テストが1組増え、画像の一括取得も残る |

## 影響

「ページを表示した」は「表示領域に入り、画像が取得された」の近似である。スクロールで通過しただけの場合や部分的な表示も、1閲覧として数える。滞在時間は測らない。精度が必要になった場合は、可視時間のしきい値を持つbeacon方式へ見直す。

Power Automate / DataDeliveryは、未知の`event_type=page_view`と`page`項目を扱う必要がある。「何ページ目まで確認したか」は、DataDelivery側で`max(page)`を集計して得る。DataDelivery側の冪等キー「文書IDと発生日時」は、`page_view`でも実用上一意である（マイクロ秒精度）。厳密にする場合は、連携側のキーに`event_type`と`page`を加える。

`page_view`によって、イベント件数は閲覧ページ数に比例して増える。日次バッチで扱えない規模になった場合は、ADR-0013の見直し条件（カーソル方式）が早まる。
