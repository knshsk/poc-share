---
status: accepted
date: 2026-08-25
---

# IdPにKeycloakを採用しContainer Apps相乗りでホストする

## 背景

PoCの認証方式として、フロントエンド・APIの認証を担うIdPの選定と配置が必要になった。横展開時は社内展開済みのSaaS環境へ相乗りする可能性が高く、同環境の認証基盤はKeycloakを採用している。

## 決定

IdPとしてKeycloak（自前ホスト・公式イメージ）を採用し、認証方式はOpenID Connectとする。ホスト先はContainer Apps相乗りとし、DBはPostgreSQL共用サーバ内の別DBとする。

realm定義JSONは`keycloak/`でconfig-as-codeとして管理し、`--import-realm`でローカル・Azure両方へ同一定義を投入する。realm JSONにはシークレットを含めない。Keycloakのrealmインポートは環境変数置換を行わないため、シークレット類は起動後に`kcadm`を使うスクリプトで設定する。値の供給元は、ローカルが`.env`、AzureがKey Vault参照である。

採用理由は次のとおり。横展開先の社内SaaS環境がKeycloakを採用済みのため、PoCから合わせることで移行摩擦を排除できる。また、社内Entra統制に依存しないテナント模擬の自由度と、IdP中立性を確保できる。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| Microsoft Entra ID（社内テナント利用） | 社内統制に依存し、テナント模擬の自由度がない。顧客横展開時のIdP中立性も損なわれる |
| 専用インスタンスでのKeycloakホスト | PoC規模では相乗り構成（Container Apps+共用PostgreSQL）で十分であり、コストのみ増える |

## 影響

PoC期間限定の運用とし、Keycloak自体の本番水準の可用性・堅牢化は対象外とする。

realm設計（realm分離 vs 単一realm+テナントクレーム）は、相乗り先SaaS環境の構成を確認した後に確定する。それまでは`keycloak/README.md`で暫定運用を記す（2026-09-15: 単一realm+`tenant_id`クレームで確定。[ADR-0020](0020-single-realm-tenant-claim.md)）。

テナント識別・ロール・文書アクセス認可の詳細は未確定（2026-09-15: テナント識別はADR-0020で確定。ロール・文書アクセス認可は未確定のまま）。
