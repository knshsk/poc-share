---
status: accepted
date: 2026-08-25
---

# 認証トークン処理ライブラリにPyJWTとoidc-client-tsを採用

## 背景

ViewerのOIDC/PKCEログインとAPIのJWT検証を認証統合として実装するにあたり、トークン処理ライブラリを選ぶ必要が生じた。認証方式はKeycloak+OIDCで、ブラウザ側はSPA+認可コードフロー+PKCEとする。APIはJWT検証のみを担う。この構成は決定済みである。

## 決定

API（Python/FastAPI）のJWT検証にはPyJWTを、Viewer（Vue SPA）のOIDCクライアントにはoidc-client-tsを採用する。いずれも実装着手時点の最新安定版を使用する。

PyJWTの採用理由は次のとおり。PyJWTはJWT検証のデファクトで、活発にメンテされている。`PyJWKClient`によるJWKS取得・キャッシュが標準装備で、Keycloak公開鍵での署名検証がライブラリ内で完結する。APIが小さく検証パラメータ（issuer / audience / exp）が明示的なので、セキュリティレビューが容易。「APIはJWT検証のみ」というスコープに過不足なく一致する。

oidc-client-tsの採用理由は次のとおり。oidc-client-tsは標準OIDCに準拠し、IdPに依存しない。旧定番oidc-clientの公式後継で、認可コードフロー+PKCEとrefresh token rotationに対応しており、決定済みの認証方式と一致する。フレームワーク非依存のため、Piniaストアに素直に統合できる。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| python-jose（API） | メンテが停滞しており、2024年にアルゴリズム混同・DoSのCVEがあった。実質非推奨である |
| Authlib（API） | 高品質だが、OAuthサーバ/クライアント機能を含む統合ライブラリで、JWT検証のみの用途には過剰 |
| joserfc（API） | 設計は良いが、採用実績とエコシステムの成熟度でPyJWTに劣後する |
| python-keycloak（API） | Keycloak admin API操作が主目的で、トークン検証だけに使うと不要な結合が生じる |
| keycloak-js（Viewer） | Keycloak専用で、サーババージョンと密結合の傾向がある。IdP中立性の方針と整合しない |
| Vue向けOIDCラッパー各種（Viewer） | メンテが薄い。実質oidc-client系のラッパーで、層が増えるだけ |

## 影響

Keycloak固有機能（セッション管理連携等）は、ライブラリからは使わない。必要になった場合は、標準OIDCの範囲で実現するか、本決定を見直す。

oidc-client-tsはトークンをブラウザ側で扱うため、XSS耐性はBFF方式に劣る。BFF自作の却下は、ブラウザ側認証方式のADRで扱う。BFF方式は、本番化時の強化オプションとして再評価する。

PyJWTのJWKSキャッシュ動作（更新頻度・失効時の挙動）は、Keycloak鍵ローテーションの運用を決める際に確認する。
