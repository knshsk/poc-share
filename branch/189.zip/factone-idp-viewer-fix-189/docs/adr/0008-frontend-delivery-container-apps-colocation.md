---
status: accepted
date: 2026-08-25
---

# フロントエンドをContainer Apps同居で配信する

## 背景

Viewer（Vue SPA）の配信方式として、Azure Static Web Apps（SWA）を使うか、APIコンテナに同居させるかを選ぶ必要があった。認証基盤はKeycloak採用が決定済み（ADR-0006）で、Power AutomateはIDP APIを直接呼び出す。

## 決定

FastAPIからViewerビルド成果物を配信する、Container Apps同居配信とする。コンテナ1本の最小構成で、実装はSPAフォールバック付きのcatch-allルートによる静的ファイル配信である。コンテナビルドはマルチステージ構成とし、Viewerビルド成果物をPython実行イメージへ同梱する。

採用理由は次のとおり。単一オリジンとなり、CORS管理が不要になる。全経路（ブラウザ・Power Automate）がJWT検証一本で通り、認証モデルが単純になる。デプロイ単位が1つで済む。将来VNet+PE隔離を採用する場合も、構成が変わらない。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| Static Web Apps無料プラン | カスタムOIDCを使えない（Standardのみ）。そのためKeycloakと組めず、認証面の利点がゼロ。別オリジンとなり、CORS管理も必要になる |
| SWA Standard+カスタムOIDC（Easy Auth）+リンクバックエンド | 認証実装量は最小で、トークン非露出もEasy Authで得られる。しかし次の問題がある。(1) Power AutomateのAPI直接呼出と`x-ms-client-principal`ヘッダ信頼モデルが併存し、認証経路が二重化する。ingressをSWA専用に閉じられず、偽装対策が別途必要になる。(2) SWAはVNetに参加できず、将来隔離を採用するときに成立しない。(3) 相乗り先環境の構成と整合しない可能性がある |

## 影響

静的配信の性能・責務分離が必要になった場合は、同一Environment内の配信コンテナ分離へ発展させる。コンテナビルドのコンテキストはリポジトリルートとし、`api/Containerfile`から`viewer/`・`api/`両方を参照する。
