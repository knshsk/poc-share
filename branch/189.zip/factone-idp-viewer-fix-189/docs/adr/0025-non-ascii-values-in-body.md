---
status: accepted
date: 2026-10-01
---

# 非ASCIIを含みうる値はヘッダでなく本文で受け、原本ファイル名の本文フィールドを設ける

## 背景

文書登録API（`POST /api/v1/documents`）は、原本ファイル名をmultipartの`file`パートの`filename`から取っていた。`filename`は、パートヘッダ`Content-Disposition`のパラメータである。Power Automate（PA）のHTTPアクションは、送信前にパートヘッダの非ASCII文字を1文字ずつ`?`に置き換える。そのため、日本語のファイル名は`ABC???.pdf`のように化けて保存される。

公式ドキュメントに記載はないが、Logic Appsでも同じ症状が報告されている。リクエスト全体に`charset=utf-8`を付けても直らない。パートの本文（テキスト）はUTF-8のまま届くことを、実機で確認した。

## 決定

外部連携から受ける値のうち、非ASCIIを含みうるものは、HTTPヘッダ（multipartのパートヘッダを含む）ではなく本文で受ける。文書登録APIに任意のテキストフィールド`original_filename`を追加し、`filename`より優先して原本ファイル名に使う。

正規化は、`original_filename`と`filename`のどちらにも同じものを適用する。正規化の内容は、basenameの取り出し・前後の空白の除去・255文字での切り詰めである。`original_filename`を正規化した結果が空なら、従来どおり`filename`を使う。結果が空になるのは、たとえば空の値・空白のみの値・パス区切りで終わる値である。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| PAで`filename`をpercent-encodeし、APIで復号する | `%20`のような文字列を含む実際のファイル名が、復号で失われる。全クライアントの`filename`の解釈が変わり、APIがPAの挙動に依存する |
| `filename*`（RFC 5987のUTF-8表記）を受ける | multipart/form-dataでは、RFC 7578 §4.2が`filename*`を使わないよう定めており、python-multipartも読まない。パートヘッダを自前で解析する必要がある |
| multipartの本文全体をbase64にして`$content`で送る（Microsoftが案内するLogic Appsの回避策） | バイト列の連結にC#のインラインコード（Logic Apps Standard専用）が要り、PAでは組めない |

## 影響

PAのフローは、`original_filename`のテキストパートを足して、実際のファイル名を渡す。`file`パートの`filename`は省けない。省くとファイルとして扱われず、422になる。そのため、`filename`は化けた値のまま送ってよい。

ブラウザ（Viewerの画面登録）は`filename`をUTF-8のまま送れるため、`original_filename`を送らない。

外部連携向けに、値をヘッダで受けるAPIを新たに設けるときは、値がASCIIに限られることを確かめる。
