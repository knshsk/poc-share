# IDP機能要件

IDP（レーン8／OX層／商品化対象SaaS・API）に求められる機能要件。本PJのIDPは、Azure AI Document Intelligenceを指す。

出所は、[../business/operation-flow.md](../business/operation-flow.md)のレーン定義（レーン8）と、K2・K4・K5・R1の各シーケンス。

## 機能要件

### IDP-01: 見積PDFの文字化（項目化）

見積PDFを文字化（項目化）し、項目データを返却する。

出所工程はK2（K2-6）。

補足として、呼出元はPower Automateで、連携フォルダ監視トリガーで起動する。案件IDの解決・検証・付与は、呼出後にPower Automateが行う（K2-7）。

関連対象外事項はOUT-17（見積の同日複数版は扱わない）。

### IDP-02: 注文書PDFの項目化

注文書PDFをスキャンして項目化し、品目・数量・納期・単価を返却する。

出所工程はK4（K4-5〜K4-6）。

補足として、呼出元はPower Automateである。項目化結果を用いた型区分判定（案件型／ルート型）、案件ID引き当て、ルートID採番はPower Automateの責務。1PDF＝1文書IDを前提とする。

関連対象外事項はOUT-03とOUT-15。OUT-03では、1PDFに複数注文書が含まれるケースを扱わない。OUT-15では、判定不能時のエラー停止をPower Automateの責務とする。

### IDP-03: 確信度の返却

項目化結果とあわせて、確信度を返却する。

出所工程はK2・K4。

補足として、PoCでは確信度の返却・記録のみを行い、閾値判定は行わない。全件をHuman in the Loop（SAP承認ワークフロー）で確認する。

関連対象外事項はOUT-06とOUT-09。OUT-06では、確信度による自動／手動の振り分けを行わない。OUT-09では、サンプルデータのため読取精度・確信度分布をPoCでは測定できない。

### IDP-04: REST APIとしての提供

文字化・項目化機能をREST APIとして提供し、Power AutomateおよびViewerから呼出可能とする。

出所工程はK2（K2-6）・K4（K4-5）・K5（K5-6）・R1（R1-6）。

補足として、Viewerからの呼出は、承認時に項目化結果へ疑義がある場合の再項目化に用いる。Viewer側の要件はVW-06。

## 境界（非責務）

- 案件ID・ルートIDの解決・付与は行わない。Power Automateの責務である。
- 顧客固有の名寄せロジックは持たない。
- 確信度による自動・手動の振り分け判定は行わない。Power Automateの責務としても、本PoCでは対象外とする（OUT-06）。
- 型区分判定（案件型／ルート型の振り分け）は行わない。Power Automateの責務である。

## 関連ドキュメント

設計ドキュメントは次のとおり。

| 参照先 | 内容 |
| --- | --- |
| [../api/](../api/) | API設計 |
| [../data-model/idp-runs.md](../data-model/idp-runs.md) | IDP実行 |
| [../data-model/documents.md](../data-model/documents.md) | 文書 |

関連する要件は、[viewer.md](viewer.md)のVW-06（画面からのIDP実行）。
