"""閲覧URL（発行・検証・失効・無認証閲覧）の統合テスト。

セキュリティ検証対象（厚くするテスト領域）。実PostgreSQLコンテナ接続。
"""

from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select, text
from sqlalchemy.orm import Session

from app.models import ViewAccessFailure, ViewToken


def register(
    client: TestClient,
    document_id: str,
    pdf: bytes,
    document_type: str = "quotation",
    filename: str = "doc.pdf",
) -> None:
    response = client.post(
        "/api/v1/documents",
        data={"document_id": document_id, "document_type": document_type},
        files={"file": (filename, pdf, "application/pdf")},
    )
    assert response.status_code == 201


def issue(client: TestClient, document_id: str, **payload: Any) -> Any:
    return client.post(
        f"/api/v1/documents/{document_id}/view-urls", json=payload or None
    )


def test_issue_view_url_for_quote(doc_client: TestClient, pdf_bytes: bytes) -> None:
    """見積文書への閲覧URL発行が201となり、トークン込みパスと期限を返すことを確認する。"""
    register(doc_client, "vu-quotation", pdf_bytes)

    response = issue(doc_client, "vu-quotation")

    assert response.status_code == 201
    body = response.json()
    assert body["view_path"].startswith("/view/")
    # トークンは256bit URL-safe（43文字以上）
    assert len(body["view_path"].removeprefix("/view/")) >= 43
    assert "id" in body
    assert "expires_at" in body


def test_issue_rejected_for_non_shareable_type(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """注文書（非共有種別）への発行が403となることを確認する。"""
    register(doc_client, "vu-order", pdf_bytes, document_type="purchase_order")

    response = issue(doc_client, "vu-order")

    assert response.status_code == 403


def test_issue_for_unknown_document_returns_404(doc_client: TestClient) -> None:
    """存在しない文書への発行が404となることを確認する。"""
    response = issue(doc_client, "vu-none")

    assert response.status_code == 404


def test_issue_requires_auth(doc_client: TestClient, pdf_bytes: bytes) -> None:
    """トークンなしの発行が401となることを確認する。"""
    register(doc_client, "vu-auth", pdf_bytes)
    auth = doc_client.headers.pop("Authorization")

    response = issue(doc_client, "vu-auth")

    assert response.status_code == 401
    doc_client.headers["Authorization"] = auth


def test_token_plaintext_not_stored(
    doc_client: TestClient, pdf_bytes: bytes, test_database_url: str
) -> None:
    """トークン平文がDBに保存されないこと（ハッシュのみ）を確認する。"""
    register(doc_client, "vu-hash", pdf_bytes)
    token = issue(doc_client, "vu-hash").json()["view_path"].removeprefix("/view/")

    engine = create_engine(test_database_url)
    with Session(engine) as session:
        row = session.scalars(select(ViewToken)).one()
        assert row.token_hash != token
        assert len(row.token_hash) == 64  # SHA-256 hex
    engine.dispose()


def test_list_view_urls_excludes_token(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """発行済み一覧が管理情報のみでトークン平文を含まないことを確認する。"""
    register(doc_client, "vu-list", pdf_bytes)
    issue(doc_client, "vu-list")

    response = doc_client.get("/api/v1/documents/vu-list/view-urls")

    assert response.status_code == 200
    items = response.json()
    assert len(items) == 1
    assert "id" in items[0]
    assert "view_path" not in items[0]
    assert "token" not in items[0]


def test_public_view_with_valid_token(doc_client: TestClient, pdf_bytes: bytes) -> None:
    """有効トークンで認証なしのページ閲覧・画像・原本取得ができることを確認する。"""
    register(doc_client, "vu-view", pdf_bytes)
    token = issue(doc_client, "vu-view").json()["view_path"].removeprefix("/view/")
    auth = doc_client.headers.pop("Authorization")

    pages = doc_client.get(f"/view/{token}/pages")
    image = doc_client.get(f"/view/{token}/pages/1/image")
    pdf = doc_client.get(f"/view/{token}/pdf")

    assert pages.status_code == 200
    assert pages.json()["page_count"] == 1
    assert image.status_code == 200
    assert image.headers["content-type"] == "image/png"
    assert pdf.status_code == 200
    doc_client.headers["Authorization"] = auth


def test_public_pdf_uses_uploaded_filename(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """閲覧URL経由の原本DLもアップロード時のファイル名を返す。"""
    register(doc_client, "vu-fn", pdf_bytes, filename="請求書.pdf")
    token = issue(doc_client, "vu-fn").json()["view_path"].removeprefix("/view/")
    auth = doc_client.headers.pop("Authorization")

    pdf = doc_client.get(f"/view/{token}/pdf")

    assert pdf.headers["content-disposition"] == (
        'attachment; filename="vu-fn.pdf"; '
        "filename*=UTF-8''%E8%AB%8B%E6%B1%82%E6%9B%B8.pdf"
    )
    doc_client.headers["Authorization"] = auth


def test_public_view_with_unknown_token_returns_404(doc_client: TestClient) -> None:
    """存在しないトークンが404となることを確認する。"""
    response = doc_client.get(f"/view/{'x' * 43}/pages")

    assert response.status_code == 404


def test_public_view_with_expired_token_returns_404(
    doc_client: TestClient, pdf_bytes: bytes, test_database_url: str
) -> None:
    """期限切れトークンが404となることを確認する。"""
    register(doc_client, "vu-exp", pdf_bytes)
    token = issue(doc_client, "vu-exp").json()["view_path"].removeprefix("/view/")

    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(
            text("UPDATE view_tokens SET expires_at = :past"),
            {"past": datetime.now(UTC) - timedelta(seconds=1)},
        )
        conn.commit()
    engine.dispose()

    response = doc_client.get(f"/view/{token}/pages")

    assert response.status_code == 404


def test_revoke_takes_effect_immediately(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """失効操作後、同一トークンでの閲覧が即時404となることを確認する。"""
    register(doc_client, "vu-rev", pdf_bytes)
    body = issue(doc_client, "vu-rev").json()
    token = body["view_path"].removeprefix("/view/")
    assert doc_client.get(f"/view/{token}/pages").status_code == 200

    revoke = doc_client.post(f"/api/v1/view-urls/{body['id']}/revoke")

    assert revoke.status_code == 200
    assert doc_client.get(f"/view/{token}/pages").status_code == 404


def test_revoke_all_revokes_every_active_url(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """文書単位の一括失効で全トークンが即時404となり、既失効分は件数に含まれないことを確認する。"""
    register(doc_client, "vu-rev-all", pdf_bytes)
    first = issue(doc_client, "vu-rev-all").json()
    second = issue(doc_client, "vu-rev-all").json()
    tokens = [b["view_path"].removeprefix("/view/") for b in (first, second)]
    assert doc_client.post(f"/api/v1/view-urls/{first['id']}/revoke").status_code == 200

    response = doc_client.post("/api/v1/documents/vu-rev-all/view-urls/revoke-all")

    assert response.status_code == 200
    assert response.json() == {"status": "revoked", "revoked_count": 1}
    for token in tokens:
        assert doc_client.get(f"/view/{token}/pages").status_code == 404
    # 再実行は冪等（対象0件でも200）
    again = doc_client.post("/api/v1/documents/vu-rev-all/view-urls/revoke-all")
    assert again.status_code == 200
    assert again.json()["revoked_count"] == 0


def test_revoke_all_for_unknown_document_returns_404(doc_client: TestClient) -> None:
    """未知の文書への一括失効が404となることを確認する。"""
    response = doc_client.post("/api/v1/documents/vu-none/view-urls/revoke-all")

    assert response.status_code == 404
    assert response.json()["type"] == "/errors/document-not-found"


def test_invalid_token_failure_is_recorded(
    doc_client: TestClient, test_database_url: str
) -> None:
    """無効トークンの試行が失敗記録に残ることを確認する。"""
    doc_client.get(f"/view/{'y' * 43}/pages")

    engine = create_engine(test_database_url)
    with Session(engine) as session:
        failures = session.scalars(select(ViewAccessFailure)).all()
        assert len(failures) == 1
        # トークン全体は記録しない（先頭断片のみ）
        assert failures[0].token_fragment == "y" * 8
    engine.dispose()


def test_nul_in_token_returns_404_and_records_fragment_without_nul(
    doc_client: TestClient, test_database_url: str
) -> None:
    """先頭にNULを含むトークンも無効トークンとして404になり、NULを除いた断片を記録することを確認する。"""
    response = doc_client.get(f"/view/%00{'y' * 42}/pages")

    assert response.status_code == 404
    engine = create_engine(test_database_url)
    with Session(engine) as session:
        failures = session.scalars(select(ViewAccessFailure)).all()
        assert [f.token_fragment for f in failures] == ["y" * 7]
    engine.dispose()


def test_repeated_failures_are_rate_limited(doc_client: TestClient) -> None:
    """無効トークンの連続試行がレート制限（429）となることを確認する。"""
    for _ in range(10):
        assert doc_client.get(f"/view/{'z' * 43}/pages").status_code == 404

    response = doc_client.get(f"/view/{'z' * 43}/pages")

    assert response.status_code == 429


def test_shareable_config_controls_issuance(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """設定でshareable=falseに変えると既存のquoteでも発行拒否となることを確認する。"""
    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": False,
            "fields": [{"key": "document_no", "label": "文書番号", "type": "string"}],
        },
    )
    register(doc_client, "vu-cfg-1", pdf_bytes)

    response = issue(doc_client, "vu-cfg-1")

    assert response.status_code == 403


def test_shareable_new_type_allows_issuance(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """CRUDで追加したshareable=trueの種別へ発行できることを確認する。"""
    doc_client.post(
        "/api/v1/config/document-types",
        json={
            "type_code": "invoice",
            "display_name": "請求書",
            "shareable": True,
            "fields": [{"key": "invoice_no", "label": "請求書番号", "type": "string"}],
        },
    )
    register(doc_client, "vu-cfg-2", pdf_bytes, document_type="invoice")

    response = issue(doc_client, "vu-cfg-2")

    assert response.status_code == 201
