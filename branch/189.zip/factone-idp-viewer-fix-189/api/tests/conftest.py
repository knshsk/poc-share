import io
import time
from collections.abc import Iterator
from typing import Any

import jwt
import pypdfium2 as pdfium
import pytest
from alembic.config import Config
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient
from sqlalchemy import Connection, create_engine, text

from app.core.auth import StaticKeySource
from app.core.config import Settings
from app.core.db import create_session_factory
from app.main import create_app
from app.services.di import AnalysisResult, DiTable, QueryFieldResult

TEST_DATABASE_URL = (
    "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone_test"
)
ADMIN_DATABASE_URL = (
    "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone"
)


class InMemoryBlobStorage:
    """テスト用のBlobStorageフェイク。"""

    def __init__(self) -> None:
        self.saved: dict[str, bytes] = {}

    def save(self, ref: str, data: bytes) -> None:
        # AzureBlobStorage（overwrite=False）と同じく、同名の Blob は上書きしない
        if ref in self.saved:
            raise FileExistsError(ref)
        self.saved[ref] = data

    def load(self, ref: str) -> bytes:
        return self.saved[ref]


class FakeDocumentAnalyzer:
    """テスト用のDocumentAnalyzerフェイク。

    results: {field: (value, confidence)}。regions: {field: (page_number, polygon)}。
    tablesは認識済テーブル領域、contentは全文テキスト（正規表現マッチ対象）。
    raw_responseは生応答bytes（Blob保存内容の検証用）。error設定時は解析呼出で送出する。
    """

    def __init__(self) -> None:
        self.results: dict[str, tuple[str, float]] = {}
        self.regions: dict[str, tuple[int, tuple[float, ...]]] = {}
        self.tables: tuple[DiTable, ...] = ()
        self.content: str = ""
        self.api_version: str | None = "2024-11-30"
        self.model_id: str | None = "prebuilt-layout"
        self.raw_response: bytes = (
            b'{"status":"succeeded","analyzeResult":'
            b'{"apiVersion":"2024-11-30","modelId":"prebuilt-layout"}}'
        )
        self.error: Exception | None = None
        self.calls: list[tuple[bytes, tuple[str, ...]]] = []

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult:
        self.calls.append((pdf, query_fields))
        if self.error is not None:
            raise self.error
        fields = {}
        for field, (value, confidence) in self.results.items():
            if field not in query_fields:
                continue
            page_number, polygon = self.regions.get(field, (None, None))
            fields[field] = QueryFieldResult(
                value=value,
                confidence=confidence,
                page_number=page_number,
                polygon=polygon,
            )
        return AnalysisResult(
            fields=fields,
            tables=self.tables,
            content=self.content,
            api_version=self.api_version,
            model_id=self.model_id,
            raw_response=self.raw_response,
        )


def make_pdf(pages: int = 1) -> bytes:
    """白紙ページだけのPDFを作る。ページはUS Letter（612x792ポイント = 8.5x11インチ）。"""
    doc = pdfium.PdfDocument.new()
    for _ in range(pages):
        doc.new_page(612, 792)
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


DEFAULT_COMMON_FIELDS = [
    {"key": "SenderCompanyName", "label": "取引先", "type": "string"},
    {
        "key": "ReceiverCompanyName",
        "label": "自社名",
        "type": "string",
        "visible": False,
    },
    {"key": "OrderDate", "label": "注文日", "type": "date"},
    {"key": "TotalAmount", "label": "合計金額", "type": "number"},
    {"key": "DeliveryDate", "label": "納品期限", "type": "date"},
    {"key": "DeliveryLocation", "label": "納品場所", "type": "string"},
    {"key": "CustomerContactPersonName", "label": "取引先担当者", "type": "string"},
    {"key": "QuotationId", "label": "見積書ID", "type": "string"},
]

# マイグレーション b7e3d2a9c1f5 のシードと同内容
DEFAULT_CONFIGS = [
    (
        "purchase_order",
        "注文書",
        False,
        [
            *DEFAULT_COMMON_FIELDS,
            {"key": "PurchaseOrderId", "label": "注文書ID", "type": "string"},
        ],
    ),
    ("quotation", "見積書", True, DEFAULT_COMMON_FIELDS),
]


def _seed_default_configs(conn: Connection, tenant_id: str = "default") -> None:
    import json
    import uuid as _uuid

    for code, name, shareable, fields in DEFAULT_CONFIGS:
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields) "
                "VALUES (:id, :tenant_id, :code, :name, :shareable, :fields)"
            ),
            {
                "id": str(_uuid.uuid4()),
                "tenant_id": tenant_id,
                "code": code,
                "name": name,
                "shareable": shareable,
                "fields": json.dumps(fields),
            },
        )


def alembic_config(database_url: str) -> Config:
    """テスト DB に向けた Alembic 設定（migrations/env.py は attributes の database_url を優先する）。"""
    config = Config("alembic.ini")
    config.set_main_option("script_location", "migrations")
    config.attributes["database_url"] = database_url
    return config


def make_token(key: RSAPrivateKey, tenant_id: str | None = "default") -> str:
    claims: dict[str, Any] = {
        "iss": "http://localhost:8080/realms/factone",
        "aud": "factone-api",
        "sub": "test-user",
        "preferred_username": "testuser",
        "exp": int(time.time()) + 300,
    }
    if tenant_id is not None:
        claims["tenant_id"] = tenant_id
    return jwt.encode(claims, key, algorithm="RS256")


OTHER_TENANT = "other"


def as_tenant(client: TestClient, key: RSAPrivateKey, tenant_id: str) -> None:
    """以降のリクエストを指定テナントのトークンで送る（クロステナントのテスト用）。"""
    client.headers["Authorization"] = f"Bearer {make_token(key, tenant_id=tenant_id)}"


@pytest.fixture
def client() -> TestClient:
    return TestClient(create_app())


@pytest.fixture(scope="session")
def test_database_url() -> str:
    admin_engine = create_engine(ADMIN_DATABASE_URL, isolation_level="AUTOCOMMIT")
    with admin_engine.connect() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM pg_database WHERE datname = 'factone_test'")
        ).scalar()
        if not exists:
            conn.execute(text("CREATE DATABASE factone_test"))
    admin_engine.dispose()

    from alembic import command

    command.upgrade(alembic_config(TEST_DATABASE_URL), "head")
    return TEST_DATABASE_URL


@pytest.fixture(scope="session")
def signing_key() -> RSAPrivateKey:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture
def blob_storage() -> InMemoryBlobStorage:
    return InMemoryBlobStorage()


@pytest.fixture(scope="session")
def pdf_bytes() -> bytes:
    return make_pdf()


@pytest.fixture
def fake_analyzer() -> FakeDocumentAnalyzer:
    return FakeDocumentAnalyzer()


@pytest.fixture
def doc_client(
    test_database_url: str,
    signing_key: RSAPrivateKey,
    blob_storage: InMemoryBlobStorage,
    fake_analyzer: FakeDocumentAnalyzer,
) -> Iterator[TestClient]:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
        conn.execute(text("TRUNCATE TABLE view_access_failures"))
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        _seed_default_configs(conn)
        _seed_default_configs(conn, "other")
        conn.commit()

    settings = Settings(_env_file=None, database_url=test_database_url)  # type: ignore[call-arg]
    app = create_app(
        settings=settings,
        key_source=StaticKeySource(signing_key.public_key()),
        session_factory=create_session_factory(engine),
        blob_storage=blob_storage,
        document_analyzer=fake_analyzer,
    )
    client = TestClient(app)
    client.headers["Authorization"] = f"Bearer {make_token(signing_key)}"
    yield client
    engine.dispose()
