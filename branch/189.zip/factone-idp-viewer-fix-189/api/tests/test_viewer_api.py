"""文書表示API（メタデータ・ページ画像・原本PDF配信）の統合テスト。

有効なPDFは make_pdf で実行時生成し、破損PDFは tests/fixtures/broken.pdf を使用する。
"""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from tests.conftest import InMemoryBlobStorage, make_pdf

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def valid_pdf() -> bytes:
    return make_pdf(pages=2)


def register(client: TestClient, document_id: str, content: bytes) -> None:
    response = client.post(
        "/api/v1/documents",
        data={"document_id": document_id, "document_type": "quotation"},
        files={"file": ("doc.pdf", content, "application/pdf")},
    )
    assert response.status_code == 201


def test_get_document_metadata(doc_client: TestClient, valid_pdf: bytes) -> None:
    """登録済み文書のメタデータが取得できることを確認する。"""
    register(doc_client, "doc-meta", valid_pdf)

    response = doc_client.get("/api/v1/documents/doc-meta")

    assert response.status_code == 200
    assert response.json()["document_id"] == "doc-meta"
    assert response.json()["document_type"] == "quotation"


def test_get_unknown_document_returns_404(doc_client: TestClient) -> None:
    """存在しない文書IDのメタデータ取得が404となることを確認する。"""
    response = doc_client.get("/api/v1/documents/no-such-doc")

    assert response.status_code == 404


def test_get_pages_returns_count_and_sizes_in_inches(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """ページ一覧がページ数と各ページ寸法（インチ単位）を返すことを確認する。

    DI座標系（インチ）とSVG viewBoxを整合させるための座標系変換（ポイント→インチ）を検証する。
    """
    register(doc_client, "doc-pages", valid_pdf)

    response = doc_client.get("/api/v1/documents/doc-pages/pages")

    assert response.status_code == 200
    body = response.json()
    assert body["page_count"] == 2
    assert body["pages"][0]["width"] == pytest.approx(8.5)
    assert body["pages"][0]["height"] == pytest.approx(11.0)


def test_get_page_image_returns_png(doc_client: TestClient, valid_pdf: bytes) -> None:
    """ページ画像がPNGで配信されることを確認する。"""
    register(doc_client, "doc-img", valid_pdf)

    response = doc_client.get("/api/v1/documents/doc-img/pages/1/image")

    assert response.status_code == 200
    assert response.headers["content-type"] == "image/png"
    assert response.content.startswith(b"\x89PNG")


def test_get_page_image_out_of_range_returns_404(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """範囲外ページの画像要求が404となることを確認する。"""
    register(doc_client, "doc-range", valid_pdf)

    assert (
        doc_client.get("/api/v1/documents/doc-range/pages/3/image").status_code == 404
    )
    assert (
        doc_client.get("/api/v1/documents/doc-range/pages/0/image").status_code == 404
    )


def test_get_original_pdf(doc_client: TestClient, valid_pdf: bytes) -> None:
    """原本PDFがそのまま配信されることを確認する。"""
    register(doc_client, "doc-dl", valid_pdf)

    response = doc_client.get("/api/v1/documents/doc-dl/pdf")

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content == valid_pdf


def test_json_responses_are_gzipped(doc_client: TestClient) -> None:
    """JSON の応答は gzip で返すことを確認する。"""
    response = doc_client.get(
        "/api/v1/config/document-types", headers={"Accept-Encoding": "gzip"}
    )

    assert response.status_code == 200
    assert len(response.content) >= 500  # 圧縮の最小サイズ以上であることの前提
    assert response.headers["content-encoding"] == "gzip"


def test_page_image_and_pdf_are_not_gzipped(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """圧縮済みの形式（ページ画像の PNG・原本 PDF）は gzip で包まないことを確認する。"""
    register(doc_client, "doc-gz", valid_pdf)
    headers = {"Accept-Encoding": "gzip"}

    image = doc_client.get("/api/v1/documents/doc-gz/pages/1/image", headers=headers)
    pdf = doc_client.get("/api/v1/documents/doc-gz/pdf", headers=headers)

    assert image.status_code == 200
    assert pdf.status_code == 200
    assert len(pdf.content) >= 500  # 除外が無ければ圧縮される大きさであることの前提
    assert "content-encoding" not in image.headers
    assert "content-encoding" not in pdf.headers


def test_broken_pdf_returns_500_with_detail(
    doc_client: TestClient, valid_pdf: bytes, blob_storage: InMemoryBlobStorage
) -> None:
    """登録済みの文書のPDFを処理できないとき、ページ処理が明示的なエラー応答となることを確認する。

    開けないPDFは登録で拒否されるため、登録後にBlobの中身を破損PDFに差し替えて再現する。
    """
    register(doc_client, "doc-broken", valid_pdf)
    (blob_ref,) = blob_storage.saved
    blob_storage.saved[blob_ref] = (FIXTURES / "broken.pdf").read_bytes()

    response = doc_client.get("/api/v1/documents/doc-broken/pages")

    assert response.status_code == 500
    assert response.json()["detail"] == "Failed to process PDF"
    assert response.json()["type"] == "/errors/pdf-processing-failed"


def test_viewer_endpoints_require_auth(
    doc_client: TestClient, valid_pdf: bytes
) -> None:
    """表示系エンドポイントがトークンなしで401となることを確認する。"""
    register(doc_client, "doc-auth", valid_pdf)
    doc_client.headers.pop("Authorization")

    assert doc_client.get("/api/v1/documents/doc-auth").status_code == 401
    assert doc_client.get("/api/v1/documents/doc-auth/pages").status_code == 401
    assert doc_client.get("/api/v1/documents/doc-auth/pages/1/image").status_code == 401
    assert doc_client.get("/api/v1/documents/doc-auth/pdf").status_code == 401
