# FactONE IDP/Viewer API

FastAPI製のバックエンドAPI。ディレクトリ構成には、FastAPI公式の[Bigger Applications](https://fastapi.tiangolo.com/tutorial/bigger-applications/)に準拠したレイヤー型構造を採用する。

## ディレクトリ構成

```
api/
├── app/                   # アプリケーション本体
│   ├── main.py            # アプリファクトリ（create_app）。依存オブジェクトの組み立て、ミドルウェア・例外ハンドラ・ルーター・SPA 配信の登録
│   ├── models.py          # SQLAlchemy ORM モデル（全テーブル定義）
│   ├── core/              # 横断基盤（全ルーターが依存する共通機能）
│   │   ├── config.py      # 設定（環境変数、pydantic-settings）
│   │   ├── auth.py        # OIDC/JWT 認証
│   │   ├── db.py          # DB エンジン・セッションファクトリ
│   │   ├── problem.py     # RFC 9457 Problem Details のエラー応答
│   │   └── static_serving.py  # SPA 静的配信マウント
│   ├── routers/           # API エンドポイント（リクエスト/レスポンススキーマ同居）
│   │   ├── document_type_configs.py  # 文書種別設定の CRUD
│   │   ├── documents.py   # ドキュメント登録・取得・ページ画像・原本 PDF
│   │   ├── idp_runs.py    # IDP 実行・履歴・修正の確定
│   │   └── view_urls.py   # 閲覧用 URL 発行・管理・公開閲覧・イベント記録と取得
│   └── services/          # 外部サービス連携・ドメイン処理
│       ├── blob.py        # Blob ストレージ（Azure Blob / ローカルファイル）
│       ├── di.py          # Azure Document Intelligence クライアント
│       ├── document_type_config.py  # 文書種別設定の取得と型付け
│       ├── idp_extraction.py  # DI 応答のパース・正規化・パターン照合・修正適用
│       └── pdf_render.py  # PDF レンダリング（pypdfium2）
├── migrations/            # Alembic マイグレーション
├── scripts/               # 運用スクリプト（OpenAPI エクスポート等）
├── tests/                 # pytest テスト
├── alembic.ini
├── Containerfile
├── pyproject.toml         # 依存管理は uv
└── uv.lock                # uv のロックファイル
```

## 各ディレクトリの責務と配置指針

新しいモジュールをどこに置くか、どこを編集するかを判断するための基準。

### `routers/`（APIエンドポイント）

HTTPエンドポイント（`APIRouter`）を定義する層。リクエスト/レスポンスのPydanticスキーマと、エンドポイント固有のヘルパーも同じファイルに置く。新規エンドポイントを追加するときは、既存の機能領域に属するなら該当ファイルへ追記する。新しい機能領域なら、新規ファイルを作成して`main.py`で`include_router`する。

### `services/`（外部連携・ドメイン処理）

外部サービス（Blobストレージ、Document Intelligenceなど）とのやり取りや、データ変換・パースなどの処理を置く層。FastAPIには依存しない。外部サービス連携や変換ロジックを追加するときは、`services/`に新規ファイルを作成する。ルーターからは関数・クラスをimportして使う。

### `core/`（横断基盤）

認証・設定・DB接続など、複数のルーターが共通で依存する基盤を置く層。全体に関わる共通機能を追加するときは、この層に置く。特定機能でしか使わないものは`services/`に置く。

### `app/`直下

`main.py`はアプリファクトリ。依存オブジェクトの組み立て、ミドルウェアと例外ハンドラ、ルーターとSPA配信の登録を行う。`/health`と`/api/v1/me`の2つのエンドポイントも`main.py`に直接置く。ビジネスロジックは書かない。

`models.py`にはSQLAlchemy ORMモデルを置く。テーブルを追加するときは、`models.py`に追記してAlembicマイグレーションを作成する。`migrations/env.py`は`app.models.Base`を参照する。

## 起動・テスト

```
uv run uvicorn app.main:create_app --factory   # 起動
uv run pytest                                   # テスト
uv run ruff check app tests                     # lint
```
