import {
  InMemoryWebStorage,
  UserManager,
  WebStorageStateStore,
} from 'oidc-client-ts'

export interface Session {
  accessToken: string
  username: string | null
}

export interface Oidc {
  login(): Promise<void>
  handleCallback(): Promise<Session | null>
  logout(): Promise<void>
}

// アクセストークンはメモリ保持（localStorage 等へ永続化しない）
function createUserManager(): UserManager {
  return new UserManager({
    // 空文字（ビルド引数未指定）でも既定値へフォールバックさせるため || を使う
    authority:
      import.meta.env.VITE_OIDC_AUTHORITY ||
      'http://localhost:8080/realms/factone',
    client_id: import.meta.env.VITE_OIDC_CLIENT_ID || 'factone-viewer',
    redirect_uri: `${window.location.origin}/callback`,
    post_logout_redirect_uri: window.location.origin,
    scope: 'openid',
    userStore: new WebStorageStateStore({ store: new InMemoryWebStorage() }),
  })
}

// コールバック後の復元先。同一オリジンの相対パス（"/"始まり・"//"不可）のみ許可し、
// 不正値はトップへフォールバックする（オープンリダイレクト防止）
export function resolveReturnTo(state: unknown): string {
  const returnTo = (state as { returnTo?: unknown } | undefined)?.returnTo
  if (typeof returnTo !== 'string') return '/'
  if (!returnTo.startsWith('/') || returnTo.startsWith('//')) return '/'
  return returnTo
}

export function createOidc(): Oidc {
  const userManager = createUserManager()
  return {
    async login() {
      // ログイン前 URL（?document_id= 等）を state に保存し、コールバック後に復元する
      await userManager.signinRedirect({
        state: {
          returnTo: `${window.location.pathname}${window.location.search}`,
        },
      })
    },
    async handleCallback() {
      const user = await userManager.signinCallback()
      // 認証済みへ遷移すると Mediator が location.search の document_id を読むため、URL 復元を先に行う
      window.history.replaceState({}, '', resolveReturnTo(user?.state))
      if (!user) return null
      return {
        accessToken: user.access_token,
        username: user.profile?.preferred_username ?? null,
      }
    },
    async logout() {
      await userManager.signoutRedirect()
    },
  }
}
