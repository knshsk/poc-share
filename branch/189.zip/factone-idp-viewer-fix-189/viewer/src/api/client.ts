import createClient from 'openapi-fetch'

import type { paths } from './schema'

// 同一オリジン前提（本番はContainer Apps同居配信、ローカルはVite devプロキシ）
export const apiClient = createClient<paths>({ baseUrl: '/' })

// アクセストークンはメモリ保持。Mediator が OIDC コールバック後に設定し、ログアウトで消す
let accessToken: string | null = null

export function setAccessToken(token: string | null): void {
  accessToken = token
}

apiClient.use({
  onRequest({ request }) {
    if (accessToken) {
      request.headers.set('Authorization', `Bearer ${accessToken}`)
    }
    return request
  },
})
