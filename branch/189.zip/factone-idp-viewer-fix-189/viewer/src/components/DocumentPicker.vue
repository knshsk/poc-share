<script setup lang="ts">
import { PhFileArrowUp, PhFileMagnifyingGlass, PhX } from '@phosphor-icons/vue'
import { nextTick, ref, watch } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { PickerVm } from '../mediator/vm'
import { useReturnFocus } from '../utils/returnFocus'
import DocumentRegisterForm from './DocumentRegisterForm.vue'

// 文書選択ダイアログ（文書を登録 / 文書IDで参照）。開閉は Mediator が持ち（vm.open）、× と Esc で
// closeDocumentPicker を bubble する。背景のクリックでは閉じない（閉じると中身が破棄され、選んだ PDF も消えるため）。
// 決定した文書IDは openDocument で bubble する
const props = defineProps<{ vm: PickerVm }>()

const bubble = useBubble()
const tab = ref<'register' | 'view'>('register')
const inputId = ref('')
const inputRef = ref<{ focus: () => void; select: () => void } | null>(null)

// 閉じたら開く前の要素へフォーカスを戻す。戻せないとき（自動で開いた、読込・登録で「文書を開く」や文書タイトルが
// 置き換わった）は、アプリバーの入口（文書タイトル / 文書を開く。AppHeader.vue の id）へ移す
useReturnFocus(
  () => props.vm.open,
  () => document.getElementById('document-picker-entry'),
)

// 開くたびに初期化する（閉じると Vuetify が中身を破棄するので、登録フォームの入力も同時に消える）。
// 表示中（または取得に失敗した）文書があれば、参照タブにその ID を入れて開く
watch(
  () => props.vm.open,
  (open) => {
    if (!open) return
    tab.value = props.vm.documentId ? 'view' : 'register'
    inputId.value = props.vm.documentId
  },
  { immediate: true },
)

// 参照タブは入力欄1本のため、切替時にフォーカスして即入力できるようにする
watch(tab, async (value) => {
  if (value !== 'view') return
  await nextTick()
  inputRef.value?.focus()
})

// 参照タブで開いたときは ID を全選択する（打てば置き換わる）。VDialog は after-enter でフォーカスが中身の外に
// あれば中身へ移すため、同じイベントで入力欄へ当てる
function onAfterEnter(): void {
  if (tab.value !== 'view') return
  inputRef.value?.focus()
  inputRef.value?.select()
}

function close(): void {
  bubble({ type: 'closeDocumentPicker' })
}

function applyInputId(): void {
  if (inputId.value) {
    bubble({ type: 'openDocument', documentId: inputId.value })
  }
}
</script>

<template>
  <v-dialog
    :model-value="vm.open"
    persistent
    max-width="560"
    aria-label="文書を開く"
    @keydown.esc="close"
    @after-enter="onAfterEnter"
  >
    <v-card rounded="lg">
      <div class="d-flex align-center picker-tabs">
        <v-tabs v-model="tab" grow color="primary" class="flex-grow-1">
          <v-tab value="register" data-testid="picker-tab-register">
            <PhFileArrowUp :size="20" class="mr-2" />
            文書を登録
          </v-tab>
          <v-tab value="view" data-testid="picker-tab-view">
            <PhFileMagnifyingGlass :size="20" class="mr-2" />
            文書IDで参照
          </v-tab>
        </v-tabs>
        <!-- 送信中は閉じない（Mediator も registering の closeDocumentPicker を捨てる） -->
        <v-btn
          icon
          variant="text"
          aria-label="閉じる"
          :disabled="vm.register.submitting"
          data-testid="picker-close"
          @click="close"
        >
          <PhX :size="20" />
        </v-btn>
      </div>

      <v-window v-model="tab">
        <!-- 定型外フロー向けの手動登録。登録済み文書IDをそのまま表示対象にする -->
        <v-window-item value="register">
          <DocumentRegisterForm :vm="vm.register" class="pa-6 picker-pane" />
        </v-window-item>

        <v-window-item value="view">
          <v-form
            class="pa-6 picker-pane picker-pane--view"
            @submit.prevent="applyInputId"
          >
            <v-text-field
              ref="inputRef"
              v-model="inputId"
              label="文書ID"
              class="mb-4"
              hide-details
              data-testid="document-id-input"
            />
            <div class="d-flex justify-center">
              <v-btn
                type="submit"
                color="primary"
                min-width="120"
                :disabled="!inputId"
                data-testid="document-id-apply"
              >
                参照
              </v-btn>
            </div>
          </v-form>
        </v-window-item>
      </v-window>
    </v-card>
  </v-dialog>
</template>

<style scoped>
.picker-tabs {
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* タブ切替でダイアログ高さが変わらないよう、両ペインを登録フォームの高さに揃える */
.picker-pane {
  min-height: 376px;
}

/* 参照タブは入力欄1本のため縦中央に寄せる（grid は子を伸ばさない） */
.picker-pane--view {
  display: grid;
  align-content: center;
}
</style>
