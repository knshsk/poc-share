<script setup lang="ts">
// 読取結果タブの表 1 件（DI 認識テーブル）。罫線付きの表にセルの入力欄を並べ、連続する空行は畳む。
// PageSvg と同じ「繰り返し要素の葉」で、親（ResultEditor）が表ごとの props に分けて渡す
import { PhCaretDown, PhCaretRight } from '@phosphor-icons/vue'
import { computed, reactive, useId, watch } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { Request } from '../mediator/model'
import {
  CORRECTION_MAX_LENGTH,
  cellId,
  cellKey,
  parseCellId,
  type IdpRun,
} from '../utils/runs'
import {
  columnTemplate,
  isNumeric,
  rowBlocks,
  type RowBlock,
} from '../utils/table'

const props = defineProps<{
  table: NonNullable<IdpRun['tables']>[number]
  tableIndex: number
  draftCells: Record<string, string>
  // 保存済みの人手修正があるセル（cellKey "t:r:c"）
  correctedCells: ReadonlySet<string>
  activeId: string | null
  focusRequest: Request | null
}>()

const bubble = useBubble()
// 修正済みセルの読み上げ用テキストの id（三角印は装飾のため）
const correctedId = useId()
// 見出しの id（表ごとの role="group" のラベル。複数の表でセルの aria-label が同名になるのを防ぐ）
const headingId = useId()

// "row:column" → セル。DI にセルが無い座標は undefined
const cells = computed(
  () =>
    new Map(
      props.table.cells.map(
        (c) => [`${c.row_index}:${c.column_index}`, c] as const,
      ),
    ),
)
const contentAt = (r: number, c: number): string | undefined =>
  cells.value.get(`${r}:${c}`)?.content
const draftAt = (r: number, c: number): string | undefined =>
  props.draftCells[cellKey(props.tableIndex, r, c)]

// 列幅は元の内容だけで決める（下書きを含めると入力中に列が揺れる）
const columns = computed(() =>
  columnTemplate(props.table.column_count, (c) =>
    Array.from(
      { length: props.table.row_count },
      (_, r) => contentAt(r, c) ?? '',
    ),
  ),
)

// 空行 = 存在するセルがすべて空で、下書きも無い行（入力中の行は畳まない）
function isEmptyRow(r: number): boolean {
  for (let c = 0; c < props.table.column_count; c++)
    if (contentAt(r, c) || draftAt(r, c) !== undefined) return false
  return true
}
const blocks = computed(() => rowBlocks(props.table.row_count, isEmptyRow))

// 展開した空行。行番号で持つ（入力で塊が分かれても、展開済みの行は開いたままにする）
const expandedRows = reactive(new Set<number>())
type Gap = Extract<RowBlock, { kind: 'gap' }>
const rowsIn = (gap: Gap): number[] =>
  Array.from({ length: gap.count }, (_, i) => gap.start + i)
// 塊の中に展開済みの行が 1 つでもあれば開いている扱いにする
// （入力で分かれた塊が元に戻っても、入力中の行を畳まない）
const isExpanded = (gap: Gap): boolean =>
  rowsIn(gap).some((r) => expandedRows.has(r))

// 描画する並び。行は塊をまたいで行番号をキーにする（入力で塊が分かれても、入力中の <input> を作り直さない）
type Item = { key: string; gap: Gap | null; row: number }
const items = computed<Item[]>(() =>
  blocks.value.flatMap((b): Item[] =>
    b.kind === 'row'
      ? [{ key: `r${b.row}`, gap: null, row: b.row }]
      : [
          { key: `g${b.start}`, gap: b, row: -1 },
          ...(isExpanded(b) ? rowsIn(b) : []).map((r) => ({
            key: `r${r}`,
            gap: null,
            row: r,
          })),
        ],
  ),
)

function setExpanded(gap: Gap, open: boolean): void {
  for (const r of rowsIn(gap)) {
    if (open) expandedRows.add(r)
    else expandedRows.delete(r)
  }
}

// 入力した行は展開済みとして記録する（他の行の入力を経由して塊が組み直されると、この行だけが
// 一度も setExpanded を通らず expandedRows に無いまま空行に戻り、塊に吸われて消えることがあった）
function onCellInput(r: number, c: number, value: string): void {
  expandedRows.add(r)
  bubble({
    type: 'cellInput',
    table: props.tableIndex,
    row: r,
    column: c,
    value,
  })
}

// キャンバスで畳まれた行のセルが選択されたら、その塊を展開する（区分を開く・フォーカスは親が nextTick 後に行う）
watch(
  () => props.focusRequest,
  (request) => {
    const target = request && parseCellId(request.id)
    if (!target || target.table !== props.tableIndex) return
    const gap = blocks.value.find(
      (b): b is Gap =>
        b.kind === 'gap' &&
        target.row >= b.start &&
        target.row < b.start + b.count,
    )
    if (gap) setExpanded(gap, true)
  },
)

// 行内のセル記述子。セルの Map は 1 回だけ引く
function rowCells(r: number) {
  return Array.from({ length: props.table.column_count }, (_, c) => {
    const cell = cells.value.get(`${r}:${c}`)
    const draft = draftAt(r, c)
    const id = cellId(props.tableIndex, r, c)
    const header = cell?.kind === 'columnHeader'
    return {
      column: c,
      exists: cell !== undefined,
      header,
      // 右寄せは元の読取値で判定する（下書きで判定すると入力中に寄せが反転する。列幅と同じ方針）
      numeric: !header && isNumeric(cell?.content ?? ''),
      id,
      value: draft ?? cell?.content ?? '',
      draft: draft !== undefined,
      corrected:
        draft === undefined &&
        props.correctedCells.has(cellKey(props.tableIndex, r, c)),
      active: props.activeId === id,
    }
  })
}
</script>

<template>
  <div
    class="table-block"
    data-testid="grid-table"
    role="group"
    :aria-labelledby="headingId"
  >
    <div :id="headingId" class="text-body-medium text-secondary mb-1">
      表 {{ tableIndex + 1 }}（{{ table.row_count }}行 ×
      {{ table.column_count }}列）
    </div>
    <!-- aria-describedby から直接参照する説明は hidden でよい（d-sr-only だと見出し直後に
         毎回読み上げられてしまう。hidden の要素は参照元からの読み上げ計算にだけ使われる） -->
    <span :id="correctedId" hidden>修正済</span>
    <!-- 列が多く最小幅を割るときだけ、表の中で横スクロールする -->
    <div class="tbl-scroller">
      <div class="tbl" :style="{ '--tbl-columns': columns }">
        <template v-for="{ key, gap, row: r } in items" :key="key">
          <button
            v-if="gap"
            type="button"
            class="tbl-gap text-body-medium text-secondary"
            :aria-expanded="isExpanded(gap)"
            data-testid="grid-gap"
            @click="setExpanded(gap, !isExpanded(gap))"
          >
            <component
              :is="isExpanded(gap) ? PhCaretDown : PhCaretRight"
              :size="12"
              aria-hidden="true"
            />
            空行 {{ gap.count }} 行を{{ isExpanded(gap) ? '隠す' : '表示' }}
          </button>
          <template v-else>
            <template v-for="cell in rowCells(r)" :key="cell.column">
              <div
                v-if="cell.exists"
                class="tbl-cell"
                :class="{
                  'tbl-cell--header': cell.header,
                  'tbl-cell--num': cell.numeric,
                  'tbl-cell--draft': cell.draft,
                  'tbl-cell--corrected': cell.corrected,
                  'target--active': cell.active,
                }"
                :data-target-id="cell.id"
                :title="cell.corrected ? '修正済' : undefined"
                data-testid="grid-cell"
              >
                <input
                  :value="cell.value"
                  :aria-label="`${r + 1}行${cell.column + 1}列`"
                  :aria-current="cell.active ? 'true' : undefined"
                  :aria-describedby="cell.corrected ? correctedId : undefined"
                  :maxlength="CORRECTION_MAX_LENGTH"
                  size="1"
                  data-testid="cell-input"
                  @input="
                    (e) =>
                      onCellInput(
                        r,
                        cell.column,
                        (e.target as HTMLInputElement).value,
                      )
                  "
                  @focus="bubble({ type: 'targetFocus', id: cell.id })"
                />
              </div>
              <!-- DI にセルが無い座標（入力欄なし） -->
              <div
                v-else
                class="tbl-cell tbl-cell--missing"
                data-testid="grid-cell-empty"
              />
            </template>
          </template>
        </template>
      </div>
    </div>
  </div>
</template>

<style scoped>
.table-block + .table-block {
  margin-top: 16px;
}

.tbl-scroller {
  overflow-x: auto;
}

/* 罫線付きの表。列定義は内容の文字幅の比（--tbl-columns）。
   セルの右・下と、表の上・左に線を引いて格子にする。
   罫線はセル（枠の無い入力欄）の境界を兼ねるため、入力欄の枠と同じ濃さにする
   （白地 3.7:1・見出しセルのキャンバス地 3.5:1。WCAG 1.4.11・ADR-0024） */
.tbl {
  --tbl-line: 1px solid rgba(var(--v-theme-on-surface), 0.56);
  display: grid;
  grid-template-columns: var(--tbl-columns);
  width: 100%;
  font-size: 0.875rem;
  border-left: var(--tbl-line);
}

/* 上の線は全トラックにまたがる擬似要素で引く
   （列が多くトラックが .tbl の幅から溢れても、横スクロール部分まで線が届く） */
.tbl::before {
  content: '';
  grid-column: 1 / -1;
  border-top: var(--tbl-line);
}

.tbl-cell,
.tbl-gap {
  border-right: var(--tbl-line);
  border-bottom: var(--tbl-line);
}

.tbl-cell {
  position: relative;
  min-width: 0;
  min-height: 32px;
}

/* size="1" で <input> の既定の固有幅（約 20 文字）が列を押し広げないようにしている。
   左右の余白 4px: 文字 14px で列の多い表が切れないよう詰めている（右ペイン 528px の注文書 6 列で切れ 0） */
.tbl-cell input {
  display: block;
  width: 100%;
  height: 32px;
  padding: 0 4px;
  border: 0;
  outline: 0;
  background: transparent;
  color: inherit;
  font: inherit;
}

/* forced-colors では box-shadow が消えるため、透明の outline を置く（強制配色時だけ見える） */
.tbl-cell input:focus {
  outline: 2px solid transparent;
  outline-offset: -2px;
}

.tbl-cell--header {
  background: rgb(var(--v-theme-canvas));
  font-weight: 500;
}

.tbl-cell--missing {
  background: rgb(var(--v-theme-canvas));
}

.tbl-cell--num input {
  text-align: right;
}

/* 未保存の下書き: 薄い塗り */
.tbl-cell--draft {
  background: rgba(var(--v-theme-primary), 0.08);
}

/* 保存済みの修正: 右上の三角印（装飾。読み上げは aria-describedby の「修正済」） */
.tbl-cell--corrected::after {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  border-style: solid;
  border-width: 0 8px 8px 0;
  border-color: transparent rgb(var(--v-theme-primary)) transparent transparent;
}

/* フォーカス中と、キャンバスと連動して選択中: 主色の 2px 枠 */
.tbl-cell:focus-within,
.tbl-cell.target--active {
  box-shadow: inset 0 0 0 2px rgb(var(--v-theme-primary));
}

.tbl-gap {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  gap: 4px;
  height: 28px;
  padding: 0 4px;
  border-top: 0;
  border-left: 0;
  background: transparent;
  cursor: pointer;
  text-align: left;
}

.tbl-gap:hover,
.tbl-gap:focus-visible {
  background: rgba(var(--v-theme-on-surface), 0.04);
}

.tbl-gap:focus-visible {
  outline: 2px solid rgb(var(--v-theme-primary));
  outline-offset: -2px;
}
</style>
