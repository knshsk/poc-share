<script setup lang="ts">
import { PhWarningCircle } from '@phosphor-icons/vue'
import { onMounted, onUnmounted, ref } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { OverlayRect } from '../utils/runs'
import LoadingSpinner from './LoadingSpinner.vue'

const props = defineProps<{
  page: number
  width: number
  height: number
  // 読取矩形（DI座標系＝インチ。polygonの外接矩形）。ID は utils/runs の fieldId / cellId
  rects?: OverlayRect[]
  // 選択中の矩形 ID
  activeId?: string | null
  // ページ画像の blob URL（Mediator が取得して vm.images に入れる）。null は未取得
  imageUrl?: string | null
  // 画像の取得に失敗した（紙面に失敗を表示する）
  imageFailed?: boolean
}>()

const bubble = useBubble()
const root = ref<SVGSVGElement | null>(null)
// 画像を要求した（表示領域に入った）。要求前のページ（画面外）にはスピナーを出さない
// （画面外のスピナーを「表示中」と数えると、遅延表示の判定で後の読込がすべて「続き」扱いになる）
const requested = ref(false)
let observer: IntersectionObserver | null = null

function requestImage(): void {
  requested.value = true
  bubble({ type: 'pageVisible', page: props.page })
}

onMounted(() => {
  // 表示領域に入った時だけ画像を要求する。閲覧URL経由ではこの取得がpage_view記録になるため、
  // 未表示ページを先読みしない（rootMargin 0・threshold 0＝1pxでも見えたら要求）
  if (typeof IntersectionObserver === 'undefined' || !root.value) {
    requestImage()
    return
  }
  observer = new IntersectionObserver((entries) => {
    if (!observer || !entries.some((entry) => entry.isIntersecting)) return
    observer.disconnect()
    observer = null
    requestImage()
  })
  observer.observe(root.value)
})

onUnmounted(() => {
  observer?.disconnect()
  observer = null
})
</script>

<template>
  <!-- 紙面（svg）の上に状態（取得中のスピナー / 取得失敗）を重ねる -->
  <div class="page">
    <!-- viewBoxをDI座標系（インチ）に合わせ、rect座標を無変換で使えるようにする -->
    <svg
      ref="root"
      :viewBox="`0 0 ${width} ${height}`"
      xmlns="http://www.w3.org/2000/svg"
      class="page-svg"
    >
      <image
        v-if="imageUrl"
        :href="imageUrl"
        :width="width"
        :height="height"
        x="0"
        y="0"
      />
      <!-- 矩形はキーボードでも選択可能（Tab で到達、Enter / Space でクリックと同じ）。<title> がツールチップ兼アクセシブル名 -->
      <rect
        v-for="rect in rects ?? []"
        :key="rect.id"
        :data-rect-id="rect.id"
        :x="rect.x"
        :y="rect.y"
        :width="rect.width"
        :height="rect.height"
        :class="[
          'overlay-rect',
          `overlay-rect--${rect.kind}`,
          { 'overlay-rect--active': rect.id === activeId },
        ]"
        tabindex="0"
        role="button"
        @click="bubble({ type: 'rectClick', id: rect.id })"
        @keydown.enter.space.prevent="
          bubble({ type: 'rectClick', id: rect.id })
        "
      >
        <title>{{ rect.label }}</title>
      </rect>
    </svg>
    <div v-if="imageFailed" class="page-state" data-testid="page-image-failed">
      <PhWarningCircle :size="32" class="text-error mb-2" aria-hidden="true" />
      <p class="text-body-medium">ページを表示できませんでした</p>
    </div>
    <div v-else-if="requested && !imageUrl" class="page-state">
      <LoadingSpinner />
    </div>
  </div>
</template>

<style scoped>
.page {
  position: relative;
}

.page-svg {
  width: 100%;
  height: auto;
  display: block;
  border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* 取得中のスピナー・取得失敗は紙面の縦横中央に重ねる（下の矩形の操作を妨げない） */
.page-state {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}

/* 読取矩形の色はテーマトークン参照（--v-theme-primaryはカンマ区切りRGB値）。
   常時は薄く、ホバーで強調、選択中は塗り＋太枠。semantic color（warning 等）は使わない */
.overlay-rect {
  /* tabindex でクリック時にもフォーカスされる。ブラウザ既定のフォーカスリングは viewBox（インチ）の拡大で
     巨大な黒枠になるため常に消し、キーボードフォーカスは :focus-visible の太枠で示す */
  outline: none;
  fill: rgba(var(--v-theme-primary), 0.06);
  stroke: rgba(var(--v-theme-primary), 0.45);
  stroke-width: 0.012;
  cursor: pointer;
  transition: fill 0.12s ease;
}

/* キー項目は破線、セルは実線 */
.overlay-rect--field {
  stroke-dasharray: 0.04 0.03;
}

.overlay-rect:hover {
  fill: rgba(var(--v-theme-primary), 0.18);
}

.overlay-rect--active,
.overlay-rect:focus-visible {
  fill: rgba(var(--v-theme-primary), 0.32);
  stroke: rgb(var(--v-theme-primary-darken-1));
  stroke-width: 0.03;
  stroke-dasharray: none;
}
</style>
