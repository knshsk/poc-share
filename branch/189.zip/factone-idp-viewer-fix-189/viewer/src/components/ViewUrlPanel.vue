<script setup lang="ts">
import { PhCopy, PhLinkSimple } from '@phosphor-icons/vue'
import { ref } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { ViewUrlSummary } from '../mediator/model'
import type { ViewUrlsVm } from '../mediator/vm'
import { formatDateTime } from '../utils/format'
import { useReturnFocus } from '../utils/returnFocus'

// 発行・一覧・失効は Mediator が行う。View は一覧の状態表示と操作の通知だけ
const props = defineProps<{ vm: ViewUrlsVm }>()

const bubble = useBubble()
const issueButton = ref<{ $el: HTMLElement } | null>(null)

// 失効の確認を閉じたら、開く前の要素（行の「失効させる」）へフォーカスを戻す。失効を確定したときは、その行の
// 「失効させる」が一覧の再取得で消えるので、戻さずに「閲覧URL発行」へ移す（戻した後に消えると行き場を失う）
const forgetOpener = useReturnFocus(
  () => props.vm.revokeTarget !== null,
  () => issueButton.value?.$el,
)

function confirmRevoke(): void {
  forgetOpener()
  bubble({ type: 'confirmRevoke' })
}

// 期限判定はクライアント時刻
function isExpired(url: ViewUrlSummary): boolean {
  return new Date(url.expires_at).getTime() <= Date.now()
}

function statusLabel(url: ViewUrlSummary): string {
  if (url.revoked) return '失効済み'
  if (isExpired(url)) return '期限切れ'
  return '有効'
}

// 使えない URL（失効済み・期限切れ）は無彩色、有効だけ success。赤は操作（失効させる）に限り、
// 状態と操作が同じ語・同じ色で並ばないようにする
function statusColor(url: ViewUrlSummary): string {
  return url.revoked || isExpired(url) ? 'secondary' : 'success'
}
</script>

<template>
  <div>
    <div class="d-flex align-center mb-2">
      <v-btn
        ref="issueButton"
        color="primary"
        variant="tonal"
        data-testid="issue-view-url"
        :loading="vm.issuing"
        :disabled="vm.issuing"
        @click="bubble({ type: 'issueViewUrl' })"
      >
        <PhLinkSimple :size="16" class="mr-1" />
        閲覧URL発行
      </v-btn>
    </div>
    <v-alert
      v-if="vm.error"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-2"
    >
      {{ vm.error }}
    </v-alert>

    <div v-if="vm.issuedUrl" class="issued-block mb-3">
      <div class="d-flex align-center ga-2">
        <code class="font-mono issued-url" data-testid="issued-url">{{
          vm.issuedUrl
        }}</code>
        <v-btn
          data-testid="copy-view-url"
          size="small"
          variant="text"
          aria-label="コピー"
          @click="bubble({ type: 'copyIssuedUrl' })"
        >
          <PhCopy :size="16" class="mr-1" />
          コピー
        </v-btn>
      </div>
      <p class="text-body-medium text-warning mt-3">
        このURLは再表示できません。今すぐコピーしてください
      </p>
    </div>

    <!-- 副題を Vuetify の副題の透明度で薄めない（本文との区別は secondary 色） -->
    <v-list
      v-if="vm.urls.length > 0"
      density="compact"
      class="pa-0"
      :style="{ '--v-list-item-subtitle-opacity': 1 }"
    >
      <v-list-item
        v-for="url in vm.urls"
        :key="url.id"
        data-testid="view-url-row"
        class="px-0"
      >
        <v-list-item-title class="text-body-medium">
          {{ formatDateTime(url.issued_at) }}
        </v-list-item-title>
        <v-list-item-subtitle class="text-body-medium text-secondary">
          期限: {{ formatDateTime(url.expires_at) }}
        </v-list-item-subtitle>
        <template #append>
          <v-chip size="small" variant="tonal" :color="statusColor(url)">
            {{ statusLabel(url) }}
          </v-chip>
          <v-btn
            v-if="!url.revoked && !isExpired(url)"
            data-testid="revoke-view-url"
            size="small"
            variant="text"
            color="error"
            class="ml-2"
            @click="bubble({ type: 'revokeViewUrl', viewUrlId: url.id })"
          >
            失効させる
          </v-btn>
        </template>
      </v-list-item>
    </v-list>

    <!-- 失効は取消不可のため確認ダイアログを挟む -->
    <v-dialog
      :model-value="vm.revokeTarget !== null"
      max-width="400"
      aria-labelledby="revoke-dialog-title"
      @update:model-value="
        (v: boolean) => !v && bubble({ type: 'cancelRevoke' })
      "
    >
      <v-card>
        <v-card-title id="revoke-dialog-title" class="text-title-medium">
          閲覧URLを失効させますか？
        </v-card-title>
        <v-card-text class="text-body-medium text-secondary">
          失効すると得意先はこのURLで閲覧できなくなります。取消はできません。
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn
            data-testid="revoke-cancel"
            @click="bubble({ type: 'cancelRevoke' })"
          >
            キャンセル
          </v-btn>
          <v-btn
            color="error"
            variant="flat"
            data-testid="revoke-confirm"
            @click="confirmRevoke"
          >
            失効させる
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<style scoped>
.issued-url {
  overflow-wrap: anywhere;
  font-size: 0.875rem;
}
</style>
