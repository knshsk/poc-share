<script lang="ts">
import { createSpinnerClock } from '../utils/spinnerClock'

// 全スピナーで 1 つを共有する（読込の続きかどうかを、他のスピナーの表示状況で判定する）。
// 起動時刻はモジュールの評価時（アプリの起動時）
const clock = createSpinnerClock(performance.now())
</script>

<script setup lang="ts">
import { onUnmounted } from 'vue'

// 読込中の表示の共通部品。色・大きさ・名前をここで統一する。遅延表示の規則は utils/spinnerClock.ts
const now = performance.now()
const entry = clock.appear(now)
const wait = entry.visibleAt - now
onUnmounted(() => clock.gone(entry, performance.now()))
</script>

<template>
  <v-progress-circular
    indeterminate
    color="primary"
    size="40"
    width="4"
    aria-label="読み込み中"
    data-testid="loading-spinner"
    :class="{ 'loading-spinner--wait': wait > 0 }"
    :style="wait > 0 ? { '--loading-spinner-wait': `${wait}ms` } : undefined"
  />
</template>

<style scoped>
/* 待ちの間は透明で、その後 150ms でフェードインする（待ちの間に消えれば一度も見えない） */
.loading-spinner--wait {
  animation: loading-spinner-in 150ms ease var(--loading-spinner-wait) both;
}

@keyframes loading-spinner-in {
  from {
    opacity: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .loading-spinner--wait {
    animation-duration: 1ms;
  }
}
</style>
