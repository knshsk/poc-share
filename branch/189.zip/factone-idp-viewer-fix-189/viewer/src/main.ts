import '@fontsource/ibm-plex-sans-jp/400.css'
import '@fontsource/ibm-plex-sans-jp/500.css'
import '@fontsource/ibm-plex-sans-jp/700.css'
import '@fontsource/ibm-plex-mono/400.css'
import './assets/main.css'

import { createApp } from 'vue'

import { createAppVuetify } from './plugins/vuetify'
import Root from './Root.vue'

createApp(Root).use(createAppVuetify()).mount('#app')
