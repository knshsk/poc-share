import { inject, provide, type InjectionKey } from 'vue'

import type { AppEvent } from './events'

export type Dispatch = (e: AppEvent) => void

// 鎖の終点。Root が mediator.dispatch を provide する
export const BUBBLE: InjectionKey<Dispatch> = Symbol('bubble')

const noop: Dispatch = () => {}

// Chain of Responsibility: 自ノードの handle が true を返せば停止、それ以外は直近祖先の bubble へ委譲する。
// provide/inject は Vue のコンポーネント親子で解決するため、v-dialog 等の Teleport 越しでも鎖は切れない
export function useBubble(handle?: (e: AppEvent) => boolean): Dispatch {
  const parent = inject(BUBBLE, noop)
  const bubble: Dispatch = (e) => {
    if (handle?.(e)) return
    parent(e)
  }
  provide(BUBBLE, bubble)
  return bubble
}
