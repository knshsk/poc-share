import { reactive, ref, type ComputedRef, type Ref } from 'vue'

import { createOidc, type Oidc } from '../auth/oidc'
import type { Dispatch } from './bubble'
import type { AppEvent } from './events'
import { authHandlers } from './handlers/auth'
import { documentHandlers } from './handlers/document'
import { publicHandlers } from './handlers/public'
import { runHandlers } from './handlers/runs'
import { viewUrlHandlers } from './handlers/viewUrls'
import { draftCount, initialModel, type Model, type State } from './model'
import { buildVm, type RootVm } from './vm'

export interface Ctx {
  state: Ref<State>
  model: Model
  oidc: Oidc
  dispatch: Dispatch
}

// 遷移表の 1 行。in に現状態が無ければ dispatch は黙って捨てる（＝裁定）。run は同期で、
// API 呼出は void promise.then(ok => dispatch(完了イベント), () => dispatch(失敗イベント)) の形で投げる
export interface Entry<E extends AppEvent = AppEvent> {
  in: readonly State[] | '*'
  run: (ctx: Ctx, e: E) => void
}

export type Handlers = {
  [K in AppEvent['type']]?: Entry<Extract<AppEvent, { type: K }>>
}

export interface Mediator {
  state: Ref<State>
  vm: ComputedRef<RootVm>
  dispatch: Dispatch
}

// 未保存の変更があれば操作を保留して確認ダイアログへ（confirmProceed で再 dispatch、confirmCancel で破棄）
export function guardDirty(ctx: Ctx, e: AppEvent): boolean {
  if (draftCount(ctx.model.draft) === 0) return false
  ctx.model.pendingEvent = e
  ctx.state.value = 'confirmDiscard'
  return true
}

export function createMediator(oidc: Oidc = createOidc()): Mediator {
  const state = ref<State>('booting')
  const model = reactive(initialModel()) as Model
  const table: Handlers = {
    ...authHandlers,
    ...publicHandlers,
    ...documentHandlers,
    ...runHandlers,
    ...viewUrlHandlers,
  }

  function dispatch(e: AppEvent): void {
    const entry = table[e.type] as Entry | undefined
    if (!entry) return
    if (entry.in !== '*' && !entry.in.includes(state.value)) return
    entry.run(ctx, e)
  }

  const ctx: Ctx = { state, model, oidc, dispatch }
  return { state, vm: buildVm(state, model), dispatch }
}
