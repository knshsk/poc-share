import { apiClient } from '../../api/client'
import type { Ctx, Handlers } from '../machine'
import { SETTLING, WORKING } from '../model'

export function loadViewUrls(ctx: Ctx): void {
  const documentId = ctx.model.documentId
  ctx.model.viewUrls.error = null
  void apiClient
    .GET('/api/v1/documents/{document_id}/view-urls', {
      params: { path: { document_id: documentId } },
    })
    .then(
      ({ data, error }) =>
        ctx.dispatch(
          error || !data
            ? { type: 'viewUrlsFailed', documentId }
            : { type: 'viewUrlsLoaded', documentId, urls: data },
        ),
      () => ctx.dispatch({ type: 'viewUrlsFailed', documentId }),
    )
}

export const viewUrlHandlers: Handlers = {
  viewUrlsLoaded: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.viewUrls.urls = e.urls
      ctx.model.viewUrls.loadedFor = e.documentId
    },
  },
  viewUrlsFailed: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.viewUrls.error = '閲覧URL一覧を取得できませんでした'
    },
  },
  issueViewUrl: {
    in: WORKING,
    run(ctx) {
      const m = ctx.model
      const documentId = m.documentId
      m.viewUrls.error = null
      m.viewUrls.issuing = true
      void apiClient
        .POST('/api/v1/documents/{document_id}/view-urls', {
          params: { path: { document_id: documentId } },
        })
        .then(
          ({ data, error }) =>
            ctx.dispatch(
              error || !data
                ? { type: 'viewUrlIssueFailed', documentId }
                : {
                    type: 'viewUrlIssued',
                    documentId,
                    viewPath: data.view_path,
                  },
            ),
          () => ctx.dispatch({ type: 'viewUrlIssueFailed', documentId }),
        )
    },
  },
  // 発行直後の平文 URL は再表示不可（サーバはハッシュのみ保持）のため発行時だけ持つ。発行後は一覧を再取得する
  viewUrlIssued: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      const v = ctx.model.viewUrls
      v.issuing = false
      v.issuedUrl = `${window.location.origin}${e.viewPath}`
      loadViewUrls(ctx)
    },
  },
  viewUrlIssueFailed: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.viewUrls.issuing = false
      ctx.model.viewUrls.error = '閲覧URLの発行に失敗しました'
    },
  },
  copyIssuedUrl: {
    in: WORKING,
    run(ctx) {
      const url = ctx.model.viewUrls.issuedUrl
      if (url) void navigator.clipboard.writeText(url)
    },
  },
  // 失効は取消不可のため確認ダイアログ（revokeTarget が対象 ID。null で非表示）を挟む
  revokeViewUrl: {
    in: WORKING,
    run(ctx, e) {
      ctx.model.viewUrls.revokeTarget = e.viewUrlId
    },
  },
  cancelRevoke: {
    in: WORKING,
    run(ctx) {
      ctx.model.viewUrls.revokeTarget = null
    },
  },
  confirmRevoke: {
    in: WORKING,
    run(ctx) {
      const v = ctx.model.viewUrls
      const target = v.revokeTarget
      if (!target) return
      const documentId = ctx.model.documentId
      v.revokeTarget = null
      v.error = null
      void apiClient
        .POST('/api/v1/view-urls/{view_url_id}/revoke', {
          params: { path: { view_url_id: target } },
        })
        .then(
          ({ error }) =>
            ctx.dispatch(
              error
                ? { type: 'viewUrlRevokeFailed', documentId }
                : { type: 'viewUrlRevoked', documentId },
            ),
          () => ctx.dispatch({ type: 'viewUrlRevokeFailed', documentId }),
        )
    },
  },
  // 文書切替後に届いた失効応答は捨てる（別文書の一覧を再取得したり、失効エラーを誤表示しない）
  viewUrlRevoked: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      loadViewUrls(ctx)
    },
  },
  viewUrlRevokeFailed: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.viewUrls.error = '閲覧URLの失効に失敗しました'
    },
  },
}
