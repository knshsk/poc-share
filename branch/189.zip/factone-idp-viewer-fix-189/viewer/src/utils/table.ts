// 表（DI 認識テーブル）の描画用の純関数

// 文字幅の概算（ch 単位）。全角 1 文字は半角数字（1ch）の約 1.7 倍幅
export function textWidth(text: string): number {
  return [...text].reduce((n, c) => n + (c.charCodeAt(0) > 0xff ? 1.7 : 1), 0)
}

const MIN_CH = 3
const MAX_CH = 24
const PADDING_CH = 2
const FLOOR_CH = 8

// 列幅は内容の最大文字幅の比（fr）で配分する。ペイン幅に必ず収まり、列が多く最小幅（8ch まで）を
// 割るときだけ表の中で横スクロールになる。contents(c) は c 列目の各セルの文字列
export function columnTemplate(
  columnCount: number,
  contents: (column: number) => string[],
): string {
  return Array.from({ length: columnCount }, (_, c) => {
    const widest = Math.max(MIN_CH, ...contents(c).map(textWidth))
    const w = Math.ceil(Math.min(MAX_CH, widest)) + PADDING_CH
    return `minmax(${Math.min(w, FLOOR_CH)}ch, ${w}fr)`
  }).join(' ')
}

export type RowBlock =
  { kind: 'row'; row: number } | { kind: 'gap'; start: number; count: number }

// 連続する空行を 1 つの塊（gap）にまとめる
export function rowBlocks(
  rowCount: number,
  isEmpty: (row: number) => boolean,
): RowBlock[] {
  const blocks: RowBlock[] = []
  for (let row = 0; row < rowCount; row++) {
    const last = blocks[blocks.length - 1]
    if (!isEmpty(row)) blocks.push({ kind: 'row', row })
    else if (last?.kind === 'gap') last.count++
    else blocks.push({ kind: 'gap', start: row, count: 1 })
  }
  return blocks
}

// 数値らしいセル（右寄せにする）。数字を含み、¥・桁区切り・小数点・符号・空白だけでできている
export function isNumeric(text: string): boolean {
  return /\d/.test(text) && /^[¥\\\d,.\-\s]+$/.test(text)
}
