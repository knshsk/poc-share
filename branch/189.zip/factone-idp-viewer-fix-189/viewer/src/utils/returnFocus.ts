import { onBeforeUnmount, watch } from 'vue'

// :model-value だけで開くダイアログ（activator なし）は、閉じても Vuetify がフォーカスを戻さない（VOverlay が
// 戻す先は activatorEl だけ）。開いた時点でフォーカスのあった要素を覚え、閉じたらそこへ戻す。戻せないとき
// （自動で開いた・要素が消えた・隠れた・無効になった）は fallback へ移す。移す時点は Vuetify が activator へ
// 戻すのと同じく閉じた時点（退場の演出の前）で、閉じる操作で変わった後の描画を見て判定する。
// 戻り値は覚えた要素を捨てる関数。確定するとその要素が後から消えるダイアログが、閉じる前に呼ぶ
export function useReturnFocus(
  isOpen: () => boolean,
  fallback: () => HTMLElement | null | undefined,
): () => void {
  let opener: HTMLElement | null = null

  // 画面から消えた要素・無効な要素への focus() は何もしないので、当たったかどうかで判定する
  function restore(): void {
    opener?.focus()
    if (document.activeElement !== opener) fallback()?.focus()
    opener = null
  }

  watch(
    isOpen,
    (open) => {
      if (!open) return restore()
      const el = document.activeElement
      opener = el === document.body ? null : (el as HTMLElement | null)
    },
    { flush: 'post' },
  )

  // 開いたまま部品ごと消えたとき（未保存の変更の確認から文書を切り替えて右ペインが消えた）は、閉じる変化が来ない
  onBeforeUnmount(() => {
    if (isOpen()) restore()
  })

  return () => {
    opener = null
  }
}
