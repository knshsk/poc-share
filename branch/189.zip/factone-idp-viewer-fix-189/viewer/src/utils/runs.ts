import type { components } from '../api/schema'

export type IdpRun = components['schemas']['IdpRunResponse']
export type IdpRunSummary = components['schemas']['IdpRunSummary']
export type Corrections = components['schemas']['CorrectionRequest']
export type TableCell = components['schemas']['TableCell']

export const RUN_TYPE_LABEL: Record<IdpRunSummary['run_type'], string> = {
  initial: '初回',
  rerun: '再実行',
  corrected: '修正',
}

// 修正文字数の上限。サーバ側 CorrectionText（api/app/routers/idp_runs.py）の max_length と一致させる
export const CORRECTION_MAX_LENGTH = 2000

// キャンバス⇄右ペインの相互ハイライトで使う要素 ID（draft の cellKey "t:r:c" とは別物）
export const fieldId = (key: string): string => `field:${key}`
export const cellId = (table: number, row: number, col: number): string =>
  `cell:${table}:${row}:${col}`

// cellId の逆変換。セル以外の ID（field:…）は null
export function parseCellId(
  id: string,
): { table: number; row: number; column: number } | null {
  const m = /^cell:(\d+):(\d+):(\d+)$/.exec(id)
  return m
    ? { table: Number(m[1]), row: Number(m[2]), column: Number(m[3]) }
    : null
}

// キャンバス上の読取矩形。座標は DI 座標系（インチ）のまま。PageSvg の viewBox と同一単位
export interface OverlayRect {
  id: string
  kind: 'field' | 'cell'
  // アクセシブル名（<title>）。キー項目 = ラベル（無ければキー）、セル = 「表 n の r 行 c 列」（1 始まり）
  label: string
  x: number
  y: number
  width: number
  height: number
}

// DI polygon（x, y の交互配列）の外接矩形
export function polygonToRect(
  polygon: number[],
): Omit<OverlayRect, 'id' | 'kind' | 'label'> {
  const xs = polygon.filter((_, i) => i % 2 === 0)
  const ys = polygon.filter((_, i) => i % 2 === 1)
  const x = Math.min(...xs)
  const y = Math.min(...ys)
  return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y }
}

// 選択中の成功実行からページ番号ごとの矩形を作る。
// セル = polygon あり全件、キー項目 = region あり・visible=true（hiddenKeys 外）・value 非 null。
// region / polygon は verbose=true の応答にだけ含まれる。無ければ矩形なし。
// セルを先・キー項目を後に並べる（重なり時にキー項目が前面）。失敗実行・未選択は空
export function overlayRectsByPage(
  run: IdpRun | null,
  hiddenKeys: ReadonlySet<string>,
): Map<number, OverlayRect[]> {
  const byPage = new Map<number, OverlayRect[]>()
  if (!run || run.status !== 'succeeded') return byPage
  const push = (page: number, rect: OverlayRect): void => {
    const list = byPage.get(page) ?? []
    list.push(rect)
    byPage.set(page, list)
  }
  ;(run.tables ?? []).forEach((table, t) => {
    for (const cell of table.cells) {
      if (!cell.polygon || cell.polygon.length < 4 || cell.page_number == null)
        continue
      push(cell.page_number, {
        id: cellId(t, cell.row_index, cell.column_index),
        kind: 'cell',
        label: `表 ${t + 1} の ${cell.row_index + 1} 行 ${cell.column_index + 1} 列`,
        ...polygonToRect(cell.polygon),
      })
    }
  })
  for (const [key, field] of Object.entries(run.fields ?? {})) {
    const region = field.region
    if (
      !region ||
      region.polygon.length < 4 ||
      hiddenKeys.has(key) ||
      field.value == null
    )
      continue
    push(region.page_number, {
      id: fieldId(key),
      kind: 'field',
      label: field.label ?? key,
      ...polygonToRect(region.polygon),
    })
  }
  return byPage
}

// 表のセルの下書きキー（table_index:row_index:column_index）。ハイライト ID の cellId とは別物
export function cellKey(t: number, r: number, c: number): string {
  return `${t}:${r}:${c}`
}

// 表示対象のキー項目: 現在の文書種別設定の順（応答の fields は JSONB 由来でキー順が設定順にならない）。
// 設定に無いキー（設定変更後）は末尾、visible=false は除く
export function visibleFieldKeys(
  run: IdpRun,
  fieldDefs: { key: string; visible: boolean }[],
): string[] {
  const keys = Object.keys(run.fields ?? {})
  const configured = fieldDefs.map((f) => f.key).filter((k) => keys.includes(k))
  const hidden = new Set(fieldDefs.filter((f) => !f.visible).map((f) => f.key))
  return [...configured, ...keys.filter((k) => !configured.includes(k))].filter(
    (k) => !hidden.has(k),
  )
}

// 入力欄の元値: 正規化値（文字列化）、無ければ DI の読取値。差分判定もこの値を基準にする
export function originalValue(run: IdpRun, key: string): string | null {
  const field = run.fields?.[key]
  const normalized = field?.normalized_value
  if (normalized != null) return String(normalized)
  return field?.value ?? null
}

// cellInput ハンドラが入力ごとに 1 回呼ぶ線形探索（描画側は ResultTable が持つ Map を使うため対象外）
export function cellAt(
  run: IdpRun,
  t: number,
  r: number,
  c: number,
): TableCell | null {
  return (
    run.tables?.[t]?.cells.find(
      (x) => x.row_index === r && x.column_index === c,
    ) ?? null
  )
}
