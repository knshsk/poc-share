import { formatConfidence } from './format'

// これ未満の確信度を「要確認」として目立たせる。確信度の閾値はここが唯一の定義
export const LOW_CONFIDENCE = 0.8

export interface FieldStatus {
  kind: 'draft' | 'corrected' | 'empty' | 'low' | 'ok'
  text: string
}

// キー項目の状態表示。優先順位は 未保存 > 修正済 > 未読取 > 確信度
export function fieldStatus(input: {
  draft: boolean // 未保存の下書きがある
  corrected: boolean // 保存済みの人手修正に含まれる
  value: string | null // fields[key].value（DI の読取値）
  confidence: number | null
}): FieldStatus {
  if (input.draft) return { kind: 'draft', text: '未保存' }
  if (input.corrected) return { kind: 'corrected', text: '修正済' }
  if (input.value == null) return { kind: 'empty', text: '未読取' }
  // 確信度を持たない値に「要確認 0%」を出さない
  if (input.confidence == null) return { kind: 'ok', text: '' }
  const percent = formatConfidence(input.confidence)
  return input.confidence < LOW_CONFIDENCE
    ? { kind: 'low', text: `要確認 ${percent}` }
    : { kind: 'ok', text: percent }
}
