// 表示用フォーマッタ。確信度の閾値は utils/fieldStatus.ts（LOW_CONFIDENCE）が唯一の定義
export function formatConfidence(value: number | null | undefined): string {
  if (value == null) return '-'
  return `${Math.round(value * 100)}%`
}

export function formatDateTime(value: string): string {
  return new Date(value).toLocaleString()
}
