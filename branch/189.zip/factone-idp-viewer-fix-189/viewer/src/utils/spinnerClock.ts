// スピナーの遅延表示の判定（時刻は ms。呼び出し側が performance.now() を渡す）。
// 新しいスピナーは SPINNER_DELAY 待ってから出す（その間に読込が終われば一度も見えない。高速回線のちらつき防止）。
// ただし表示済み（SHOWN 以上見えていた）のスピナーが今も出ている、または HANDOFF 未満の間まで出ていたときは
// 読込の続きとみなして待たずに出す（段階の切替でスピナーが一度消えて点滅しない）
export const SPINNER_DELAY = 300
const SHOWN = 100
const HANDOFF = 100
// index.html の起動スプラッシュは CSS の animation-delay で navigation 開始からおよそ 300ms 後に見える
const SPLASH_VISIBLE_AT = 300

type Entry = { visibleAt: number }

const shown = (entry: Entry, now: number): boolean =>
  now - entry.visibleAt >= SHOWN

// startedAt: アプリの起動時刻。起動時点でスプラッシュが表示済みなら、その直後（続き）とみなす
export function createSpinnerClock(startedAt: number) {
  const live = new Set<Entry>()
  let lastShownGone = shown({ visibleAt: SPLASH_VISIBLE_AT }, startedAt)
    ? startedAt
    : -Infinity
  return {
    appear(now: number) {
      const continuing =
        [...live].some((entry) => shown(entry, now)) ||
        now - lastShownGone < HANDOFF
      const entry = { visibleAt: continuing ? now : now + SPINNER_DELAY }
      live.add(entry)
      return entry
    },
    gone(entry: Entry, now: number) {
      live.delete(entry)
      if (shown(entry, now)) lastShownGone = now
    },
  }
}
