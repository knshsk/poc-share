import { flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import ResultEditor from '../src/components/ResultEditor.vue'
import ResultTable from '../src/components/ResultTable.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { EditorVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import type { IdpRun } from '../src/utils/runs'
import { editorVm } from './fixtures'

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  fields: {
    TotalAmount: {
      value: '1,200,000',
      normalized_value: 1200000,
      confidence: 0.96,
      label: '合計金額',
      region: null,
    },
    DeliveryDate: {
      value: '2026-10-30',
      normalized_value: '2026-10-30',
      confidence: 0.85,
      label: '納品期限',
      region: null,
    },
    Note: {
      value: null,
      normalized_value: null,
      confidence: null,
      region: null,
    },
    Hidden: {
      value: 'secret',
      normalized_value: 'secret',
      confidence: 0.5,
      region: null,
    },
  },
  tables: [
    {
      row_count: 2,
      column_count: 2,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: '品目',
          kind: 'columnHeader',
          page_number: 1,
          polygon: [1, 2, 3, 2],
        },
        {
          row_index: 1,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'P-9001',
          kind: null,
          page_number: 1,
          polygon: [1, 3, 3, 3],
        },
      ],
    },
  ],
  pattern_matches: {
    TCode: { label: '登録番号', regex: 'T\\d{13}', values: ['T1234567890123'] },
    QuotationNo: { label: '見積番号', regex: 'Q-\\d{6}', values: [] },
  },
  corrections: null,
}

const fieldDefs = [
  {
    key: 'TotalAmount',
    label: '合計金額',
    type: 'number' as const,
    visible: true,
  },
  {
    key: 'DeliveryDate',
    label: '納品期限',
    type: 'date' as const,
    visible: true,
  },
  { key: 'Note', label: '備考', type: 'string' as const, visible: true },
  { key: 'Hidden', label: '非表示', type: 'string' as const, visible: false },
]

const bubble = vi.fn()

function vmOf(over: Partial<EditorVm> = {}, runOver: Partial<IdpRun> = {}) {
  return editorVm({ run: { ...run, ...runOver }, fieldDefs, ...over })
}

function mountEditor(
  over: Partial<EditorVm> = {},
  runOver: Partial<IdpRun> = {},
  attachTo?: HTMLElement,
  stubs?: Record<string, boolean>,
) {
  return mount(ResultEditor, {
    props: { vm: vmOf(over, runOver) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
      stubs,
    },
    attachTo,
  })
}

function cellInputs(wrapper: ReturnType<typeof mountEditor>) {
  return wrapper.findAll('[data-testid="cell-input"]')
}

describe('ResultEditor', () => {
  beforeEach(() => {
    bubble.mockClear()
  })

  afterEach(() => {
    // @ts-expect-error jsdom に無いメソッドを差し込んだテストの後始末
    delete Element.prototype.scrollIntoView
    vi.unstubAllGlobals()
  })

  it('キー項目の区分に表示対象の件数を出す', () => {
    expect(
      mountEditor().get('[data-testid="section-fields"]').text(),
    ).toContain('3件')
  })

  // 値の表示なのでチップではなく読取専用の入力欄（選択・コピー可）。複数は縦に並べ、0 件は「一致なし」
  it('候補値を読取専用の入力欄で表示し、0 件は「一致なし」と表示する', () => {
    const wrapper = mountEditor(
      {},
      {
        pattern_matches: {
          TCode: {
            label: '登録番号',
            regex: 'T\\d{13}',
            values: ['T1234567890123', 'T9876543210987'],
          },
          QuotationNo: { label: '見積番号', regex: 'Q-\\d{6}', values: [] },
        },
      },
    )
    const rows = wrapper.findAll('[data-testid="candidate-row"]')
    expect(rows).toHaveLength(2)
    const values = rows[0]!.findAll('[data-testid="candidate-value"] input')
    expect(values.map((v) => (v.element as HTMLInputElement).value)).toEqual([
      'T1234567890123',
      'T9876543210987',
    ])
    expect(values[0]!.attributes('readonly')).toBeDefined()
    expect(values[0]!.attributes('aria-label')).toBe('登録番号の候補値')
    expect(rows[1]!.text()).toContain('一致なし')
    expect(wrapper.find('.v-chip').exists()).toBe(false)
    // パターンの正規表現そのものは表示しない（値だけ見せる）
    expect(wrapper.text()).not.toContain('\\d{13}')
  })

  it('区分名は「キー項目」「候補値」「表」', () => {
    const wrapper = mountEditor()
    expect(wrapper.get('[data-testid="section-fields"]').text()).toContain(
      'キー項目',
    )
    expect(wrapper.get('[data-testid="section-candidates"]').text()).toContain(
      '候補値',
    )
    expect(wrapper.get('[data-testid="section-grid"]').text()).toMatch(
      /表\s*1件/,
    )
    expect(wrapper.text()).not.toContain('グリッド')
    expect(wrapper.text()).not.toContain('キー項目候補')
  })

  // 表の中身は ResultTable のテストで検証する。ここでは表ごとに props を分けて渡すことを確認する
  it('表ごとに ResultTable を描画し、保存済みの修正セルを渡す', () => {
    const wrapper = mountEditor(
      { draftCells: { '0:1:0': 'x' }, activeId: 'cell:0:1:0' },
      {
        corrections: {
          fields: {},
          table_cells: [
            {
              table_index: 0,
              row_index: 1,
              column_index: 0,
              content: 'P-9002',
            },
          ],
        },
      },
    )
    const tables = wrapper.findAllComponents(ResultTable)
    expect(tables).toHaveLength(1)
    expect(tables[0]!.props()).toMatchObject({
      tableIndex: 0,
      draftCells: { '0:1:0': 'x' },
      activeId: 'cell:0:1:0',
    })
    expect([...tables[0]!.props('correctedCells')]).toEqual(['0:1:0'])
  })

  it('テーブルが無いときはテーブル未検出と表示する', () => {
    const wrapper = mountEditor({}, { tables: [] })
    expect(wrapper.get('[data-testid="section-grid"]').text()).toContain(
      'テーブル未検出',
    )
  })

  // キャンバス側の要求（focusRequest）で該当入力欄へスクロールしフォーカスする
  it('focusRequest で該当入力欄を scrollIntoView してフォーカスする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, {}, host)
    try {
      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:1:0', seq: 1 } }),
      })
      await wrapper.vm.$nextTick()

      const input = cellInputs(wrapper)[1]!.element
      expect(document.activeElement).toBe(input)
      expect(scrollSpy).toHaveBeenCalledTimes(1)
      expect(scrollSpy.mock.instances[0]).toBe(input)
      expect(scrollSpy).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'smooth' }),
      )
    } finally {
      wrapper.unmount()
      host.remove()
    }
  })

  it('reduced-motion 指定時は behavior auto でスクロールする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    vi.stubGlobal('matchMedia', () => ({ matches: true }))
    const wrapper = mountEditor()
    await wrapper.setProps({
      vm: vmOf({ focusRequest: { id: 'field:TotalAmount', seq: 1 } }),
    })
    await wrapper.vm.$nextTick()
    expect(scrollSpy).toHaveBeenCalledWith(
      expect.objectContaining({ behavior: 'auto' }),
    )
  })

  // 折りたたみ中の区分に focusRequest が来たら区分を開いてからフォーカスする
  it('折りたたみ中の区分への focusRequest で区分を開いてフォーカスする', async () => {
    Element.prototype.scrollIntoView = vi.fn()
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, {}, host)
    try {
      await wrapper
        .get('[data-testid="section-grid"] .v-expansion-panel-title')
        .trigger('click')
      await wrapper.vm.$nextTick()

      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:1:0', seq: 1 } }),
      })
      await wrapper.vm.$nextTick()

      expect(document.activeElement).toBe(cellInputs(wrapper)[1]!.element)
      expect(wrapper.get('[data-testid="section-grid"]').classes()).toContain(
        'v-expansion-panel--active',
      )
    } finally {
      wrapper.unmount()
      host.remove()
    }
  })

  // 区分を開いた直後は展開トランジションの途中（高さ0）でスクロール位置が定まらないため、
  // トランジション終了後にもう一度 scrollIntoView する。`.v-expansion-panel-text` 自身の transitionend
  // だけを拾う（子孫の入力欄などから bubble してくる transitionend は無視する）
  it('区分を開いた場合だけ、展開トランジション終了後にもう一度 scrollIntoView する', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, {}, host)
    try {
      // 表の区分を畳む
      await wrapper
        .get('[data-testid="section-grid"] .v-expansion-panel-title')
        .trigger('click')
      await wrapper.vm.$nextTick()

      // 1. 畳んだ区分への focusRequest → 開いて 1 回 scrollIntoView
      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:1:0', seq: 1 } }),
      })
      await wrapper.vm.$nextTick()
      expect(scrollSpy).toHaveBeenCalledTimes(1)

      const panel = wrapper.get(
        '[data-testid="section-grid"] .v-expansion-panel-text',
      ).element
      const input = cellInputs(wrapper)[1]!.element

      // 2. 入力欄（子孫）から bubble する transitionend は無視する
      input.dispatchEvent(new Event('transitionend', { bubbles: true }))
      expect(scrollSpy).toHaveBeenCalledTimes(1)

      // 3. 区分本文自身の transitionend でもう一度 scrollIntoView する。リスナーは 1 回限り
      panel.dispatchEvent(new Event('transitionend', { bubbles: true }))
      expect(scrollSpy).toHaveBeenCalledTimes(2)
      panel.dispatchEvent(new Event('transitionend', { bubbles: true }))
      expect(scrollSpy).toHaveBeenCalledTimes(2)

      // 4. 区分が開いている状態での focusRequest では transitionend を dispatch しても増えない
      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:1:0', seq: 2 } }),
      })
      await wrapper.vm.$nextTick()
      expect(scrollSpy).toHaveBeenCalledTimes(3)
      panel.dispatchEvent(new Event('transitionend', { bubbles: true }))
      expect(scrollSpy).toHaveBeenCalledTimes(3)
    } finally {
      wrapper.unmount()
      host.remove()
    }
  })

  // キャンバスで畳まれた空行のセルを選択したとき: ResultTable が塊を展開し、ResultEditor がフォーカスする
  it('畳まれた空行のセルへの focusRequest で展開してフォーカスする', async () => {
    Element.prototype.scrollIntoView = vi.fn()
    const emptyRow = (r: number) => ({
      row_index: r,
      column_index: 0,
      row_span: 1,
      column_span: 1,
      content: '',
      kind: null,
      page_number: 1,
      polygon: [1, 1, 2, 2],
    })
    const tables = [
      {
        row_count: 4,
        column_count: 1,
        cells: [...run.tables![0]!.cells, emptyRow(2), emptyRow(3)],
      },
    ]
    const wrapper = mountEditor({}, { tables }, document.body)
    try {
      expect(wrapper.find('[data-target-id="cell:0:3:0"]').exists()).toBe(false)

      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:3:0', seq: 1 } }, { tables }),
      })
      await flushPromises()
      const input = wrapper.get('[data-target-id="cell:0:3:0"] input')
      expect(document.activeElement).toBe(input.element)
    } finally {
      wrapper.unmount()
    }
  })

  // Vuetify の v-expansion-panel-text は leave 完了後に slot を unmount する（lazy）。表の区分だけ
  // eager を付けて畳んでも ResultTable を保ち、畳んだ状態でも空行の塊をキャンバスから展開できるようにする
  it('表の区分を畳んでも、畳まれた空行への focusRequest で展開してフォーカスする（実トランジション）', async () => {
    Element.prototype.scrollIntoView = vi.fn()
    const emptyRow = (r: number) => ({
      row_index: r,
      column_index: 0,
      row_span: 1,
      column_span: 1,
      content: '',
      kind: null,
      page_number: 1,
      polygon: [1, 1, 2, 2],
    })
    const tables = [
      {
        row_count: 4,
        column_count: 1,
        cells: [...run.tables![0]!.cells, emptyRow(2), emptyRow(3)],
      },
    ]
    const wrapper = mountEditor({}, { tables }, document.body, {
      transition: false,
    })
    try {
      const textEl = wrapper.get(
        '[data-testid="section-grid"] .v-expansion-panel-text',
      ).element as HTMLElement
      // 表の区分を畳む → leave トランジションの完了を待つ（jsdom は transitionend を自動発火しないため、
      // v-show が display:none を書いた時点を明示条件にして待つ）
      await wrapper
        .get('[data-testid="section-grid"] .v-expansion-panel-title')
        .trigger('click')
      await vi.waitFor(() => expect(textEl.style.display).toBe('none'))
      expect(
        wrapper.get('[data-testid="section-grid"]').classes(),
      ).not.toContain('v-expansion-panel--active')

      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:3:0', seq: 1 } }, { tables }),
      })
      await flushPromises()

      expect(wrapper.get('[data-testid="section-grid"]').classes()).toContain(
        'v-expansion-panel--active',
      )
      const input = wrapper.get('[data-target-id="cell:0:3:0"] input')
      expect(document.activeElement).toBe(input.element)
    } finally {
      wrapper.unmount()
    }
  })
})
