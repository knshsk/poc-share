import { describe, expect, it } from 'vitest'

import { fieldStatus, LOW_CONFIDENCE } from '../src/utils/fieldStatus'

const base = { draft: false, corrected: false, value: 'x', confidence: 0.92 }

describe('fieldStatus', () => {
  it('確信度が閾値以上なら % だけ、未満なら「要確認 n%」', () => {
    expect(LOW_CONFIDENCE).toBe(0.8)
    expect(fieldStatus(base)).toEqual({ kind: 'ok', text: '92%' })
    expect(fieldStatus({ ...base, confidence: 0.8 })).toEqual({
      kind: 'ok',
      text: '80%',
    })
    expect(fieldStatus({ ...base, confidence: 0.799 })).toEqual({
      kind: 'low',
      text: '要確認 80%',
    })
    expect(fieldStatus({ ...base, confidence: 0.62 })).toEqual({
      kind: 'low',
      text: '要確認 62%',
    })
  })

  // 優先順位: 未保存 > 修正済 > 未読取 > 確信度
  it('未保存・修正済・未読取を確信度より優先する', () => {
    expect(
      fieldStatus({
        draft: true,
        corrected: true,
        value: null,
        confidence: 0.1,
      }),
    ).toEqual({ kind: 'draft', text: '未保存' })
    expect(
      fieldStatus({ ...base, corrected: true, value: null, confidence: null }),
    ).toEqual({ kind: 'corrected', text: '修正済' })
    expect(fieldStatus({ ...base, value: null, confidence: 0 })).toEqual({
      kind: 'empty',
      text: '未読取',
    })
  })

  // 確信度を持たない値に「要確認 0%」を出さない
  it('値があり確信度が null なら表示なし', () => {
    expect(fieldStatus({ ...base, confidence: null })).toEqual({
      kind: 'ok',
      text: '',
    })
  })
})
