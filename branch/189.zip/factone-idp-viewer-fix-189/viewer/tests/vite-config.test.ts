// @vitest-environment node
import { describe, expect, it } from 'vitest'

import { moveStylesheetsToBody } from '../vite.config'

// Vite のビルド出力（head に module script と CSS の link が入る）を模した入力
const built = `<!doctype html>
<html lang="ja">
  <head>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <script type="module" crossorigin src="/assets/index-a.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-a.css">
    <link rel="stylesheet" crossorigin href="/assets/vendor-b.css">
    <link crossorigin rel="stylesheet" href="/assets/late-c.css">
  </head>
  <body>
    <div id="app"><div class="boot-splash"></div></div>
  </body>
</html>`

describe('moveStylesheetsToBody', () => {
  it('stylesheet の link を head から </body> の直前へ移し、他のタグは動かさない', () => {
    const [head, body] = moveStylesheetsToBody(built).split('</head>') as [
      string,
      string,
    ]
    expect(head).not.toContain('rel="stylesheet"')
    expect(head).toContain('rel="icon"')
    expect(head).toContain('<script type="module"')
    const app = body.indexOf('<div id="app">')
    const end = body.indexOf('</body>')
    for (const css of ['index-a.css', 'vendor-b.css', 'late-c.css']) {
      expect(body.indexOf(css)).toBeGreaterThan(app)
      expect(body.indexOf(css)).toBeLessThan(end)
    }
  })

  it('stylesheet が無ければそのまま返す', () => {
    const html = '<html><head></head><body></body></html>'
    expect(moveStylesheetsToBody(html)).toBe(html)
  })
})
