import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentPicker from '../src/components/DocumentPicker.vue'
import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { PickerVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { pickerVm, registerVm } from './fixtures'

const bubble = vi.fn()

// VTU の既定は Transition を stub する（after-enter が発火せず、背景のクリックも拾わない）。それらの検証だけ
// transition: false で実物の Transition を動かす（jsdom でも発火する）
function mountPicker(over: Partial<PickerVm> = {}, stubTransition = true) {
  return mount(DocumentPicker, {
    props: { vm: pickerVm(over) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
      stubs: { transition: stubTransition },
    },
  })
}

// v-dialogの内容はbodyへteleportされるためdocumentから探す
function q<T extends Element = HTMLElement>(selector: string): T | null {
  return document.querySelector<T>(selector)
}

function idInput(): HTMLInputElement {
  return q<HTMLInputElement>('[data-testid="document-id-input"] input')!
}

async function openViewTab() {
  q('[data-testid="picker-tab-view"]')!.click()
  await flushPromises()
}

enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentPicker', () => {
  // 文書なしで開くと「文書を登録」タブで、登録フォームに vm.register を渡す
  it('文書 ID が無ければ登録タブで開き、登録フォームを表示する', async () => {
    const wrapper = mountPicker()
    // VTab は選択状態（aria-selected）を ref の取得後に判定するため、mount 直後は false。再描画を待つ
    await flushPromises()
    expect(
      q('[data-testid="picker-tab-register"]')!.getAttribute('aria-selected'),
    ).toBe('true')
    expect(wrapper.findComponent(DocumentRegisterForm).props('vm')).toEqual(
      registerVm(),
    )
    expect(q('[data-testid="document-id-input"]')).toBeNull()
  })

  // 表示中（取得失敗を含む）の文書があれば、参照タブにその ID を入れて開く
  it('文書 ID があれば参照タブで開き、入力欄にその ID を入れる', async () => {
    mountPicker({ documentId: 'doc-1' })
    await flushPromises()
    expect(
      q('[data-testid="picker-tab-view"]')!.getAttribute('aria-selected'),
    ).toBe('true')
    expect(idInput().value).toBe('doc-1')
  })

  // 打てば置き換わるよう、参照タブで開いたら入力欄にフォーカスして ID を全選択する
  it('参照タブで開くと入力欄にフォーカスして ID を全選択する', async () => {
    mountPicker({ documentId: 'doc-1' }, false)
    await vi.waitFor(() => expect(document.activeElement).toBe(idInput()))
    expect([idInput().selectionStart, idInput().selectionEnd]).toEqual([0, 5])
  })

  // 参照タブへ切り替えると文書ID入力欄を表示し、入力欄へフォーカスする
  it('参照タブ切替で文書ID入力欄を表示しフォーカスする', async () => {
    mountPicker()
    await openViewTab()
    expect(document.activeElement).toBe(idInput())
  })

  it('文書ID未入力では参照ボタンを無効化する', async () => {
    mountPicker()
    await openViewTab()
    const button = q<HTMLButtonElement>('[data-testid="document-id-apply"]')!
    expect(button.disabled).toBe(true)

    idInput().value = 'doc-1'
    idInput().dispatchEvent(new Event('input'))
    await flushPromises()
    expect(button.disabled).toBe(false)
  })

  // 参照ボタンで入力した文書IDを openDocument として bubble する
  it('参照で入力した文書IDを openDocument で bubble する', async () => {
    mountPicker()
    await openViewTab()
    idInput().value = 'doc-1'
    idInput().dispatchEvent(new Event('input'))
    await flushPromises()
    q('[data-testid="document-id-apply"]')!.click()
    await flushPromises()
    expect(bubble).toHaveBeenCalledWith({
      type: 'openDocument',
      documentId: 'doc-1',
    })
  })

  // 閉じると中身が破棄されるため、開き直したら初期状態から始める（前回のタブ・入力を引きずらない）
  it('開き直すとタブと参照欄を初期化する', async () => {
    const wrapper = mountPicker()
    await openViewTab()
    idInput().value = 'typed'
    idInput().dispatchEvent(new Event('input'))
    await wrapper.setProps({ vm: pickerVm({ open: false }) })
    await wrapper.setProps({ vm: pickerVm({ open: true }) })
    await flushPromises()
    expect(
      q('[data-testid="picker-tab-register"]')!.getAttribute('aria-selected'),
    ).toBe('true')
    await openViewTab()
    expect(idInput().value).toBe('')
  })

  // × と Esc で閉じる（送信中かどうかの判定は Mediator）
  it('× と Esc で closeDocumentPicker を bubble する', async () => {
    mountPicker()
    await flushPromises()
    q('[data-testid="picker-close"]')!.click()
    expect(bubble).toHaveBeenCalledWith({ type: 'closeDocumentPicker' })

    bubble.mockClear()
    // フォーカスが中身の外にあると、VOverlay は window の keydown でも通知するため、中身に置いてから押す
    const tab = q('[data-testid="picker-tab-register"]')!
    tab.focus()
    expect(document.activeElement).toBe(tab)
    tab.dispatchEvent(
      new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }),
    )
    expect(bubble).toHaveBeenCalledTimes(1)
    expect(bubble).toHaveBeenCalledWith({ type: 'closeDocumentPicker' })
  })

  it('送信中は × を無効にする', async () => {
    mountPicker({ register: registerVm({ submitting: true }) })
    await flushPromises()
    expect(q<HTMLButtonElement>('[data-testid="picker-close"]')!.disabled).toBe(
      true,
    )
  })

  // 背景の誤クリックで入力と選んだ PDF を失わないよう、背景のクリックでは閉じない（persistent）。
  // Transition を stub すると Vuetify は背景のクリックを拾わず persistent を外しても閉じないため、実物の
  // Transition で動かし、クリックの処理（setTimeout）を待ってから、開いたままであることまで確かめる
  it('背景のクリックでは閉じず、closeDocumentPicker も bubble しない', async () => {
    mountPicker({}, false)
    await flushPromises()
    const scrim = q('.v-overlay__scrim')!
    scrim.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }))
    scrim.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    await new Promise((resolve) => setTimeout(resolve, 0))
    await flushPromises()
    expect(q('.v-overlay--active')).not.toBeNull()
    expect(bubble).not.toHaveBeenCalled()
  })
})
