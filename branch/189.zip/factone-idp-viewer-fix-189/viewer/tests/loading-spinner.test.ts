import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

const delay = vi.hoisted(() => ({ ms: 300 }))
vi.mock('../src/utils/spinnerClock', () => ({
  createSpinnerClock: () => ({
    appear: (now: number) => ({ visibleAt: now + delay.ms }),
    gone: () => {},
  }),
}))

import LoadingSpinner from '../src/components/LoadingSpinner.vue'
import { createAppVuetify } from '../src/plugins/vuetify'

describe('LoadingSpinner', () => {
  // 色・大きさ・名前を 1 か所で決める（読込中の各所はこの部品だけを置く）
  it('primary の indeterminate スピナーを「読み込み中」の名前で出す', () => {
    const wrapper = mount(LoadingSpinner, {
      global: { plugins: [createAppVuetify()] },
    })
    const el = wrapper.get('[data-testid="loading-spinner"]')
    expect(el.attributes('role')).toBe('progressbar')
    expect(el.attributes('aria-label')).toBe('読み込み中')
    expect(el.classes()).toContain('v-progress-circular--indeterminate')
    expect(el.classes()).toContain('text-primary')
    expect(el.attributes('style')).toContain('width: 40px')
  })

  // 待ちがあるときだけ遅延表示のクラスと CSS 変数を付ける結線を固定する
  it('待ちがあるときは loading-spinner--wait と --loading-spinner-wait を付ける', () => {
    delay.ms = 300
    const wrapper = mount(LoadingSpinner, {
      global: { plugins: [createAppVuetify()] },
    })
    const el = wrapper.get('[data-testid="loading-spinner"]')
    expect(el.classes()).toContain('loading-spinner--wait')
    // wait は performance.now() 由来の浮動小数点差分（now + delay.ms - now）のため、厳密に 300 とは限らない
    const match = el
      .attributes('style')
      ?.match(/--loading-spinner-wait: ([\d.]+)ms/)
    expect(Number(match?.[1])).toBeCloseTo(300, 6)
  })

  it('待ちが無いときはクラスも CSS 変数も付けない', () => {
    delay.ms = 0
    const wrapper = mount(LoadingSpinner, {
      global: { plugins: [createAppVuetify()] },
    })
    const el = wrapper.get('[data-testid="loading-spinner"]')
    expect(el.classes()).not.toContain('loading-spinner--wait')
    expect(el.attributes('style')).not.toContain('--loading-spinner-wait')
  })
})
