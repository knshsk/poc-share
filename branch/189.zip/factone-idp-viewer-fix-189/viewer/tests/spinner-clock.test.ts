import { describe, expect, it } from 'vitest'

import { createSpinnerClock, SPINNER_DELAY } from '../src/utils/spinnerClock'

// 時刻は ms。起動 0ms（スプラッシュ未表示）の判定器から始める
const fresh = () => createSpinnerClock(0)

describe('createSpinnerClock', () => {
  it('新しいスピナーは 300ms 待つ', () => {
    expect(SPINNER_DELAY).toBe(300)
    expect(fresh().appear(1000).visibleAt).toBe(1300)
  })

  it('表示済み（見えてから 100ms 以上）のスピナーが出ていれば待たない', () => {
    const clock = fresh()
    clock.appear(1000) // 1300 に見える
    expect(clock.appear(1400).visibleAt).toBe(1400)
  })

  it('見えて 100ms 未満のスピナーしか出ていなければ待つ', () => {
    const clock = fresh()
    clock.appear(1000) // 1300 に見える
    expect(clock.appear(1350).visibleAt).toBe(1650)
  })

  it('表示済みのスピナーが消えて 100ms 未満なら待たず、100ms 以上なら待つ', () => {
    const a = fresh()
    a.gone(a.appear(1000), 1500)
    expect(a.appear(1550).visibleAt).toBe(1550)

    const b = fresh()
    b.gone(b.appear(1000), 1500)
    expect(b.appear(1600).visibleAt).toBe(1900)
  })

  // 高速回線で、段階ごとのスピナーが次々に待ちを引き継いで見えてしまうのを防ぐ
  it('見える前に消えたスピナーは続きと数えない', () => {
    const clock = fresh()
    clock.gone(clock.appear(1000), 1200) // 1300 に見える予定が、その前に消えた
    expect(clock.appear(1200).visibleAt).toBe(1500)
  })

  // index.html のスプラッシュは navigation 開始からおよそ 300ms で見える
  it('起動が 400ms 以降ならスプラッシュの続きとみなし、最初のスピナーは待たない', () => {
    expect(createSpinnerClock(400).appear(400).visibleAt).toBe(400)
    expect(createSpinnerClock(350).appear(350).visibleAt).toBe(650)
  })
})
