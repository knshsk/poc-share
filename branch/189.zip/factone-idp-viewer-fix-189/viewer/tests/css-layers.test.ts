// @vitest-environment node
import { readdirSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'

import { describe, expect, it } from 'vitest'

// カスケードレイヤーの優先順は、各レイヤー名が文書内で最初に現れた順で決まる（後に現れたものほど強い）。
// stylesheet の並びはビルドと dev で異なり（ビルドは CSS の <link> を body の末尾へ移す。Vuetify はテーマの CSS を
// 実行時に head へ足す）、並びに任せると本番だけ順が崩れる。そのため index.html の head の最初の <style> で
// 全レイヤーを宣言して順を固定する

const indexHtml = readFileSync(
  join(import.meta.dirname, '../index.html'),
  'utf8',
)
// 文書で最初の stylesheet（属性付きの <style nonce="…"> 等も含める）
const firstStyle = /<style\b[^>]*>([\s\S]*?)<\/style>/.exec(indexHtml)

const srcDir = join(import.meta.dirname, '../src')
// vuetify/styles（src/plugins/vuetify.ts が import する）の実体 = lib/styles/main.css
const vuetifyStyles = createRequire(import.meta.url).resolve('vuetify/styles')
const vuetifyLib = join(dirname(vuetifyStyles), '..')

// CSS の @layer の名前を、入れ子を . で連結して初出順に返す（コメントは除く）
function layerNames(css: string): string[] {
  const names: string[] = []
  // 開いている括弧ごとに、@layer のブロックならその名前、それ以外（規則・@media 等）なら ''
  const open: string[] = []
  const code = css.replace(/\/\*[\s\S]*?\*\//g, '')
  // 文の終わりは ; のほか、ブロック末尾で ; を省いた } もある（minify 後の CSS）
  for (const [token, list = '', end] of code.matchAll(
    /@layer\s+([^{;}]+)([{;}])|[{}]/g,
  )) {
    if (token === '{') open.push('')
    else if (token === '}') open.pop()
    else {
      const prefix = open.filter(Boolean).join('.')
      for (const name of list.split(',')) {
        const full = [prefix, name.trim()].filter(Boolean).join('.')
        if (!names.includes(full)) names.push(full)
      }
      if (end === '{') open.push(list.trim())
      else if (end === '}') open.pop()
    }
  }
  return names
}

// [表示名, CSS] の一覧。アプリは src の .css と .vue の <style>、Vuetify は lib 配下の全 .css
function appCss(): [string, string][] {
  return readdirSync(srcDir, { recursive: true, encoding: 'utf8' })
    .filter((file) => /\.(css|vue)$/.test(file))
    .map((file) => {
      const text = readFileSync(join(srcDir, file), 'utf8')
      const css = file.endsWith('.vue')
        ? [...text.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/g)]
            .map(([, body]) => body)
            .join('\n')
        : text
      return [`src/${file}`, css]
    })
}

function vuetifyCss(): [string, string][] {
  return readdirSync(vuetifyLib, { recursive: true, encoding: 'utf8' })
    .filter((file) => file.endsWith('.css'))
    .map((file) => [
      `vuetify/lib/${file}`,
      readFileSync(join(vuetifyLib, file), 'utf8'),
    ])
}

describe('カスケードレイヤーの順（index.html）', () => {
  it('layerNames は入れ子を . で連結して初出順に返し、コメントとレイヤー以外の括弧を数えない', () => {
    const css = `
      /* @layer commented; */
      @layer a;
      @layer b {
        .rule { color: red; }
        @layer x, y;
        @media (min-width: 1px) { .r { margin: 0; } }
        @layer v { .r { margin: 0; } }
      }
      @layer b.z { .r { margin: 0; } }
      @layer a { @layer w; }
      @layer m{@layer n,o}.x{color:red}@layer p;
    `
    expect(layerNames(css)).toEqual([
      'a',
      'b',
      'b.x',
      'b.y',
      'b.v',
      'b.z',
      'a.w',
      'm',
      'm.n',
      'm.o',
      'p',
    ])
  })

  // 宣言が無い・Vuetify と食い違う・stylesheet の後ろにあると、順が stylesheet の並びで決まり、本番ビルドで
  // vuetify-utilities が最下位になる（pa-* / mb-* / bg-* が部品の規則に負ける）
  it('head の最初の <style> で、app-reset を最下位に、Vuetify のレイヤーを vuetify/styles と同じ順で宣言している', () => {
    const style = firstStyle?.index ?? -1
    expect(style).toBeGreaterThanOrEqual(0)
    expect(style).toBeLessThan(indexHtml.indexOf('</head>'))
    expect(indexHtml.slice(0, style)).not.toContain('rel="stylesheet"')
    expect(layerNames(firstStyle?.[1] ?? '')).toEqual([
      'app-reset',
      ...layerNames(readFileSync(vuetifyStyles, 'utf8')),
    ])
  })

  // 宣言していないレイヤーは、最初に現れた stylesheet の位置で順が決まる
  it('アプリと Vuetify の CSS が使うレイヤーをすべて宣言している', () => {
    const declared = layerNames(firstStyle?.[1] ?? '')
    const undeclared = new Map<string, string>()
    for (const [file, css] of [...appCss(), ...vuetifyCss()]) {
      for (const name of layerNames(css)) {
        if (!declared.includes(name) && !undeclared.has(name)) {
          undeclared.set(name, file)
        }
      }
    }
    expect([...undeclared].map(([name, file]) => `${name}（${file}）`)).toEqual(
      [],
    )
  })
})
