import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { describe, expect, it } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// 起動スプラッシュは Vuetify の起動前に描くため、色を直書きしている。テーマと食い違うと起動の前後で色が変わる
const indexHtml = readFileSync(
  join(import.meta.dirname, '../index.html'),
  'utf8',
).toLowerCase()

describe('起動スプラッシュ（index.html）', () => {
  it('背景と弧の色がテーマの background / primary と一致する', () => {
    const colors = createAppVuetify().theme.themes.value.factone!.colors
    expect(indexHtml).toContain(
      `background: ${colors.background!.toLowerCase()}`,
    )
    expect(indexHtml).toContain(`stroke: ${colors.primary!.toLowerCase()}`)
  })

  it('#app の中にスプラッシュを置き、「読み込み中」の名前を付ける', () => {
    expect(indexHtml).toMatch(/<div id="app">\s*<div class="boot-splash">/)
    expect(indexHtml).toContain('role="progressbar"')
    expect(indexHtml).toContain('aria-label="読み込み中"')
  })
})
