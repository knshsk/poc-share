import { describe, expect, it } from 'vitest'

import { formatConfidence, formatDateTime } from '../src/utils/format'

describe('format', () => {
  it('確信度を%表示する（null系は-）', () => {
    expect(formatConfidence(0.98)).toBe('98%')
    expect(formatConfidence(0.755)).toBe('76%')
    expect(formatConfidence(null)).toBe('-')
    expect(formatConfidence(undefined)).toBe('-')
  })

  it('日時をロケール文字列にする', () => {
    expect(formatDateTime('2026-08-01T00:00:00Z')).toBe(
      new Date('2026-08-01T00:00:00Z').toLocaleString(),
    )
  })
})
