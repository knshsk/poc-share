import { mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import KeyFieldList from '../src/components/KeyFieldList.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { EditorVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import type { IdpRun } from '../src/utils/runs'
import { editorVm } from './fixtures'

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  fields: {
    TotalAmount: {
      value: '1,200,000',
      normalized_value: 1200000,
      confidence: 0.96,
      label: '合計金額',
      region: null,
    },
    DeliveryDate: {
      value: '2026-10-30',
      normalized_value: '2026-10-30',
      confidence: 0.85,
      label: '納品期限',
      region: null,
    },
    Note: {
      value: null,
      normalized_value: null,
      confidence: null,
      region: null,
    },
    Hidden: {
      value: 'secret',
      normalized_value: 'secret',
      confidence: 0.5,
      region: null,
    },
  },
  tables: [],
  pattern_matches: {},
  corrections: null,
}

const fieldDefs = [
  {
    key: 'TotalAmount',
    label: '合計金額',
    type: 'number' as const,
    visible: true,
  },
  {
    key: 'DeliveryDate',
    label: '納品期限',
    type: 'date' as const,
    visible: true,
  },
  { key: 'Note', label: '備考', type: 'string' as const, visible: true },
  { key: 'Hidden', label: '非表示', type: 'string' as const, visible: false },
]

const bubble = vi.fn()

function vmOf(over: Partial<EditorVm> = {}, runOver: Partial<IdpRun> = {}) {
  return editorVm({ run: { ...run, ...runOver }, fieldDefs, ...over })
}

function mountList(
  over: Partial<EditorVm> = {},
  runOver: Partial<IdpRun> = {},
) {
  return mount(KeyFieldList, {
    props: { vm: vmOf(over, runOver) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

const inputs = (w: ReturnType<typeof mountList>) =>
  w.findAll('[data-testid="field-input"] input')
const statuses = (w: ReturnType<typeof mountList>) =>
  w.findAll('[data-testid="field-status"]')

describe('KeyFieldList', () => {
  beforeEach(() => bubble.mockClear())

  // 表示順・非表示・ラベル・値・プレースホルダは従来どおり。確信度バーは出さない
  it('キー項目を設定の順に描画し、visible=false を除外する', () => {
    const wrapper = mountList()
    const rows = wrapper.findAll('[data-testid="field-row"]')
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('合計金額')
    expect(rows[2]!.text()).toContain('Note')
    expect(wrapper.text()).not.toContain('secret')
    expect((inputs(wrapper)[0]!.element as HTMLInputElement).value).toBe(
      '1200000',
    )
    expect(inputs(wrapper)[2]!.attributes('placeholder')).toBe('（値なし）')
    expect(inputs(wrapper)[0]!.attributes('aria-label')).toBe('合計金額')
    expect(inputs(wrapper)[0]!.attributes('maxlength')).toBe('2000')
    // Vuetify の VField は loading 用 v-progress-linear を常に内部描画する（非表示時は height:0）ため、
    // クラスではなく元の confidence-bar の data-testid の不在で確認する
    expect(wrapper.find('[data-testid="confidence-bar"]').exists()).toBe(false)
  })

  // 状態: 96% = そのまま、85% = そのまま（閾値 80% 以上）、値なし = 未読取
  it('確信度と未読取を状態として表示する', () => {
    const wrapper = mountList()
    expect(statuses(wrapper).map((s) => s.text())).toEqual([
      '96%',
      '85%',
      '未読取',
    ])
    expect(statuses(wrapper)[0]!.classes()).toContain('field-status--ok')
    expect(statuses(wrapper)[2]!.classes()).toContain('field-status--empty')
  })

  it('80% 未満は「要確認」、保存済みの修正は「修正済」、下書きは「未保存」にする', () => {
    const wrapper = mountList(
      { draftFields: { Note: 'メモ' } },
      {
        fields: {
          ...run.fields,
          TotalAmount: { ...run.fields!.TotalAmount!, confidence: 0.62 },
        },
        corrections: {
          fields: { DeliveryDate: '2026-11-01' },
          table_cells: [],
        },
      },
    )
    expect(statuses(wrapper).map((s) => s.text())).toEqual([
      '要確認 62%',
      '修正済',
      '未保存',
    ])
    const statusClasses = statuses(wrapper).map((s) => s.classes())
    expect(statusClasses[0]).toContain('field-status--low')
    expect(statusClasses[1]).toContain('field-status--corrected')
    expect(statusClasses[2]).toContain('field-status--draft')
    // 未保存の入力欄だけ塗る。保存済みの修正は状態表示だけ
    const fields = wrapper.findAll('.field-input')
    expect(fields[2]!.classes()).toContain('input--draft')
    expect(fields[1]!.classes()).not.toContain('input--draft')
  })

  // 状態・読取値・ヒントは aria-describedby で入力欄に紐付ける（状態が先頭）
  it('状態と読取値を aria-describedby で入力欄に紐付ける', () => {
    const wrapper = mountList()
    // 読取値の補足は元値と異なる項目だけ（DeliveryDate は正規化値が読取値と同じなので出ない）
    expect(wrapper.findAll('[data-testid="raw-value"]')).toHaveLength(1)
    const raw = wrapper.get('[data-testid="raw-value"]')
    expect(raw.text()).toBe('読取値 1,200,000')
    expect(inputs(wrapper)[0]!.attributes('aria-describedby')).toBe(
      `${statuses(wrapper)[0]!.attributes('id')} ${raw.attributes('id')}`,
    )
    expect(inputs(wrapper)[2]!.attributes('aria-describedby')).toBe(
      statuses(wrapper)[2]!.attributes('id'),
    )
  })

  it('正規化ヒントを型別に表示し、入力欄に紐付ける', () => {
    const wrapper = mountList({
      draftFields: { TotalAmount: '約120万', DeliveryDate: '2026/11/1' },
    })
    const hints = wrapper.findAll('[data-testid="normalization-hint"]')
    expect(hints.map((h) => h.text())).toEqual([
      '数値として解釈できません',
      '正規化値 2026-11-01',
    ])
    expect(inputs(wrapper)[0]!.attributes('aria-describedby')).toContain(
      hints[0]!.attributes('id'),
    )
  })

  it('入力で fieldInput、フォーカスで targetFocus を bubble し、下書きの値を表示する', async () => {
    const wrapper = mountList({ draftFields: { DeliveryDate: null } })
    expect((inputs(wrapper)[1]!.element as HTMLInputElement).value).toBe('')
    await inputs(wrapper)[0]!.setValue('1,250,000')
    expect(bubble).toHaveBeenCalledWith({
      type: 'fieldInput',
      key: 'TotalAmount',
      value: '1,250,000',
    })
    await inputs(wrapper)[0]!.trigger('focus')
    expect(bubble).toHaveBeenCalledWith({
      type: 'targetFocus',
      id: 'field:TotalAmount',
    })
  })

  it('activeId の入力欄に aria-current と選択中クラスを付ける', () => {
    const wrapper = mountList({ activeId: 'field:DeliveryDate' })
    expect(inputs(wrapper)[1]!.attributes('aria-current')).toBe('true')
    expect(inputs(wrapper)[0]!.attributes('aria-current')).toBeUndefined()
    expect(wrapper.findAll('.field-input')[1]!.classes()).toContain(
      'target--active',
    )
  })
})
