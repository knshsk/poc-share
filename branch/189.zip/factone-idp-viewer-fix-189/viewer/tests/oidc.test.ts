import { beforeEach, describe, expect, it, vi } from 'vitest'

const signinRedirect = vi.fn()
const signinCallback = vi.fn()
const signoutRedirect = vi.fn()

vi.mock('oidc-client-ts', () => ({
  UserManager: class {
    signinRedirect = signinRedirect
    signinCallback = signinCallback
    signoutRedirect = signoutRedirect
  },
  WebStorageStateStore: class {},
  InMemoryWebStorage: class {},
}))

import { createOidc, resolveReturnTo } from '../src/auth/oidc'

describe('createOidc', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    window.history.replaceState(null, '', '/')
  })

  // ログイン前の URL（パス＋クエリ）を state に保存し、コールバック後に復元できるようにする
  it('login() はログイン前 URL を state に入れて signinRedirect する', async () => {
    window.history.replaceState(null, '', '/?document_id=doc-1')

    await createOidc().login()

    expect(signinRedirect).toHaveBeenCalledWith({
      state: { returnTo: '/?document_id=doc-1' },
    })
  })

  // コールバックで state の復元先へ replaceState し、トークンとユーザー名を返す
  it('handleCallback() は復元先 URL へ遷移しセッションを返す', async () => {
    window.history.replaceState(null, '', '/callback?code=abc&state=xyz')
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: { preferred_username: 'testuser' },
      state: { returnTo: '/?document_id=doc-1' },
    })

    const session = await createOidc().handleCallback()

    expect(window.location.pathname + window.location.search).toBe(
      '/?document_id=doc-1',
    )
    expect(session).toEqual({ accessToken: 'token-abc', username: 'testuser' })
  })

  it('handleCallback() はユーザーが無ければ null を返す', async () => {
    signinCallback.mockResolvedValue(null)
    expect(await createOidc().handleCallback()).toBeNull()
  })

  it('logout() は signoutRedirect する', async () => {
    await createOidc().logout()
    expect(signoutRedirect).toHaveBeenCalledOnce()
  })
})

// state なし・不正値（外部 URL・スキーム相対・相対パスでない・文字列でない）は "/" へフォールバックする（オープンリダイレクト防止）
describe('resolveReturnTo', () => {
  it.each([
    ['state なし', undefined, '/'],
    ['外部 URL', { returnTo: 'https://evil.example/' }, '/'],
    ['スキーム相対 URL', { returnTo: '//evil.example/' }, '/'],
    ['相対パスでない', { returnTo: 'foo' }, '/'],
    ['文字列でない', { returnTo: 1 }, '/'],
    ['正常', { returnTo: '/?document_id=doc-1' }, '/?document_id=doc-1'],
  ])('%s のとき %s', (_label, state, expected) => {
    expect(resolveReturnTo(state)).toBe(expected)
  })
})
