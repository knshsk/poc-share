import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import ViewUrlPanel from '../src/components/ViewUrlPanel.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { ViewUrlsVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { viewUrlsVm } from './fixtures'

const activeUrl = {
  id: '11111111-1111-1111-1111-111111111111',
  issued_at: '2026-08-01T00:00:00Z',
  expires_at: '2099-08-31T00:00:00Z',
  revoked: false,
}
const revokedUrl = {
  ...activeUrl,
  id: '22222222-2222-2222-2222-222222222222',
  revoked: true,
}
const expiredUrl = {
  ...activeUrl,
  id: '33333333-3333-3333-3333-333333333333',
  expires_at: '2000-01-01T00:00:00Z',
}

const bubble = vi.fn()

function mountPanel(over: Partial<ViewUrlsVm> = {}, attachTo?: HTMLElement) {
  return mount(ViewUrlPanel, {
    props: { vm: viewUrlsVm(over) },
    attachTo,
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// ダイアログはbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('ViewUrlPanel', () => {
  it('一覧を状態（有効 / 失効済み / 期限切れ）付きで表示し、失効済み・期限切れには操作ボタンを出さない', () => {
    const wrapper = mountPanel({ urls: [activeUrl, revokedUrl, expiredUrl] })
    const rows = wrapper.findAll('[data-testid="view-url-row"]')
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('有効')
    expect(rows[1]!.text()).toContain('失効済み')
    expect(rows[2]!.text()).toContain('期限切れ')
    expect(wrapper.findAll('[data-testid="revoke-view-url"]')).toHaveLength(1)
    // 状態（失効済み）と操作（失効させる）は別の語にする
    expect(rows[0]!.get('[data-testid="revoke-view-url"]').text()).toBe(
      '失効させる',
    )
    expect(rows[1]!.text()).not.toContain('失効させる')
    // 期限（副題）も 14px（文字の下限）。本文との区別は secondary 色で付け、Vuetify が副題に掛ける透明度は
    // 掛けない（WCAG 1.4.3・ADR-0024）
    expect(rows[0]!.get('.v-list-item-subtitle').classes()).toEqual(
      expect.arrayContaining(['text-body-medium', 'text-secondary']),
    )
    expect(
      rows[0]!.element.closest('.v-list')!.getAttribute('style'),
    ).toContain('--v-list-item-subtitle-opacity: 1')
  })

  it('発行ボタンで issueViewUrl を bubble し、発行中は無効化する', async () => {
    const wrapper = mountPanel()
    await wrapper.get('[data-testid="issue-view-url"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'issueViewUrl' })

    const issuing = mountPanel({ issuing: true })
    expect(
      issuing.get('[data-testid="issue-view-url"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('発行URLを表示し、コピーで copyIssuedUrl を bubble する', async () => {
    const wrapper = mountPanel({
      issuedUrl: 'http://localhost:3000/view/tok-abc',
    })
    expect(wrapper.get('[data-testid="issued-url"]').text()).toBe(
      'http://localhost:3000/view/tok-abc',
    )
    await wrapper.get('[data-testid="copy-view-url"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'copyIssuedUrl' })
  })

  // 失効は確認ダイアログを挟む。ボタンで対象を通知し、ダイアログ表示は vm.revokeTarget で決まる
  it('失効ボタンで revokeViewUrl を bubble し、revokeTarget があれば確認ダイアログを出す', async () => {
    const wrapper = mountPanel({ urls: [activeUrl] })
    await wrapper.get('[data-testid="revoke-view-url"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({
      type: 'revokeViewUrl',
      viewUrlId: activeUrl.id,
    })
    expect(document.querySelector('[data-testid="revoke-confirm"]')).toBeNull()

    mountPanel({ urls: [activeUrl], revokeTarget: activeUrl.id })
    const confirm = document.querySelector(
      '[data-testid="revoke-confirm"]',
    ) as HTMLElement
    expect(confirm).not.toBeNull()
    expect(confirm.textContent?.trim()).toBe('失効させる')
    // ダイアログのアクセシブル名はタイトル要素（aria-labelledby）
    const titleId = document
      .querySelector('[role="dialog"]')
      ?.getAttribute('aria-labelledby')
    expect(titleId).toBeTruthy()
    expect(document.getElementById(titleId!)?.textContent).toContain(
      '閲覧URLを失効させますか？',
    )
    confirm.click()
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmRevoke' })
    ;(
      document.querySelector('[data-testid="revoke-cancel"]') as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'cancelRevoke' })
  })

  // 行の「失効させる」で確認ダイアログを開き、ダイアログ内のボタン（testid）へフォーカスを移した状態にする
  async function openRevokeFrom(focusInside: string) {
    const wrapper = mountPanel({ urls: [activeUrl] }, document.body)
    const revoke = wrapper.get<HTMLButtonElement>(
      '[data-testid="revoke-view-url"]',
    ).element
    revoke.focus()
    await wrapper.setProps({
      vm: viewUrlsVm({ urls: [activeUrl], revokeTarget: activeUrl.id }),
    })
    document
      .querySelector<HTMLElement>(`[data-testid="${focusInside}"]`)!
      .focus()
    return { wrapper, revoke }
  }

  it('失効の確認をキャンセルで閉じたら、行の「失効させる」へフォーカスを戻す', async () => {
    const { wrapper, revoke } = await openRevokeFrom('revoke-cancel')
    await wrapper.setProps({ vm: viewUrlsVm({ urls: [activeUrl] }) })
    expect(document.activeElement).toBe(revoke)
  })

  // 失効した行の「失効させる」は一覧の再取得で消える。閉じた時点ではまだ残っているが、戻さない
  it('失効を確定して閉じたら、「閲覧URL発行」へフォーカスを移す', async () => {
    const { wrapper } = await openRevokeFrom('revoke-confirm')
    document
      .querySelector<HTMLElement>('[data-testid="revoke-confirm"]')!
      .click()
    await wrapper.setProps({ vm: viewUrlsVm({ urls: [activeUrl] }) })
    expect(document.activeElement).toBe(
      wrapper.get('[data-testid="issue-view-url"]').element,
    )
  })

  it('エラーメッセージを表示する', () => {
    const wrapper = mountPanel({ error: '閲覧URLの発行に失敗しました' })
    expect(wrapper.text()).toContain('閲覧URLの発行に失敗しました')
  })
})
