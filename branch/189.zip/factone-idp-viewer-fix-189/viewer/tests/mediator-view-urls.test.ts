import { flushPromises } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
  setAccessToken: vi.fn(),
}))

import { createMediator, type Mediator } from '../src/mediator/machine'
import type { IdpRun } from '../src/utils/runs'
import { fakeOidc, routeGet, succeededRun } from './fixtures'

const activeUrl = {
  id: '11111111-1111-1111-1111-111111111111',
  issued_at: '2026-08-01T00:00:00Z',
  expires_at: '2099-08-31T00:00:00Z',
  revoked: false,
}

function withUrls(urls: unknown[], runs: IdpRun[] = []) {
  return (path: string, options?: never) =>
    path === '/api/v1/documents/{document_id}/view-urls'
      ? Promise.resolve({ data: urls, error: undefined })
      : routeGet(runs)(path, options)
}

// shareable な文書を開いて閲覧URLタブを開いた状態
async function onUrlsTab(
  urls: unknown[] = [],
  runs: IdpRun[] = [],
): Promise<Mediator> {
  getMock.mockImplementation(withUrls(urls, runs))
  const m = createMediator(fakeOidc())
  m.state.value = 'empty'
  m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
  await flushPromises()
  m.dispatch({ type: 'tabChanged', tab: 'urls' })
  await flushPromises()
  return m
}

const vu = (m: Mediator) => m.vm.value.document!.workPanel!.viewUrls
const listCalls = () =>
  getMock.mock.calls.filter(
    ([path]) => path === '/api/v1/documents/{document_id}/view-urls',
  )

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
})

describe('Mediator（閲覧URL）', () => {
  it('閲覧URLタブを初めて開いたときだけ一覧を取得する', async () => {
    const m = await onUrlsTab([activeUrl])
    expect(listCalls()).toHaveLength(1)
    expect(vu(m).urls).toEqual([activeUrl])

    m.dispatch({ type: 'tabChanged', tab: 'result' })
    m.dispatch({ type: 'tabChanged', tab: 'urls' })
    await flushPromises()
    expect(listCalls()).toHaveLength(1)
  })

  it('一覧取得失敗は「閲覧URL一覧を取得できませんでした」', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/view-urls'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet()(path),
    )
    const m = createMediator(fakeOidc())
    m.state.value = 'empty'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    m.dispatch({ type: 'tabChanged', tab: 'urls' })
    await flushPromises()
    expect(vu(m).error).toBe('閲覧URL一覧を取得できませんでした')
  })

  // 発行: POST → 応答 view_path に自オリジンを付けて表示し、一覧を再取得する
  it('issueViewUrl で POST し、発行URLを絶対URLで持ち、一覧を再取得する', async () => {
    postMock.mockResolvedValue({
      data: {
        id: activeUrl.id,
        view_path: '/view/tok-abc',
        expires_at: activeUrl.expires_at,
      },
      error: undefined,
    })
    const m = await onUrlsTab()
    m.dispatch({ type: 'issueViewUrl' })
    expect(vu(m).issuing).toBe(true)
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/view-urls',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    expect(vu(m).issuedUrl).toBe(`${window.location.origin}/view/tok-abc`)
    expect(vu(m).issuing).toBe(false)
    expect(listCalls()).toHaveLength(2)
  })

  it('発行失敗は「閲覧URLの発行に失敗しました」', async () => {
    postMock.mockResolvedValue({ data: undefined, error: { detail: 'x' } })
    const m = await onUrlsTab()
    m.dispatch({ type: 'issueViewUrl' })
    await flushPromises()
    expect(vu(m).error).toBe('閲覧URLの発行に失敗しました')
    expect(vu(m).issuing).toBe(false)
  })

  it('copyIssuedUrl は発行URLをクリップボードへ書き込む', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.assign(navigator, { clipboard: { writeText } })
    postMock.mockResolvedValue({
      data: { id: activeUrl.id, view_path: '/view/tok-abc', expires_at: '' },
      error: undefined,
    })
    const m = await onUrlsTab()
    m.dispatch({ type: 'copyIssuedUrl' })
    expect(writeText).not.toHaveBeenCalled()

    m.dispatch({ type: 'issueViewUrl' })
    await flushPromises()
    m.dispatch({ type: 'copyIssuedUrl' })
    expect(writeText).toHaveBeenCalledWith(
      `${window.location.origin}/view/tok-abc`,
    )
  })

  // 失効は確認を挟み、確定時だけ POST して一覧を再取得する。取消は何もしない
  it('revokeViewUrl → confirmRevoke で失効 POST し一覧を再取得、cancelRevoke は POST しない', async () => {
    postMock.mockResolvedValue({
      data: { status: 'revoked' },
      error: undefined,
    })
    const m = await onUrlsTab([activeUrl])

    m.dispatch({ type: 'revokeViewUrl', viewUrlId: activeUrl.id })
    expect(vu(m).revokeTarget).toBe(activeUrl.id)
    m.dispatch({ type: 'cancelRevoke' })
    expect(vu(m).revokeTarget).toBeNull()
    expect(postMock).not.toHaveBeenCalled()

    m.dispatch({ type: 'revokeViewUrl', viewUrlId: activeUrl.id })
    m.dispatch({ type: 'confirmRevoke' })
    expect(vu(m).revokeTarget).toBeNull()
    await flushPromises()
    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/view-urls/{view_url_id}/revoke',
      expect.objectContaining({
        params: { path: { view_url_id: activeUrl.id } },
      }),
    )
    expect(listCalls()).toHaveLength(2)
  })

  it('失効失敗は「閲覧URLの失効に失敗しました」', async () => {
    postMock.mockResolvedValue({ data: undefined, error: {} })
    const m = await onUrlsTab([activeUrl])
    m.dispatch({ type: 'revokeViewUrl', viewUrlId: activeUrl.id })
    m.dispatch({ type: 'confirmRevoke' })
    await flushPromises()
    expect(vu(m).error).toBe('閲覧URLの失効に失敗しました')
  })

  // 文書切替後に届いた古い発行応答は捨てる（別文書のURLを表示しない）
  it('文書切替後に届いた発行応答は捨てる', async () => {
    let resolveIssue: (v: unknown) => void = () => {}
    postMock.mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveIssue = resolve
        }),
    )
    const m = await onUrlsTab()
    m.dispatch({ type: 'issueViewUrl' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()
    resolveIssue({
      data: { id: activeUrl.id, view_path: '/view/tok-old', expires_at: '' },
      error: undefined,
    })
    await flushPromises()
    expect(vu(m).issuedUrl).toBeNull()
    expect(vu(m).issuing).toBe(false)
  })

  // 文書切替後に届いた古い失効応答は捨てる（新文書側に失効エラーを誤表示しない）
  it('文書切替後に届いた失効応答は捨てる', async () => {
    let resolveRevoke: (v: unknown) => void = () => {}
    postMock.mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveRevoke = resolve
        }),
    )
    const m = await onUrlsTab([activeUrl])
    m.dispatch({ type: 'revokeViewUrl', viewUrlId: activeUrl.id })
    m.dispatch({ type: 'confirmRevoke' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()
    const listCallsBefore = listCalls().length
    resolveRevoke({ data: undefined, error: {} })
    await flushPromises()
    expect(vu(m).error).toBeNull()
    expect(listCalls()).toHaveLength(listCallsBefore)
  })

  // 確認ダイアログ表示中も完了イベントは受ける（捨てると issuing が固着し、発行済みの URL も失う）
  it('confirmDiscard 中に届いた発行応答も受け取り issuing を解除する', async () => {
    let resolveIssue: (v: unknown) => void = () => {}
    postMock.mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveIssue = resolve
        }),
    )
    const m = await onUrlsTab([], [succeededRun])
    m.dispatch({ type: 'issueViewUrl' })
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    m.dispatch({ type: 'executeIdp' })
    expect(m.state.value).toBe('confirmDiscard')

    resolveIssue({
      data: { id: 'x', view_path: '/view/tok-late', expires_at: '' },
      error: undefined,
    })
    await flushPromises()
    expect(vu(m).issuing).toBe(false)
    expect(vu(m).issuedUrl).toBe(`${window.location.origin}/view/tok-late`)
  })
})
