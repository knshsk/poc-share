import { mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import ResultTable from '../src/components/ResultTable.vue'
import { BUBBLE } from '../src/mediator/bubble'
import { createAppVuetify } from '../src/plugins/vuetify'

const bubble = vi.fn()

// 5 行 × 3 列。0 行目はヘッダー、2〜3 行目は空行、(1,2) は DI にセルが無い
function cell(
  r: number,
  c: number,
  content: string,
  kind: string | null = null,
) {
  return {
    row_index: r,
    column_index: c,
    row_span: 1,
    column_span: 1,
    content,
    kind,
    page_number: 1,
    polygon: [1, 1, 2, 2],
  }
}
const table = {
  row_count: 5,
  column_count: 3,
  cells: [
    cell(0, 0, '商品コード', 'columnHeader'),
    cell(0, 1, '商品名', 'columnHeader'),
    cell(0, 2, '金額', 'columnHeader'),
    cell(1, 0, 'TST-001'),
    cell(1, 1, 'テスト用コピー用紙'),
    ...[2, 3].flatMap((r) => [cell(r, 0, ''), cell(r, 1, ''), cell(r, 2, '')]),
    cell(4, 0, ''),
    cell(4, 1, '合計'),
    cell(4, 2, '33,000'),
  ],
}

// フォーカス保持の回帰テスト用。空行が 3 行以上ある表（既存 fixture の空行は 2 行のみ）
const tableWithLongGap = {
  row_count: 6,
  column_count: 2,
  cells: [
    cell(0, 0, '品名', 'columnHeader'),
    cell(0, 1, '金額', 'columnHeader'),
    cell(1, 0, 'A'),
    cell(1, 1, '100'),
    ...[2, 3, 4].flatMap((r) => [cell(r, 0, ''), cell(r, 1, '')]),
    cell(5, 0, '合計'),
    cell(5, 1, '100'),
  ],
}

type Props = InstanceType<typeof ResultTable>['$props']

function mountTable(over: Partial<Props> = {}, attachTo?: HTMLElement) {
  return mount(ResultTable, {
    props: {
      table,
      tableIndex: 1,
      draftCells: {},
      correctedCells: new Set<string>(),
      activeId: null,
      focusRequest: null,
      ...over,
    } as Props,
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
    attachTo,
  })
}

const inputAt = (w: ReturnType<typeof mountTable>, r: number, c: number) =>
  w.find(`[data-target-id="cell:1:${r}:${c}"] input`)

describe('ResultTable', () => {
  beforeEach(() => bubble.mockClear())

  it('見出し・ヘッダー行・セルが無い座標・数値の右寄せを描画する', () => {
    const wrapper = mountTable()
    expect(wrapper.text()).toContain('表 2（5行 × 3列）')
    expect(wrapper.get('[data-target-id="cell:1:0:0"]').classes()).toContain(
      'tbl-cell--header',
    )
    expect(
      wrapper.get('[data-target-id="cell:1:1:0"]').classes(),
    ).not.toContain('tbl-cell--header')
    expect(wrapper.findAll('[data-testid="grid-cell-empty"]')).toHaveLength(1)
    expect(wrapper.get('[data-target-id="cell:1:4:2"]').classes()).toContain(
      'tbl-cell--num',
    )
    expect(
      wrapper.get('[data-target-id="cell:1:4:1"]').classes(),
    ).not.toContain('tbl-cell--num')
    const input = inputAt(wrapper, 1, 0)
    expect(input.attributes()).toMatchObject({
      'aria-label': '2行1列',
      maxlength: '2000',
      size: '1',
      'data-testid': 'cell-input',
    })
    // 列幅は CSS 変数で渡す（列定義は stylesheet 側）
    expect(wrapper.get('.tbl').attributes('style')).toContain(
      '--tbl-columns: minmax(8ch, 11fr) minmax(8ch, 18fr) minmax(8ch, 8fr)',
    )
    // 表ごとに role=group + 見出しへの aria-labelledby（複数の表でセルの名前が同名になるのを防ぐ）
    const root = wrapper.get('[data-testid="grid-table"]')
    expect(root.attributes('role')).toBe('group')
    const headingId = root.attributes('aria-labelledby')
    expect(wrapper.get(`[id="${headingId}"]`).text()).toBe('表 2（5行 × 3列）')
  })

  it('連続する空行を畳み、クリックで展開・再度隠せる', async () => {
    const wrapper = mountTable()
    const gap = wrapper.get('[data-testid="grid-gap"]')
    expect(gap.text()).toBe('空行 2 行を表示')
    expect(gap.attributes('aria-expanded')).toBe('false')
    expect(inputAt(wrapper, 2, 0).exists()).toBe(false)

    await gap.trigger('click')
    expect(gap.text()).toBe('空行 2 行を隠す')
    expect(gap.attributes('aria-expanded')).toBe('true')
    expect(inputAt(wrapper, 2, 0).exists()).toBe(true)
    expect(inputAt(wrapper, 3, 2).exists()).toBe(true)

    await gap.trigger('click')
    expect(inputAt(wrapper, 2, 0).exists()).toBe(false)
  })

  // 下書きのある行は空行にしない（入力中の行が畳まれない）。塊が分かれても展開済みの行は開いたまま
  it('下書きのある行は畳まず、展開済みの行は塊が分かれても開いたままにする', async () => {
    const wrapper = mountTable()
    await wrapper.get('[data-testid="grid-gap"]').trigger('click')
    await wrapper.setProps({ draftCells: { '1:2:1': '追記' } })
    expect((inputAt(wrapper, 2, 1).element as HTMLInputElement).value).toBe(
      '追記',
    )
    expect(inputAt(wrapper, 3, 0).exists()).toBe(true)
    expect(wrapper.get('[data-target-id="cell:1:2:1"]').classes()).toContain(
      'tbl-cell--draft',
    )

    // 最初から下書きがある行は、畳まれた状態でも表示する
    const fresh = mountTable({ draftCells: { '1:3:0': 'X' } })
    expect(inputAt(fresh, 3, 0).exists()).toBe(true)
    expect(inputAt(fresh, 2, 0).exists()).toBe(false)
    expect(fresh.get('[data-testid="grid-gap"]').text()).toBe('空行 1 行を表示')
  })

  // キャンバスで畳まれた行のセルが選択されたら、その塊を展開する（フォーカスは親が行う）
  it('focusRequest が畳まれた行のセルを指したら展開する', async () => {
    const wrapper = mountTable()
    await wrapper.setProps({ focusRequest: { id: 'cell:0:3:1', seq: 1 } })
    expect(inputAt(wrapper, 3, 1).exists()).toBe(false) // 別の表への要求は無視
    await wrapper.setProps({ focusRequest: { id: 'cell:1:3:1', seq: 2 } })
    expect(inputAt(wrapper, 3, 1).exists()).toBe(true)
    expect(inputAt(wrapper, 2, 0).exists()).toBe(true)
  })

  it('入力で cellInput、フォーカスで targetFocus を bubble し、下書きの値を表示する', async () => {
    const wrapper = mountTable({ draftCells: { '1:1:1': '下書き' } })
    expect((inputAt(wrapper, 1, 1).element as HTMLInputElement).value).toBe(
      '下書き',
    )
    await inputAt(wrapper, 1, 0).setValue('TST-002')
    expect(bubble).toHaveBeenCalledWith({
      type: 'cellInput',
      table: 1,
      row: 1,
      column: 0,
      value: 'TST-002',
    })
    await inputAt(wrapper, 1, 0).trigger('focus')
    expect(bubble).toHaveBeenCalledWith({
      type: 'targetFocus',
      id: 'cell:1:1:0',
    })
  })

  // 保存済みの修正は三角印（装飾）。読み上げ用に hidden のテキスト「修正済」を aria-describedby で参照する
  it('保存済みの修正セルに印と読み上げ用の説明を付け、下書きがあれば下書きを優先する', () => {
    const wrapper = mountTable({
      correctedCells: new Set(['1:1:0', '1:1:1']),
      draftCells: { '1:1:1': 'x' },
    })
    const corrected = wrapper.get('[data-target-id="cell:1:1:0"]')
    expect(corrected.classes()).toContain('tbl-cell--corrected')
    expect(corrected.attributes('title')).toBe('修正済')
    const description = wrapper.get('[hidden]')
    expect(description.text()).toBe('修正済')
    expect(inputAt(wrapper, 1, 0).attributes('aria-describedby')).toBe(
      description.attributes('id'),
    )
    const drafted = wrapper.get('[data-target-id="cell:1:1:1"]')
    expect(drafted.classes()).toContain('tbl-cell--draft')
    expect(drafted.classes()).not.toContain('tbl-cell--corrected')
    expect(inputAt(wrapper, 1, 2).exists()).toBe(false)
  })

  it('activeId のセルに aria-current と選択中クラスを付ける', () => {
    const wrapper = mountTable({ activeId: 'cell:1:1:1' })
    expect(inputAt(wrapper, 1, 1).attributes('aria-current')).toBe('true')
    expect(wrapper.get('[data-target-id="cell:1:1:1"]').classes()).toContain(
      'target--active',
    )
    expect(inputAt(wrapper, 1, 0).attributes('aria-current')).toBeUndefined()
  })

  // 数値らしさは元の読取値で判定する（下書きでは判定しない。列幅と同じ方針）
  it('数値かどうかは下書きでなく元の読取値で判定する', () => {
    const wrapper = mountTable({
      draftCells: { '1:4:2': '10箱', '1:2:0': '100' },
    })
    // 元が数値のセルは、下書きが数値でなくなっても右寄せのまま
    expect(wrapper.get('[data-target-id="cell:1:4:2"]').classes()).toContain(
      'tbl-cell--num',
    )
    // 元が空のセルは、下書きが数値でも右寄せにならない
    expect(
      wrapper.get('[data-target-id="cell:1:2:0"]').classes(),
    ).not.toContain('tbl-cell--num')
  })

  // 行が塊（block）ごとの keyed Fragment の子だと、入力で塊が g2 → g2/r3/g4 に分かれたとき
  // 入力中の行が別キーの配下に移り <input> が破棄・再生成されフォーカスを失う。行番号キーで直す
  it('展開した空行の中ほどの行に入力しても、塊が分かれても・合流してもフォーカスを保つ', async () => {
    const wrapper = mountTable({ table: tableWithLongGap }, document.body)
    try {
      await wrapper.get('[data-testid="grid-gap"]').trigger('click')
      const before = inputAt(wrapper, 3, 0).element as HTMLInputElement
      before.focus()

      // 1 文字目を入力（行 3 が空行でなくなり、塊が g2 / r3 / g4 に分かれる）
      before.value = 'a'
      before.dispatchEvent(new Event('input', { bubbles: true }))
      await wrapper.setProps({ draftCells: { '1:3:0': 'a' } })
      expect(inputAt(wrapper, 3, 0).element).toBe(before)
      expect(before.isConnected).toBe(true)
      expect(document.activeElement).toBe(before)

      // 元に戻す（行 3 が空行に戻り、塊が 1 つに戻る）
      await wrapper.setProps({ draftCells: {} })
      expect(inputAt(wrapper, 3, 0).element).toBe(before)
      expect(document.activeElement).toBe(before)
    } finally {
      wrapper.unmount()
    }
  })

  // 塊の先頭行に入力すると g2 が消えて g3 が生まれるケース。同じ理由で同じ確認をする
  it('展開した空行の先頭行に入力しても、塊が分かれてもフォーカスを保つ', async () => {
    const wrapper = mountTable({ table: tableWithLongGap }, document.body)
    try {
      await wrapper.get('[data-testid="grid-gap"]').trigger('click')
      const before = inputAt(wrapper, 2, 0).element as HTMLInputElement
      before.focus()

      before.value = 'a'
      before.dispatchEvent(new Event('input', { bubbles: true }))
      await wrapper.setProps({ draftCells: { '1:2:0': 'a' } })
      expect(inputAt(wrapper, 2, 0).element).toBe(before)
      expect(document.activeElement).toBe(before)
    } finally {
      wrapper.unmount()
    }
  })

  // isExpanded を gap.start だけで判定すると、展開 → 行 3 に入力 → 両隣の塊を隠す → 入力を空へ戻す、で
  // 行 3 が「空行 N 行を表示」に吸われて消える。塊内のどこか 1 行でも展開済みなら開いた扱いにして直す
  it('入力中の行の両隣の塊を隠してから入力を戻しても、行が空行の塊に吸われて消えない', async () => {
    const wrapper = mountTable({ table: tableWithLongGap })
    try {
      await wrapper.get('[data-testid="grid-gap"]').trigger('click')
      await wrapper.setProps({ draftCells: { '1:3:0': 'x' } })
      expect(inputAt(wrapper, 3, 0).exists()).toBe(true)

      for (const gap of wrapper.findAll('[data-testid="grid-gap"]')) {
        await gap.trigger('click')
      }
      expect(inputAt(wrapper, 3, 0).exists()).toBe(true)

      await wrapper.setProps({ draftCells: {} })
      expect(inputAt(wrapper, 3, 0).exists()).toBe(true)
    } finally {
      wrapper.unmount()
    }
  })

  // 展開 → 行3に入力 → 両隣の塊を隠す → 行3を空へ戻す（some() で行2・4も再表示）→ 行2に入力 →
  // 残りの塊を隠す → 行2を空へ戻す、という経路では、行2自身が一度も setExpanded を通らないまま
  // 空行に戻るため、行2が expandedRows に無く塊に吸われて <input> が消えていた
  it('別の行への入力を経由しても、入力中の行が空行の塊に吸われて消えない', async () => {
    const wrapper = mountTable({ table: tableWithLongGap })
    try {
      const type = async (
        r: number,
        value: string,
        drafts: Record<string, string>,
      ): Promise<void> => {
        const el = inputAt(wrapper, r, 0).element as HTMLInputElement
        el.value = value
        el.dispatchEvent(new Event('input', { bubbles: true }))
        await wrapper.setProps({ draftCells: drafts })
      }
      const hideAllGaps = async (): Promise<void> => {
        for (const gap of wrapper.findAll('[data-testid="grid-gap"]')) {
          await gap.trigger('click')
        }
      }

      await wrapper.get('[data-testid="grid-gap"]').trigger('click')
      await type(3, 'x', { '1:3:0': 'x' })
      await hideAllGaps()
      await type(3, '', {})
      expect(inputAt(wrapper, 2, 0).exists()).toBe(true) // some() で行2・4も再表示

      await type(2, 'y', { '1:2:0': 'y' })
      await hideAllGaps()
      await type(2, '', {})
      expect(inputAt(wrapper, 2, 0).exists()).toBe(true)
    } finally {
      wrapper.unmount()
    }
  })
})
