import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import { defineComponent, h } from 'vue'

import { BUBBLE, useBubble } from '../src/mediator/bubble'
import type { AppEvent } from '../src/mediator/events'

const event: AppEvent = { type: 'rectClick', id: 'field:a' }

// 葉が bubble した操作を中間ノードが処理しなければ、Root が provide した dispatch へ届く
function makeTree(middleHandle?: (e: AppEvent) => boolean) {
  const Leaf = defineComponent({
    setup() {
      const bubble = useBubble()
      return () => h('button', { onClick: () => bubble(event) })
    },
  })
  const Middle = defineComponent({
    setup() {
      useBubble(middleHandle)
      return () => h(Leaf)
    },
  })
  return Middle
}

describe('useBubble', () => {
  it('子の bubble は中間ノードを経て Root の dispatch へ届く', async () => {
    const root = vi.fn()
    const middle = vi.fn().mockReturnValue(false)
    const wrapper = mount(makeTree(middle), {
      global: { provide: { [BUBBLE as symbol]: root } },
    })

    await wrapper.get('button').trigger('click')

    expect(middle).toHaveBeenCalledWith(event)
    expect(root).toHaveBeenCalledWith(event)
  })

  it('中間ノードの handle が true を返すと親へ伝えない', async () => {
    const root = vi.fn()
    const wrapper = mount(
      makeTree(() => true),
      {
        global: { provide: { [BUBBLE as symbol]: root } },
      },
    )

    await wrapper.get('button').trigger('click')

    expect(root).not.toHaveBeenCalled()
  })

  it('Root の provide が無くても例外にならない', async () => {
    const wrapper = mount(makeTree())
    await expect(
      wrapper.get('button').trigger('click'),
    ).resolves.toBeUndefined()
  })
})
