import { describe, expect, it } from 'vitest'

import { fitZoom } from '../src/utils/zoom'

// 倍率はページ実寸（1 インチ = 96px）に対する %。letter（8.5×11 インチ）の実寸は 816×1056px
// スクローラの内寸: 幅 = clientWidth - 48（左右 padding）、高さ = clientHeight - 74（上下 padding 48 + 枠下マージン 24 + 枠線 2）
const letter = { width: 8.5, height: 11 }

describe('fitZoom', () => {
  it('width は内寸幅に 1 ページの幅が収まる実寸比 %', () => {
    // 内寸幅 1272-48=1224px / 816px = 150%、864-48=816px / 816px = 100%
    expect(fitZoom('width', 1272, 400, letter)).toBe(150)
    expect(fitZoom('width', 864, 400, letter)).toBe(100)
  })

  // 右ペインの幅を変えても、高さが制約の間はページ全体の倍率が変わらない（#168）
  it('page は 1 ページが幅にも高さにも収まる実寸比 %（両者の小さいほう）', () => {
    // 高さが制約: 幅 150% / 高さ 可視高さ 866-74=792px / 1056px = 75%
    expect(fitZoom('page', 1272, 866, letter)).toBe(75)
    // 幅を狭めても高さが制約のまま: 幅 100% / 高さ 75%
    expect(fitZoom('page', 864, 866, letter)).toBe(75)
    // 幅が制約: 内寸幅 456-48=408px / 816px = 50% / 高さ 75%
    expect(fitZoom('page', 456, 866, letter)).toBe(50)
  })

  it('端数は切り捨てる（はみ出さない側）', () => {
    // 内寸幅 1048-48=1000px / 816px = 122.5…% → 122
    expect(fitZoom('width', 1048, 400, letter)).toBe(122)
  })

  it('浮動小数誤差で 1% 落とさない', () => {
    // 595pt 幅の A4（595/72 インチ = 793.33…px）で内寸幅 762-48=714px はちょうど 90%。
    // 浮動小数では 89.999… になるため、切り捨てだけだと 89 になる
    expect(
      fitZoom('width', 762, 400, { width: 595 / 72, height: 842 / 72 }),
    ).toBe(90)
  })

  it('フィット値は 25〜200 に制限せず、下限は 1', () => {
    // 内寸幅 2496-48=2448px / 816px = 300%
    expect(fitZoom('width', 2496, 400, letter)).toBe(300)
    // 可視高さ 78-74=4px / 1056px = 0.37…%（幅 122% より小さい）→ floor 0 → 下限 1
    expect(fitZoom('page', 1048, 78, letter)).toBe(1)
  })

  it('計測不能（サイズ 0）のときは 100 を返す', () => {
    expect(fitZoom('width', 0, 0, letter)).toBe(100)
    expect(fitZoom('page', 0, 0, letter)).toBe(100)
  })
})
