import { describe, expect, it } from 'vitest'

import {
  columnTemplate,
  isNumeric,
  rowBlocks,
  textWidth,
} from '../src/utils/table'

describe('textWidth', () => {
  it('半角は 1、全角は 1.7 として数える', () => {
    expect(textWidth('TST-001')).toBe(7)
    expect(textWidth('商品名')).toBeCloseTo(5.1)
    expect(textWidth('')).toBe(0)
  })
})

describe('columnTemplate', () => {
  // w = ceil(min(24, max(3, 最大文字幅))) + 2、各列 minmax(min(w, 8)ch, w fr)
  it('内容の最大文字幅の比で列を配分する', () => {
    const columns = [
      ['商品コード', 'TST-001'], // 8.5 → 9 + 2 = 11
      ['単位', '箱'], // 3.4 → 4 + 2 = 6
      ['', ''], // 下限 3 + 2 = 5
      ['あ'.repeat(40)], // 上限 24 + 2 = 26
    ]
    expect(columnTemplate(4, (c) => columns[c]!)).toBe(
      'minmax(8ch, 11fr) minmax(6ch, 6fr) minmax(5ch, 5fr) minmax(8ch, 26fr)',
    )
  })

  it('列が無ければ空文字', () => {
    expect(columnTemplate(0, () => [])).toBe('')
  })
})

describe('rowBlocks', () => {
  it('連続する空行を 1 つの塊にまとめる', () => {
    const empty = new Set([2, 3, 4, 6])
    expect(rowBlocks(8, (r) => empty.has(r))).toEqual([
      { kind: 'row', row: 0 },
      { kind: 'row', row: 1 },
      { kind: 'gap', start: 2, count: 3 },
      { kind: 'row', row: 5 },
      { kind: 'gap', start: 6, count: 1 },
      { kind: 'row', row: 7 },
    ])
  })

  it('行が無ければ空', () => {
    expect(rowBlocks(0, () => true)).toEqual([])
  })
})

describe('isNumeric', () => {
  it('数字を含み、¥・桁区切り・小数点・符号・空白だけなら数値', () => {
    for (const s of ['10', '3,300', '¥ 74,800', '-1.5', '\\1,000'])
      expect(isNumeric(s)).toBe(true)
    for (const s of ['', '-', ',', 'TST-001', '10箱', '合計金額'])
      expect(isNumeric(s)).toBe(false)
  })
})
