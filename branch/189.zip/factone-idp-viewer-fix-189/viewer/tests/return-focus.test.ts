import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, describe, expect, it } from 'vitest'
import { defineComponent, h } from 'vue'

import { useReturnFocus } from '../src/utils/returnFocus'

// ダイアログの開閉だけを持つ部品。forget は確定でダイアログを閉じる部品が呼ぶ
const Harness = defineComponent({
  props: { open: Boolean, fallback: { type: Object, default: null } },
  setup(props, { expose }) {
    const forget = useReturnFocus(
      () => props.open,
      () => props.fallback as HTMLElement | null,
    )
    expose({ forget })
    return () => h('div')
  },
})

// body に置いたボタン。テストの後に afterEach で外す
const added: HTMLElement[] = []
function button(): HTMLButtonElement {
  const el = document.createElement('button')
  document.body.append(el)
  added.push(el)
  return el
}

// 開いた時点のフォーカス要素（opener）を作り、ダイアログを開いて中身（inside）へフォーカスを移した状態にする
async function openFrom(opener: HTMLElement | null) {
  const fallback = button()
  const inside = button()
  opener?.focus()
  const wrapper = mount(Harness, { props: { open: false, fallback } })
  await wrapper.setProps({ open: true })
  inside.focus()
  return { wrapper, fallback, inside }
}

enableAutoUnmount(afterEach)

afterEach(() => {
  for (const el of added.splice(0)) el.remove()
  ;(document.activeElement as HTMLElement | null)?.blur()
})

describe('useReturnFocus', () => {
  it('閉じたら、開いた時点でフォーカスのあった要素へ戻す', async () => {
    const opener = button()
    const { wrapper } = await openFrom(opener)
    await wrapper.setProps({ open: false })
    expect(document.activeElement).toBe(opener)
  })

  // 自動で開いたダイアログ（開いた時点のフォーカスが body）
  it('開いた時点でどの要素にもフォーカスが無ければ、閉じたら fallback へ移す', async () => {
    const { wrapper, fallback } = await openFrom(null)
    expect(document.activeElement).not.toBe(fallback)
    await wrapper.setProps({ open: false })
    expect(document.activeElement).toBe(fallback)
  })

  // 開いてすぐ閉じたなど、中身へフォーカスが移る前に閉じた場合
  it('開いた時点も閉じた時点もフォーカスが body なら、閉じたら fallback へ移す', async () => {
    const fallback = button()
    const wrapper = mount(Harness, { props: { open: false, fallback } })
    await wrapper.setProps({ open: true })
    await wrapper.setProps({ open: false })
    expect(document.activeElement).toBe(fallback)
  })

  // 画面に残っていても、無効・非表示でフォーカスを受けられなければ戻せない
  it.each([
    ['画面から消えた', (el: HTMLButtonElement) => el.remove()],
    ['無効になった', (el: HTMLButtonElement) => (el.disabled = true)],
  ])('開いた時点の要素が%sら、閉じたら fallback へ移す', async (_, change) => {
    const opener = button()
    const { wrapper, fallback } = await openFrom(opener)
    change(opener)
    await wrapper.setProps({ open: false })
    expect(document.activeElement).toBe(fallback)
  })

  it('forget の後に閉じたら、開いた時点の要素が残っていても fallback へ移す', async () => {
    const opener = button()
    const { wrapper, fallback } = await openFrom(opener)
    ;(wrapper.vm as unknown as { forget: () => void }).forget()
    await wrapper.setProps({ open: false })
    expect(document.activeElement).toBe(fallback)
  })

  // 開いたまま部品ごと消えると、閉じる変化が来ない
  it('開いたまま unmount したら、開いた時点の要素へ戻す', async () => {
    const opener = button()
    const { wrapper } = await openFrom(opener)
    wrapper.unmount()
    expect(document.activeElement).toBe(opener)
  })

  it('閉じたままなら、mount でも unmount でもフォーカスを動かさない', () => {
    const fallback = button()
    const current = button()
    current.focus()
    const wrapper = mount(Harness, { props: { open: false, fallback } })
    wrapper.unmount()
    expect(document.activeElement).toBe(current)
  })
})
