import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { RegisterVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { configs, registerVm } from './fixtures'

const pdf = new File(['%PDF-1.4'], 'order.pdf', { type: 'application/pdf' })
const bubble = vi.fn()

function mountForm(over: Partial<RegisterVm> = {}) {
  return mount(DocumentRegisterForm, {
    props: { vm: registerVm(over) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// 文書ID・種別・PDFを入力済みにする
async function fillForm(wrapper: ReturnType<typeof mountForm>) {
  await wrapper
    .get('[data-testid="register-document-id"] input')
    .setValue('doc-9')
  await wrapper
    .findComponent({ name: 'VSelect' })
    .vm.$emit('update:modelValue', 'quotation')
  await wrapper
    .findComponent({ name: 'VFileUpload' })
    .vm.$emit('update:modelValue', pdf)
  await flushPromises()
}

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentRegisterForm', () => {
  // 種別一覧は vm から受け取り、display_name を選択肢として表示する
  it('vm の種別一覧を選択肢に表示する', () => {
    const select = mountForm().findComponent({ name: 'VSelect' })
    expect(select.props('items')).toEqual(configs)
    expect(select.props('itemTitle')).toBe('display_name')
    expect(select.props('itemValue')).toBe('type_code')
  })

  // 送信は入力値を register として bubble する（multipart 化と API 呼出は Mediator）
  it('送信で register を bubble する', async () => {
    const wrapper = mountForm()
    await fillForm(wrapper)
    await wrapper.get('form').trigger('submit')
    expect(bubble).toHaveBeenCalledWith({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
  })

  // 未入力（文書ID・種別・PDFのいずれか欠落）では登録ボタンを無効化し、送信しない
  it('未入力では登録ボタンを無効化し送信しない', async () => {
    const wrapper = mountForm()
    const button = wrapper.get<HTMLButtonElement>(
      '[data-testid="register-submit"]',
    )
    expect(button.element.disabled).toBe(true)
    await wrapper.get('form').trigger('submit')
    expect(bubble).not.toHaveBeenCalled()

    await fillForm(wrapper)
    expect(button.element.disabled).toBe(false)
  })

  // ドロップゾーンはPDFのみ受け付け（D&Dはaccept属性が効かないためfilter-by-typeで絞る）、選択後はゾーン内にファイル名を表示する
  it('ドロップゾーンはPDFのみ受け付け選択後はゾーン内にファイル名を表示する', async () => {
    const wrapper = mountForm()
    const upload = wrapper.findComponent({ name: 'VFileUpload' })
    expect(upload.props('filterByType')).toBe('application/pdf')
    expect(upload.props('insetFileList')).toBe(true)

    await upload.vm.$emit('update:modelValue', pdf)
    await flushPromises()
    expect(wrapper.get('.v-file-upload-dropzone').text()).toContain('order.pdf')
  })

  it('vm のエラーを表示し、送信中はボタンを loading にする', () => {
    const wrapper = mountForm({
      error: '文書IDは別の内容で登録済みです',
      submitting: true,
    })
    expect(wrapper.get('[data-testid="register-error"]').text()).toContain(
      '文書IDは別の内容で登録済み',
    )
    expect(wrapper.get('[data-testid="register-submit"]').classes()).toContain(
      'v-btn--loading',
    )
  })
})
