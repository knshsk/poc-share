import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

// API呼出はapiClient経由のためモックする（画面はキャンバス組込とエラーstateが検証対象）
const getMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
}))

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import { createAppVuetify } from '../src/plugins/vuetify'
import PublicView from '../src/views/PublicView.vue'

function respond(path: string) {
  if (path === '/view/{token}/pages') {
    return Promise.resolve({
      data: { pages: [{ width: 8.5, height: 11 }] },
      error: undefined,
    })
  }
  if (path === '/view/{token}/pdf') {
    return Promise.resolve({ data: undefined, error: {} })
  }
  return Promise.resolve({ data: new Blob(), error: undefined })
}

function mountView() {
  return mount(PublicView, {
    props: { token: 'tok-1' },
    global: { plugins: [createAppVuetify(), createPinia()] },
  })
}

describe('PublicView', () => {
  beforeEach(() => {
    getMock.mockReset()
    getMock.mockImplementation((path: string) => respond(path))
  })

  // ページ取得後に DocumentCanvas（token 経路・ダウンロード文言）を表示することを確認する（#149）
  it('ページ取得後にキャンバスを表示する', async () => {
    const wrapper = mountView()
    expect(wrapper.find('.v-skeleton-loader').exists()).toBe(true)
    await flushPromises()

    const canvas = wrapper.findComponent(DocumentCanvas)
    expect(canvas.exists()).toBe(true)
    expect(canvas.props('token')).toBe('tok-1')
    expect(canvas.props('pages')).toEqual([{ width: 8.5, height: 11 }])
    expect(wrapper.get('[data-testid="download-original"]').text()).toContain(
      'ダウンロード',
    )
    expect(wrapper.find('.v-skeleton-loader').exists()).toBe(false)
  })

  // 無効な閲覧URL（ページ取得失敗）はエラーstateを表示し、本文を出さないことを確認する
  it('ページ取得失敗でエラーstateを表示する', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/view/{token}/pages'
        ? Promise.resolve({ data: undefined, error: {} })
        : respond(path),
    )
    const wrapper = mountView()
    await flushPromises()

    expect(wrapper.get('[data-testid="public-error"]').text()).toContain(
      'この閲覧URLは無効です',
    )
    expect(wrapper.findComponent(DocumentCanvas).exists()).toBe(false)
  })

  // ダウンロード失敗時はエラーstateへ切り替わり本文を消すことを確認する
  it('ダウンロード失敗でエラーstateを表示する', async () => {
    const wrapper = mountView()
    await flushPromises()

    await wrapper.get('[data-testid="download-original"]').trigger('click')
    await flushPromises()
    expect(wrapper.get('[data-testid="public-error"]').text()).toContain(
      'ダウンロードできませんでした',
    )
    expect(wrapper.findComponent(DocumentCanvas).exists()).toBe(false)
  })
})
