import { describe, expect, it, vi } from 'vitest'

import { filenameFromDisposition, saveBlob } from '../src/utils/download'

describe('filenameFromDisposition', () => {
  it('filename*（UTF-8 percent-encoded）を優先してデコードする', () => {
    expect(
      filenameFromDisposition(
        'attachment; filename="doc-1.pdf"; filename*=UTF-8\'\'%E8%A6%8B%E7%A9%8D%E6%9B%B8%20A.pdf',
        'x.pdf',
      ),
    ).toBe('見積書 A.pdf')
  })

  it('filename* が無ければ filename を使う', () => {
    expect(
      filenameFromDisposition('attachment; filename="doc-1.pdf"', 'x.pdf'),
    ).toBe('doc-1.pdf')
  })

  it('ヘッダ無し・解析不能はフォールバック', () => {
    expect(filenameFromDisposition(null, 'x.pdf')).toBe('x.pdf')
    expect(filenameFromDisposition('attachment', 'x.pdf')).toBe('x.pdf')
  })
})

describe('saveBlob', () => {
  // 一時 URL を作ってアンカーの click で保存し、URL を解放することを確認する
  it('アンカー経由で保存し blob URL を解放する', () => {
    const createSpy = vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:x')
    const revokeSpy = vi
      .spyOn(URL, 'revokeObjectURL')
      .mockImplementation(() => {})
    const clickSpy = vi
      .spyOn(HTMLAnchorElement.prototype, 'click')
      .mockImplementation(function (this: HTMLAnchorElement) {
        expect(this.download).toBe('q.pdf')
        expect(this.href).toBe('blob:x')
      })

    saveBlob(new Blob(), 'q.pdf')
    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(clickSpy).toHaveBeenCalledTimes(1)
    expect(revokeSpy).toHaveBeenCalledWith('blob:x')
    vi.restoreAllMocks()
  })
})
