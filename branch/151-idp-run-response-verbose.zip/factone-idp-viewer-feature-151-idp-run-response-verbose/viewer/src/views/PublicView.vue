<script setup lang="ts">
import { PhWarningCircle } from '@phosphor-icons/vue'
import { onMounted, ref } from 'vue'

import { apiClient } from '../api/client'
import type { PageInfo } from '../components/DocumentCanvas.vue'
import DocumentCanvas from '../components/DocumentCanvas.vue'
import { filenameFromDisposition, saveBlob } from '../utils/download'

const props = defineProps<{ token: string }>()

const pages = ref<PageInfo[]>([])
const errorMessage = ref<string | null>(null)

onMounted(async () => {
  const { data, error } = await apiClient.GET('/view/{token}/pages', {
    params: { path: { token: props.token } },
  })
  if (error || !data) {
    errorMessage.value = 'この閲覧URLは無効です'
    return
  }
  pages.value = data.pages
})

async function download(): Promise<void> {
  const { data, error, response } = await apiClient.GET('/view/{token}/pdf', {
    params: { path: { token: props.token } },
    parseAs: 'blob',
  })
  if (error || !data) {
    errorMessage.value = 'ダウンロードできませんでした'
    return
  }
  saveBlob(
    data,
    filenameFromDisposition(
      response.headers.get('content-disposition'),
      'document.pdf',
    ),
  )
}
</script>

<template>
  <!-- 無効URL / ダウンロード失敗: エラーstate（認証後 Viewer と同じ見た目。再試行は出さない） -->
  <div v-if="errorMessage" class="state-screen">
    <PhWarningCircle :size="48" class="text-error mb-4" />
    <p class="text-body-1" data-testid="public-error">{{ errorMessage }}</p>
  </div>

  <!-- 閲覧者向けはキャンバス全幅（読取矩形・右ペインなし）。ページ画像の遅延読込は PageSvg 側で page_view 記録の契機になる -->
  <div v-else class="public-layout">
    <DocumentCanvas
      v-if="pages.length > 0"
      :token="token"
      :pages="pages"
      download-label="ダウンロード"
      @download-original="download"
    />
    <div v-else class="canvas-loading">
      <v-skeleton-loader type="image" class="page-skeleton" />
    </div>
  </div>
</template>

<style scoped>
/* DocumentView の 2 ペインと同じ高さ計算（app-bar・footer を除く）でキャンバス内スクロールにする */
.public-layout {
  height: calc(100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px));
}
</style>
