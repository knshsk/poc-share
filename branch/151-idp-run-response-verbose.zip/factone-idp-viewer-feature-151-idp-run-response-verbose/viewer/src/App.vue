<script setup lang="ts">
import { onMounted } from 'vue'

import AppHeader from './components/AppHeader.vue'
import { useAuthStore } from './stores/auth'
import DocumentView from './views/DocumentView.vue'
import PublicView from './views/PublicView.vue'

const auth = useAuthStore()

// 閲覧URL（/view/{token}）は認証なしの顧客閲覧画面（ルーター未導入のためパス判定）
const viewToken = window.location.pathname.startsWith('/view/')
  ? window.location.pathname.split('/')[2]
  : null

onMounted(async () => {
  // ルーター未導入のため、コールバックURLはパスで判定して処理する
  // （ログイン前URLへの復元はhandleCallback内で行う）
  if (window.location.pathname === '/callback') {
    await auth.handleCallback()
  }
})
</script>

<template>
  <v-app>
    <template v-if="viewToken">
      <AppHeader />
      <v-main class="bg-background">
        <PublicView :token="viewToken" />
      </v-main>
    </template>

    <template v-else-if="auth.isAuthenticated">
      <AppHeader />
      <v-main class="bg-background">
        <DocumentView />
      </v-main>
    </template>

    <v-main v-else class="bg-background">
      <div class="login-screen">
        <v-card class="login-card pa-8" elevation="2" rounded="lg">
          <div class="text-primary font-weight-bold text-h6 mb-2">
            FactONE Viewer
          </div>
          <p class="text-secondary text-body-2 mb-6">
            プロトタイプ実装中のため、動作は予告なく変更される可能性があります。
          </p>
          <v-btn color="primary" block size="large" @click="auth.login">
            ログイン
          </v-btn>
        </v-card>
      </div>
    </v-main>

    <!-- 下端表示領域。全状態で表示。リンクはプレースホルダ（文言・遷移先は後続で確定） -->
    <v-footer
      app
      height="32"
      color="surface"
      class="app-footer text-caption text-secondary py-0"
      data-testid="app-footer"
    >
      <span>FactONE Viewer</span>
      <v-spacer />
      <a href="#" class="footer-link">プライバシーポリシー</a>
      <a href="#" class="footer-link">お問い合わせ</a>
      <a href="#" class="footer-link">ライセンス</a>
    </v-footer>
  </v-app>
</template>

<style scoped>
.login-screen {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: calc(
    100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px)
  );
}

.login-card {
  width: 360px;
  max-width: 90vw;
}

.app-footer {
  gap: 16px;
  border-top: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.footer-link {
  color: inherit;
  text-decoration: none;
}

.footer-link:hover {
  text-decoration: underline;
}
</style>
