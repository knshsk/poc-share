import type { components } from '../api/schema'

export type IdpRun = components['schemas']['IdpRunResponse']
export type IdpRunSummary = components['schemas']['IdpRunSummary']
export type Corrections = components['schemas']['CorrectionRequest']
export type TableCell = components['schemas']['TableCell']

export const RUN_TYPE_LABEL: Record<IdpRunSummary['run_type'], string> = {
  initial: '初回',
  rerun: '再実行',
  corrected: '修正',
}

// キャンバス⇄右ペインの相互ハイライトで使う要素 ID（draft の cellKey "t:r:c" とは別物）
export const fieldId = (key: string): string => `field:${key}`
export const cellId = (table: number, row: number, col: number): string =>
  `cell:${table}:${row}:${col}`

// キャンバス上の読取矩形。座標は DI 座標系（インチ）のまま。PageSvg の viewBox と同一単位
export interface OverlayRect {
  id: string
  kind: 'field' | 'cell'
  // アクセシブル名（<title>）。キー項目 = ラベル（無ければキー）、セル = 「表 n の r 行 c 列」（1 始まり）
  label: string
  x: number
  y: number
  width: number
  height: number
}

// DI polygon（x, y の交互配列）の外接矩形
export function polygonToRect(
  polygon: number[],
): Omit<OverlayRect, 'id' | 'kind' | 'label'> {
  const xs = polygon.filter((_, i) => i % 2 === 0)
  const ys = polygon.filter((_, i) => i % 2 === 1)
  const x = Math.min(...xs)
  const y = Math.min(...ys)
  return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y }
}

// 選択中の成功実行からページ番号ごとの矩形を作る。
// セル = polygon あり全件、キー項目 = region あり・visible=true（hiddenKeys 外）・value 非 null。
// region / polygon は verbose=true の応答にだけ含まれる。無ければ矩形なし。
// セルを先・キー項目を後に並べる（重なり時にキー項目が前面）。失敗実行・未選択は空
export function overlayRectsByPage(
  run: IdpRun | null,
  hiddenKeys: ReadonlySet<string>,
): Map<number, OverlayRect[]> {
  const byPage = new Map<number, OverlayRect[]>()
  if (!run || run.status !== 'succeeded') return byPage
  const push = (page: number, rect: OverlayRect): void => {
    const list = byPage.get(page) ?? []
    list.push(rect)
    byPage.set(page, list)
  }
  ;(run.tables ?? []).forEach((table, t) => {
    for (const cell of table.cells) {
      if (!cell.polygon || cell.polygon.length < 4 || cell.page_number == null)
        continue
      push(cell.page_number, {
        id: cellId(t, cell.row_index, cell.column_index),
        kind: 'cell',
        label: `表 ${t + 1} の ${cell.row_index + 1} 行 ${cell.column_index + 1} 列`,
        ...polygonToRect(cell.polygon),
      })
    }
  })
  for (const [key, field] of Object.entries(run.fields ?? {})) {
    const region = field.region
    if (
      !region ||
      region.polygon.length < 4 ||
      hiddenKeys.has(key) ||
      field.value == null
    )
      continue
    push(region.page_number, {
      id: fieldId(key),
      kind: 'field',
      label: field.label ?? key,
      ...polygonToRect(region.polygon),
    })
  }
  return byPage
}
