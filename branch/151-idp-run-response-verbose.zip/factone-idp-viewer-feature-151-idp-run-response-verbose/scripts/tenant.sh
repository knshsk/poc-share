#!/usr/bin/env bash
# テナント運用スクリプト（realm factone を kcadm で操作する）
#
# 使い方:
#   ./scripts/tenant.sh create <tenant_id>
#       M2M クライアント factone-integration-<tenant_id> を作成し、シークレットを標準出力に表示する
#   ./scripts/tenant.sh add-user <tenant_id> <username> <email>
#       属性 tenant_id 付きのユーザーを作成する（初期パスワードは KC_NEW_USER_PASSWORD。初回ログインで変更を強制）
#   ./scripts/tenant.sh disable <tenant_id>
#       クライアントと所属ユーザーを無効化する（文書・Blob・設定は残す。閲覧 URL は失効しない）
#   ./scripts/tenant.sh enable <tenant_id>
#       無効化を取り消す
#
# 接続先は KC_SERVER（既定 http://localhost:8080。Azure は https://<Keycloak の FQDN>）。
# 管理者は KC_BOOTSTRAP_ADMIN_USERNAME / KC_BOOTSTRAP_ADMIN_PASSWORD（未設定なら .env から補う）。
# kcadm はローカルの Keycloak コンテナ内のものを使う（KEYCLOAK_CONTAINER、既定 factone-idp-viewer_keycloak_1）。
# default テナント（factone-integration / testuser）は realm 定義由来のため本スクリプトの対象外。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${SCRIPT_DIR}/.."
CONTAINER="${KEYCLOAK_CONTAINER:-factone-idp-viewer_keycloak_1}"
KC_SERVER="${KC_SERVER:-http://localhost:8080}"
REALM="factone"
TENANT_ID_PATTERN='^[a-z0-9][a-z0-9-]{0,62}$'

usage() {
  sed -n '2,/^set -euo pipefail/p' "${BASH_SOURCE[0]}" | sed '$d' | sed 's/^# \{0,1\}//' >&2
  exit 1
}

# .env は未設定の変数だけ補う（コマンドラインで渡した値を優先する）。
# 解釈は apply-keycloak-secrets.sh と同じく bash の source に任せる
load_env() {
  [[ -f "${REPO_ROOT}/.env" ]] || return 0
  local var
  for var in KC_BOOTSTRAP_ADMIN_USERNAME KC_BOOTSTRAP_ADMIN_PASSWORD KC_NEW_USER_PASSWORD; do
    # shellcheck source=/dev/null
    [[ -n "${!var:-}" ]] || export "${var}=$(set -a; source "${REPO_ROOT}/.env" >/dev/null 2>&1; printf '%s' "${!var:-}")"
  done
}

kc() {
  podman exec "${CONTAINER}" /opt/keycloak/bin/kcadm.sh "$@"
}

require_var() {
  if [[ -z "${!1:-}" ]]; then
    echo "エラー: ${1} を設定してください" >&2
    exit 1
  fi
}

validate_tenant_id() {
  if [[ ! "$1" =~ ${TENANT_ID_PATTERN} ]]; then
    echo "エラー: tenant_id は ${TENANT_ID_PATTERN} に一致させてください: $1" >&2
    exit 1
  fi
  if [[ "$1" == "default" ]]; then
    echo "エラー: default テナントは realm 定義で管理するため本スクリプトの対象外です" >&2
    exit 1
  fi
}

login() {
  require_var KC_BOOTSTRAP_ADMIN_USERNAME
  require_var KC_BOOTSTRAP_ADMIN_PASSWORD
  kc config credentials --server "${KC_SERVER}" --realm master \
    --user "${KC_BOOTSTRAP_ADMIN_USERNAME}" --password "${KC_BOOTSTRAP_ADMIN_PASSWORD}"
}

client_uuid() {
  kc get clients -r "${REALM}" -q "clientId=$1" --fields id --format csv --noquotes
}

cmd_create() {
  local tenant_id="$1"
  local client_id="factone-integration-${tenant_id}"
  local existing
  existing=$(client_uuid "${client_id}")
  if [[ -n "${existing}" ]]; then
    echo "エラー: クライアント ${client_id} は既に存在します" >&2
    exit 1
  fi
  local uuid
  uuid=$(kc create clients -r "${REALM}" -i \
    -s "clientId=${client_id}" \
    -s "name=FactONE Integration (${tenant_id})" \
    -s enabled=true -s protocol=openid-connect -s publicClient=false \
    -s standardFlowEnabled=false -s directAccessGrantsEnabled=false \
    -s serviceAccountsEnabled=true)
  kc create "clients/${uuid}/protocol-mappers/models" -r "${REALM}" \
    -s name=factone-api-audience -s protocol=openid-connect \
    -s protocolMapper=oidc-audience-mapper \
    -s 'config."included.custom.audience"=factone-api' \
    -s 'config."access.token.claim"=true' \
    -s 'config."id.token.claim"=false'
  kc create "clients/${uuid}/protocol-mappers/models" -r "${REALM}" \
    -s name=tenant-id -s protocol=openid-connect \
    -s protocolMapper=oidc-hardcoded-claim-mapper \
    -s 'config."claim.name"=tenant_id' \
    -s "config.\"claim.value\"=${tenant_id}" \
    -s 'config."jsonType.label"=String' \
    -s 'config."access.token.claim"=true' \
    -s 'config."id.token.claim"=false' \
    -s 'config."userinfo.token.claim"=false'
  local secret
  secret=$(kc get "clients/${uuid}/client-secret" -r "${REALM}" --fields value --format csv --noquotes)
  echo "作成: ${client_id}"
  echo "client_secret: ${secret}"
  echo "（シークレットはこの出力にしか出ない。テナントの連携システムへ安全な経路で渡すこと）"
}

cmd_add_user() {
  local tenant_id="$1" username="$2" email="$3"
  local client_uuid_value
  client_uuid_value=$(client_uuid "factone-integration-${tenant_id}")
  if [[ -z "${client_uuid_value}" ]]; then
    echo "エラー: テナント ${tenant_id} が見つかりません（先に create を実行してください）" >&2
    exit 1
  fi
  require_var KC_NEW_USER_PASSWORD
  local existing
  existing=$(kc get users -r "${REALM}" -q "username=${username}" -q exact=true --fields id --format csv --noquotes)
  if [[ -n "${existing}" ]]; then
    echo "エラー: ユーザー ${username} は既に存在します" >&2
    exit 1
  fi
  kc create users -r "${REALM}" \
    -s "username=${username}" -s "email=${email}" \
    -s enabled=true -s emailVerified=true \
    -s "attributes.tenant_id=[\"${tenant_id}\"]"
  kc set-password -r "${REALM}" --username "${username}" \
    --new-password "${KC_NEW_USER_PASSWORD}" --temporary
  echo "作成: ${username}（tenant_id=${tenant_id}。初回ログインでパスワード変更）"
}

set_enabled() {
  local tenant_id="$1" enabled="$2"
  local client_id="factone-integration-${tenant_id}"
  local uuid
  uuid=$(client_uuid "${client_id}")
  if [[ -z "${uuid}" ]]; then
    echo "エラー: クライアント ${client_id} が見つかりません" >&2
    exit 1
  fi
  kc update "clients/${uuid}" -r "${REALM}" -s "enabled=${enabled}"
  local user_ids
  user_ids=$(kc get users -r "${REALM}" -q "q=tenant_id:${tenant_id}" --fields id --format csv --noquotes)
  for user_id in ${user_ids}; do
    kc update "users/${user_id}" -r "${REALM}" -s "enabled=${enabled}"
  done
  echo "enabled=${enabled}: ${client_id} とユーザー $(grep -c . <<<"${user_ids}" || true) 件"
}

main() {
  [[ $# -ge 2 ]] || usage
  local cmd="$1"
  shift
  validate_tenant_id "$1"
  load_env
  login
  case "${cmd}" in
    create)
      [[ $# -eq 1 ]] || usage
      cmd_create "$1"
      ;;
    add-user)
      [[ $# -eq 3 ]] || usage
      cmd_add_user "$1" "$2" "$3"
      ;;
    disable)
      [[ $# -eq 1 ]] || usage
      set_enabled "$1" false
      ;;
    enable)
      [[ $# -eq 1 ]] || usage
      set_enabled "$1" true
      ;;
    *)
      usage
      ;;
  esac
}

main "$@"
