"""documents を内部 UUID 主キーにし (tenant_id, document_id) を一意にする

呼出側採番の document_id はテナント内でのみ一意とし、テナント間の衝突を許す（ADR-0021）。
子テーブル（view_tokens / view_events / idp_runs）の外部キーを document_id（文字列）から
documents.id（UUID）の document_pk へ張り替える。既存行は JOIN で埋める。

downgrade は document_id を復元するが、テナント間で同じ document_id が存在すると
主キー再作成で失敗する（旧スキーマでは表現できないため）。

Revision ID: d7e4b2c9a1f6
Revises: e1c9d4a7b283
Create Date: 2026-09-15 10:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "d7e4b2c9a1f6"
down_revision: str | None = "e1c9d4a7b283"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CHILD_TABLES = ("view_tokens", "view_events", "idp_runs")


def upgrade() -> None:
    # 1. documents.id を追加して既存行を埋める
    op.add_column("documents", sa.Column("id", sa.Uuid(), nullable=True))
    op.execute("UPDATE documents SET id = gen_random_uuid()")
    op.alter_column("documents", "id", nullable=False)

    # 2. 子テーブルに document_pk を追加して JOIN で埋め、旧外部キーを落とす
    for table in _CHILD_TABLES:
        op.add_column(table, sa.Column("document_pk", sa.Uuid(), nullable=True))
        op.execute(
            f"UPDATE {table} AS t SET document_pk = d.id "
            f"FROM documents AS d WHERE d.document_id = t.document_id"
        )
        op.alter_column(table, "document_pk", nullable=False)
        op.drop_constraint(f"{table}_document_id_fkey", table, type_="foreignkey")

    # 3. 旧冪等キーと旧列を落とす
    op.drop_constraint("uq_view_events_idempotency", "view_events", type_="unique")
    for table in _CHILD_TABLES:
        op.drop_column(table, "document_id")

    # 4. 主キーを付け替え、テナント内一意制約を足す
    op.drop_constraint("documents_pkey", "documents", type_="primary")
    op.create_primary_key("documents_pkey", "documents", ["id"])
    op.create_unique_constraint(
        "uq_documents_tenant_document", "documents", ["tenant_id", "document_id"]
    )

    # 5. 新外部キーと新冪等キー
    for table in _CHILD_TABLES:
        op.create_foreign_key(
            f"{table}_document_pk_fkey", table, "documents", ["document_pk"], ["id"]
        )
    op.create_unique_constraint(
        "uq_view_events_idempotency",
        "view_events",
        ["document_pk", "occurred_at", "event_type"],
    )


def downgrade() -> None:
    op.drop_constraint("uq_view_events_idempotency", "view_events", type_="unique")
    for table in _CHILD_TABLES:
        op.drop_constraint(f"{table}_document_pk_fkey", table, type_="foreignkey")
        op.add_column(
            table, sa.Column("document_id", sa.String(length=255), nullable=True)
        )
        op.execute(
            f"UPDATE {table} AS t SET document_id = d.document_id "
            f"FROM documents AS d WHERE d.id = t.document_pk"
        )
        op.alter_column(table, "document_id", nullable=False)
        op.drop_column(table, "document_pk")

    op.drop_constraint("uq_documents_tenant_document", "documents", type_="unique")
    op.drop_constraint("documents_pkey", "documents", type_="primary")
    op.create_primary_key("documents_pkey", "documents", ["document_id"])
    op.drop_column("documents", "id")

    for table in _CHILD_TABLES:
        op.create_foreign_key(
            f"{table}_document_id_fkey",
            table,
            "documents",
            ["document_id"],
            ["document_id"],
        )
    op.create_unique_constraint(
        "uq_view_events_idempotency",
        "view_events",
        ["document_id", "occurred_at", "event_type"],
    )
