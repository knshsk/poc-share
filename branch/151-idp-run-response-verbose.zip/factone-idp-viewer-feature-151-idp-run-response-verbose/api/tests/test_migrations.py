"""documents 内部 UUID 主キー化（d7e4b2c9a1f6）のデータ移行テスト。

旧スキーマ（e1c9d4a7b283）に文書・トークン・イベント・実行ログを入れてから upgrade し、
子テーブルの document_pk が documents.id で埋まること、旧 document_id 列が消えることを確認する。
"""

import uuid

from alembic import command
from sqlalchemy import create_engine, text

from tests.conftest import alembic_config

PREVIOUS = "e1c9d4a7b283"
TARGET = "d7e4b2c9a1f6"
CHILD_TABLES = ("view_tokens", "view_events", "idp_runs")


def test_upgrade_fills_document_pk_from_legacy_rows(test_database_url: str) -> None:
    """旧スキーマの行が新外部キーへ移行されることを確認する（downgrade → 投入 → upgrade）。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.downgrade(config, PREVIOUS)

    token_id, event_id, run_id = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    with engine.begin() as conn:
        conn.execute(
            text(
                "INSERT INTO documents (document_id, tenant_id, document_type, blob_ref, "
                "content_sha256, received_at) VALUES ('mig-doc', 'default', 'quotation', "
                "'default/mig-doc.pdf', 'sha', now())"
            )
        )
        conn.execute(
            text(
                "INSERT INTO view_tokens (id, token_hash, document_id, expires_at, revoked) "
                "VALUES (:id, 'hash-mig', 'mig-doc', now() + interval '1 day', false)"
            ),
            {"id": token_id},
        )
        conn.execute(
            text(
                "INSERT INTO view_events (id, document_id, view_token_id, event_type, "
                "occurred_at, client_ip, user_agent) "
                "VALUES (:id, 'mig-doc', :token_id, 'view', now(), '127.0.0.1', 'ua')"
            ),
            {"id": event_id, "token_id": token_id},
        )
        conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_id, run_type, status, executed_at) "
                "VALUES (:id, 'mig-doc', 'initial', 'failed', now())"
            ),
            {"id": run_id},
        )

    command.upgrade(config, TARGET)

    with engine.connect() as conn:
        document_pk = conn.execute(
            text(
                "SELECT id FROM documents "
                "WHERE tenant_id = 'default' AND document_id = 'mig-doc'"
            )
        ).scalar_one()
        for table in CHILD_TABLES:
            assert (
                conn.execute(text(f"SELECT document_pk FROM {table}")).scalar_one()
                == document_pk
            )
        legacy_columns = conn.execute(
            text(
                "SELECT count(*) FROM information_schema.columns "
                "WHERE table_name IN ('view_tokens', 'view_events', 'idp_runs') "
                "AND column_name = 'document_id'"
            )
        ).scalar_one()
        assert legacy_columns == 0
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    engine.dispose()


def test_downgrade_and_upgrade_round_trip(test_database_url: str) -> None:
    """空データで downgrade / upgrade を往復できることを確認する。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    engine.dispose()

    command.downgrade(config, PREVIOUS)
    command.upgrade(config, "head")
