import time
from typing import Any

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient

from app.core.auth import StaticKeySource
from app.core.config import Settings
from app.main import create_app

ISSUER = "http://localhost:8080/realms/factone"
AUDIENCE = "factone-api"


@pytest.fixture(scope="module")
def private_key() -> RSAPrivateKey:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture(scope="module")
def other_key() -> RSAPrivateKey:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture
def auth_client(private_key: RSAPrivateKey) -> TestClient:
    settings = Settings(_env_file=None)  # type: ignore[call-arg]
    app = create_app(
        settings=settings, key_source=StaticKeySource(private_key.public_key())
    )
    return TestClient(app)


def make_token(key: RSAPrivateKey, **overrides: Any) -> str:
    claims: dict[str, Any] = {
        "iss": ISSUER,
        "aud": AUDIENCE,
        "sub": "user-id-123",
        "preferred_username": "testuser",
        "tenant_id": "default",
        "exp": int(time.time()) + 300,
        **overrides,
    }
    # 値が None のクレームは省く（クレーム欠落のテスト用）
    claims = {k: v for k, v in claims.items() if v is not None}
    return jwt.encode(claims, key, algorithm="RS256")


def test_me_returns_user_info_with_valid_token(
    auth_client: TestClient, private_key: RSAPrivateKey
) -> None:
    """有効なトークンで /api/v1/me が認証ユーザー情報を返すことを確認する。"""
    token = make_token(private_key)

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 200
    assert response.json() == {"sub": "user-id-123", "username": "testuser"}


def test_me_rejects_missing_token(auth_client: TestClient) -> None:
    """トークンなしのアクセスが401になることを確認する。"""
    response = auth_client.get("/api/v1/me")

    assert response.status_code == 401


def test_me_rejects_expired_token(
    auth_client: TestClient, private_key: RSAPrivateKey
) -> None:
    """期限切れトークンが401になることを確認する。"""
    token = make_token(private_key, exp=int(time.time()) - 60)

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 401


def test_me_rejects_wrong_issuer(
    auth_client: TestClient, private_key: RSAPrivateKey
) -> None:
    """issuer不一致のトークンが401になることを確認する。"""
    token = make_token(private_key, iss="http://evil.example.com/realms/factone")

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 401


def test_me_rejects_wrong_audience(
    auth_client: TestClient, private_key: RSAPrivateKey
) -> None:
    """audience不一致のトークンが401になることを確認する。"""
    token = make_token(private_key, aud="other-api")

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 401


def test_me_rejects_token_signed_by_other_key(
    auth_client: TestClient, other_key: RSAPrivateKey
) -> None:
    """別鍵で署名されたトークン（偽造）が401になることを確認する。"""
    token = make_token(other_key)

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 401


def test_me_rejects_unsigned_token(auth_client: TestClient) -> None:
    """無署名（alg=none）トークンが401になることを確認する。"""
    token = jwt.encode(
        {"iss": ISSUER, "aud": AUDIENCE, "sub": "x", "exp": int(time.time()) + 300},
        key="",
        algorithm="none",
    )

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 401


def test_health_stays_public(auth_client: TestClient) -> None:
    """/health が認証なしで応答し続けることを確認する。"""
    response = auth_client.get("/health")

    assert response.status_code == 200


def test_me_rejects_token_without_tenant_claim(
    auth_client: TestClient, private_key: RSAPrivateKey
) -> None:
    """tenant_id クレームが無い正当なトークンは 403 tenant-unresolved になることを確認する。"""
    token = make_token(private_key, tenant_id=None)

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 403
    assert response.json()["type"] == "/errors/tenant-unresolved"


@pytest.mark.parametrize(
    "tenant_id", ["", 123, ["default"], "Bad_ID", "../x", "a" * 64]
)
def test_me_rejects_malformed_tenant_claim(
    auth_client: TestClient, private_key: RSAPrivateKey, tenant_id: object
) -> None:
    """tenant_id が空文字・文字列以外のトークンは 403 になることを確認する。"""
    token = make_token(private_key, tenant_id=tenant_id)

    response = auth_client.get(
        "/api/v1/me", headers={"Authorization": f"Bearer {token}"}
    )

    assert response.status_code == 403
    assert response.json()["type"] == "/errors/tenant-unresolved"
