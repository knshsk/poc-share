"""テナント分離の統合テスト（異常系・重点領域）。

テナント default で登録した文書に対し、テナント other のトークンで各 API を呼ぶと
存在を秘匿した 404 になること、同じ document_id をテナントごとに登録できることを確認する。
"""

import pytest
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient

from tests.conftest import OTHER_TENANT, InMemoryBlobStorage, as_tenant
from tests.test_documents_api import post_document


@pytest.mark.parametrize("document_id", ["../escape", "a/b", "a\\b", ".", ".."])
def test_register_rejects_path_unsafe_document_id(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage, document_id: str
) -> None:
    """document_id が Blob パス区切り・ディレクトリ参照を含む場合 422 になり、
    Blob へ保存されないことを確認する（テナント境界越えの防止）。
    """
    response = post_document(doc_client, document_id=document_id)

    assert response.status_code == 422
    assert not blob_storage.saved


@pytest.fixture
def registered(doc_client: TestClient) -> str:
    response = post_document(doc_client, document_id="iso-doc")
    assert response.status_code == 201
    return "iso-doc"


def test_register_uses_tenant_from_token(
    doc_client: TestClient,
    signing_key: RSAPrivateKey,
    blob_storage: InMemoryBlobStorage,
) -> None:
    """登録時の tenant_id と Blob パスがトークンのテナントになることを確認する。"""
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = post_document(doc_client, document_id="iso-reg")

    assert response.status_code == 201
    assert response.json()["tenant_id"] == OTHER_TENANT
    assert "other/iso-reg.pdf" in blob_storage.saved


def test_same_document_id_can_exist_in_two_tenants(
    doc_client: TestClient,
    signing_key: RSAPrivateKey,
    registered: str,
    blob_storage: InMemoryBlobStorage,
) -> None:
    """別テナントは同じ document_id を新規登録でき（201）、互いに独立していることを確認する。"""
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = post_document(
        doc_client, document_id=registered, content=b"%PDF-1.7 other"
    )

    assert response.status_code == 201
    assert response.json()["tenant_id"] == OTHER_TENANT
    assert {"default/iso-doc.pdf", "other/iso-doc.pdf"} <= set(blob_storage.saved)


@pytest.mark.parametrize(
    ("method", "path"),
    [
        ("GET", "/api/v1/documents/{doc}"),
        ("GET", "/api/v1/documents/{doc}/pages"),
        ("GET", "/api/v1/documents/{doc}/pages/1/image"),
        ("GET", "/api/v1/documents/{doc}/pdf"),
        ("POST", "/api/v1/documents/{doc}/idp-runs"),
        ("GET", "/api/v1/documents/{doc}/idp-runs"),
        ("GET", "/api/v1/documents/{doc}/idp-runs/latest"),
    ],
)
def test_other_tenant_gets_404_for_document_routes(
    doc_client: TestClient,
    signing_key: RSAPrivateKey,
    registered: str,
    method: str,
    path: str,
) -> None:
    """他テナントの文書は文書系・IDP 実行系の全ルートで 404 になることを確認する。"""
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = doc_client.request(method, path.format(doc=registered))

    assert response.status_code == 404
    assert response.json()["type"] == "/errors/document-not-found"


def test_other_tenant_cannot_read_idp_run_by_id(
    doc_client: TestClient, signing_key: RSAPrivateKey, registered: str
) -> None:
    """実行 ID を知っていても他テナントからは 404 になることを確認する。"""
    run = doc_client.post(f"/api/v1/documents/{registered}/idp-runs")
    assert run.status_code == 201
    runs = doc_client.get(f"/api/v1/documents/{registered}/idp-runs").json()["runs"]
    run_id = runs[0]["run_id"]
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = doc_client.get(f"/api/v1/documents/{registered}/idp-runs/{run_id}")

    assert response.status_code == 404


def test_document_type_configs_are_tenant_scoped(
    doc_client: TestClient, signing_key: RSAPrivateKey
) -> None:
    """テナント default で作った種別が other の一覧・取得に出ないことを確認する。"""
    created = doc_client.post(
        "/api/v1/config/document-types",
        json={
            "type_code": "iso_only",
            "display_name": "分離確認",
            "shareable": True,
            "fields": [{"key": "A", "label": "A", "type": "string"}],
        },
    )
    assert created.status_code == 201
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    codes = [
        c["type_code"] for c in doc_client.get("/api/v1/config/document-types").json()
    ]
    single = doc_client.get("/api/v1/config/document-types/iso_only")

    assert "iso_only" not in codes
    assert single.status_code == 404


def test_register_rejects_type_configured_only_for_other_tenant(
    doc_client: TestClient, signing_key: RSAPrivateKey
) -> None:
    """種別の存在判定もトークンのテナントで行われることを確認する（422）。"""
    created = doc_client.post(
        "/api/v1/config/document-types",
        json={
            "type_code": "default_only",
            "display_name": "default 専用",
            "shareable": True,
            "fields": [{"key": "A", "label": "A", "type": "string"}],
        },
    )
    assert created.status_code == 201
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = post_document(
        doc_client, document_id="iso-422", document_type="default_only"
    )

    assert response.status_code == 422
    assert response.json()["type"] == "/errors/unknown-document-type"


@pytest.fixture
def issued(doc_client: TestClient, registered: str) -> dict[str, str]:
    response = doc_client.post(f"/api/v1/documents/{registered}/view-urls")
    assert response.status_code == 201
    return dict(response.json())


@pytest.mark.parametrize(
    ("method", "path"),
    [
        ("POST", "/api/v1/documents/{doc}/view-urls"),
        ("GET", "/api/v1/documents/{doc}/view-urls"),
        ("GET", "/api/v1/documents/{doc}/events"),
        ("POST", "/api/v1/documents/{doc}/view-urls/revoke-all"),
    ],
)
def test_other_tenant_gets_404_for_view_url_routes(
    doc_client: TestClient,
    signing_key: RSAPrivateKey,
    registered: str,
    method: str,
    path: str,
) -> None:
    """他テナントの文書は閲覧 URL 系の全ルートで 404 になることを確認する。"""
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = doc_client.request(method, path.format(doc=registered))

    assert response.status_code == 404


def test_other_tenant_cannot_revoke_view_url_by_id(
    doc_client: TestClient, signing_key: RSAPrivateKey, issued: dict[str, str]
) -> None:
    """管理 ID を知っていても他テナントからの単体失効は 404 で、URL は有効なままであることを確認する。"""
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = doc_client.post(f"/api/v1/view-urls/{issued['id']}/revoke")

    assert response.status_code == 404
    assert response.json()["type"] == "/errors/view-url-not-found"
    token = issued["view_path"].removeprefix("/view/")
    assert doc_client.get(f"/view/{token}/pdf").status_code == 200


def test_view_event_feed_is_tenant_scoped(
    doc_client: TestClient, signing_key: RSAPrivateKey, issued: dict[str, str]
) -> None:
    """閲覧イベント差分フィードに他テナントの文書のイベントが含まれないことを確認する。"""
    token = issued["view_path"].removeprefix("/view/")
    assert doc_client.get(f"/view/{token}/pdf").status_code == 200
    assert len(doc_client.get("/api/v1/view-events").json()) == 1
    as_tenant(doc_client, signing_key, OTHER_TENANT)

    response = doc_client.get("/api/v1/view-events")

    assert response.status_code == 200
    assert response.json() == []


def test_public_view_works_regardless_of_tenant_header(
    doc_client: TestClient, issued: dict[str, str]
) -> None:
    """閲覧者経路は無認証で、Authorization ヘッダの有無に関わらず文書に到達できることを確認する。"""
    token = issued["view_path"].removeprefix("/view/")
    del doc_client.headers["Authorization"]

    # post_document の既定内容は描画できない疑似 PDF のため、レンダリングしない /pdf で確認する
    response = doc_client.get(f"/view/{token}/pdf")

    assert response.status_code == 200
