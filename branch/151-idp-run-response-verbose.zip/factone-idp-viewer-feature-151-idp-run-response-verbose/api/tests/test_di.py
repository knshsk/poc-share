"""Document Intelligence境界のテーブル抽出テスト。

Azure SDKの解析結果（duck-typedスタブ）からDiTableへの変換を検証する。
"""

from types import SimpleNamespace
from typing import Any

import pytest

from app.services.di import (
    AzureDocumentAnalyzer,
    DiError,
    build_analysis_result,
    extract_tables,
)


def _region(page_number: int, polygon: list[float]) -> SimpleNamespace:
    return SimpleNamespace(page_number=page_number, polygon=polygon)


def _cell(
    row_index: int,
    column_index: int,
    content: str,
    kind: str | None = None,
    bounding_regions: list[SimpleNamespace] | None = None,
    row_span: int | None = None,
    column_span: int | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        row_index=row_index,
        column_index=column_index,
        content=content,
        kind=kind,
        bounding_regions=bounding_regions,
        row_span=row_span,
        column_span=column_span,
    )


def _table(
    row_count: int, column_count: int, cells: list[SimpleNamespace]
) -> SimpleNamespace:
    return SimpleNamespace(row_count=row_count, column_count=column_count, cells=cells)


class TestExtractTables:
    def test_extracts_all_recognized_tables(self) -> None:
        # 複数テーブル認識時は全件返す（明細領域の特定はSaaS責務外）
        tables: list[Any] = [
            _table(
                2,
                2,
                [
                    _cell(
                        0,
                        0,
                        "品目",
                        kind="columnHeader",
                        bounding_regions=[_region(1, [1.0, 2.0, 3.0, 2.0])],
                    ),
                    _cell(
                        1,
                        0,
                        "P-9001",
                        bounding_regions=[_region(1, [1.0, 3.0, 3.0, 3.0])],
                    ),
                ],
            ),
            _table(1, 1, [_cell(0, 0, "備考")]),
        ]
        extracted = extract_tables(tables)
        assert len(extracted) == 2
        first = extracted[0]
        assert first.row_count == 2
        assert first.column_count == 2
        header = first.cells[0]
        assert header.row_index == 0
        assert header.column_index == 0
        assert header.content == "品目"
        assert header.kind == "columnHeader"
        assert header.page_number == 1
        assert header.polygon == (1.0, 2.0, 3.0, 2.0)
        assert extracted[1].cells[0].content == "備考"

    def test_cell_without_bounding_regions_has_no_position(self) -> None:
        tables: list[Any] = [_table(1, 1, [_cell(0, 0, "x", bounding_regions=None)])]
        cell = extract_tables(tables)[0].cells[0]
        assert cell.page_number is None
        assert cell.polygon is None

    def test_no_tables_yields_empty(self) -> None:
        # layout応答にtablesが無い（None）場合は空
        assert extract_tables(None) == ()
        assert extract_tables([]) == ()

    def test_extracts_row_and_column_span(self) -> None:
        # 結合セルは DI の rowSpan / columnSpan をそのまま持つ
        tables: list[Any] = [
            _table(2, 2, [_cell(0, 0, "結合", row_span=2, column_span=2)])
        ]
        cell = extract_tables(tables)[0].cells[0]
        assert cell.row_span == 2
        assert cell.column_span == 2

    def test_missing_span_defaults_to_one(self) -> None:
        # SDK は span 省略可（省略 = 1 の意味）
        tables: list[Any] = [_table(1, 1, [_cell(0, 0, "x")])]
        cell = extract_tables(tables)[0].cells[0]
        assert cell.row_span == 1
        assert cell.column_span == 1


def _field(
    content: str | None,
    confidence: float | None,
    bounding_regions: list[SimpleNamespace] | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        content=content, confidence=confidence, bounding_regions=bounding_regions
    )


def _analyze_result(
    fields: dict[str, SimpleNamespace] | None,
    api_version: str = "2024-11-30",
    model_id: str = "prebuilt-layout",
) -> SimpleNamespace:
    documents = [SimpleNamespace(fields=fields)] if fields is not None else []
    return SimpleNamespace(
        api_version=api_version,
        model_id=model_id,
        content="全文",
        documents=documents,
        tables=None,
    )


class TestBuildAnalysisResult:
    def test_extracts_fields_with_region_and_di_info(self) -> None:
        # Query Fields の値・確信度に加え、boundingRegions[0] の座標を項目別に取り出す
        result = _analyze_result(
            {
                "TotalAmount": _field(
                    "1,200,000",
                    0.96,
                    bounding_regions=[
                        _region(1, [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1])
                    ],
                ),
            }
        )
        analysis = build_analysis_result(result, b'{"status":"succeeded"}')
        field = analysis.fields["TotalAmount"]
        assert field.value == "1,200,000"
        assert field.confidence == 0.96
        assert field.page_number == 1
        assert field.polygon == (6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1)
        assert analysis.content == "全文"
        assert analysis.api_version == "2024-11-30"
        assert analysis.model_id == "prebuilt-layout"
        assert analysis.raw_response == b'{"status":"succeeded"}'

    def test_field_without_bounding_regions_has_no_position(self) -> None:
        result = _analyze_result({"Code": _field("A-1", 0.5, bounding_regions=None)})
        field = build_analysis_result(result, b"{}").fields["Code"]
        assert field.page_number is None
        assert field.polygon is None

    def test_no_documents_yields_empty_fields(self) -> None:
        analysis = build_analysis_result(_analyze_result(None), b"{}")
        assert analysis.fields == {}
        assert analysis.tables == ()


class _FakePoller:
    """LROPollerのフェイク。done=Falseでタイムアウト（wait後も未完了）を再現する。"""

    def __init__(
        self,
        done: bool = True,
        resource: tuple[Any, bytes] = (None, b""),
        wait_error: Exception | None = None,
    ) -> None:
        self._done = done
        self._resource = resource
        self._wait_error = wait_error

    def wait(self, timeout: float | None = None) -> None:
        if self._wait_error is not None:
            raise self._wait_error

    def done(self) -> bool:
        return self._done

    def result(self) -> tuple[Any, bytes]:
        return self._resource


def _analyzer(poller: _FakePoller) -> AzureDocumentAnalyzer:
    # SDKクライアント生成（認証）を避けるため __init__ を通さずフェイクを差し込む
    analyzer = AzureDocumentAnalyzer.__new__(AzureDocumentAnalyzer)
    analyzer._client = SimpleNamespace(  # type: ignore[assignment]
        begin_analyze_document=lambda *args, **kwargs: poller
    )
    analyzer._timeout_seconds = 1
    return analyzer


class TestAzureDocumentAnalyzer:
    def test_timeout_raises_di_error(self) -> None:
        # azure-coreのresult(timeout)は未完了でも例外を出さず戻るため、done()で判定してDiErrorにする
        analyzer = _analyzer(_FakePoller(done=False))
        with pytest.raises(DiError, match="timed out"):
            analyzer.analyze(b"%PDF", ("TotalAmount",))

    def test_azure_error_is_converted_to_di_error(self) -> None:
        from azure.core.exceptions import HttpResponseError

        analyzer = _analyzer(_FakePoller(wait_error=HttpResponseError("boom")))
        with pytest.raises(DiError, match="boom"):
            analyzer.analyze(b"%PDF", ())

    def test_completed_result_is_built(self) -> None:
        raw = b'{"status":"succeeded"}'
        analyzer = _analyzer(_FakePoller(resource=(_analyze_result(None), raw)))
        analysis = analyzer.analyze(b"%PDF", ())
        assert analysis.raw_response == raw
        assert analysis.model_id == "prebuilt-layout"
