"""データモデル定義。設計はdocs/data-model/を参照。"""

import enum
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Document(Base):
    """文書メタデータ。文書IDは呼出側採番で、SaaS内では採番しない。

    主キーは内部 UUID（id）。呼出側採番の document_id はテナント内でのみ一意で、
    テナント間の衝突を許す（ADR-0021）。
    """

    __tablename__ = "documents"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "document_id", name="uq_documents_tenant_document"
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    document_id: Mapped[str] = mapped_column(String(255))
    tenant_id: Mapped[str] = mapped_column(String(255))
    document_type: Mapped[str] = mapped_column(String(50))
    blob_ref: Mapped[str] = mapped_column(String(1024))
    content_sha256: Mapped[str] = mapped_column(String(64))
    # アップロード時のファイル名（basename）。原本DLの保存名に使う。列追加前の行は NULL
    original_filename: Mapped[str | None] = mapped_column(String(255), nullable=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class ViewToken(Base):
    """閲覧URLトークン。

    トークン平文は保存せずSHA-256ハッシュのみ保持する（DB漏洩時もURL再構成不可）。
    失効は revoked の行更新（追記型の実行ログと異なり、状態変更が仕様）。
    """

    __tablename__ = "view_tokens"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    document_pk: Mapped[uuid.UUID] = mapped_column(ForeignKey("documents.id"))
    document: Mapped[Document] = relationship()
    issued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


class ViewEventType(enum.StrEnum):
    """閲覧イベント種別。"""

    VIEW = "view"
    DOWNLOAD = "download"
    PAGE_VIEW = "page_view"


class ViewEvent(Base):
    """閲覧・DLイベント。追記型（更新・削除しない）。

    冪等キー（文書の内部ID+イベント発生日時+種別）をUNIQUE制約で担保。
    案件IDは保持しない（外部連携側が文書IDから解決する）。
    page は page_view のみ値を持つ（1始まり）。view / download は NULL。
    """

    __tablename__ = "view_events"
    __table_args__ = (
        UniqueConstraint(
            "document_pk",
            "occurred_at",
            "event_type",
            name="uq_view_events_idempotency",
        ),
        CheckConstraint(
            "event_type IN ('view', 'download', 'page_view')",
            name="ck_view_events_event_type",
        ),
        CheckConstraint(
            "(event_type = 'page_view') = (page IS NOT NULL)",
            name="ck_view_events_page",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    document_pk: Mapped[uuid.UUID] = mapped_column(ForeignKey("documents.id"))
    view_token_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("view_tokens.id"))
    event_type: Mapped[str] = mapped_column(String(20))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    client_ip: Mapped[str] = mapped_column(String(64))
    user_agent: Mapped[str] = mapped_column(String(512))
    page: Mapped[int | None] = mapped_column(Integer)


class IdpRunType(enum.StrEnum):
    """IDP実行区分。initial/rerunは同一文書IDの既存実行有無からサーバ側で判定する。
    correctedは人手修正（base_run_idの実行結果に差分を当てて追記した行）。"""

    INITIAL = "initial"
    RERUN = "rerun"
    CORRECTED = "corrected"


class IdpRunStatus(enum.StrEnum):
    """IDP実行の処理状態。"""

    SUCCEEDED = "succeeded"
    FAILED = "failed"


class IdpRun(Base):
    """IDP実行ログ。追記型（再実行で過去結果を上書きしない）。

    生値（raw_fields）・正規化値（normalized_fields）・確信度（confidence）を
    項目別JSONで分離保持する。失敗実行もerror_info付きで記録する。
    生応答はBlobに保存し参照（raw_response_ref）のみ保持する。
    人手修正は run_type='corrected' の行として追記する（ADR-0018）。
    """

    __tablename__ = "idp_runs"
    __table_args__ = (
        CheckConstraint(
            "run_type IN ('initial', 'rerun', 'corrected')",
            name="ck_idp_runs_run_type",
        ),
        CheckConstraint(
            "status IN ('succeeded', 'failed')",
            name="ck_idp_runs_status",
        ),
        # corrected 行のみ base_run_id / corrected_by を持つ
        CheckConstraint(
            "(run_type = 'corrected') = (base_run_id IS NOT NULL)",
            name="ck_idp_runs_corrected_base",
        ),
        CheckConstraint(
            "(run_type = 'corrected') = (corrected_by IS NOT NULL)",
            name="ck_idp_runs_corrected_by",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    document_pk: Mapped[uuid.UUID] = mapped_column(ForeignKey("documents.id"))
    document: Mapped[Document] = relationship()
    run_type: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20))
    executed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    raw_fields: Mapped[dict[str, str | None] | None] = mapped_column(
        JSONB, nullable=True
    )
    normalized_fields: Mapped[dict[str, str | int | None] | None] = mapped_column(
        JSONB, nullable=True
    )
    confidence: Mapped[dict[str, float | None] | None] = mapped_column(
        JSONB, nullable=True
    )
    field_labels: Mapped[dict[str, str] | None] = mapped_column(JSONB, nullable=True)
    tables: Mapped[list[dict[str, object]] | None] = mapped_column(JSONB, nullable=True)
    # 正規表現パターンのマッチ結果 {key: {"label", "regex", "values": [...]}}。失敗時はNULL
    pattern_matches: Mapped[dict[str, dict[str, object]] | None] = mapped_column(
        JSONB, nullable=True
    )
    # 項目別の読取領域 {key: {"page_number": int, "polygon": [...]} | None}。失敗時はNULL
    field_regions: Mapped[dict[str, dict[str, object] | None] | None] = mapped_column(
        JSONB, nullable=True
    )
    # DI応答の analyzeResult.apiVersion / modelId。失敗時はNULL
    di_api_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    di_model_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    # 生応答（最終ポーリング応答本文）のBlobパス {tenant}/{document_id}/idp-runs/{run_id}.json。失敗時はNULL
    raw_response_ref: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    # 人手修正（corrected）のみ非NULL。base_run_id は修正元の実行結果、corrections は根の機械実行に対する人手差分の累積
    base_run_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("idp_runs.id"), nullable=True
    )
    corrected_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    corrections: Mapped[dict[str, object] | None] = mapped_column(JSONB, nullable=True)
    error_info: Mapped[str | None] = mapped_column(String(2048), nullable=True)


class ViewAccessFailure(Base):
    """閲覧URLの失敗試行記録（総当り検知用）。"""

    __tablename__ = "view_access_failures"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_fragment: Mapped[str] = mapped_column(String(8))
    client_ip: Mapped[str] = mapped_column(String(64))
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class DocumentTypeConfig(Base):
    """文書種別のテナント別設定。

    fieldsはJSONB配列（順序保持）:
    [{"key": str, "label": str, "type": "string"|"number"|"date", "visible": bool}]
    visibleは省略可（省略時true）
    patternsはJSONB配列（順序保持）: [{"key": str, "label": str, "regex": str}]
    設定の読み取りは (tenant_id, type_code) の1行取得のみでJSONB内部検索はしない。
    """

    __tablename__ = "document_type_configs"
    __table_args__ = (
        UniqueConstraint("tenant_id", "type_code", name="uq_document_type_configs"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(255))
    type_code: Mapped[str] = mapped_column(String(50))
    display_name: Mapped[str] = mapped_column(String(100))
    shareable: Mapped[bool] = mapped_column(Boolean)
    fields: Mapped[list[dict[str, Any]]] = mapped_column(JSONB)
    patterns: Mapped[list[dict[str, Any]]] = mapped_column(JSONB, server_default="[]")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
