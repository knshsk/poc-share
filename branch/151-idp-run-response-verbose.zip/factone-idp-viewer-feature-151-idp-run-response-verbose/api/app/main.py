from fastapi import FastAPI
from sqlalchemy.orm import Session, sessionmaker

from app.core.auth import CurrentUser, JwksKeySource, KeySource
from app.core.config import Settings
from app.core.db import create_db_engine, create_session_factory
from app.core.problem import (
    install_problem_schema,
    problem_responses,
    register_problem_handlers,
)
from app.core.static_serving import mount_spa
from app.routers.document_type_configs import router as document_type_configs_router
from app.routers.documents import router as documents_router
from app.routers.idp_runs import router as idp_runs_router
from app.routers.view_urls import FailureRateLimiter
from app.routers.view_urls import router as view_urls_router
from app.services.blob import BlobStorage, create_blob_storage
from app.services.di import DocumentAnalyzer, create_document_analyzer
from app.services.pdf_render import PdfiumRenderer, PdfRenderer


def create_app(
    settings: Settings | None = None,
    key_source: KeySource | None = None,
    session_factory: sessionmaker[Session] | None = None,
    blob_storage: BlobStorage | None = None,
    pdf_renderer: PdfRenderer | None = None,
    document_analyzer: DocumentAnalyzer | None = None,
) -> FastAPI:
    settings = settings or Settings()
    key_source = key_source or JwksKeySource(settings.oidc_jwks_url)
    session_factory = session_factory or create_session_factory(
        create_db_engine(settings.database_url)
    )
    blob_storage = blob_storage or create_blob_storage(
        settings.blob_backend,
        settings.blob_local_dir,
        settings.blob_account_url,
        settings.blob_container,
    )

    app = FastAPI(title=settings.app_name)
    register_problem_handlers(app)
    install_problem_schema(app)
    app.state.settings = settings
    app.state.key_source = key_source
    app.state.session_factory = session_factory
    app.state.blob_storage = blob_storage
    app.state.pdf_renderer = pdf_renderer or PdfiumRenderer()
    app.state.document_analyzer = document_analyzer or create_document_analyzer(
        settings.di_endpoint, settings.di_api_key, settings.di_timeout_seconds
    )
    app.state.view_rate_limiter = FailureRateLimiter(
        settings.view_url_max_failures, settings.view_url_failure_window_seconds
    )

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/api/v1/me", responses=problem_responses(401, 403))
    def me(user: CurrentUser) -> dict[str, str]:
        return {"sub": user.sub, "username": user.username}

    app.include_router(documents_router)
    app.include_router(idp_runs_router)
    app.include_router(view_urls_router)
    app.include_router(document_type_configs_router)
    # 全APIルート登録後にSPA配信（catch-all）を登録する（API優先の担保）
    mount_spa(app, settings.static_dir)

    return app
