"""JWT検証（Keycloak発行のアクセストークン）。

検証と tenant_id クレームの抽出を担い、認可（ロール・文書アクセス）は未確定事項の解消後に拡張する。
鍵取得は境界アダプタ（KeySource）として分離し、テストでは静的鍵に差し替える。
"""

import re
from dataclasses import dataclass
from typing import Annotated, Any, Protocol

import jwt
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.config import Settings
from app.core.problem import ProblemException

ALLOWED_ALGORITHMS = ["RS256"]
# realm のユーザープロファイル属性 tenant_id と同じパターン（keycloak/realm/factone.json）
TENANT_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")


class KeySource(Protocol):
    """トークン署名検証鍵の取得境界。"""

    def get_verification_key(self, token: str) -> Any: ...


class JwksKeySource:
    """KeycloakのJWKSエンドポイントから検証鍵を取得する（キャッシュはPyJWKClientが担う）。"""

    def __init__(self, jwks_url: str) -> None:
        self._client = jwt.PyJWKClient(jwks_url)

    def get_verification_key(self, token: str) -> Any:
        return self._client.get_signing_key_from_jwt(token).key


class StaticKeySource:
    """固定の公開鍵を返す（テスト・検証用）。"""

    def __init__(self, key: Any) -> None:
        self._key = key

    def get_verification_key(self, token: str) -> Any:
        return self._key


@dataclass(frozen=True)
class AuthenticatedUser:
    sub: str
    username: str
    tenant_id: str


_bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    request: Request,
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(_bearer_scheme)
    ],
) -> AuthenticatedUser:
    if credentials is None:
        raise ProblemException(
            401,
            "unauthenticated",
            "Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    settings: Settings = request.app.state.settings
    key_source: KeySource = request.app.state.key_source
    token = credentials.credentials

    try:
        key = key_source.get_verification_key(token)
        claims = jwt.decode(
            token,
            key=key,
            algorithms=ALLOWED_ALGORITHMS,
            issuer=settings.oidc_issuer,
            audience=settings.oidc_audience,
            options={"require": ["exp", "iss", "aud", "sub"]},
        )
    except jwt.PyJWTError as exc:
        raise ProblemException(
            401,
            "invalid-token",
            "Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    # テナントはトークンの tenant_id クレームで解決する（単一 realm + クレーム方式。ADR-0020）。
    # 署名・iss・aud は正当なのでトークン自体の拒否（401）ではなく 403 にする
    tenant_id = claims.get("tenant_id")
    if not isinstance(tenant_id, str) or not TENANT_ID_PATTERN.fullmatch(tenant_id):
        raise ProblemException(
            403, "tenant-unresolved", "Tenant could not be resolved from token"
        )

    return AuthenticatedUser(
        sub=claims["sub"],
        username=claims.get("preferred_username", ""),
        tenant_id=tenant_id,
    )


CurrentUser = Annotated[AuthenticatedUser, Depends(get_current_user)]
