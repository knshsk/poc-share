# Keycloak構成管理

Keycloakのrealm定義をconfig-as-codeで管理するディレクトリ。

## 運用ルール

realm設計は「単一 realm `factone` + アクセストークンの `tenant_id` クレーム」で確定した（[ADR-0020](../docs/adr/0020-single-realm-tenant-claim.md)、[docs/architecture/auth.md](../docs/architecture/auth.md)）。テナントの作成・無効化は `scripts/tenant.sh`（[docs/develop-guide/tenant.md](../docs/develop-guide/tenant.md)）で行う。

- **realm定義JSON（`realm/` 配下）を構成管理の正とする。** Keycloak管理コンソールでの手動変更はJSONに反映されず realm 再作成時に失われるため、変更はJSONを編集して再投入する。
- 投入方法: 起動時の `--import-realm` で `realm/` 配下のJSONが自動投入される（ローカルは `compose.yaml` でマウント、Azureは `Containerfile` でイメージへ焼き込み。いずれも同一定義）。
- 既存realmがある場合、`--import-realm` は既定でスキップされる。定義変更を反映するには realm を削除して再起動するか、ローカルではデータボリュームを初期化する（手順は `docs/develop-guide/local-stack.md`）。

## シークレット非含有ルール

- **realm JSONにシークレット（クライアントシークレット・パスワード等）を含めない。**
- **Keycloakのrealmインポートは環境変数置換を行わない**（プレースホルダ文字列がそのまま値になる）。パスワード・クライアントシークレット等の実行時設定が必要な項目は、起動後に `kcadm` を使うスクリプトで設定する（`scripts/local-stack/apply-keycloak-secrets.sh`）。
- 現在のrealm定義:
  - realm本体（ユーザープロファイルに属性 `tenant_id` を宣言。編集は管理者のみ）
  - publicクライアント `factone-viewer`（SPA用。PKCE S256必須・audienceマッパー・ユーザー属性 `tenant_id` をクレーム `tenant_id` に載せるマッパー）
  - confidentialクライアント `factone-integration`（テナント `default` の外部システム連携用M2M。client credentials grant・audienceマッパー・hardcoded claim `tenant_id=default`。シークレットはインポート対象外）
  - テストユーザー `testuser`（属性 `tenant_id=default`。パスワードはインポート対象外）
  - テナント追加時のクライアント `factone-integration-<tenant_id>` とユーザーは realm 定義に含めず `scripts/tenant.sh` で作る（シークレット非含有ルールのため）
  - ロールは未確定事項の解消後に拡充する。
