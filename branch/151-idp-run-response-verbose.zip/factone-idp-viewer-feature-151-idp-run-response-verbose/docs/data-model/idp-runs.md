# IDP実行ログ（idp_runs）

Document Intelligenceによる項目抽出の実行履歴と、Viewerからの人手修正結果。追記型（再実行・修正で過去結果を上書きしない）。

API 応答（`IdpRunResponse`）は本テーブルの列をそのまま返さず、`fields[key] = {value, normalized_value, confidence}` に組み直す。`field_labels` / `field_regions` / セルの `polygon` / `corrections` はクエリ `verbose=true` のときだけ `fields[key].label` / `fields[key].region` / `tables[].cells[].polygon` / `corrections` として返す（[ADR-0022](../adr/0022-idp-run-response-single-schema-verbose.md)）。応答の正は [api/openapi.json](../api/openapi.json)。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 実行ID（サーバ採番） |
| document_pk | uuid | NOT NULL・FK(documents.id) | 対象文書（内部ID）。API 応答の `document_id` は documents 経由で返す |
| run_type | varchar(20) | NOT NULL・CHECK | `initial`（初回）/ `rerun`（再実行）/ `corrected`（人手修正）。初回/再実行は同一文書IDの既存実行有無からサーバ側で自動判定（失敗実行・修正行も既存実行に数える） |
| status | varchar(20) | NOT NULL・CHECK | `succeeded` / `failed` |
| executed_at | timestamptz | NOT NULL | 実行日時（サーバで記録） |
| raw_fields | jsonb | NULL可 | 項目別の生値（DIが返した文字列そのまま）。失敗時はNULL |
| normalized_fields | jsonb | NULL可 | 項目別の正規化値（下記「正規化規則」）。正規化不能な値はnull |
| confidence | jsonb | NULL可 | 項目別確信度（0〜1）。返却・記録のみで閾値判定には使用しない |
| field_labels | jsonb | NULL可 | 項目別の表示ラベル（実行時点の文書種別設定 `fields[].label` のスナップショット）。失敗時はNULL |
| tables | jsonb | NULL可 | DIが認識したテーブル領域（明細仮）の配列。成功時はテーブル未検出でも空配列、失敗時はNULL |
| pattern_matches | jsonb | NULL可 | 文書種別設定の `patterns` をDI全文テキストに適用した結果（下記）。成功時はパターン未設定でも空オブジェクト、失敗時はNULL |
| field_regions | jsonb | NULL可 | 項目別の読取領域（下記）。成功時はキーを全項目分持ち、領域なし・値なしの項目はnull。失敗時はNULL |
| di_api_version | varchar(20) | NULL可 | DI応答の `analyzeResult.apiVersion`（例 `2024-11-30`）。失敗時はNULL |
| di_model_id | varchar(100) | NULL可 | DI応答の `analyzeResult.modelId`（現在 `prebuilt-layout`）。失敗時はNULL |
| raw_response_ref | varchar(1024) | NULL可 | 生応答のBlobパス `{tenant_id}/{document_id}/idp-runs/{run_id}.json`。失敗時はNULL |
| base_run_id | uuid | NULL可・FK(idp_runs)・CHECK | 修正元の実行結果。`corrected` 行のみ非NULL（`ck_idp_runs_corrected_base`） |
| corrected_by | varchar(255) | NULL可・CHECK | 修正者（JWTの `preferred_username`。無い場合は `sub`）。`corrected` 行のみ非NULL（`ck_idp_runs_corrected_by`） |
| corrections | jsonb | NULL可 | 根の機械実行に対する人手差分の累積（下記）。`corrected` 行のみ非NULL |
| error_info | varchar(2048) | NULL可 | 失敗時のエラー情報 |

- 生値・正規化値・確信度を分離保持する（生OCR結果と正規化値の分離方針に基づく）
- JSONのキーは文書種別ごとのクエリセット（`api/app/services/idp_extraction.py`）と一致する。未抽出項目もキーを残し、値はnull

### 正規化規則

型は文書種別設定 `fields[].type`。`string` は生値のまま。`number` / `date` は NFKC 正規化（全角→半角）の上で次を適用し、当てはまらなければ null（`api/app/services/idp_extraction.py` の `_normalize`。Viewer の `viewer/src/utils/normalize.ts` も同規則）。

- `number`: `¥` `円` `,` `、` 空白を除いて整数化（例 `￥74,800` → `74800`、`７４，８００` → `74800`）。小数は null
- `date`: 西暦 `YYYY[-/.年]M[-/.月]D[日]`（ゼロ埋め任意）または和暦 `(令和|平成|昭和|R|H|S)N[-/.年]M[-/.月]D[日]`（`元` 可・空白許容）を `YYYY-MM-DD` にする（例 `令和 8年 9月 4日` → `2026-09-04`）。暦上存在しない日付は null

### tables（テーブル領域）の構造

- 各要素は `row_count` / `column_count` / `cells` を持つ。複数テーブル認識時は全件保持する
- `cells` の各要素は `row_index` / `column_index` / `row_span` / `column_span`（結合セルの行数・列数。2026-09-17 の #151 以降に保存された行のみ持ち、無い行は API が 1 で補完する）/ `content` / `kind`（`columnHeader` 等、無い場合null）/ `page_number` / `polygon`（座標配列。無い場合null。API 応答では `verbose=true` のときのみ）
- DIの認識結果を意味付けせず素通しする。どのテーブルが明細領域か、どの列・行がSAP入力項目の何に相当するかの判断はSaaS側の責務外（利用側で解釈する）

### pattern_matches（正規表現マッチ結果）の構造

キーは設定の `patterns[].key`。値は実行時点の `label` / `regex` と、全文テキストへの一致値の配列。

```json
{
  "TCode": {"label": "登録番号", "regex": "T\\d{13}", "values": ["T1234567890123"]},
  "QuotationNo": {"label": "見積番号", "regex": "Q-\\d{6}", "values": []}
}
```

- `values` は出現順で、重複を除去しない（同一文字列が複数箇所にあればその回数分並ぶ）。0件でもキーを残す
- 長さ 0 の一致（`\d*` 等が空文字に一致した場合）は `values` に含めない。空文字は情報を持たず、文字位置ごとに 1 件生成されて結果が肥大するため
- 実行時点の `label` / `regex` を同梱するため、設定変更後も当時の条件を再現できる
- 一致値の妥当性検証は外部システムの責務（PoC）

### field_regions（項目別読取領域）の構造

キーは Query Fields のキー。値は DI 応答 `documents[0].fields[key].boundingRegions[0]` の `pageNumber` / `polygon`（インチ単位。SVG の viewBox と同一座標系）。

```json
{
  "TotalAmount": {"page_number": 1, "polygon": [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1]},
  "QuotationId": null
}
```

- Viewer のキャンバス⇄右ペイン相互ハイライトのデータ源。API 応答では `verbose=true` のとき `fields[key].region` として返す。領域が無い項目・未抽出の項目は null

### 生応答の保存（Blob）

- DI の最終ポーリング GET の応答本文（`status` / `createdDateTime` / `lastUpdatedDateTime` / `analyzeResult` を含むラッパ込み JSON）を bytes のまま Blob `{tenant_id}/{document_id}/idp-runs/{run_id}.json` に保存する。再シリアライズしない（ADR-0019）
- 用途: `tables` / `fields` 以外の情報（words / lines / paragraphs 等）を使う将来機能への互換、カスタムモデル学習データ（DI Studio の `.ocr.json` と同形）
- 保存順序は DI 成功 → Blob 保存 → 実行ログ INSERT。Blob 保存失敗は 500 で実行ログを残さない
- Blob のコンテンツタイプは設定しない。取得 API が `application/json` で返す

### corrected 行（人手修正）の値

人手修正は `base_run_id` の実行結果に差分を当てた新しい行として追記する（ADR-0018）。`corrected` 行を base にした再修正（連鎖）を許す。排他制御は行わず、同一 base への並行修正は両方追記され `latest` は新しい方を返す（PoC 制限）。

| 列 | 値 |
| --- | --- |
| status | `succeeded` 固定 |
| executed_at | 確定日時（サーバ時刻） |
| error_info | NULL |
| raw_fields | base の値に `corrections.fields` を上書きしたもの |
| normalized_fields | 変更キーのみ再正規化。型は**現在の**文書種別設定 `fields[].type` を参照する（実行ログは型を保持していないため）。設定に無いキーは `string` として扱う。正規化できない入力も受理し null にする。未変更キーは base の値を維持 |
| confidence | 変更キーは null（人手値に機械確信度は付けない）。未変更キーは base の値を維持 |
| field_labels / pattern_matches / field_regions | base からコピー。修正したキーの `field_regions` も base の領域を維持する（DI が読んだ場所へ遷移できるようにする） |
| tables | base の構造（`row_count` / `column_count` / セルの `kind` / `row_span` / `column_span` / `page_number` / `polygon`）を維持し、`corrections.table_cells` の `content` だけ差し替え |
| di_api_version / di_model_id / raw_response_ref | base からコピー（修正行からも元の DI 応答へ辿れる。学習用に「修正済み値 + 元 OCR」の対を取得できる） |

### corrections（累積差分）の構造

修正 API のリクエストボディと同じ形。base が機械実行ならボディそのまま、base が `corrected` 行なら base の `corrections` に今回のボディを重ねた累積差分（同一キー・同一セル座標は今回の値で上書き、セルは base の並びを維持して新規座標を末尾に追加）。連鎖修正のどの世代を見ても「根の機械実行から人が変えたキー / セル」の全体が分かる。1 世代分の差分が必要な場合は base 行の値と比較して復元する。

```json
{
  "fields": {"TotalAmount": "1,250,000", "DeliveryDate": null},
  "table_cells": [
    {"table_index": 0, "row_index": 2, "column_index": 3, "content": "10"}
  ]
}
```

- `fields`: キー → 文字列 または null（「値なし」に訂正）。省略時 `{}`
- `table_cells`: `table_index` / `row_index` / `column_index`（0 始まり整数）と `content`（文字列。空文字可）。省略時 `[]`
- 文字列は各 2000 文字上限。両方空・同一セル座標の重複は 422 `validation-error`
- 値が base と同一かどうかは検査しない（クライアントが差分のみ送る前提）
- 省略したキーは既定値（`fields` は `{}`、`table_cells` は `[]`）を補って保存する（保存形状を一定にするため）

## 抽出方式

- prebuilt-layout+Query Fields（学習・ラベリングなしで項目指定抽出と項目別確信度を取得）
- クエリセットは文書種別ごとに固定。確定抽出項目が未確定のため、検証用サンプルPDFの様式に合わせた仮置き
  - 注文書（案件型・ルート型）: 得意先コード・品目コード・数量・納期・単価
  - 見積: 文書番号・得意先コード・発行日・合計金額
- WBS原価データは様式確定まで対象外
- 同期応答（非同期化の要否は処理時間・サイズ上限の確定後に再検討）。タイムアウトは設定値 `FACTONE_DI_TIMEOUT_SECONDS`（既定120秒）。超過時はDI失敗（`DiError`）として扱う
- 正規表現パターンマッチ: 文書種別設定の `patterns` を DI 応答の全文テキスト（`content`）に `re.finditer` で適用し、全一致を `pattern_matches` に保存する。Query Fields で取得しづらい項目（見積番号・Tコード等）の補完用

## API

- `POST /api/v1/documents/{document_id}/idp-runs`（JWT必須）— 登録済文書に対して抽出を実行し、結果を履歴に追記して返す。DI失敗時は502を返し、失敗実行もerror_info付きで記録する
- `GET /api/v1/documents/{document_id}/idp-runs`（JWT必須）— 実行履歴一覧（実行日時昇順）。サマリ項目（`run_id` / `document_id` / `run_type` / `status` / `executed_at` / `base_run_id` / `corrected_by` / `di_api_version` / `di_model_id` / `error_info`）のみを返し、項目値・テーブル・領域・パターン一致は含めない
- `GET /api/v1/documents/{document_id}/idp-runs/latest`（JWT必須）— 最新の成功実行を詳細で返す（`executed_at` 降順・同時刻は `id` 降順の先頭）。任意クエリ `run_type=initial|rerun|corrected` で区分を絞る。該当なしは404 `idp-run-not-found`
- `GET /api/v1/documents/{document_id}/idp-runs/{run_id}`（JWT必須）— 実行結果の詳細（項目値・確信度・ラベル・領域・テーブル・パターン一致）。他文書の run_id・不在は404 `idp-run-not-found`
- `GET /api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response`（JWT必須）— 生応答を `application/json` で無変換返却。他文書の run_id・不在は404 `idp-run-not-found`、失敗実行は404 `raw-response-not-found`
- `POST /api/v1/documents/{document_id}/idp-runs/{run_id}/corrections`（JWT必須）— `run_id` を base に人手修正を `corrected` 行として追記し、201 で詳細を返す。base が失敗実行は409 `idp-run-not-correctable`、base に無いキー・セル座標は422 `unknown-correction-target`、他文書の run_id・不在は404 `idp-run-not-found`
