# 閲覧 URL と公開閲覧

## 役割

共有可の文書種別の文書に、認証なしで閲覧できる URL を発行する。閲覧者の行動（閲覧・ページ閲覧・ダウンロード）を追記型のイベントとして記録し、テナント利用者と外部連携システムへ提供する。URL には文書 ID や業務キーを含めず、推測できないこと（256 bit 乱数）と総当りを抑えること（一律 404・失敗記録・レート制限）を担保する。

## 構成

```mermaid
flowchart LR
    panel["Viewer: ViewUrlPanel"]
    pub["閲覧者ブラウザ: PublicView"]
    integ["外部連携システム"]
    api["API: routers/view_urls.py"]
    tokens[("view_tokens")]
    events[("view_events")]
    failures[("view_access_failures")]
    blob[("Blob: PDF 原本")]
    limiter["FailureRateLimiter（インメモリ）"]

    panel -- "発行 / 一覧 / 失効（Bearer）" --> api
    pub -- "/view/{token}/*（無認証）" --> api
    integ -- "イベント差分取得（Bearer）" --> api
    api --> tokens
    api --> events
    api --> failures
    api --> blob
    api --> limiter
```

- 認証ありの管理 API と無認証の公開 API を同じルーターに置く。公開 API 3 本はすべて `_resolve_token`（検証と PDF 読込）を通る。強制する仕組みはなく規約
- 一括失効は Viewer から呼ばない（外部連携システム向け。見積改訂時の旧版 URL 差し替え用）
- 閲覧者が `/view/{token}` を開くと API の catch-all（ビルド成果物があるときだけ登録。ローカルは Vite dev サーバ）が Viewer SPA を返し、`App.vue` がパスを見て `PublicView` を表示する。SPA は認証を経ずに公開 API だけを呼ぶ

## 主要処理の流れ

### トークンのライフサイクル

```mermaid
flowchart LR
    issue["発行"] --> valid["有効"]
    valid -- "revoke / revoke-all" --> revoked["失効"]
    valid -- "expires_at 経過" --> expired["期限切れ"]
```

- 発行（`POST /api/v1/documents/{document_id}/view-urls`）: 文書が無ければ 404。文書種別設定の `shareable` を確認し、設定なし・不可なら 403（`view-url-not-allowed`。[ADR-0002](../adr/0002-document-type-shareability.md)）。`secrets.token_urlsafe(32)`（256 bit）で生成し、DB には SHA-256 だけを保存する。期限はリクエストの `expires_at`（妥当性は検証しない）、無ければ発行時刻 + 既定 90 日。応答 `{id, view_path: /view/{token}, expires_at}` で平文を一度だけ返す
- 一覧（`GET .../view-urls`）: `id` / `issued_at` / `expires_at` / `revoked`。並び順は未指定
- 検証: ハッシュ一致 AND 未失効 AND `expires_at` が現在時刻より後。どれか欠けても一律 404（`not-found`）で存在を推測させない
- 失効: `POST /api/v1/view-urls/{view_url_id}/revoke`（1 件。`revoked` を立てるだけで即時。応答 `{status: revoked}`）と `POST .../view-urls/revoke-all`（文書の未失効トークンをすべて失効。応答 `{status, revoked_count}`。対象 0 件でも 200 で冪等）。1 件失効は管理 ID（発行応答の `id`。トークンとは無関係な UUID）で指定する。所属文書のテナントが JWT のテナントと一致しなければ 404
- 1 文書に複数トークンを発行できる。発行レコードの並びがそのまま、その文書に対して発行した閲覧 URL の履歴（見積改訂ごとの旧版・新版）になる

### 公開閲覧と閲覧イベント

```mermaid
sequenceDiagram
    participant V as 閲覧者ブラウザ（PublicView）
    participant A as API
    participant P as PostgreSQL
    participant B as Blob

    V->>A: GET /view/{token}/pages
    A->>A: IP が制限中なら 429
    A->>P: ハッシュで view_tokens を検索、未失効・期限内か
    alt 無効
        A->>P: view_access_failures に先頭 8 文字と IP を記録（DB）、FailureRateLimiter の失敗回数を加算（インメモリ）
        A-->>V: 404
    end
    A->>B: PDF を読む（公開 API 3 本すべてで行う）
    A->>A: ページ寸法を計算
    A->>P: view を記録
    A-->>V: ページ寸法一覧
    loop 表示領域に入ったページ
        V->>A: GET /view/{token}/pages/{page}/image
        A->>A: 同じ検証 → PNG を生成
        A->>P: page_view（page 付き）を記録
        A-->>V: PNG（Cache-Control: no-store）
    end
    V->>A: GET /view/{token}/pdf
    A->>P: download を記録
    A-->>V: PDF（元ファイル名で Content-Disposition）
```

- `view` と `page_view` はページ寸法計算・PNG 生成の成功後に記録する（PDF 処理に失敗して 500 になった要求は記録しない）。`download` は Blob 読込後、応答生成の直前に記録する
- `view_events` は文書 ID・発生日時（マイクロ秒精度）・種別で一意。`page` は一意キーに含まれないため、同一時刻の別ページの `page_view` は片方が捨てられる。衝突時は記録を捨てて配信は成功させる
- `page_view` は SPA の遅延読込（`IntersectionObserver` で表示領域に入ったページだけ画像を取得。非対応環境では全ページを即時取得）が契機で、`Cache-Control: no-store` でブラウザキャッシュによる取りこぼしを防ぐ（[ADR-0015](../adr/0015-page-view-event.md)）
- テナント利用者が Viewer 上で見る認証ありのページ画像・PDF は記録しない（[ADR-0012](../adr/0012-no-internal-view-event-history.md)）
- イベントには `client_ip`（`request.client.host`。`X-Forwarded-For` は見ないため、プロキシ配下ではプロキシの IP になりうる）・`user_agent`・`page` を保存する。`view_token_id` は内部管理値で API には出さない
- `PublicView` は取得失敗を 404 / 429 / 500 の区別なく「この閲覧URLは無効です」と表示する。`ViewUrlPanel` の有効 / 期限切れ表示はクライアント時刻で判定する

### イベントの提供

- 文書別: `GET /api/v1/documents/{document_id}/events`。`occurred_at` 昇順（同時刻の並びは未規定）
- 横断差分: `GET /api/v1/view-events?since=<日時>`。JWT のテナントの全文書を対象に `occurred_at >= since`（境界を含む）を `occurred_at, id` 昇順で返す。`since` 省略時は全件。件数上限・ページングはない。境界の重複は連携側の冪等キー（文書 ID + 発生日時）で除く前提で、取りこぼしゼロを優先する（[ADR-0013](../adr/0013-view-event-delta-feed.md)）

### 防御

- 一律 404: トークン不一致・失効・期限切れ・文書不在を区別しない
- 失敗試行の記録: `view_access_failures` にトークン先頭 8 文字と IP を保存する（総当り検知用。全体は保存しない）
- レート制限: IP ごとに直近 `FACTONE_VIEW_URL_FAILURE_WINDOW_SECONDS`（60）秒の失敗が `FACTONE_VIEW_URL_MAX_FAILURES`（10）回に達すると、その IP からの公開 API を 429（`too-many-requests`）にする（スライディング窓）。成功要求は数えず、有効トークンの要求は制限しない。インメモリ（`FailureRateLimiter`）のためプロセス再起動で消え、単一レプリカ前提。スケールアウト時は外部化が必要
- 429 の要求はイベントも失敗記録も残さず、窓も延長しない（最後の失敗から 60 秒で解除）

## 外部依存・設定

- `FACTONE_VIEW_URL_DEFAULT_TTL_DAYS`（90）、`FACTONE_VIEW_URL_MAX_FAILURES`（10）、`FACTONE_VIEW_URL_FAILURE_WINDOW_SECONDS`（60）
- 文書種別設定の `shareable`（[data-model/document-type-configs.md](../data-model/document-type-configs.md)）
- Blob（PDF 原本）、pypdfium2（ページ画像）

## 詳細仕様への導線

- [data-model/view-tokens.md](../data-model/view-tokens.md)（`view_tokens` / `view_access_failures`）、[data-model/view-events.md](../data-model/view-events.md)
- [viewer/display.md](../viewer/display.md)（ページ画像の遅延読込・座標系）、[viewer.md](viewer.md)（`PublicView` / `ViewUrlPanel`）
- [api/README.md](../api/README.md)（`/view/**` はパスにバージョンを含めない）
- [ADR-0002](../adr/0002-document-type-shareability.md)、[ADR-0011](../adr/0011-view-url-opaque-token.md)、[ADR-0012](../adr/0012-no-internal-view-event-history.md)、[ADR-0013](../adr/0013-view-event-delta-feed.md)、[ADR-0015](../adr/0015-page-view-event.md)
