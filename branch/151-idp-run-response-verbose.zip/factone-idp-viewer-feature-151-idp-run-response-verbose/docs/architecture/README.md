# 全体設計ドキュメント

モジュールを横断する全体像（L1）と、モジュールごとの構成（L2）。

## 文書一覧

- [overview.md](overview.md) — L1。システム文脈・コンポーネント構成・主要ユースケース・データの流れ
- [api.md](api.md) — L2。API のレイヤ構成・リソース・IDP 実行の内部フロー
- [viewer.md](viewer.md) — L2。画面・コンポーネント・状態管理
- [auth.md](auth.md) — L2。認証経路・JWT 検証・Keycloak realm
- [view-url.md](view-url.md) — L2。閲覧 URL のライフサイクル・公開閲覧・イベント

## 記述方針

- L2 文書は「役割 / 構成 / 主要処理の流れ / 外部依存・設定 / 詳細仕様への導線」の 5 節で書く
- 図は Mermaid（構成図は `flowchart`、処理の流れは `sequenceDiagram`）。図と本文で同じ情報を二重に書かない
- テナント固有の外部システム名は書かない。外部は役割名で表す
- Keycloak realm 設計は単一 realm + `tenant_id` クレームで確定済み（[ADR-0020](../adr/0020-single-realm-tenant-claim.md)）。現行仕様は [auth.md](auth.md) に書く
