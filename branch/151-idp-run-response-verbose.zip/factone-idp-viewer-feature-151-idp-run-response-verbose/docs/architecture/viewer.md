# Viewer

## 役割

Vue 3 + Vuetify + Pinia の SPA。テナント利用者向けに文書の表示・登録・IDP 実行・読取結果の確認と修正・閲覧 URL の管理を行う認証ありの画面と、閲覧者向けに文書を表示・ダウンロードする無認証の画面の 2 つを持つ。ビルド成果物は API コンテナに同梱され、API が配信する。

## 構成

```mermaid
flowchart TB
    app["App.vue（パスで分岐）"]
    app -- "/view/{token}" --> pub["PublicView（AppHeader はロゴのみ）"]
    app -- "/callback（onMounted で処理）" --> cb["OIDC コールバック処理"]
    app -- "その他（認証済）" --> docv["DocumentView"]
    app -- "その他（未認証）" --> login["ログイン画面"]
    cb --> login

    subgraph docview["DocumentView"]
        header["AppHeader（表示中の文書 ID・切替入力・ユーザーメニュー）"]
        start["開始ダイアログ（文書未指定時: 閲覧 / 新規登録）"]
        canvas["DocumentCanvas（ナビ・ズーム・原本 DL）"]
        pagesvg["PageSvg × ページ（画像 + 読取矩形）"]
        work["WorkPanel（右ペイン）"]
        editor["ResultEditor（読取結果タブ）"]
        history["実行履歴タブ"]
        urls["ViewUrlPanel（閲覧 URL タブ）"]
        reg["DocumentRegisterForm"]
        start --> reg
        canvas --> pagesvg
        work --> editor
        work --> history
        work --> urls
    end
    pub --> canvas2["DocumentCanvas（ナビ・ズーム・ダウンロード。矩形なし）"]
    canvas2 --> pagesvg2["PageSvg × ページ"]

    subgraph stores["Pinia ストア"]
        auth["auth"]
        document["document"]
        draft["draft"]
        highlight["highlight"]
    end
    client["api/client.ts（openapi-fetch、Bearer 付与）"]
    docview --> stores
    docview --> client
    pub --> client
```

- ルーティングライブラリは使わない。`App.vue` が `window.location.pathname` を見て `PublicView`（`/view/{token}`。`AppHeader` は未認証のためロゴだけを出す）と `DocumentView`（認証済）/ ログイン画面（未認証）を切り替える。`/callback` は画面ではなく、ログイン画面を出したまま `onMounted` でトークンを受け取って認証済へ遷移する。`DocumentView` は `?document_id=` があれば起動時にその文書を開く
- `utils/`: `runs.ts`（実行結果の型付け、読取矩形 `overlayRectsByPage`、ハイライト ID）、`zoom.ts`（フィット倍率）、`normalize.ts`（正規化ヒント）、`download.ts`（`Content-Disposition` からのファイル名）、`format.ts`、`motion.ts`（reduced-motion 対応）
- ストアの責務
  - `auth`: `oidc-client-ts` のラッパ。アクセストークン（メモリ保持）・ユーザー名・認証済フラグ。ログイン / コールバック / ログアウト（[auth.md](auth.md)）
  - `document`: 表示中の文書コンテキスト。入力中の文書 ID と確定済み文書 ID、文書種別、種別設定由来の表示名・`shareable`・`fieldDefs`（key / label / type / visible）。データ取得は `DocumentView` の責務
  - `draft`: 未確定の修正。元値との差分だけを `fields` / `cells` に持ち、件数・dirty を算出し、確定時に corrections API のボディへ変換する。未保存のまま履歴選択・IDP 実行・文書切替が要求されたときの保留状態（`guard` / `proceed` / `cancel`。ダイアログの表示は `WorkPanel`）
  - `highlight`: キャンバスの読取矩形と右ペインの入力欄の相互選択状態。`selectFromPane` / `selectFromCanvas` が連番付き要求を発行し、相手側が watch で反応する。履歴選択・IDP 実行で `clear`
- API 型は OpenAPI から生成した `api/schema.d.ts` が単一情報源。`npm run generate:api` で再生成し、ドリフトは pre-commit で検出する。`api/client.ts` が同一オリジン前提で Bearer を付ける
- ビルド成果物は `api/Containerfile` のマルチステージで API イメージの `static/` に同梱する。OIDC の authority とクライアント ID はビルド時に焼き込む。ローカルは Vite dev サーバ + プロキシ（`/api` と `/view/{token}/pages|pdf` を 8000 番へ）

## 主要処理の流れ

### 文書表示

1. 文書 ID の入力口は 2 つ。文書未指定時は開始ダイアログ（閲覧 / 新規登録）、表示中は `AppHeader` の切替入力（未保存の変更があれば `draft.guard` で確認）。いずれも `document.documentId` を更新する
2. `DocumentView` が watch で検知し、`GET /api/v1/documents/{id}`、`GET .../pages`、`GET /api/v1/config/document-types` を並行取得する。文書種別設定から表示名・`shareable`・`fieldDefs` をストアへ反映し、`loadedDocumentId` を確定する。設定が取れないときは種別コードを表示名にし、`shareable=false`・全項目表示に倒す
3. `DocumentCanvas` がページ寸法（インチ）から `PageSvg` を並べ、各ページは表示領域に入ったときだけ `GET .../pages/{page}/image` を取得する。読取矩形は選択中の成功実行の `fields[key].region` / `tables[].cells[].polygon`（`verbose=true` で取得）から外接矩形を描く（`utils/runs.ts`。キー項目は `visible=false` と値なしを除く。テーブルセルは全件）。原本 DL は `GET .../pdf`。座標系とズームは [viewer/display.md](../viewer/display.md)
4. `loadedDocumentId` 確定後に `WorkPanel` が現れ、`GET .../idp-runs` でサマリ一覧（昇順）を取って反転し降順で表示する。先頭（= API 応答の末尾、最新。失敗実行も含む）を `GET .../idp-runs/{run_id}` で取得して読取結果タブに表示する（`verbose=true`）
5. 新規登録は `DocumentRegisterForm` が `POST /api/v1/documents` を multipart で呼び、登録後はその文書を開く

### IDP 実行と修正の確定

1. [IDP 実行] → `draft.guard` → `POST .../idp-runs`（`verbose=true`）。応答をそのまま選択状態にし、履歴の先頭へ追加する（再取得しない）。応答受信時に `pendingRunId` を更新し、遅れて届いた古い詳細取得で表示を上書きしない
2. `ResultEditor` の入力欄を編集すると `draft.setField` / `setCell` が元値との差分を記録する。number / date 型はクライアント側で正規化を試し、ヒントを表示する（サーバと同規則の `utils/normalize.ts`）
3. [確定]（読取結果タブ・成功実行選択中・変更 1 件以上のときだけ表示）→ `POST .../idp-runs/{run_id}/corrections`（`verbose=true`）に `draft.toCorrections()` を送る。応答の `corrected` 行を選択状態にして履歴の先頭へ追加し、下書きをリセットする。[破棄] は下書きのリセットのみ
4. 未保存の変更があるまま履歴選択・IDP 実行・ヘッダからの文書切替をすると確認ダイアログを出す（タブ切替は対象外）。ブラウザ離脱は `WorkPanel` 表示中に限り `beforeunload` の標準警告

読取結果タブはキー項目（Query Fields）・キー項目候補（正規表現の一致値）・グリッド（テーブル領域）の 3 区分で表示する。詳細（各区分の表示・修正済みマーク・アクセシビリティ）は [viewer/result-panel.md](../viewer/result-panel.md)。

### 相互ハイライト

入力欄のフォーカスで `highlight.selectFromPane(id)` → キャンバスが該当矩形を表示範囲へスクロール。矩形のクリック（Enter / Space も）で `highlight.selectFromCanvas(id)` → `WorkPanel` が読取結果タブへ切り替え、`ResultEditor` が該当区分を展開して入力欄へスクロール・フォーカスする。ID は `field:{key}` / `cell:{table}:{row}:{col}`。

### 閲覧 URL の管理（`ViewUrlPanel`）

文書種別が `shareable` のときだけタブを出す。`GET .../view-urls` で一覧（発行日時・期限・状態: 有効 / 期限切れ / 失効。期限判定はクライアント時刻）を表示し、発行（`POST .../view-urls`）の応答 `view_path` に自オリジンを付けて完全 URL を表示・コピーさせる（平文は再表示できない）。発行後は一覧を再取得する。失効は確認ダイアログの後に `POST /api/v1/view-urls/{view_url_id}/revoke`。一括失効は画面から呼ばない。

### 公開閲覧（`PublicView`）

`GET /view/{token}/pages` でページ寸法を取り、`DocumentCanvas` を `token` 指定・全幅（右ペインなし）で表示する。ページナビ・ズーム・フィットは認証済み表示と同じ。`run` を渡さないため読取矩形は出ない。`PageSvg` が表示領域に入ったページの画像を `GET /view/{token}/pages/{page}/image` で取得する（遅延読込は変えない。[ADR-0015](../adr/0015-page-view-event.md)）。ツールバーの [ダウンロード]（`downloadLabel`。認証済み表示は「原本DL」）は `GET /view/{token}/pdf` を blob として受け、`Content-Disposition` のファイル名（無ければ `document.pdf`）で保存する。取得中はページスケルトン。ページ一覧の取得失敗は「この閲覧URLは無効です」、ダウンロード失敗は「ダウンロードできませんでした」を `DocumentView` と同じエラー state（アイコン + メッセージ。再試行なし）で表示し、いずれも本文を消す（[view-url.md](view-url.md)）。

## 外部依存・設定

- ビルド時環境変数: `VITE_OIDC_AUTHORITY`（既定 `http://localhost:8080/realms/factone`）、`VITE_OIDC_CLIENT_ID`（既定 `factone-viewer`）
- API（同一オリジン。ローカルは Vite プロキシ）、Keycloak（OIDC リダイレクト）
- 主要ライブラリ: Vue 3、Vuetify、Pinia、oidc-client-ts、openapi-fetch、Phosphor Icons、Fontsource（IBM Plex）。テストは Vitest + Vue Test Utils

## 詳細仕様への導線

- [viewer/display.md](../viewer/display.md)（ページ画像 + SVG オーバーレイ、座標系、ズーム、遅延読込）、[viewer/result-panel.md](../viewer/result-panel.md)（右ペイン、修正の下書きと確定、相互ハイライト、アクセシビリティ）
- [viewer/README.md（リポジトリ）](../../viewer/README.md)（ディレクトリ構成と配置指針）、[develop-guide/viewer.md](../develop-guide/viewer.md)（起動・テスト・ビルド）
- [requirements/viewer.md](../requirements/viewer.md)（機能要件 VW-xx）
- [ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)、[ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md)、[ADR-0010](../adr/0010-blob-access-full-api-proxy.md)
