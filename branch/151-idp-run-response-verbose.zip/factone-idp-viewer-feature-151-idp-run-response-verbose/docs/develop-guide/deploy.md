# デプロイ手順

デプロイ手順の正は `scripts/` のスクリプト。本ドキュメントは前提条件・使い方・トラブルシュートのみを記載する。

## コアインフラ（DI・Blob・PostgreSQL・Key Vault）

### 前提条件

- Azure CLI（`az`）がインストール済みで、対象サブスクリプションへ `az login` 済みであること
- サブスクリプションに対しリソースグループ作成・デプロイ権限があること

### 使い方

```bash
FACTONE_POSTGRES_ADMIN_PASSWORD='<管理者パスワード>' ./scripts/deploy-infra.sh
```

- 第1引数: リソースグループ名（既定: `factone-poc-rg`）
- 第2引数: リージョン（既定: `japaneast`）

作成されるリソース: Document Intelligence（S0）、Blob Storage（`documents` コンテナ）、PostgreSQL Flexible Server（B1ms）、Key Vault（管理者パスワードを `postgres-admin-password` シークレットとして格納）。

### トラブルシュート

- `FACTONE_POSTGRES_ADMIN_PASSWORD` 未設定エラー → 環境変数を設定して再実行する（PostgreSQLのパスワードポリシーは8文字以上・英大小数字を含む）
- 未ログインエラー → `az login` 後に再実行する
- 名前衝突エラー → リソース名にはリソースグループ由来の一意サフィックスが付くため通常発生しない。別リソースグループ名を指定すると別の一意名で作成される

## アプリ層（Container Apps・ACR）

コアインフラ構築後、以下の順で実行する。

### 1. イメージビルド（ACRクラウドビルド）

```bash
./scripts/build-images.sh
```

- `api/Containerfile`（マルチステージ: viewerビルド→Python実行イメージへ同梱）と `keycloak/Containerfile`（公式イメージ+realm定義焼き込み）をビルド
- 第1引数: リソースグループ名（既定: `factone-poc-rg`）、第2引数: タグ（既定: `latest`）

### 2. アプリデプロイ

```bash
FACTONE_POSTGRES_ADMIN_PASSWORD='<DB管理者パスワード>' FACTONE_KEYCLOAK_ADMIN_PASSWORD='<Keycloak管理者パスワード>' ./scripts/deploy-apps.sh
```

- API（フロント同居配信・ユーザー割当マネージドIDでBlob/DI/Key Vault/ACRへアクセス）とKeycloak（共用PostgreSQL内別DB）のContainer Appsを作成
- 出力にAPI・KeycloakのFQDNが表示される

### デプロイ後の手動設定

#### Keycloakシークレット類の設定

realm定義JSONはシークレットを含めない運用のため、インポート直後は以下が未設定。ローカルの `apply-keycloak-secrets.sh` に相当する操作を、コンテナ内の `kcadm` で実施する（realmを再インポートした場合も再実施が必要）。

realm 定義に `tenant_id` 属性・マッパーが入る前にデプロイした環境では、稼働中の realm にそれらが無く API が 403 `tenant-unresolved` を返す。`--import-realm` は既存 realm をスキップするため、Keycloak 管理コンソールで realm `factone` を削除してから Container App を再起動（再インポート）し、本節のシークレット設定とリダイレクト URI 追加をやり直す。テナント追加で作ったクライアント・ユーザーも消えるので、`scripts/tenant.sh` で再作成する（[tenant.md](tenant.md)）。

- テストユーザー（testuser）のパスワード
- M2M連携クライアント（factone-integration）のクライアントシークレット

1. Keycloakコンテナへ接続する。

```bash
az containerapp exec --name factone-poc-keycloak --resource-group factone-poc-rg --command bash
```

2. コンテナ内で管理者ログインする（パスワードは `deploy-apps.sh` 実行時の `FACTONE_KEYCLOAK_ADMIN_PASSWORD`）。

```bash
/opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 --realm master --user admin --password '<Keycloak管理者パスワード>'
```

3. テストユーザーのパスワードを設定する。

```bash
/opt/keycloak/bin/kcadm.sh set-password -r factone --username testuser --new-password '<テストユーザーのパスワード>'
```

4. M2M連携クライアントのシークレットを設定する。

```bash
CLIENT_ID=$(/opt/keycloak/bin/kcadm.sh get clients -r factone -q clientId=factone-integration --fields id --format csv --noquotes) && /opt/keycloak/bin/kcadm.sh update "clients/$CLIENT_ID" -r factone -s secret='<クライアントシークレット>'
```

5. SPAクライアントのリダイレクトURIへAzureのURLを追加する（realm定義はローカルURLのみのため。`<APIのFQDN>` は `deploy-apps.sh` 出力のapi列）。

```bash
VIEWER_ID=$(/opt/keycloak/bin/kcadm.sh get clients -r factone -q clientId=factone-viewer --fields id --format csv --noquotes) && /opt/keycloak/bin/kcadm.sh update "clients/$VIEWER_ID" -r factone -s 'redirectUris=["http://localhost:5173/*","https://<APIのFQDN>/*"]' -s 'webOrigins=["http://localhost:5173","https://<APIのFQDN>"]' -s 'attributes."post.logout.redirect.uris"=http://localhost:5173/*##https://<APIのFQDN>/*'
```

補足: `az containerapp exec` は対話前提でスクリプト自動化に不向き。デプロイを繰り返す運用に入る場合は、Admin REST APIベースのスクリプト化を検討する。

#### ViewerのOIDC設定（イメージビルド時焼き込み）

Viteの環境変数（`VITE_OIDC_AUTHORITY` 等）はビルド時にバンドルへ焼き込まれる。`build-images.sh` がContainer Apps EnvironmentからKeycloakのFQDNを解決してビルド引数として渡すため、**コアインフラのデプロイ後にイメージをビルド**する（順序を守らないとローカルURL既定値で焼き込まれる）。

#### その他の既知の制約

- realm定義の恒久的なAzure URL対応（手動ステップ5の解消）は、環境URL確定後のrealm JSON更新またはスクリプト化で整理する

### リソース削除

検証後にリソースを削除する場合はリソースグループごと削除する。

```bash
az group delete --name factone-poc-rg
```

**再デプロイ時の注意:** Key Vault と Document Intelligence は削除後もソフトデリート状態で名前が90日間予約される。リソース名はリソースグループ名由来の一意サフィックスを含むため、同名リソースグループへ再デプロイすると名前が衝突する。再デプロイ前にパージする。

```bash
az keyvault purge --name <Key Vault名>
```

```bash
az cognitiveservices account purge --name <DI名> --resource-group <リソースグループ名> --location japaneast
```

（別のリソースグループ名でデプロイし直す場合、サフィックスが変わるためパージ不要）

### 補足

- ネットワーク隔離（VNet+Private Endpoint）はPoCでは行いません（本番化時にモジュール単位で後付け）（ADR-0007）
