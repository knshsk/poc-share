# 品質ゲート

lint・format・型検査は pre-commit に一元化している。コミット時に自動実行されるほか、手動で全体実行もできる。

## 対象ツール

- API（`api/`）: ruff（lint・format）、mypy（型検査・strict）
- Viewer（`viewer/`）: eslint（lint）、prettier（format）
- シェルスクリプト（`*.sh`）: 実行権限チェック（`scripts/check-script-permissions.sh`）— git 上のモードが `100755` でないとコミットを拒否する。新規スクリプトは `chmod 755` してからコミットする。加えて shellcheck（構文・落とし穴の静的検査）

設定はそれぞれ `api/pyproject.toml`・`viewer/eslint.config.ts`・`viewer/.prettierrc.json` にある。

## セットアップ（開発者ごとに1回）

前提: uv・Node.js がインストール済みであること（[api.md](api.md)・[viewer.md](viewer.md) 参照）。

```bash
uv tool install pre-commit
```

```bash
cd /path/to/factone-idp-viewer
pre-commit install
```

以降、`git commit` のたびに変更ファイルへ自動でチェックが走る。

## 手動実行

全ファイルを対象にチェックする場合:

```bash
pre-commit run --all-files
```

将来CIを導入する際も、このコマンドを同一の入口として使用する。

## テスト

テストは pre-commit に含めない（コミット毎の実行は過剰なため）。従来どおり実行する:

```bash
cd api && uv run pytest
```

```bash
cd viewer && npm run test
```

## トラブルシュート

- `mypy` や `eslint` のフックが失敗する場合、依存が未同期の可能性がある。`cd api && uv sync`・`cd viewer && npm install` を実行する。
- フックは Linux（WSL2）シェル上で `uv`・`npm` が PATH にあることを前提とする。
