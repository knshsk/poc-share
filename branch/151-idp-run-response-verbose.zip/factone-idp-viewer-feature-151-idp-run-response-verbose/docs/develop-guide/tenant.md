# テナント運用（作成・ユーザー追加・無効化）

テナントの追加と無効化を `scripts/tenant.sh` で行う手順。本稼働時は社内 SaaS の Keycloak に統合する予定のため、本スクリプトは統合までの間に本リポジトリの realm `factone` を運用する最小限の手段である。テナント管理 API・管理画面は持たない。

設計は [architecture/auth.md](../architecture/auth.md) の「テナント解決」と [ADR-0020](../adr/0020-single-realm-tenant-claim.md) を参照。

## 前提

- ローカルスタックが起動している（`kcadm` はローカルの Keycloak コンテナ内のものを使う。[local-stack.md](local-stack.md)）
- 管理者資格情報: `.env` の `KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD`。環境変数で渡すと `.env` より優先される
- Azure の realm を操作する場合は `KC_SERVER=https://<Keycloak の FQDN>` と Azure 側の管理者パスワード（`deploy-apps.sh` の `FACTONE_KEYCLOAK_ADMIN_PASSWORD`）を環境変数で渡す。ローカルコンテナ内の `kcadm` がリモートに接続する

```bash
KC_SERVER=https://factone-poc-keycloak.example.azurecontainerapps.io KC_BOOTSTRAP_ADMIN_USERNAME=admin KC_BOOTSTRAP_ADMIN_PASSWORD='<パスワード>' ./scripts/tenant.sh create acme
```

## テナント ID

`^[a-z0-9][a-z0-9-]{0,62}$`。Blob パス・クライアント ID・URL に使うため小文字英数字とハイフンに限る。`default` は realm 定義で管理する既定テナントで、本スクリプトでは扱えない。

## 1. テナント作成

```bash
./scripts/tenant.sh create <tenant_id>
```

- confidential クライアント `factone-integration-<tenant_id>` を作る（service accounts のみ。audience マッパーと hardcoded claim `tenant_id=<tenant_id>`）
- クライアントシークレットは標準出力にだけ出る。ファイルには残さないので、テナントの連携システムへ安全な経路で渡す
- 同名クライアントがあればエラー終了する（冪等ではない）
- 文書種別は投入しない。次節で登録する

## 2. 文書種別の登録

テナントの M2M トークンで文書種別設定 API を呼ぶ。トークンは client credentials grant で取る。

```bash
TOKEN=$(curl -s -d 'grant_type=client_credentials&client_id=factone-integration-<tenant_id>&client_secret=<シークレット>' http://localhost:8080/realms/factone/protocol/openid-connect/token | python3 -c 'import sys,json; print(json.load(sys.stdin)["access_token"])')
```

```bash
curl -s -X POST http://localhost:8000/api/v1/config/document-types -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"type_code":"quotation","display_name":"見積書","shareable":true,"fields":[{"key":"QuotationNo","label":"見積番号","type":"string"},{"key":"TotalAmount","label":"合計金額","type":"number"},{"key":"IssueDate","label":"発行日","type":"date"}]}'
```

種別ごとの項目は [data-model/document-type-configs.md](../data-model/document-type-configs.md) を参照。

## 3. ユーザー追加（Viewer 利用者）

```bash
KC_NEW_USER_PASSWORD='<初期パスワード>' ./scripts/tenant.sh add-user <tenant_id> <username> <email>
```

- 属性 `tenant_id=<tenant_id>` を付けて作る。1 ユーザーは 1 テナントにだけ所属する
- 初期パスワードは一時パスワードで、初回ログイン時に変更を強制する
- 既存ユーザー名ならエラー終了する
- テナントが未作成（`create` 未実行）ならエラー終了する

## 4. 無効化・再有効化

```bash
./scripts/tenant.sh disable <tenant_id>
```

```bash
./scripts/tenant.sh enable <tenant_id>
```

- クライアント `factone-integration-<tenant_id>` と、属性 `tenant_id=<tenant_id>` を持つ全ユーザーの `enabled` を切り替える
- 文書・Blob・文書種別設定は削除しない。物理削除は運用判断が必要なため対象外
- 閲覧 URL は失効しない（閲覧者はテナントの認証と無関係）。止める場合は文書ごとに一括失効 API `POST /api/v1/documents/{document_id}/view-urls/revoke-all` を呼ぶ

## 動作確認（作成から無効化まで）

1. `create` でクライアントを作り、client credentials でトークンを取って `tenant_id` クレームを確認する
2. 2 節の手順で文書種別を 1 つ登録し、`GET /api/v1/config/document-types` に出ることを確認する
3. `POST /api/v1/documents` で文書を登録し、`tenant_id` が応答に入ることを確認する
4. `disable` 後にトークン取得が 401 になることを確認する
5. `enable` で戻す

## トラブルシュート

- `エラー: クライアント ... が見つかりません`: `create` 前に `disable` / `enable` を呼んでいる。または `KC_SERVER` の接続先が違う
- `kcadm` の `HTTP 401`: 管理者資格情報が違う。Azure は `deploy-apps.sh` 実行時のパスワードを使う
- 作ったユーザーでログインできるのに API が 403 `tenant-unresolved`: realm 定義に `tenant_id` 属性・マッパーが入る前の Keycloak データを使っている。[local-stack.md](local-stack.md) の初期化、Azure は [deploy.md](deploy.md) の realm 再インポートを行う
