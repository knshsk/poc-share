# 読取結果パネル（右ペイン）

Viewer 右ペインの作業パネル（`WorkPanel`）の設計。読取結果の確認・修正・確定と、実行履歴の閲覧を行う。キャンバスとの相互ハイライトは本書末尾と [display.md](display.md) を参照。

## 構成

- 上部: [IDP実行] ボタンと選択中結果のチップ（区分 · 日時 · 修正者。`corrected` は primary 色）
- タブ: 読取結果 / 実行履歴 / 閲覧URL（文書種別が `shareable` のときのみ）
- 本文: タブごとの内容。パネル内で縦スクロールする
- 下部固定のアクションバー（読取結果タブ・成功実行選択時のみ）: 「変更 N件」+ [破棄] + [確定]。確定・破棄は N ≥ 1 のときだけ有効

## 読取結果タブ（`ResultEditor`）

`v-expansion-panels`（複数同時展開・初期は全展開）で 3 区分を縦に並べる。

- **キー項目**（Query Fields）: 行 = ラベル（実行時 `fields[key].label`、無ければキー）+ 確信度 % + 編集可テキストボックス + 確信度バー。値は `fields[key].normalized_value` を文字列化したもの（null なら `fields[key].value`。両方 null は空欄でプレースホルダ「（値なし）」）。表示順は現在の文書種別設定 `fields[].key` の順（応答の `fields` は JSONB 由来でキー順が設定順にならない）。設定に無いキーは末尾。設定で `visible=false` の項目は表示しない（抽出・保存・API 返却は行う）
  - `fields[key].value` が入力欄の元値と異なる項目は、確信度バーの下に「読取値 …」を補足表示する（DI が読んだ原典。転記対象は正規化値）
  - number / date 型は入力中にクライアント側で正規化を試し、「正規化値 …」（入力値と同表記なら省略）または「数値として解釈できません」「日付として解釈できません」を行内に表示する（`viewer/src/utils/normalize.ts`。サーバ `_normalize` と同規則。規則は [idp-runs.md](../data-model/idp-runs.md) の「正規化規則」。表示のみで送信は妨げない）。型は現在の文書種別設定を参照し、設定に無いキーは string
- **キー項目候補**（正規表現一致 `pattern_matches`）: パターンごとにラベルと一致値のチップ列。正規表現は表示しない。0 件は「一致なし」。読取専用
- **グリッド**（`tables`）: テーブルごとに見出し「表 n（r 行 × c 列）」と `row_count × column_count` の CSS グリッド。全セル（ヘッダ行を含む）が編集可。`kind = columnHeader` は背景色で区別。セルが無い座標は破線の空枠。横は区分内スクロール。結合セル（`row_span` / `column_span` > 1）も起点セルのみ描画する
- 失敗実行を選択中はエラー表示のみ（編集不可）

## 修正の下書きと確定

- 下書きは Pinia ストア `draft`（`viewer/src/stores/draft.ts`）に差分のみ保持する: `fields: {key: string | null}` / `cells: {"t:r:c": string}`。入力値が元値（入力欄の初期値 = 正規化値、無ければ読取値）と同じに戻ったら差分から外す。空欄は null（値なし）
- 変更件数 = `fields` のキー数 + `cells` のキー数
- 確定: `POST /api/v1/documents/{document_id}/idp-runs/{run_id}/corrections` に差分（`{fields, table_cells}`）を送る。`run_id` は選択中の実行結果（base）。応答の `corrected` 行を選択状態にして履歴の先頭へ追加し、下書きをリセットし、スナックバー「修正を保存しました」を表示する。失敗時はエラーアラート「修正の保存に失敗しました」（下書きは保持）
- 破棄: 下書きをリセットする
- 人手修正済みの値（保存済み `run.corrections` に含まれるキー / セルと、未保存の下書き）はテキストボックス左端の primary アクセントと鉛筆アイコン（ツールチップ「修正」）で示す。`corrections` は根の機械実行に対する累積差分のため、連鎖修正の 2 世代目以降でも前世代で直したキー / セルにマークが付く
- 値が base と同一でも送信を拒否しない（差分に入らないだけ）。排他制御は行わない（同一 base への並行修正は両方追記される。PoC 制限）

## 未保存の変更のガード

- 未保存の変更がある状態での **履歴選択 / IDP実行 / 文書切替（ヘッダの文書 ID 変更）** は `draft.guard(action)` で保留し、確認ダイアログ「未保存の変更を破棄しますか？」（キャンセル / 破棄して続行）を挟む。続行で下書きを捨ててから操作を実行する
- 履歴選択のガードは、先に読取結果タブへ切り替えてからダイアログを表示する（未保存の編集内容がダイアログの下に見えたままになる）
- ブラウザ離脱（タブを閉じる・リロード）には `beforeunload` の標準警告を出す（文言はブラウザ固定）

## 実行履歴タブ

- 一覧 API のサマリで描画する（日時・区分「初回 / 再実行 / 修正」・成否・修正者）。モデル ID・API バージョンは表示しない
- 行選択で詳細を取得して読取結果タブへ切り替える。表示順は日時降順

## データ取得

- 文書表示時: 一覧取得 → 末尾（最新）を選択 → 詳細取得
- IDP実行 / 確定: 応答（`IdpRunResponse`）をそのまま選択状態にする（再取得しない）。応答受信時に `pendingRunId` を更新し、それ以前に要求した詳細取得の応答が遅れて届いても表示を上書きしない
- 履歴選択: 詳細取得。取得済みは `run_id` をキーにコンポーネント内でキャッシュする（行は不変）
- 文書種別設定（`fields[].key / label / type / visible`）は `document` ストアの `fieldDefs` に保持し、非表示判定と型ヒントに使う

## 相互ハイライト（キャンバス⇄右ペイン）

- 入力欄（キー項目・グリッドセル）のフォーカスで `highlight.selectFromPane(id)` を呼び、`activeId` を設定してキャンバスへ「矩形を表示範囲へ」を要求する。ID は `field:{key}` / `cell:{table}:{row}:{col}`（`viewer/src/utils/runs.ts` の `fieldId` / `cellId`。下書きの `cellKey` とは別）
- キャンバスの矩形クリック（`highlight.selectFromCanvas(id)`）で `WorkPanel` が読取結果タブへ切り替え、`ResultEditor` が該当入力欄（`data-target-id`）を `scrollIntoView` + `focus()` する
- 選択中の入力欄は primary 10% の背景 + 1px の primary 枠（`target--active`）に加え、`<input>` に `aria-current="true"` を付ける（色以外の手掛かり）。フォーカスが外れても維持し、履歴選択・IDP実行・確定で解除する
- キー項目候補（正規表現一致）は座標を持たないため対象外

## アクセシビリティ

- キーボード操作: キャンバスの読取矩形は Tab で到達でき、Enter / Space でクリックと同じ選択（読取結果タブへ切替 + 該当入力欄へフォーカス）を行う（[display.md](display.md) を参照）。入力欄のフォーカス（Tab 移動を含む）でキャンバス側の矩形が選択される
- 読取値の補足と正規化ヒントは `hide-details` のため messages スロットを使わず、各要素に `id` を振って入力欄の `aria-describedby` で紐付ける（両方あるときは空白区切り）
- 修正済みマーク（鉛筆アイコン）は `role="img"` + `aria-label="修正"`（ツールチップはマウス限定のため）
- 確認ダイアログ「未保存の変更を破棄しますか？」はタイトル要素を `aria-labelledby` で紐付ける
- 入力欄の `scrollIntoView` は `prefers-reduced-motion: reduce` のとき `behavior: 'auto'`（`viewer/src/utils/motion.ts` の `scrollBehavior`）
- 修正入力欄は `maxlength="2000"`（サーバ側 `CorrectionText` の上限と一致）
