---
status: accepted
date: 2026-09-17
---

# IDP 実行結果の応答を単一スキーマとし、Viewer 向け付加情報は `verbose` パラメータで追加する

## 背景

IDP 実行結果（`IdpRunResponse`）は外部連携システム（Power Automate・CRM 等）と Viewer の両方が取得する。Viewer はキャンバスのハイライトに読取領域・セル座標を、修正 UI に人手差分（`corrections`）を使うが、外部システムには不要で応答を肥大させる。また項目値が `raw_fields` / `normalized_fields` / `confidence` / `field_labels` / `field_regions` の並列 dict に分かれ、同じキーを何度も引く必要があった。外部連携システムは未接続で、v1 内の破壊的変更を許容できる期間にある（ADR-0017）。

## 決定

- 応答は単一スキーマとし、項目値は `fields[key] = {value, normalized_value, confidence}` に統合する。
- クエリ `verbose`（既定 `false`）を `IdpRunResponse` を返す 4 エンドポイント（実行・最新・詳細・修正）に付ける。`verbose=true` は同じスキーマにキーを追加するだけで、値の形は変えない: `fields[key].label` / `fields[key].region` / `tables[].cells[].polygon` / `corrections`。非 verbose ではこれらのキー自体を省略する。
- `pattern_matches` は座標を含まず小さいため現行形（`label` / `regex` / `values`）を維持する。セルの `content` は修正リクエストと同名を保つ。
- DB 列は変更せず、応答組立で変換する。テーブルセルには `row_span` / `column_span` を新たに抽出し、保存前の行は応答で 1 に補完する。

## 検討した代替案

- 外部向け・Viewer 向けの別エンドポイント — 契約が 2 本になり、修正 API など詳細を返す経路ごとに対を作る必要がある。同期コストが増えるため却下
- `include=regions,corrections` のような項目選択 — 必要な区分は「外部向け」「Viewer 向け」の 2 種のみで、選択肢の組合せ分のテストと文書が過剰。必要になった時点で `verbose` から拡張できるため却下
- `Accept` ヘッダによる表現切替 — クライアント（openapi-fetch）と OpenAPI 生成の扱いが煩雑で、ブラウザから確認しづらいため却下
- 応答形状を変えず座標だけ省く — 並列 dict の読みにくさが残る。破壊的変更を許容できる今しか統合の機会がないため統合を選んだ

## 影響

- v1 内の破壊的変更（`docs/api/README.md` に記録）。Viewer は同 PR で追従する
- Viewer は詳細取得・実行・修正の応答を `verbose=true` で受ける必要がある。付け忘れるとハイライトと修正済みマークが出ない（型上は optional で検知できない）
- 非 verbose 時のキー省略は `response_model_exclude_unset` に依存する。応答組立で verbose 専用キーを既定値に頼ると省略されるため、明示的にセットする規約を `_to_response` に置く
- `row_span` / `column_span` の Viewer 側描画（結合セルの矩形拡張・グリッドの結合表示）は未対応。必要になった時点で対応する
