---
status: accepted
date: 2026-09-15
---

# テナントは単一 realm のアクセストークンの tenant_id クレームで解決する

## 背景

データモデルには `tenant_id` 列を先行導入していたが、テナントを解決する手段がなく、全 API が設定値 `FACTONE_TENANT_ID=default` で固定されていた。本稼働時は社内で展開されている SaaS に統合する予定で、その IdP は Keycloak であり、SaaS 内の各サービスは単一 realm + テナント ID クレームでテナントを解決している。

## 決定

Keycloak は単一 realm `factone` のまま、アクセストークンのクレーム `tenant_id` でテナントを解決する。API は JWT 検証後にクレームを取り、欠落・空文字・文字列以外なら 403 `tenant-unresolved` を返す。全データアクセスはこの値で絞る。

- SPA 利用者: ユーザー属性 `tenant_id` を user-attribute マッパーでクレームに載せる。1 ユーザーは 1 テナントにだけ所属する
- 外部連携システム（M2M）: テナントごとに confidential クライアント `factone-integration-<tenant_id>` を作り、hardcoded claim マッパーで `tenant_id` を載せる
- テナントの作成・無効化は `scripts/tenant.sh`（kcadm）で行い、管理 API・画面は持たない

## 検討した代替案

- realm 分離（テナントごとに realm） — 統合先の SaaS と方式が異なる。Viewer の OIDC authority を実行時に切り替える必要があり、JWKS 取得も realm 数分になる
- 単一 M2M クライアント + リクエストヘッダでテナント指定 — テナントが JWT 外の値になり信頼境界が弱い。全テナントで 1 つのシークレットを共有することになる
- 単一 M2M クライアントの service account ユーザーに属性付与 — 実質テナント 1 個固定。複数テナントにするとテナント毎クライアントと同じ操作量で、属性の所在が見えにくい
- 複数テナント所属ユーザー — 現時点の要件になく、クレームの多値化と選択 UI が必要になるため対象外

## 影響

- 既存クライアントは Keycloak 側のマッパー追加だけで無変更。API のパス・応答スキーマは変えない
- 新エラー 403 `tenant-unresolved` が認証必須の全エンドポイントに加わる
- テナント追加の運用負荷はクライアント 1 個 + マッパー 1 個。シークレットの発行・配布はどの方式でも必要
- 統合先 SaaS のクレーム名・形式が `tenant_id` 文字列と異なる場合は `core/auth.py` の抽出部だけを合わせる
