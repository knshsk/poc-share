---
status: accepted
date: 2026-09-15
---

# documents の主キーを内部 UUID にし (tenant_id, document_id) を一意にする

## 背景

`documents.document_id` は呼出側採番の文字列で単独主キーだった。テナントごとに採番体系が異なるため、複数テナントを収容すると同じ `document_id` が別テナントから登録されうる。子テーブル（`view_tokens` / `view_events` / `idp_runs`）は `document_id` への外部キーを持っていた。

## 決定

`documents` に内部 UUID 主キー `id` を追加し、`(tenant_id, document_id)` を UNIQUE（`uq_documents_tenant_document`）にする。子テーブルの外部キーは `document_pk UUID → documents.id` に張り替え、`view_events` の冪等キーも `(document_pk, occurred_at, event_type)` にする。API の URL は引き続き `document_id` で、テナントは JWT から取って `(tenant_id, document_id)` で引く。

## 検討した代替案

- 複合主キー `(tenant_id, document_id)` — 子テーブル 3 本の外部キーが複合になり、結合・挿入の記述が全て 2 列になる
- 文書 ID をテナント跨ぎで全体一意にする — 呼出側に採番の制約を押し付ける。テナント間で採番体系を揃えられない

## 影響

- 応答の `document_id` は relationship 経由（`run.document.document_id` 等）で返す。応答の形は変えない
- 子テーブルに `tenant_id` は持たない。テナント絞りは `documents` との JOIN で行う
- マイグレーションの downgrade は、テナント間で同じ `document_id` が存在すると旧主キーを再作成できず失敗する
