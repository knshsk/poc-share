<script setup lang="ts">
import {
  PhArrowsHorizontal,
  PhCaretLeft,
  PhCaretRight,
  PhCornersOut,
  PhDownloadSimple,
  PhMagnifyingGlassMinus,
  PhMagnifyingGlassPlus,
} from '@phosphor-icons/vue'
import type { ComponentPublicInstance } from 'vue'
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { CanvasVm } from '../mediator/vm'
import { scrollBehavior } from '../utils/motion'
import { overlayRectsByPage } from '../utils/runs'
import { fitZoom, PX_PER_INCH, type ZoomMode } from '../utils/zoom'
import PageSvg from './PageSvg.vue'

// vm: ページ寸法・選択中の実行（矩形の描画元）・項目定義（visible=false の除外）・ページ画像・
// 選択中 ID・ペインからのスクロール要求・ダウンロード文言。認証済みと公開閲覧の違いは Mediator が vm で吸収する
const props = defineProps<{ vm: CanvasVm }>()

const bubble = useBubble()

const ZOOM_MIN = 25
const ZOOM_MAX = 200
const ZOOM_STEP = 25
// ズームはページ実寸比%（100=実寸）。CSS width制御のためPageSvgのviewBox（DI座標系）は不変。
// モードはフィット2種（幅・全体）+手動。初期は全体表示。複数ページは1ページ目の寸法で倍率を計算し、全ページ同じ幅で並べる。
// ズーム・表示中ページは描画パラメータなので View が持つ
const mode = ref<ZoomMode>('page')
const zoom = ref(100)
const frameWidth = computed(
  () => ((props.vm.pages[0]?.width ?? 0) * PX_PER_INCH * zoom.value) / 100,
)
const currentPage = ref(1)
const scroller = ref<HTMLElement | null>(null)
const pageEls = ref<HTMLElement[]>([])
let resizeObserver: ResizeObserver | null = null

function setPageEl(
  el: Element | ComponentPublicInstance | null,
  index: number,
): void {
  if (el instanceof HTMLElement) pageEls.value[index] = el
}

// v-btn-toggleは選択中ボタンの再クリックでundefinedを渡す（選択解除）。フィットモードは解除せず、
// 現在のモードのまま再計算する（コンテナサイズ変化後の再クリックでズームを追従させるため）
function applyMode(next: ZoomMode | undefined): void {
  const target = next ?? mode.value
  if (target === 'custom') return
  mode.value = target
  const el = scroller.value
  const page = props.vm.pages[0]
  zoom.value =
    el && page ? fitZoom(target, el.clientWidth, el.clientHeight, page) : 100
}

// ±は25の倍数へスナップする（フィット値85%から拡大→100%、縮小→75%）
function stepZoom(delta: number): void {
  mode.value = 'custom'
  const next =
    delta > 0
      ? Math.floor(zoom.value / ZOOM_STEP) * ZOOM_STEP + ZOOM_STEP
      : Math.ceil(zoom.value / ZOOM_STEP) * ZOOM_STEP - ZOOM_STEP
  zoom.value = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, next))
}

onMounted(() => {
  applyMode('page')
  // コンテナサイズ変化（ペイン幅・ウィンドウ）でフィット系モードを再計算する。手動ズームは維持。
  // border-box観測かつ実寸不変なら再計算しない（スクロールバー出入り・初回通知で再フィットが連鎖しないように）
  if (typeof ResizeObserver !== 'undefined' && scroller.value) {
    let lastSize = ''
    resizeObserver = new ResizeObserver(([entry]) => {
      const size = `${entry?.borderBoxSize?.[0]?.inlineSize ?? 0}x${entry?.borderBoxSize?.[0]?.blockSize ?? 0}`
      if (size === lastSize) return
      lastSize = size
      applyMode(mode.value)
    })
    resizeObserver.observe(scroller.value, { box: 'border-box' })
  }
})

onUnmounted(() => {
  resizeObserver?.disconnect()
  resizeObserver = null
})

const hiddenKeys = computed(
  () => new Set(props.vm.fieldDefs.filter((f) => !f.visible).map((f) => f.key)),
)
const rectsByPage = computed(() =>
  overlayRectsByPage(props.vm.run, hiddenKeys.value),
)

// ペイン側フォーカス → 該当矩形を表示範囲へ（同一 ID の再要求も seq が変わるため発火する）
watch(
  () => props.vm.scrollRequest,
  async (request) => {
    if (!request) return
    await nextTick()
    scroller.value
      ?.querySelector(`[data-rect-id="${CSS.escape(request.id)}"]`)
      ?.scrollIntoView?.({
        block: 'center',
        inline: 'center',
        behavior: scrollBehavior(),
      })
  },
)

function goToPage(page: number): void {
  const target = Math.min(props.vm.pages.length, Math.max(1, page))
  currentPage.value = target
  // jsdomはscrollIntoView未実装のため存在確認する
  pageEls.value[target - 1]?.scrollIntoView?.({
    block: 'start',
    behavior: scrollBehavior(),
  })
}

// スクロール位置から表示中ページを判定（コンテナ上端+1/3を基準線とする）
function onScroll(): void {
  const container = scroller.value
  if (!container) return
  const line =
    container.getBoundingClientRect().top + container.clientHeight / 3
  for (let i = pageEls.value.length - 1; i >= 0; i--) {
    const rect = pageEls.value[i]?.getBoundingClientRect()
    if (rect && rect.top <= line) {
      currentPage.value = i + 1
      return
    }
  }
  currentPage.value = 1
}
</script>

<template>
  <div class="document-canvas">
    <div class="canvas-toolbar">
      <!-- ページ送りは複数ページ文書のときだけ出す（1 ページでは移動先が無い） -->
      <template v-if="vm.pages.length > 1">
        <v-btn
          icon
          size="small"
          variant="text"
          data-testid="canvas-prev"
          aria-label="前のページ"
          :disabled="currentPage <= 1"
          @click="goToPage(currentPage - 1)"
        >
          <PhCaretLeft :size="18" />
        </v-btn>
        <span class="text-body-medium" data-testid="canvas-page-indicator">
          {{ currentPage }} / {{ vm.pages.length }}
        </span>
        <v-btn
          icon
          size="small"
          variant="text"
          data-testid="canvas-next"
          aria-label="次のページ"
          :disabled="currentPage >= vm.pages.length"
          @click="goToPage(currentPage + 1)"
        >
          <PhCaretRight :size="18" />
        </v-btn>

        <v-divider vertical class="mx-2" />
      </template>

      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-zoom-out"
        aria-label="縮小"
        :disabled="zoom <= ZOOM_MIN"
        @click="stepZoom(-ZOOM_STEP)"
      >
        <PhMagnifyingGlassMinus :size="18" />
      </v-btn>
      <span class="text-body-medium zoom-value" data-testid="canvas-zoom"
        >{{ zoom }}%</span
      >
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-zoom-in"
        aria-label="拡大"
        :disabled="zoom >= ZOOM_MAX"
        @click="stepZoom(ZOOM_STEP)"
      >
        <PhMagnifyingGlassPlus :size="18" />
      </v-btn>

      <v-divider vertical class="mx-2" />

      <!-- フィット: 幅に合わせる / ページ全体を表示。選択中を強調し、±操作後（custom）は非選択。
           v-btn-toggle 内の icon ボタンは左右余白が付かず幅 20px に潰れるため、icon 指定はしない -->
      <v-btn-toggle
        :model-value="mode"
        density="compact"
        variant="text"
        color="primary"
        @update:model-value="(v) => applyMode(v as ZoomMode | undefined)"
      >
        <v-btn
          size="small"
          value="width"
          data-testid="canvas-fit-width"
          aria-label="幅に合わせる"
          :aria-pressed="mode === 'width'"
        >
          <v-tooltip activator="parent" location="bottom"
            >幅に合わせる</v-tooltip
          >
          <PhArrowsHorizontal :size="18" />
        </v-btn>
        <v-btn
          size="small"
          value="page"
          data-testid="canvas-fit-page"
          aria-label="ページ全体を表示"
          :aria-pressed="mode === 'page'"
        >
          <v-tooltip activator="parent" location="bottom"
            >ページ全体を表示</v-tooltip
          >
          <PhCornersOut :size="18" />
        </v-btn>
      </v-btn-toggle>

      <v-spacer />

      <v-btn
        variant="outlined"
        size="small"
        data-testid="download-original"
        @click="bubble({ type: 'downloadOriginal' })"
      >
        <PhDownloadSimple :size="16" class="mr-1" />
        {{ vm.downloadLabel }}
      </v-btn>
    </div>

    <div ref="scroller" class="canvas-scroller" @scroll.passive="onScroll">
      <div
        v-for="(page, index) in vm.pages"
        :key="index"
        :ref="(el) => setPageEl(el, index)"
        class="page-frame"
        :style="{ width: `${frameWidth}px` }"
      >
        <PageSvg
          :page="index + 1"
          :width="page.width"
          :height="page.height"
          :rects="rectsByPage.get(index + 1) ?? []"
          :active-id="vm.activeId"
          :image-url="vm.images[index + 1] ?? null"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
.document-canvas {
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 100%;
}

.canvas-toolbar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 4px;
  padding: 4px 12px;
  background: rgb(var(--v-theme-surface));
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.zoom-value {
  min-width: 44px;
  text-align: center;
}

/* padding / margin の値は utils/zoom.ts の定数（SCROLLER_PADDING 等）と一致させる */
.canvas-scroller {
  flex: 1;
  min-height: 0;
  overflow: auto;
  /* 縦スクロールバーの有無で内寸幅が変わるとフィット倍率が押下のたびにずれる（37%→36%）ため、溝を常時確保する。
     ponytail: 横スクロールバー（手動の倍率で横にはみ出した状態から全体表示にしたとき）の高さは未考慮。必要になれば offsetHeight-clientHeight で補正 */
  scrollbar-gutter: stable;
  background: rgb(var(--v-theme-canvas));
  padding: 24px;
}

.page-frame {
  margin: 0 auto 24px;
  background: rgb(var(--v-theme-surface));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
</style>
