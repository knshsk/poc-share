import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { describe, expect, it } from 'vitest'

// Vuetify 4 のタイポグラフィクラスは MD3 名（text-body-medium 等）だけ。Vuetify 3 までの旧名（text-caption 等）・
// text-button・レスポンシブ接頭辞（text-md-h6 等）・MD3 名の typo（text-body-mid 等）は定義が無く、
// 書いても無言で効かない（16px 継承になる）ため、混入をここで検出する
const LEGACY =
  /\btext-(?:(?:sm|md|lg|xl|xxl)-)?(?:caption|button|overline|h[1-6]|subtitle-[12]|(?:display|headline|title|body|label)-(?!(?:large|medium|small)\b)[\w-]*)/

// 文字の下限は 14px（ADR-0024）。MD3 名のうち 14px 未満のもの（body-small 12px・label-medium 12px・label-small 11px）
const SMALL_CLASS = /\btext-(?:body-small|label-medium|label-small)\b/
// x-small のチップ・ボタンは高さ 20px で、14px の文字が収まらない
const X_SMALL = /\bsize="x-small"/
// font-size の数値と単位（rem / px）
const FONT_SIZE = /font-size:\s*([\d.]+)(rem|px)\b/g

const srcDir = join(import.meta.dirname, '../src')
const mainCss = readFileSync(join(srcDir, 'assets/main.css'), 'utf8')
const mainTs = readFileSync(join(srcDir, 'main.ts'), 'utf8')

// src 配下で拡張子が ext に一致するファイルから、match に一致する行を「ファイル:行番号: 行」で返す
function findLines(ext: RegExp, match: (line: string) => boolean): string[] {
  return readdirSync(srcDir, { recursive: true, encoding: 'utf8' })
    .filter((file) => ext.test(file))
    .flatMap((file) =>
      readFileSync(join(srcDir, file), 'utf8')
        .split('\n')
        .flatMap((line, i) =>
          match(line) ? [`${file}:${i + 1}: ${line.trim()}`] : [],
        ),
    )
}

// 行に 14px（0.875rem）未満の font-size があるか（1rem = 16px）
function hasSmallFontSize(line: string): boolean {
  return [...line.matchAll(FONT_SIZE)].some(
    ([, value, unit]) => Number(value) * (unit === 'rem' ? 16 : 1) < 14,
  )
}

describe('タイポグラフィクラス', () => {
  it('Vuetify 3 までの旧クラス名を使っていない', () => {
    expect(findLines(/\.(vue|ts)$/, (line) => LEGACY.test(line))).toEqual([])
  })

  it('LEGACY は旧名・text-button・レスポンシブ接頭辞・MD3 名の typo に一致し、正しい MD3 名には一致しない', () => {
    for (const cls of [
      'text-caption',
      'text-md-h6',
      'text-body-mid',
      'text-button',
    ]) {
      expect(LEGACY.test(cls)).toBe(true)
    }
    for (const cls of [
      'text-body-medium',
      'text-title-large',
      'text-medium-emphasis',
      'text-none',
    ]) {
      expect(LEGACY.test(cls)).toBe(false)
    }
  })

  // コメントの例示も対象にする（例示が書き写されるため）
  it('14px 未満のタイポグラフィクラスを使っていない', () => {
    expect(
      findLines(/\.(vue|ts|css)$/, (line) => SMALL_CLASS.test(line)),
    ).toEqual([])
  })

  it('size="x-small" を使っていない', () => {
    expect(findLines(/\.vue$/, (line) => X_SMALL.test(line))).toEqual([])
  })

  it('14px（0.875rem）未満の font-size を書いていない', () => {
    expect(findLines(/\.(vue|css)$/, hasSmallFontSize)).toEqual([])
  })

  it('14px 未満の検出は 14px 未満の指定に一致し、14px 以上には一致しない', () => {
    for (const cls of [
      'text-body-small',
      'text-label-medium',
      'text-label-small',
    ]) {
      expect(SMALL_CLASS.test(cls)).toBe(true)
    }
    for (const cls of [
      'text-body-medium',
      'text-body-large',
      'text-label-large',
      'text-title-small',
    ]) {
      expect(SMALL_CLASS.test(cls)).toBe(false)
    }
    expect(X_SMALL.test('<v-chip size="x-small">')).toBe(true)
    expect(X_SMALL.test('<v-chip size="small">')).toBe(false)
    for (const decl of [
      'font-size: 0.8125rem;',
      'font-size: 0.75rem',
      'font-size: 12px',
      'font-size:13px',
    ]) {
      expect(hasSmallFontSize(decl)).toBe(true)
    }
    for (const decl of [
      'font-size: 0.875rem;',
      'font-size: 1rem',
      'font-size: 14px',
      'font-size: var(--v-btn-size)',
    ]) {
      expect(hasSmallFontSize(decl)).toBe(false)
    }
  })

  // --v-font-body が消えると MD3 クラスの箇所とオーバーレイが無言で Roboto に戻る
  it('main.css が --v-font-body を定義している', () => {
    expect(mainCss).toMatch(/^\s*--v-font-body:\s*\S/m)
  })

  // 日本語フォールバックが無いと、キー項目の正規化値のヒント・候補値に含まれる仮名・漢字が環境依存の
  // 和文フォント（generic monospace）に落ちる
  it('main.css の --font-mono が IBM Plex Sans JP にフォールバックする', () => {
    expect(mainCss).toMatch(/--font-mono:[^;]*'IBM Plex Sans JP'/)
  })

  // レイヤーに入れないと、この reset は Vuetify の mt-*/mb-*（vuetify-utilities レイヤー）に無言で負ける
  it('main.css が @layer app-reset 内で p の margin を 0 にしている', () => {
    expect(mainCss).toMatch(
      /@layer app-reset\s*{\s*p\s*{\s*margin:\s*0;?\s*}\s*}/,
    )
  })

  // app-reset がレイヤーに入っていても、main.css の import が vuetify より後だとレイヤーの登録順が
  // 逆転し、app-reset が最上位（最優先）レイヤーになって Vuetify の他のレイヤーに勝ってしまう
  it('main.ts で main.css の import が vuetify プラグインの import より前にある', () => {
    expect(mainTs.indexOf('./assets/main.css')).toBeLessThan(
      mainTs.indexOf('./plugins/vuetify'),
    )
  })
})

const overridesPath = join(srcDir, 'assets/vuetify-overrides.css')
const pluginTs = readFileSync(join(srcDir, 'plugins/vuetify.ts'), 'utf8')

// Vuetify の部品が内部で持つ文字サイズ・透明度は assets/vuetify-overrides.css の vuetify-overrides レイヤーで上書きする
// （ADR-0024）。見た目の効きは jsdom で計算できないため、ここでは規則・レイヤー・import 順を検査する
describe('Vuetify 内部の上書き（assets/vuetify-overrides.css）', () => {
  const css = existsSync(overridesPath)
    ? readFileSync(overridesPath, 'utf8')
    : ''
  // コメントを除いた本体
  const code = css.replace(/\/\*[\s\S]*?\*\//g, '').trim()

  // レイヤーの外に書いた規則は、Vuetify のユーティリティクラス（text-* / mt-* 等）にも勝ってしまう
  it('全体が 1 つの @layer vuetify-overrides ブロックである', () => {
    expect(code.startsWith('@layer vuetify-overrides {')).toBe(true)
    // レイヤーの開き括弧に対応する閉じ括弧が、本体の最後の文字であること
    let depth = 0
    let close = -1
    for (let i = code.indexOf('{'); i >= 0 && i < code.length; i++) {
      if (code[i] === '{') depth++
      else if (code[i] === '}' && --depth === 0) {
        close = i
        break
      }
    }
    expect(close).toBe(code.length - 1)
  })

  // プレースホルダと枠のセレクタの条件は、Vuetify の既定の挙動を壊さないためのもの:
  // ラベル付きの未入力の欄ではプレースホルダを隠す（opacity 0）、ホバー・フォーカス・エラーでは枠を濃くする
  it.each([
    [
      '浮動ラベル 14px',
      /\.v-label\.v-field-label--floating\s*{\s*--v-field-label-scale:\s*0\.875em;/,
    ],
    [
      'small のボタン 14px',
      /\.v-btn\.v-btn--size-small\s*{\s*--v-btn-size:\s*0\.875rem;/,
    ],
    [
      'small のチップ 14px',
      /\.v-chip\.v-chip--size-small\s*{[^}]*font-size:\s*0\.875rem;/,
    ],
    [
      'プレースホルダは見える状態だけ 0.85',
      /:where\(\s*\.v-field--no-label,\s*\.v-field--active\s*\)\s*:where\([^)]*\)::placeholder\s*{\s*opacity:\s*0\.85;/,
    ],
    [
      '入力欄の枠は通常時だけ 0.64',
      /\.v-field:not\(\s*:hover,\s*\.v-field--focused,\s*\.v-field--error\s*\)\s+\.v-field__outline\s*{\s*--v-field-border-opacity:\s*0\.64;/,
    ],
  ])('%s', (_, rule) => {
    expect(code).toMatch(rule)
  })

  // main.css は vuetify より先に読むため、そこに @layer vuetify-overrides を書くとレイヤーの登録順が
  // vuetify-core より前になり、上書きが Vuetify に負ける
  it('plugins/vuetify.ts で vuetify/styles の後に import し、main.css には書かない', () => {
    const styles = pluginTs.indexOf("import 'vuetify/styles'")
    const overrides = pluginTs.indexOf(
      "import '../assets/vuetify-overrides.css'",
    )
    expect(styles).toBeGreaterThanOrEqual(0)
    expect(overrides).toBeGreaterThan(styles)
    expect(mainCss).not.toContain('vuetify-overrides')
  })
})
