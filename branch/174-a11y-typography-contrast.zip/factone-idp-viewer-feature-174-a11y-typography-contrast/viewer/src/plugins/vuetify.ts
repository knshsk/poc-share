import 'vuetify/styles'
// Vuetify の部品の内部の文字サイズ・透明度の上書き（vuetify-overrides レイヤー）。vuetify/styles より後に読む
import '../assets/vuetify-overrides.css'

import {
  PhArrowDown,
  PhArrowElbowDownLeft,
  PhArrowFatUp,
  PhArrowLeft,
  PhArrowRight,
  PhArrowUp,
  PhBackspace,
  PhCalendarBlank,
  PhCaretDown,
  PhCaretLeft,
  PhCaretLineLeft,
  PhCaretLineRight,
  PhCaretRight,
  PhCaretUp,
  PhCaretUpDown,
  PhCheck,
  PhCheckCircle,
  PhCheckSquare,
  PhCircle,
  PhCommand,
  PhControl,
  PhEyedropper,
  PhInfo,
  PhList,
  PhMinus,
  PhMinusSquare,
  PhOption,
  PhPalette,
  PhPaperclip,
  PhPencilSimple,
  PhPlus,
  PhRadioButton,
  PhSpinner,
  PhSquare,
  PhStar,
  PhStarHalf,
  PhUploadSimple,
  PhWarning,
  PhWarningCircle,
  PhX,
  PhXCircle,
} from '@phosphor-icons/vue'
import type { FunctionalComponent } from 'vue'
import { h } from 'vue'
import type { IconAliases, IconProps, IconSet } from 'vuetify'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

// カラートークンの唯一の定義箇所（Fluent Azureパレット）。
// ここの値を変更するとアプリ全体へ反映される。コンポーネント側での hex 直書きは禁止し、
// color="primary" などのテーマ参照か rgb(var(--v-theme-xxx)) の CSS 変数で参照する。
// 文字色に使う primary / secondary / warning / error / success は、白地・自色の淡色地（tonal）・選択行の灰色地の
// いずれでも、ホバーが重なった状態を含めて 4.5:1 以上にする（WCAG 2.2 AA・ADR-0024。tests/vuetify-plugin.test.ts が検査する）
// 例外: index.html の起動スプラッシュは Vuetify の起動前に描くため background / primary を直書きしている
// （値を変えたら index.html も直す。tests/boot-splash.test.ts が一致を検査する）
const factoneColors = {
  primary: '#0E65B0',
  'primary-darken-1': '#115EA3',
  secondary: '#616161',
  background: '#F7F9FB',
  surface: '#FFFFFF',
  // ドキュメントキャンバス地（ページ画像の背景）・バッジ背景
  canvas: '#E9EDF2',
  success: '#0F730F',
  warning: '#885B00',
  error: '#BC2A2E',
  'on-surface': '#242424',
  'on-canvas': '#424242',
}

// Vuetify が補助の文字（未入力の入力欄のラベル・一覧の副題など）に掛ける透明度。既定の 0.60 では on-surface
// （high-emphasis 0.87 が掛かる）が白地で 3.3:1 しかないため、0.78 で白地 5.4:1・選択行の灰色地（ホバー時を含む）4.7:1 以上にする（ADR-0024）
const factoneVariables = {
  'medium-emphasis-opacity': 0.78,
}

// Vuetify内部が使用するアイコンをPhosphorへ差し替える（mdi依存を持たない）
const aliases: IconAliases = {
  collapse: PhCaretUp,
  complete: PhCheck,
  cancel: PhXCircle,
  close: PhX,
  delete: PhXCircle,
  clear: PhXCircle,
  success: PhCheckCircle,
  info: PhInfo,
  warning: PhWarning,
  error: PhWarningCircle,
  prev: PhCaretLeft,
  next: PhCaretRight,
  checkboxOn: PhCheckSquare,
  checkboxOff: PhSquare,
  checkboxIndeterminate: PhMinusSquare,
  delimiter: PhCircle,
  sortAsc: PhArrowUp,
  sortDesc: PhArrowDown,
  expand: PhCaretDown,
  menu: PhList,
  subgroup: PhCaretDown,
  dropdown: PhCaretDown,
  radioOn: PhRadioButton,
  radioOff: PhCircle,
  edit: PhPencilSimple,
  ratingEmpty: PhStar,
  ratingFull: PhStar,
  ratingHalf: PhStarHalf,
  loading: PhSpinner,
  first: PhCaretLineLeft,
  last: PhCaretLineRight,
  unfold: PhCaretUpDown,
  file: PhPaperclip,
  plus: PhPlus,
  minus: PhMinus,
  calendar: PhCalendarBlank,
  treeviewCollapse: PhCaretDown,
  treeviewExpand: PhCaretRight,
  eyeDropper: PhEyedropper,
  upload: PhUploadSimple,
  color: PhPalette,
  // キーボードキー表示用（VHotkey等）
  command: PhCommand,
  ctrl: PhControl,
  space: PhMinus,
  shift: PhArrowFatUp,
  alt: PhOption,
  enter: PhArrowElbowDownLeft,
  arrowup: PhArrowUp,
  arrowdown: PhArrowDown,
  arrowleft: PhArrowLeft,
  arrowright: PhArrowRight,
  backspace: PhBackspace,
}

// エイリアス値（Phosphorコンポーネント）をそのまま描画するアイコンセット。
// 文字列アイコン名は解決しないため、テンプレートでは $alias か Phosphor 直接 import を使う
const phosphor: IconSet = {
  component: (props: IconProps) =>
    h(props.icon as FunctionalComponent, { size: '1.25em' }),
}

// components/directivesを登録しないと<v-btn>等が未知要素として素通し描画される
export function createAppVuetify() {
  return createVuetify({
    components,
    directives,
    // 入力欄の見た目はここで統一する（各コンポーネントで variant / density を指定しない）
    defaults: {
      VTextField: { variant: 'outlined', density: 'compact' },
      VSelect: { variant: 'outlined', density: 'compact' },
    },
    theme: {
      defaultTheme: 'factone',
      themes: {
        factone: {
          dark: false,
          colors: factoneColors,
          variables: factoneVariables,
        },
      },
    },
    icons: {
      defaultSet: 'phosphor',
      aliases,
      sets: { phosphor },
    },
  })
}
