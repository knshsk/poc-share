# API 開発ガイド

バックエンドAPI（`api/`）の起動・テスト実行手順です。

## 前提条件

- [uv](https://docs.astral.sh/uv/) がインストールされていること

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Python本体は uv が自動で取得するため、個別インストールは不要です。

## セットアップ

```bash
cd api
uv sync
```

依存パッケージと仮想環境（`api/.venv/`）が作成されます。

## 起動

```bash
cd api
uv run uvicorn --factory app.main:create_app --reload
```

起動後、`http://127.0.0.1:8000/health` にアクセスして `{"status": "ok"}` が返れば成功です。

## テスト実行

```bash
cd api
uv run pytest
```

## API契約の型共有（OpenAPI → TypeScript）

API契約は Pydantic モデルを単一情報源とし、以下を生成物としてコミットします。

- `docs/api/openapi.json` — OpenAPIスキーマのエクスポート（外部向け契約レビュー・共有用の正）
- `viewer/src/api/schema.d.ts` — openapi-typescript による TypeScript 型

APIのエンドポイントやモデルを変更したら再生成してコミットしてください:

```bash
cd viewer
npm run generate:api
```

生成物が古いまま（ドリフト）だと pre-commit の「API契約生成物の差分チェック」が失敗します。

## 設定

アプリケーション設定は `app/config.py` の `Settings` で管理しています。
環境変数（プレフィックス `FACTONE_`）または `api/.env` ファイルから読み込みます。

例: アプリケーション名を変更する場合

```bash
FACTONE_APP_NAME=my-api uv run uvicorn --factory app.main:create_app
```
