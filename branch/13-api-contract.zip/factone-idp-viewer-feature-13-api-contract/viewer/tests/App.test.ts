import { mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { describe, expect, it } from 'vitest'
import { createVuetify } from 'vuetify'

import App from '../src/App.vue'

describe('App', () => {
  // Vuetify・Piniaを組み込んだAppがレンダリングされ、アプリ名が表示されることを確認する
  it('アプリ名を表示する', () => {
    const wrapper = mount(App, {
      global: {
        plugins: [createVuetify(), createPinia()],
      },
    })

    expect(wrapper.text()).toContain('FactONE Viewer')
  })
})
