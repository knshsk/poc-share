<script setup lang="ts">
const appName = 'FactONE Viewer'
</script>

<template>
  <v-app>
    <v-main>
      <v-container>
        <h1>{{ appName }}</h1>
      </v-container>
    </v-main>
  </v-app>
</template>
