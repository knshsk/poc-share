import { createPinia } from 'pinia'
import { createApp } from 'vue'
import { createVuetify } from 'vuetify'
import 'vuetify/styles'

import App from './App.vue'

createApp(App).use(createPinia()).use(createVuetify()).mount('#app')
