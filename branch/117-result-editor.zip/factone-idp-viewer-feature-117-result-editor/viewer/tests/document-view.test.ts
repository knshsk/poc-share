import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// API呼出はapiClient経由のためモックする（画面はレイアウトとパネル組込が検証対象）
// 文書種別は閲覧URLパネルの表示ゲートに使う（既定: 見積）
let documentType = 'quotation'
const getMock = vi.fn()

function defaultGetImplementation(path: string) {
  if (path === '/api/v1/documents/{document_id}') {
    return Promise.resolve({
      data: {
        document_id: 'doc-1',
        tenant_id: 'tenant-1',
        document_type: documentType,
        content_sha256: 'x'.repeat(64),
        received_at: '2026-08-01T00:00:00Z',
      },
      error: undefined,
    })
  }
  if (path === '/api/v1/documents/{document_id}/view-urls') {
    return Promise.resolve({ data: [], error: undefined })
  }
  if (path === '/api/v1/documents/{document_id}/pages') {
    return Promise.resolve({
      data: { document_id: 'doc-1', pages: [{ width: 8.5, height: 11 }] },
      error: undefined,
    })
  }
  if (path === '/api/v1/documents/{document_id}/pages/{page}/image') {
    return Promise.resolve({ data: new Blob(), error: undefined })
  }
  if (path === '/api/v1/config/document-types') {
    return Promise.resolve({
      data: [
        {
          type_code: 'quotation',
          display_name: '御見積書',
          shareable: true,
          // visible=falseの項目はWorkPanelで非表示（#91）
          fields: [
            {
              key: 'total_amount',
              label: '合計金額',
              type: 'number',
              visible: true,
            },
            {
              key: 'own_company',
              label: '自社名',
              type: 'string',
              visible: false,
            },
          ],
          created_at: '2026-08-01T00:00:00Z',
          updated_at: '2026-08-01T00:00:00Z',
        },
        {
          type_code: 'purchase_order',
          display_name: '注文書（案件）',
          shareable: false,
          fields: [],
          created_at: '2026-08-01T00:00:00Z',
          updated_at: '2026-08-01T00:00:00Z',
        },
      ],
      error: undefined,
    })
  }
  return Promise.resolve({
    data: { document_id: 'doc-1', runs: [] },
    error: undefined,
  })
}

vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return vi.fn()
    },
  },
}))

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import { useDocumentStore } from '../src/stores/document'
import DocumentView from '../src/views/DocumentView.vue'

function mountView() {
  const pinia = createPinia()
  const wrapper = mount(DocumentView, {
    global: { plugins: [createAppVuetify(), pinia] },
  })
  return { wrapper, pinia }
}

// ダイアログ内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

describe('DocumentView', () => {
  beforeEach(() => {
    documentType = 'quotation'
    getMock.mockReset()
    getMock.mockImplementation(defaultGetImplementation)
  })

  // 文書表示時に作業パネルが文書ID・共有可否（設定のshareable）を引き渡されて組み込まれることを確認する
  it('文書表示時にWorkPanelを表示しshareableを渡す', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { wrapper } = mountView()
    await flushPromises()

    const panel = wrapper.findComponent(WorkPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('documentId')).toBe('doc-1')
    expect(panel.props('shareable')).toBe(true)
  })

  // 文書種別設定のfields（key/label/type/visible）がストア経由でWorkPanelへ渡ることを確認する（#91・#117）
  it('設定のfieldsをfieldDefsとしてWorkPanelへ渡す', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { wrapper, pinia } = mountView()
    await flushPromises()

    const panel = wrapper.findComponent(WorkPanel)
    expect(panel.props('fieldDefs')).toEqual([
      { key: 'total_amount', label: '合計金額', type: 'number', visible: true },
      { key: 'own_company', label: '自社名', type: 'string', visible: false },
    ])
    expect(useDocumentStore(pinia).fieldDefs).toHaveLength(2)
  })

  // 文書未表示（文書ID未入力）ではパネルを表示しないことを確認する
  it('文書未表示ではWorkPanelを表示しない', () => {
    window.history.replaceState(null, '', '/')

    const { wrapper } = mountView()

    expect(wrapper.findComponent(WorkPanel).exists()).toBe(false)
  })

  // shareable=falseの種別ではWorkPanelにfalseが渡ることを確認する
  // （閲覧URLタブの表示ゲート自体はwork-panel.test.tsが担保。ADR-0002）
  it('shareable=false種別ではWorkPanelにfalseが渡る', async () => {
    documentType = 'purchase_order'
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { wrapper } = mountView()
    await flushPromises()

    const panel = wrapper.findComponent(WorkPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('shareable')).toBe(false)
  })

  // 設定のdisplay_nameがストアへ保存されることを確認する（AppHeaderの種別チップが参照）
  it('設定のdisplay_nameをストアへ保存する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { pinia } = mountView()
    await flushPromises()

    const store = useDocumentStore(pinia)
    expect(store.documentTypeDisplayName).toBe('御見積書')
  })

  // 設定取得失敗時は表示名なし・共有不可へフォールバックすることを確認する（安全側）
  it('設定取得失敗時はdisplay_nameなし・shareable=falseへフォールバックする', async () => {
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/config/document-types') {
        return Promise.resolve({ data: undefined, error: { detail: 'x' } })
      }
      return defaultGetImplementation(path)
    })
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { wrapper, pinia } = mountView()
    await flushPromises()

    const store = useDocumentStore(pinia)
    expect(store.documentTypeDisplayName).toBeNull()
    const panel = wrapper.findComponent(WorkPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('shareable')).toBe(false)
    // 設定なし＝全項目表示（#91）
    expect(panel.props('fieldDefs')).toEqual([])
  })

  // 設定一覧に文書の種別が無い場合も同様にフォールバックすることを確認する
  it('設定に無い種別はdisplay_nameなし・shareable=falseへフォールバックする', async () => {
    documentType = 'unknown_type'
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { wrapper, pinia } = mountView()
    await flushPromises()

    const store = useDocumentStore(pinia)
    expect(store.documentTypeDisplayName).toBeNull()
    expect(wrapper.findComponent(WorkPanel).props('shareable')).toBe(false)
  })

  // 文書ID未指定時は「閲覧」「新規登録」の選択ダイアログを表示することを確認する
  it('文書ID未指定時は閲覧/新規登録の選択ダイアログを表示する', async () => {
    window.history.replaceState(null, '', '/')

    mountView()
    await flushPromises()

    // v-dialogの内容はteleportされるためdocumentから探す
    expect(document.querySelector('[data-testid="start-view"]')).not.toBeNull()
    expect(
      document.querySelector('[data-testid="start-register"]'),
    ).not.toBeNull()
    expect(
      document.querySelector('[data-testid="document-id-input"]'),
    ).toBeNull()
  })

  // 「閲覧」選択で文書ID入力欄を表示し、入力した文書IDで取得することを確認する
  it('閲覧選択で文書ID入力欄を表示し入力IDで取得する', async () => {
    window.history.replaceState(null, '', '/')

    const { pinia } = mountView()
    await flushPromises()
    ;(
      document.querySelector('[data-testid="start-view"]') as HTMLElement
    ).click()
    await flushPromises()

    const input = document.querySelector(
      '[data-testid="document-id-input"] input',
    ) as HTMLInputElement
    expect(input).not.toBeNull()
    input.value = 'doc-1'
    input.dispatchEvent(new Event('input'))
    ;(
      document.querySelector('[data-testid="document-id-apply"]') as HTMLElement
    ).click()
    await flushPromises()

    expect(useDocumentStore(pinia).documentId).toBe('doc-1')
  })

  // 「新規登録」選択で登録フォームを表示し、登録完了した文書IDを表示対象にすることを確認する
  it('新規登録選択で登録フォームを表示し登録後にその文書IDを表示する', async () => {
    window.history.replaceState(null, '', '/')

    const { wrapper, pinia } = mountView()
    await flushPromises()
    ;(
      document.querySelector('[data-testid="start-register"]') as HTMLElement
    ).click()
    await flushPromises()

    const form = wrapper.findComponent(DocumentRegisterForm)
    expect(form.exists()).toBe(true)
    form.vm.$emit('registered', 'doc-1')
    await flushPromises()

    expect(useDocumentStore(pinia).documentId).toBe('doc-1')
    expect(wrapper.findComponent(WorkPanel).props('documentId')).toBe('doc-1')
  })

  // 文書取得失敗時はエラーstateと再試行ボタンを表示することを確認する
  it('文書取得失敗時はエラーと再試行を表示する', async () => {
    getMock.mockImplementation(() =>
      Promise.resolve({ data: undefined, error: { detail: 'x' } }),
    )
    window.history.replaceState(null, '', '?document_id=doc-x')

    const { wrapper } = mountView()
    await flushPromises()

    expect(wrapper.get('[data-testid="document-error"]').text()).toContain(
      '文書を取得できませんでした',
    )
    expect(wrapper.find('[data-testid="document-retry"]').exists()).toBe(true)
  })

  // 表示成功時にDocumentCanvasへページとIDが渡ることを確認する
  it('表示成功時にDocumentCanvasを表示する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const { wrapper } = mountView()
    await flushPromises()

    const canvas = wrapper.findComponent(DocumentCanvas)
    expect(canvas.exists()).toBe(true)
    expect(canvas.props('documentId')).toBe('doc-1')
    expect(canvas.props('pages')).toHaveLength(1)
  })
})
