import type { components } from '../api/schema'

export type IdpRun = components['schemas']['IdpRunResponse']
export type IdpRunSummary = components['schemas']['IdpRunSummary']
export type Corrections = components['schemas']['CorrectionRequest']

// OpenAPI 上 dict[str, object] の列に型を付け直す。構造は docs/data-model/idp-runs.md
export interface DiTableCell {
  row_index: number
  column_index: number
  content: string
  kind: string | null
  page_number: number | null
  polygon: number[] | null
}

export interface DiTable {
  row_count: number
  column_count: number
  cells: DiTableCell[]
}

export interface PatternMatch {
  label: string
  regex: string
  values: string[]
}

export function runTables(run: IdpRun): DiTable[] {
  return (run.tables ?? []) as unknown as DiTable[]
}

export function runPatternMatches(run: IdpRun): Record<string, PatternMatch> {
  return (run.pattern_matches ?? {}) as unknown as Record<string, PatternMatch>
}

export function runCorrections(run: IdpRun): Corrections | null {
  return run.corrections as unknown as Corrections | null
}

export const RUN_TYPE_LABEL: Record<IdpRunSummary['run_type'], string> = {
  initial: '初回',
  rerun: '再実行',
  corrected: '修正',
}
