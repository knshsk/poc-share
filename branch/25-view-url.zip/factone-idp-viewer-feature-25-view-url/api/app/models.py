"""データモデル定義。設計はdocs/data-model/を参照。"""

import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class DocumentType(enum.StrEnum):
    """文書種別。

    単一テーブル+種別列は統合モデル採否が未確定のための仮置き。
    値の追加はここに列挙値を足し、CHECK制約を張り替えるマイグレーションを作成する。
    """

    QUOTE = "quote"
    ORDER_PROJECT = "order_project"
    ORDER_ROUTE = "order_route"

    @property
    def customer_shareable(self) -> bool:
        """顧客向け閲覧URLを発行できる種別か（VWR-04。ADR-0002参照）。"""
        return self in _CUSTOMER_SHAREABLE


# 顧客開示URLの発行を許可する種別（注文書は発行禁止=VWR-04）
_CUSTOMER_SHAREABLE = frozenset({DocumentType.QUOTE})


class Document(Base):
    """文書メタデータ。文書IDは呼出側採番（COM-01）で、SaaS内では採番しない。"""

    __tablename__ = "documents"
    __table_args__ = (
        CheckConstraint(
            "document_type IN ('quote', 'order_project', 'order_route')",
            name="ck_documents_document_type",
        ),
    )

    document_id: Mapped[str] = mapped_column(String(255), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(255))
    document_type: Mapped[str] = mapped_column(String(50))
    blob_ref: Mapped[str] = mapped_column(String(1024))
    content_sha256: Mapped[str] = mapped_column(String(64))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class ViewToken(Base):
    """閲覧URLトークン（VWR-02）。

    トークン平文は保存せずSHA-256ハッシュのみ保持する（DB漏洩時もURL再構成不可）。
    失効は revoked の行更新（追記型の実行ログと異なり、状態変更が仕様）。
    """

    __tablename__ = "view_tokens"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    document_id: Mapped[str] = mapped_column(
        String(255), ForeignKey("documents.document_id")
    )
    issued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


class ViewAccessFailure(Base):
    """閲覧URLの失敗試行記録（総当り検知用）。"""

    __tablename__ = "view_access_failures"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_fragment: Mapped[str] = mapped_column(String(8))
    client_ip: Mapped[str] = mapped_column(String(64))
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
