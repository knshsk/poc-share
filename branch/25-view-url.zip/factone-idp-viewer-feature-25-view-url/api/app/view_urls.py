"""閲覧URL（VWR-02）: 発行・一覧・失効と、トークンによる無認証閲覧。

- トークンは256bit URL-safe乱数。DBにはSHA-256ハッシュのみ保存（平文はログにも残さない）
- 無効トークン（不存在・期限切れ・失効）は一律404（存在推測を防ぐ）+失敗記録
- 顧客共有可否は文書種別の属性で判定（ADR-0002）
"""

import hashlib
import secrets
import time
import uuid
from collections import defaultdict, deque
from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth import CurrentUser
from app.blob import BlobStorage
from app.config import Settings
from app.db import get_db_session
from app.documents import PageInfo, PagesResponse
from app.models import Document, DocumentType, ViewAccessFailure, ViewToken
from app.pdf_render import PdfProcessingError, PdfRenderer

router = APIRouter()


class FailureRateLimiter:
    """無効トークン試行のIP単位レート制限（固定窓・インメモリ。PoC単一インスタンス前提）。"""

    def __init__(self, max_failures: int, window_seconds: int) -> None:
        self._max_failures = max_failures
        self._window_seconds = window_seconds
        self._failures: dict[str, deque[float]] = defaultdict(deque)

    def _prune(self, ip: str, now: float) -> None:
        window = self._failures[ip]
        while window and now - window[0] > self._window_seconds:
            window.popleft()

    def is_blocked(self, ip: str) -> bool:
        now = time.monotonic()
        self._prune(ip, now)
        return len(self._failures[ip]) >= self._max_failures

    def record_failure(self, ip: str) -> None:
        now = time.monotonic()
        self._prune(ip, now)
        self._failures[ip].append(now)


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class ViewUrlIssueRequest(BaseModel):
    expires_at: datetime | None = None


class ViewUrlIssueResponse(BaseModel):
    id: uuid.UUID
    view_path: str
    expires_at: datetime


class ViewUrlSummary(BaseModel):
    id: uuid.UUID
    issued_at: datetime
    expires_at: datetime
    revoked: bool


@router.post(
    "/api/documents/{document_id}/view-urls",
    response_model=ViewUrlIssueResponse,
    status_code=201,
)
def issue_view_url(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    payload: ViewUrlIssueRequest | None = None,
) -> ViewUrlIssueResponse:
    settings: Settings = request.app.state.settings
    document = session.get(Document, document_id)
    if document is None or document.tenant_id != settings.tenant_id:
        raise HTTPException(status_code=404, detail="Document not found")
    if not DocumentType(document.document_type).customer_shareable:
        raise HTTPException(
            status_code=403,
            detail="View URLs cannot be issued for this document type",
        )

    token = secrets.token_urlsafe(32)
    expires_at = (payload.expires_at if payload else None) or datetime.now(
        UTC
    ) + timedelta(days=settings.view_url_default_ttl_days)
    view_token = ViewToken(
        token_hash=_hash_token(token),
        document_id=document.document_id,
        expires_at=expires_at,
    )
    session.add(view_token)
    session.commit()
    return ViewUrlIssueResponse(
        id=view_token.id, view_path=f"/view/{token}", expires_at=view_token.expires_at
    )


@router.get(
    "/api/documents/{document_id}/view-urls", response_model=list[ViewUrlSummary]
)
def list_view_urls(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> list[ViewUrlSummary]:
    settings: Settings = request.app.state.settings
    document = session.get(Document, document_id)
    if document is None or document.tenant_id != settings.tenant_id:
        raise HTTPException(status_code=404, detail="Document not found")
    tokens = session.scalars(
        select(ViewToken).where(ViewToken.document_id == document_id)
    ).all()
    return [
        ViewUrlSummary(
            id=row.id,
            issued_at=row.issued_at,
            expires_at=row.expires_at,
            revoked=row.revoked,
        )
        for row in tokens
    ]


@router.post("/api/view-urls/{view_url_id}/revoke")
def revoke_view_url(
    _user: CurrentUser,
    view_url_id: uuid.UUID,
    session: Annotated[Session, Depends(get_db_session)],
) -> dict[str, str]:
    view_token = session.get(ViewToken, view_url_id)
    if view_token is None:
        raise HTTPException(status_code=404, detail="View URL not found")
    view_token.revoked = True
    session.commit()
    return {"status": "revoked"}


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _resolve_token(
    request: Request, session: Session, token: str
) -> tuple[Document, bytes]:
    """トークンを検証し、対象文書とPDFを返す。無効なら一律404。"""
    limiter: FailureRateLimiter = request.app.state.view_rate_limiter
    ip = _client_ip(request)
    if limiter.is_blocked(ip):
        raise HTTPException(status_code=429, detail="Too many requests")

    view_token = session.scalars(
        select(ViewToken).where(ViewToken.token_hash == _hash_token(token))
    ).one_or_none()
    valid = (
        view_token is not None
        and not view_token.revoked
        and view_token.expires_at > datetime.now(UTC)
    )
    if not valid or view_token is None:
        limiter.record_failure(ip)
        session.add(ViewAccessFailure(token_fragment=token[:8], client_ip=ip))
        session.commit()
        raise HTTPException(status_code=404, detail="Not found")

    document = session.get(Document, view_token.document_id)
    if document is None:
        raise HTTPException(status_code=404, detail="Not found")
    blob_storage: BlobStorage = request.app.state.blob_storage
    return document, blob_storage.load(document.blob_ref)


@router.get("/view/{token}/pages", response_model=PagesResponse)
def public_pages(
    request: Request,
    token: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> PagesResponse:
    _document, pdf = _resolve_token(request, session, token)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        sizes = renderer.get_page_sizes(pdf)
    except PdfProcessingError as exc:
        raise HTTPException(status_code=500, detail="Failed to process PDF") from exc
    return PagesResponse(
        page_count=len(sizes),
        pages=[PageInfo(width=size.width, height=size.height) for size in sizes],
    )


@router.get("/view/{token}/pages/{page}/image")
def public_page_image(
    request: Request,
    token: str,
    page: int,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    _document, pdf = _resolve_token(request, session, token)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        png = renderer.render_page_png(pdf, page - 1)
    except IndexError:
        raise HTTPException(status_code=404, detail="Page not found") from None
    except PdfProcessingError as exc:
        raise HTTPException(status_code=500, detail="Failed to process PDF") from exc
    return Response(content=png, media_type="image/png")


@router.get("/view/{token}/pdf")
def public_pdf(
    request: Request,
    token: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document, pdf = _resolve_token(request, session, token)
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{document.document_id}.pdf"'
        },
    )
