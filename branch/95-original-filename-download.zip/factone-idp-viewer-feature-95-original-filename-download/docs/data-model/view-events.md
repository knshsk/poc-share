# 閲覧・DLイベント（view_events）

閲覧URL経由の閲覧・ダウンロード記録。追記型（更新・削除しない）。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | |
| document_id | varchar(255) | NOT NULL・FK(documents) | 対象文書。**案件IDは保持しない**（外部連携側が文書IDから解決） |
| view_token_id | uuid | NOT NULL・FK(view_tokens) | どの閲覧URL経由か（発行台帳との紐付け） |
| event_type | varchar(20) | NOT NULL・CHECK | `view`（文書を開いた）/ `download`（原本DL）/ `page_view`（ページ表示） |
| occurred_at | timestamptz | NOT NULL | 発生日時（配信時にサーバで記録） |
| client_ip | varchar(64) | NOT NULL | 端末情報 |
| user_agent | varchar(512) | NOT NULL | 端末情報 |
| page | integer | NULL・CHECK | 表示されたページ番号（1始まり）。`page_view` のみ値を持ち、`view` / `download` はNULL |

- **UNIQUE(document_id, occurred_at, event_type)** — 冪等キー（文書ID+イベント発生日時）のDB制約。衝突時は挿入スキップ（配信は成功させ、記録の重複だけ防ぐ）。`page` はキーに含めない（NULLを含む複合UNIQUEは `view` / `download` の冪等性を壊すため。同一文書・同一マイクロ秒の `page_view` 衝突は事実上発生しない）
- **CHECK ck_view_events_page: `(event_type = 'page_view') = (page IS NOT NULL)`** — 種別と `page` 列の整合をDB制約で担保する

## 記録ポイント

APIプロキシ配信が唯一の関門である決定に基づき、公開閲覧経路の配信成功時にのみ記録する。

| 経路 | イベント |
| --- | --- |
| `GET /view/{token}/pages` 成功 | view（文書を開いた=1閲覧） |
| `GET /view/{token}/pages/{page}/image` 成功 | page_view（`page` 付き。Viewerは表示領域に入ったページだけ画像取得するため、取得成功＝ページ表示。[ADR-0015](../adr/0015-page-view-event.md)） |
| `GET /view/{token}/pdf` 成功 | download |
| 無効トークン・存在しないページ番号のアクセス | 記録しない（無効トークンは失敗記録 `view_access_failures` 側に残る） |
| 社内（認証済み）表示 | **記録しない**（ルート型注文書を含め社内閲覧イベントは履歴化しない。ADR-0012） |

「ページを表示した」の定義: ページが表示領域に1pxでも入り画像が取得されたこと。スクロール通過や部分表示も1閲覧として数え、滞在時間は測らない。同一表示中の再表示は再取得しないため再記録されない。リロード・再訪は新たに記録される。「何ページ目まで確認したか」は連携側で `page_view` の `max(page)` を集計して得る。

## 取得（外部連携IF-04）

`GET /api/view-events?since=<日時>`（JWT必須）が外部連携（Power Automate等）向けの正式契約（[ADR-0013](../adr/0013-view-event-delta-feed.md)）。

- 取得方式: REST pull・文書横断の差分取得。日次バッチで連携側が前回取得の最終 `occurred_at` を `since` に指定する
- `since` は境界包含（`occurred_at >= since`）。境界上の重複はDataDelivery登録の冪等キー（文書ID＋イベント発生日時）で連携側が排除する。`since` 省略時は全件
- 応答: 全文書のイベントを `occurred_at` 昇順（同時刻は `id` 順）で返す。ページネーションなし（PoCの日次・単一テナント規模を前提。件数増時はカーソル方式へ見直し）
- 応答項目: `id` / `document_id` / `event_type` / `occurred_at` / `client_ip` / `user_agent` / `page`。`page` は `page_view` のみ値を持ち、他は `null`。`view_token_id` は内部管理値のため応答に含めない。文書IDから案件IDへの解決は連携側の責務
- `page_view` は無条件にフィードへ含まれる（種別による除外フィルタはない）
- 認証: Keycloakの M2M クライアント（client credentials）で取得したアクセストークンを利用可
- `since` が日時として解釈できない場合は422、イベント未発生の場合は空リスト

補足: `GET /api/documents/{document_id}/events` は文書ID単位の個別照会用として存続する（応答項目は `document_id` を除く上記と同一）。
