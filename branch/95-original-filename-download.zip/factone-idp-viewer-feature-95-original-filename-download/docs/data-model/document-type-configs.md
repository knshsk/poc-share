# 文書種別設定（document_type_configs）

文書種別のテナント別設定。Query Fieldsのキー・ラベル・型と、閲覧URL発行可否を種別ごとに保持する（ADR-0014）。設定CRUD API（`/api/config/document-types`）で管理する。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 管理ID |
| tenant_id | varchar(255) | NOT NULL | テナント識別子。**仮置き: 認可設計確定まで固定値 `default`** |
| type_code | varchar(50) | NOT NULL | 文書種別コード（`^[a-z0-9_]{1,50}$`）。`documents.document_type` が参照する |
| display_name | varchar(100) | NOT NULL | 種別表示名（例: 見積書） |
| shareable | bool | NOT NULL | 閲覧URL発行可否 |
| fields | jsonb | NOT NULL | 抽出フィールド定義の配列（下記。順序保持） |
| created_at | timestamptz | NOT NULL・default now() | 行作成日時 |
| updated_at | timestamptz | NOT NULL・default now() | 行更新日時 |

- UNIQUE(`tenant_id`, `type_code`)
- `documents.document_type` とのFKは張らない（種別コードは文字列参照。整合はアプリ層で担保）

## fields 要素

| キー | 型 | 説明 |
| --- | --- | --- |
| key | string | Query Fieldsで使用するキー（`^[a-z0-9_]{1,50}$`。種別内一意） |
| label | string | 表示ラベル（例: 顧客コード） |
| type | string | `string` / `number` / `date`。IDP抽出結果の正規化を駆動する |
| visible | bool | Viewerの読み取り結果に表示するか。省略時 `true`。`false` でも抽出・保存・API返却は行う（Viewer表示のみ除外） |

- 読み取りは (tenant_id, type_code) の1行取得のみ。JSONB内部への検索は行わない（GINインデックス不要）
- `visible` は表示時にViewerが現在の設定を参照して判定する（実行時スナップショットではない）。設定変更は過去の実行結果の表示にも反映される。送信先／送信元のように対で指定すると抽出精度が上がるが表示不要な項目（例: 受領注文書の自社名）を想定

## 整合性ルール

- 使用中の種別（`documents` に参照行あり）の削除は409で拒否
- フィールド定義の更新は自由。過去のIDP実行ログ（idp_runs）は実行時点の結果をJSONBで保持済みのため影響を受けない
- 文書登録時、テナント設定に未登録の種別は422で拒否
- IDP実行時、文書の種別が設定に未登録の場合は409（削除保護があるため通常発生しない防御的措置）

## シードデータ

マイグレーションで既存3種別を `tenant_id="default"` に投入する。

| type_code | display_name | shareable |
| --- | --- | --- |
| quote | 見積書 | true |
| order_project | 注文書（プロジェクト） | false |
| order_route | 注文書（ルート） | false |

`shareable` のデフォルトはADR-0002の判断（注文書は発行禁止）を引き継ぐ。
