# 業務フロー

FactONEが対象とする業務フローに関するドキュメント。

## 関係者定義

- 【案】: 案件型固有の内容
- 【ル】: ルート型固有の内容
- 【共】: 案件型、ルート型共通の内容

| #   | レーン名 | プール | 層区分 | 責務（担うこと） | 非責務（担わないこと＝境界） |
| --- | -------- | ------ | ------ | ---------------- | ---------------------------- |
| 1 | 得意先 | 社外 | 社外 | 【案】引合・仕様を提示する／見積PDFを閲覧・DLする<br/>【共】注文書を発行・送付する<br/>【ル】繰返し発注 | 社内処理には関与しない（外部主体＝ブラックボックスとして内部プロセスは展開しない） |
| 2 | 営業（自社） | 自社 | 人 | 【案】商談を登録し、見積もりを依頼・開示操作する<br/>【共】注文書PDFを受領し連携フォルダへ配置する／SAP承認画面で確認・修正・承認する（＝目視補正）／受注を登録する<br/>【ル】MGRアラート（D5/V5）を確認しフォロー方針を判断する／EWMAのα値・D/V閾値を改定する | キーの採番・解決・付与は行わない（→ PowerAutomate）<br/>型区分判定は行わない（→ PowerAutomate）<br/>※本来は「営業担当」と「営業マネージャー」の別役割だが、PoCでは本レーンに集約する |　　
| 3 | D365 CRM | 自社 | 既存システム | 【案】引合・商談・活動履歴・案件IDを保持する／見積の閲覧用URLを得意先へメール送達し、開示日時を活動履歴に記録する（送達の正本＝営業活動履歴） | 受注・発注実績は保持しない<br/>【ル】未使用（見積工程がないため） |　　
| 4 | 見積システム | 自社 | 既存システム | 【案】見積PDFを出力する／見積IDを自ら採番する | 改修負荷・APIなし＝自動連携機能を持たない（出力ファイルは人手で連携フォルダへ配置）<br/>【ル】未使用（見積工程がないため） |　　
| 5 | SAP ERP | 自社 | 既存システム | 受注以降の基幹として受注オーダを保持し、未承認→承認・確定の状態を管理する<br/>【案】受注確定時にWBSを採番する<br/>【ル】受注確定時に在庫引当・出荷指示を行い、分納時は納入日程行を生成する | WBS採番はルート型では行わない<br/>得意先へ返す帳票（請書・納期回答書）は発行しない<br/>請求・売上計上は扱わない |　　
| 6 | WalkMe<br/>（図中表記: WalkMe【CRM】／WalkMe【SAP】） | 自社 | OX層 | 既存画面（CRM入力画面／SAP承認画面）にオーバレイし、案件ID・ルートID・文書IDを自動セットする／これらの必須化・形式検査を担う（本機能はWalkMeに一本化する） | 採番・生成のロジックを持たない（PowerAutomateを同期呼び出しして受領するのみ） |　　
| 7 | **Viewer** | 自社 | OX層／**商品化対象SaaS**（画面） |【案】見積の閲覧用URLを発行し、閲覧・DLを記録する<br/>【共】注文書を社内表示し、IDP実行と結果表示を担う（※1）  | 注文書は顧客へ開示しない（閲覧用URLを発行しない）<br/>案件ID・ルートIDを受領・保持しない（顧客の業務体系に属するキーのため）<br/>文書IDを自ら解決・採番しない（呼出側からパラメータで受領するのみ） |　　
| 8 | **IDP** | 自社 | OX層／**商品化対象SaaS**（API） | PDFの文字化・項目化を行い、確信度を返却する（※1） | 案件ID・ルートIDの解決・付与を行わない（→ PowerAutomate）<br/>顧客固有の名寄せロジックを持たない<br/>確信度による自動・手動の振り分け判定を行わない |　　
| 9 | PowerAutomate | 自社 | 連携層(EAI) | 採番マスタを保持し、案件ID・ルートID・文書IDを採番・解決・検証・付与する<br/>型区分判定を行い、案件型／ルート型の経路を振り分ける<br/>SAPへ受注オーダを転記する（＝未承認登録）<br/>イベント起動＋日次バッチで各レーン間の連携を実行する | 見積ID（見積システム）・WBS・受注ID（SAP）は管轄外<br/>独自のエラー記録・通知・退避処理は行わない |　　
| 10 | DataDelivery（DD） | 自社 | DX層 | 実績情報を統一管理する<br/>【案】案件ID単位で商談・活動・閲覧ログ・見積・受注実績を蓄積する／月末時点の案件の状態・受注確度と売上予定金額を凍結し、2時点比較と成立させる（D13・D14）<br/>【ル】ルートID単位で発注実績を時系列蓄積する／予測結果を生成日別に保管し、計上月別スナップショット・月次スナップショットの凍結を担う（予測の正本＝DD） | 予測の算出は行わない（算出 → Databricks／保管・凍結 → DataDelivery）<br/>EDI由来の実績は取りこまない |　　
| 11 | Databricks・ダッシュボード | 自社 | DX層 | 【案】REスコア算出・前月差分の差異分類・受注確度×REスコアによる見込み算出<br/>【ル】EWMA需要予測・D/V格付け（CV方式）・予測精度の検証（誤差率）・MGRアラート表示<br/>【統】統合フォーキャスト算出・ドリルダウン・増減理由の提示 | 打ち手（安全在庫・数量バッファ等）の実行・在庫施策への反映は行わない<br/>プッシュ通知は行わない（ダッシュボード表示まで）<br/>D・Vを掛け合わせず、予測値・確度へ自動反映しない |　　

※1 Viewer（レーン7／画面）とIDP（レーン8／API）は同一のマルチテナントSaaSの2つの提供形態。Viewer画面の「IDP実行」ボタンから同一SaaS内のIDPを呼び出し、項目化結果を画面に表示する。

## K1: 引合・商談

```mermaid
sequenceDiagram
    participant C as 得意先（社外）
    participant S as 営業（自社/人）
    participant W as WalkMe【CRM】（OX層）
    participant CRM as D365 CRM（既存システム）
    participant PA as Power Automate（連携層/EAI）
    participant DD as DataDelivery（DD/DX層）

    Note over C,DD: K1 引合・商談（案件型）／処理開始

    C->>S: K1-1 引合・仕様を提示する
    Note over C,S: メール・電話など

    S->>W: K1-2 D365 CRMに引合／商談を登録し、受注確度を入力する〔業務行為〕
    Note over S,W: 画面操作

    W->>PA: K1-3 【CRM】引合登録時に案件IDの採番を要求する
    Note over W,PA: REST API（要求）

    PA-->>W: K1-4 案件IDを新規採番し、呼出元へ返却する
    Note over PA,W: REST API（応答）

    W->>CRM: K1-5 【CRM】CRM入力画面に採番された案件IDを設定する
    Note over W,CRM: 画面操作（オーバレイ）

    CRM->>CRM: K1-6 案件ID付きの商談・活動履歴を保持する
    Note over CRM: 処理終了（リアルタイム系）

    Note over CRM,PA: 処理開始：日次バッチ
    CRM->>PA: K1-7 商談・活動データを取得する
    Note over CRM,PA: OData
    PA->>DD: DBコネクタ?
    DD->>DD: K1-8 案件ID単位で商談・活動データを蓄積する
    Note over DD: 処理終了（日次バッチ系）
```

## K2: 原価積算・見積

```mermaid
sequenceDiagram
    participant EIGYO as 営業（自社）<br/>（人）
    participant IDP as IDP<br/>（OX層／商品化対象SaaS（API））
    participant MITSU as 見積システム<br/>（既存システム）
    participant PA as Power Automate<br/>（連携層（EAI））
    participant DD as DataDelivery（DD）<br/>（DX層）

    Note over EIGYO: 処理開始
    EIGYO->>MITSU: K2-1 見積システムで原価積算・見積書を作成する（画面操作（人））
    Note over MITSU: K2-2 原価積算結果・見積データを保持する
    MITSU-->>EIGYO: K2-3 見積PDFを出力する<br/>▼ファイル出力（手動DL）※API無し
    EIGYO->>PA: K2-4 出力ファイル（見積PDF）を連携フォルダへ人手で配置する<br/>▼ファイル配置
    Note over PA: K2-5 連携フォルダを監視し、ファイル配置を検知、1ファイルごとに文書IDを発行する
    PA->>IDP: K2-6 PDFごとに見積PDFを文字化（項目化）（REST API 要求）
    IDP-->>PA: K2-6 文字データを取得する（REST API 応答）
    Note over PA: K2-7 見積PDFに該当する案件IDを解決する
    PA->>DD: K2-8 IDP処理完了後、データをDDへ登録する（DBコネクタ）
    Note over DD: K2-9 見積PDF本体と項目データを保管する
    Note over PA: K2-10 見積PDFを保管フォルダに移動する
    Note over DD: 処理終了
    Note over PA: ［8/26確認事項］WalkMe担当者確認（CRMとのデータ連携）：Power Automate⇒CRMでデータを入れる？紐づくIDだけ？
```

## K3: 見積提示・フォロー

```mermaid
sequenceDiagram
    participant CUS as 得意先（社外）
    participant SAL as 営業（自社）（人）
    participant WM as WalkMe【CRM】（OX層）
    participant VW as Viewer（OX層／商品化対象SaaS（画面））
    participant CRM as D365 CRM（既存システム）
    participant PA as Power Automate（連携層（EAI））
    participant DD as DataDelivery（DD）（DX層）
    participant DBX as Databricks・ダッシュボード（DX層）

    Note over SAL: 処理開始
    SAL->>WM: K3-1 D365 CRMからWalkMe経由でViewerを起動し<br/>見積PDFを開示する
    WM->>VW: K3-2 【CRM】CRM画面からViewerを起動し文書IDを受け渡す<br/>▽REST API?/画面操作?
    Note over WM,VW: 確認事項：WalkMe⇒Viewerに閲覧URL要求する手段<br/>案1:REST APIで発行／案2:Viewer画面起動・ボタンで発行⇒WalkMe読取り
    VW-->>SAL: K3-3 文書IDに紐づく見積PDFの閲覧用URLを発行する<br/>▽Viewer API（REST）
    SAL->>CUS: K3-4 見積PDFの閲覧用URLを得意先へメール送信し、<br/>送信記録を活動履歴に登録する ▽メール
    SAL->>CRM: K3-4 送信記録を活動履歴に登録する ▽画面操作
    Note over CRM: 確認事項：CRMのメール送信について<br/>閲覧URLをWalkMeを使って画面反映が必要?
    CUS->>VW: K3-5 Viewerを使って見積PDFを閲覧・ダウンロードする<br/>▽HTTPS/画面操作
    Note over VW: K3-6 閲覧・DLをイベントとして記録する
    SAL->>CRM: K3-7 顧客フォローの活動・日報をCRMに登録する ▽画面操作
    Note over CRM: K3-8 案件ID付きの活動履歴・日報DATAを保持する

    Note over PA: 処理開始：日次バッチ
    VW-->>PA: 閲覧ログ（閲覧・DL）差分取得 ▽REST API
    PA->>DD: K3-9 閲覧ログ（閲覧・DL）を取得し、文書IDから案件IDを<br/>解決したうえでDDへ登録する
    CRM-->>PA: 日報DATA・活動履歴 取得 ▽OData?/DBコネクタ?
    PA->>DD: K3-10 日報DATA・活動履歴を取得しDDへ登録する
    Note over DD: K3-11 閲覧ログ・日報を案件ID単位で蓄積する

    Note over DBX: 処理開始：画面アクセス
    DD-->>DBX: 案件型顧客エンゲージメント履歴 ▽DBコネクタ?
    DBX->>SAL: K3-12 案件型顧客エンゲージメント履歴をREスコア（5段階）化し<br/>営業入力の受注確度（A～D）と対比する
    Note over SAL: K3-13 反応のある案件を優先フォローし<br/>失注リスクを早期に検知する
    Note over SAL: 処理終了
```

## K4: 受注前処理_共通

```mermaid
sequenceDiagram
    autonumber
    participant C as 得意先<br/>（社外）
    participant S as 営業（自社）<br/>（人）
    participant PA as Power Automate<br/>（連携層（EAI））
    participant IDP as IDP<br/>（OX層／商品化対象SaaS（API））

    Note over C: K4-1 注文書PDFを発行・送付する
    C->>S: ▼注文書PDF（メール・郵送・FAX）
    Note over S: K4-2 得意先から注文書PDFを受領する ▼受領した注文書PDF
    Note over S: K4-3 受領した注文書PDFを連携フォルダへ配置する
    S->>PA: ▼連携フォルダ格納ファイル（注文書PDF）（ファイル配置）
    Note over PA: K4-4 連携フォルダを監視し、ファイル配置を検知。<br/>1ファイル＝1文書IDで文書IDを発行する ▼文書ID
    PA->>IDP: K4-5 IDPをAPI呼出して注文書PDFをデータ項目化する<br/>▼IDP呼出要求（REST API 要求）
    Note over IDP: K4-6 注文書PDFをデータ項目化する
    IDP-->>PA: ▼注文項目データ（REST API 応答）
    Note over PA: K4-10 注文書PDFを保管フォルダに移動する
    Note over PA: K4-7 注文書に紐づく見積データを検索し、有無で型区分を判定する<br/>（見積あり＝案件型／見積なし＝ルート型）▼型区分判定結果
    alt 型区分判定結果＝案件型
        Note over PA: K4-8 商談・見積情報から案件IDを引き当てる<br/>▼案件ID → 以降はK5受注登録へ
    else 型区分判定結果＝ルート型
        Note over PA: K4-9 得意先コード×品目コードを名寄せキーとして、<br/>ルートIDを get-or-create で採番する<br/>▼ルートID → 以降はR1受注登録へ
    end
    Note over PA,IDP: ロジックメモ：案件型・ルート型問わず、採番前にSAPまたはCRMへ<br/>コードの実在を照会して確認が必要（IDP読取り精度≠100％のため）。<br/>注文に紐づく見積データの検索方法詳細は要相談。
```

## K5: 受注登録

```mermaid
sequenceDiagram
    autonumber
    actor Sales as 営業（自社）
    participant WalkMe as WalkMe【SAP】
    participant Viewer as Viewer
    participant IDP as IDP
    participant SAP as SAP ERP
    participant PA as Power Automate
    participant DD as DataDelivery（DD）

    Note over PA: 処理開始：「K4受注前処理_共通」のフローを実施<br/>（注文書受領～案件ID引き当てまで）
    PA->>SAP: K5-1 案件IDを用い、SAPへ受注オーダを転記する<br/>▼ 引き当て済み案件ID／案件ID付き登録データ
    Note over SAP: K5-2 【未承認登録】Power Automateから転記された受注オーダを<br/>承認ワークフローの未承認ステータスで登録する〔前工程完了〕<br/>▼ 受注データ（未承認）
    Note over SAP: 処理終了（承認待ち）

    Note over Sales: 処理開始：営業がSAP画面にアクセス
    WalkMe->>Sales: K5-3 【SAP】SAPの承認画面にオーバーレイし、案件ID・文書IDを表示<br/>▼ 入力値（案件ID・文書ID）
    Sales->>SAP: K5-4 SAPのワークフローで未承認の受注データを確認し、IDPの読取結果に<br/>誤りがあれば修正したうえで承認して確定する〔業務行為〕<br/>▼ 承認済み受注データ（確定）
    opt 承認時／必要な場合のみ（原本照合・再項目化）
        Sales->>Viewer: K5-5 注文書PDFを表示し原本照合を支援。疑義がある場合は画面からIDPを実行<br/>▼ 表示画面／再項目化結果
        Viewer->>IDP: K5-6 IDPを実行し、文字データを読み取る（REST API）
        IDP->>WalkMe: K5-7 【SAP】IDP結果をSAP画面に反映する
        WalkMe-->>Sales: 反映結果（SAP画面）
    end
    Note over SAP: K5-8 【承認後の確定】承認を受けて受注を確定する
    Note over SAP: 処理終了

    Note over PA: 処理開始：日次バッチ
    SAP->>PA: K5-9 SAP受注実績を取得しDDへ連携登録する（OData）<br/>▼ 案件ID別 受注実績データ
    PA->>DD: K5-10 注文書PDF・注文DATA・受注データを案件ID単位で保管する
    Note over PA,DD: 参考：WBS情報を持っている場合、ここでSAPへWBS情報を連携する<br/>※今回は対象外
    Note over DD: 処理終了
```

## R1: 受注登録

```mermaid
sequenceDiagram
    autonumber
    participant EI as 営業（自社）<br/>（人）
    participant WM as WalkMe【SAP】<br/>（OX層）
    participant VW as Viewer<br/>（OX層/SaaS画面）
    participant IDP as IDP<br/>（OX層/SaaS API）
    participant SAP as SAP ERP<br/>（既存システム）
    participant PA as Power Automate<br/>（連携層/EAI）
    participant DD as DataDelivery（DD）<br/>（DX層）

    rect rgb(235, 244, 255)
    Note over PA,SAP: 処理開始：「K4受注前処理_共通」のフローを実施<br/>（注文書受領～ルートID発行まで）
    PA->>SAP: R1-1 型区分判定でルート型と判定された注文書について、<br/>SAPへ受注オーダを転記する<br/>▼ ルートID付き登録データ
    Note over SAP: R1-2 Power Automateから転記された<br/>受注オーダを登録する<br/>▼ 受注データ（未承認）
    Note over PA,SAP: 処理終了
    end

    rect rgb(235, 255, 240)
    Note over EI: 処理開始：営業がSAP画面にアクセス
    WM->>EI: R1-3 【SAP】SAPの承認画面にオーバーレイし、<br/>ルートID・文書IDを表示する<br/>▼ ルートID付き入力値（承認画面）
    Note over EI: R1-4 SAPのワークフローで未承認の受注データを確認し、<br/>IDPの読取結果に誤りがあれば修正を行ったうえで<br/>承認して確定する<br/>▼ 承認済み受注データ

    opt 項目化結果に疑義がある場合
    EI->>VW: R1-5 【承認時/必要な場合のみ】注文書PDFを社内表示し<br/>原本照合を支援する。項目化結果に疑義がある場合は<br/>画面からIDPを再実行する<br/>▼ 表示画面（文書ID紐づけ済）/再項目化結果
    VW->>IDP: R1-6 【必要な場合のみ】IDPを実行し、<br/>文字データを読み取る（REST API）
    IDP->>WM: R1-7 【SAP/必要な場合のみ】IDP結果を<br/>SAP画面に反映する（画面操作）
    WM-->>EI: 再項目化結果を承認画面へ反映
    end

    EI->>SAP: R1-8 【承認後の確定】承認を受けて受注を確定する
    Note over EI,SAP: 処理終了
    end

    rect rgb(255, 248, 235)
    Note over SAP,DD: 処理開始：日次バッチ
    SAP->>DD: R1-9 SAP受注実績を取得しDDへ連携する（OData）<br/>▼ SAP受注データ
    Note over DD: R1-10 ルートID（得意先×品目）単位で発注実績<br/>（発注日・数量・間隔）を時系列で蓄積する
    Note over DD: 処理終了
    end
```

## F1: 案件型の見込み算出

```mermaid
sequenceDiagram
    participant DD as DataDelivery（DD）<br/>（DX層）
    participant DB as Databricks・ダッシュボード<br/>（DX層）

    Note over DD: 処理開始：月次バッチ
    DD->>DD: F1-1 月末時点の案件情報を確定データとして保存（凍結）する
    DD->>DB: DBコネクタ？<br/>※担当者検討中（9/1現在回答待ち）
    DB->>DB: F1-2 前月差分を失注・スリップ・増減・新規に自動分類する
    DB->>DB: F1-3 受注確度×REスコアから案件型の受注・売上見込みを算出する
    DB->>DD: F1-4 案件型見込みを案件×対象月の粒度で保管する
    Note over DB: 処理終了
```

## F2: 需要予測

```mermaid
sequenceDiagram
    autonumber
    participant DB as Databricks・ダッシュボード<br/>（DX層）
    participant DD as DataDelivery（DD）<br/>（DX層）

    Note over DB,DD: 補足：R1のDD蓄積の後

    Note over DB,DD: 【予測系】処理開始：日次バッチ
    DB->>DB: F2-1 [予測系]ルートIDごとに発注量のEWMAを算出する
    Note right of DB: ▼ 発注量EWMA
    DB->>DB: F2-2 [予測系]ルートIDごとに発注サイクル（平均発注間隔）のEWMAを算出する
    Note right of DB: ▼ 発注サイクルEWMA
    DB->>DD: F2-8 需要パターンへ z_t・p_t・単価・α値の最新値を保管する（DBコネクタ経由）
    Note right of DD: ▼ 需要パターン（最新値）
    DB->>DB: F2-3 [予測系]EWMA（発注量／発注サイクル、α値で加重）から次回の発注時期・数量を予測する
    Note right of DB: ▼ 次回発注予測（時期・数量）
    DB->>DD: F2-4 [予測系]予測結果を生成日付きで需要予測へ登録する
    Note right of DD: ▼ 需要予測（生成日別レコード）
    Note over DB,DD: 処理終了

    Note over DB,DD: 【格付け】処理開始：日次バッチ
    DB->>DB: F2-5 [格付け]V：Variable＝発注量のCV（標準偏差÷平均）を算出し5段階（V1〜V5）に格付けする
    Note right of DB: ▼ V評価（1〜5）
    DB->>DB: F2-6 [格付け]D：Delay＝発注サイクル（発注間隔）のCV（標準偏差÷平均）を算出し5段階（D1〜D5）に格付けする
    Note right of DB: ▼ D評価（1〜5）
    DB->>DD: F2-9 D/V格付け履歴へ格付けとCV・標準偏差を閾値バージョン付きで保管する
    Note right of DD: ▼ D/V格付け履歴
    Note over DB,DD: 処理終了

    Note over DB,DD: 【日次モニタ】処理開始：日次バッチ
    DB->>DB: F2-7 [日次モニタ]新規発注の実績値とEWMA期待値の乖離率を算出し、閾値超過分をダッシュボードに当日フラグ表示する
    Note right of DB: ▼ EWMA乖離フラグ（当日）
    Note over DB,DD: 処理終了
```

## F3: 精度検証

```mermaid
sequenceDiagram
    participant DD as DataDelivery（DD）<br/>（DX層）
    participant DB as Databricks・ダッシュボード<br/>（DX層）
    participant Sales as 営業（自社）<br/>（人）

    Note over DD,DB: 処理開始：バッチ
    Note over DD: F3-7 計上月別スナップショットへルート×計上月の金額を保管する<br/>※担当者検討中（9/1現在回答待ち）
    DD-->>DB: DBコネクタ?
    Note over DB: F3-1 実績＋予測を計上月別に集計する。
    Note over DB: F3-2 予測と受注実績の誤差率を検証する
    Note over DB: F3-3 全案件をD×Vの2軸マトリクス上に配置してダッシュボードに表示。D5かつV5（AND条件）に該当するルートIDをMGRアラート対象として強調表示する
    Note over DB: 処理終了

    Note over Sales: 処理開始：ダッシュボードへアクセス
    DB-->>Sales: D×Vマトリクス
    Note over Sales: F3-4 D×Vマトリクスをダッシュボードで確認し、MGRアラート対象（D5かつV5）を案件（スポット）扱い・個別フォロー対象の案件として確認する
    Note over Sales: F3-5 検証結果をもとにEWMAのα値・D/V評価の閾値を調整
    Note over Sales: 処理終了

    Note over DB: 処理開始：月次バッチ
    Note over DB: F3-6 予測結果からルート型の売上見込みを算出する
    Note over DB: 処理終了
```

## F4: 統合販売フォーキャスト

```mermaid
sequenceDiagram
    participant DB as Databricks・ダッシュボード<br/>（DX層）
    participant DD as DataDelivery（DD）<br/>（DX層）
    participant EIGYO as 営業（自社）<br/>（人）

    Note over DB: 処理開始：月次バッチ
    DB->>DB: F4-1 案件型の受注・売上見込みとルート型の売上見込みを<br/>案件ID・ルートID単位で単純合算する
    DB->>DB: F4-2 統合フォーキャストを表示し、型区分別・得意先別・<br/>品目別・案件別にドリルダウンできるようにする
    DB->>DD: 対象月×型区分の集約金額を引き渡す
    DD->>DD: F4-5 月次スナップショットへ対象月×型区分の集約金額を<br/>月次確定値として保管（凍結）する
    DD-->>DB: 凍結済み月次確定値
    DB->>DB: F4-3 差分→案件→注文書→元データへ遡及し、<br/>増減理由（失注・スリップ・増減・新規）を根拠付きで提示する
    Note over DB: 処理終了

    Note over EIGYO: 処理開始：ダッシュボードへアクセス
    EIGYO->>DB: ダッシュボードへアクセス
    DB-->>EIGYO: 統合フォーキャスト／増減理由の根拠データ
    EIGYO->>EIGYO: F4-4 事業部全体の着地見込みと増減理由を説明する
    Note over EIGYO: 処理終了
```