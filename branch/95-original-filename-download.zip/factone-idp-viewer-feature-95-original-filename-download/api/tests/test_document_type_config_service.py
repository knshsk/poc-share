"""文書種別設定の取得サービスのテスト。"""

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from app.services.document_type_config import (
    FieldDef,
    FieldType,
    config_field_defs,
    get_config,
)


def test_get_config_returns_seeded_quote(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields) "
                "VALUES (gen_random_uuid(), 'default', 'quote', '見積書', true, "
                '\'[{"key": "total_amount", "label": "合計金額", "type": "number"}, '
                '{"key": "own_company", "label": "自社名", "type": "string", '
                '"visible": false}]\'::jsonb)'
            )
        )
        conn.commit()
    with Session(engine) as session:
        config = get_config(session, "default", "quote")
        assert config is not None
        assert config.shareable is True
        # visibleは抽出側のFieldDefに含めない（Viewer表示専用。#91）
        assert config_field_defs(config) == (
            FieldDef(key="total_amount", label="合計金額", type=FieldType.NUMBER),
            FieldDef(key="own_company", label="自社名", type=FieldType.STRING),
        )
    engine.dispose()


def test_get_config_returns_none_for_unknown_type(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with Session(engine) as session:
        assert get_config(session, "default", "unknown_type") is None
    engine.dispose()


def test_get_config_is_tenant_scoped(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields) "
                "VALUES (gen_random_uuid(), 'other-tenant', 'quote', '見積書', true, '[]'::jsonb)"
            )
        )
        conn.commit()
    with Session(engine) as session:
        assert get_config(session, "default", "quote") is None
    engine.dispose()
