"""文書種別設定CRUD APIのテスト。"""

import io

from fastapi.testclient import TestClient

VALID_FIELDS = [
    {"key": "invoice_no", "label": "請求書番号", "type": "string"},
    {"key": "billing_amount", "label": "請求金額", "type": "number"},
    {"key": "due_date", "label": "支払期日", "type": "date"},
]
VALID_PAYLOAD = {
    "type_code": "invoice",
    "display_name": "請求書",
    "shareable": True,
    "fields": VALID_FIELDS,
}


class TestList:
    def test_returns_seeded_configs(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/config/document-types")
        assert response.status_code == 200
        body = response.json()
        codes = {c["type_code"] for c in body}
        assert codes == {"quote", "order_project", "order_route"}
        # シードのfieldsはvisible未指定。応答ではtrue補完される（#91）
        assert all(f["visible"] is True for c in body for f in c["fields"])

    def test_requires_auth(self, doc_client: TestClient) -> None:
        response = doc_client.get(
            "/api/config/document-types", headers={"Authorization": "Bearer bad"}
        )
        assert response.status_code == 401


class TestCreate:
    def test_creates_new_config(self, doc_client: TestClient) -> None:
        response = doc_client.post("/api/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 201
        body = response.json()
        assert body["type_code"] == "invoice"
        # visible省略時はtrue補完して応答される（#91）
        assert body["fields"] == [{**f, "visible": True} for f in VALID_FIELDS]

    # visible省略時はtrue補完、false指定は保持して応答されることを確認する（#91）
    def test_visible_defaults_true_and_roundtrips_false(
        self, doc_client: TestClient
    ) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [
                {"key": "invoice_no", "label": "請求書番号", "type": "string"},
                {
                    "key": "own_company",
                    "label": "自社名",
                    "type": "string",
                    "visible": False,
                },
            ],
        }
        response = doc_client.post("/api/config/document-types", json=payload)
        assert response.status_code == 201
        assert [f["visible"] for f in response.json()["fields"]] == [True, False]

        fetched = doc_client.get("/api/config/document-types/invoice")
        assert fetched.status_code == 200
        assert [f["visible"] for f in fetched.json()["fields"]] == [True, False]

    def test_duplicate_type_code_returns_409(self, doc_client: TestClient) -> None:
        assert (
            doc_client.post(
                "/api/config/document-types", json=VALID_PAYLOAD
            ).status_code
            == 201
        )
        response = doc_client.post("/api/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 409

    def test_invalid_type_code_returns_422(self, doc_client: TestClient) -> None:
        payload = {**VALID_PAYLOAD, "type_code": "Invalid-Code"}
        response = doc_client.post("/api/config/document-types", json=payload)
        assert response.status_code == 422

    def test_empty_fields_returns_422(self, doc_client: TestClient) -> None:
        payload = {**VALID_PAYLOAD, "fields": []}
        response = doc_client.post("/api/config/document-types", json=payload)
        assert response.status_code == 422

    def test_duplicate_field_key_returns_422(self, doc_client: TestClient) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [
                {"key": "invoice_no", "label": "請求書番号", "type": "string"},
                {"key": "invoice_no", "label": "重複キー", "type": "string"},
            ],
        }
        response = doc_client.post("/api/config/document-types", json=payload)
        assert response.status_code == 422

    def test_invalid_field_type_returns_422(self, doc_client: TestClient) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [{"key": "invoice_no", "label": "番号", "type": "boolean"}],
        }
        response = doc_client.post("/api/config/document-types", json=payload)
        assert response.status_code == 422


class TestGet:
    def test_returns_single_config(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/config/document-types/quote")
        assert response.status_code == 200
        body = response.json()
        assert body["display_name"] == "見積書"
        assert body["shareable"] is True

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/config/document-types/unknown")
        assert response.status_code == 404


class TestUpdate:
    def test_replaces_config(self, doc_client: TestClient) -> None:
        payload = {
            "display_name": "見積書（改）",
            "shareable": False,
            "fields": [{"key": "document_no", "label": "番号", "type": "string"}],
        }
        response = doc_client.put("/api/config/document-types/quote", json=payload)
        assert response.status_code == 200
        body = response.json()
        assert body["display_name"] == "見積書（改）"
        assert body["shareable"] is False
        assert len(body["fields"]) == 1

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        payload = {
            "display_name": "x",
            "shareable": False,
            "fields": VALID_PAYLOAD["fields"],
        }
        response = doc_client.put("/api/config/document-types/unknown", json=payload)
        assert response.status_code == 404


class TestDelete:
    def test_deletes_unused_config(self, doc_client: TestClient) -> None:
        response = doc_client.delete("/api/config/document-types/order_route")
        assert response.status_code == 204
        assert (
            doc_client.get("/api/config/document-types/order_route").status_code == 404
        )

    def test_config_in_use_returns_409(self, doc_client: TestClient) -> None:
        pdf = io.BytesIO(b"%PDF-1.4 test")
        register = doc_client.post(
            "/api/documents",
            data={"document_id": "cfg-del-1", "document_type": "quote"},
            files={"file": ("doc.pdf", pdf, "application/pdf")},
        )
        assert register.status_code == 201
        response = doc_client.delete("/api/config/document-types/quote")
        assert response.status_code == 409

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.delete("/api/config/document-types/unknown")
        assert response.status_code == 404
