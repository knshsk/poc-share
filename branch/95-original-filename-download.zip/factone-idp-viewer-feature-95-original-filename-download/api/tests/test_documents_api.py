"""文書登録APIの統合テスト（実PostgreSQLコンテナ接続）。

事前に `podman compose up -d postgres` が必要。テスト専用DB（factone_test）を自動作成する。
共有フィクスチャ（doc_client等）は conftest.py を参照。
"""

from typing import Any

from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text

from app.core.auth import StaticKeySource
from app.core.config import Settings
from app.core.db import create_session_factory
from app.main import create_app
from tests.conftest import InMemoryBlobStorage

PDF_BYTES = b"%PDF-1.7 minimal test pdf content"
PDF_BYTES_OTHER = b"%PDF-1.7 different content"


def post_document(
    client: TestClient,
    document_id: str = "doc-001",
    document_type: str = "quote",
    content: bytes = PDF_BYTES,
    filename: str = "test.pdf",
    content_type: str = "application/pdf",
) -> Any:
    return client.post(
        "/api/documents",
        data={"document_id": document_id, "document_type": document_type},
        files={"file": (filename, content, content_type)},
    )


def test_register_new_document_returns_201(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage
) -> None:
    """新規文書の登録が201となり、Blob保存とメタデータ返却が行われることを確認する。"""
    response = post_document(doc_client)

    assert response.status_code == 201
    body = response.json()
    assert body["document_id"] == "doc-001"
    assert body["document_type"] == "quote"
    assert body["tenant_id"] == "default"
    assert "default/doc-001.pdf" in blob_storage.saved


def test_idempotent_resend_returns_200(doc_client: TestClient) -> None:
    """同一文書ID・同一内容の再送が200（冪等）となることを確認する。"""
    first = post_document(doc_client)
    second = post_document(doc_client)

    assert first.status_code == 201
    assert second.status_code == 200
    assert second.json()["document_id"] == "doc-001"


def test_same_id_different_content_returns_409(doc_client: TestClient) -> None:
    """同一文書IDで内容が異なる登録が409となることを確認する。"""
    post_document(doc_client)

    response = post_document(doc_client, content=PDF_BYTES_OTHER)

    assert response.status_code == 409


def test_same_id_different_type_returns_409(doc_client: TestClient) -> None:
    """同一文書ID・同一内容でも文書種別が異なる登録は409となることを確認する。"""
    post_document(doc_client)

    response = post_document(doc_client, document_type="order_project")

    assert response.status_code == 409


def test_non_pdf_content_returns_415(doc_client: TestClient) -> None:
    """PDF以外のファイルが415となることを確認する。"""
    response = post_document(
        doc_client,
        content=b"not a pdf",
        filename="test.txt",
        content_type="text/plain",
    )

    assert response.status_code == 415


def test_invalid_document_type_returns_422(doc_client: TestClient) -> None:
    """不正な文書種別が422となることを確認する。"""
    response = post_document(doc_client, document_type="invalid-type")

    assert response.status_code == 422


def test_register_requires_auth(
    test_database_url: str,
    signing_key: RSAPrivateKey,
    blob_storage: InMemoryBlobStorage,
) -> None:
    """トークンなしの登録が401となることを確認する。"""
    engine = create_engine(test_database_url)
    settings = Settings(_env_file=None, database_url=test_database_url)  # type: ignore[call-arg]
    app = create_app(
        settings=settings,
        key_source=StaticKeySource(signing_key.public_key()),
        session_factory=create_session_factory(engine),
        blob_storage=blob_storage,
    )
    client = TestClient(app)

    response = post_document(client)

    assert response.status_code == 401
    engine.dispose()


def test_config_registered_type_is_accepted(doc_client: TestClient) -> None:
    """CRUDで追加した種別が文書登録に使えることを確認する。"""
    doc_client.post(
        "/api/config/document-types",
        json={
            "type_code": "invoice",
            "display_name": "請求書",
            "shareable": False,
            "fields": [{"key": "invoice_no", "label": "請求書番号", "type": "string"}],
        },
    )
    response = post_document(doc_client, document_type="invoice")
    assert response.status_code == 201
    assert response.json()["document_type"] == "invoice"


def _disposition(client: TestClient, document_id: str) -> str:
    response = client.get(f"/api/documents/{document_id}/pdf")
    assert response.status_code == 200
    return response.headers["content-disposition"]


def test_original_pdf_uses_uploaded_filename(doc_client: TestClient) -> None:
    """原本DLのContent-Dispositionにアップロード時のファイル名（日本語含む）を返す。"""
    post_document(doc_client, document_id="doc-fn", filename="見積書 A.pdf")

    assert _disposition(doc_client, "doc-fn") == (
        'attachment; filename="doc-fn.pdf"; '
        "filename*=UTF-8''%E8%A6%8B%E7%A9%8D%E6%9B%B8%20A.pdf"
    )


def test_original_filename_strips_path_components(doc_client: TestClient) -> None:
    """パス付きファイル名はbasenameのみ保存する（Windows/POSIX区切り両方）。"""
    post_document(doc_client, document_id="doc-path", filename="C:\\dir\\sub/a b.pdf")

    assert _disposition(doc_client, "doc-path").endswith("filename*=UTF-8''a%20b.pdf")


def test_original_filename_not_overwritten_by_resend(doc_client: TestClient) -> None:
    """冪等再送でファイル名が違っても初回のファイル名を維持する。"""
    post_document(doc_client, document_id="doc-re", filename="first.pdf")
    assert (
        post_document(
            doc_client, document_id="doc-re", filename="second.pdf"
        ).status_code
        == 200
    )

    assert _disposition(doc_client, "doc-re").endswith("filename*=UTF-8''first.pdf")


def test_original_pdf_falls_back_to_document_id(
    doc_client: TestClient, test_database_url: str
) -> None:
    """ファイル名未保存の既存文書は従来どおり {document_id}.pdf で返す。"""
    post_document(doc_client, document_id="doc-null")
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(
            text(
                "UPDATE documents SET original_filename = NULL WHERE document_id = 'doc-null'"
            )
        )
    engine.dispose()

    assert _disposition(doc_client, "doc-null") == 'attachment; filename="doc-null.pdf"'
