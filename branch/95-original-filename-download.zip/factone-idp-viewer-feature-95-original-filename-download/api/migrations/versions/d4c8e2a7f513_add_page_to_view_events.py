"""add page to view events

Revision ID: d4c8e2a7f513
Revises: a3d51c7e8b24
Create Date: 2026-09-08 12:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "d4c8e2a7f513"
down_revision: str | None = "a3d51c7e8b24"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("view_events", sa.Column("page", sa.Integer(), nullable=True))
    op.drop_constraint("ck_view_events_event_type", "view_events", type_="check")
    op.create_check_constraint(
        "ck_view_events_event_type",
        "view_events",
        "event_type IN ('view', 'download', 'page_view')",
    )
    op.create_check_constraint(
        "ck_view_events_page",
        "view_events",
        "(event_type = 'page_view') = (page IS NOT NULL)",
    )


def downgrade() -> None:
    # page_view 行は旧CHECK制約に違反するため、制約を戻す前に削除する
    op.execute("DELETE FROM view_events WHERE event_type = 'page_view'")
    op.drop_constraint("ck_view_events_page", "view_events", type_="check")
    op.drop_constraint("ck_view_events_event_type", "view_events", type_="check")
    op.create_check_constraint(
        "ck_view_events_event_type",
        "view_events",
        "event_type IN ('view', 'download')",
    )
    op.drop_column("view_events", "page")
