"""add original_filename to documents

Revision ID: f2a9c7d1e604
Revises: d4c8e2a7f513
Create Date: 2026-09-09 12:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "f2a9c7d1e604"
down_revision: str | None = "d4c8e2a7f513"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # 既存行は NULL（アップロード時のファイル名は再取得不可。DL時は document_id.pdf にフォールバック）
    op.add_column(
        "documents", sa.Column("original_filename", sa.String(255), nullable=True)
    )


def downgrade() -> None:
    op.drop_column("documents", "original_filename")
