"""文書登録API（Power Automate連携の受付部分）。

冪等性: 同一文書ID・同一内容の再送は200、内容不一致は409。
文書IDは呼出側採番で、SaaS内では採番・解決しない。
"""

import hashlib
import re
from datetime import UTC, datetime
from typing import Annotated
from urllib.parse import quote

from fastapi import (
    APIRouter,
    Depends,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
)
from pydantic import BaseModel
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.config import Settings
from app.core.db import get_db_session
from app.models import Document
from app.services.blob import BlobStorage
from app.services.document_type_config import get_config
from app.services.pdf_render import PdfProcessingError, PdfRenderer

router = APIRouter()


class DocumentResponse(BaseModel):
    document_id: str
    tenant_id: str
    document_type: str
    content_sha256: str
    received_at: datetime


def _to_response(doc: Document) -> DocumentResponse:
    return DocumentResponse(
        document_id=doc.document_id,
        tenant_id=doc.tenant_id,
        document_type=doc.document_type,
        content_sha256=doc.content_sha256,
        received_at=doc.received_at,
    )


@router.post(
    "/api/documents",
    response_model=DocumentResponse,
    status_code=201,
    responses={200: {"model": DocumentResponse}},
)
async def register_document(
    request: Request,
    response: Response,
    _user: CurrentUser,
    document_id: Annotated[str, Form(min_length=1, max_length=255)],
    document_type: Annotated[str, Form(min_length=1, max_length=50)],
    file: UploadFile,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentResponse:
    content = await file.read()
    if file.content_type != "application/pdf" or not content.startswith(b"%PDF"):
        raise HTTPException(status_code=415, detail="Only PDF files are accepted")

    settings: Settings = request.app.state.settings
    if get_config(session, settings.tenant_id, document_type) is None:
        raise HTTPException(
            status_code=422,
            detail="Unknown document type for this tenant",
        )
    blob_storage: BlobStorage = request.app.state.blob_storage
    sha256 = hashlib.sha256(content).hexdigest()

    existing = session.get(Document, document_id)
    if existing is not None:
        return _respond_for_existing(response, existing, sha256, document_type)

    blob_ref = f"{settings.tenant_id}/{document_id}.pdf"
    document = Document(
        document_id=document_id,
        tenant_id=settings.tenant_id,
        document_type=document_type,
        blob_ref=blob_ref,
        content_sha256=sha256,
        original_filename=_original_filename(file.filename),
        received_at=datetime.now(UTC),
    )
    blob_storage.save(blob_ref, content)
    session.add(document)
    try:
        session.commit()
    except IntegrityError:
        # 同時登録の競合。既存行と突き合わせて冪等判定へフォールバック
        session.rollback()
        existing = session.get(Document, document_id)
        if existing is None:
            raise
        return _respond_for_existing(response, existing, sha256, document_type)
    return _to_response(document)


def _original_filename(filename: str | None) -> str | None:
    """multipart の filename から basename を取り出す（Windows/POSIX 区切り両対応）。空は None。"""
    name = re.split(r"[\\/]", filename or "")[-1].strip()
    return name[:255] or None


def pdf_response(document: Document, pdf: bytes) -> Response:
    """原本PDFの添付応答。保存名はアップロード時のファイル名（RFC 6266/5987）、未保存なら document_id.pdf。"""
    disposition = f'attachment; filename="{document.document_id}.pdf"'
    if document.original_filename:
        disposition += (
            f"; filename*=UTF-8''{quote(document.original_filename, safe='')}"
        )
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": disposition},
    )


class PageInfo(BaseModel):
    width: float
    height: float


class PagesResponse(BaseModel):
    page_count: int
    pages: list[PageInfo]


def _get_document_or_404(
    request: Request, session: Session, document_id: str
) -> Document:
    settings: Settings = request.app.state.settings
    document = session.get(Document, document_id)
    # テナント不一致は存在自体を秘匿するため404（他テナント文書IDの受入観点に対応）
    if document is None or document.tenant_id != settings.tenant_id:
        raise HTTPException(status_code=404, detail="Document not found")
    return document


def _load_pdf(request: Request, document: Document) -> bytes:
    blob_storage: BlobStorage = request.app.state.blob_storage
    return blob_storage.load(document.blob_ref)


@router.get("/api/documents/{document_id}", response_model=DocumentResponse)
def get_document(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentResponse:
    return _to_response(_get_document_or_404(request, session, document_id))


@router.get("/api/documents/{document_id}/pages", response_model=PagesResponse)
def get_pages(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> PagesResponse:
    document = _get_document_or_404(request, session, document_id)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        sizes = renderer.get_page_sizes(_load_pdf(request, document))
    except PdfProcessingError as exc:
        raise HTTPException(status_code=500, detail="Failed to process PDF") from exc
    return PagesResponse(
        page_count=len(sizes),
        pages=[PageInfo(width=size.width, height=size.height) for size in sizes],
    )


@router.get("/api/documents/{document_id}/pages/{page}/image")
def get_page_image(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    page: int,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document = _get_document_or_404(request, session, document_id)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        png = renderer.render_page_png(_load_pdf(request, document), page - 1)
    except IndexError:
        raise HTTPException(status_code=404, detail="Page not found") from None
    except PdfProcessingError as exc:
        raise HTTPException(status_code=500, detail="Failed to process PDF") from exc
    return Response(content=png, media_type="image/png")


@router.get("/api/documents/{document_id}/pdf")
def get_original_pdf(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document = _get_document_or_404(request, session, document_id)
    return pdf_response(document, _load_pdf(request, document))


def _respond_for_existing(
    response: Response, existing: Document, sha256: str, document_type: str
) -> DocumentResponse:
    if existing.content_sha256 == sha256 and existing.document_type == document_type:
        # 冪等再送: 既定の201を200へ差し替える
        response.status_code = 200
        return _to_response(existing)
    raise HTTPException(
        status_code=409,
        detail="Document ID already registered with different content",
    )
