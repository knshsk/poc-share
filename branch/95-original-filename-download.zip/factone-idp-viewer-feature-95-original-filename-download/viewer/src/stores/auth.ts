import {
  InMemoryWebStorage,
  UserManager,
  WebStorageStateStore,
} from 'oidc-client-ts'
import { defineStore } from 'pinia'
import { ref } from 'vue'

// アクセストークンはメモリ保持（localStorage等へ永続化しない）
function createUserManager(): UserManager {
  return new UserManager({
    // 空文字（ビルド引数未指定）でも既定値へフォールバックさせるため || を使う
    authority:
      import.meta.env.VITE_OIDC_AUTHORITY ||
      'http://localhost:8080/realms/factone',
    client_id: import.meta.env.VITE_OIDC_CLIENT_ID || 'factone-viewer',
    redirect_uri: `${window.location.origin}/callback`,
    post_logout_redirect_uri: window.location.origin,
    scope: 'openid',
    userStore: new WebStorageStateStore({ store: new InMemoryWebStorage() }),
  })
}

// コールバック後の復元先。同一オリジンの相対パス（"/"始まり・"//"不可）のみ許可し、
// 不正値はトップへフォールバックする（オープンリダイレクト防止）
function resolveReturnTo(state: unknown): string {
  const returnTo = (state as { returnTo?: unknown } | undefined)?.returnTo
  if (typeof returnTo !== 'string') return '/'
  if (!returnTo.startsWith('/') || returnTo.startsWith('//')) return '/'
  return returnTo
}

export const useAuthStore = defineStore('auth', () => {
  const userManager = createUserManager()
  const accessToken = ref<string | null>(null)
  const username = ref<string | null>(null)
  const isAuthenticated = ref(false)

  async function login(): Promise<void> {
    // ログイン前URL（?document_id= 等）をstateに保存し、コールバック後に復元する
    await userManager.signinRedirect({
      state: {
        returnTo: `${window.location.pathname}${window.location.search}`,
      },
    })
  }

  async function handleCallback(): Promise<void> {
    const user = await userManager.signinCallback()
    // 認証済フラグを立てるとDocumentViewが即マウントされ location.search を読むため、
    // URL復元（不正・未設定時は"/"）はフラグ確定より前に行う
    window.history.replaceState({}, '', resolveReturnTo(user?.state))
    if (user) {
      accessToken.value = user.access_token
      username.value = user.profile?.preferred_username ?? null
      isAuthenticated.value = true
    }
  }

  async function logout(): Promise<void> {
    accessToken.value = null
    username.value = null
    isAuthenticated.value = false
    await userManager.signoutRedirect()
  }

  return {
    accessToken,
    username,
    isAuthenticated,
    login,
    handleCallback,
    logout,
  }
})
