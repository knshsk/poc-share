// Content-Disposition から保存ファイル名を取り出す（filename* 優先、無ければ filename、無ければ fallback）
export function filenameFromDisposition(
  header: string | null,
  fallback: string,
): string {
  if (!header) return fallback
  const ext = /filename\*=UTF-8''([^;]+)/i.exec(header)
  if (ext) {
    try {
      return decodeURIComponent(ext[1].trim())
    } catch {
      return fallback
    }
  }
  const plain = /filename="([^"]+)"/i.exec(header)
  return plain?.[1] ?? fallback
}
