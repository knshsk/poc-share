<script setup lang="ts">
import { PhFileMagnifyingGlass, PhWarningCircle } from '@phosphor-icons/vue'
import { onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import { filenameFromDisposition } from '../utils/download'
import type { PageInfo } from '../components/DocumentCanvas.vue'
import DocumentCanvas from '../components/DocumentCanvas.vue'
import WorkPanel from '../components/WorkPanel.vue'
import { useDocumentStore } from '../stores/document'

const store = useDocumentStore()
const inputId = ref('')
const pages = ref<PageInfo[]>([])
const loading = ref(false)
const errorMessage = ref<string | null>(null)

async function loadDocument(): Promise<void> {
  errorMessage.value = null
  pages.value = []
  store.loadedDocumentId = null
  store.documentType = null
  store.documentTypeDisplayName = null
  store.documentTypeShareable = false
  store.hiddenFieldKeys = []
  if (!store.documentId) return

  loading.value = true
  try {
    const [docResult, pagesResult, configsResult] = await Promise.all([
      apiClient.GET('/api/documents/{document_id}', {
        params: { path: { document_id: store.documentId } },
      }),
      apiClient.GET('/api/documents/{document_id}/pages', {
        params: { path: { document_id: store.documentId } },
      }),
      apiClient.GET('/api/config/document-types'),
    ])
    if (
      docResult.error ||
      !docResult.data ||
      pagesResult.error ||
      !pagesResult.data
    ) {
      errorMessage.value = '文書を取得できませんでした'
      return
    }
    store.documentType = docResult.data.document_type
    // 種別設定（display_name・shareable・fields.visible）を反映する。
    // 設定取得失敗・設定なしは表示名フォールバック（種別コード表示）・共有不可・全項目表示のまま継続する
    const config = configsResult.data?.find(
      (c) => c.type_code === docResult.data.document_type,
    )
    store.documentTypeDisplayName = config?.display_name ?? null
    store.documentTypeShareable = config?.shareable ?? false
    store.hiddenFieldKeys = (config?.fields ?? [])
      .filter((f) => !f.visible)
      .map((f) => f.key)
    pages.value = pagesResult.data.pages
    store.loadedDocumentId = store.documentId
  } finally {
    loading.value = false
  }
}

function applyInputId(): void {
  if (inputId.value) store.documentId = inputId.value
}

async function downloadOriginal(): Promise<void> {
  const { data, error, response } = await apiClient.GET(
    '/api/documents/{document_id}/pdf',
    {
      params: { path: { document_id: store.documentId } },
      parseAs: 'blob',
    },
  )
  if (error || !data) {
    errorMessage.value = '原本を取得できませんでした'
    return
  }
  const url = URL.createObjectURL(data)
  const link = document.createElement('a')
  link.href = url
  link.download = filenameFromDisposition(
    response.headers.get('content-disposition'),
    `${store.documentId}.pdf`,
  )
  link.click()
  URL.revokeObjectURL(url)
}

onMounted(() => {
  // 呼出パラメータの文書IDのみを受領する（案件ID・ルートIDは要求しない）
  store.documentId =
    new URLSearchParams(window.location.search).get('document_id') ?? ''
  if (store.documentId) void loadDocument()
})

// ヘッダバッジ・empty stateからの再入力で再取得する
watch(
  () => store.documentId,
  () => void loadDocument(),
)
</script>

<template>
  <!-- 文書ID未指定: empty state -->
  <div v-if="!store.documentId" class="state-screen">
    <PhFileMagnifyingGlass :size="48" class="text-secondary mb-4" />
    <p class="text-body-1 mb-4">文書IDを指定して起動してください</p>
    <div class="state-input">
      <v-text-field
        v-model="inputId"
        label="文書ID"
        density="compact"
        hide-details
        data-testid="document-id-input"
        @keyup.enter="applyInputId"
      />
      <v-btn
        color="primary"
        data-testid="document-id-apply"
        @click="applyInputId"
      >
        表示
      </v-btn>
    </div>
  </div>

  <!-- 取得失敗: エラーstate -->
  <div v-else-if="errorMessage" class="state-screen">
    <PhWarningCircle :size="48" class="text-error mb-4" />
    <p class="text-body-1 mb-4" data-testid="document-error">
      {{ errorMessage }}
    </p>
    <v-btn
      color="primary"
      variant="outlined"
      data-testid="document-retry"
      @click="loadDocument"
    >
      再試行
    </v-btn>
  </div>

  <!-- 2ペイン: 左キャンバス / 右作業パネル -->
  <div v-else class="document-layout">
    <section class="canvas-pane">
      <DocumentCanvas
        v-if="pages.length > 0"
        :document-id="store.documentId"
        :pages="pages"
        @download-original="downloadOriginal"
      />
      <div v-else class="canvas-loading">
        <v-skeleton-loader type="image" class="page-skeleton" />
      </div>
    </section>

    <aside class="work-pane">
      <WorkPanel
        v-if="store.loadedDocumentId && store.documentType"
        :document-id="store.loadedDocumentId"
        :shareable="store.documentTypeShareable"
        :hidden-field-keys="store.hiddenFieldKeys"
      />
      <v-skeleton-loader v-else type="article" />
    </aside>
  </div>
</template>

<style scoped>
.state-screen {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 60vh;
  text-align: center;
}

.state-input {
  display: flex;
  gap: 8px;
  width: 320px;
  max-width: 90vw;
}

/* アプリバーを除いた高さで2ペインを固定し、ペイン内スクロールにする */
.document-layout {
  display: grid;
  grid-template-columns: 1fr 380px;
  height: calc(100dvh - 64px);
}

.canvas-pane {
  min-width: 0;
}

.canvas-loading {
  height: 100%;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  background: rgb(var(--v-theme-canvas));
  padding: 24px;
}

.page-skeleton {
  width: 60%;
  aspect-ratio: 8.5 / 11;
}

.work-pane {
  overflow-y: auto;
  padding: 16px;
  background: rgb(var(--v-theme-surface));
  border-left: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* 幅960px未満は縦積みフォールバック（作業パネルが上・キャンバスが下） */
@media (max-width: 960px) {
  .document-layout {
    display: flex;
    flex-direction: column-reverse;
    height: auto;
  }

  .canvas-pane {
    min-height: 60vh;
  }

  .work-pane {
    border-left: none;
    border-bottom: 1px solid
      rgba(var(--v-border-color), var(--v-border-opacity));
  }
}
</style>
