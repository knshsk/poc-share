import { describe, expect, it } from 'vitest'

import { filenameFromDisposition } from '../src/utils/download'

describe('filenameFromDisposition', () => {
  it('filename*（UTF-8 percent-encoded）を優先してデコードする', () => {
    expect(
      filenameFromDisposition(
        'attachment; filename="doc-1.pdf"; filename*=UTF-8\'\'%E8%A6%8B%E7%A9%8D%E6%9B%B8%20A.pdf',
        'x.pdf',
      ),
    ).toBe('見積書 A.pdf')
  })

  it('filename* が無ければ filename を使う', () => {
    expect(
      filenameFromDisposition('attachment; filename="doc-1.pdf"', 'x.pdf'),
    ).toBe('doc-1.pdf')
  })

  it('ヘッダ無し・解析不能はフォールバック', () => {
    expect(filenameFromDisposition(null, 'x.pdf')).toBe('x.pdf')
    expect(filenameFromDisposition('attachment', 'x.pdf')).toBe('x.pdf')
  })
})
