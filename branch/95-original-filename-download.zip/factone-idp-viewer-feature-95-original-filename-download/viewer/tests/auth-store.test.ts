import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const signinRedirect = vi.fn()
const signinCallback = vi.fn()
const signoutRedirect = vi.fn()

vi.mock('oidc-client-ts', () => ({
  UserManager: class {
    signinRedirect = signinRedirect
    signinCallback = signinCallback
    signoutRedirect = signoutRedirect
  },
  WebStorageStateStore: class {},
  InMemoryWebStorage: class {},
}))

import { useAuthStore } from '../src/stores/auth'

describe('認証ストア', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  // 初期状態では未認証であることを確認する
  it('初期状態は未認証', () => {
    const store = useAuthStore()

    expect(store.isAuthenticated).toBe(false)
    expect(store.accessToken).toBeNull()
  })

  // login() がKeycloakへのリダイレクトを開始することを確認する
  it('login()でsigninRedirectが呼ばれる', async () => {
    const store = useAuthStore()

    await store.login()

    expect(signinRedirect).toHaveBeenCalledOnce()
  })

  // ログイン前のURL（パス＋クエリ）をstateに保存し、コールバック後に復元できることを確認する
  it('login()でログイン前URLをstateに保存する', async () => {
    window.history.replaceState(null, '', '/?document_id=doc-1')
    const store = useAuthStore()

    await store.login()

    expect(signinRedirect).toHaveBeenCalledWith({
      state: { returnTo: '/?document_id=doc-1' },
    })
  })

  // handleCallback()がstateのログイン前URLへ復元することを確認する
  it('handleCallback()はstateの復元先URLへ遷移する', async () => {
    window.history.replaceState(null, '', '/callback?code=abc&state=xyz')
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: {},
      state: { returnTo: '/?document_id=doc-1' },
    })
    const store = useAuthStore()
    const replaceState = vi.spyOn(window.history, 'replaceState')

    await store.handleCallback()

    expect(window.location.pathname + window.location.search).toBe(
      '/?document_id=doc-1',
    )
    expect(replaceState).toHaveBeenCalledOnce()
    expect(store.isAuthenticated).toBe(true)
    replaceState.mockRestore()
    window.history.replaceState(null, '', '/')
  })

  // stateなし・不正値（外部URL・スキーム相対）は"/"へフォールバックすることを確認する
  it.each([
    ['stateなし', undefined],
    ['外部URL', { returnTo: 'https://evil.example/' }],
    ['スキーム相対URL', { returnTo: '//evil.example/' }],
    ['相対パスでない', { returnTo: 'foo' }],
    ['文字列でない', { returnTo: 1 }],
  ])(
    'handleCallback()の復元先が%s のとき"/"へ遷移する',
    async (_label, state) => {
      window.history.replaceState(null, '', '/callback?code=abc&state=xyz')
      signinCallback.mockResolvedValue({
        access_token: 'token-abc',
        profile: {},
        state,
      })
      const store = useAuthStore()

      await store.handleCallback()

      expect(window.location.pathname + window.location.search).toBe('/')
    },
  )

  // コールバック処理後に認証済みとなり、トークン・ユーザー名を保持することを確認する
  it('handleCallback()でユーザー情報とトークンを保持する', async () => {
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: { preferred_username: 'testuser' },
    })
    const store = useAuthStore()

    await store.handleCallback()

    expect(store.isAuthenticated).toBe(true)
    expect(store.accessToken).toBe('token-abc')
    expect(store.username).toBe('testuser')
  })

  // logout() でローカル状態が破棄されリダイレクトが開始されることを確認する
  it('logout()で状態破棄とsignoutRedirectが行われる', async () => {
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: { preferred_username: 'testuser' },
    })
    const store = useAuthStore()
    await store.handleCallback()

    await store.logout()

    expect(store.isAuthenticated).toBe(false)
    expect(store.accessToken).toBeNull()
    expect(signoutRedirect).toHaveBeenCalledOnce()
  })
})
