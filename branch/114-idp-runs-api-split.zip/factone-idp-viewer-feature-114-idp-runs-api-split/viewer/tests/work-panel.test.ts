import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// 実行API呼出はapiClient経由のためモックする（パネルは操作と表示分岐が検証対象）
const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
}))

import WorkPanel from '../src/components/WorkPanel.vue'

const succeededRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-08-01T00:00:00Z',
  raw_fields: { order_no: 'A-001' },
  normalized_fields: { order_no: 'A-001', total_amount: 1000 },
  confidence: { order_no: 0.98, total_amount: 0.75 },
  error_info: null,
}

const failedRun = {
  run_id: '22222222-2222-2222-2222-222222222222',
  document_id: 'doc-1',
  run_type: 'rerun',
  status: 'failed',
  executed_at: '2026-08-02T00:00:00Z',
  raw_fields: null,
  normalized_fields: null,
  confidence: null,
  error_info: 'DI request failed',
}

type RunLike = typeof succeededRun | typeof failedRun

// 一覧はサマリ（項目値・テーブルを含まない）、詳細は run_id で個別取得する現行APIを模す
function toSummary(run: RunLike) {
  return {
    run_id: run.run_id,
    document_id: run.document_id,
    run_type: run.run_type,
    status: run.status,
    executed_at: run.executed_at,
    di_api_version: null,
    di_model_id: null,
    error_info: run.error_info,
  }
}

function mockRuns(runs: RunLike[]): void {
  getMock.mockImplementation(
    (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return Promise.resolve({
          data: { document_id: 'doc-1', runs: runs.map(toSummary) },
          error: undefined,
        })
      }
      if (path === '/api/v1/documents/{document_id}/idp-runs/{run_id}') {
        const run = runs.find((r) => r.run_id === options?.params?.path?.run_id)
        return Promise.resolve(
          run
            ? { data: run, error: undefined }
            : { data: undefined, error: { status: 404 } },
        )
      }
      return Promise.resolve({ data: undefined, error: undefined })
    },
  )
}

function mountPanel(shareable = false, hiddenFieldKeys: string[] = []) {
  return mount(WorkPanel, {
    props: { documentId: 'doc-1', shareable, hiddenFieldKeys },
    global: { plugins: [createAppVuetify()] },
  })
}

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
  mockRuns([])
})

describe('WorkPanel', () => {
  // 文書表示時に一覧を自動取得し、最新実行の詳細を個別取得して表示することを確認する
  it('マウント時に一覧を取得し、最新実行の詳細を個別取得して表示する', async () => {
    // サーバ応答は実行日時昇順。最新（末尾のfailedRun）を初期選択し、詳細APIで取得する
    mockRuns([succeededRun, failedRun])

    const wrapper = mountPanel()
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1', run_id: failedRun.run_id } },
      }),
    )
    // 最新=failedRunのためエラー情報が表示される
    expect(wrapper.text()).toContain('DI request failed')

    // 取得順は一覧→詳細
    expect(getMock.mock.calls.map(([path]) => path)).toEqual([
      '/api/v1/documents/{document_id}/idp-runs',
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
    ])
  })

  // 成功実行選択時、項目名・値・確信度が一覧表示されることを確認する
  it('成功実行の項目化結果と確信度を項目別に表示する', async () => {
    mockRuns([succeededRun])

    const wrapper = mountPanel()
    await flushPromises()

    const text = wrapper.text()
    expect(text).toContain('order_no')
    expect(text).toContain('A-001')
    expect(text).toContain('total_amount')
    expect(text).toContain('1000')
    // 確信度は%表示
    expect(text).toContain('98%')
    expect(text).toContain('75%')
  })

  // IDP実行ボタンでPOSTし、応答結果が表示・履歴追加されることを確認する
  it('IDP実行ボタンでPOSTし結果を表示する', async () => {
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1' } },
      }),
    )
    expect(wrapper.text()).toContain('order_no')
    expect(wrapper.text()).toContain('98%')

    // 履歴タブに1件追加される
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await flushPromises()
    expect(wrapper.findAll('[data-testid="run-row"]')).toHaveLength(1)
  })

  // 実行失敗（API呼出エラー）時にエラーメッセージが表示されることを確認する
  it('POST失敗時にエラーメッセージを表示する', async () => {
    postMock.mockResolvedValue({
      data: undefined,
      error: { detail: 'Document analysis failed' },
    })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('IDP実行に失敗しました')
  })

  // 履歴行選択で当該実行の結果へ表示が切り替わることを確認する
  it('履歴行選択で該当実行の結果を表示する', async () => {
    mockRuns([succeededRun, failedRun])

    const wrapper = mountPanel()
    await flushPromises()

    // 履歴タブを開き、初期選択（最新=failedRun）から過去行（succeededRun）を選択する
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await flushPromises()
    const rows = wrapper.findAll('[data-testid="run-row"]')
    expect(rows).toHaveLength(2)
    await rows[1]!.trigger('click')
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1', run_id: succeededRun.run_id } },
      }),
    )
    // 選択で読取結果タブへ戻り、該当実行の結果が表示される
    expect(wrapper.text()).toContain('order_no')
    expect(wrapper.text()).toContain('98%')
  })

  // 確信度が3段階の色トークンでバー表示されることを確認する
  it('確信度バーを3段階の色で表示する', async () => {
    mockRuns([succeededRun])

    const wrapper = mountPanel()
    await flushPromises()

    const bars = wrapper.findAll('[data-testid="confidence-bar"]')
    expect(bars).toHaveLength(2)
    // order_no: 0.98 -> success / total_amount: 0.75 -> error
    expect(bars[0]!.classes().join(' ')).toContain('text-success')
    expect(bars[1]!.classes().join(' ')).toContain('text-error')
  })

  // 項目名は実行時ラベル（field_labels）を表示し、無い項目はキー名フォールバックすることを確認する
  it('field_labelsのラベルを項目名表示しキー名フォールバックする', async () => {
    const labeledRun = {
      ...succeededRun,
      field_labels: { order_no: '注文番号' },
    }
    mockRuns([labeledRun])

    const wrapper = mountPanel()
    await flushPromises()

    const text = wrapper.text()
    expect(text).toContain('注文番号')
    expect(text).not.toContain('order_no')
    // field_labelsに無い項目はキー名表示
    expect(text).toContain('total_amount')
  })

  // 設定でvisible=falseの項目（hiddenFieldKeys）は読み取り結果に表示しないことを確認する（#91）
  it('hiddenFieldKeysの項目を読み取り結果から除外する', async () => {
    mockRuns([succeededRun])

    const wrapper = mountPanel(false, ['total_amount', 'not_in_run'])
    await flushPromises()

    const rows = wrapper.findAll('[data-testid="field-row"]')
    expect(rows).toHaveLength(1)
    const text = wrapper.text()
    expect(text).toContain('order_no')
    expect(text).not.toContain('total_amount')
    expect(text).not.toContain('1000')
  })

  // 閲覧URLタブは設定のshareableで表示制御することを確認する（#81・ADR-0002）
  it('shareable=trueで閲覧URLタブを表示し、falseでは表示しない', async () => {
    const notShareable = mountPanel(false)
    await flushPromises()
    expect(notShareable.find('[data-testid="tab-urls"]').exists()).toBe(false)

    const shareable = mountPanel(true)
    await flushPromises()
    expect(shareable.find('[data-testid="tab-urls"]').exists()).toBe(true)
  })

  // 詳細取得の失敗時はエラーメッセージを表示することを確認する
  it('詳細取得に失敗するとエラーメッセージを表示する', async () => {
    getMock.mockImplementation((path: string) =>
      Promise.resolve(
        path === '/api/v1/documents/{document_id}/idp-runs'
          ? {
              data: { document_id: 'doc-1', runs: [toSummary(succeededRun)] },
              error: undefined,
            }
          : { data: undefined, error: { status: 500 } },
      ),
    )

    const wrapper = mountPanel()
    await flushPromises()

    expect(wrapper.text()).toContain('実行結果を取得できませんでした')
  })

  // 取得済みの詳細は再選択時に再取得しないことを確認する
  it('取得済みの詳細はキャッシュし再取得しない', async () => {
    mockRuns([succeededRun, failedRun])
    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    const rows = wrapper.findAll('[data-testid="run-row"]')
    await rows[1]!.trigger('click')
    await flushPromises()
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await wrapper.findAll('[data-testid="run-row"]')[0]!.trigger('click')
    await flushPromises()

    const detailCalls = getMock.mock.calls.filter(
      ([path]) => path === '/api/v1/documents/{document_id}/idp-runs/{run_id}',
    )
    // failedRun（初期選択）と succeededRun の2件のみ。failedRun の再選択は再取得しない
    expect(detailCalls).toHaveLength(2)
  })

  // 取得失敗のエラー表示は、取得済み（キャッシュ）の実行を再選択したときに消えることを確認する
  it('取得済みの実行を再選択するとエラー表示を消す', async () => {
    getMock.mockImplementation(
      (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
        if (path === '/api/v1/documents/{document_id}/idp-runs') {
          return Promise.resolve({
            data: {
              document_id: 'doc-1',
              runs: [succeededRun, failedRun].map(toSummary),
            },
            error: undefined,
          })
        }
        if (options?.params?.path?.run_id === succeededRun.run_id) {
          return Promise.resolve({ data: succeededRun, error: undefined })
        }
        return Promise.resolve({ data: undefined, error: { status: 500 } })
      },
    )

    const wrapper = mountPanel()
    await flushPromises()
    // 初期選択（failedRun）の詳細取得が失敗する
    expect(wrapper.text()).toContain('実行結果を取得できませんでした')

    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await wrapper.findAll('[data-testid="run-row"]')[1]!.trigger('click')
    await flushPromises()
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await wrapper.findAll('[data-testid="run-row"]')[0]!.trigger('click')
    await flushPromises()
    expect(wrapper.text()).toContain('実行結果を取得できませんでした')

    // succeededRun は取得済みのためキャッシュから表示され、エラー表示が消える
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await wrapper.findAll('[data-testid="run-row"]')[1]!.trigger('click')
    await flushPromises()
    expect(wrapper.text()).not.toContain('実行結果を取得できませんでした')
    expect(wrapper.text()).toContain('A-001')
  })

  // 応答待ちの間に別の実行を選択した場合、遅れて届いた古い応答で表示を上書きしないことを確認する
  it('応答待ち中に別の実行を選択した場合は古い応答を表示しない', async () => {
    let resolveDetail: (value: unknown) => void = () => {}
    getMock.mockImplementation(
      (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
        if (path === '/api/v1/documents/{document_id}/idp-runs') {
          return Promise.resolve({
            data: {
              document_id: 'doc-1',
              runs: [succeededRun, failedRun].map(toSummary),
            },
            error: undefined,
          })
        }
        if (options?.params?.path?.run_id === succeededRun.run_id) {
          return new Promise((resolve) => {
            resolveDetail = resolve
          })
        }
        return Promise.resolve({ data: failedRun, error: undefined })
      },
    )

    const wrapper = mountPanel()
    await flushPromises()

    // succeededRun を選択（応答保留）→ 取得済みの failedRun を選択
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await wrapper.findAll('[data-testid="run-row"]')[1]!.trigger('click')
    await wrapper.get('[data-testid="tab-history"]').trigger('click')
    await wrapper.findAll('[data-testid="run-row"]')[0]!.trigger('click')
    await flushPromises()

    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()

    expect(wrapper.text()).toContain('DI request failed')
    expect(wrapper.text()).not.toContain('A-001')
  })
})
