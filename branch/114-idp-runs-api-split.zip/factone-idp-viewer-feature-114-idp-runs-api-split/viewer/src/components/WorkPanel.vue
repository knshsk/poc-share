<script setup lang="ts">
import { PhArrowsClockwise } from '@phosphor-icons/vue'
import { computed, onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import type { components } from '../api/schema'
import {
  confidenceColor,
  formatConfidence,
  formatDateTime,
} from '../utils/format'
import ViewUrlPanel from './ViewUrlPanel.vue'

type IdpRunSummary = components['schemas']['IdpRunSummary']
type IdpRun = components['schemas']['IdpRunResponse']

// shareable: 文書種別設定（document_type_configs）の共有可否。閲覧URLタブの表示ゲート
// hiddenFieldKeys: 設定でvisible=falseの項目キー。読み取り結果の表示から除外する（#91）
const props = defineProps<{
  documentId: string
  shareable: boolean
  hiddenFieldKeys: string[]
}>()

const activeTab = ref<'result' | 'history' | 'urls'>('result')
// 履歴は一覧API（サマリ）を表示用に実行日時降順で保持する（サーバ応答は昇順）
const runs = ref<IdpRunSummary[]>([])
// 選択中実行の詳細。一覧には項目値・テーブルが無いため run_id ごとに詳細APIで取得し、行は不変なのでキャッシュする
const selectedRun = ref<IdpRun | null>(null)
const details = new Map<string, IdpRun>()
// 応答待ち中の run_id。応答受信時に選択が変わっていれば古い応答は捨てる
let pendingRunId: string | null = null
const executing = ref(false)
const loadingRuns = ref(false)
const errorMessage = ref<string | null>(null)

// 表示対象の項目（非表示設定のキーを除外）。APIの応答自体は全項目を保持する
const visibleFields = computed(() =>
  Object.entries(selectedRun.value?.normalized_fields ?? {}).filter(
    ([key]) => !props.hiddenFieldKeys.includes(key),
  ),
)

async function selectRun(runId: string): Promise<void> {
  activeTab.value = 'result'
  errorMessage.value = null
  pendingRunId = runId
  const cached = details.get(runId)
  if (cached) {
    selectedRun.value = cached
    return
  }
  const { data, error } = await apiClient.GET(
    '/api/v1/documents/{document_id}/idp-runs/{run_id}',
    {
      params: { path: { document_id: props.documentId, run_id: runId } },
    },
  )
  // 応答待ちの間に別の実行が選択された場合は古い応答を捨てる（後勝ちの誤表示防止）
  if (pendingRunId !== runId) return
  if (error || !data) {
    errorMessage.value = '実行結果を取得できませんでした'
    return
  }
  details.set(runId, data)
  selectedRun.value = data
}

async function loadRuns(): Promise<void> {
  errorMessage.value = null
  runs.value = []
  selectedRun.value = null
  details.clear()
  pendingRunId = null
  if (!props.documentId) return

  loadingRuns.value = true
  try {
    const { data, error } = await apiClient.GET(
      '/api/v1/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = '実行履歴を取得できませんでした'
      return
    }
    runs.value = [...data.runs].reverse()
    const latest = runs.value[0]
    if (latest) await selectRun(latest.run_id)
  } finally {
    loadingRuns.value = false
  }
}

async function executeIdp(): Promise<void> {
  errorMessage.value = null
  executing.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/v1/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = 'IDP実行に失敗しました'
      return
    }
    // 実行応答は詳細と同形。そのままキャッシュし選択状態にする
    details.set(data.run_id, data)
    runs.value = [data, ...runs.value]
    selectedRun.value = data
    activeTab.value = 'result'
  } finally {
    executing.value = false
  }
}

onMounted(() => void loadRuns())
watch(
  () => props.documentId,
  () => void loadRuns(),
)
</script>

<template>
  <div class="work-panel">
    <!-- IDP実行はタブ非依存で常置（K5-5/R1-5の再項目化導線） -->
    <div class="d-flex align-center mb-3">
      <v-btn
        color="primary"
        data-testid="execute-idp"
        :loading="executing"
        :disabled="executing || !documentId"
        @click="executeIdp"
      >
        <PhArrowsClockwise :size="16" class="mr-1" />
        IDP実行
      </v-btn>
    </div>
    <v-alert
      v-if="errorMessage"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-3"
    >
      {{ errorMessage }}
    </v-alert>

    <v-tabs v-model="activeTab" density="compact" color="primary">
      <v-tab value="result" data-testid="tab-result">読取結果</v-tab>
      <v-tab value="history" data-testid="tab-history">実行履歴</v-tab>
      <v-tab v-if="props.shareable" value="urls" data-testid="tab-urls">
        閲覧URL
      </v-tab>
    </v-tabs>

    <v-tabs-window v-model="activeTab" class="pt-3">
      <v-tabs-window-item value="result">
        <v-skeleton-loader v-if="loadingRuns" type="list-item@3" />
        <template v-else-if="selectedRun">
          <div
            v-if="selectedRun.status === 'succeeded'"
            data-testid="run-result"
          >
            <div
              v-for="[key, value] in visibleFields"
              :key="key"
              class="field-row"
              data-testid="field-row"
            >
              <div class="d-flex justify-space-between align-baseline">
                <span class="text-caption text-secondary">{{
                  selectedRun.field_labels?.[key] ?? key
                }}</span>
                <span
                  class="font-mono text-caption"
                  :class="
                    confidenceColor(selectedRun.confidence?.[key])
                      ? `text-${confidenceColor(selectedRun.confidence?.[key])}`
                      : ''
                  "
                >
                  {{ formatConfidence(selectedRun.confidence?.[key]) }}
                </span>
              </div>
              <div class="text-body-2">{{ value ?? '-' }}</div>
              <v-progress-linear
                :model-value="(selectedRun.confidence?.[key] ?? 0) * 100"
                :color="confidenceColor(selectedRun.confidence?.[key])"
                :class="
                  confidenceColor(selectedRun.confidence?.[key])
                    ? `text-${confidenceColor(selectedRun.confidence?.[key])}`
                    : ''
                "
                height="4"
                rounded
                data-testid="confidence-bar"
              />
            </div>
          </div>
          <p v-else class="text-error text-body-2" data-testid="run-error">
            実行失敗: {{ selectedRun.error_info ?? '不明なエラー' }}
          </p>
        </template>
        <p v-else class="text-secondary text-body-2">実行結果がありません</p>
      </v-tabs-window-item>

      <v-tabs-window-item value="history">
        <v-list density="compact">
          <v-list-item
            v-for="run in runs"
            :key="run.run_id"
            data-testid="run-row"
            :active="run.run_id === selectedRun?.run_id"
            @click="selectRun(run.run_id)"
          >
            <v-list-item-title class="font-mono text-body-2">
              {{ formatDateTime(run.executed_at) }}
            </v-list-item-title>
            <v-list-item-subtitle>
              {{ run.run_type === 'initial' ? '初回' : '再実行' }}
              ・
              <span
                :class="
                  run.status === 'succeeded' ? 'text-success' : 'text-error'
                "
              >
                {{ run.status === 'succeeded' ? '成功' : '失敗' }}
              </span>
            </v-list-item-subtitle>
          </v-list-item>
        </v-list>
        <p v-if="runs.length === 0" class="text-secondary text-body-2">
          実行履歴がありません
        </p>
      </v-tabs-window-item>

      <v-tabs-window-item v-if="props.shareable" value="urls">
        <ViewUrlPanel :document-id="documentId" />
      </v-tabs-window-item>
    </v-tabs-window>
  </div>
</template>

<style scoped>
.field-row {
  padding: 8px 0;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.field-row:last-child {
  border-bottom: none;
}
</style>
