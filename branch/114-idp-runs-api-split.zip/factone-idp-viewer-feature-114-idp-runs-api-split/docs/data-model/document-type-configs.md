# 文書種別設定（document_type_configs）

文書種別のテナント別設定。Query Fieldsのキー・ラベル・型と、閲覧URL発行可否を種別ごとに保持する（ADR-0014）。設定CRUD API（`/api/v1/config/document-types`）で管理する。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 管理ID |
| tenant_id | varchar(255) | NOT NULL | テナント識別子。**仮置き: 認可設計確定まで固定値 `default`** |
| type_code | varchar(50) | NOT NULL | 文書種別コード（`^[A-Za-z0-9_]{1,50}$`）。`documents.document_type` が参照する |
| display_name | varchar(100) | NOT NULL | 種別表示名（例: 見積書） |
| shareable | bool | NOT NULL | 閲覧URL発行可否 |
| fields | jsonb | NOT NULL | 抽出フィールド定義の配列（下記。順序保持） |
| patterns | jsonb | NOT NULL・default `[]` | 正規表現パターン定義の配列（下記。順序保持）。IDP実行時にDI全文テキストへ適用する |
| created_at | timestamptz | NOT NULL・default now() | 行作成日時 |
| updated_at | timestamptz | NOT NULL・default now() | 行更新日時 |

- UNIQUE(`tenant_id`, `type_code`)
- `documents.document_type` とのFKは張らない（種別コードは文字列参照。整合はアプリ層で担保）

## fields 要素

| キー | 型 | 説明 |
| --- | --- | --- |
| key | string | Query Fieldsで使用するキー（`^[A-Za-z0-9_]{1,50}$`。種別内一意） |
| label | string | 表示ラベル（例: 顧客コード） |
| type | string | `string` / `number` / `date`。IDP抽出結果の正規化を駆動する |
| visible | bool | Viewerの読み取り結果に表示するか。省略時 `true`。`false` でも抽出・保存・API返却は行う（Viewer表示のみ除外） |

- 読み取りは (tenant_id, type_code) の1行取得のみ。JSONB内部への検索は行わない（GINインデックス不要）
- `visible` は表示時にViewerが現在の設定を参照して判定する（実行時スナップショットではない）。設定変更は過去の実行結果の表示にも反映される。送信先／送信元のように対で指定すると抽出精度が上がるが表示不要な項目（例: 受領注文書の自社名）を想定

## patterns 要素

Query Fieldsで取得しづらい項目（採番規則のある見積番号、適格請求書発行事業者登録番号等）を補うため、DI応答の全文テキスト（`content`）に正規表現を適用する。

| キー | 型 | 説明 |
| --- | --- | --- |
| key | string | 結果のキー（`^[A-Za-z0-9_]{1,50}$`。patterns内で一意。fieldsのkeyとは別空間で重複可） |
| label | string | 表示ラベル（例: 登録番号） |
| regex | string | Python `re` 構文の正規表現（1〜512文字。登録時に `re.compile` で検証し失敗は422） |

- 実行時にフラグは指定しない（大文字小文字を区別し、`.` は改行に一致しない）。パターン内のインラインフラグ（`(?i)` 等）は Python `re` の仕様どおり有効。返す値は一致全体（group 0）。キャプチャグループは使わず、部分抽出は先読み・後読みで表現する
- 正規表現はテナント管理者入力であり、Python `re` にはタイムアウトがない。PoCでは長さ上限とコンパイル検証のみで、本番前に `re2` 等バックトラックしないエンジンへの差し替えを検討する
- マッチ値の妥当性検証（実在する見積番号か等）は外部システムの責務。SaaS側は検出と返却のみ行う
- 設定 API の PUT は `patterns` を全置換する。`patterns` を省略した PUT は `[]` に置換する（`fields` と同じ置換セマンティクス）

## 整合性ルール

- 使用中の種別（`documents` に参照行あり）の削除は409で拒否
- フィールド定義の更新は自由。過去のIDP実行ログ（idp_runs）は実行時点の結果をJSONBで保持済みのため影響を受けない
- 文書登録時、テナント設定に未登録の種別は422で拒否
- IDP実行時、文書の種別が設定に未登録の場合は409（削除保護があるため通常発生しない防御的措置）

## シードデータ

マイグレーションで以下2種別を `tenant_id="default"` に投入する（#105。注文書はIDP実行後に案件型・ルート型へ分岐するため、実行前の種別は分けない）。

| type_code | display_name | shareable | fields |
| --- | --- | --- | --- |
| purchase_order | 注文書 | false | 共通8項目 + `PurchaseOrderId`（注文書ID） |
| quotation | 見積書 | true | 共通8項目 |

共通8項目（Query Fieldsキーは Document Intelligence のドキュメントに倣いPascalCase）:

| key | label | type | visible |
| --- | --- | --- | --- |
| SenderCompanyName | 取引先 | string | true |
| ReceiverCompanyName | 自社名 | string | **false** |
| OrderDate | 注文日 | date | true |
| TotalAmount | 合計金額 | number | true |
| DeliveryDate | 納品期限 | date | true |
| DeliveryLocation | 納品場所 | string | true |
| CustomerContactPersonName | 取引先担当者 | string | true |
| QuotationId | 見積書ID | string | true |

`shareable` のデフォルトはADR-0002の判断（注文書は発行禁止）を引き継ぐ。

両種別の `patterns` に登録番号（Tコード）を投入する。見積番号は採番規則が未確定のため投入しない。

| key | label | regex |
| --- | --- | --- |
| TCode | 登録番号 | `T\d{13}` |
