---
status: accepted
date: 2026-09-13
---

# Document Intelligence の生応答を Blob にバイト保存する

## 背景

IDP 実行ログ（`idp_runs`）は Query Fields の項目値・確信度・テーブル領域・正規表現一致のみを JSONB で保持しており、DI 応答のそれ以外の情報（words / lines / paragraphs / 座標等）は捨てていた。今後 `tables` / `fields` 以外を使う機能（座標を使った照合支援など）と、人手修正結果を教師データにしたカスタムモデル学習が見込まれるため、応答を欠落なく残す必要がある。DI の API バージョンが変わる可能性もあり、どの版の応答かを残す必要がある。

## 決定

- DI の最終ポーリング GET の応答本文（`status` / `createdDateTime` / `lastUpdatedDateTime` / `analyzeResult` を含むラッパ込み JSON）を、SDK の `cls` コールバックで bytes のまま受け取り、Blob `{tenant_id}/{document_id}/idp-runs/{run_id}.json` に無変換で保存する。
- `idp_runs` には参照パス（`raw_response_ref`）と `analyzeResult.apiVersion` / `modelId`（`di_api_version` / `di_model_id`）を列として持つ。
- 生応答は `GET /api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response` が Blob から素通しで返す（Blob 全面非公開・API プロキシ方式は ADR-0010 のまま）。
- 保存順序は DI 成功 → Blob 保存 → 実行ログ INSERT とし、Blob 保存失敗は 500 で実行ログを残さない。

## 検討した代替案

- `idp_runs` の JSONB 列に保存 — 1 実行あたり数百 KB〜数 MB で DB が肥大する。JSONB はキー順序・空白を保持せず「応答のまま」にならない。学習データとして使う際に Blob へ再配置が必要になるため却下
- SDK の `AnalyzeResult.as_dict()` を再シリアライズして保存 — ラッパ（`status` / 処理時刻）が落ち、将来のトップレベル項目追加に追随できない。バイト一致も保証されないため却下
- 保存しない（必要になったら再実行） — DI 呼出コストが二重になり、修正時点の応答と一致する保証がなく学習データに使えないため却下

## 影響

- Blob の容量が実行回数に比例して増える。PoC のデータ保持方針（機能検証に必要な期間のみ）の範囲では問題にならない
- DI Studio の `.ocr.json` と同形のため、カスタムモデル学習時は PDF と併せてコピーするだけで使える
- 応答の構造は DI の API バージョンに依存する。`di_api_version` を見て解釈すること
