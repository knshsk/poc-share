"""文書種別設定CRUD APIのテスト。"""

import io

from fastapi.testclient import TestClient

VALID_FIELDS = [
    {"key": "invoice_no", "label": "請求書番号", "type": "string"},
    {"key": "billing_amount", "label": "請求金額", "type": "number"},
    {"key": "due_date", "label": "支払期日", "type": "date"},
]
VALID_PAYLOAD = {
    "type_code": "invoice",
    "display_name": "請求書",
    "shareable": True,
    "fields": VALID_FIELDS,
}


class TestList:
    def test_returns_seeded_configs(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types")
        assert response.status_code == 200
        body = response.json()
        codes = {c["type_code"] for c in body}
        assert codes == {"purchase_order", "quotation"}
        # シードはReceiverCompanyNameのみvisible=false。未指定はtrue補完される（#91）
        hidden = {f["key"] for c in body for f in c["fields"] if not f["visible"]}
        assert hidden == {"ReceiverCompanyName"}

    def test_requires_auth(self, doc_client: TestClient) -> None:
        response = doc_client.get(
            "/api/v1/config/document-types", headers={"Authorization": "Bearer bad"}
        )
        assert response.status_code == 401


class TestCreate:
    def test_creates_new_config(self, doc_client: TestClient) -> None:
        response = doc_client.post("/api/v1/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 201
        body = response.json()
        assert body["type_code"] == "invoice"
        # visible省略時はtrue補完して応答される（#91）
        assert body["fields"] == [{**f, "visible": True} for f in VALID_FIELDS]

    # visible省略時はtrue補完、false指定は保持して応答されることを確認する（#91）
    def test_visible_defaults_true_and_roundtrips_false(
        self, doc_client: TestClient
    ) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [
                {"key": "invoice_no", "label": "請求書番号", "type": "string"},
                {
                    "key": "own_company",
                    "label": "自社名",
                    "type": "string",
                    "visible": False,
                },
            ],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 201
        assert [f["visible"] for f in response.json()["fields"]] == [True, False]

        fetched = doc_client.get("/api/v1/config/document-types/invoice")
        assert fetched.status_code == 200
        assert [f["visible"] for f in fetched.json()["fields"]] == [True, False]

    def test_duplicate_type_code_returns_409(self, doc_client: TestClient) -> None:
        assert (
            doc_client.post(
                "/api/v1/config/document-types", json=VALID_PAYLOAD
            ).status_code
            == 201
        )
        response = doc_client.post("/api/v1/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 409

    def test_invalid_type_code_returns_422(self, doc_client: TestClient) -> None:
        payload = {**VALID_PAYLOAD, "type_code": "Invalid-Code"}
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_pascal_case_key_and_type_code_accepted(
        self, doc_client: TestClient
    ) -> None:
        payload = {
            **VALID_PAYLOAD,
            "type_code": "PurchaseOrder",
            "fields": [{"key": "InvoiceNo", "label": "請求書番号", "type": "string"}],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 201
        assert response.json()["fields"][0]["key"] == "InvoiceNo"

    def test_empty_fields_returns_422(self, doc_client: TestClient) -> None:
        payload = {**VALID_PAYLOAD, "fields": []}
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_duplicate_field_key_returns_422(self, doc_client: TestClient) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [
                {"key": "invoice_no", "label": "請求書番号", "type": "string"},
                {"key": "invoice_no", "label": "重複キー", "type": "string"},
            ],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_invalid_field_type_returns_422(self, doc_client: TestClient) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [{"key": "invoice_no", "label": "番号", "type": "boolean"}],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_patterns_default_empty(self, doc_client: TestClient) -> None:
        # patterns省略時は空配列で応答する（既存クライアント互換）
        response = doc_client.post("/api/v1/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 201
        assert response.json()["patterns"] == []

    def test_patterns_roundtrip(self, doc_client: TestClient) -> None:
        patterns = [{"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}]
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**VALID_PAYLOAD, "patterns": patterns},
        )
        assert response.status_code == 201
        assert response.json()["patterns"] == patterns
        listed = doc_client.get("/api/v1/config/document-types/invoice").json()
        assert listed["patterns"] == patterns

    def test_invalid_regex_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [{"key": "Bad", "label": "不正", "regex": "("}],
            },
        )
        assert response.status_code == 422

    def test_too_long_regex_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [{"key": "Long", "label": "長い", "regex": "a" * 513}],
            },
        )
        assert response.status_code == 422

    def test_duplicate_pattern_key_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [
                    {"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"},
                    {"key": "TCode", "label": "重複", "regex": r"T\d{13}"},
                ],
            },
        )
        assert response.status_code == 422

    def test_pattern_key_may_equal_field_key(self, doc_client: TestClient) -> None:
        # fieldsとpatternsのkeyは別空間。重複を許す
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [
                    {"key": "invoice_no", "label": "請求書番号", "regex": r"INV-\d+"}
                ],
            },
        )
        assert response.status_code == 201


class TestGet:
    def test_returns_single_config(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types/quotation")
        assert response.status_code == 200
        body = response.json()
        assert body["display_name"] == "見積書"
        assert body["shareable"] is True

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types/unknown")
        assert response.status_code == 404


class TestUpdate:
    def test_replaces_config(self, doc_client: TestClient) -> None:
        payload = {
            "display_name": "見積書（改）",
            "shareable": False,
            "fields": [{"key": "document_no", "label": "番号", "type": "string"}],
        }
        response = doc_client.put(
            "/api/v1/config/document-types/quotation", json=payload
        )
        assert response.status_code == 200
        body = response.json()
        assert body["display_name"] == "見積書（改）"
        assert body["shareable"] is False
        assert len(body["fields"]) == 1

    def test_replaces_patterns(self, doc_client: TestClient) -> None:
        patterns = [{"key": "QuotationNo", "label": "見積番号", "regex": r"Q-\d{6}"}]
        response = doc_client.put(
            "/api/v1/config/document-types/purchase_order",
            json={
                "display_name": "注文書",
                "shareable": False,
                "fields": VALID_FIELDS,
                "patterns": patterns,
            },
        )
        assert response.status_code == 200
        assert response.json()["patterns"] == patterns

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        payload = {
            "display_name": "x",
            "shareable": False,
            "fields": VALID_PAYLOAD["fields"],
        }
        response = doc_client.put("/api/v1/config/document-types/unknown", json=payload)
        assert response.status_code == 404


class TestDelete:
    def test_deletes_unused_config(self, doc_client: TestClient) -> None:
        response = doc_client.delete("/api/v1/config/document-types/purchase_order")
        assert response.status_code == 204
        assert (
            doc_client.get("/api/v1/config/document-types/purchase_order").status_code
            == 404
        )

    def test_config_in_use_returns_409(self, doc_client: TestClient) -> None:
        pdf = io.BytesIO(b"%PDF-1.4 test")
        register = doc_client.post(
            "/api/v1/documents",
            data={"document_id": "cfg-del-1", "document_type": "quotation"},
            files={"file": ("doc.pdf", pdf, "application/pdf")},
        )
        assert register.status_code == 201
        response = doc_client.delete("/api/v1/config/document-types/quotation")
        assert response.status_code == 409

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.delete("/api/v1/config/document-types/unknown")
        assert response.status_code == 404
