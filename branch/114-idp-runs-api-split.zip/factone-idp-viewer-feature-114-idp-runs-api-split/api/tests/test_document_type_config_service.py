"""文書種別設定の取得サービスのテスト。"""

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from app.services.document_type_config import (
    FieldDef,
    FieldType,
    PatternDef,
    config_field_defs,
    config_pattern_defs,
    get_config,
)


def test_get_config_returns_seeded_quote(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields) "
                "VALUES (gen_random_uuid(), 'default', 'quotation', '見積書', true, "
                '\'[{"key": "total_amount", "label": "合計金額", "type": "number"}, '
                '{"key": "own_company", "label": "自社名", "type": "string", '
                '"visible": false}]\'::jsonb)'
            )
        )
        conn.commit()
    with Session(engine) as session:
        config = get_config(session, "default", "quotation")
        assert config is not None
        assert config.shareable is True
        # visibleは抽出側のFieldDefに含めない（Viewer表示専用。#91）
        assert config_field_defs(config) == (
            FieldDef(key="total_amount", label="合計金額", type=FieldType.NUMBER),
            FieldDef(key="own_company", label="自社名", type=FieldType.STRING),
        )
    engine.dispose()


def test_get_config_returns_none_for_unknown_type(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with Session(engine) as session:
        assert get_config(session, "default", "unknown_type") is None
    engine.dispose()


def test_get_config_is_tenant_scoped(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields) "
                "VALUES (gen_random_uuid(), 'other-tenant', 'quotation', '見積書', true, '[]'::jsonb)"
            )
        )
        conn.commit()
    with Session(engine) as session:
        assert get_config(session, "default", "quotation") is None
    engine.dispose()


def test_config_pattern_defs_converts_jsonb(test_database_url: str) -> None:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields, patterns) "
                "VALUES (gen_random_uuid(), 'default', 'quotation', '見積書', true, "
                '\'[{"key": "total_amount", "label": "合計金額", "type": "number"}]\'::jsonb, '
                '\'[{"key": "TCode", "label": "登録番号", "regex": "T\\\\d{13}"}]\'::jsonb)'
            )
        )
        conn.commit()
    with Session(engine) as session:
        config = get_config(session, "default", "quotation")
        assert config is not None
        assert config_pattern_defs(config) == (
            PatternDef(key="TCode", label="登録番号", regex=r"T\d{13}"),
        )
    engine.dispose()


def test_config_pattern_defs_empty_when_column_defaulted(
    test_database_url: str,
) -> None:
    # patterns列を指定しないINSERT（既存の投入経路）はserver_defaultの空配列になる
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        conn.execute(
            text(
                "INSERT INTO document_type_configs "
                "(id, tenant_id, type_code, display_name, shareable, fields) "
                "VALUES (gen_random_uuid(), 'default', 'quotation', '見積書', true, "
                "'[]'::jsonb)"
            )
        )
        conn.commit()
    with Session(engine) as session:
        config = get_config(session, "default", "quotation")
        assert config is not None
        assert config_pattern_defs(config) == ()
    engine.dispose()
