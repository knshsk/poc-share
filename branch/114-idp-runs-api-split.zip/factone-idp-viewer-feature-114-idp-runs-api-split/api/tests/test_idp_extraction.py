"""IDP抽出結果のパース・正規化・確信度分離のテスト。"""

from app.services.di import DiTable, DiTableCell, QueryFieldResult
from app.services.document_type_config import FieldDef, FieldType, PatternDef
from app.services.idp_extraction import match_patterns, parse_analysis, tables_to_json

ORDER_FIELDS = (
    FieldDef(key="customer_code", label="得意先コード", type=FieldType.STRING),
    FieldDef(key="item_code", label="品目コード", type=FieldType.STRING),
    FieldDef(key="quantity", label="数量", type=FieldType.NUMBER),
    FieldDef(key="delivery_date", label="納期", type=FieldType.DATE),
    FieldDef(key="unit_price", label="単価", type=FieldType.NUMBER),
)


class TestParseAnalysis:
    def test_separates_raw_normalized_and_confidence(self) -> None:
        results = {
            "customer_code": QueryFieldResult(value="C-9001", confidence=0.98),
            "item_code": QueryFieldResult(value="P-9001", confidence=0.95),
            "quantity": QueryFieldResult(value="2", confidence=0.99),
            "delivery_date": QueryFieldResult(value="2026-10-30", confidence=0.97),
            "unit_price": QueryFieldResult(value="500,000", confidence=0.96),
        }
        parsed = parse_analysis(ORDER_FIELDS, results)
        assert parsed.raw["unit_price"] == "500,000"
        assert parsed.normalized["unit_price"] == 500000
        assert parsed.confidence["unit_price"] == 0.96

    def test_normalizes_number_fields_by_type(self) -> None:
        fields = (FieldDef(key="anything", label="任意", type=FieldType.NUMBER),)
        results = {"anything": QueryFieldResult(value="1,200", confidence=0.9)}
        parsed = parse_analysis(fields, results)
        assert parsed.normalized["anything"] == 1200

    def test_normalizes_slash_date_to_iso_by_type(self) -> None:
        fields = (FieldDef(key="some_date", label="日付", type=FieldType.DATE),)
        results = {"some_date": QueryFieldResult(value="2026/10/30", confidence=0.9)}
        parsed = parse_analysis(fields, results)
        assert parsed.normalized["some_date"] == "2026-10-30"

    def test_string_field_passes_through(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"code": QueryFieldResult(value="A-001", confidence=0.9)}
        parsed = parse_analysis(fields, results)
        assert parsed.normalized["code"] == "A-001"

    def test_unparseable_number_keeps_raw_and_nulls_normalized(self) -> None:
        fields = (FieldDef(key="quantity", label="数量", type=FieldType.NUMBER),)
        results = {"quantity": QueryFieldResult(value="二個", confidence=0.4)}
        parsed = parse_analysis(fields, results)
        assert parsed.raw["quantity"] == "二個"
        assert parsed.normalized["quantity"] is None
        assert parsed.confidence["quantity"] == 0.4

    def test_unparseable_date_keeps_raw_and_nulls_normalized(self) -> None:
        fields = (FieldDef(key="delivery_date", label="納期", type=FieldType.DATE),)
        results = {"delivery_date": QueryFieldResult(value="月末", confidence=0.3)}
        parsed = parse_analysis(fields, results)
        assert parsed.raw["delivery_date"] == "月末"
        assert parsed.normalized["delivery_date"] is None

    def test_missing_field_yields_none_for_all_views(self) -> None:
        # 必須項目未抽出: 生値・正規化値・確信度すべてNoneで項目自体は返す
        parsed = parse_analysis(ORDER_FIELDS, {})
        assert parsed.raw["customer_code"] is None
        assert parsed.normalized["customer_code"] is None
        assert parsed.confidence["customer_code"] is None

    def test_extra_fields_outside_defs_are_ignored(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"unexpected": QueryFieldResult(value="x", confidence=0.5)}
        parsed = parse_analysis(fields, results)
        assert "unexpected" not in parsed.raw

    def test_regions_follow_bounding_region_of_each_field(self) -> None:
        # 領域ありは {page_number, polygon}、領域なし・値なしは None。キーは定義全件
        fields = (
            FieldDef(key="code", label="コード", type=FieldType.STRING),
            FieldDef(key="amount", label="金額", type=FieldType.NUMBER),
            FieldDef(key="missing", label="未抽出", type=FieldType.STRING),
        )
        results = {
            "code": QueryFieldResult(
                value="A-1", confidence=0.9, page_number=1, polygon=(1.0, 2.0, 3.0, 2.0)
            ),
            "amount": QueryFieldResult(value="100", confidence=0.8),
        }
        parsed = parse_analysis(fields, results)
        assert parsed.regions == {
            "code": {"page_number": 1, "polygon": [1.0, 2.0, 3.0, 2.0]},
            "amount": None,
            "missing": None,
        }

    def test_region_is_none_when_value_is_none(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {
            "code": QueryFieldResult(
                value=None, confidence=None, page_number=1, polygon=(1.0, 2.0)
            )
        }
        assert parse_analysis(fields, results).regions == {"code": None}


class TestTablesToJson:
    def test_serializes_tables_without_interpretation(self) -> None:
        # 意味付けせずJSON化する（明細特定・項目対応はSaaS責務外）
        tables = (
            DiTable(
                row_count=1,
                column_count=2,
                cells=(
                    DiTableCell(
                        row_index=0,
                        column_index=0,
                        content="品目",
                        kind="columnHeader",
                        page_number=1,
                        polygon=(1.0, 2.0),
                    ),
                    DiTableCell(
                        row_index=0,
                        column_index=1,
                        content="数量",
                        kind=None,
                        page_number=None,
                        polygon=None,
                    ),
                ),
            ),
        )
        assert tables_to_json(tables) == [
            {
                "row_count": 1,
                "column_count": 2,
                "cells": [
                    {
                        "row_index": 0,
                        "column_index": 0,
                        "content": "品目",
                        "kind": "columnHeader",
                        "page_number": 1,
                        "polygon": [1.0, 2.0],
                    },
                    {
                        "row_index": 0,
                        "column_index": 1,
                        "content": "数量",
                        "kind": None,
                        "page_number": None,
                        "polygon": None,
                    },
                ],
            }
        ]

    def test_empty_tables_yield_empty_list(self) -> None:
        assert tables_to_json(()) == []


TCODE = PatternDef(key="TCode", label="登録番号", regex=r"T\d{13}")
QUOTATION_NO = PatternDef(key="QuotationNo", label="見積番号", regex=r"Q-\d{6}")


class TestMatchPatterns:
    def test_returns_all_matches_in_order_with_duplicates(self) -> None:
        # 同一文字列が複数箇所にあれば出現回数分返す（重複除去しない）
        content = (
            "登録番号 T1234567890123\n明細...\nフッタ T1234567890123 T9876543210987"
        )
        result = match_patterns((TCODE,), content)
        assert result == {
            "TCode": {
                "label": "登録番号",
                "regex": r"T\d{13}",
                "values": ["T1234567890123", "T1234567890123", "T9876543210987"],
            }
        }

    def test_multiple_patterns_keep_definition_order(self) -> None:
        content = "見積 Q-000123 / T1234567890123"
        result = match_patterns((TCODE, QUOTATION_NO), content)
        assert list(result) == ["TCode", "QuotationNo"]
        assert result["QuotationNo"]["values"] == ["Q-000123"]

    def test_no_match_keeps_key_with_empty_values(self) -> None:
        result = match_patterns((QUOTATION_NO,), "見積番号なし")
        assert result == {
            "QuotationNo": {"label": "見積番号", "regex": r"Q-\d{6}", "values": []}
        }

    def test_empty_content_yields_empty_values(self) -> None:
        assert match_patterns((TCODE,), "")["TCode"]["values"] == []

    def test_no_patterns_yields_empty_dict(self) -> None:
        assert match_patterns((), "T1234567890123") == {}

    def test_zero_length_matches_are_dropped(self) -> None:
        # `\d*` は文字位置ごとに空文字に一致する。空文字は情報を持たず肥大するため除外
        pattern = PatternDef(key="Digits", label="数字", regex=r"\d*")
        result = match_patterns((pattern,), "ab12cd345")
        assert result["Digits"]["values"] == ["12", "345"]
