"""IDP抽出応答のパース・正規化・確信度分離。

生値（DIが返した文字列）と正規化値・確信度を分離して保持する。
対象フィールドと型は文書種別設定（document_type_configs）由来のFieldDefで受け取る。
全文テキストへの正規表現マッチ（PatternDef）も本モジュールで行う。
"""

import re
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from datetime import date

from app.services.di import DiTable, QueryFieldResult
from app.services.document_type_config import FieldDef, FieldType, PatternDef


@dataclass(frozen=True)
class ParsedExtraction:
    """項目別の生値・正規化値・確信度・読取領域。キーはフィールド定義と同一。"""

    raw: dict[str, str | None]
    normalized: dict[str, str | int | None]
    confidence: dict[str, float | None]
    # {"page_number": int, "polygon": [float, ...]} または None（領域なし・値なし）
    regions: dict[str, dict[str, object] | None]


def _normalize(field_type: FieldType, value: str) -> str | int | None:
    if field_type is FieldType.NUMBER:
        try:
            return int(value.replace(",", ""))
        except ValueError:
            return None
    if field_type is FieldType.DATE:
        try:
            return date.fromisoformat(value.replace("/", "-")).isoformat()
        except ValueError:
            return None
    return value


def tables_to_json(tables: tuple[DiTable, ...]) -> list[dict[str, object]]:
    """テーブル領域（明細仮）をJSON化する。意味付け・正規化は行わない。"""
    serialized = []
    for table in tables:
        data = asdict(table)
        data["cells"] = [
            {**cell, "polygon": list(cell["polygon"]) if cell["polygon"] else None}
            for cell in data["cells"]
        ]
        serialized.append(data)
    return serialized


def parse_analysis(
    fields: Sequence[FieldDef], results: dict[str, QueryFieldResult]
) -> ParsedExtraction:
    raw: dict[str, str | None] = {}
    normalized: dict[str, str | int | None] = {}
    confidence: dict[str, float | None] = {}
    regions: dict[str, dict[str, object] | None] = {}
    for field in fields:
        result = results.get(field.key)
        regions[field.key] = None
        if result is None or result.value is None:
            raw[field.key] = None
            normalized[field.key] = None
            confidence[field.key] = result.confidence if result else None
            continue
        raw[field.key] = result.value
        normalized[field.key] = _normalize(field.type, result.value)
        confidence[field.key] = result.confidence
        if result.page_number is not None and result.polygon is not None:
            regions[field.key] = {
                "page_number": result.page_number,
                "polygon": list(result.polygon),
            }
    return ParsedExtraction(
        raw=raw, normalized=normalized, confidence=confidence, regions=regions
    )


def match_patterns(
    patterns: Sequence[PatternDef], content: str
) -> dict[str, dict[str, object]]:
    """全文テキストに各パターンを適用し、出現順・重複ありの全一致を返す。

    値は一致全体（group 0）。0件でもキーを残す。実行時点のlabel/regexを同梱し、
    設定変更後も当時の条件を再現できるようにする。regexは設定登録時に検証済み。
    長さ0の一致は含めない（`\\d*` 等が文字位置ごとに空文字を生む肥大防止）。
    """
    return {
        p.key: {
            "label": p.label,
            "regex": p.regex,
            "values": [m.group(0) for m in re.finditer(p.regex, content) if m.group(0)],
        }
        for p in patterns
    }
