"""add raw response ref, di info and field regions to idp_runs

DI生応答のBlob保存と実行時情報の記録（#113）。
生応答本体はBlobに置き、参照パスとDIのAPIバージョン・モデルID・項目別読取領域を列として持つ。

Revision ID: c2f7a1d9e4b3
Revises: a9c3e5d7b1f2
Create Date: 2026-09-13 21:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "c2f7a1d9e4b3"
down_revision: str | None = "a9c3e5d7b1f2"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("idp_runs", sa.Column("field_regions", JSONB(), nullable=True))
    op.add_column(
        "idp_runs", sa.Column("di_api_version", sa.String(length=20), nullable=True)
    )
    op.add_column(
        "idp_runs", sa.Column("di_model_id", sa.String(length=100), nullable=True)
    )
    op.add_column(
        "idp_runs",
        sa.Column("raw_response_ref", sa.String(length=1024), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("idp_runs", "raw_response_ref")
    op.drop_column("idp_runs", "di_model_id")
    op.drop_column("idp_runs", "di_api_version")
    op.drop_column("idp_runs", "field_regions")
