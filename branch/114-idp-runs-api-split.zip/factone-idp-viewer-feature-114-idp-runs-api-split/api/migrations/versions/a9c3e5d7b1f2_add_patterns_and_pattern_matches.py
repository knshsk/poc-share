"""add patterns to document_type_configs and pattern_matches to idp_runs

DI全文テキストへの正規表現マッチ（#107）。
設定に patterns（{key, label, regex} 配列）を、実行ログに pattern_matches を追加する。
既存シード2種別（purchase_order / quotation）に登録番号（Tコード）パターンを投入する。

Revision ID: a9c3e5d7b1f2
Revises: b7e3d2a9c1f5
Create Date: 2026-09-09 15:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "a9c3e5d7b1f2"
down_revision: str | None = "b7e3d2a9c1f5"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLE = sa.table(
    "document_type_configs",
    sa.column("tenant_id", sa.String),
    sa.column("type_code", sa.String),
    sa.column("patterns", JSONB),
)

_SEED_PATTERNS = [{"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}]


def upgrade() -> None:
    op.add_column(
        "document_type_configs",
        sa.Column("patterns", JSONB(), nullable=False, server_default="[]"),
    )
    op.add_column("idp_runs", sa.Column("pattern_matches", JSONB(), nullable=True))
    op.execute(
        _TABLE.update()
        .where(
            _TABLE.c.tenant_id == "default",
            _TABLE.c.type_code.in_(["purchase_order", "quotation"]),
        )
        .values(patterns=_SEED_PATTERNS)
    )


def downgrade() -> None:
    op.drop_column("idp_runs", "pattern_matches")
    op.drop_column("document_type_configs", "patterns")
