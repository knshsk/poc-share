import { flushPromises } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const getMock = vi.fn()
const setAccessToken = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
  get setAccessToken() {
    return setAccessToken
  },
}))

import { createMediator } from '../src/mediator/machine'
import { configs, fakeOidc, routeGet, session } from './fixtures'

beforeEach(() => {
  getMock.mockReset()
  getMock.mockImplementation(routeGet())
  setAccessToken.mockReset()
  window.history.replaceState(null, '', '/')
})

describe('Mediator（認証・起動）', () => {
  it('init はパスで public / callback / login に分岐する', () => {
    const pub = createMediator(fakeOidc())
    pub.dispatch({ type: 'init', pathname: '/view/tok-1', search: '' })
    expect(pub.state.value).toBe('public')
    expect(pub.vm.value.screen).toBe('public')
    expect(getMock).toHaveBeenCalledWith(
      '/view/{token}/pages',
      expect.objectContaining({ params: { path: { token: 'tok-1' } } }),
    )

    const cb = createMediator(fakeOidc())
    cb.dispatch({ type: 'init', pathname: '/callback', search: '?code=abc' })
    expect(cb.state.value).toBe('callback')
    // トークン交換中はログインカードでなく読込中の画面（ロゴだけのアプリバー）
    expect(cb.vm.value.screen).toBe('loading')
    expect(cb.vm.value.header).toMatchObject({
      authenticated: false,
      documentId: '',
    })

    const login = createMediator(fakeOidc())
    login.dispatch({ type: 'init', pathname: '/', search: '' })
    expect(login.state.value).toBe('login')
    expect(login.vm.value.header.authenticated).toBe(false)
  })

  // 起動処理中（init 前）も読込中の画面にする（ログインカードを出す余地を残さない）
  it('init 前（booting）は読込中の画面', () => {
    expect(createMediator(fakeOidc()).vm.value.screen).toBe('loading')
  })

  it('/view/ でトークンが空なら login へ倒す', () => {
    const m = createMediator(fakeOidc())
    m.dispatch({ type: 'init', pathname: '/view/', search: '' })
    expect(m.state.value).toBe('login')
    expect(getMock).not.toHaveBeenCalled()
  })

  // 起動前（booting）以外で init を受けない＝二重初期化しない
  it('init は booting 状態でだけ受ける', () => {
    const m = createMediator(fakeOidc())
    m.dispatch({ type: 'init', pathname: '/', search: '' })
    m.dispatch({ type: 'init', pathname: '/view/tok-1', search: '' })
    expect(m.state.value).toBe('login')
  })

  it('login は未認証のときだけ oidc.login を呼ぶ', () => {
    const oidc = fakeOidc()
    const m = createMediator(oidc)
    m.dispatch({ type: 'login' })
    expect(oidc.login).not.toHaveBeenCalled()

    m.dispatch({ type: 'init', pathname: '/', search: '' })
    m.dispatch({ type: 'login' })
    expect(oidc.login).toHaveBeenCalledOnce()
  })

  // コールバック成功でトークンを保持し、文書なし（empty）へ。種別一覧を取得して登録フォームへ渡す
  it('コールバック成功で empty へ遷移し、トークン設定と種別一覧取得を行う', async () => {
    const m = createMediator(fakeOidc())
    m.dispatch({ type: 'init', pathname: '/callback', search: '?code=abc' })
    await flushPromises()

    expect(setAccessToken).toHaveBeenCalledWith(session.accessToken)
    expect(m.state.value).toBe('empty')
    expect(m.vm.value.header).toMatchObject({
      authenticated: true,
      username: 'testuser',
    })
    expect(m.vm.value.document?.phase).toBe('empty')
    // 文書 ID が無ければ文書選択ダイアログを開く
    expect(m.vm.value.document?.picker.open).toBe(true)
    expect(m.vm.value.document?.picker.register.typeItems).toEqual(configs)
  })

  it('種別一覧の取得に失敗しても empty のまま続行し、登録フォームに失敗を出す', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/config/document-types'
        ? Promise.reject(new Error('x'))
        : routeGet()(path),
    )
    const m = createMediator(fakeOidc())
    m.dispatch({ type: 'init', pathname: '/callback', search: '' })
    await flushPromises()
    expect(m.state.value).toBe('empty')
    expect(m.vm.value.document?.picker.register).toMatchObject({
      typeItems: [],
      typesFailed: true,
    })
  })

  // 復元後 URL（oidc.handleCallback が replaceState 済み）に document_id があればその文書を開く
  it('コールバック後の URL に document_id があれば文書を開く', async () => {
    const oidc = fakeOidc()
    oidc.handleCallback.mockImplementation(async () => {
      window.history.replaceState(null, '', '/?document_id=doc-1')
      return session
    })
    const m = createMediator(oidc)
    m.dispatch({ type: 'init', pathname: '/callback', search: '?code=abc' })
    await flushPromises()

    expect(m.vm.value.header.documentId).toBe('doc-1')
    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    // 文書を開くときは文書選択ダイアログを開かない
    expect(m.vm.value.document?.picker.open).toBe(false)
  })

  it('コールバック失敗（ユーザー無し・例外）は login へ戻る', async () => {
    const noUser = fakeOidc()
    noUser.handleCallback.mockResolvedValue(null)
    const a = createMediator(noUser)
    a.dispatch({ type: 'init', pathname: '/callback', search: '' })
    await flushPromises()
    expect(a.state.value).toBe('login')
    expect(a.vm.value.screen).toBe('login')

    const thrown = fakeOidc()
    thrown.handleCallback.mockRejectedValue(new Error('x'))
    const b = createMediator(thrown)
    b.dispatch({ type: 'init', pathname: '/callback', search: '' })
    await flushPromises()
    expect(b.state.value).toBe('login')
    expect(setAccessToken).not.toHaveBeenCalled()
  })

  it('logout はトークンとユーザー名を消して login へ遷移し signoutRedirect する', async () => {
    const oidc = fakeOidc()
    const m = createMediator(oidc)
    m.dispatch({ type: 'init', pathname: '/callback', search: '' })
    await flushPromises()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(m.vm.value.header.documentId).toBe('doc-1')

    m.dispatch({ type: 'logout' })

    expect(setAccessToken).toHaveBeenLastCalledWith(null)
    expect(m.state.value).toBe('login')
    expect(m.vm.value.header.username).toBeNull()
    expect(m.vm.value.header.documentId).toBe('')
    expect(oidc.logout).toHaveBeenCalledOnce()
  })
})
