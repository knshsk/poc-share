import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// API呼出はapiClient経由のためモックする（フォームは種別一覧・送信・エラー表示が検証対象）
const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
}))

import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'

const configs = [
  {
    type_code: 'quote',
    display_name: '御見積書',
    shareable: true,
    fields: [],
    created_at: '2026-08-01T00:00:00Z',
    updated_at: '2026-08-01T00:00:00Z',
  },
  {
    type_code: 'order_project',
    display_name: '注文書（案件）',
    shareable: false,
    fields: [],
    created_at: '2026-08-01T00:00:00Z',
    updated_at: '2026-08-01T00:00:00Z',
  },
]

const pdf = new File(['%PDF-1.4'], 'order.pdf', { type: 'application/pdf' })

function mountForm() {
  return mount(DocumentRegisterForm, {
    global: { plugins: [createAppVuetify()] },
  })
}

// 文書ID・種別・PDFを入力済みにする
async function fillForm(wrapper: ReturnType<typeof mountForm>) {
  await wrapper
    .get('[data-testid="register-document-id"] input')
    .setValue('doc-9')
  await wrapper
    .findComponent({ name: 'VSelect' })
    .vm.$emit('update:modelValue', 'quote')
  await wrapper
    .findComponent({ name: 'VFileInput' })
    .vm.$emit('update:modelValue', pdf)
  await flushPromises()
}

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
  getMock.mockResolvedValue({ data: configs, error: undefined })
})

describe('DocumentRegisterForm', () => {
  // マウント時に種別設定を取得し、display_nameを選択肢として表示することを確認する
  it('マウント時に種別一覧を取得し選択肢に表示する', async () => {
    const wrapper = mountForm()
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith('/api/v1/config/document-types')
    const select = wrapper.findComponent({ name: 'VSelect' })
    expect(select.props('items')).toEqual(configs)
    expect(select.props('itemTitle')).toBe('display_name')
    expect(select.props('itemValue')).toBe('type_code')
  })

  // 入力値をmultipartで登録APIへ送信し、成功時に文書IDをemitすることを確認する
  it('送信で登録APIをmultipart呼出し成功時にregisteredをemitする', async () => {
    postMock.mockResolvedValue({
      data: { document_id: 'doc-9', document_type: 'quote' },
      error: undefined,
      response: { status: 201 },
    })
    const wrapper = mountForm()
    await flushPromises()
    await fillForm(wrapper)

    await wrapper.get('form').trigger('submit')
    await flushPromises()

    expect(postMock).toHaveBeenCalledTimes(1)
    const [path, options] = postMock.mock.calls[0]!
    expect(path).toBe('/api/v1/documents')
    const body = options.bodySerializer(options.body) as FormData
    expect(body).toBeInstanceOf(FormData)
    expect(body.get('document_id')).toBe('doc-9')
    expect(body.get('document_type')).toBe('quote')
    expect(body.get('file')).toBe(pdf)
    expect(wrapper.emitted('registered')).toEqual([['doc-9']])
  })

  // 未入力（文書ID・種別・PDFのいずれか欠落）では送信しないことを確認する
  it('未入力では送信しない', async () => {
    const wrapper = mountForm()
    await flushPromises()

    await wrapper.get('form').trigger('submit')
    await flushPromises()

    expect(postMock).not.toHaveBeenCalled()
  })

  // 409（同一文書IDが別内容で登録済み）は専用メッセージを表示しemitしないことを確認する
  it('409は別内容で登録済みのエラーを表示しemitしない', async () => {
    postMock.mockResolvedValue({
      data: undefined,
      error: {
        type: '/errors/document-conflict',
        title: 'Document conflict',
        status: 409,
        detail: 'Document ID already registered with different content',
      },
      response: { status: 409 },
    })
    const wrapper = mountForm()
    await flushPromises()
    await fillForm(wrapper)

    await wrapper.get('form').trigger('submit')
    await flushPromises()

    expect(wrapper.get('[data-testid="register-error"]').text()).toContain(
      '文書IDは別の内容で登録済み',
    )
    expect(wrapper.emitted('registered')).toBeUndefined()
  })

  // 409以外のエラーはProblem Detailsのdetailをそのまま表示することを確認する
  it('その他のエラーはProblem Detailsのdetailを表示する', async () => {
    postMock.mockResolvedValue({
      data: undefined,
      error: {
        type: '/errors/unknown-document-type',
        title: 'Unknown document type',
        status: 422,
        detail: 'Unknown document type for this tenant',
      },
      response: { status: 422 },
    })
    const wrapper = mountForm()
    await flushPromises()
    await fillForm(wrapper)

    await wrapper.get('form').trigger('submit')
    await flushPromises()

    expect(wrapper.get('[data-testid="register-error"]').text()).toContain(
      'Unknown document type for this tenant',
    )
  })
})
