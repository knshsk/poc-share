# ADR（Architecture Decision Record）

アーキテクチャ上の意思決定を記録するディレクトリ。

- テンプレート: [0000-adr-template.md](0000-adr-template.md)
- ファイル名は `NNNN-<決定内容の簡潔な説明>.md`（連番4桁）とする。
- 決定の背景・却下した代替案・トレードオフを記録する。設計ドキュメント本体には確定事項のみを記述する。
