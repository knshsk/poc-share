# API 開発ガイド

バックエンドAPI（`api/`）の起動・テスト実行手順。

## 前提条件

- [uv](https://docs.astral.sh/uv/) がインストールされていること

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Python本体は uv が自動で取得するため、個別インストールは不要。

## セットアップ

```bash
cd api
uv sync
```

依存パッケージと仮想環境（`api/.venv/`）が作成される。

## データベースのマイグレーション

スキーマはAlembicで管理する。ローカルスタックのPostgreSQL起動後、初回およびスキーマ変更時に適用する。

```bash
cd api
uv run alembic upgrade head
```

モデル（`app/models.py`）を変更した場合のマイグレーション作成:

```bash
cd api
uv run alembic revision --autogenerate -m "<変更内容>"
```

## 起動

```bash
cd api
uv run uvicorn --factory app.main:create_app --reload
```

起動後、`http://127.0.0.1:8000/health` にアクセスして `{"status": "ok"}` が返れば成功。

## テスト実行

```bash
cd api
uv run pytest
```

## API契約の型共有（OpenAPI → TypeScript）

API契約は Pydantic モデルを単一情報源とし、以下を生成物としてコミットする。

- `docs/api/openapi.json` — OpenAPIスキーマのエクスポート（外部向け契約レビュー・共有用の正）
- `viewer/src/api/schema.d.ts` — openapi-typescript による TypeScript 型

APIのエンドポイントやモデルを変更したら再生成してコミットする:

```bash
cd viewer
npm run generate:api
```

生成物が古いまま（ドリフト）だと pre-commit の「API契約生成物の差分チェック」が失敗する。

## 設定

アプリケーション設定は `app/config.py` の `Settings` で管理する。
環境変数（プレフィックス `FACTONE_`）またはリポジトリルートの `.env` ファイルから読み込む（起動ディレクトリに依存しない）。ローカルスタック用の変数（`POSTGRES_*` 等）と同じファイルに集約し、`FACTONE_` プレフィックスの有無で区別する。

例: アプリケーション名を変更する場合

```bash
FACTONE_APP_NAME=my-api uv run uvicorn --factory app.main:create_app
```

### Document Intelligence接続

IDP実行APIを実サービスに接続する場合、ルートの `.env` に以下を設定する（未設定時は実行APIが502を返す）。

```bash
# APIキー未設定時はManaged ID認証（Azure上での実行向け）
FACTONE_DI_ENDPOINT=https://<resource-name>.cognitiveservices.azure.com/
FACTONE_DI_API_KEY=<key>
```
