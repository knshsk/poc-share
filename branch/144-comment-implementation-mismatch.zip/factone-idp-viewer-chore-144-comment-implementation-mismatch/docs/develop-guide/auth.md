# ローカル認証動作手順

Keycloakを使った認証付きの動作確認手順。前提として [local-stack.md](local-stack.md)・[api.md](api.md)・[viewer.md](viewer.md) のセットアップが完了していること。

## 1. ローカルスタック起動とテストユーザー設定

```bash
podman compose up -d
```

初回起動（またはボリューム初期化後）は、realmインポート完了を待ってからテストユーザーのパスワードを設定する。

```bash
./scripts/local-stack/apply-keycloak-secrets.sh
```

`.env` の `KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD` で管理者ログインし、`KC_TEST_USER_PASSWORD`（テストユーザー）と `KC_INTEGRATION_CLIENT_SECRET`（M2M連携クライアント）が設定される。realm定義JSONにはシークレットを含めない運用のため、このスクリプトでの設定が必要（Keycloakのrealmインポートは環境変数置換を行わない）。

## M2M（サーバ間）呼出

外部システム連携用クライアント `factone-integration`（client credentials grant）でトークンを取得できる。

```bash
curl -d 'grant_type=client_credentials&client_id=factone-integration&client_secret=<シークレット>' http://localhost:8080/realms/factone/protocol/openid-connect/token
```

## 2. API・Viewer起動

```bash
cd api
uv run uvicorn --factory app.main:create_app --reload
```

```bash
cd viewer
npm run dev
```

## 3. 動作確認

1. `http://localhost:5173/` を開く
2. 「ログイン」→ Keycloakのログイン画面で `testuser` / `.env` のパスワードを入力
3. ログイン後、文書閲覧画面（文書 ID の入力）が表示され、ヘッダのユーザーメニューにユーザー名が出る
4. 「ログアウト」で未認証状態に戻る

## 構成メモ

- 認証フロー: 認可コードフロー+PKCE（S256必須）。クライアントは `factone-viewer`（public）
- アクセストークン: Viewer側でメモリ保持（永続化なし）。API呼出時に `Authorization: Bearer` 付与
- API側検証: 署名（KeycloakのJWKS、RS256のみ）・issuer・audience（`factone-api`）・有効期限・`sub` の存在
- ローカルのAPI呼出はVite devプロキシ（`/api` と `/view/{token}/pages|pdf` → `localhost:8000`）で同一オリジン化
- 設定の上書き: API側は環境変数 `FACTONE_OIDC_ISSUER` / `FACTONE_OIDC_AUDIENCE`、Viewer側は `VITE_OIDC_AUTHORITY` / `VITE_OIDC_CLIENT_ID`
- テナント識別・ロール・文書アクセス認可は未実装（未確定事項の解消後に対応）
