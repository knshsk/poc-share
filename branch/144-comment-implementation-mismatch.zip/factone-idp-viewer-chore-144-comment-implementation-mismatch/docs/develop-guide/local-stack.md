# ローカル開発スタック起動手順

ローカル開発で使用するKeycloak・PostgreSQLをコンテナで起動する手順。

## 前提条件

- [wsl-setup.md](wsl-setup.md) の環境構築（WSL2+Ubuntu 24.04、プロキシ設定、Podman導入）が完了していること

## 初回セットアップ

リポジトリルートで環境変数ファイルを作成する。

```bash
cp .env.example .env
```

`.env` の `changeme-` で始まる値をローカル用の任意の値に書き換える。`.env` はGit管理対象外。

## 起動

```bash
podman compose up -d
```

- PostgreSQL起動 → ヘルスチェック通過後にKeycloakが起動する。
- 初回起動時に以下が自動実行される。
  - Keycloak用DB・ユーザーの作成（`scripts/local-stack/init-keycloak-db.sh`）
  - realm定義の投入（`keycloak/realm/factone.json` を `--import-realm` で投入）

## 接続先

| サービス | URL / 接続先 | 認証情報 |
| --- | --- | --- |
| Keycloak管理コンソール | http://localhost:8080 | `.env` の `KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD` |
| PostgreSQL（アプリ用DB） | localhost:5432 / DB名 `factone` | `.env` の `POSTGRES_USER` / `POSTGRES_PASSWORD` |
| PostgreSQL（Keycloak用DB） | localhost:5432 / DB名 `keycloak` | `.env` の `KEYCLOAK_DB_USER` / `KEYCLOAK_DB_PASSWORD` |

## 停止

```bash
podman compose down
```

データ（PostgreSQLボリューム）は保持される。

## 初期化（データ削除）

realm定義の変更を反映したい場合や環境を作り直したい場合は、ボリュームごと削除して再起動する。

> **警告:** 以下のコマンドはローカルPostgreSQLの全データ（アプリ用DB・Keycloak用DBの両方）を削除する。取り消しはできない。

```bash
podman compose down -v
```

その後 `podman compose up -d` で再作成される。

## トラブルシュート

- **Keycloakが起動しない**: `podman compose logs keycloak` を確認する。DB接続エラーの場合はPostgreSQLのヘルスチェック状態（`podman compose ps`）を確認する。
- **realm定義の変更が反映されない**: 既存realmがある場合 `--import-realm` はスキップされる。上記「初期化」を実施する。
- **`.env` の変更が反映されない**: コンテナ再作成が必要。`podman compose up -d --force-recreate` を実行する。ただしDB系の資格情報は初回起動時にデータボリュームへ焼き込まれるため、変更する場合は初期化が必要。
