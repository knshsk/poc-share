# WSL開発環境構築手順

ローカル開発の前提となるWSL2（Ubuntu 24.04）+ Podman環境を構築する手順。マシンごとに1回だけ実施する。

日常のスタック起動・停止は [local-stack.md](local-stack.md) を参照。

## 前提条件

- OA PC（Windows 11）のセットアップ済み
- 管理者権限パスワードを発行済み

## 1. WSL2とUbuntu 24.04の導入

PowerShell（管理者）で実行する。

```powershell
wsl --update
wsl --install Ubuntu-24.04
```

- 初回起動時にUbuntuのユーザー名・パスワードを設定する。
- 任意の名前でディストリビューションをインストールしたい場合は `--name <任意の名前>` を指定する（例: `--name Ubuntu-24.04-factone`）
- 既定ディストリビューションにする場合は `wsl --set-default Ubuntu-24.04` を実行する。
  - `--name` を指定した場合はその名前を指定する。

### systemdの確認

Podmanのrootless実行（ヘルスチェック等）にsystemdが必要。Ubuntu 24.04の新規導入では既定で有効だが、確認しておく。

```bash
systemctl is-system-running
```

`running` または `degraded` 以外（`offline` 等）の場合は `/etc/wsl.conf` に以下を追記し、PowerShellから `wsl --shutdown` 後に再起動する。

```ini
[boot]
systemd=true
```

## 2. プロキシ設定

### 2-1. 環境変数

`~/.bashrc` の末尾に追記する（`<user>` `<pass>` `<proxy-host>` `<port>` は実際の値に置換。パスワードに記号を含む場合はURLエンコードが必要）。

```bash
export http_proxy="http://<user>:<pass>@<proxy-host>:<port>"
export https_proxy="$http_proxy"
export HTTP_PROXY="$http_proxy"
export HTTPS_PROXY="$http_proxy"
export no_proxy="localhost,127.0.0.1"
export NO_PROXY="localhost,127.0.0.1"
```

反映は `source ~/.bashrc` または再ログイン。

> **注意:** `~/.bashrc` にプロキシパスワードが平文で残る。ファイル権限（`chmod 600 ~/.bashrc`）と取り扱いに注意すること。

### 2-2. apt

aptは環境変数を参照しないため個別設定する。`/etc/apt/apt.conf.d/95proxy` を作成する。

```bash
sudo tee /etc/apt/apt.conf.d/95proxy > /dev/null <<'EOF'
Acquire::http::Proxy "http://<user>:<pass>@<proxy-host>:<port>";
Acquire::https::Proxy "http://<user>:<pass>@<proxy-host>:<port>";
EOF
```

## 3. Podman

### 3-1. Podmanの導入

```bash
sudo apt-get update
sudo apt-get install -y podman podman-compose
```

`podman compose` サブコマンド（podman 4.7以降）が `podman-compose` へ委譲する構成になる。

### 3-2. compose providerの固定

Windows側に残っているDocker Desktop等の `docker-compose` を誤って拾わないように、委譲先を `podman-compose` に固定する。

```bash
mkdir -p ~/.config/containers
printf '[engine]\ncompose_providers = ["/usr/bin/podman-compose"]\n' > ~/.config/containers/containers.conf
```

### 3-3. 動作確認

```bash
podman compose version
```

```bash
podman run docker.io/library/hello-world
```

イメージ取得が成功し、 `Hello from Docker!` が出力されれば動作確認完了。

## 4. nvm + Node.js v24

Node.jsをnvm（Node.jsのバージョン管理ツール）経由でインストールする。

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.7/install.sh | bash
source ~/.bashrc
nvm install 24 # LTS最新版
node -v
> v24.19.0
```

> [!NOTE]
> `nvm@040.7` は本資料作成時点の最新バージョン。
> [公式リポジトリ](https://github.com/nvm-sh/nvm)で最新版を確認する。

## 5. uv + Python 3.14

Pythonの仮想環境・依存関係はすべてuvが管理する（`uv sync`）。

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
source ~/.bashrc
uv --version
> uv 0.12.5 (x86_64-unknown-linux-gnu)
uv python install 3.14
```

## 6. Azure CLI（venv版）

### 6-1. Azure CLIの導入

Azure CLI（`az` コマンド群）をvenvでインストールする。

> [!NOTE]
> 社内プロキシサーバの暗号スイートの問題。
> apt、公式インストールスクリプト同梱のPythonでは、対応する暗号スイートが無効化されているため通信時エラーとなる。
> そのため、特定バージョンのPython（`pip`）で `az` をインストールして利用する必要がある。

```bash
sudo apt install python3-pip
uv venv -p 3.12 ~/.azure-cli-venv
source ~/.azure-cli-venv/bin/activate
# 仮想環境が有効化された状態でインストール
(.azure-cli-venv)$ uv pip install azure-cli
```

デバイスコードを使用してログインする。
以下のURLにアクセスし、デバイスコードを入力すると、アカウントに紐づけられているサブスクリプションが表示される。

```bash
(.azure-cli-venv)$ az login --tenant <開発環境のテナントID> --use-device-code
~
# 利用したいサブスクリプション番号を入力してEnter
> Select a subscription and tenant (Type a number or Enter for no changes):

(.azure-cli-venv)$ az group list
> サブスクリプションのリソースグループ一覧が表示されることを確認
```

`.azure-cli-venv` 配下の `az` を標準で使うようにパスを設定する。

`~/.bashrc` 末尾に以下を追加:

```bash
export PATH="$HOME/.azure-cli-venv/bin:$PATH"
```

追加後、パスが通っていることを確認する。

```bash
source ~/.bashrc
which az
> ~/.azure-cli-venv/bin/az
```

### 6-2. bicepモジュールの導入

Bicepデプロイ用にbicepモジュールをインストールする。

```bash
az bicep install
az bicep version
> Bicep CLI version 0.46.1 (545b338e2c)
```

続けて [local-stack.md](local-stack.md) の手順でローカルスタックを起動する（リポジトリのclone・git設定は済んでいる前提）。

## トラブルシュート

- **`407 Proxy Authentication Required`**: プロキシの資格情報が誤っている。パスワードのURLエンコード漏れ（`@` → `%40` 等）を確認する。
- **aptだけ失敗する**: aptは環境変数を参照しない。「2-2」の設定を確認する。
- **`podman compose` がWindows側の `docker-compose`（`/mnt/c/...`）を実行して失敗する**: compose providerの探索がWindows側PATHのバイナリを拾っている。「3. compose providerの固定」を実施する。Windows側のDocker Desktopが不要であればアンインストールを推奨する（有償ライセンス制約により利用不可のため）。
- **`/etc/wsl.conf` の変更が効かない**: PowerShellから `wsl --shutdown` を実行し、WSLを完全再起動する。
- **ヘルスチェックが動かない・コンテナ状態が `starting` のまま**: systemdが無効の可能性がある。「1」のsystemd確認を実施する。
