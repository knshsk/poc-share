# 認証・認可

## 役割

誰が何を使って本システムに認証されるかを定める。認証は IdP（Keycloak）が発行する JWT の検証に一本化し、本システムはログイン画面・資格情報・セッションを持たない。認可（ロール・テナント・文書単位のアクセス制御）は未実装で、認証済みなら全操作ができる。閲覧者は認証せず、閲覧 URL の不透明トークンだけで文書に到達する。

## 構成

```mermaid
flowchart LR
    spa["Viewer SPA"]
    integ["外部連携システム"]
    viewer(["閲覧者"])
    kc["Keycloak realm factone"]
    api["API"]

    spa -- "Authorization Code + PKCE（client: factone-viewer）" --> kc
    integ -- "client credentials（client: factone-integration）" --> kc
    spa -- "Bearer JWT" --> api
    integ -- "Bearer JWT" --> api
    viewer -- "/view/{token}（無認証）" --> api
    api -- "JWKS 取得" --> kc
```

- API は JWT の発行元クライアントを区別しない。issuer・audience・有効期限・署名が正しければ SPA 用でも M2M 用でも同じ操作ができる
- SPA 側の画面は「ログイン」ボタンだけで、資格情報の入力は Keycloak のログイン画面で行う。SPA はリダイレクトで往復するだけ

## 主要処理の流れ

### テナント利用者（SPA）のログイン

1. 未認証の SPA は「ログイン」で `oidc-client-ts` の `signinRedirect` を呼ぶ。scope `openid`、`redirect_uri` は `{origin}/callback`、ログイン前の URL（`?document_id=` を含む）を state に入れる
2. Keycloak でログイン後 `/callback` に戻る。SPA は `signinCallback` でトークンを受け取り、state の URL へ復元する。復元先は同一オリジンの相対パス（`/` 始まりかつ `//` 始まりでない）に限る（オープンリダイレクト防止）
3. アクセストークンはメモリだけに保持し、localStorage 等に書かない（[ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md)）。API 呼出時に `Authorization: Bearer` を付ける
4. ログアウトはストアのトークン・ユーザー名・認証済フラグを消して `signoutRedirect`（戻り先は自オリジン）

### 外部連携システム（M2M）

`factone-integration` の client credentials grant で Keycloak のトークンエンドポイントからアクセストークンを得て、Bearer で API を呼ぶ。クライアントシークレットは realm 定義に含めず、起動後に投入する（後述）。

### JWT 検証（API、`core/auth.py`）

1. `Authorization: Bearer` が無ければ 401（`unauthenticated`）
2. `KeySource.get_verification_key(token)` で検証鍵を得る。`create_app` に指定が無ければ `JwksKeySource`（Keycloak の `{issuer}/protocol/openid-connect/certs`。`PyJWKClient` がキャッシュする）。テストは `StaticKeySource` を引数で注入する
3. `jwt.decode` で検証する。アルゴリズムは RS256 のみ、`iss` = `FACTONE_OIDC_ISSUER`、`aud` = `FACTONE_OIDC_AUDIENCE`（既定 `factone-api`）、必須クレームは `exp` / `iss` / `aud` / `sub`。失敗は 401（`invalid-token`）
4. `AuthenticatedUser(sub, username)` を返す。`username` は `preferred_username`、無ければ空文字。人手修正の `corrected_by` には `username`、空なら `sub` を記録する

audience は realm の両クライアントに付けた audience マッパー（`factone-api-audience`）がアクセストークンに入れる。

### テナント解決

現状はテナントを解決しない。全 API が設定値 `FACTONE_TENANT_ID`（既定 `default`）を使い、文書・文書種別設定をこの値で絞る。JWT のクレームからテナントを取る仕組みと、realm 分離 or 単一 realm + テナントクレームの選択は未確定。確定後にここと `core/auth.py` を更新する。

### 閲覧者

認証しない。閲覧 URL の不透明トークン（256 bit 乱数）が唯一の鍵で、API はハッシュ一致・未失効・期限内を確認する（[ADR-0011](../adr/0011-view-url-opaque-token.md)、[view-url.md](view-url.md)）。

## 外部依存・設定

- Keycloak realm `factone`（`keycloak/realm/factone.json` が正。管理コンソールでの変更は JSON に反映されず realm 再作成で失われる。運用ルールは [keycloak/README.md](../../keycloak/README.md)）
  - realm 設定: `sslRequired: external`、セルフ登録無効、メールでのログイン可、総当り防御有効
  - `factone-viewer`: public クライアント、standard flow（認可コード）、PKCE S256 必須、direct access grant 無効。redirect URI（`http://localhost:5173/*`）・web origin（`http://localhost:5173`）・ログアウト後の戻り先は realm 定義ではローカルのみで、Azure の URL はデプロイ後に `kcadm` で追加する（稼働 realm は JSON と完全には一致しない）
  - `factone-integration`: confidential クライアント、service accounts（client credentials）のみ。シークレットは realm 定義に含めない
  - 両クライアントに audience マッパー `factone-api-audience`
  - realm ロールなし。テストユーザー `testuser`（パスワードは定義に含めない）
- シークレットの投入: realm インポートは環境変数を置換しないため、`testuser` のパスワードと `factone-integration` のシークレットは起動後に `kcadm` で設定する。ローカルは `scripts/local-stack/apply-keycloak-secrets.sh`（`.env` の `KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD` で管理者ログインし、`KC_TEST_USER_PASSWORD` / `KC_INTEGRATION_CLIENT_SECRET` を投入）、Azure は [develop-guide/deploy.md](../develop-guide/deploy.md) の手順
- API: `FACTONE_OIDC_ISSUER`（既定 `http://localhost:8080/realms/factone`）、`FACTONE_OIDC_AUDIENCE`（既定 `factone-api`）
- Viewer: ビルド時の `VITE_OIDC_AUTHORITY`（既定 `http://localhost:8080/realms/factone`）、`VITE_OIDC_CLIENT_ID`（既定 `factone-viewer`）
- ローカルの API 呼出は Vite dev サーバのプロキシ（`/api` と `/view/{token}/pages|pdf`）で同一オリジン化する。Azure は API が SPA を同梱配信するため同一オリジン

## 詳細仕様への導線

- [develop-guide/auth.md](../develop-guide/auth.md)（ローカルでの動作確認・M2M のトークン取得例）
- [keycloak/README.md](../../keycloak/README.md)（realm 運用ルール）
- [ADR-0006](../adr/0006-keycloak-as-idp.md)（Keycloak 採用）、[ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md)（SPA の OIDC + PKCE）、[ADR-0010](../adr/0010-blob-access-full-api-proxy.md)（Blob の API プロキシ）、[ADR-0011](../adr/0011-view-url-opaque-token.md)（不透明トークン）
- [azure/README.md](../azure/README.md)（Keycloak Container App、Managed ID）
