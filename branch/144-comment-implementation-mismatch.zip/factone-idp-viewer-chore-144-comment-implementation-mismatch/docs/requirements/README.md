# requirements

IDP/Viewerに求められる機能要件をコンポーネント単位で整理したドキュメントを格納するディレクトリ。

## ドキュメント一覧

| ファイル | 内容 |
| --- | --- |
| [viewer.md](viewer.md) | Viewer（画面）の機能要件（要件ID: VW-xx） |
| [idp.md](idp.md) | IDP（API）の機能要件（要件ID: IDP-xx） |

## 対象

- 業務ドキュメント（`../business/`）から導出した、IDP/Viewerがシステムとして満たすべき機能要件
- 各要件の出所となる業務工程（K1〜K5・R1）と、関連するPoC対象外事項（OUT-xx）の紐付け

## 出所

本ディレクトリの要件は以下から導出している。

- [../business/operation-flow.md](../business/operation-flow.md) — レーン定義（レーン7: Viewer、レーン8: IDP）と各工程のシーケンス図
- [../business/out-of-scope.md](../business/out-of-scope.md) — PoC対象外事項（縮退仕様）
- [../business/factone-concept.md](../business/factone-concept.md) — PJ全体構想・検証観点

## IDP/Viewer共通事項

- ViewerとIDPは同一のマルチテナントSaaSの2つの提供形態である。Viewerは画面、IDPはAPIとして提供する。Viewer画面の「IDP実行」ボタンから同一SaaS内のIDPを呼び出す。
- 案件ID・ルートIDは受領・保持しない。これらは顧客の業務体系に属するキーであり、採番・解決・付与はPower Automateの責務である。
- 文書IDは自ら解決・採番しない。呼出側からパラメータで受領するのみとする。
- 本PoCでは性能・可用性・セキュリティ・テナント分離の評価・保証は対象外とする（OUT-08a・OUT-08b）。ただし接続認証・最小権限・文書IDのテナント跨ぎの一意性確認はPoCでも実施する。

## 記述方針

- 確定事項のみを記述し、決定に至る経緯・却下案は `../adr/` に記録する。
- 業務フロー・業務要件そのものは `../business/` に委ね、本ディレクトリは「IDP/Viewerが何を提供するか」の機能要件に限定する。
- 技術的な実現方式（API仕様・データモデル・画面設計）は記述せず、`../api/`・`../data-model/`・`../viewer/` 等の設計ドキュメントに委ねる。
- 要件には要件ID（VW-xx / IDP-xx）を付与し、出所工程（K2〜R1）・関連対象外事項（OUT-xx）を紐付ける。
