# docs

設計・開発に関するドキュメント。初めて読む場合は次の順に読む。

## 読み順

1. **PoC 要件（L0）** — [business/](business/README.md)、[requirements/](requirements/README.md)。本 PoC でテナントがどう使うか。業務フロー・機能要件・対象外事項
2. **全体像（L1）** — [architecture/overview.md](architecture/overview.md)。マルチテナント SaaS としての IDP/Viewer の構成と主要ユースケース。**リポジトリ初見ならここから**
3. **モジュール構成（L2）** — [architecture/](architecture/README.md)（API・Viewer・認証・閲覧 URL）、[azure/](azure/README.md)。各モジュールの構成・主要処理・外部依存
4. **詳細仕様（L3）** — [data-model/](data-model/README.md)、[api/](api/README.md)、[viewer/](viewer/README.md)。テーブル定義・API 契約・画面部品

横断:

- [adr/](adr/README.md) — 決定の経緯・却下案。設計文書には確定事項のみを書き、経緯はここに記録する
- [develop-guide/](develop-guide/README.md) — 環境構築・起動・テスト・デプロイの手順

L0〜L3 は抽象度の段階。L0 が「この PoC で何をするか」、L1 が「システム全体が何でできているか」、L2 が「各モジュールがどう動くか」、L3 が「個々の定義と契約」。

L1/L2 にはテナント固有の外部システム名（PoC の題材）を書かない。外部の主体は役割名（テナント利用者・外部連携システム・閲覧者）で表し、固有の利用形態は L0 に閉じる。本システムの構成要素である製品名（Keycloak、Azure Document Intelligence など）は書く。

## ディレクトリ一覧

| ディレクトリ | 層 | 内容 |
| --- | --- | --- |
| `business/` | L0 | 業務フロー・業務要件・PoC 対象外事項 |
| `requirements/` | L0 | IDP/Viewer の機能要件（業務ドキュメントからの導出） |
| `architecture/` | L1/L2 | 全体像と、モジュールを横断する構成（API・Viewer・認証・閲覧 URL） |
| `azure/` | L2 | Azure 上のリソース構成と各サービスの設計 |
| `data-model/` | L3 | テーブル定義とリレーション |
| `api/` | L3 | API 契約（OpenAPI エクスポート・バージョニング・エラー応答） |
| `viewer/` | L3 | Viewer の画面設計 |
| `adr/` | 横断 | Architecture Decision Record |
| `develop-guide/` | 横断 | 開発者向け手順 |
