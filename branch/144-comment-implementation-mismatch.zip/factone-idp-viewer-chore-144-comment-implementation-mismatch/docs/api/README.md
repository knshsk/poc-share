# API設計ドキュメント

API（FastAPI）に関する設計ドキュメントを格納するディレクトリ。

- OpenAPIスキーマのエクスポートを含む。外部連携システム向けの公開契約はここに固定し、レビュー・共有する。
- API契約の型共有はPydanticモデルを単一情報源とし、OpenAPI経由でTypeScript型を生成する。

## バージョニング（ADR-0017）

認証ありAPIは `/api/v1/**` に配置する。バージョンはURLパスで表す。

- 版付与対象: `/api/**` のみ。顧客向け閲覧URL `/view/{token}/**` とヘルスチェック `/health` は無版
- 版はメジャーのみ（`v1`, `v2`）。破壊的変更を行うときに限り上げる
- 破壊的変更: レスポンスのフィールド削除・改名・型変更・意味変更、リクエストの必須化、エンドポイントの削除・パス変更
- 追加的変更（フィールド・エンドポイント・エラーcode・任意パラメータの追加）は同一版内で行う
- 破壊的変更時は `/api/v2/**` を並行公開し、`/api/v1/**` の廃止期限をこの節に明記する

現在の版: `v1`（廃止予定なし）

### 外部利用者接続前の破壊的変更（記録）

外部連携システムが未接続の間は、v1 内での破壊的変更を許容する（ADR-0017 追記）。適用した変更:

- 2026-09-13（#114）: `GET /api/v1/documents/{document_id}/idp-runs` の一覧項目から `raw_fields` / `normalized_fields` / `confidence` / `field_labels` / `field_regions` / `tables` / `pattern_matches` を除き、サマリ項目のみとした。詳細は `GET …/idp-runs/{run_id}` で取得する

## エラー応答（RFC 9457 Problem Details）

全エラー応答は `Content-Type: application/problem+json` で以下の本文を返す（ADR-0016）。

```json
{
  "type": "/errors/document-not-found",
  "title": "Document not found",
  "status": 404,
  "detail": "Document not found"
}
```

- `type`: `/errors/<code>` 形式の相対URI。エラー種別の判別にはこの値を使う
- `title`: エラー種別の短い説明（code から導出）
- `status`: HTTPステータスコード
- `detail`: 発生箇所の説明文
- `errors`: 422 `validation-error` のみ。`loc` / `msg` / `type` の配列

### エラーコード一覧

| status | type | 発生条件 |
|---|---|---|
| 401 | `/errors/unauthenticated` | Authorization ヘッダなし |
| 401 | `/errors/invalid-token` | トークン検証失敗 |
| 403 | `/errors/view-url-not-allowed` | 共有不可の文書種別に閲覧URLを発行 |
| 404 | `/errors/document-not-found` | 文書が存在しない（他テナント含む） |
| 404 | `/errors/page-not-found` | ページ番号が範囲外 |
| 404 | `/errors/document-type-not-found` | 文書種別設定が存在しない |
| 404 | `/errors/idp-run-not-found` | IDP実行結果が存在しない（他文書の run_id を含む） |
| 404 | `/errors/raw-response-not-found` | 生応答が保存されていない実行結果（失敗実行） |
| 404 | `/errors/view-url-not-found` | 閲覧URLが存在しない（失効操作時） |
| 404 | `/errors/not-found` | 閲覧トークン無効（不存在・期限切れ・失効を秘匿）、未知のAPIパス |
| 409 | `/errors/document-conflict` | 同一文書IDで内容が異なる再登録 |
| 409 | `/errors/document-type-not-configured` | IDP実行対象の文書種別が未設定 |
| 409 | `/errors/document-type-exists` | 文書種別の重複作成 |
| 409 | `/errors/document-type-in-use` | 使用中の文書種別の削除 |
| 409 | `/errors/idp-run-not-correctable` | 失敗した実行結果（`status=failed`）に修正を要求 |
| 415 | `/errors/unsupported-media-type` | PDF以外のファイル |
| 422 | `/errors/validation-error` | リクエスト検証エラー（`errors` 付き） |
| 422 | `/errors/unknown-document-type` | 文書登録時の文書種別がテナント未設定 |
| 422 | `/errors/unknown-correction-target` | 修正対象のキー・セル座標が base の実行結果に存在しない |
| 429 | `/errors/too-many-requests` | 閲覧トークン失敗の連続によるレート制限 |
| 500 | `/errors/pdf-processing-failed` | PDF処理失敗 |
| 500 | `/errors/internal-error` | 未捕捉の内部エラー |
| 502 | `/errors/document-analysis-failed` | Document Intelligence 呼出失敗 |

上表にない `type` は FastAPI/Starlette が内部で送出するエラー（例: 405）で、HTTPステータス句をケバブケースにしたもの（例: `/errors/method-not-allowed`）。

422 の例:

```json
{
  "type": "/errors/validation-error",
  "title": "Validation error",
  "status": 422,
  "detail": "Request validation failed",
  "errors": [
    {"loc": ["path", "page"], "msg": "Input should be a valid integer, unable to parse string as an integer", "type": "int_parsing"}
  ]
}
```
