# 閲覧URLトークン（view_tokens / view_access_failures）

顧客向け見積閲覧URLのトークン管理。決定済みの「不透明ランダムトークン+DB管理」方式の実装仕様。

## view_tokens

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 管理ID（失効操作に使用。トークンとは無関係） |
| token_hash | varchar(64) | NOT NULL・UNIQUE | トークンのSHA-256ハッシュ。**平文は保存しない**（発行応答で一度だけ返却） |
| document_id | varchar(255) | NOT NULL・FK(documents) | 対象文書 |
| issued_at | timestamptz | NOT NULL・default now() | 発行日時 |
| expires_at | timestamptz | NOT NULL | 有効期限（発行時必須。既定90日=設定値・業務要件確定までの仮置き） |
| revoked | bool | NOT NULL・default false | 失効フラグ。即時失効はこの行更新のみ |

- トークンは256bit URL-safe乱数（`secrets.token_urlsafe(32)`）。URL形式は `/view/{token}` で文書ID・案件IDを含めない
- 検証条件: ハッシュ一致 AND 未失効 AND 期限内。いずれか欠けても応答は一律404（存在推測を防ぐ）
- 発行は共有可の文書種別のみ（`document_type_configs.shareable`。ADR-0002の判断をシードのデフォルト値として引き継ぐ。ADR-0014）

## view_access_failures

| 列 | 型 | 説明 |
| --- | --- | --- |
| id | uuid | PK |
| token_fragment | varchar(8) | 試行トークンの先頭8文字のみ（全体は記録しない） |
| client_ip | varchar(64) | 試行元IP |
| occurred_at | timestamptz | 発生日時 |

- 総当り検知用の失敗試行記録。あわせてIP単位のスライディング窓レート制限（既定: 直近60秒に10失敗で429）をインメモリで実施（PoC単一インスタンス前提。スケールアウト時は要外部化）

## 世代管理

発行レコードがそのまま世代管理台帳となる（1文書に複数トークン可）。見積改訂履歴の扱い確定後に拡張する。
