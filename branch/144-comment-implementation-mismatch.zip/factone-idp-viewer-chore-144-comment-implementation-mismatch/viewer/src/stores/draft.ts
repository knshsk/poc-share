import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

import type { Corrections } from '../utils/runs'

// グリッドセルの下書きキー（table_index:row_index:column_index）
export function cellKey(t: number, r: number, c: number): string {
  return `${t}:${r}:${c}`
}

// 未確定の修正。元値との差分のみ保持し、確定時に corrections API のボディへ変換する
export const useDraftStore = defineStore('draft', () => {
  const fields = ref<Record<string, string | null>>({})
  const cells = ref<Record<string, string>>({})
  // 未保存の変更がある状態で要求された操作（履歴選択・IDP実行・文書切替）。確認ダイアログで続行 / 取消する
  const pending = ref<(() => void) | null>(null)

  const count = computed(
    () => Object.keys(fields.value).length + Object.keys(cells.value).length,
  )
  const dirty = computed(() => count.value > 0)

  // 空欄は「値なし（null）」として扱う。元値と同じに戻ったら差分から外す
  function setField(key: string, value: string, original: string | null): void {
    const next = value === '' ? null : value
    if (next === original) delete fields.value[key]
    else fields.value[key] = next
  }

  function setCell(key: string, value: string, original: string): void {
    if (value === original) delete cells.value[key]
    else cells.value[key] = value
  }

  function reset(): void {
    fields.value = {}
    cells.value = {}
  }

  function toCorrections(): Corrections {
    return {
      fields: { ...fields.value },
      table_cells: Object.entries(cells.value).map(([key, content]) => {
        // キーは cellKey() 由来の "t:r:c" のみ
        const [t, r, c] = key.split(':').map(Number) as [number, number, number]
        return { table_index: t, row_index: r, column_index: c, content }
      }),
    }
  }

  function guard(action: () => void): void {
    if (dirty.value) pending.value = action
    else action()
  }

  function proceed(): void {
    const action = pending.value
    pending.value = null
    reset()
    action?.()
  }

  function cancel(): void {
    pending.value = null
  }

  return {
    fields,
    cells,
    pending,
    count,
    dirty,
    setField,
    setCell,
    reset,
    toCorrections,
    guard,
    proceed,
    cancel,
  }
})
