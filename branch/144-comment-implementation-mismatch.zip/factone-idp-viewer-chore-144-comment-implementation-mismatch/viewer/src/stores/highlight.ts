import { defineStore } from 'pinia'
import { ref } from 'vue'

// 要求は連番付き。同一 ID の再要求（同じ入力欄を再フォーカス等）を watch で検知できるようにする
interface Request {
  id: string
  seq: number
}

// キャンバス（矩形）⇄ 右ペイン（入力欄）の相互ハイライト状態。ID は utils/runs の fieldId / cellId
export const useHighlightStore = defineStore('highlight', () => {
  const activeId = ref<string | null>(null)
  // ペイン側フォーカス → キャンバスへ「該当矩形を表示範囲へ」
  const canvasScroll = ref<Request | null>(null)
  // キャンバス側クリック → ペインへ「該当入力欄をフォーカス」
  const paneFocus = ref<Request | null>(null)
  let seq = 0

  function selectFromPane(id: string): void {
    activeId.value = id
    canvasScroll.value = { id, seq: ++seq }
  }

  function selectFromCanvas(id: string): void {
    activeId.value = id
    paneFocus.value = { id, seq: ++seq }
  }

  // 選択はフォーカスが外れても維持する（照合のため）。履歴選択・IDP実行で解除する
  function clear(): void {
    activeId.value = null
  }

  return {
    activeId,
    canvasScroll,
    paneFocus,
    selectFromPane,
    selectFromCanvas,
    clear,
  }
})
