import { defineStore } from 'pinia'
import { ref } from 'vue'

import type { components } from '../api/schema'

export type DocumentTypeValue =
  components['schemas']['DocumentResponse']['document_type']
export type FieldDef = components['schemas']['FieldDefPayload']

// 文書コンテキスト（AppHeaderとDocumentViewで共有）。データ取得はDocumentViewの責務
export const useDocumentStore = defineStore('document', () => {
  // 表示要求中の文書ID（URLパラメータ・手入力由来）。変更をDocumentViewがwatchして再取得する
  const documentId = ref('')
  // 表示確定済の文書ID（入力途中の値と区別し、作業パネルへ渡す）
  const loadedDocumentId = ref<string | null>(null)
  const documentType = ref<DocumentTypeValue | null>(null)
  // 文書種別設定（document_type_configs）由来。未取得・設定なしはnull/false（安全側）
  const documentTypeDisplayName = ref<string | null>(null)
  const documentTypeShareable = ref(false)
  // 文書種別設定の項目定義（key/label/type/visible）。非表示判定と正規化ヒントの型に使う。未取得は空＝全項目表示・string 扱い
  const fieldDefs = ref<FieldDef[]>([])

  return {
    documentId,
    loadedDocumentId,
    documentType,
    documentTypeDisplayName,
    documentTypeShareable,
    fieldDefs,
  }
})
