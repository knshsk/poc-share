// prefers-reduced-motion: reduce のときはスムーススクロールを止める。matchMedia が無い環境（jsdom）は smooth
export function scrollBehavior(): ScrollBehavior {
  return window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    ? 'auto'
    : 'smooth'
}
