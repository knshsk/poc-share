import type { components } from '../api/schema'

export type FieldType = components['schemas']['FieldDefPayload']['type']

// サーバ側 idp_extraction._normalize と同じ規則をクライアントで再現する（入力中の注意喚起用。判定はサーバが正）
// NFKC で全角を半角に寄せた上で、number: 通貨記号・カンマ・空白を除いて整数、
// date: 西暦 / 和暦（令和・平成・昭和・R H S、元年可）の年月日を YYYY-MM-DD にする
const NUMBER_NOISE = /[¥円,、\s]/g
const DATE =
  /^(?:(令和|平成|昭和|[RHS])\s*(\d{1,2}|元)|(\d{4}))\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})\s*日?$/
const ERA_BASE: Record<string, number> = {
  令和: 2018,
  R: 2018,
  平成: 1988,
  H: 1988,
  昭和: 1925,
  S: 1925,
}

export function normalizeValue(
  type: FieldType,
  value: string,
): string | number | null {
  value = value.normalize('NFKC')
  if (type === 'number') {
    const s = value.replace(NUMBER_NOISE, '')
    return /^[+-]?\d+$/.test(s) ? Number(s) : null
  }
  if (type === 'date') {
    const m = DATE.exec(value.trim())
    if (!m) return null
    const year = m[1]
      ? ERA_BASE[m[1]]! + (m[2] === '元' ? 1 : Number(m[2]))
      : Number(m[3])
    const iso = `${year}-${m[4]!.padStart(2, '0')}-${m[5]!.padStart(2, '0')}`
    const d = new Date(`${iso}T00:00:00Z`)
    return Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== iso
      ? null
      : iso
  }
  return value
}

// 入力欄の下に出す行内ヒント。string 型・空欄は出さない
export function normalizationHint(
  type: FieldType,
  value: string,
): { ok: boolean; text: string } | null {
  if (type === 'string' || value === '') return null
  const normalized = normalizeValue(type, value)
  if (normalized == null) {
    return {
      ok: false,
      text:
        type === 'number'
          ? '数値として解釈できません'
          : '日付として解釈できません',
    }
  }
  if (String(normalized) === value) return null
  return { ok: true, text: `正規化値 ${normalized}` }
}
