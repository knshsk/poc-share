<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'

import { apiClient } from '../api/client'
import type { OverlayRect } from '../utils/runs'

const props = defineProps<{
  // 認証済み表示は documentId、閲覧URL経由（無認証）は token を指定する
  documentId?: string
  token?: string
  page: number
  width: number
  height: number
  // 読取矩形（DI座標系＝インチ。polygonの外接矩形）。ID は utils/runs の fieldId / cellId
  rects?: OverlayRect[]
  // 選択中の矩形 ID（highlight ストアの activeId）
  activeId?: string | null
}>()

const emit = defineEmits<{ rectClick: [id: string] }>()

const imageUrl = ref<string | null>(null)
const root = ref<SVGSVGElement | null>(null)
let observer: IntersectionObserver | null = null
let disposed = false

async function fetchImage(): Promise<Blob | null> {
  if (props.token) {
    const { data, error } = await apiClient.GET(
      '/view/{token}/pages/{page}/image',
      {
        params: { path: { token: props.token, page: props.page } },
        parseAs: 'blob',
      },
    )
    return error ? null : data
  }
  if (props.documentId) {
    const { data, error } = await apiClient.GET(
      '/api/v1/documents/{document_id}/pages/{page}/image',
      {
        params: { path: { document_id: props.documentId, page: props.page } },
        parseAs: 'blob',
      },
    )
    return error ? null : data
  }
  return null
}

async function load(): Promise<void> {
  // 画像はAPIプロキシ配信のため、fetchしてblob URLで表示する
  const data = await fetchImage()
  if (disposed) return // fetch中にアンマウントされた場合、blob URLを作らずリークを防ぐ
  if (data) {
    imageUrl.value = URL.createObjectURL(data)
  }
}

onMounted(() => {
  // 表示領域に入った時だけ画像取得する。閲覧URL経由ではこの取得がpage_view記録になるため、
  // 未表示ページを先読みしない（rootMargin 0・threshold 0＝1pxでも見えたら取得）
  if (typeof IntersectionObserver === 'undefined' || !root.value) {
    void load()
    return
  }
  observer = new IntersectionObserver((entries) => {
    if (!observer || !entries.some((entry) => entry.isIntersecting)) return
    observer.disconnect()
    observer = null
    void load()
  })
  observer.observe(root.value)
})

onUnmounted(() => {
  disposed = true
  observer?.disconnect()
  observer = null
  if (imageUrl.value) URL.revokeObjectURL(imageUrl.value)
})
</script>

<template>
  <!-- viewBoxをDI座標系（インチ）に合わせ、rect座標を無変換で使えるようにする -->
  <svg
    ref="root"
    :viewBox="`0 0 ${width} ${height}`"
    xmlns="http://www.w3.org/2000/svg"
    :class="['page-svg', { 'page-svg--loading': !imageUrl }]"
  >
    <image
      v-if="imageUrl"
      :href="imageUrl"
      :width="width"
      :height="height"
      x="0"
      y="0"
    />
    <!-- 矩形はキーボードでも選択可能（Tab で到達、Enter / Space でクリックと同じ）。<title> がツールチップ兼アクセシブル名 -->
    <rect
      v-for="rect in rects ?? []"
      :key="rect.id"
      :data-rect-id="rect.id"
      :x="rect.x"
      :y="rect.y"
      :width="rect.width"
      :height="rect.height"
      :class="[
        'overlay-rect',
        `overlay-rect--${rect.kind}`,
        { 'overlay-rect--active': rect.id === activeId },
      ]"
      tabindex="0"
      role="button"
      @click="emit('rectClick', rect.id)"
      @keydown.enter.space.prevent="emit('rectClick', rect.id)"
    >
      <title>{{ rect.label }}</title>
    </rect>
  </svg>
</template>

<style scoped>
.page-svg {
  width: 100%;
  height: auto;
  display: block;
  border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* 画像取得中のパルス表示 */
.page-svg--loading {
  animation: page-pulse 1.5s ease-in-out infinite;
  background: rgba(var(--v-border-color), 0.08);
}

@keyframes page-pulse {
  50% {
    opacity: 0.6;
  }
}

@media (prefers-reduced-motion: reduce) {
  .page-svg--loading {
    animation: none;
  }
}

/* 読取矩形の色はテーマトークン参照（--v-theme-primaryはカンマ区切りRGB値）。
   常時は薄く、ホバーで強調、選択中は塗り＋太枠。semantic color（warning 等）は使わない */
.overlay-rect {
  /* tabindex でクリック時にもフォーカスされる。ブラウザ既定のフォーカスリングは viewBox（インチ）の拡大で
     巨大な黒枠になるため常に消し、キーボードフォーカスは :focus-visible の太枠で示す */
  outline: none;
  fill: rgba(var(--v-theme-primary), 0.06);
  stroke: rgba(var(--v-theme-primary), 0.45);
  stroke-width: 0.012;
  cursor: pointer;
  transition: fill 0.12s ease;
}

/* キー項目は破線、セルは実線 */
.overlay-rect--field {
  stroke-dasharray: 0.04 0.03;
}

.overlay-rect:hover {
  fill: rgba(var(--v-theme-primary), 0.18);
}

.overlay-rect--active,
.overlay-rect:focus-visible {
  fill: rgba(var(--v-theme-primary), 0.32);
  stroke: rgb(var(--v-theme-primary-darken-1));
  stroke-width: 0.03;
  stroke-dasharray: none;
}
</style>
