import { describe, expect, it } from 'vitest'

import { normalizationHint, normalizeValue } from '../src/utils/normalize'

// サーバ側 idp_extraction._normalize と同じ規則（tests/test_idp_extraction.py と同ケース）
describe('normalizeValue', () => {
  it.each([
    ['1,250,000', 1250000],
    ['￥74,800', 74800],
    ['¥74,800円', 74800],
    ['７４，８００', 74800],
    ['1 250 000', 1250000],
    [' -12 ', -12],
    ['12.5', null],
    ['約120万', null],
  ])('number %s → %s', (value, expected) => {
    expect(normalizeValue('number', value)).toBe(expected)
  })

  it.each([
    ['2026-09-04', '2026-09-04'],
    ['2026/9/4', '2026-09-04'],
    ['2026.09.04', '2026-09-04'],
    ['2026年9月4日', '2026-09-04'],
    ['２０２６年９月４日', '2026-09-04'],
    ['令和 8年 9月 4日', '2026-09-04'],
    ['令和元年5月1日', '2019-05-01'],
    ['平成31年4月30日', '2019-04-30'],
    ['昭和64年1月7日', '1989-01-07'],
    ['R8.9.4', '2026-09-04'],
    ['H30/1/2', '2018-01-02'],
    [' 2026-01-02 ', '2026-01-02'],
    ['2026-02-30', null],
    ['令和8年13月1日', null],
    ['9/4', null],
    ['月末', null],
  ])('date %s → %s', (value, expected) => {
    expect(normalizeValue('date', value)).toBe(expected)
  })

  it('string はそのまま', () => {
    expect(normalizeValue('string', ' abc ')).toBe(' abc ')
  })
})

describe('normalizationHint', () => {
  it('string と空欄はヒントなし', () => {
    expect(normalizationHint('string', 'x')).toBeNull()
    expect(normalizationHint('number', '')).toBeNull()
  })

  it('解釈できる値は正規化値、できない値は型別の注意文を返す', () => {
    expect(normalizationHint('number', '1,000')).toEqual({
      ok: true,
      text: '正規化値 1000',
    })
    expect(normalizationHint('number', 'abc')).toEqual({
      ok: false,
      text: '数値として解釈できません',
    })
    expect(normalizationHint('date', '2026/01/02')).toEqual({
      ok: true,
      text: '正規化値 2026-01-02',
    })
    expect(normalizationHint('date', '来月')).toEqual({
      ok: false,
      text: '日付として解釈できません',
    })
  })

  it('入力値が正規化値と同じ表記ならヒントを出さない', () => {
    expect(normalizationHint('number', '74800')).toBeNull()
    expect(normalizationHint('date', '2026-09-04')).toBeNull()
  })
})
