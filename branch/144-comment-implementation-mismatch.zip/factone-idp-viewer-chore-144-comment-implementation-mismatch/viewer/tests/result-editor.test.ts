import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import ResultEditor from '../src/components/ResultEditor.vue'
import { createAppVuetify } from '../src/plugins/vuetify'
import { useDraftStore } from '../src/stores/draft'
import { useHighlightStore } from '../src/stores/highlight'
import type { IdpRun } from '../src/utils/runs'

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  raw_fields: {
    TotalAmount: '1,200,000',
    DeliveryDate: '2026-10-30',
    Note: null,
    Hidden: 'secret',
  },
  normalized_fields: {
    TotalAmount: 1200000,
    DeliveryDate: '2026-10-30',
    Note: null,
    Hidden: 'secret',
  },
  confidence: {
    TotalAmount: 0.96,
    DeliveryDate: 0.85,
    Note: null,
    Hidden: 0.5,
  },
  field_labels: { TotalAmount: '合計金額', DeliveryDate: '納品期限' },
  field_regions: null,
  tables: [
    {
      row_count: 2,
      column_count: 2,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          content: '品目',
          kind: 'columnHeader',
          page_number: 1,
          polygon: [1, 2, 3, 2],
        },
        {
          row_index: 1,
          column_index: 0,
          content: 'P-9001',
          kind: null,
          page_number: 1,
          polygon: [1, 3, 3, 3],
        },
      ],
    },
  ],
  pattern_matches: {
    TCode: { label: '登録番号', regex: 'T\\d{13}', values: ['T1234567890123'] },
    QuotationNo: { label: '見積番号', regex: 'Q-\\d{6}', values: [] },
  },
  corrections: null,
}

const fieldDefs = [
  {
    key: 'TotalAmount',
    label: '合計金額',
    type: 'number' as const,
    visible: true,
  },
  {
    key: 'DeliveryDate',
    label: '納品期限',
    type: 'date' as const,
    visible: true,
  },
  { key: 'Note', label: '備考', type: 'string' as const, visible: true },
  { key: 'Hidden', label: '非表示', type: 'string' as const, visible: false },
]

function mountEditor(overrides: Partial<IdpRun> = {}, attachTo?: HTMLElement) {
  return mount(ResultEditor, {
    props: { run: { ...run, ...overrides }, fieldDefs },
    global: { plugins: [createAppVuetify()] },
    attachTo,
  })
}

function fieldInputs(wrapper: ReturnType<typeof mountEditor>) {
  return wrapper.findAll('[data-testid="field-input"] input')
}

describe('ResultEditor', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  // キー項目は raw_fields のキー順・visible=true のみ。ラベルは field_labels（無ければキー）、値は正規化値（無ければ raw）、null は空欄
  it('キー項目を raw_fields の順に描画し、visible=false を除外する', () => {
    const wrapper = mountEditor()
    const rows = wrapper.findAll('[data-testid="field-row"]')
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('合計金額')
    expect(rows[0]!.text()).toContain('96%')
    expect(rows[2]!.text()).toContain('Note')
    expect(wrapper.text()).not.toContain('secret')

    const inputs = fieldInputs(wrapper)
    expect((inputs[0]!.element as HTMLInputElement).value).toBe('1200000')
    expect((inputs[2]!.element as HTMLInputElement).value).toBe('')
    expect(inputs[2]!.attributes('placeholder')).toBe('（値なし）')
    expect(inputs[0]!.attributes('aria-label')).toBe('合計金額')
    expect(wrapper.findAll('[data-testid="confidence-bar"]')).toHaveLength(3)
  })

  // 正規化値と DI の読取値が異なる項目だけ「読取値 …」を補足表示し、入力欄の aria-describedby で紐付ける。
  // 正規化不能な項目は raw をそのまま入力欄に出す
  it('正規化値が読取値と異なるとき読取値を補足表示する', () => {
    const wrapper = mountEditor({
      raw_fields: {
        ...run.raw_fields,
        DeliveryDate: '令和 8年 9月 4日',
        Note: '約120万',
      },
      normalized_fields: {
        ...run.normalized_fields,
        DeliveryDate: '2026-09-04',
        Note: null,
      },
    })
    const inputs = fieldInputs(wrapper)
    expect((inputs[1]!.element as HTMLInputElement).value).toBe('2026-09-04')
    expect((inputs[2]!.element as HTMLInputElement).value).toBe('約120万')
    const raws = wrapper.findAll('[data-testid="raw-value"]')
    expect(raws.map((r) => r.text())).toEqual([
      '読取値 1,200,000',
      '読取値 令和 8年 9月 4日',
    ])
    expect(inputs[0]!.attributes('aria-describedby')).toBe(
      raws[0]!.attributes('id'),
    )
    expect(inputs[2]!.attributes('aria-describedby')).toBeUndefined()
  })

  // 編集で draft に差分が入り、元値（表示初期値 = 正規化値）に戻すと消える。空欄は null
  it('入力で下書きが増減し、元値復帰で差分から外れる', async () => {
    const wrapper = mountEditor()
    const draft = useDraftStore()
    const inputs = fieldInputs(wrapper)

    await inputs[0]!.setValue('1,250,000')
    expect(draft.fields).toEqual({ TotalAmount: '1,250,000' })
    expect(draft.count).toBe(1)

    await inputs[1]!.setValue('')
    expect(draft.fields.DeliveryDate).toBeNull()
    expect(draft.count).toBe(2)

    await inputs[0]!.setValue('1200000')
    expect(draft.count).toBe(1)
    expect(draft.fields).toEqual({ DeliveryDate: null })
  })

  // number / date は入力中に正規化の可否を行内表示する（string・正規化値と同表記は出さない）
  it('正規化ヒントを型別に表示する', async () => {
    const wrapper = mountEditor()
    const inputs = fieldInputs(wrapper)
    expect(wrapper.findAll('[data-testid="normalization-hint"]')).toHaveLength(
      0,
    )
    await inputs[0]!.setValue('1,250,000')
    expect(wrapper.text()).toContain('正規化値 1250000')
    await inputs[1]!.setValue('2026/11/1')
    expect(wrapper.text()).toContain('正規化値 2026-11-01')

    await inputs[0]!.setValue('約120万')
    expect(wrapper.text()).toContain('数値として解釈できません')
    await inputs[1]!.setValue('来月')
    expect(wrapper.text()).toContain('日付として解釈できません')
    await inputs[2]!.setValue('メモ')
    expect(wrapper.findAll('[data-testid="normalization-hint"]')).toHaveLength(
      2,
    )
  })

  // 修正済みマークは保存済み corrections と未保存の下書きの両方に付く
  it('保存済み修正と下書きに修正済みマークを付ける', async () => {
    const wrapper = mountEditor({
      corrections: {
        fields: { DeliveryDate: '2026-11-01' },
        table_cells: [
          { table_index: 0, row_index: 1, column_index: 0, content: 'P-9002' },
        ],
      },
    })
    expect(wrapper.findAll('[data-testid="corrected-mark"]')).toHaveLength(2)

    await fieldInputs(wrapper)[0]!.setValue('1')
    expect(wrapper.findAll('[data-testid="corrected-mark"]')).toHaveLength(3)
  })

  // 修正済みマークはツールチップがマウス限定のため、アイコン自体にアクセシブル名を持たせる
  it('修正済みマークに role=img と aria-label を付ける', () => {
    const wrapper = mountEditor({
      corrections: { fields: { DeliveryDate: '2026-11-01' }, table_cells: [] },
    })
    const mark = wrapper.get('[data-testid="corrected-mark"]')
    expect(mark.attributes('role')).toBe('img')
    expect(mark.attributes('aria-label')).toBe('修正')
  })

  // hide-details のため messages スロットが使えず、ヒントは aria-describedby で入力欄に紐付ける
  it('正規化ヒントを aria-describedby で入力欄に紐付ける', async () => {
    const wrapper = mountEditor()
    const inputs = fieldInputs(wrapper)
    await inputs[0]!.setValue('1,250,000')
    await inputs[1]!.setValue('2026/11/1')
    const hints = wrapper.findAll('[data-testid="normalization-hint"]')
    expect(hints[0]!.attributes('id')).toBeTruthy()
    // TotalAmount は読取値の補足もあるので両方の id を空白区切りで持つ
    expect(inputs[0]!.attributes('aria-describedby')).toBe(
      `${wrapper.get('[data-testid="raw-value"]').attributes('id')} ${hints[0]!.attributes('id')}`,
    )
    expect(inputs[1]!.attributes('aria-describedby')).toBe(
      hints[1]!.attributes('id'),
    )
    expect(hints[0]!.attributes('id')).not.toBe(hints[1]!.attributes('id'))
    expect(inputs[2]!.attributes('aria-describedby')).toBeUndefined()
  })

  // サーバ側 CorrectionText（max_length=2000）と同じ上限を入力欄に付ける
  it('修正入力欄に maxlength=2000 を付ける', () => {
    const wrapper = mountEditor()
    expect(fieldInputs(wrapper)[0]!.attributes('maxlength')).toBe('2000')
    expect(
      wrapper.get('[data-testid="cell-input"] input').attributes('maxlength'),
    ).toBe('2000')
  })

  // 選択中の入力欄は色以外の手掛かりとして aria-current を持つ
  it('選択中の入力欄に aria-current を付ける', async () => {
    const wrapper = mountEditor()
    const highlight = useHighlightStore()
    highlight.selectFromPane('field:DeliveryDate')
    await wrapper.vm.$nextTick()

    const inputs = fieldInputs(wrapper)
    expect(inputs[0]!.attributes('aria-current')).toBeUndefined()
    expect(inputs[1]!.attributes('aria-current')).toBe('true')

    highlight.selectFromPane('cell:0:1:0')
    await wrapper.vm.$nextTick()
    expect(inputs[1]!.attributes('aria-current')).toBeUndefined()
    expect(
      wrapper
        .findAll('[data-testid="cell-input"] input')[1]!
        .attributes('aria-current'),
    ).toBe('true')
  })

  // キー項目候補はラベルと一致値チップ。0 件は「一致なし」。正規表現は表示しない
  it('キー項目候補をチップで表示し、0件は一致なしと表示する', () => {
    const wrapper = mountEditor()
    const rows = wrapper.findAll('[data-testid="candidate-row"]')
    expect(rows).toHaveLength(2)
    expect(rows[0]!.text()).toContain('登録番号')
    expect(rows[0]!.findAll('[data-testid="candidate-chip"]')).toHaveLength(1)
    expect(rows[0]!.text()).toContain('T1234567890123')
    expect(rows[1]!.text()).toContain('一致なし')
    expect(wrapper.text()).not.toContain('\\d{13}')
    expect(wrapper.find('[data-testid="candidate-row"] input').exists()).toBe(
      false,
    )
  })

  // グリッドは row_count × column_count。セルは編集可、ヘッダは区別、無い座標は空枠
  it('グリッドを描画し、セル編集が下書きに入る', async () => {
    const wrapper = mountEditor()
    const draft = useDraftStore()
    expect(wrapper.get('[data-testid="section-grid"]').text()).toContain(
      '表 1（2行 × 2列）',
    )
    const cells = wrapper.findAll('[data-testid="grid-cell"]')
    const empties = wrapper.findAll('[data-testid="grid-cell-empty"]')
    expect(cells).toHaveLength(2)
    expect(empties).toHaveLength(2)
    expect(cells[0]!.classes()).toContain('grid-cell--header')
    expect(cells[1]!.classes()).not.toContain('grid-cell--header')

    const cellInputs = wrapper.findAll('[data-testid="cell-input"] input')
    expect((cellInputs[1]!.element as HTMLInputElement).value).toBe('P-9001')
    expect(cellInputs[1]!.attributes('aria-label')).toBe('2行1列')
    await cellInputs[1]!.setValue('P-9002')
    expect(draft.cells).toEqual({ '0:1:0': 'P-9002' })
    await cellInputs[1]!.setValue('P-9001')
    expect(draft.cells).toEqual({})
  })

  it('テーブルが無いときはテーブル未検出と表示する', () => {
    const wrapper = mountEditor({ tables: [] })
    expect(wrapper.get('[data-testid="section-grid"]').text()).toContain(
      'テーブル未検出',
    )
  })

  // 入力欄フォーカスで activeId とキャンバスへのスクロール要求を出し、選択中の入力欄に active クラスが付く
  it('入力欄フォーカスでhighlightを更新し、選択中クラスを付ける', async () => {
    const wrapper = mountEditor()
    const highlight = useHighlightStore()

    await fieldInputs(wrapper)[0]!.trigger('focus')
    expect(highlight.activeId).toBe('field:TotalAmount')
    expect(highlight.canvasScroll).toEqual({ id: 'field:TotalAmount', seq: 1 })
    await wrapper.vm.$nextTick()
    expect(
      wrapper.get('[data-target-id="field:TotalAmount"]').classes(),
    ).toContain('target--active')

    await wrapper
      .findAll('[data-testid="cell-input"] input')[1]!
      .trigger('focus')
    expect(highlight.activeId).toBe('cell:0:1:0')
    await wrapper.vm.$nextTick()
    expect(wrapper.get('[data-target-id="cell:0:1:0"]').classes()).toContain(
      'target--active',
    )
    expect(
      wrapper.get('[data-target-id="field:TotalAmount"]').classes(),
    ).not.toContain('target--active')

    // フォーカスが外れても選択は維持する
    await wrapper
      .findAll('[data-testid="cell-input"] input')[1]!
      .trigger('blur')
    expect(highlight.activeId).toBe('cell:0:1:0')
  })

  // キャンバス側の要求で該当入力欄へスクロールしフォーカスする
  it('paneFocus要求で該当入力欄をscrollIntoViewしてフォーカスする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, host)
    try {
      const highlight = useHighlightStore()

      highlight.selectFromCanvas('cell:0:1:0')
      await wrapper.vm.$nextTick()
      await wrapper.vm.$nextTick()

      const input = wrapper.findAll('[data-testid="cell-input"] input')[1]!
        .element
      expect(document.activeElement).toBe(input)
      expect(scrollSpy).toHaveBeenCalledTimes(1)
      expect(scrollSpy.mock.instances[0]).toBe(input)
      expect(scrollSpy).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'smooth' }),
      )
    } finally {
      wrapper.unmount()
      host.remove()
      // @ts-expect-error jsdom に無いメソッドを差し込んだ後始末
      delete Element.prototype.scrollIntoView
    }
  })

  // prefers-reduced-motion: reduce のときはスムーススクロールを使わない
  it('reduced-motion 指定時は behavior auto でスクロールする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    vi.stubGlobal('matchMedia', () => ({ matches: true }))
    const wrapper = mountEditor()
    try {
      useHighlightStore().selectFromCanvas('field:TotalAmount')
      await wrapper.vm.$nextTick()
      await wrapper.vm.$nextTick()
      expect(scrollSpy).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'auto' }),
      )
    } finally {
      vi.unstubAllGlobals()
      // @ts-expect-error jsdom に無いメソッドを差し込んだ後始末
      delete Element.prototype.scrollIntoView
    }
  })

  // 折りたたみ中の区分にpaneFocus要求が来たら区分を開いてからフォーカスする
  it('折りたたみ中の区分へのpaneFocus要求で区分を開いてフォーカスする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, host)
    try {
      const highlight = useHighlightStore()

      await wrapper
        .get('[data-testid="section-grid"] .v-expansion-panel-title')
        .trigger('click')
      await wrapper.vm.$nextTick()

      highlight.selectFromCanvas('cell:0:1:0')
      await wrapper.vm.$nextTick()
      await wrapper.vm.$nextTick()

      const input = wrapper.findAll('[data-testid="cell-input"] input')[1]!
        .element
      expect(document.activeElement).toBe(input)
      expect(wrapper.get('[data-testid="section-grid"]').classes()).toContain(
        'v-expansion-panel--active',
      )
    } finally {
      wrapper.unmount()
      host.remove()
      // @ts-expect-error jsdom に無いメソッドを差し込んだ後始末
      delete Element.prototype.scrollIntoView
    }
  })
})
