import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { cellKey, useDraftStore } from '../src/stores/draft'

describe('draftストア', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('初期状態は変更なし', () => {
    const draft = useDraftStore()
    expect(draft.count).toBe(0)
    expect(draft.dirty).toBe(false)
    expect(draft.pending).toBeNull()
  })

  // 差分のみ保持し、元値に戻ったら差分から外す。空欄は null（値なし）
  it('setField は元値との差分だけを保持し、空欄は null にする', () => {
    const draft = useDraftStore()
    draft.setField('TotalAmount', '1,250,000', '1,200,000')
    draft.setField('Note', '', null)
    expect(draft.fields).toEqual({ TotalAmount: '1,250,000' })
    expect(draft.count).toBe(1)

    draft.setField('Note', 'x', null)
    expect(draft.fields).toEqual({ TotalAmount: '1,250,000', Note: 'x' })
    draft.setField('Note', '', null)
    expect(draft.fields).toEqual({ TotalAmount: '1,250,000' })

    draft.setField('DeliveryDate', '', '2026-10-30')
    expect(draft.fields.DeliveryDate).toBeNull()
    draft.setField('TotalAmount', '1,200,000', '1,200,000')
    expect(draft.fields).toEqual({ DeliveryDate: null })
  })

  it('setCell は元値との差分だけを保持する', () => {
    const draft = useDraftStore()
    draft.setCell(cellKey(0, 1, 0), 'P-9002', 'P-9001')
    expect(draft.cells).toEqual({ '0:1:0': 'P-9002' })
    draft.setCell(cellKey(0, 1, 0), 'P-9001', 'P-9001')
    expect(draft.cells).toEqual({})
  })

  it('toCorrections は API のボディ形式（fields + table_cells）を返す', () => {
    const draft = useDraftStore()
    draft.setField('TotalAmount', '1,250,000', '1,200,000')
    draft.setField('DeliveryDate', '', '2026-10-30')
    draft.setCell(cellKey(0, 2, 3), '10', '1')
    expect(draft.toCorrections()).toEqual({
      fields: { TotalAmount: '1,250,000', DeliveryDate: null },
      table_cells: [
        { table_index: 0, row_index: 2, column_index: 3, content: '10' },
      ],
    })
  })

  it('reset で下書きが空になる', () => {
    const draft = useDraftStore()
    draft.setField('a', 'x', null)
    draft.setCell('0:0:0', 'y', 'z')
    draft.reset()
    expect(draft.count).toBe(0)
  })

  // 未保存の変更がある状態の操作は pending に保留し、proceed で下書きを捨てて実行、cancel で操作だけ取り消す
  it('guard は変更なしなら即実行、変更ありなら保留する', () => {
    const draft = useDraftStore()
    const action = vi.fn()
    draft.guard(action)
    expect(action).toHaveBeenCalledTimes(1)

    draft.setField('a', 'x', null)
    draft.guard(action)
    expect(action).toHaveBeenCalledTimes(1)
    expect(draft.pending).not.toBeNull()

    draft.cancel()
    expect(draft.pending).toBeNull()
    expect(draft.dirty).toBe(true)

    draft.guard(action)
    draft.proceed()
    expect(action).toHaveBeenCalledTimes(2)
    expect(draft.pending).toBeNull()
    expect(draft.dirty).toBe(false)
  })
})
