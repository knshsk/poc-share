import { afterEach, describe, expect, it, vi } from 'vitest'

import { scrollBehavior } from '../src/utils/motion'

// prefers-reduced-motion: reduce のときはスムーススクロールを止める。matchMedia が無い環境（jsdom）は smooth
describe('scrollBehavior', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('matchMedia が無ければ smooth', () => {
    expect(scrollBehavior()).toBe('smooth')
  })

  it('reduce 指定時は auto', () => {
    vi.stubGlobal('matchMedia', () => ({ matches: true }))
    expect(scrollBehavior()).toBe('auto')
  })

  it('reduce 未指定時は smooth', () => {
    vi.stubGlobal('matchMedia', () => ({ matches: false }))
    expect(scrollBehavior()).toBe('smooth')
  })
})
