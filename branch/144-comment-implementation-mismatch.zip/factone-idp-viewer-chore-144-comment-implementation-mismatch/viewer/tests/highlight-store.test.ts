import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'

import { useHighlightStore } from '../src/stores/highlight'

describe('highlightストア', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('初期状態は未選択・要求なし', () => {
    const highlight = useHighlightStore()
    expect(highlight.activeId).toBeNull()
    expect(highlight.canvasScroll).toBeNull()
    expect(highlight.paneFocus).toBeNull()
  })

  // ペイン側フォーカス → activeId とキャンバスへのスクロール要求。同一 ID の再要求は連番で区別する
  it('selectFromPane は activeId を設定しキャンバスへ連番付きで要求する', () => {
    const highlight = useHighlightStore()
    highlight.selectFromPane('field:TotalAmount')
    expect(highlight.activeId).toBe('field:TotalAmount')
    expect(highlight.canvasScroll).toEqual({ id: 'field:TotalAmount', seq: 1 })
    expect(highlight.paneFocus).toBeNull()

    highlight.selectFromPane('field:TotalAmount')
    expect(highlight.canvasScroll?.seq).toBe(2)
  })

  // キャンバス側クリック → activeId とペインへのフォーカス要求
  it('selectFromCanvas は activeId を設定しペインへ連番付きで要求する', () => {
    const highlight = useHighlightStore()
    highlight.selectFromCanvas('cell:0:1:0')
    expect(highlight.activeId).toBe('cell:0:1:0')
    expect(highlight.paneFocus).toEqual({ id: 'cell:0:1:0', seq: 1 })
    expect(highlight.canvasScroll).toBeNull()
  })

  // 解除は選択だけを消す（要求は残っていても連番で古いと分かる）
  it('clear は activeId だけを解除する', () => {
    const highlight = useHighlightStore()
    highlight.selectFromPane('field:a')
    highlight.clear()
    expect(highlight.activeId).toBeNull()
    expect(highlight.canvasScroll).toEqual({ id: 'field:a', seq: 1 })
  })
})
