"""閲覧URL: 発行・一覧・失効と、トークンによる無認証閲覧。

- トークンは256bit URL-safe乱数。DBにはSHA-256ハッシュのみ保存（平文はログにも残さない）
- 無効トークン（不存在・期限切れ・失効）は一律404（存在推測を防ぐ）+失敗記録
- 共有可否は文書種別設定（document_type_configs.shareable）で判定
"""

import hashlib
import logging
import secrets
import time
import uuid
from collections import defaultdict, deque
from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.config import Settings
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import (
    Document,
    ViewAccessFailure,
    ViewEvent,
    ViewEventType,
    ViewToken,
)
from app.routers.documents import (
    PageInfo,
    PagesResponse,
    _get_document_or_404,
    pdf_response,
)
from app.services.blob import BlobStorage
from app.services.document_type_config import get_config
from app.services.pdf_render import PdfProcessingError, PdfRenderer

router = APIRouter(responses=problem_responses(422))
logger = logging.getLogger(__name__)


class FailureRateLimiter:
    """無効トークン試行のIP単位レート制限（スライディング窓・インメモリ。直近window_seconds秒の失敗回数で判定。PoC単一インスタンス前提）。"""

    def __init__(self, max_failures: int, window_seconds: int) -> None:
        self._max_failures = max_failures
        self._window_seconds = window_seconds
        self._failures: dict[str, deque[float]] = defaultdict(deque)

    def _prune(self, ip: str, now: float) -> None:
        window = self._failures[ip]
        while window and now - window[0] > self._window_seconds:
            window.popleft()

    def is_blocked(self, ip: str) -> bool:
        now = time.monotonic()
        self._prune(ip, now)
        return len(self._failures[ip]) >= self._max_failures

    def record_failure(self, ip: str) -> None:
        now = time.monotonic()
        self._prune(ip, now)
        self._failures[ip].append(now)


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class ViewUrlIssueRequest(BaseModel):
    expires_at: datetime | None = None


class ViewUrlIssueResponse(BaseModel):
    id: uuid.UUID
    view_path: str
    expires_at: datetime


class ViewUrlSummary(BaseModel):
    id: uuid.UUID
    issued_at: datetime
    expires_at: datetime
    revoked: bool


@router.post(
    "/api/v1/documents/{document_id}/view-urls",
    response_model=ViewUrlIssueResponse,
    status_code=201,
    responses=problem_responses(401, 403, 404),
)
def issue_view_url(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    payload: ViewUrlIssueRequest | None = None,
) -> ViewUrlIssueResponse:
    settings: Settings = request.app.state.settings
    document = _get_document_or_404(request, session, document_id)
    config = get_config(session, settings.tenant_id, document.document_type)
    if config is None or not config.shareable:
        raise ProblemException(
            403,
            "view-url-not-allowed",
            "View URLs cannot be issued for this document type",
        )

    token = secrets.token_urlsafe(32)
    expires_at = (payload.expires_at if payload else None) or datetime.now(
        UTC
    ) + timedelta(days=settings.view_url_default_ttl_days)
    view_token = ViewToken(
        token_hash=_hash_token(token),
        document_id=document.document_id,
        expires_at=expires_at,
    )
    session.add(view_token)
    session.commit()
    return ViewUrlIssueResponse(
        id=view_token.id, view_path=f"/view/{token}", expires_at=view_token.expires_at
    )


@router.get(
    "/api/v1/documents/{document_id}/view-urls",
    response_model=list[ViewUrlSummary],
    responses=problem_responses(401, 404),
)
def list_view_urls(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> list[ViewUrlSummary]:
    _get_document_or_404(request, session, document_id)
    tokens = session.scalars(
        select(ViewToken).where(ViewToken.document_id == document_id)
    ).all()
    return [
        ViewUrlSummary(
            id=row.id,
            issued_at=row.issued_at,
            expires_at=row.expires_at,
            revoked=row.revoked,
        )
        for row in tokens
    ]


class ViewEventSummary(BaseModel):
    """閲覧イベント（外部連携IF-04の応答契約。view_token_idは内部管理値のため非公開）。

    page は page_view のときのみ値を持つ（1始まり）。view / download は null。
    """

    id: uuid.UUID
    event_type: str
    occurred_at: datetime
    client_ip: str
    user_agent: str
    page: int | None


@router.get(
    "/api/v1/documents/{document_id}/events",
    response_model=list[ViewEventSummary],
    responses=problem_responses(401, 404),
)
def list_view_events(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> list[ViewEventSummary]:
    _get_document_or_404(request, session, document_id)
    events = session.scalars(
        select(ViewEvent)
        .where(ViewEvent.document_id == document_id)
        .order_by(ViewEvent.occurred_at)
    ).all()
    return [
        ViewEventSummary(
            id=row.id,
            event_type=row.event_type,
            occurred_at=row.occurred_at,
            client_ip=row.client_ip,
            user_agent=row.user_agent,
            page=row.page,
        )
        for row in events
    ]


class ViewEventFeedItem(BaseModel):
    """閲覧イベント横断フィード項目（外部連携IF-04）。

    差分取得の応答契約。文書横断のためdocument_idを含む（案件IDへの解決は連携側の責務）。
    view_token_idは内部管理値のため非公開。
    page は page_view のときのみ値を持つ（1始まり）。view / download は null。
    """

    id: uuid.UUID
    document_id: str
    event_type: str
    occurred_at: datetime
    client_ip: str
    user_agent: str
    page: int | None


@router.get(
    "/api/v1/view-events",
    response_model=list[ViewEventFeedItem],
    responses=problem_responses(401),
)
def list_view_event_feed(
    request: Request,
    _user: CurrentUser,
    session: Annotated[Session, Depends(get_db_session)],
    since: datetime | None = None,
) -> list[ViewEventFeedItem]:
    """全文書の閲覧イベントを差分取得する（ADR-0013）。

    sinceは境界包含（occurred_at >= since）。境界重複は連携側のDD登録冪等キー
    （文書ID+発生日時）で排除される前提のため、取りこぼしゼロを優先する。
    """
    settings: Settings = request.app.state.settings
    query = (
        select(ViewEvent)
        .join(Document, ViewEvent.document_id == Document.document_id)
        .where(Document.tenant_id == settings.tenant_id)
    )
    if since is not None:
        query = query.where(ViewEvent.occurred_at >= since)
    events = session.scalars(query.order_by(ViewEvent.occurred_at, ViewEvent.id)).all()
    return [
        ViewEventFeedItem(
            id=row.id,
            document_id=row.document_id,
            event_type=row.event_type,
            occurred_at=row.occurred_at,
            client_ip=row.client_ip,
            user_agent=row.user_agent,
            page=row.page,
        )
        for row in events
    ]


@router.post(
    "/api/v1/view-urls/{view_url_id}/revoke", responses=problem_responses(401, 404)
)
def revoke_view_url(
    _user: CurrentUser,
    view_url_id: uuid.UUID,
    session: Annotated[Session, Depends(get_db_session)],
) -> dict[str, str]:
    view_token = session.get(ViewToken, view_url_id)
    if view_token is None:
        raise ProblemException(404, "view-url-not-found", "View URL not found")
    view_token.revoked = True
    session.commit()
    return {"status": "revoked"}


class RevokeAllResponse(BaseModel):
    status: str
    revoked_count: int


@router.post(
    "/api/v1/documents/{document_id}/view-urls/revoke-all",
    response_model=RevokeAllResponse,
    responses=problem_responses(401, 404),
)
def revoke_all_view_urls(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> RevokeAllResponse:
    """文書の未失効トークンを一括失効する（見積改訂時の旧版URL差し替え用）。

    対象0件でも200を返す（冪等。連携側の再実行で安全）。
    """
    _get_document_or_404(request, session, document_id)
    revoked_ids = session.scalars(
        update(ViewToken)
        .where(ViewToken.document_id == document_id)
        .where(ViewToken.revoked.is_(False))
        .values(revoked=True)
        .returning(ViewToken.id)
    ).all()
    session.commit()
    return RevokeAllResponse(status="revoked", revoked_count=len(revoked_ids))


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _record_event(
    request: Request,
    session: Session,
    document: Document,
    view_token: ViewToken,
    event_type: ViewEventType,
    page: int | None = None,
) -> None:
    """閲覧・DLイベントを記録する（追記型・配信成功経路でのみ呼ぶ）。

    冪等キー（文書ID+発生日時+種別）のUNIQUE制約衝突時は挿入をスキップし、
    配信自体は成功させる（記録の重複だけを防ぐ）。
    page は page_view のときのみ指定する（1始まり）。
    """
    session.add(
        ViewEvent(
            document_id=document.document_id,
            view_token_id=view_token.id,
            event_type=event_type.value,
            occurred_at=datetime.now(UTC),
            client_ip=_client_ip(request),
            user_agent=request.headers.get("user-agent", ""),
            page=page,
        )
    )
    try:
        session.commit()
    except IntegrityError as exc:
        logger.warning("view event not recorded: %s", exc)
        session.rollback()


def _resolve_token(
    request: Request, session: Session, token: str
) -> tuple[Document, ViewToken, bytes]:
    """トークンを検証し、対象文書・トークン行・PDFを返す。無効なら一律404。"""
    limiter: FailureRateLimiter = request.app.state.view_rate_limiter
    ip = _client_ip(request)
    if limiter.is_blocked(ip):
        raise ProblemException(429, "too-many-requests", "Too many requests")

    view_token = session.scalars(
        select(ViewToken).where(ViewToken.token_hash == _hash_token(token))
    ).one_or_none()
    valid = (
        view_token is not None
        and not view_token.revoked
        and view_token.expires_at > datetime.now(UTC)
    )
    if not valid or view_token is None:
        limiter.record_failure(ip)
        session.add(ViewAccessFailure(token_fragment=token[:8], client_ip=ip))
        session.commit()
        raise ProblemException(404, "not-found", "Not found")

    document = session.get(Document, view_token.document_id)
    if document is None:
        raise ProblemException(404, "not-found", "Not found")
    blob_storage: BlobStorage = request.app.state.blob_storage
    return document, view_token, blob_storage.load(document.blob_ref)


@router.get(
    "/view/{token}/pages",
    response_model=PagesResponse,
    responses=problem_responses(404, 429, 500),
)
def public_pages(
    request: Request,
    token: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> PagesResponse:
    document, view_token, pdf = _resolve_token(request, session, token)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        sizes = renderer.get_page_sizes(pdf)
    except PdfProcessingError as exc:
        raise ProblemException(
            500, "pdf-processing-failed", "Failed to process PDF"
        ) from exc
    _record_event(request, session, document, view_token, ViewEventType.VIEW)
    return PagesResponse(
        page_count=len(sizes),
        pages=[PageInfo(width=size.width, height=size.height) for size in sizes],
    )


@router.get(
    "/view/{token}/pages/{page}/image", responses=problem_responses(404, 429, 500)
)
def public_page_image(
    request: Request,
    token: str,
    page: int,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document, view_token, pdf = _resolve_token(request, session, token)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        png = renderer.render_page_png(pdf, page - 1)
    except IndexError:
        raise ProblemException(404, "page-not-found", "Page not found") from None
    except PdfProcessingError as exc:
        raise ProblemException(
            500, "pdf-processing-failed", "Failed to process PDF"
        ) from exc
    # Viewerは表示領域に入ったページだけ画像取得するため、取得成功＝ページ表示として記録する
    _record_event(
        request, session, document, view_token, ViewEventType.PAGE_VIEW, page=page
    )
    # 画像取得がpage_viewの記録契機のため、キャッシュから配信されないようにする
    return Response(
        content=png, media_type="image/png", headers={"Cache-Control": "no-store"}
    )


@router.get("/view/{token}/pdf", responses=problem_responses(404, 429))
def public_pdf(
    request: Request,
    token: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document, view_token, pdf = _resolve_token(request, session, token)
    _record_event(request, session, document, view_token, ViewEventType.DOWNLOAD)
    return pdf_response(document, pdf)
