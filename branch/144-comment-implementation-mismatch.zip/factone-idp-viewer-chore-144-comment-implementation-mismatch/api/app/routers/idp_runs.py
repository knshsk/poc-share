"""IDP実行API（項目抽出の実行と履歴参照）。

実行区分（初回/再実行）は同一文書IDの既存実行有無からサーバ側で判定する。
実行ログは追記型で、DI失敗時もエラー情報付きで記録する。
"""

import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field, StringConstraints, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import Document, IdpRun, IdpRunStatus, IdpRunType
from app.routers.documents import _get_document_or_404
from app.services.blob import BlobStorage
from app.services.di import DiError, DocumentAnalyzer
from app.services.document_type_config import (
    config_field_defs,
    config_pattern_defs,
    get_config,
)
from app.services.idp_extraction import (
    CellCorrection,
    UnknownCorrectionTarget,
    apply_corrections,
    match_patterns,
    parse_analysis,
    tables_to_json,
)

router = APIRouter(responses=problem_responses(401, 422))


class IdpRunSummary(BaseModel):
    """一覧用の軽量項目。項目値・テーブル・領域は詳細（IdpRunResponse）で取得する。"""

    run_id: uuid.UUID
    document_id: str
    run_type: IdpRunType
    status: IdpRunStatus
    executed_at: datetime
    # corrected 行のみ非 null（修正元の実行結果と修正者）
    base_run_id: uuid.UUID | None
    corrected_by: str | None
    di_api_version: str | None
    di_model_id: str | None
    error_info: str | None


class IdpRunResponse(IdpRunSummary):
    raw_fields: dict[str, str | None] | None
    normalized_fields: dict[str, str | int | None] | None
    confidence: dict[str, float | None] | None
    field_labels: dict[str, str] | None
    tables: list[dict[str, object]] | None
    pattern_matches: dict[str, dict[str, object]] | None
    field_regions: dict[str, dict[str, object] | None] | None
    # corrected 行のみ非 null。根の機械実行に対する人手差分の累積（修正ボディと同じ形）
    corrections: dict[str, object] | None


class IdpRunListResponse(BaseModel):
    document_id: str
    runs: list[IdpRunSummary]


CorrectionText = Annotated[str, StringConstraints(max_length=2000)]


class TableCellCorrection(BaseModel):
    table_index: int = Field(ge=0)
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    content: CorrectionText


class CorrectionRequest(BaseModel):
    """読取結果の差分修正。変更した項目・セルだけを送る（サーバがbaseとマージする）。"""

    fields: dict[str, CorrectionText | None] = {}
    table_cells: list[TableCellCorrection] = []

    @model_validator(mode="after")
    def _require_changes_and_unique_cells(self) -> CorrectionRequest:
        if not self.fields and not self.table_cells:
            raise ValueError("fields or table_cells is required")
        coords = [
            (c.table_index, c.row_index, c.column_index) for c in self.table_cells
        ]
        if len(coords) != len(set(coords)):
            raise ValueError("table_cells contains duplicate coordinates")
        return self


def _to_summary(run: IdpRun) -> IdpRunSummary:
    return IdpRunSummary(
        run_id=run.id,
        document_id=run.document_id,
        run_type=IdpRunType(run.run_type),
        status=IdpRunStatus(run.status),
        executed_at=run.executed_at,
        base_run_id=run.base_run_id,
        corrected_by=run.corrected_by,
        di_api_version=run.di_api_version,
        di_model_id=run.di_model_id,
        error_info=run.error_info,
    )


def _to_response(run: IdpRun) -> IdpRunResponse:
    return IdpRunResponse(
        **_to_summary(run).model_dump(),
        raw_fields=run.raw_fields,
        normalized_fields=run.normalized_fields,
        confidence=run.confidence,
        field_labels=run.field_labels,
        tables=run.tables,
        pattern_matches=run.pattern_matches,
        field_regions=run.field_regions,
        corrections=run.corrections,
    )


def _determine_run_type(session: Session, document_id: str) -> IdpRunType:
    exists = session.execute(
        select(IdpRun.id).where(IdpRun.document_id == document_id).limit(1)
    ).first()
    return IdpRunType.RERUN if exists else IdpRunType.INITIAL


@router.post(
    "/api/v1/documents/{document_id}/idp-runs",
    response_model=IdpRunResponse,
    status_code=201,
    responses=problem_responses(404, 409, 502),
)
def execute_idp_run(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunResponse:
    document: Document = _get_document_or_404(request, session, document_id)
    blob_storage: BlobStorage = request.app.state.blob_storage
    analyzer: DocumentAnalyzer = request.app.state.document_analyzer

    run_type = _determine_run_type(session, document_id)
    settings = request.app.state.settings
    config = get_config(session, settings.tenant_id, document.document_type)
    if config is None:
        raise ProblemException(
            409,
            "document-type-not-configured",
            "Document type is not configured for this tenant",
        )
    field_defs = config_field_defs(config)
    query_fields = tuple(f.key for f in field_defs)
    # 生応答のBlobパスに実行IDを使うため、INSERT前に採番する
    run_id = uuid.uuid4()
    run = IdpRun(
        id=run_id,
        document_id=document_id,
        run_type=run_type.value,
        executed_at=datetime.now(UTC),
    )
    try:
        results = analyzer.analyze(blob_storage.load(document.blob_ref), query_fields)
    except DiError as exc:
        run.status = IdpRunStatus.FAILED.value
        run.error_info = str(exc)
        session.add(run)
        session.commit()
        raise ProblemException(
            502, "document-analysis-failed", "Document analysis failed"
        ) from exc

    # 生応答はBlobに無変換で保存し、DBには参照のみ持つ（ADR-0019）。保存失敗は500で実行ログを残さない
    raw_response_ref = f"{settings.tenant_id}/{document_id}/idp-runs/{run_id}.json"
    blob_storage.save(raw_response_ref, results.raw_response)

    parsed = parse_analysis(field_defs, results.fields)
    run.status = IdpRunStatus.SUCCEEDED.value
    run.raw_fields = parsed.raw
    run.normalized_fields = parsed.normalized
    run.confidence = parsed.confidence
    run.field_labels = {f.key: f.label for f in field_defs}
    run.field_regions = parsed.regions
    run.tables = tables_to_json(results.tables)
    run.pattern_matches = match_patterns(config_pattern_defs(config), results.content)
    run.di_api_version = results.api_version
    run.di_model_id = results.model_id
    run.raw_response_ref = raw_response_ref
    session.add(run)
    session.commit()
    return _to_response(run)


@router.get(
    "/api/v1/documents/{document_id}/idp-runs",
    response_model=IdpRunListResponse,
    responses=problem_responses(404),
)
def list_idp_runs(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunListResponse:
    _get_document_or_404(request, session, document_id)
    runs = (
        session.execute(
            select(IdpRun)
            .where(IdpRun.document_id == document_id)
            .order_by(IdpRun.executed_at, IdpRun.id)
        )
        .scalars()
        .all()
    )
    return IdpRunListResponse(
        document_id=document_id, runs=[_to_summary(run) for run in runs]
    )


def _get_run_or_404(session: Session, document_id: str, run_id: uuid.UUID) -> IdpRun:
    run = session.get(IdpRun, run_id)
    # 他文書の実行IDは存在自体を秘匿するため404
    if run is None or run.document_id != document_id:
        raise ProblemException(404, "idp-run-not-found", "IDP run not found")
    return run


@router.get(
    "/api/v1/documents/{document_id}/idp-runs/latest",
    response_model=IdpRunResponse,
    responses=problem_responses(404),
)
def get_latest_idp_run(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    run_type: IdpRunType | None = None,
) -> IdpRunResponse:
    """最新の成功実行を返す。run_type 指定で区分を絞る（失敗実行は対象外）。"""
    _get_document_or_404(request, session, document_id)
    stmt = select(IdpRun).where(
        IdpRun.document_id == document_id,
        IdpRun.status == IdpRunStatus.SUCCEEDED.value,
    )
    if run_type is not None:
        stmt = stmt.where(IdpRun.run_type == run_type.value)
    run = session.execute(
        stmt.order_by(IdpRun.executed_at.desc(), IdpRun.id.desc()).limit(1)
    ).scalar_one_or_none()
    if run is None:
        raise ProblemException(404, "idp-run-not-found", "IDP run not found")
    return _to_response(run)


@router.get(
    "/api/v1/documents/{document_id}/idp-runs/{run_id}",
    response_model=IdpRunResponse,
    responses=problem_responses(404),
)
def get_idp_run(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    run_id: uuid.UUID,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunResponse:
    _get_document_or_404(request, session, document_id)
    return _to_response(_get_run_or_404(session, document_id, run_id))


@router.get(
    "/api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response",
    responses=problem_responses(404),
)
def get_raw_response(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    run_id: uuid.UUID,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    """DI生応答（最終ポーリング応答本文）をBlobから無変換で返す。失敗実行は参照が無く404。"""
    _get_document_or_404(request, session, document_id)
    run = _get_run_or_404(session, document_id, run_id)
    if run.raw_response_ref is None:
        raise ProblemException(
            404, "raw-response-not-found", "Raw response is not available"
        )
    blob_storage: BlobStorage = request.app.state.blob_storage
    return Response(
        content=blob_storage.load(run.raw_response_ref), media_type="application/json"
    )


def _accumulate_corrections(
    base: dict[str, object] | None, body: CorrectionRequest
) -> dict[str, object]:
    """base の累積差分（機械実行なら None）に今回の差分を重ねる。同一キー・同一セル座標は今回の値で上書き。"""
    if not base:
        return body.model_dump()
    prev = CorrectionRequest.model_validate(base)
    cells = {
        (c.table_index, c.row_index, c.column_index): c
        for c in (*prev.table_cells, *body.table_cells)
    }
    return CorrectionRequest(
        fields={**prev.fields, **body.fields}, table_cells=list(cells.values())
    ).model_dump()


@router.post(
    "/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections",
    response_model=IdpRunResponse,
    status_code=201,
    responses=problem_responses(404, 409),
)
def create_correction(
    request: Request,
    user: CurrentUser,
    document_id: str,
    run_id: uuid.UUID,
    body: CorrectionRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunResponse:
    """base（run_id）に差分を当てたcorrected行を追記する（ADR-0018）。

    正規化は現在の文書種別設定の型で行う。排他制御は行わず、同一baseへの並行修正は両方追記される。
    """
    document: Document = _get_document_or_404(request, session, document_id)
    base = _get_run_or_404(session, document_id, run_id)
    if base.status != IdpRunStatus.SUCCEEDED.value:
        raise ProblemException(
            409, "idp-run-not-correctable", "Failed IDP run cannot be corrected"
        )
    settings = request.app.state.settings
    config = get_config(session, settings.tenant_id, document.document_type)
    field_types = {f.key: f.type for f in config_field_defs(config)} if config else {}
    try:
        values = apply_corrections(
            base.raw_fields or {},
            base.normalized_fields or {},
            base.confidence or {},
            base.tables or [],
            body.fields,
            [CellCorrection(**c.model_dump()) for c in body.table_cells],
            field_types,
        )
    except UnknownCorrectionTarget as exc:
        raise ProblemException(422, "unknown-correction-target", str(exc)) from exc

    run = IdpRun(
        document_id=document_id,
        run_type=IdpRunType.CORRECTED.value,
        status=IdpRunStatus.SUCCEEDED.value,
        executed_at=datetime.now(UTC),
        raw_fields=values.raw,
        normalized_fields=values.normalized,
        confidence=values.confidence,
        tables=values.tables,
        field_labels=base.field_labels,
        pattern_matches=base.pattern_matches,
        field_regions=base.field_regions,
        di_api_version=base.di_api_version,
        di_model_id=base.di_model_id,
        raw_response_ref=base.raw_response_ref,
        base_run_id=base.id,
        corrected_by=user.username or user.sub,
        corrections=_accumulate_corrections(base.corrections, body),
    )
    session.add(run)
    session.commit()
    return _to_response(run)
