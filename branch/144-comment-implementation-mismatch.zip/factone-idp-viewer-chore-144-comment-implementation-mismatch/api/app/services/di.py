"""Document Intelligenceの境界アダプタ。

外部サービス（Azure Document Intelligence）への依存をProtocolで分離し、
テストではフェイクに差し替える。prebuilt-layout+Query Fieldsで項目指定抽出を行う。
"""

import io
from dataclasses import dataclass
from typing import Any, Protocol, cast


@dataclass(frozen=True)
class QueryFieldResult:
    """Query Fieldsの項目別抽出結果（生値・確信度・読取領域）。座標は元応答に無い場合None。"""

    value: str | None
    confidence: float | None
    page_number: int | None = None
    polygon: tuple[float, ...] | None = None


@dataclass(frozen=True)
class DiTableCell:
    """テーブルセル。座標（page_number・polygon）は元応答に無い場合None。"""

    row_index: int
    column_index: int
    content: str
    kind: str | None
    page_number: int | None
    polygon: tuple[float, ...] | None


@dataclass(frozen=True)
class DiTable:
    """DIが認識したテーブル領域（明細仮）。意味付けは行わず認識結果を素通しする。"""

    row_count: int
    column_count: int
    cells: tuple[DiTableCell, ...]


def extract_tables(tables: object) -> tuple[DiTable, ...]:
    """layout応答のtablesをDiTableへ変換する。複数認識時は全件返す。"""
    extracted: list[DiTable] = []
    for table in tables or []:  # type: ignore[attr-defined]
        cells = []
        for cell in table.cells or []:
            region = (cell.bounding_regions or [None])[0]
            cells.append(
                DiTableCell(
                    row_index=cell.row_index,
                    column_index=cell.column_index,
                    content=cell.content,
                    kind=cell.kind,
                    page_number=region.page_number if region else None,
                    polygon=tuple(region.polygon) if region else None,
                )
            )
        extracted.append(
            DiTable(
                row_count=table.row_count,
                column_count=table.column_count,
                cells=tuple(cells),
            )
        )
    return tuple(extracted)


def build_analysis_result(result: Any, raw_response: bytes) -> AnalysisResult:
    """SDKのAnalyzeResultと応答本文からAnalysisResultを組み立てる。

    Query Fieldsの座標は boundingRegions[0] を採用する（項目は通常1領域）。
    """
    extracted: dict[str, QueryFieldResult] = {}
    for document in result.documents or []:
        for name, field in (document.fields or {}).items():
            region = (field.bounding_regions or [None])[0]
            extracted[name] = QueryFieldResult(
                value=field.content,
                confidence=field.confidence,
                page_number=region.page_number if region else None,
                polygon=tuple(region.polygon) if region else None,
            )
    return AnalysisResult(
        fields=extracted,
        tables=extract_tables(result.tables),
        content=result.content or "",
        api_version=result.api_version,
        model_id=result.model_id,
        raw_response=raw_response,
    )


@dataclass(frozen=True)
class AnalysisResult:
    """解析結果。Query Fields抽出値・認識テーブル領域（明細仮）・全文テキストに加え、
    実行時のAPIバージョン・モデルID・生応答（最終ポーリング応答の本文bytes）を保持する。"""

    fields: dict[str, QueryFieldResult]
    tables: tuple[DiTable, ...]
    # 読み順で連結した全文テキスト。正規表現パターンマッチの対象
    content: str = ""
    api_version: str | None = None
    model_id: str | None = None
    # DIの最終ポーリングGET応答本文（status/createdDateTime/analyzeResultを含むラッパ込み）を無変換で保持
    raw_response: bytes = b""


class DiError(Exception):
    """Document Intelligence呼出の失敗（タイムアウト・サービス障害・未設定）。"""


class DocumentAnalyzer(Protocol):
    """PDF解析の境界。query_fieldsで指定した項目の抽出結果とテーブル領域を返す。"""

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult: ...


class UnconfiguredAnalyzer:
    """接続先未設定時のプレースホルダ（ローカル開発でDI未設定のまま起動可能にする）。"""

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult:
        raise DiError("Document Intelligence endpoint is not configured")


class AzureDocumentAnalyzer:
    """Azure Document Intelligence実装（prebuilt-layout+Query Fields）。

    api_key未設定時はManaged ID（DefaultAzureCredential）で認証する。
    """

    def __init__(self, endpoint: str, api_key: str, timeout_seconds: int) -> None:
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        from azure.core.credentials import AzureKeyCredential

        credential: object
        if api_key:
            credential = AzureKeyCredential(api_key)
        else:
            from azure.identity import DefaultAzureCredential

            credential = DefaultAzureCredential()
        self._client = DocumentIntelligenceClient(endpoint, credential)
        self._timeout_seconds = timeout_seconds

    def analyze(self, pdf: bytes, query_fields: tuple[str, ...]) -> AnalysisResult:
        from azure.ai.documentintelligence.models import DocumentAnalysisFeature
        from azure.core.exceptions import AzureError

        # 最終ポーリングGETの応答本文をbytesのまま受け取るため、デシリアライズ結果と併せて返す
        def capture(
            pipeline_response: Any, deserialized: Any, _headers: Any
        ) -> tuple[Any, bytes]:
            return deserialized, pipeline_response.http_response.content

        try:
            poller = self._client.begin_analyze_document(
                "prebuilt-layout",
                io.BytesIO(pdf),
                content_type="application/pdf",
                features=[DocumentAnalysisFeature.QUERY_FIELDS],
                query_fields=list(query_fields),
                cls=capture,
            )
            # result(timeout)はタイムアウト時に例外を出さず未完了応答を返すため、done()で判定する
            poller.wait(timeout=self._timeout_seconds)
            if not poller.done():
                raise DiError("Document Intelligence request timed out")
            deserialized, raw_response = cast(tuple[Any, bytes], poller.result())
        except AzureError as exc:
            raise DiError(str(exc)) from exc
        return build_analysis_result(deserialized, raw_response)


def create_document_analyzer(
    endpoint: str, api_key: str, timeout_seconds: int
) -> DocumentAnalyzer:
    if endpoint:
        return AzureDocumentAnalyzer(endpoint, api_key, timeout_seconds)
    return UnconfiguredAnalyzer()
