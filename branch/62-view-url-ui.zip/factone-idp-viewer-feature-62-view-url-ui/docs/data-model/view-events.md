# 閲覧・DLイベント（view_events）

閲覧URL経由の閲覧・ダウンロード記録。追記型（更新・削除しない）。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | |
| document_id | varchar(255) | NOT NULL・FK(documents) | 対象文書。**案件IDは保持しない**（外部連携側が文書IDから解決） |
| view_token_id | uuid | NOT NULL・FK(view_tokens) | どの閲覧URL経由か（発行台帳との紐付け） |
| event_type | varchar(20) | NOT NULL・CHECK | `view`（閲覧）/ `download`（原本DL） |
| occurred_at | timestamptz | NOT NULL | 発生日時（配信時にサーバで記録） |
| client_ip | varchar(64) | NOT NULL | 端末情報 |
| user_agent | varchar(512) | NOT NULL | 端末情報 |

- **UNIQUE(document_id, occurred_at, event_type)** — 冪等キー（文書ID+イベント発生日時）のDB制約。衝突時は挿入スキップ（配信は成功させ、記録の重複だけ防ぐ）

## 記録ポイント

APIプロキシ配信が唯一の関門である決定に基づき、公開閲覧経路の配信成功時にのみ記録する。

| 経路 | イベント |
| --- | --- |
| `GET /view/{token}/pages` 成功 | view（文書を開いた=1閲覧） |
| `GET /view/{token}/pdf` 成功 | download |
| `GET /view/{token}/pages/{page}/image` | 記録しない（viewの一部。二重記録防止） |
| 無効トークンのアクセス | 記録しない（失敗記録 `view_access_failures` 側に残る） |
| 社内（認証済み）表示 | **記録しない**（ルート型注文書を含め社内閲覧イベントは履歴化しない。ADR-0012） |

## 取得（外部連携IF-04）

`GET /api/documents/{document_id}/events`（JWT必須）が外部連携（Power Automate等）向けの正式契約。

- 取得方式: REST pull。連携側が文書IDを指定して取得する（案件IDから文書IDへの解決は連携側の責務）
- 応答: 該当文書の全イベントを `occurred_at` 昇順で返す。ページネーションなし（文書ID単位の取得のため件数増を考慮しない）
- 応答項目: `id` / `event_type` / `occurred_at` / `client_ip` / `user_agent`。`view_token_id` は内部管理値のため応答に含めない
- 認証: Keycloakの M2M クライアント（client credentials）で取得したアクセストークンを利用可
- 文書が存在しない場合は404、イベント未発生の場合は空リスト
