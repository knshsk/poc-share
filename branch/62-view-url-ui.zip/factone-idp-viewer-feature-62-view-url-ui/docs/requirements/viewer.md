# Viewer 機能要件

Viewer（レーン7／OX層／商品化対象SaaS・画面）に求められる機能要件。

出所: [../business/operation-flow.md](../business/operation-flow.md) レーン定義（レーン7）、K3・K5・R1 の各シーケンス。

## 機能要件

### VW-01: 見積PDFの閲覧用URL発行

- 内容: 文書IDに紐づく見積PDFの閲覧用URLを発行する。
- 出所工程: K3（K3-2〜K3-3）
- 補足:
  - 案件型のみ。ルート型には見積工程がないため対象外。
  - Viewerの起動はD365 CRM画面からWalkMe経由で行われ、文書IDは起動パラメータとして受領する（VW-06）。
  - 閲覧用URLは不透明トークン方式とする（[ADR-0011](../adr/0011-view-url-opaque-token.md)）。
- 関連対象外事項: なし

### VW-02: 得意先による見積PDFの閲覧・ダウンロード提供

- 内容: 閲覧用URLを受け取った得意先が、見積PDFを閲覧・ダウンロードできる。
- 出所工程: K3（K3-5）
- 補足:
  - 閲覧用URLのメール送達はD365 CRM＋営業の責務であり、Viewerは送達を行わない（送達の正本＝CRMの営業活動履歴）。
- 関連対象外事項: なし

### VW-03: 閲覧・ダウンロードのイベント記録

- 内容: 得意先による見積PDFの閲覧・ダウンロードを、文書ID付きのイベントとして記録する。
- 出所工程: K3（K3-6）
- 補足:
  - 社内閲覧イベントは履歴化しない（[ADR-0012](../adr/0012-no-internal-view-event-history.md)）。
  - イベントの分析利用（Engagement History・REスコア化）はDX層（DataDelivery・Databricks）の責務であり、Viewerは記録と提供までを担う。
- 関連対象外事項: なし

### VW-04: 閲覧ログの外部提供

- 内容: 記録した閲覧ログを、外部（Power Automate）が差分取得できる形で提供する。
- 出所工程: K3（K3-9。日次バッチでPower Automateが差分取得し、文書IDから案件IDを解決してDataDeliveryへ登録。冪等キー: 文書ID＋イベント発生日時）
- 補足:
  - 文書IDから案件IDへの解決はPower Automateの責務。Viewerは文書ID付きイベントの提供までを担う。
- 関連対象外事項: なし

### VW-05: 注文書PDFの社内表示・原本照合支援

- 内容: 注文書PDFを社内向けに表示し、SAP承認時の原本照合を支援する。
- 出所工程: K5（K5-5）・R1（R1-5）
- 補足:
  - 表示は承認時／必要な場合のみの任意操作。
  - **注文書は顧客へ開示しない（閲覧用URLを発行しない）。** 閲覧用URLの発行対象は見積PDFのみ（VW-01）。
- 関連対象外事項: OUT-07（注文書PDFのDD登録は日次連携で許容。Viewerに即時登録の責務はない）

### VW-06: 画面からのIDP実行・結果表示

- 内容: 画面の「IDP実行」ボタンから同一SaaS内のIDPを呼び出し、項目化結果を画面に表示する。
- 出所工程: K5（K5-5〜K5-6）・R1（R1-5〜R1-6）
- 補足:
  - 項目化結果に疑義がある場合の再項目化に用いる。SAP画面への反映はWalkMe【SAP】の責務。
- 関連対象外事項: OUT-06（確信度による自動／手動の振り分けは行わない。全件Human in the Loop）

### VW-07: 起動パラメータによる文書IDの受領

- 内容: 呼出側（WalkMe経由のCRM画面・SAP画面）から起動パラメータで文書IDを受領し、対象文書を特定する。
- 出所工程: K3(K3-2)・K5・R1
- 補足:
  - 文書IDを自ら解決・採番しない（境界参照）。

## 境界（非責務）

- 注文書の顧客開示は行わない（注文書の閲覧用URLは発行しない）。
- 案件ID・ルートIDは受領・保持しない（顧客の業務体系に属するキーのため）。
- 文書IDを自ら解決・採番しない（呼出側からパラメータで受領するのみ）。
- 閲覧用URLのメール送達は行わない（D365 CRM＋営業の責務）。
- 閲覧ログの案件IDへの紐付け・蓄積・分析は行わない（Power Automate・DataDelivery・Databricksの責務）。

## 関連ドキュメント

- 設計: [../viewer/](../viewer/)（画面設計）、[../data-model/view-tokens.md](../data-model/view-tokens.md)（閲覧トークン）、[../data-model/view-events.md](../data-model/view-events.md)（閲覧イベント）、[../api/](../api/)（API設計）
- ADR: [0011 閲覧用URLの不透明トークン](../adr/0011-view-url-opaque-token.md)、[0012 社内閲覧イベントの非履歴化](../adr/0012-no-internal-view-event-history.md)
