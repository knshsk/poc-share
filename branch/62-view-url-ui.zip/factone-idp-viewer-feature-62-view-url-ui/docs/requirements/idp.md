# IDP 機能要件

IDP（レーン8／OX層／商品化対象SaaS・API）に求められる機能要件。本PJのIDPはAzure AI Document Intelligenceを指す。

出所: [../business/operation-flow.md](../business/operation-flow.md) レーン定義（レーン8）、K2・K4・K5・R1 の各シーケンス。

## 機能要件

### IDP-01: 見積PDF・WBS原価データの文字化（項目化）

- 内容: 見積PDF・WBS原価データを文字化（項目化）し、項目データを返却する。
- 出所工程: K2（K2-6）
- 補足:
  - 呼出元はPower Automate（連携フォルダ監視トリガーで起動）。
  - 案件IDの解決・検証・付与は呼出後にPower Automateが行う（K2-7）。
- 関連対象外事項: OUT-17（見積の同日複数版は扱わない）

### IDP-02: 注文書PDFの項目化

- 内容: 注文書PDFをスキャンして項目化し、品目・数量・納期・単価を返却する。
- 出所工程: K4（K4-5〜K4-6）
- 補足:
  - 呼出元はPower Automate。項目化結果を用いた型区分判定（案件型／ルート型）・案件ID引き当て・ルートID採番はPower Automateの責務。
  - 1PDF＝1文書IDを前提とする。
- 関連対象外事項: OUT-03（1PDFに複数注文書が含まれるケースは扱わない）、OUT-15（判定不能時のエラー停止はPower Automateの責務）

### IDP-03: 確信度の返却

- 内容: 項目化結果とあわせて確信度を返却する。
- 出所工程: K2・K4
- 補足:
  - PoCでは確信度は返却・記録のみ行い、閾値判定は行わない。全件Human in the Loop（SAP承認ワークフロー）で確認する。
- 関連対象外事項: OUT-06（確信度による自動／手動の振り分けは行わない）、OUT-09（サンプルデータのため読取精度・確信度分布はPoCでは測定できない）

### IDP-04: REST APIとしての提供

- 内容: 文字化・項目化機能をREST APIとして提供し、Power AutomateおよびViewerから呼出可能とする。
- 出所工程: K2（K2-6）・K4（K4-5）・K5（K5-6）・R1（R1-6）
- 補足:
  - Viewerからの呼出は、承認時に項目化結果へ疑義がある場合の再項目化に用いる（Viewer側要件: VW-06）。

## 境界（非責務）

- 案件ID・ルートIDの解決・付与は行わない（Power Automateの責務）。
- 顧客固有の名寄せロジックは持たない。
- 確信度による自動・手動の振り分け判定は行わない（Power Automateの責務としても本PoCでは対象外＝OUT-06）。
- 型区分判定（案件型／ルート型の振り分け）は行わない（Power Automateの責務）。

## 関連ドキュメント

- 設計: [../api/](../api/)（API設計）、[../data-model/idp-runs.md](../data-model/idp-runs.md)（IDP実行）、[../data-model/documents.md](../data-model/documents.md)（文書）
- 要件: [viewer.md](viewer.md)（VW-06: 画面からのIDP実行）
