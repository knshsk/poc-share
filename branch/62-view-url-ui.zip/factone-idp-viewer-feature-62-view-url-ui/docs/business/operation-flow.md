# 業務フロー

FactONEが対象とする業務フローに関するドキュメント。

## 関係者定義

- 【案】: 案件型固有の内容
- 【ル】: ルート型固有の内容
- 【共】: 案件型、ルート型共通の内容

| #   | レーン名 | プール | 層区分 | 責務（担うこと） | 非責務（担わないこと＝境界） |
| --- | -------- | ------ | ------ | ---------------- | ---------------------------- |
| 1 | 得意先 | 社外 | 社外 | 【案】引合・仕様を提示する／見積PDFを閲覧・DLする<br/>【共】注文書を発行・送付する<br/>【ル】繰返し発注 | 社内処理には関与しない（外部主体＝ブラックボックスとして内部プロセスは展開しない） |
| 2 | 営業（自社） | 自社 | 人 | 【案】商談を登録し、見積もりを依頼・開示操作する<br/>【共】注文書PDFを受領し連携フォルダへ配置する／SAP承認画面で確認・修正・承認する（＝目視補正）／受注を登録する<br/>【ル】MGRアラート（D5/V5）を確認しフォロー方針を判断する／EWMAのα値・D/V閾値を改定する | キーの採番・解決・付与は行わない（→ PowerAutomate）<br/>型区分判定は行わない（→ PowerAutomate）<br/>※本来は「営業担当」と「営業マネージャー」の別役割だが、PoCでは本レーンに集約する |　　
| 3 | D365 CRM | 自社 | 既存システム | 【案】引合・商談・活動履歴・案件IDを保持する／見積の閲覧用URLを得意先へメール送達し、開示日時を活動履歴に記録する（送達の正本＝営業活動履歴） | 受注・発注実績は保持しない<br/>【ル】未使用（見積工程がないため） |　　
| 4 | 見積システム | 自社 | 既存システム | 【案】見積PDF・WBS原価データを出力する／見積IDを自ら採番する | 改修負荷・APIなし＝自動連携機能を持たない（出力ファイルは人手で連携フォルダへ配置）<br/>【ル】未使用（見積工程がないため） |　　
| 5 | SAP ERP | 自社 | 既存システム | 受注以降の基幹として受注オーダを保持し、未承認→承認・確定の状態を管理する<br/>【案】受注確定時にWBSを採番する<br/>【ル】受注確定時に在庫引当・出荷指示を行い、分納時は納入日程行を生成する | WBS採番はルート型では行わない<br/>得意先へ返す帳票（請書・納期回答書）は発行しない<br/>請求・売上計上は扱わない |　　
| 6 | WalkMe<br/>（図中表記: WalkMe【CRM】／WalkMe【SAP】） | 自社 | OX層 | 既存画面（CRM入力画面／SAP承認画面）にオーバレイし、案件ID・ルートID・文書IDを自動セットする／これらの必須化・形式検査を担う（本機能はWalkMeに一本化する） | 採番・生成のロジックを持たない（PowerAutomateを同期呼び出しして受領するのみ） |　　
| 7 | **Viewer** | 自社 | OX層／**商品化対象SaaS**（画面） |【案】見積の閲覧用URLを発行し、閲覧・DLを記録する<br/>【共】注文書を社内表示し、IDP実行と結果表示を担う（※1）  | 注文書は顧客へ開示しない（閲覧用URLを発行しない）<br/>案件ID・ルートIDを受領・保持しない（顧客の業務体系に属するキーのため）<br/>文書IDを自ら解決・採番しない（呼出側からパラメータで受領するのみ） |　　
| 8 | **IDP** | 自社 | OX層／**商品化対象SaaS**（API） | PDFの文字化・項目化を行い、確信度を返却する（※1） | 案件ID・ルートIDの解決・付与を行わない（→ PowerAutomate）<br/>顧客固有の名寄せロジックを持たない<br/>確信度による自動・手動の振り分け判定を行わない |　　
| 9 | PowerAutomate | 自社 | 連携層(EAI) | 採番マスタを保持し、案件ID・ルートID・文書IDを採番・解決・検証・付与する<br/>型区分判定を行い、案件型／ルート型の経路を振り分ける<br/>SAPへ受注オーダを転記する（＝未承認登録）<br/>イベント起動＋日次バッチで各レーン間の連携を実行する | 見積ID（見積システム）・WBS・受注ID（SAP）は管轄外<br/>独自のエラー記録・通知・退避処理は行わない |　　
| 10 | DataDelivery（DD） | 自社 | DX層 | 実績情報を統一管理する<br/>【案】案件ID単位で商談・活動・閲覧ログ・見積・受注実績を蓄積する／月末時点の案件の状態・受注確度と売上予定金額を凍結し、2時点比較と成立させる（D13・D14）<br/>【ル】ルートID単位で発注実績を時系列蓄積する／予測結果を世代別に保管し、実績＋予測のVIEW合成と月次スナップショットの凍結を担う（予測の正本＝DD） | 予測の算出は行わない（算出 → Databricks／保管・凍結 → DataDelivery）<br/>EDI由来の実績は取りこまない |　　
| 11 | Databricks・ダッシュボード | 自社 | DX層 | 【案】REスコア算出・前月差分の差異分類・受注確度×REスコアによる見込み算出<br/>【ル】EWMA需要予測・D/V格付け（CV方式）・予測精度の検証（誤差率）・MGRアラート表示<br/>【統】統合フォーキャスト算出・ドリルダウン・増減理由の提示 | 打ち手（安全在庫・数量バッファ等）の実行・在庫施策への反映は行わない<br/>プッシュ通知は行わない（ダッシュボード表示まで）<br/>D・Vを掛け合わせず、予測値・確度へ自動反映しない |　　

※1 Viewer（レーン7／画面）とIDP（レーン8／API）は同一のマルチテナントSaaSの2つの提供形態。Viewer画面の「IDP実行」ボタンから同一SaaS内のIDPを呼び出し、項目化結果を画面に表示する。

## K1: 引合・商談

```mermaid
sequenceDiagram
    participant C as 得意先
    participant S as 営業（自社）
    participant W as WalkMe【CRM】
    participant CRM as D365 CRM
    participant PA as Power Automate
    participant DD as DataDelivery（DD）
    Note over C,DD: K1 引合・商談（案件型）
    C->>S: K1-1 引合・仕様を提示する<br/>〔業務行為〕
    Note over C,S: メール・電話など
    S->>CRM: K1-2 D365 CRMに引合/商談を登録し受注確度入力<br/>〔業務行為〕
    W->>PA: K1-3 案件ID採番要求<br>REST API(要求)
    PA-->>W: K1-4 新規案件ID返却<br>▼新規案件ID<br/>REST API(応答)
    W->>CRM: K1-5 CRM入力画面オーバーレイ<br/>案件ID設定・必須化・形式検査<br/>▼案件ID付き入力値
    CRM->>CRM: K1-6 案件ID付き商談・活動履歴保持<br/>▼案件ID付き引合・商談情報（仕様・受注確度・活動履歴）
    Note over CRM,PA: 処理開始：日次バッチ
    CRM->>PA: K1-7 商談・活動データ差分取得(日次)<br/>OData<br/>▼商談・活動データ
    PA->>DD: DBコネクタ？
    DD->>DD: K1-8 案件ID単位で商談・活動データ蓄積
    Note over DD: 処理終了
```

## K2: 原価積算・見積

```mermaid
sequenceDiagram
    participant EIGYO as 営業（自社）<br/>（人）
    participant IDP as IDP<br/>（OX層／商品化対象SaaS（API））
    participant MITSU as 見積システム<br/>（既存システム）
    participant PA as Power Automate<br/>（連携層（EAI））
    participant DD as DataDelivery（DD）<br/>（DX層）

    Note over EIGYO: 処理開始
    EIGYO->>MITSU: K2-1 見積システムで原価積算・見積書を作成する〔業務行為〕（画面操作）
    Note over MITSU: K2-2 原価積算結果・見積データを保持する（見積番号を採番）
    MITSU-->>EIGYO: K2-3 見積PDFとWBS原価データを出力する<br/>▼見積PDF／WBS原価データ（ファイル出力・手動DL／API無し）
    EIGYO->>PA: K2-4 出力ファイルを連携フォルダへ人手で配置する〔業務行為〕<br/>▼連携フォルダ格納ファイル（ファイル配置）
    Note over PA: K2-5 連携フォルダを監視しファイル配置を検知してフロー起動（フォルダ監視トリガー）。1ファイルごとに文書IDを発行<br/>▼フロー起動イベント／文書ID
    PA->>IDP: K2-6 見積PDF・WBSの文字化（項目化）を要求（REST API 要求）
    IDP-->>PA: K2-6 見積PDF・WBSを文字化（項目化）し文字データ等を返却<br/>▼項目データ（REST API 応答）
    Note over PA: K2-7 案件IDを解決・検証し項目データへ付与する
    PA->>DD: K2-8 IDP処理完了後、項目データ・見積PDFをDDへ登録（冪等キー：案件ID＋文書ID）（DBコネクタ）
    Note over DD: K2-9 見積PDF本体と項目データ・WBSを案件IDにぶら下げて保管する<br/>▼案件ID別 見積・WBSレコード
    Note over DD: 処理終了
```

## K3: 見積提示・フォロー

```mermaid
sequenceDiagram
    participant CUS as 得意先（社外）
    participant SAL as 営業（自社）（人）
    participant WM as WalkMe【CRM】（OX層）
    participant VW as Viewer（画面/SaaS）
    participant CRM as D365 CRM（既存システム）
    participant PA as Power Automate（EAI）
    participant DD as DataDelivery（DX層）
    participant DBX as Databricks・ダッシュボード（DX層）

    Note over SAL: 処理開始
    SAL->>WM: K3-1 D365 CRMからWalkMe経由でViewerを起動し<br/>見積PDFを開示する〔業務行為〕
    WM->>VW: K3-2 【CRM】CRM画面からViewerを起動し文書IDを受け渡す<br/>▼ Viewer起動パラメータ
    VW-->>SAL: K3-3 文書IDに紐づく見積PDFの閲覧用URLを発行する<br/>▼ 見積PDF閲覧用URL（文書ID付）
    SAL->>CUS: K3-4 見積PDFの閲覧用URLを得意先へメール送信<br/>▼ 開示通知メール
    SAL->>CRM: K3-4 送信記録を活動履歴に登録する<br/>▼ CRM活動履歴（開示日時）
    CUS->>VW: K3-5 見積PDFを閲覧・ダウンロードする〔業務行為〕
    Note over VW: K3-6 閲覧・DLをイベントとして記録する<br/>▼ 閲覧ログ（文書ID付）
    SAL->>CRM: K3-7 顧客フォローの活動・日報をCRMに登録する〔業務行為〕
    Note over CRM: K3-8 案件ID付きの活動履歴・日報DATAを保持する

    Note over PA: 処理開始：日次バッチ
    VW-->>PA: 閲覧ログ（差分取得）
    PA->>DD: K3-9 閲覧ログを差分取得し、文書IDから案件IDを解決しDDへ登録<br/>（冪等キー：文書ID＋イベント発生日時）
    CRM-->>PA: 日報・活動履歴（差分取得）
    PA->>DD: K3-10 日報DATA・活動履歴を差分取得しDDへ登録（日次）<br/>▼ 日報・活動集約データ
    Note over DD: K3-11 閲覧ログ・日報を案件ID単位で蓄積する

    Note over DBX: 処理開始：画面アクセス
    DD-->>DBX: ▼ 案件ID別 Engagement History
    DBX->>SAL: K3-12 Engagement HistoryをREスコア（5段階）化し<br/>受注確度（A〜D）と対比する ▼ REスコア／確度対比結果
    Note over SAL: K3-13 反応のある案件を優先フォローし<br/>失注リスクを早期に検知する〔業務行為〕
```

## K4: 受注前処理_共通

```mermaid
sequenceDiagram
    autonumber
    participant C as 得意先<br/>（社外）
    participant S as 営業（自社）<br/>（人）
    participant PA as Power Automate<br/>（連携層（EAI））
    participant IDP as IDP<br/>（OX層／商品化対象SaaS（API））

    Note over C: K4-1 注文書PDFを発行・送付する〔業務行為〕
    C->>S: ▼注文書PDF（メール・郵送・FAX）
    Note over S: K4-2 得意先から注文書PDFを受領する<br/>（SAP画面の操作は承認時に行う）〔業務行為〕<br/>▼受領した注文書PDF
    Note over S: K4-3 受領した注文書PDFを連携フォルダへ配置する〔業務行為〕
    S->>PA: ▼連携フォルダ格納ファイル（注文書PDF）（ファイル配置）
    Note over PA: K4-4 連携フォルダを監視し、ファイル配置を検知してフローを起動。<br/>1ファイル＝1文書IDで文書IDを発行する ▼文書ID
    PA->>IDP: K4-5 IDPをAPI呼出して注文書PDFを項目化する<br/>▼IDP呼出要求（REST API 要求）
    Note over IDP: K4-6 注文書PDFをSCANし項目化する<br/>（品目・数量・納期・単価を返却）
    IDP-->>PA: ▼注文項目データ（REST API 応答）
    Note over PA: K4-7 得意先コード×品目コードで品目マスタを照会し型区分を判定する<br/>▼型区分判定結果
    alt 型区分判定結果＝案件型
        Note over PA: K4-8 商談・見積情報から案件IDを引き当てる<br/>▼案件ID → 以降はK5受注登録へ
    else 型区分判定結果＝ルート型
        Note over PA: K4-9 得意先コード×品目コードを名寄せキーとして採番APIを呼出し、<br/>ルートIDを get-or-create で採番する<br/>▼ルートID → 以降はR1受注登録へ
    end
```

## K5: 受注登録

```mermaid
sequenceDiagram
    autonumber
    actor Sales as 営業（自社）
    participant WalkMe as WalkMe【SAP】
    participant Viewer as Viewer
    participant IDP as IDP
    participant SAP as SAP ERP
    participant PA as Power Automate
    participant DD as DataDelivery（DD）

    Note over PA: 処理開始：「K4受注前処理_共通」のフローを実施<br/>（注文書受領～案件ID引き当てまで）
    PA->>SAP: K5-1 案件IDを用い、SAPへ受注オーダを転記する<br/>▼ 引き当て済み案件ID／案件ID付き登録データ
    Note over SAP: K5-2 【未承認登録】Power Automateから転記された受注オーダを<br/>承認ワークフローの未承認ステータスで登録する〔前工程完了〕<br/>▼ 受注データ（未承認）
    Note over SAP: 処理終了（承認待ち）

    Note over Sales: 処理開始：営業がSAP画面にアクセス
    WalkMe->>Sales: K5-3 【SAP】SAPの承認画面にオーバーレイし、案件ID・文書IDを表示<br/>▼ 入力値（案件ID・文書ID）
    Sales->>SAP: K5-4 SAPのワークフローで未承認の受注データを確認し、IDPの読取結果に<br/>誤りがあれば修正したうえで承認して確定する〔業務行為〕<br/>▼ 承認済み受注データ（確定）
    opt 承認時／必要な場合のみ（原本照合・再項目化）
        Sales->>Viewer: K5-5 注文書PDFを表示し原本照合を支援。疑義がある場合は画面からIDPを実行<br/>▼ 表示画面／再項目化結果
        Viewer->>IDP: K5-6 IDPを実行し、文字データを読み取る（REST API）
        IDP->>WalkMe: K5-7 【SAP】IDP結果をSAP画面に反映する
        WalkMe-->>Sales: 反映結果（SAP画面）
    end
    Note over SAP: K5-8 【承認後の確定】承認を受けて受注を確定する
    Note over SAP: 処理終了

    Note over PA: 処理開始：日次バッチ
    SAP->>PA: K5-9 SAP受注実績を取得しDDへ連携登録する（OData）<br/>▼ 案件ID別 受注実績データ
    PA->>DD: K5-10 注文書PDF・注文DATA・WBS DATA・受注データを案件ID単位で保管する
    Note over DD: 処理終了
```

## R1: 受注登録

```mermaid
sequenceDiagram
    autonumber
    participant EI as 営業（自社）<br/>（人）
    participant WM as WalkMe【SAP】<br/>（OX層）
    participant VW as Viewer<br/>（OX層/SaaS画面）
    participant IDP as IDP<br/>（OX層/SaaS API）
    participant SAP as SAP ERP<br/>（既存システム）
    participant PA as Power Automate<br/>（連携層/EAI）
    participant DD as DataDelivery（DD）<br/>（DX層）

    rect rgb(235, 244, 255)
    Note over PA,SAP: 処理開始：「K4受注前処理_共通」のフローを実施<br/>（注文書受領～ルートID発行まで）
    PA->>SAP: R1-1 型区分判定でルート型と判定された注文書について、<br/>SAPへ受注オーダを転記する<br/>▼ ルートID付き登録データ
    Note over SAP: R1-2 Power Automateから転記された<br/>受注オーダを登録する<br/>▼ 受注データ（未承認）
    Note over PA,SAP: 処理終了
    end

    rect rgb(235, 255, 240)
    Note over EI: 処理開始：営業がSAP画面にアクセス
    WM->>EI: R1-3 【SAP】SAPの承認画面にオーバーレイし、<br/>ルートID・文書IDを表示する<br/>▼ ルートID付き入力値（承認画面）
    Note over EI: R1-4 SAPのワークフローで未承認の受注データを確認し、<br/>IDPの読取結果に誤りがあれば修正、分納が必要な場合は<br/>分納設定（納入日程行）を行ったうえで承認して確定する〔業務行為〕<br/>▼ 承認済み受注データ（確定/分納設定を含む）

    opt 項目化結果に疑義がある場合
    EI->>VW: R1-5 【承認時/必要な場合のみ】注文書PDFを社内表示し<br/>原本照合を支援する（顧客開示なし）。疑義がある場合は<br/>画面からIDPを再実行する<br/>▼ 表示画面（文書ID紐づけ済）/再項目化結果
    VW->>IDP: R1-6 【必要な場合のみ】IDPを実行し、<br/>文字データを読み取る（REST API）
    IDP->>WM: R1-7 【SAP/必要な場合のみ】IDP結果を<br/>SAP画面に反映する（画面操作）
    WM-->>EI: 再項目化結果を承認画面へ反映
    end

    EI->>SAP: R1-8 【承認後の確定】承認を受けて受注を確定する
    Note over EI,SAP: 処理終了
    end

    rect rgb(255, 248, 235)
    Note over SAP,DD: 処理開始：日次バッチ
    SAP->>DD: R1-9 SAP受注実績を取得しDDへ連携する（OData）<br/>▼ SAP受注データ
    Note over DD: R1-10 ルートID（得意先×品目）単位で発注実績<br/>（発注日・数量・間隔）を時系列で蓄積する
    Note over DD: 処理終了
    end
```

## F1: 案件型の見込み算出

```mermaid
sequenceDiagram
    participant DD as DataDelivery（DD）<br/>（DX層）
    participant DB as Databricks・ダッシュボード<br/>（DX層）

    Note over DD: 処理開始：月次バッチ
    DD->>DD: F1-1 月次スナップショットを作成する<br/>（2時点比較を成立させる）
    Note over DD: ▼ 月次スナップショット
    DD->>DB: DBコネクタ？（▼ 月次スナップショットを連携）
    DB->>DB: F1-2 前月差分を失注・スリップ・増減・新規に自動分類する
    DB->>DB: F1-3 受注確度×REスコアから案件型の受注・売上見込みを算出する
    Note over DB: ▼ 案件型の受注・売上見込み
    Note over DB: 処理終了
```

## F2: 需要予測

```mermaid
sequenceDiagram
    autonumber
    participant DB as Databricks・ダッシュボード<br/>（DX層）
    participant DD as DataDelivery（DD）<br/>（DX層）

    Note over DB,DD: 【予測系】処理開始：発注イベント都度（DDへ発注実績が蓄積されたとき）
    DB->>DB: F2-1 [予測系]ルートIDごとに発注量のEWMAを算出する
    Note right of DB: ▼ 発注量EWMA
    DB->>DB: F2-2 [予測系]ルートIDごとに発注サイクル（平均発注間隔）のEWMAを算出する
    Note right of DB: ▼ 発注サイクルEWMA
    DB->>DB: F2-3 [予測系]EWMA（発注量／発注サイクル、α値で加重）から次回の発注時期・数量を予測する（D・V評価は安定度の指標であり予測値には掛け合わせない）
    Note right of DB: ▼ 次回発注予測（時期・数量）
    DB->>DD: F2-4 [予測系]予測結果を生成日付きでForecastHistory（物理・INSERT ONLY）へ登録する（冪等キー：ルートID＋計上月＋生成日／新世代で対象期間の全月を上書きし、サイクルが着地しない月は0を計上）
    Note right of DD: ▼ ForecastHistory（生成日別 予測レコード）
    Note over DB,DD: 処理終了

    Note over DB,DD: 【格付け】処理開始：月次バッチ
    DB->>DB: F2-5 [格付け]V：Variable＝発注量のCV（標準偏差÷平均）を算出し5段階（V1〜V5）に格付けする
    Note right of DB: ▼ V評価（1〜5）
    Note over DB,DD: 処理終了

    Note over DB,DD: 【格付け】処理開始：月次バッチ
    DB->>DB: F2-6 [格付け]D：Delay＝発注サイクル（発注間隔）のCV（標準偏差÷平均）を算出し5段階（D1〜D5）に格付けする
    Note right of DB: ▼ D評価（1〜5）
    Note over DB,DD: 処理終了

    Note over DB,DD: 【日次モニタ】処理開始：日次バッチ
    DB->>DB: F2-7 [日次モニタ]新規発注の実績値とEWMA期待値の乖離率を算出し、閾値超過分をダッシュボードに当日フラグ表示する（瞬間指標／CV方式のD・V格付けとは役割を分ける）
    Note right of DB: ▼ EWMA乖離フラグ（当日）
    Note over DB,DD: 処理終了
```

## F3: 精度検証

```mermaid
sequenceDiagram
    participant DD as DataDelivery（DD）<br/>（DX層）
    participant DB as Databricks・ダッシュボード<br/>（DX層）
    participant Sales as 営業（自社）<br/>（人）

    Note over DD: 処理開始：月次バッチ
    Note over DD: F3-1 実績（OrderHistory）と最新世代の予測（ForecastHistory）を合成したVIEWを計上月別に集計し、<br/>月中は仮想／月末は翌月第2営業日に物理スナップショットとして凍結する<br/>（Actual優先→無い月は最新生成日のForecastを採用）
    DD->>DB: ▼ 予測スナップショット
    Note over DB: F3-2 予測と受注実績の誤差率を検証する
    Note over DB: ▼ 精度検証結果
    Note over DB: F3-3 全案件をD×Vの2軸マトリクス上に配置してダッシュボードに表示。<br/>D5かつV5（AND条件）に該当するルートIDをMGRアラート対象として強調表示する
    Note over DB: ▼ D×Vマトリクス（MGRアラート対象＝D5×V5を強調表示）
    Note over DB: 処理終了

    Note over Sales: 処理開始：ダッシュボードへアクセス
    DB-->>Sales: ▼ D×Vマトリクス
    Note over Sales: F3-4 D×Vマトリクスをダッシュボードで確認し、<br/>MGRアラート対象（D5かつV5）を案件（スポット）扱い・個別フォロー対象の案件として確認する
    Note over Sales: F3-5 検証結果をもとにEWMAのα値・D/V評価の閾値を調整する<br/>（※α値は次回のF2で反映）<br/>〔業務行為〕
    Note over Sales: ▼ パラメータ改定
    Note over Sales: 処理終了

    Note over DB: 処理開始：月次バッチ
    Note over DB: F3-6 予測結果からルート型の売上見込みを算出する〔月次バッチ〕
    Note over DB: ▼ ルート型の売上見込み
    Note over DB: 処理終了
```

## F4: 統合販売フォーキャスト

```mermaid
sequenceDiagram
    participant DB as Databricks・ダッシュボード<br/>（DX層）
    participant EIGYO as 営業（自社）<br/>（人）

    Note over DB: 処理開始：月次バッチ
    DB->>DB: F4-1 案件型の受注・売上見込みとルート型の売上見込みを<br/>案件ID・ルートID単位で単純合算する<br/>▼ 統合販売フォーキャスト
    DB->>DB: F4-2 統合フォーキャストを表示し、型区分別・得意先別・<br/>品目別・案件別にドリルダウンできるようにする<br/>▼ REマネジメントダッシュボード
    DB->>DB: F4-3 差分→案件→注文書→元データへ遡及し、<br/>増減理由（失注・スリップ・増減・新規）を根拠付きで提示する<br/>▼ 増減理由の根拠データ
    Note over DB: 処理終了

    Note over EIGYO: 処理開始：ダッシュボードへアクセス
    EIGYO->>DB: ダッシュボードへアクセス
    DB-->>EIGYO: ▼ REマネジメントダッシュボード／増減理由の根拠データ
    EIGYO->>EIGYO: F4-4 事業部全体の着地見込みと増減理由を説明する〔業務行為〕<br/>▼ 事業部着地報告（PoCの最終アウトプット）
    Note over EIGYO: 処理終了
```