"""閲覧・DLイベント記録の統合テスト（厚くするテスト領域）。"""

import io
from typing import Any

import pypdfium2 as pdfium
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.models import ViewEvent


@pytest.fixture(scope="module")
def pdf_bytes() -> bytes:
    doc = pdfium.PdfDocument.new()
    doc.new_page(612, 792)
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


@pytest.fixture
def issued_token(doc_client: TestClient, pdf_bytes: bytes) -> str:
    response = doc_client.post(
        "/api/documents",
        data={"document_id": "ev-doc", "document_type": "quote"},
        files={"file": ("doc.pdf", pdf_bytes, "application/pdf")},
    )
    assert response.status_code == 201
    issued = doc_client.post("/api/documents/ev-doc/view-urls")
    assert issued.status_code == 201
    return str(issued.json()["view_path"]).removeprefix("/view/")


def fetch_events(test_database_url: str) -> list[ViewEvent]:
    engine = create_engine(test_database_url)
    with Session(engine) as session:
        events = list(session.scalars(select(ViewEvent)).all())
    engine.dispose()
    return events


def test_view_event_recorded_on_pages_access(
    doc_client: TestClient, issued_token: str, test_database_url: str
) -> None:
    """ページ閲覧成功でviewイベントが1件記録されることを確認する（欠損なし）。"""
    response = doc_client.get(
        f"/view/{issued_token}/pages", headers={"User-Agent": "test-agent/1.0"}
    )

    assert response.status_code == 200
    events = fetch_events(test_database_url)
    assert len(events) == 1
    assert events[0].event_type == "view"
    assert events[0].document_id == "ev-doc"
    assert events[0].user_agent == "test-agent/1.0"
    assert events[0].client_ip != ""
    assert events[0].view_token_id is not None


def test_download_event_recorded_on_pdf_access(
    doc_client: TestClient, issued_token: str, test_database_url: str
) -> None:
    """原本DL成功でdownloadイベントが記録されることを確認する。"""
    response = doc_client.get(f"/view/{issued_token}/pdf")

    assert response.status_code == 200
    events = fetch_events(test_database_url)
    assert len(events) == 1
    assert events[0].event_type == "download"


def test_page_image_access_does_not_record_event(
    doc_client: TestClient, issued_token: str, test_database_url: str
) -> None:
    """ページ画像の個別取得ではイベントが記録されないことを確認する（二重記録防止）。"""
    response = doc_client.get(f"/view/{issued_token}/pages/1/image")

    assert response.status_code == 200
    assert fetch_events(test_database_url) == []


def test_invalid_token_access_not_recorded(
    doc_client: TestClient, test_database_url: str
) -> None:
    """無効トークンのアクセスがイベント記録されないことを確認する。"""
    response = doc_client.get(f"/view/{'n' * 43}/pages")

    assert response.status_code == 404
    assert fetch_events(test_database_url) == []


def test_multiple_accesses_record_multiple_events(
    doc_client: TestClient, issued_token: str, test_database_url: str
) -> None:
    """複数回の閲覧がそれぞれ記録されることを確認する。"""
    assert doc_client.get(f"/view/{issued_token}/pages").status_code == 200
    assert doc_client.get(f"/view/{issued_token}/pages").status_code == 200
    assert doc_client.get(f"/view/{issued_token}/pdf").status_code == 200

    events = fetch_events(test_database_url)
    assert len(events) == 3
    assert sorted(e.event_type for e in events) == ["download", "view", "view"]


def test_duplicate_idempotency_key_not_recorded_twice(
    doc_client: TestClient,
    issued_token: str,
    test_database_url: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """同一冪等キー（文書ID+発生日時+種別）が二重記録されないことを確認する。"""
    from datetime import UTC, datetime

    import app.view_urls as view_urls_module

    fixed = datetime(2026, 8, 25, 12, 0, 0, tzinfo=UTC)

    class FixedDatetime:
        @staticmethod
        def now(tz: Any = None) -> datetime:
            return fixed

    monkeypatch.setattr(view_urls_module, "datetime", FixedDatetime)

    first = doc_client.get(f"/view/{issued_token}/pages")
    second = doc_client.get(f"/view/{issued_token}/pages")

    assert first.status_code == 200
    assert second.status_code == 200  # 配信は成功（記録の重複だけ回避）
    events = fetch_events(test_database_url)
    assert len(events) == 1


def test_events_list_api(
    doc_client: TestClient, issued_token: str, test_database_url: str
) -> None:
    """イベント一覧APIが記録を返すことを確認する（JWT必須）。"""
    doc_client.get(f"/view/{issued_token}/pages")
    doc_client.get(f"/view/{issued_token}/pdf")

    response = doc_client.get("/api/documents/ev-doc/events")

    assert response.status_code == 200
    items = response.json()
    assert len(items) == 2
    assert {item["event_type"] for item in items} == {"view", "download"}

    auth = doc_client.headers.pop("Authorization")
    assert doc_client.get("/api/documents/ev-doc/events").status_code == 401
    doc_client.headers["Authorization"] = auth


def test_events_list_response_shape_for_export(
    doc_client: TestClient, issued_token: str
) -> None:
    """外部連携契約（IF-04）: 応答が公開項目のみで構成され、内部ID（view_token_id）を含まないことを確認する。"""
    doc_client.get(f"/view/{issued_token}/pages")

    response = doc_client.get("/api/documents/ev-doc/events")

    assert response.status_code == 200
    items = response.json()
    assert len(items) == 1
    assert set(items[0]) == {
        "id",
        "event_type",
        "occurred_at",
        "client_ip",
        "user_agent",
    }


def test_events_list_ordered_by_occurred_at(
    doc_client: TestClient, issued_token: str
) -> None:
    """外部連携契約: イベントがoccurred_at昇順で返ることを確認する。"""
    doc_client.get(f"/view/{issued_token}/pages")
    doc_client.get(f"/view/{issued_token}/pdf")

    items = doc_client.get("/api/documents/ev-doc/events").json()

    occurred = [item["occurred_at"] for item in items]
    assert occurred == sorted(occurred)


def test_events_list_empty_for_document_without_events(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """イベント未発生の文書では空リストが返ることを確認する。"""
    response = doc_client.post(
        "/api/documents",
        data={"document_id": "ev-empty", "document_type": "quote"},
        files={"file": ("doc.pdf", pdf_bytes, "application/pdf")},
    )
    assert response.status_code == 201

    response = doc_client.get("/api/documents/ev-empty/events")

    assert response.status_code == 200
    assert response.json() == []


def test_events_list_unknown_document_returns_404(doc_client: TestClient) -> None:
    """存在しない文書IDでは404が返ることを確認する。"""
    assert doc_client.get("/api/documents/no-such-doc/events").status_code == 404
