<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import type { components } from '../api/schema'

type ViewUrlSummary = components['schemas']['ViewUrlSummary']

const props = defineProps<{
  documentId: string
}>()

const urls = ref<ViewUrlSummary[]>([])
// 発行直後の平文URL。再表示不可（サーバはハッシュのみ保持）のため発行時のみ提示する
const issuedUrl = ref<string | null>(null)
const issuing = ref(false)
const errorMessage = ref<string | null>(null)

async function loadUrls(): Promise<void> {
  errorMessage.value = null
  urls.value = []
  if (!props.documentId) return

  const { data, error } = await apiClient.GET(
    '/api/documents/{document_id}/view-urls',
    {
      params: { path: { document_id: props.documentId } },
    },
  )
  if (error || !data) {
    errorMessage.value = '閲覧URL一覧を取得できませんでした'
    return
  }
  urls.value = data
}

async function issueUrl(): Promise<void> {
  errorMessage.value = null
  issuing.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/documents/{document_id}/view-urls',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = '閲覧URLの発行に失敗しました'
      return
    }
    issuedUrl.value = `${window.location.origin}${data.view_path}`
    await loadUrls()
  } finally {
    issuing.value = false
  }
}

async function copyIssuedUrl(): Promise<void> {
  if (issuedUrl.value) await navigator.clipboard.writeText(issuedUrl.value)
}

async function revokeUrl(viewUrlId: string): Promise<void> {
  errorMessage.value = null
  const { error } = await apiClient.POST(
    '/api/view-urls/{view_url_id}/revoke',
    {
      params: { path: { view_url_id: viewUrlId } },
    },
  )
  if (error) {
    errorMessage.value = '閲覧URLの失効に失敗しました'
    return
  }
  await loadUrls()
}

function formatDateTime(value: string): string {
  return new Date(value).toLocaleString()
}

function isExpired(url: ViewUrlSummary): boolean {
  return new Date(url.expires_at).getTime() <= Date.now()
}

function statusLabel(url: ViewUrlSummary): string {
  if (url.revoked) return '失効'
  if (isExpired(url)) return '期限切れ'
  return '有効'
}

onMounted(() => void loadUrls())
watch(
  () => props.documentId,
  () => {
    issuedUrl.value = null
    void loadUrls()
  },
)
</script>

<template>
  <div>
    <div class="d-flex align-center mb-2">
      <v-btn
        data-testid="issue-view-url"
        :loading="issuing"
        :disabled="issuing || !documentId"
        @click="issueUrl"
      >
        閲覧URL発行
      </v-btn>
      <span v-if="errorMessage" class="text-error ml-4">{{
        errorMessage
      }}</span>
    </div>

    <div v-if="issuedUrl" class="d-flex align-center mb-2">
      <code data-testid="issued-url">{{ issuedUrl }}</code>
      <v-btn
        data-testid="copy-view-url"
        size="small"
        class="ml-2"
        @click="copyIssuedUrl"
      >
        コピー
      </v-btn>
    </div>

    <v-table v-if="urls.length > 0" density="compact">
      <thead>
        <tr>
          <th>発行日時</th>
          <th>有効期限</th>
          <th>状態</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="url in urls" :key="url.id" data-testid="view-url-row">
          <td>{{ formatDateTime(url.issued_at) }}</td>
          <td>{{ formatDateTime(url.expires_at) }}</td>
          <td>{{ statusLabel(url) }}</td>
          <td>
            <v-btn
              v-if="!url.revoked && !isExpired(url)"
              data-testid="revoke-view-url"
              size="small"
              @click="revokeUrl(url.id)"
            >
              失効
            </v-btn>
          </td>
        </tr>
      </tbody>
    </v-table>
  </div>
</template>
