<script setup lang="ts">
import { onMounted, ref } from 'vue'

import { apiClient } from '../api/client'
import IdpRunPanel from './IdpRunPanel.vue'
import PageSvg from './PageSvg.vue'
import ViewUrlPanel from './ViewUrlPanel.vue'

interface PageInfo {
  width: number
  height: number
}

// 呼出パラメータの文書IDのみを受領する（案件ID・ルートIDは要求しない）
const documentId = ref(
  new URLSearchParams(window.location.search).get('document_id') ?? '',
)
const pages = ref<PageInfo[]>([])
// 表示確定済の文書ID（入力途中の値と区別し、IDP実行パネルへ渡す）
const loadedDocumentId = ref<string | null>(null)
// 文書種別。閲覧URLパネルは顧客共有可の見積のみ表示する（ADR-0002。サーバ側でも403で担保）
const documentType = ref<string | null>(null)
const errorMessage = ref<string | null>(null)

async function loadDocument(): Promise<void> {
  errorMessage.value = null
  pages.value = []
  loadedDocumentId.value = null
  documentType.value = null
  if (!documentId.value) return

  const [docResult, pagesResult] = await Promise.all([
    apiClient.GET('/api/documents/{document_id}', {
      params: { path: { document_id: documentId.value } },
    }),
    apiClient.GET('/api/documents/{document_id}/pages', {
      params: { path: { document_id: documentId.value } },
    }),
  ])
  if (
    docResult.error ||
    !docResult.data ||
    pagesResult.error ||
    !pagesResult.data
  ) {
    errorMessage.value = '文書を取得できませんでした'
    return
  }
  documentType.value = docResult.data.document_type
  pages.value = pagesResult.data.pages
  loadedDocumentId.value = documentId.value
}

async function downloadOriginal(): Promise<void> {
  const { data, error } = await apiClient.GET(
    '/api/documents/{document_id}/pdf',
    {
      params: { path: { document_id: documentId.value } },
      parseAs: 'blob',
    },
  )
  if (error || !data) {
    errorMessage.value = '原本を取得できませんでした'
    return
  }
  const url = URL.createObjectURL(data)
  const link = document.createElement('a')
  link.href = url
  link.download = `${documentId.value}.pdf`
  link.click()
  URL.revokeObjectURL(url)
}

onMounted(() => {
  if (documentId.value) void loadDocument()
})
</script>

<template>
  <div>
    <v-text-field
      v-model="documentId"
      label="文書ID"
      density="compact"
      class="mb-2"
    />
    <v-btn class="mr-2" @click="loadDocument">表示</v-btn>
    <v-btn :disabled="pages.length === 0" @click="downloadOriginal"
      >原本DL</v-btn
    >
    <p v-if="errorMessage" class="text-error">{{ errorMessage }}</p>
    <ViewUrlPanel
      v-if="loadedDocumentId && documentType === 'quote'"
      :document-id="loadedDocumentId"
      class="my-4"
    />
    <IdpRunPanel
      v-if="loadedDocumentId"
      :document-id="loadedDocumentId"
      class="my-4"
    />
    <div v-for="(page, index) in pages" :key="index" class="my-4">
      <PageSvg
        :document-id="documentId"
        :page="index + 1"
        :width="page.width"
        :height="page.height"
      />
    </div>
  </div>
</template>
