import { defineStore } from 'pinia'
import { ref } from 'vue'

import type { components } from '../api/schema'

export type DocumentTypeValue = components['schemas']['DocumentType']

// 文書コンテキスト（AppHeaderとDocumentViewで共有）。データ取得はDocumentViewの責務
export const useDocumentStore = defineStore('document', () => {
  // 表示要求中の文書ID（URLパラメータ・手入力由来）。変更をDocumentViewがwatchして再取得する
  const documentId = ref('')
  // 表示確定済の文書ID（入力途中の値と区別し、作業パネルへ渡す）
  const loadedDocumentId = ref<string | null>(null)
  const documentType = ref<DocumentTypeValue | null>(null)

  return { documentId, loadedDocumentId, documentType }
})
