<script setup lang="ts">
import { PhSignOut, PhUserCircle } from '@phosphor-icons/vue'
import { ref } from 'vue'

import { useAuthStore } from '../stores/auth'
import type { DocumentTypeValue } from '../stores/document'
import { useDocumentStore } from '../stores/document'

const auth = useAuthStore()
const doc = useDocumentStore()
const editId = ref('')

const typeLabels: Record<DocumentTypeValue, string> = {
  quote: '見積',
  order_project: '注文書（案件）',
  order_route: '注文書（ルート）',
}

function openEdit(): void {
  editId.value = doc.documentId
}

function applyEditId(): void {
  if (editId.value) doc.documentId = editId.value
}
</script>

<template>
  <v-app-bar flat border density="comfortable" color="surface">
    <template #prepend>
      <span class="app-logo text-primary">FactONE Viewer</span>
    </template>

    <!-- 文書コンテキスト: 文書IDバッジ（クリックで再入力）+ 種別チップ -->
    <template v-if="doc.documentId">
      <v-menu location="bottom" :close-on-content-click="false">
        <template #activator="{ props: menuProps }">
          <v-btn
            v-bind="menuProps"
            variant="tonal"
            color="secondary"
            size="small"
            class="font-mono text-none ml-4"
            data-testid="header-document-id"
            @click="openEdit"
          >
            {{ doc.documentId }}
          </v-btn>
        </template>
        <v-card class="pa-3 d-flex ga-2" min-width="320">
          <v-text-field
            v-model="editId"
            label="文書ID"
            density="compact"
            hide-details
            data-testid="header-document-id-input"
            @keyup.enter="applyEditId"
          />
          <v-btn
            color="primary"
            data-testid="header-document-id-apply"
            @click="applyEditId"
          >
            表示
          </v-btn>
        </v-card>
      </v-menu>
      <v-chip
        v-if="doc.documentType"
        size="small"
        color="primary"
        variant="tonal"
        class="ml-2"
        data-testid="header-document-type"
      >
        {{ typeLabels[doc.documentType] }}
      </v-chip>
    </template>

    <template #append>
      <v-menu location="bottom end">
        <template #activator="{ props: menuProps }">
          <v-btn
            v-bind="menuProps"
            variant="text"
            data-testid="user-menu"
            class="text-none"
          >
            <PhUserCircle :size="20" class="mr-1" />
            {{ auth.username ?? '' }}
          </v-btn>
        </template>
        <v-list density="compact">
          <v-list-item data-testid="logout" @click="auth.logout">
            <template #prepend>
              <PhSignOut :size="18" class="mr-2" />
            </template>
            <v-list-item-title>ログアウト</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </template>
  </v-app-bar>
</template>

<style scoped>
.app-logo {
  font-weight: 700;
  font-size: 1rem;
  letter-spacing: 0.02em;
}
</style>
