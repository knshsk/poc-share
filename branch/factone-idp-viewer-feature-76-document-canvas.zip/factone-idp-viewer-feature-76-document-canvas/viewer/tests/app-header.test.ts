import { mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { describe, expect, it, vi } from 'vitest'
import { defineComponent } from 'vue'

// oidc-client-tsはjsdomで初期化できるがリダイレクトは発生させない
vi.mock('oidc-client-ts', () => ({
  UserManager: class {
    signoutRedirect = vi.fn()
    signinRedirect = vi.fn()
    signinCallback = vi.fn()
  },
  WebStorageStateStore: class {},
  InMemoryWebStorage: class {},
}))

import AppHeader from '../src/components/AppHeader.vue'
import { createAppVuetify } from '../src/plugins/vuetify'
import { useAuthStore } from '../src/stores/auth'
import { useDocumentStore } from '../src/stores/document'

// v-app-barはVuetifyレイアウト（v-app）配下が必要なためProbeで包む
const Probe = defineComponent({
  components: { AppHeader },
  template: '<v-app><AppHeader /></v-app>',
})

function mountHeader() {
  const pinia = createPinia()
  const wrapper = mount(Probe, {
    global: { plugins: [createAppVuetify(), pinia] },
  })
  return { wrapper, pinia }
}

describe('AppHeader', () => {
  // アプリバーにプロダクト名とユーザー名が表示されることを確認する
  it('プロダクト名とユーザー名を表示する', async () => {
    const { wrapper } = mountHeader()
    const auth = useAuthStore()
    auth.username = 'sales01'
    await wrapper.vm.$nextTick()

    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.text()).toContain('sales01')
  })

  // ユーザーメニューからログアウトを呼び出せることを確認する
  it('ログアウトボタンでauthStore.logoutを呼ぶ', async () => {
    const { wrapper } = mountHeader()
    const auth = useAuthStore()
    auth.username = 'sales01'
    const logoutSpy = vi.spyOn(auth, 'logout').mockResolvedValue()
    await wrapper.vm.$nextTick()

    await wrapper.get('[data-testid="user-menu"]').trigger('click')
    // v-menuの内容はteleportされるためdocumentから探す
    const logoutBtn = document.querySelector('[data-testid="logout"]')
    expect(logoutBtn).not.toBeNull()
    ;(logoutBtn as HTMLElement).click()
    expect(logoutSpy).toHaveBeenCalled()
  })

  // 文書コンテキスト（ID・種別）がヘッダに表示されることを確認する
  it('文書IDと種別チップを表示する', async () => {
    const { wrapper } = mountHeader()
    const auth = useAuthStore()
    auth.username = 'sales01'
    const doc = useDocumentStore()
    doc.documentId = 'doc-1'
    doc.documentType = 'order_project'
    await wrapper.vm.$nextTick()

    expect(wrapper.get('[data-testid="header-document-id"]').text()).toContain(
      'doc-1',
    )
    expect(
      wrapper.get('[data-testid="header-document-type"]').text(),
    ).toContain('注文書（案件）')
  })

  // バッジからの再入力でストアの文書IDが更新されることを確認する
  it('バッジメニューから文書IDを変更できる', async () => {
    const { wrapper } = mountHeader()
    const auth = useAuthStore()
    auth.username = 'sales01'
    const doc = useDocumentStore()
    doc.documentId = 'doc-1'
    await wrapper.vm.$nextTick()

    await wrapper.get('[data-testid="header-document-id"]').trigger('click')
    const input = document.querySelector(
      '[data-testid="header-document-id-input"] input',
    ) as HTMLInputElement
    expect(input).not.toBeNull()
    input.value = 'doc-2'
    input.dispatchEvent(new Event('input'))
    const apply = document.querySelector(
      '[data-testid="header-document-id-apply"]',
    ) as HTMLElement
    apply.click()
    expect(doc.documentId).toBe('doc-2')
  })
})
