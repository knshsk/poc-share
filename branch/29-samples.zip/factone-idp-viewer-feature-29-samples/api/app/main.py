from fastapi import FastAPI
from sqlalchemy.orm import Session, sessionmaker

from app.auth import CurrentUser, JwksKeySource, KeySource
from app.blob import BlobStorage, create_blob_storage
from app.config import Settings
from app.db import create_db_engine, create_session_factory
from app.documents import router as documents_router
from app.pdf_render import PdfiumRenderer, PdfRenderer
from app.view_urls import FailureRateLimiter
from app.view_urls import router as view_urls_router


def create_app(
    settings: Settings | None = None,
    key_source: KeySource | None = None,
    session_factory: sessionmaker[Session] | None = None,
    blob_storage: BlobStorage | None = None,
    pdf_renderer: PdfRenderer | None = None,
) -> FastAPI:
    settings = settings or Settings()
    key_source = key_source or JwksKeySource(settings.oidc_jwks_url)
    session_factory = session_factory or create_session_factory(
        create_db_engine(settings.database_url)
    )
    blob_storage = blob_storage or create_blob_storage(
        settings.blob_backend,
        settings.blob_local_dir,
        settings.blob_account_url,
        settings.blob_container,
    )

    app = FastAPI(title=settings.app_name)
    app.state.settings = settings
    app.state.key_source = key_source
    app.state.session_factory = session_factory
    app.state.blob_storage = blob_storage
    app.state.pdf_renderer = pdf_renderer or PdfiumRenderer()
    app.state.view_rate_limiter = FailureRateLimiter(
        settings.view_url_max_failures, settings.view_url_failure_window_seconds
    )

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/api/me")
    def me(user: CurrentUser) -> dict[str, str]:
        return {"sub": user.sub, "username": user.username}

    app.include_router(documents_router)
    app.include_router(view_urls_router)

    return app
