<script setup lang="ts">
import { PhFileDashed } from '@phosphor-icons/vue'
import { onMounted, ref } from 'vue'

import { apiClient } from '../api/client'

// 定型外フロー向けの手動登録フォーム。送信先は既存の POST /api/v1/documents（Power Automate と同一API）
const emit = defineEmits<{ registered: [documentId: string] }>()

const documentId = ref('')
const documentType = ref<string | null>(null)
const file = ref<File>()
const typeItems = ref<{ display_name: string; type_code: string }[]>([])
const submitting = ref(false)
const errorMessage = ref<string | null>(null)

onMounted(async () => {
  const { data } = await apiClient.GET('/api/v1/config/document-types')
  typeItems.value = data ?? []
})

async function submit(): Promise<void> {
  const type = documentType.value
  const pdf = file.value
  if (!documentId.value || !type || !pdf) return
  errorMessage.value = null
  submitting.value = true
  const form = new FormData()
  form.set('document_id', documentId.value)
  form.set('document_type', type)
  form.set('file', pdf)
  try {
    const { data, error } = await apiClient.POST('/api/v1/documents', {
      // OpenAPI型はbinary=stringだが実体はFile。multipart化はbodySerializerで行う
      body: {
        document_id: documentId.value,
        document_type: type,
        file: pdf as unknown as string,
      },
      bodySerializer: () => form,
    })
    if (error || !data) {
      errorMessage.value =
        error?.status === 409
          ? '文書IDは別の内容で登録済みです'
          : (error?.detail ?? '登録に失敗しました')
      return
    }
    // 200（同一内容の再送）も登録済みとして成功扱い
    emit('registered', data.document_id)
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <v-form @submit.prevent="submit">
    <v-select
      v-model="documentType"
      :items="typeItems"
      item-title="display_name"
      item-value="type_code"
      label="書類種別"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-document-type"
    />
    <v-text-field
      v-model="documentId"
      label="文書ID"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-document-id"
    />
    <!-- ドロップゾーン: D&D は accept 属性が効かないため filter-by-type で PDF 以外を拒否する。
         選択後はゾーン内にファイル名を表示し（inset-file-list）、高さを変えずに差し替え・解除できる -->
    <v-file-upload
      v-model="file"
      :icon="PhFileDashed"
      title="PDFファイルをドラッグ＆ドロップ、またはクリックして選択"
      browse-text="ファイルを変更"
      filter-by-type="application/pdf"
      density="comfortable"
      hide-browse
      inset-file-list
      clearable
      show-size
      class="register-dropzone mb-4"
      data-testid="register-file"
    />
    <v-alert
      v-if="errorMessage"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-4"
      data-testid="register-error"
    >
      {{ errorMessage }}
    </v-alert>
    <div class="d-flex justify-center">
      <v-btn
        type="submit"
        color="primary"
        min-width="120"
        :loading="submitting"
        :disabled="!documentId || !documentType || !file"
        data-testid="register-submit"
      >
        登録
      </v-btn>
    </div>
  </v-form>
</template>

<style scoped>
/* ドロップゾーン: 空/選択済みで高さを固定し、Vuetify 既定の見出しサイズを補助文言相当へ落とす */
.register-dropzone :deep(.v-file-upload-dropzone) {
  min-height: 168px;
  padding: 24px 16px;
}

.register-dropzone :deep(.v-file-upload-title) {
  font-size: 0.875rem;
  font-weight: 400;
  color: rgb(var(--v-theme-secondary));
}

.register-dropzone :deep(.v-file-upload-icon) {
  color: rgb(var(--v-theme-secondary));
  opacity: 1;
  margin-bottom: 0.25rem;
}
</style>
