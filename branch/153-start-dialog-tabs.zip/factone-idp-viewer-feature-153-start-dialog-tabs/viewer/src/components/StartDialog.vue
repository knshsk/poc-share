<script setup lang="ts">
import { PhFileArrowUp, PhFileMagnifyingGlass } from '@phosphor-icons/vue'
import { nextTick, ref, watch } from 'vue'

import { useDocumentStore } from '../stores/document'
import DocumentRegisterForm from './DocumentRegisterForm.vue'

// 文書ID未指定時の開始ダイアログ（文書を登録 / 文書IDで参照）。決定した文書IDはストアへ直接反映する
const store = useDocumentStore()
const tab = ref<'register' | 'view'>('register')
const inputId = ref('')
const inputRef = ref<{ focus: () => void } | null>(null)

// 参照タブは入力欄1本のため、切替時にフォーカスして即入力できるようにする
watch(tab, async (value) => {
  if (value !== 'view') return
  await nextTick()
  inputRef.value?.focus()
})

function applyInputId(): void {
  if (inputId.value) store.documentId = inputId.value
}
</script>

<template>
  <v-dialog :model-value="true" persistent max-width="560">
    <v-card rounded="lg">
      <v-tabs v-model="tab" grow color="primary" class="start-tabs">
        <v-tab value="register" data-testid="start-tab-register">
          <PhFileArrowUp :size="20" class="mr-2" />
          文書を登録
        </v-tab>
        <v-tab value="view" data-testid="start-tab-view">
          <PhFileMagnifyingGlass :size="20" class="mr-2" />
          文書IDで参照
        </v-tab>
      </v-tabs>

      <v-window v-model="tab">
        <!-- 定型外フロー向けの手動登録。登録済み文書IDをそのまま表示対象にする -->
        <v-window-item value="register">
          <DocumentRegisterForm
            class="pa-6 start-pane"
            @registered="(id) => (store.documentId = id)"
          />
        </v-window-item>

        <v-window-item value="view">
          <v-form
            class="pa-6 start-pane start-pane--view"
            @submit.prevent="applyInputId"
          >
            <v-text-field
              ref="inputRef"
              v-model="inputId"
              label="文書ID"
              density="compact"
              class="mb-4"
              hide-details
              data-testid="document-id-input"
            />
            <div class="d-flex justify-center">
              <v-btn
                type="submit"
                color="primary"
                min-width="120"
                :disabled="!inputId"
                data-testid="document-id-apply"
              >
                参照
              </v-btn>
            </div>
          </v-form>
        </v-window-item>
      </v-window>
    </v-card>
  </v-dialog>
</template>

<style scoped>
.start-tabs {
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* タブ切替でダイアログ高さが変わらないよう、両ペインを登録フォームの高さに揃える */
.start-pane {
  min-height: 376px;
}

/* 参照タブは入力欄1本のため縦中央に寄せる（grid は子を伸ばさない） */
.start-pane--view {
  display: grid;
  align-content: center;
}
</style>
