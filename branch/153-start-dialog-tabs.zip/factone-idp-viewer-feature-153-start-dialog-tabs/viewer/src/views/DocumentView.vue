<script setup lang="ts">
import { PhWarningCircle } from '@phosphor-icons/vue'
import { onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import { filenameFromDisposition, saveBlob } from '../utils/download'
import type { PageInfo } from '../components/DocumentCanvas.vue'
import DocumentCanvas from '../components/DocumentCanvas.vue'
import StartDialog from '../components/StartDialog.vue'
import WorkPanel from '../components/WorkPanel.vue'
import { useDocumentStore } from '../stores/document'
import type { IdpRun } from '../utils/runs'

const store = useDocumentStore()
const pages = ref<PageInfo[]>([])
const loading = ref(false)
const errorMessage = ref<string | null>(null)
const selectedRun = ref<IdpRun | null>(null)

async function loadDocument(): Promise<void> {
  errorMessage.value = null
  pages.value = []
  selectedRun.value = null
  store.loadedDocumentId = null
  store.documentType = null
  store.documentTypeDisplayName = null
  store.documentTypeShareable = false
  store.fieldDefs = []
  if (!store.documentId) return

  loading.value = true
  try {
    const [docResult, pagesResult, configsResult] = await Promise.all([
      apiClient.GET('/api/v1/documents/{document_id}', {
        params: { path: { document_id: store.documentId } },
      }),
      apiClient.GET('/api/v1/documents/{document_id}/pages', {
        params: { path: { document_id: store.documentId } },
      }),
      apiClient.GET('/api/v1/config/document-types'),
    ])
    if (
      docResult.error ||
      !docResult.data ||
      pagesResult.error ||
      !pagesResult.data
    ) {
      errorMessage.value = '文書を取得できませんでした'
      return
    }
    store.documentType = docResult.data.document_type
    // 種別設定（display_name・shareable・fields.visible）を反映する。
    // 設定取得失敗・設定なしは表示名フォールバック（種別コード表示）・共有不可・全項目表示のまま継続する
    const config = configsResult.data?.find(
      (c) => c.type_code === docResult.data.document_type,
    )
    store.documentTypeDisplayName = config?.display_name ?? null
    store.documentTypeShareable = config?.shareable ?? false
    // 設定なしは全項目表示のまま継続
    store.fieldDefs = config?.fields ?? []
    pages.value = pagesResult.data.pages
    store.loadedDocumentId = store.documentId
  } finally {
    loading.value = false
  }
}

async function downloadOriginal(): Promise<void> {
  const { data, error, response } = await apiClient.GET(
    '/api/v1/documents/{document_id}/pdf',
    {
      params: { path: { document_id: store.documentId } },
      parseAs: 'blob',
    },
  )
  if (error || !data) {
    errorMessage.value = '原本を取得できませんでした'
    return
  }
  saveBlob(
    data,
    filenameFromDisposition(
      response.headers.get('content-disposition'),
      `${store.documentId}.pdf`,
    ),
  )
}

onMounted(() => {
  // 呼出パラメータの文書IDのみを受領する（案件ID・ルートIDは要求しない）
  store.documentId =
    new URLSearchParams(window.location.search).get('document_id') ?? ''
  if (store.documentId) void loadDocument()
})

// ヘッダバッジ・empty stateからの再入力で再取得する
watch(
  () => store.documentId,
  () => void loadDocument(),
)
</script>

<template>
  <!-- 文書ID未指定: 開始ダイアログ（文書を登録 / 文書IDで参照） -->
  <StartDialog v-if="!store.documentId" />

  <!-- 取得失敗: エラーstate -->
  <div v-else-if="errorMessage" class="state-screen">
    <PhWarningCircle :size="48" class="text-error mb-4" />
    <p class="text-body-1 mb-4" data-testid="document-error">
      {{ errorMessage }}
    </p>
    <v-btn
      color="primary"
      variant="outlined"
      data-testid="document-retry"
      @click="loadDocument"
    >
      再試行
    </v-btn>
  </div>

  <!-- 2ペイン: 左キャンバス / 右作業パネル -->
  <div v-else class="document-layout">
    <section class="canvas-pane">
      <DocumentCanvas
        v-if="pages.length > 0"
        :document-id="store.documentId"
        :pages="pages"
        :run="selectedRun"
        :field-defs="store.fieldDefs"
        @download-original="downloadOriginal"
      />
      <div v-else class="canvas-loading">
        <v-skeleton-loader type="image" class="page-skeleton" />
      </div>
    </section>

    <aside class="work-pane">
      <WorkPanel
        v-if="store.loadedDocumentId && store.documentType"
        :document-id="store.loadedDocumentId"
        :shareable="store.documentTypeShareable"
        :field-defs="store.fieldDefs"
        @update:selected-run="selectedRun = $event"
      />
      <v-skeleton-loader v-else type="article" />
    </aside>
  </div>
</template>

<style scoped>
/* アプリバー・フッターを除いた高さで2ペインを固定し、ペイン内スクロールにする。
   --v-layout-top / --v-layout-bottom は Vuetify が v-main に設定する（子孫から継承で参照できる。
   v-main の外では 0px にフォールバックする）（app-bar 56px・footer 32px） */
.document-layout {
  display: grid;
  grid-template-columns: 1fr 528px;
  /* 行を minmax(0, 1fr) で固定する。auto 行だとコンテンツ（ページ高さ）で行が伸びてペイン内スクロールが
     効かず、キャンバスの ResizeObserver がズーム変更のたびに発火してフィットが1%ずつ反復収束する */
  grid-template-rows: minmax(0, 1fr);
  height: calc(100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px));
}

.canvas-pane {
  min-width: 0;
  min-height: 0;
}

.work-pane {
  min-height: 0;
  overflow: hidden;
  background: rgb(var(--v-theme-surface));
  border-left: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* 幅960px未満は縦積みフォールバック（作業パネルが上・キャンバスが下）。
   作業パネルは縦積み時も内部でスクロールする（固定高さでheight:100%を効かせる） */
@media (max-width: 960px) {
  .document-layout {
    display: flex;
    flex-direction: column-reverse;
    height: auto;
  }

  .canvas-pane {
    min-height: 60vh;
  }

  .work-pane {
    border-left: none;
    border-bottom: 1px solid
      rgba(var(--v-border-color), var(--v-border-opacity));
    height: 60vh;
  }
}
</style>
