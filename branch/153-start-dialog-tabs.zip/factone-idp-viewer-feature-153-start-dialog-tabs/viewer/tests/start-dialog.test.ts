import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// 登録フォームがマウント時に種別一覧を取得するためモックする（ダイアログはタブ切替と文書ID決定が検証対象）
const getMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return vi.fn()
    },
  },
}))

import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import StartDialog from '../src/components/StartDialog.vue'
import { useDocumentStore } from '../src/stores/document'

function mountDialog() {
  const pinia = createPinia()
  const wrapper = mount(StartDialog, {
    global: { plugins: [createAppVuetify(), pinia] },
  })
  return { wrapper, pinia }
}

// v-dialogの内容はbodyへteleportされるためdocumentから探す
function q<T extends Element = HTMLElement>(selector: string): T | null {
  return document.querySelector<T>(selector)
}

async function openViewTab() {
  q('[data-testid="start-tab-view"]')!.click()
  await flushPromises()
}

enableAutoUnmount(afterEach)

describe('StartDialog', () => {
  beforeEach(() => {
    getMock.mockReset()
    getMock.mockResolvedValue({ data: [], error: undefined })
  })

  // 初期表示は「文書を登録」タブで、登録フォームを表示し文書ID参照欄は出さないことを確認する
  it('初期表示は登録タブで登録フォームを表示する', async () => {
    const { wrapper } = mountDialog()
    await flushPromises()

    expect(q('[data-testid="start-tab-register"]')).not.toBeNull()
    expect(q('[data-testid="start-tab-view"]')).not.toBeNull()
    expect(wrapper.findComponent(DocumentRegisterForm).exists()).toBe(true)
    expect(q('[data-testid="document-id-input"]')).toBeNull()
  })

  // 参照タブへ切り替えると文書ID入力欄を表示し、入力欄へフォーカスすることを確認する
  it('参照タブ切替で文書ID入力欄を表示しフォーカスする', async () => {
    mountDialog()
    await flushPromises()
    await openViewTab()

    const input = q<HTMLInputElement>('[data-testid="document-id-input"] input')
    expect(input).not.toBeNull()
    expect(document.activeElement).toBe(input)
  })

  // 文書IDが空の間は参照ボタンを無効化することを確認する
  it('文書ID未入力では参照ボタンを無効化する', async () => {
    mountDialog()
    await flushPromises()
    await openViewTab()

    const button = q<HTMLButtonElement>('[data-testid="document-id-apply"]')!
    expect(button.disabled).toBe(true)

    const input = q<HTMLInputElement>(
      '[data-testid="document-id-input"] input',
    )!
    input.value = 'doc-1'
    input.dispatchEvent(new Event('input'))
    await flushPromises()

    expect(button.disabled).toBe(false)
  })

  // 参照ボタンで入力した文書IDをストアへ反映することを確認する
  it('参照で入力した文書IDをストアへ反映する', async () => {
    const { pinia } = mountDialog()
    await flushPromises()
    await openViewTab()

    const input = q<HTMLInputElement>(
      '[data-testid="document-id-input"] input',
    )!
    input.value = 'doc-1'
    input.dispatchEvent(new Event('input'))
    await flushPromises()
    q('[data-testid="document-id-apply"]')!.click()
    await flushPromises()

    expect(useDocumentStore(pinia).documentId).toBe('doc-1')
  })

  // 登録フォームの登録完了で、その文書IDをストアへ反映することを確認する
  it('登録完了した文書IDをストアへ反映する', async () => {
    const { wrapper, pinia } = mountDialog()
    await flushPromises()

    wrapper.findComponent(DocumentRegisterForm).vm.$emit('registered', 'doc-9')
    await flushPromises()

    expect(useDocumentStore(pinia).documentId).toBe('doc-9')
  })
})
