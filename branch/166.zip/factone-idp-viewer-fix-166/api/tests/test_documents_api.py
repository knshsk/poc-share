"""文書登録APIの統合テスト（実PostgreSQLコンテナ接続）。

事前に `podman compose up -d postgres` が必要。テスト専用DB（factone_test）を自動作成する。
共有フィクスチャ（doc_client等）は conftest.py を参照。
"""

from typing import Any

import pytest
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from app.core.auth import StaticKeySource
from app.core.config import Settings
from app.core.db import create_session_factory
from app.main import create_app
from app.models import Document
from app.routers import documents as documents_router
from app.routers.documents import _original_filename
from tests.conftest import InMemoryBlobStorage

PDF_BYTES = b"%PDF-1.7 minimal test pdf content"
PDF_BYTES_OTHER = b"%PDF-1.7 different content"


def post_document(
    client: TestClient,
    document_id: str = "doc-001",
    document_type: str = "quotation",
    content: bytes = PDF_BYTES,
    filename: str = "test.pdf",
    content_type: str = "application/pdf",
    original_filename: str | None = None,
) -> Any:
    data = {"document_id": document_id, "document_type": document_type}
    if original_filename is not None:
        data["original_filename"] = original_filename
    return client.post(
        "/api/v1/documents",
        data=data,
        files={"file": (filename, content, content_type)},
    )


def test_register_new_document_returns_201(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage
) -> None:
    """新規文書の登録が201となり、Blob保存とメタデータ返却が行われることを確認する。"""
    response = post_document(doc_client)

    assert response.status_code == 201
    body = response.json()
    assert body["document_id"] == "doc-001"
    assert body["document_type"] == "quotation"
    assert body["tenant_id"] == "default"
    assert list(blob_storage.saved.values()) == [PDF_BYTES]


def test_idempotent_resend_returns_200(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage
) -> None:
    """同一文書ID・同一内容の再送が200（冪等）となり、Blobを増やさないことを確認する。"""
    first = post_document(doc_client)
    second = post_document(doc_client)

    assert first.status_code == 201
    assert second.status_code == 200
    assert second.json()["document_id"] == "doc-001"
    assert len(blob_storage.saved) == 1


def test_same_id_different_content_returns_409(doc_client: TestClient) -> None:
    """同一文書IDで内容が異なる登録が409となることを確認する。"""
    post_document(doc_client)

    response = post_document(doc_client, content=PDF_BYTES_OTHER)

    assert response.status_code == 409


def test_same_id_different_type_returns_409(doc_client: TestClient) -> None:
    """同一文書ID・同一内容でも文書種別が異なる登録は409となることを確認する。"""
    post_document(doc_client)

    response = post_document(doc_client, document_type="purchase_order")

    assert response.status_code == 409


def test_non_pdf_content_returns_415(doc_client: TestClient) -> None:
    """PDF以外のファイルが415となることを確認する。"""
    response = post_document(
        doc_client,
        content=b"not a pdf",
        filename="test.txt",
        content_type="text/plain",
    )

    assert response.status_code == 415


def test_invalid_document_type_returns_422(doc_client: TestClient) -> None:
    """不正な文書種別が422となることを確認する。"""
    response = post_document(doc_client, document_type="invalid-type")

    assert response.status_code == 422


def test_register_requires_auth(
    test_database_url: str,
    signing_key: RSAPrivateKey,
    blob_storage: InMemoryBlobStorage,
) -> None:
    """トークンなしの登録が401となることを確認する。"""
    engine = create_engine(test_database_url)
    settings = Settings(_env_file=None, database_url=test_database_url)  # type: ignore[call-arg]
    app = create_app(
        settings=settings,
        key_source=StaticKeySource(signing_key.public_key()),
        session_factory=create_session_factory(engine),
        blob_storage=blob_storage,
    )
    client = TestClient(app)

    response = post_document(client)

    assert response.status_code == 401
    engine.dispose()


def test_config_registered_type_is_accepted(doc_client: TestClient) -> None:
    """CRUDで追加した種別が文書登録に使えることを確認する。"""
    doc_client.post(
        "/api/v1/config/document-types",
        json={
            "type_code": "invoice",
            "display_name": "請求書",
            "shareable": False,
            "fields": [{"key": "invoice_no", "label": "請求書番号", "type": "string"}],
        },
    )
    response = post_document(doc_client, document_type="invoice")
    assert response.status_code == 201
    assert response.json()["document_type"] == "invoice"


def _disposition(client: TestClient, document_id: str) -> str:
    response = client.get(f"/api/v1/documents/{document_id}/pdf")
    assert response.status_code == 200
    return response.headers["content-disposition"]


def test_original_pdf_uses_uploaded_filename(doc_client: TestClient) -> None:
    """原本DLのContent-Dispositionにアップロード時のファイル名（日本語含む）を返す。"""
    post_document(doc_client, document_id="doc-fn", filename="見積書 A.pdf")

    assert _disposition(doc_client, "doc-fn") == (
        'attachment; filename="doc-fn.pdf"; '
        "filename*=UTF-8''%E8%A6%8B%E7%A9%8D%E6%9B%B8%20A.pdf"
    )


def test_original_filename_strips_path_components(doc_client: TestClient) -> None:
    """パス付きファイル名はbasenameのみ保存する（Windows/POSIX区切り両方）。"""
    post_document(doc_client, document_id="doc-path", filename="C:\\dir\\sub/a b.pdf")

    assert _disposition(doc_client, "doc-path").endswith("filename*=UTF-8''a%20b.pdf")


def test_original_filename_field_overrides_multipart_filename(
    doc_client: TestClient,
) -> None:
    """original_filename フィールドを file の filename より優先する。

    Power Automate は multipart の filename の非ASCII文字を ? に置き換えて送るため、
    実際のファイル名を本文のフィールドで受ける。
    """
    created = post_document(
        doc_client,
        document_id="doc-field",
        filename="ABC???.pdf",
        original_filename="ABCあいう.pdf",
    )

    assert created.status_code == 201
    assert created.json()["original_filename"] == "ABCあいう.pdf"
    assert _disposition(doc_client, "doc-field").endswith(
        "filename*=UTF-8''ABC%E3%81%82%E3%81%84%E3%81%86.pdf"
    )


@pytest.mark.parametrize("value", ["", "  ", " \x00\u202e "])
def test_original_filename_field_blank_falls_back_to_multipart_filename(
    doc_client: TestClient, value: str
) -> None:
    """original_filename が空・空白のみ、または制御文字と空白だけなら file の filename を使う。"""
    created = post_document(
        doc_client, document_id="doc-blank", filename="a.pdf", original_filename=value
    )

    assert created.status_code == 201
    assert created.json()["original_filename"] == "a.pdf"


def test_original_filename_field_strips_path_components(doc_client: TestClient) -> None:
    """original_filename もパス付きなら basename のみ保存する。"""
    created = post_document(
        doc_client,
        document_id="doc-field-path",
        filename="x.pdf",
        original_filename="/Shared Documents/連携/見積.pdf",
    )

    assert created.status_code == 201
    assert created.json()["original_filename"] == "見積.pdf"


def test_original_filename_not_overwritten_by_resend(doc_client: TestClient) -> None:
    """冪等再送でファイル名が違っても初回のファイル名を維持する。"""
    post_document(doc_client, document_id="doc-re", filename="first.pdf")
    assert (
        post_document(
            doc_client, document_id="doc-re", filename="second.pdf"
        ).status_code
        == 200
    )

    assert _disposition(doc_client, "doc-re").endswith("filename*=UTF-8''first.pdf")


def test_original_pdf_falls_back_to_document_id(
    doc_client: TestClient, test_database_url: str
) -> None:
    """ファイル名未保存の既存文書は従来どおり {document_id}.pdf で返す。"""
    post_document(doc_client, document_id="doc-null")
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(
            text(
                "UPDATE documents SET original_filename = NULL WHERE document_id = 'doc-null'"
            )
        )
    engine.dispose()

    assert _disposition(doc_client, "doc-null") == (
        "attachment; filename=\"doc-null.pdf\"; filename*=UTF-8''doc-null.pdf"
    )


def test_original_pdf_with_non_ascii_document_id(
    doc_client: TestClient, test_database_url: str
) -> None:
    """文書IDの非ASCII文字・`"` は filename の代替名で `_` に置き換え、保存名は filename* で返す。

    応答ヘッダは latin-1 で符号化されるため、文書IDをそのまま埋めると 500 になっていた。
    """
    post_document(doc_client, document_id='見積"1', filename="a.pdf")

    assert _disposition(doc_client, '見積"1') == (
        "attachment; filename=\"___1.pdf\"; filename*=UTF-8''a.pdf"
    )

    # ファイル名未保存なら文書IDの保存名を filename* で返す
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(
            text(
                "UPDATE documents SET original_filename = NULL WHERE document_id = :id"
            ),
            {"id": '見積"1'},
        )
    engine.dispose()

    assert _disposition(doc_client, '見積"1') == (
        "attachment; filename=\"___1.pdf\"; filename*=UTF-8''%E8%A6%8B%E7%A9%8D%221.pdf"
    )


def test_document_response_includes_original_filename(doc_client: TestClient) -> None:
    """登録（201）・再送（200）・取得（GET）の応答に原本ファイル名が入ることを確認する。"""
    created = post_document(doc_client, document_id="doc-name", filename="見積書 A.pdf")
    assert created.status_code == 201
    assert created.json()["original_filename"] == "見積書 A.pdf"

    # 再送は初回のファイル名のまま（上書きしない）
    resent = post_document(doc_client, document_id="doc-name", filename="other.pdf")
    assert resent.status_code == 200
    assert resent.json()["original_filename"] == "見積書 A.pdf"

    fetched = doc_client.get("/api/v1/documents/doc-name")
    assert fetched.status_code == 200
    assert fetched.json()["original_filename"] == "見積書 A.pdf"


def test_document_response_original_filename_is_null_when_unknown(
    doc_client: TestClient, test_database_url: str
) -> None:
    """ファイル名未保存の文書（列追加前の行など）は null を返す。"""
    post_document(doc_client, document_id="doc-noname")
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(
            text(
                "UPDATE documents SET original_filename = NULL WHERE document_id = 'doc-noname'"
            )
        )
    engine.dispose()

    fetched = doc_client.get("/api/v1/documents/doc-noname")
    assert fetched.status_code == 200
    assert fetched.json()["original_filename"] is None


@pytest.mark.parametrize(
    ("filename", "expected"),
    [
        ("a\x00b.pdf", "ab.pdf"),
        ("a\tb\x7f.pdf", "ab.pdf"),
        ("a\x85b.pdf", "ab.pdf"),
        ("in\u202evoice.pdf", "invoice.pdf"),
        ("\u2066a\u2069\u200f\u061c.pdf", "a.pdf"),
        ("C:\\dir\\a\x00b.pdf", "ab.pdf"),
        (" \x01 見積.pdf \x02 ", "見積.pdf"),
        ("\x00" * 10 + "a" * 300, "a" * 255),
        ("\x00\u202e", None),
        ("dir/", None),
        ("a\u200d\xa0\u2029\u202f\u206ab.pdf", "a\u200d\xa0\u2029\u202f\u206ab.pdf"),
        (None, None),
    ],
)
def test_original_filename_removes_control_characters(
    filename: str | None, expected: str | None
) -> None:
    """制御文字（Cc）と双方向制御文字（Bidi_Control）を除いてから前後の空白を除き、255文字で切り詰める。"""
    assert _original_filename(filename) == expected


def test_original_filename_field_with_control_characters_is_stored_without_them(
    doc_client: TestClient,
) -> None:
    """original_filename の NUL・双方向制御文字を除いて保存し、文書を取得できることを確認する。"""
    created = post_document(
        doc_client,
        document_id="doc-ctl-name",
        filename="x.pdf",
        original_filename="見\x00積\u202e書.pdf",
    )

    assert created.status_code == 201
    assert created.json()["original_filename"] == "見積書.pdf"
    fetched = doc_client.get("/api/v1/documents/doc-ctl-name")
    assert fetched.status_code == 200
    assert fetched.json()["original_filename"] == "見積書.pdf"


@pytest.mark.parametrize(
    "document_id",
    [
        "a\x00b",
        "a\x01b",
        "a\tb",
        "a\x7fb",
        "a\x85b",
        "a\u061cb",
        "a\u200fb",
        "a\u202eb",
        "a\u2066b",
    ],
    ids=["NUL", "SOH", "TAB", "DEL", "NEL", "ALM", "RLM", "RLO", "LRI"],
)
def test_register_rejects_control_characters_in_document_id(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage, document_id: str
) -> None:
    """document_id が制御文字・双方向制御文字を含むと422になり、Blobに保存しないことを確認する。"""
    response = post_document(doc_client, document_id=document_id)

    assert response.status_code == 422
    body = response.json()
    assert body["type"] == "/errors/validation-error"
    assert "errors" not in body
    assert not blob_storage.saved


def test_blob_name_uses_internal_id(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage, test_database_url: str
) -> None:
    """PDFのBlob名は、呼出側の文書IDではなく内部ID（documents.id）から作ることを確認する。"""
    assert post_document(doc_client, document_id="doc-blob").status_code == 201

    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        row = conn.execute(
            text("SELECT id, blob_ref FROM documents WHERE document_id = 'doc-blob'")
        ).one()
    engine.dispose()
    assert row.blob_ref == f"default/{row.id}.pdf"
    assert list(blob_storage.saved) == [row.blob_ref]


def test_reregister_after_failed_insert_succeeds(
    doc_client: TestClient,
    blob_storage: InMemoryBlobStorage,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """挿入が失敗してBlobが残っても、同じ文書IDで再登録できることを確認する。

    テスト用のBlobStorageはAzureと同じく同名のBlobを上書きしないため、
    Blob名が文書IDから決まると、2回目の保存が失敗する。
    """
    original_commit = Session.commit
    failures = [OperationalError("COMMIT", None, Exception("connection lost"))]

    def commit_failing_once(self: Session) -> None:
        if failures:
            raise failures.pop()
        original_commit(self)

    monkeypatch.setattr(Session, "commit", commit_failing_once)

    with pytest.raises(OperationalError):
        post_document(doc_client, document_id="doc-retry")
    assert len(blob_storage.saved) == 1

    response = post_document(doc_client, document_id="doc-retry")

    assert response.status_code == 201
    assert len(blob_storage.saved) == 2


def test_concurrent_registration_falls_back_to_existing_row(
    doc_client: TestClient,
    blob_storage: InMemoryBlobStorage,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """同時登録の2本目は、挿入が一意制約に当たると冪等判定（内容違いなら409）に戻り、
    1本目の行とBlobを変えないことを確認する。

    2本目の照会が1本目の挿入より先に行われた状況を、照会を1回だけ該当なしにして再現する。
    """
    assert post_document(doc_client, document_id="doc-race").status_code == 201
    real_find = documents_router.find_document
    skipped: list[bool] = []

    def find_missing_once(
        session: Session, tenant_id: str, document_id: str
    ) -> Document | None:
        if not skipped:
            skipped.append(True)
            return None
        return real_find(session, tenant_id, document_id)

    monkeypatch.setattr(documents_router, "find_document", find_missing_once)

    response = post_document(
        doc_client, document_id="doc-race", content=PDF_BYTES_OTHER
    )

    assert response.status_code == 409
    assert len(blob_storage.saved) == 2
    assert doc_client.get("/api/v1/documents/doc-race/pdf").content == PDF_BYTES


def test_nul_in_path_document_id_returns_404(doc_client: TestClient) -> None:
    """パスの文書IDにNULを含むと、存在しない文書として404を返すことを確認する。

    文書IDをパスに持つルートは、すべて find_document で文書を引く。
    """
    response = doc_client.get("/api/v1/documents/a%00b")

    assert response.status_code == 404
    assert response.json()["type"] == "/errors/document-not-found"


def test_register_with_nul_in_document_type_returns_422(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage
) -> None:
    """文書種別にNULを含むと、未設定の種別として422を返し、Blobに保存しないことを確認する。"""
    response = post_document(doc_client, document_type="quota\x00tion")

    assert response.status_code == 422
    assert response.json()["type"] == "/errors/unknown-document-type"
    assert not blob_storage.saved


def test_existing_document_with_control_character_in_id_is_still_found(
    doc_client: TestClient, test_database_url: str
) -> None:
    """NUL以外の制御文字を含む文書IDで以前に登録された文書は、引き続き参照できることを確認する。"""
    assert post_document(doc_client, document_id="doc-ctl").status_code == 201
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(
            text(
                "UPDATE documents SET document_id = :new WHERE document_id = 'doc-ctl'"
            ),
            {"new": "doc\x01ctl"},
        )
    engine.dispose()

    response = doc_client.get("/api/v1/documents/doc%01ctl")

    assert response.status_code == 200
    assert response.json()["document_id"] == "doc\x01ctl"
