---
status: accepted
date: 2026-10-03
---

# PDFのBlob名を内部IDから作る

## 背景

文書登録は、PDFをBlobの`{tenant_id}/{document_id}.pdf`に保存してから`documents`行を挿入していた。Blobの名前は、呼出側が採番する`document_id`から作っていた。Azureの`AzureBlobStorage.save`は、上書き不可（`overwrite=False`）で保存する。

挿入が失敗すると、Blobだけが残る。以後の登録は残ったBlobと同じ名前に保存しようとするため、その`document_id`は登録が毎回500になる。同じ`document_id`を同時に登録したときも名前が衝突し、2本目が500になっていた。

## 決定

PDFのBlob名は、`documents`の内部ID（ADR-0021）から作り、`{tenant_id}/{id}.pdf`とする。内部IDは挿入の前に採番する。Blobを先に保存し、行を後から挿入する順は変えない。参照先のPDFが無い行を作らないためである。

挿入に失敗した試行のBlobは、どの行からも参照されないまま残る。名前は試行ごとに異なるので、再登録と同時登録を妨げない。残ったBlobを消す処理は設けない。

DI生応答のBlob名`{tenant_id}/{document_id}/idp-runs/{run_id}.json`（ADR-0019）は変えない。実行IDで一意になるため、衝突しない。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| 挿入の失敗時にBlobを削除する | 同時登録の衝突が残る。削除自体が失敗すると、再登録できない状態に戻る |
| Azureで上書きを許す（`overwrite=True`） | 同時登録で後から保存した内容がBlobに残り、DBのSHA-256と食い違う |
| 挿入の後にBlobを保存する | 保存に失敗すると、PDFの無い行が残る。再送は冪等判定で200になるため、PDFを登録し直せない |

## 影響

挿入に失敗するたびに、参照されないBlobが1つ残りうる。Blobは`{tenant_id}/`の下に置くため、テナント単位で消すときは一緒に消える。

Blobの一覧から文書IDで原本を探すには、`documents.blob_ref`を引く必要がある。Blobへのアクセスは、APIのプロキシ経由に限っている（ADR-0010）。

以前に登録した行は、`blob_ref`に旧形式の名前を持ったまま残す。データは移行しない。読み出しには`blob_ref`を使うため、新旧の名前が混在しても動作は変わらない。
