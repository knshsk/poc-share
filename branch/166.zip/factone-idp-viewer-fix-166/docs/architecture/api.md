# API

## 役割

FastAPI製のバックエンド。管理API、公開閲覧API、Viewer SPAの静的配信を1プロセスで担う。管理APIは文書・文書種別設定・IDP実行・閲覧URLを扱い、認証が必要（`/api/v1/**`）。公開閲覧APIは閲覧者向けで、認証は不要（`/view/{token}/**`）。

PoCでは単一レプリカで動かす。コンテナの起動コマンド（`api/Containerfile`）は、`alembic upgrade head`を実行してからuvicornを起動する。

## 構成

```mermaid
flowchart TB
    subgraph core["core/（横断基盤）"]
        config["config.py 設定"]
        auth["auth.py JWT 検証"]
        db["db.py DB セッション"]
        problem["problem.py RFC 9457 エラー応答"]
        static["static_serving.py SPA 配信"]
    end
    subgraph routers["routers/（エンドポイント）"]
        rDoc["documents.py"]
        rRun["idp_runs.py"]
        rUrl["view_urls.py"]
        rCfg["document_type_configs.py"]
    end
    subgraph services["services/（外部連携・変換。FastAPI 非依存）"]
        blob["blob.py BlobStorage"]
        di["di.py DocumentAnalyzer"]
        pdf["pdf_render.py PdfRenderer"]
        extract["idp_extraction.py パース・正規化・パターン照合・修正適用"]
        cfg["document_type_config.py 設定の取得と型付け"]
    end
    models["models.py SQLAlchemy ORM"]
    main["main.py create_app（組み立て）"]
    ext_blob[("Blob")]
    ext_di["Document Intelligence"]
    ext_pg[("PostgreSQL")]

    main --> core
    main --> routers
    main --> services
    routers --> core
    routers --> services
    routers --> models
    cfg --> models
    blob --> ext_blob
    di --> ext_di
    db --> ext_pg
```

`routers/`には、エンドポイントと、リクエスト / レスポンスのPydanticスキーマを置く。`services/`は外部サービスとのやり取りとデータ変換を担い、FastAPIに依存しない。ただし`document_type_config.py`の設定取得だけは、SQLAlchemyセッションを受け取る。`core/`は全ルーターが共有する基盤。配置指針は[api/README.md](../../api/README.md)にある。

外部境界（Blob・DI・PDFレンダラ・JWT検証鍵の取得）は、`typing.Protocol`で呼出口を定義し、実装を`create_app`の引数で差し替える（[ADR-0004](../adr/0004-external-system-boundary-adapters.md)）。DBセッションファクトリも、同様に引数で差し替えられる。テストでは各Protocolをフェイクに差し替える。実装の組は次のとおり。

| 境界 | Protocol | ローカル | Azure |
| --- | --- | --- | --- |
| Blob | `BlobStorage` | `LocalFileBlobStorage`（`FACTONE_BLOB_LOCAL_DIR`） | `AzureBlobStorage`（Managed ID） |
| 抽出エンジン | `DocumentAnalyzer` | `UnconfiguredAnalyzer`（常に失敗 → 502） | `AzureDocumentAnalyzer`（APIキーまたはManaged ID） |
| PDFレンダラ | `PdfRenderer` | `PdfiumRenderer`（pypdfium2） | 同左 |
| JWT検証鍵 | `KeySource` | `JwksKeySource`（KeycloakのJWKS） | 同左 |

`create_app`は設定を読み、上記の実装を組み立てて`app.state`に載せてから、ルーターを登録する。SPA配信のcatch-allは最後に登録し、APIのルートが優先されるようにする。

応答は`GZipMiddleware`（Starlette同梱）でgzip圧縮する。低速回線でのViewerの初回読込を縮めるためで、JS・CSSは約2MBから約0.6MBに減る。圧縮の対象は、`Accept-Encoding: gzip`の要求に対する500バイト以上の応答（JS・CSS・HTML・JSON）。PNG・woff2などStarletteが既定で除外する形式と、原本のPDF（`application/pdf`）は圧縮しない。これらは圧縮済みの形式で、圧縮しても縮まずCPUだけを使うためである。

テナントはJWTのクレーム`tenant_id`（`CurrentUser.tenant_id`）で解決し、文書・文書種別設定・閲覧URL・実行ログをこの値で絞る（[auth.md](auth.md)）。テナントが一致しなければ404、クレームが欠落・不正なトークンは403 `tenant-unresolved`になる。文書は`(tenant_id, document_id)`で引く。`document_id`はテナント内でのみ一意である（[ADR-0021](../adr/0021-documents-uuid-primary-key.md)）。

ORMモデルは`models.py`に集約し、スキーマ変更はAlembicマイグレーションで管理する。

## リソースと操作

個別のパラメータ・応答は[api/openapi.json](../api/openapi.json)が正。ここでは群と役割だけを示す。

| 群 | パス | 操作 |
| --- | --- | --- |
| 文書種別設定 | `/api/v1/config/document-types[/{type_code}]` | 一覧・作成・取得・更新・削除。テナント別 |
| 文書 | `/api/v1/documents[/{document_id}]`、`.../pages`、`.../pages/{page}/image`、`.../pdf` | 登録（multipart、冪等）、取得、ページ寸法一覧（インチ）、ページ画像（PNG、都度生成）、原本PDF |
| IDP実行 | `/api/v1/documents/{document_id}/idp-runs[/latest \| /{run_id} \| /{run_id}/raw-response \| /{run_id}/corrections]` | 実行、サマリ一覧（`executed_at`昇順）、最新の成功実行、詳細、DI生応答、人手修正の追記 |
| 閲覧URL | `/api/v1/documents/{document_id}/view-urls[/revoke-all]`、`/api/v1/view-urls/{view_url_id}/revoke`、`/api/v1/documents/{document_id}/events`、`/api/v1/view-events` | 発行、一覧、一括失効、失効、文書別イベント一覧、横断差分フィード（[view-url.md](view-url.md)） |
| 公開閲覧 | `/view/{token}/pages`、`.../pages/{page}/image`、`.../pdf` | 無認証。IPのレート制限（429）→ トークン検証（不成立は404）→ 配信と閲覧イベント記録 |
| その他 | `/health`、`/api/v1/me`、`/{full_path}` | ヘルスチェック、認証確認（sub / username）、SPA配信（`api/`始まりは404） |

文書種別設定は`fields`（key / label / type / visible）と`patterns`（正規表現）と`shareable`を持つ。使用中の種別は削除できず、409を返す（[ADR-0014](../adr/0014-tenant-document-type-config.md)）。

IDP実行のうち最新の成功実行は、外部連携システムが結果だけを取る用途。対象は`status`が`succeeded`の行で、人手修正の`corrected`行も含む。クエリ`run_type`で区分を絞れる。Viewerはこれを使わず、一覧の末尾を選ぶ。詳細系（実行・最新・詳細・修正）は、クエリ`verbose=true`を付けると、Viewer向けの付加情報を同じスキーマに追加して返す。付加情報は項目ラベル・読取領域・セル座標・人手差分。既定は外部連携向けで、付加情報を含まない（[ADR-0022](../adr/0022-idp-run-response-single-schema-verbose.md)）。

版はURLパス（`v1`）で表す。破壊的変更の扱いは[api/README.md](../api/README.md)に書く（[ADR-0017](../adr/0017-api-versioning-url-path.md)）。

エラーはすべてRFC 9457 Problem Details（`application/problem+json`、`type: /errors/<code>`）で返す。codeの一覧は[api/README.md](../api/README.md)にある（[ADR-0016](../adr/0016-rfc9457-problem-details.md)）。他文書の実行ID・存在しない文書は、存在を秘匿するため一律404にする。

PostgreSQLはNUL（U+0000）を格納できないため、APIは入力の境界でNULを止める。パスの文書ID・文書種別コードと閲覧トークンがNULを含むときは、存在しないものとして404にする。文書種別設定と人手修正の本文の文字列がNULを含むときは、422 `validation-error`にする。文書登録での扱いは、「文書登録（`POST /api/v1/documents`）」の節に書く（[ADR-0026](../adr/0026-control-characters-in-input.md)）。

## 主要処理の流れ

### IDP実行（`POST .../idp-runs`）

1. 文書を取得する。テナント違い・不在は404。
2. 同一文書の既存実行の有無で、`initial` / `rerun`を決める。既存実行には失敗・修正の行も含む。
3. 文書種別設定を取得する。無ければ409 `document-type-not-configured`。`fields[].key`がDIへのQuery Fieldsになる。
4. 実行IDを先に採番し、BlobからPDFを読んで`DocumentAnalyzer.analyze(pdf, query_fields)`を呼ぶ。`DiError`なら`failed`行を保存して502 `document-analysis-failed`。`DiError`にはタイムアウトと未設定も含む。
5. 生応答を無変換でBlobの`{tenant_id}/{document_id}/idp-runs/{run_id}.json`に保存し、DBには参照パスだけを持つ（[ADR-0019](../adr/0019-raw-di-response-in-blob.md)）。この保存で例外が出ると、実行ログ行を残さず500 `internal-error`になる。DI失敗時とは扱いが非対称である。
6. `parse_analysis`で、項目ごとに生値・正規化値・確信度・読取領域を組み立てる。正規化は`fields[].type`（string / number / date）で駆動し、正規化できない値はnullにする。生値と正規化値は分けて保存する（[ADR-0005](../adr/0005-append-only-logs-and-raw-normalized-separation.md)）。規則は[data-model/idp-runs.md](../data-model/idp-runs.md)にある。
7. 実行時点の`fields[].label`をスナップショットする。テーブル領域は素通しでJSON化し、`patterns[].regex`を全文テキストに適用して一致値を集める。
8. `succeeded`行を挿入し、`IdpRunResponse`を返す。応答は、DB列を`fields[key] = {value, normalized_value, confidence}`の形に組み直したもの。`verbose=true`のときだけ、`label` / `region` / セルの`polygon` / `corrections`を加える（`_to_response`）。

### 文書登録（`POST /api/v1/documents`）

1. `document_id`が`/` `\`を含むか、`.` `..`そのものなら422 `validation-error`。制御文字（Unicodeの一般カテゴリCc）か双方向制御文字（Bidi_Control）を含むときも、422 `validation-error`にする。
2. content-typeと先頭バイト`%PDF`で、PDFかを判定する。違えば415。
3. 文書種別がテナントに設定済みかを確かめる。無ければ422。
4. 同じ`document_id`の既存行があれば、冪等判定をする。SHA-256と文書種別が両方一致すれば200、どちらかが違えば409。この経路ではBlobに触れない。
5. 内部ID（`documents.id`）を先に採番し、Blobの`{tenant_id}/{id}.pdf`に保存する。続けて`documents`行を挿入し、201を返す。挿入が同時登録で競合したときは、ロールバックして4の判定に戻る。挿入に失敗すると、保存したBlobはどの行からも参照されずに残る。Blobの名前は登録の試行ごとに異なるため、残ったBlobが同じ`document_id`の再登録を妨げることはない（[ADR-0027](../adr/0027-pdf-blob-name-from-internal-id.md)）。

原本ファイル名は本文の`original_filename`から取り、無ければ`file`パートの`filename`から取る。basenameを取り出し、制御文字と双方向制御文字を除いてから、255文字を超える分を切り捨てて保存する。除いた結果が空なら、値が無いものとして扱う（[ADR-0026](../adr/0026-control-characters-in-input.md)）。Power AutomateのHTTPアクションは、パートヘッダの非ASCIIを`?`に置き換えて送る。そのため、外部連携から受ける値のうち非ASCIIを含みうるものは、ヘッダではなく本文で受ける（[ADR-0025](../adr/0025-non-ascii-values-in-body.md)）。

### 人手修正の追記（`POST .../idp-runs/{run_id}/corrections`）

1. base（`run_id`）を取得する。失敗実行なら409 `idp-run-not-correctable`。
2. `apply_corrections`で、baseの値に差分（`fields`と`table_cells`）を当てる。修正した項目は、現在の文書種別設定の型で再正規化する。設定が無いときや、キーが設定に無いときは、stringの型で再正規化する。修正した項目の確信度はnullにする。baseに無いキー・座標は422 `unknown-correction-target`。
3. `corrections`は、baseの累積差分に今回分を重ねたものにする。同一キー・同一セル座標は後勝ち。結果は、根の機械実行に対する全差分になる（[ADR-0018](../adr/0018-corrections-as-appended-idp-runs.md)）。
4. `corrected`行を追記する。行は`base_run_id`と`corrected_by`を持ち、`corrected_by`にはJWTの`preferred_username`、無ければ`sub`を入れる。読取領域・ラベル・パターン一致・DI情報・生応答参照は、baseから引き継ぐ。排他制御はしない。応答も`verbose`に従う。

### ページ画像（`GET .../pages/{page}/image`）

BlobからPDFを読み、pypdfium2で該当ページを150 dpiのPNGに描画して返す。画像は保存しない。範囲外のページは404 `page-not-found`、PDFの処理失敗は500 `pdf-processing-failed`になる。公開閲覧側の応答には`Cache-Control: no-store`を付ける。

ページ寸法一覧は、ポイント値を72で割ったインチ単位で返す。Viewerはこの値を、SVGの`viewBox`にそのまま使う（[viewer/display.md](../viewer/display.md)）。

## 外部依存・設定

設定は`core/config.py`の`Settings`（pydantic-settings）で定義する。環境変数のプレフィックスは`FACTONE_`で、ローカルではリポジトリルートの`.env`からも読む。

| 設定 | 既定値 | 用途 |
| --- | --- | --- |
| `APP_NAME` | `factone-api` | FastAPIのタイトル |
| `OIDC_ISSUER` / `OIDC_AUDIENCE` | `http://localhost:8080/realms/factone` / `factone-api` | JWT検証。JWKS URLはissuerから導出 |
| `DATABASE_URL` | ローカルスタック向け | PostgreSQL（SQLAlchemy + psycopg） |
| `BLOB_BACKEND` / `BLOB_LOCAL_DIR` / `BLOB_ACCOUNT_URL` / `BLOB_CONTAINER` | `local` / `.blob-data` / 空 / `documents` | Blobの実装選択と接続先 |
| `DI_ENDPOINT` / `DI_API_KEY` / `DI_TIMEOUT_SECONDS` | 空 / 空 / 120 | DI接続。endpoint未設定なら実行は502。api_key未設定ならManaged ID |
| `STATIC_DIR` | `static` | Viewerのビルド成果物。存在するときだけ配信する |
| `VIEW_URL_DEFAULT_TTL_DAYS` / `VIEW_URL_MAX_FAILURES` / `VIEW_URL_FAILURE_WINDOW_SECONDS` | 90 / 10 / 60 | 閲覧URLの既定期限と失敗レート制限 |

外部依存は、PostgreSQL、Blob（ローカルファイルまたはAzure Blob）、Document Intelligence（`prebuilt-layout` + Query Fields）、IdP（JWKS）。

## 関連ドキュメント

| 参照先 | 内容 |
| --- | --- |
| [api/README.md](../api/README.md) | バージョニング・エラー応答 |
| [api/openapi.json](../api/openapi.json) | 契約の正。pre-commitでドリフトを検出する |
| [data-model/](../data-model/README.md) | テーブル定義・正規化規則・JSON列の構造 |
| [api/README.md（リポジトリ）](../../api/README.md) | ディレクトリ構成と配置指針 |
| [develop-guide/api.md](../develop-guide/api.md) | 起動・テスト・契約生成 |

関連するADRは、ADR-0004、ADR-0005、ADR-0014、ADR-0016、ADR-0017、ADR-0018、ADR-0019、ADR-0025、ADR-0026、ADR-0027。
