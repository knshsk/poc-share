<script setup lang="ts">
// 右ペイン: IDP実行 / 選択中結果チップ / タブ（読取結果・実行履歴・閲覧URL）/ 下部アクションバー（変更件数・破棄・確定）。
// 一覧・詳細取得・キャッシュ・未保存ガードは Mediator が行い、ここは vm の描画と操作の通知だけ
import { PhArrowsClockwise } from '@phosphor-icons/vue'
import { computed } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { Tab } from '../mediator/events'
import type { WorkPanelVm } from '../mediator/vm'
import { formatDateTime } from '../utils/format'
import { RUN_TYPE_LABEL } from '../utils/runs'
import ResultEditor from './ResultEditor.vue'
import ViewUrlPanel from './ViewUrlPanel.vue'

const props = defineProps<{ vm: WorkPanelVm }>()

const bubble = useBubble()

const selectedChip = computed(() => {
  const run = props.vm.selectedRun
  if (!run) return null
  const parts = [RUN_TYPE_LABEL[run.run_type], formatDateTime(run.executed_at)]
  if (run.corrected_by) parts.push(run.corrected_by)
  return parts.join(' · ')
})

const dirty = computed(() => props.vm.draftCount > 0)

const showActions = computed(
  () =>
    props.vm.activeTab === 'result' &&
    props.vm.selectedRun?.status === 'succeeded',
)

// 一覧を取得できていて実行が 1 件も無い（IDP実行が唯一の次操作）。取得中とエラー表示中（vm.error）は該当しない。
// ponytail: vm.error は一覧の取得失敗と IDP 実行失敗などを区別しないため、0 件文書で IDP 実行が失敗した直後も
// 該当しなくなる（ボタンは outlined のまま押せる）。区別が要るなら vm に取得失敗のフラグを足す
const noRuns = computed(
  () => !props.vm.loadingRuns && !props.vm.error && props.vm.runs.length === 0,
)
</script>

<template>
  <div class="work-panel">
    <div class="panel-head">
      <!-- IDP実行はタブ非依存で常置（K5-5/R1-5の再項目化導線）。右に選択中結果のチップ -->
      <div class="d-flex align-center ga-2 mb-2">
        <!-- IDP実行は再項目化用のまれな操作なので outlined。実行が 1 件も無い文書だけ塗りにする（取得中は outlined のままでちらつかせない） -->
        <v-btn
          color="primary"
          :variant="noRuns ? 'flat' : 'outlined'"
          data-testid="execute-idp"
          :loading="vm.executing"
          :disabled="vm.executing"
          @click="bubble({ type: 'executeIdp' })"
        >
          <PhArrowsClockwise :size="16" class="mr-1" />
          IDP実行
        </v-btn>
        <v-chip
          v-if="selectedChip"
          size="small"
          variant="tonal"
          :color="
            vm.selectedRun?.run_type === 'corrected' ? 'primary' : undefined
          "
          data-testid="selected-run-chip"
        >
          {{ selectedChip }}
        </v-chip>
      </div>
      <v-alert
        v-if="vm.error"
        type="error"
        density="compact"
        variant="tonal"
        class="mb-2"
      >
        {{ vm.error }}
      </v-alert>

      <v-tabs
        :model-value="vm.activeTab"
        density="compact"
        color="primary"
        @update:model-value="
          (t) => bubble({ type: 'tabChanged', tab: t as Tab })
        "
      >
        <v-tab value="result" data-testid="tab-result">読取結果</v-tab>
        <v-tab value="history" data-testid="tab-history">実行履歴</v-tab>
        <v-tab v-if="vm.shareable" value="urls" data-testid="tab-urls">
          閲覧URL
        </v-tab>
      </v-tabs>
    </div>

    <div class="panel-body">
      <v-tabs-window :model-value="vm.activeTab">
        <v-tabs-window-item value="result">
          <v-skeleton-loader
            v-if="vm.loadingRuns"
            type="list-item@3"
            class="pa-3"
          />
          <template v-else-if="vm.selectedRun">
            <ResultEditor
              v-if="vm.editor"
              :key="vm.editor.run.run_id"
              :vm="vm.editor"
            />
            <v-alert
              v-else
              type="error"
              variant="tonal"
              density="compact"
              class="ma-3"
              data-testid="run-error"
            >
              実行失敗: {{ vm.selectedRun.error_info ?? '不明なエラー' }}
            </v-alert>
          </template>
          <div v-else class="text-secondary text-body-medium pa-3">
            <p>実行結果がありません</p>
            <p v-if="noRuns" class="mt-1">「IDP実行」で読取を開始します</p>
          </div>
        </v-tabs-window-item>

        <v-tabs-window-item value="history">
          <v-list density="compact">
            <v-list-item
              v-for="run in vm.runs"
              :key="run.run_id"
              data-testid="run-row"
              :active="run.run_id === vm.selectedRun?.run_id"
              @click="bubble({ type: 'selectRun', runId: run.run_id })"
            >
              <v-list-item-title class="text-body-medium">
                {{ formatDateTime(run.executed_at) }}
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ RUN_TYPE_LABEL[run.run_type] }}
                <template v-if="run.corrected_by"
                  >（{{ run.corrected_by }}）</template
                >
                ・
                <span
                  :class="
                    run.status === 'succeeded' ? 'text-success' : 'text-error'
                  "
                >
                  {{ run.status === 'succeeded' ? '成功' : '失敗' }}
                </span>
              </v-list-item-subtitle>
            </v-list-item>
          </v-list>
          <p
            v-if="vm.runs.length === 0"
            class="text-secondary text-body-medium pa-3"
          >
            実行履歴がありません
          </p>
        </v-tabs-window-item>

        <v-tabs-window-item v-if="vm.shareable" value="urls" class="pa-3">
          <ViewUrlPanel :vm="vm.viewUrls" />
        </v-tabs-window-item>
      </v-tabs-window>
    </div>

    <!-- 下部固定のアクションバー: 読取結果タブ・成功実行選択時のみ。確定・破棄は変更ありのときだけ有効 -->
    <div v-if="showActions" class="panel-actions">
      <span
        class="text-body-medium"
        :class="dirty ? 'text-primary font-weight-medium' : 'text-secondary'"
        data-testid="change-count"
      >
        変更 {{ vm.draftCount }}件
      </span>
      <v-spacer />
      <v-btn
        variant="text"
        :disabled="!dirty || vm.saving"
        data-testid="discard-draft"
        @click="bubble({ type: 'discardDraft' })"
      >
        破棄
      </v-btn>
      <v-btn
        color="primary"
        variant="flat"
        :disabled="!dirty || vm.saving"
        :loading="vm.saving"
        data-testid="confirm-corrections"
        @click="bubble({ type: 'confirmCorrections' })"
      >
        確定
      </v-btn>
    </div>

    <v-dialog
      :model-value="vm.confirmDiscard"
      max-width="400"
      aria-labelledby="discard-dialog-title"
      @update:model-value="
        (v: boolean) => !v && bubble({ type: 'confirmCancel' })
      "
    >
      <v-card data-testid="discard-dialog">
        <v-card-title id="discard-dialog-title" class="text-title-medium"
          >未保存の変更を破棄しますか？</v-card-title
        >
        <v-card-text class="text-body-medium text-secondary">
          変更 {{ vm.draftCount }}件が確定されていません。続行すると失われます。
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn
            data-testid="discard-cancel"
            @click="bubble({ type: 'confirmCancel' })"
          >
            キャンセル
          </v-btn>
          <v-btn
            color="error"
            variant="flat"
            data-testid="discard-proceed"
            @click="bubble({ type: 'confirmProceed' })"
          >
            破棄して続行
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar
      :model-value="vm.savedSnackbar"
      :timeout="2500"
      color="success"
      variant="tonal"
      data-testid="correction-saved"
      @update:model-value="
        (v: boolean) => !v && bubble({ type: 'snackbarClosed' })
      "
    >
      修正を保存しました
    </v-snackbar>
  </div>
</template>

<style scoped>
.work-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.panel-head {
  padding: 12px 12px 0;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.panel-body {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
}

.panel-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-top: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
  background: rgb(var(--v-theme-surface));
}
</style>
