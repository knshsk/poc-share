<script setup lang="ts">
// 読取結果タブの本体: キー項目 / キー項目候補 / グリッドの3区分。値はテキストボックスで編集し、入力を Mediator へ bubble する
import { PhPencilSimple, PhWarning } from '@phosphor-icons/vue'
import { computed, nextTick, ref, useId, watch } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { EditorVm } from '../mediator/vm'
import { confidenceColor, formatConfidence } from '../utils/format'
import { scrollBehavior } from '../utils/motion'
import { normalizationHint, type FieldType } from '../utils/normalize'
import {
  cellAt,
  cellId,
  cellKey,
  fieldId,
  originalValue,
  type TableCell,
} from '../utils/runs'

const props = defineProps<{ vm: EditorVm }>()

// 修正文字数の上限。サーバ側 CorrectionText（api/app/routers/idp_runs.py）の max_length と一致させる
const CORRECTION_MAX_LENGTH = 2000

const bubble = useBubble()
const root = ref<HTMLElement | null>(null)
// 正規化ヒント要素の id 接頭辞（aria-describedby 用。キーは id に使えない文字を含み得るため index で振る）
const uid = useId()
// 初期は全区分展開（区分の開閉は描画パラメータなので View が持つ）
const openSections = ref([0, 1, 2])

// キャンバス側クリック → 該当入力欄へスクロール＋フォーカス（読取結果タブへの切替は Mediator が行う）
watch(
  () => props.vm.focusRequest,
  async (request) => {
    if (!request) return
    // 折りたたみ中の区分は開いてからフォーカスする（display:none では focus/scrollIntoView が効かない）
    const section = request.id.startsWith('cell:') ? 2 : 0
    if (!openSections.value.includes(section)) openSections.value.push(section)
    await nextTick()
    const input = root.value?.querySelector<HTMLInputElement>(
      `[data-target-id="${CSS.escape(request.id)}"] input`,
    )
    input?.scrollIntoView?.({ block: 'center', behavior: scrollBehavior() })
    input?.focus({ preventScroll: true })
  },
)

const defByKey = computed(
  () => new Map(props.vm.fieldDefs.map((f) => [f.key, f] as const)),
)

// 表示対象のキー項目: 現在の文書種別設定の順（応答の fields は JSONB 由来でキー順が設定順にならない）。
// 設定に無いキー（設定変更後）は末尾、visible=false は除く
const visibleKeys = computed(() => {
  const keys = Object.keys(props.vm.run.fields ?? {})
  const configured = props.vm.fieldDefs
    .map((f) => f.key)
    .filter((k) => keys.includes(k))
  return [...configured, ...keys.filter((k) => !configured.includes(k))].filter(
    (key) => defByKey.value.get(key)?.visible !== false,
  )
})

function field(key: string) {
  return props.vm.run.fields?.[key]
}

// 設定に無いキー（設定変更後）は string 扱い
function fieldType(key: string): FieldType {
  return defByKey.value.get(key)?.type ?? 'string'
}

function original(key: string): string | null {
  return originalValue(props.vm.run, key)
}

// 読取値が入力欄の元値と異なるときだけ補足表示する
function rawValue(key: string): string | null {
  const raw = field(key)?.value ?? null
  return raw !== original(key) ? raw : null
}

function labelOf(key: string): string {
  return field(key)?.label ?? key
}

function fieldValue(key: string): string {
  if (key in props.vm.draftFields) return props.vm.draftFields[key] ?? ''
  return original(key) ?? ''
}

function hintOf(key: string) {
  return normalizationHint(fieldType(key), fieldValue(key))
}

const savedCorrections = computed(() => props.vm.run.corrections ?? null)

function isFieldCorrected(key: string): boolean {
  return (
    key in props.vm.draftFields || key in (savedCorrections.value?.fields ?? {})
  )
}

function confidenceOf(key: string): number | null {
  return field(key)?.confidence ?? null
}

function confidenceClass(key: string): string {
  const color = confidenceColor(confidenceOf(key))
  return color ? `text-${color}` : 'text-secondary'
}

const patternMatches = computed(() => props.vm.run.pattern_matches ?? {})
const tables = computed(() => props.vm.run.tables ?? [])

function cell(t: number, r: number, c: number): TableCell | null {
  return cellAt(props.vm.run, t, r, c)
}

function cellValue(t: number, r: number, c: number, content: string): string {
  return props.vm.draftCells[cellKey(t, r, c)] ?? content
}

function isCellCorrected(t: number, r: number, c: number): boolean {
  if (cellKey(t, r, c) in props.vm.draftCells) return true
  return (savedCorrections.value?.table_cells ?? []).some(
    (x) => x.table_index === t && x.row_index === r && x.column_index === c,
  )
}
</script>

<template>
  <div ref="root" class="result-editor">
    <v-expansion-panels
      v-model="openSections"
      multiple
      variant="accordion"
      elevation="0"
      class="sections"
    >
      <!-- キー項目: Query Fields -->
      <v-expansion-panel :value="0" data-testid="section-fields">
        <v-expansion-panel-title class="section-title">
          <span class="font-weight-medium">キー項目</span>
          <span class="text-body-small text-secondary ml-2"
            >{{ visibleKeys.length }}件</span
          >
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          <div
            v-for="(key, i) in visibleKeys"
            :key="key"
            class="field-row"
            data-testid="field-row"
          >
            <div class="field-meta">
              <span class="text-body-small text-secondary field-label">{{
                labelOf(key)
              }}</span>
              <span
                class="font-mono text-body-small"
                :class="confidenceClass(key)"
              >
                {{ formatConfidence(confidenceOf(key)) }}
              </span>
            </div>
            <div
              class="field-input"
              :class="{ 'target--active': vm.activeId === fieldId(key) }"
              :data-target-id="fieldId(key)"
            >
              <v-text-field
                :model-value="fieldValue(key)"
                hide-details
                :placeholder="
                  field(key)?.value == null ? '（値なし）' : undefined
                "
                :aria-label="labelOf(key)"
                :aria-describedby="
                  [
                    rawValue(key) != null && `${uid}-raw-${i}`,
                    hintOf(key) && `${uid}-hint-${i}`,
                  ]
                    .filter(Boolean)
                    .join(' ') || undefined
                "
                :aria-current="
                  vm.activeId === fieldId(key) ? 'true' : undefined
                "
                :maxlength="CORRECTION_MAX_LENGTH"
                :class="{ 'input--corrected': isFieldCorrected(key) }"
                data-testid="field-input"
                @update:model-value="
                  (v: string) => bubble({ type: 'fieldInput', key, value: v })
                "
                @focus="bubble({ type: 'targetFocus', id: fieldId(key) })"
              >
                <template v-if="isFieldCorrected(key)" #append-inner>
                  <v-tooltip text="修正" location="top">
                    <template #activator="{ props: tip }">
                      <PhPencilSimple
                        v-bind="tip"
                        :size="16"
                        role="img"
                        aria-label="修正"
                        class="text-primary"
                        data-testid="corrected-mark"
                      />
                    </template>
                  </v-tooltip>
                </template>
              </v-text-field>
              <v-progress-linear
                :model-value="(confidenceOf(key) ?? 0) * 100"
                :color="confidenceColor(confidenceOf(key))"
                :class="confidenceClass(key)"
                height="3"
                rounded
                class="mt-1"
                data-testid="confidence-bar"
              />
              <div
                v-if="rawValue(key) != null"
                :id="`${uid}-raw-${i}`"
                class="text-body-small text-secondary mt-1"
                data-testid="raw-value"
              >
                読取値 {{ rawValue(key) }}
              </div>
              <div
                v-if="hintOf(key)"
                :id="`${uid}-hint-${i}`"
                class="text-body-small mt-1 d-flex align-center ga-1"
                :class="
                  hintOf(key)!.ok ? 'text-secondary font-mono' : 'text-warning'
                "
                data-testid="normalization-hint"
              >
                <PhWarning v-if="!hintOf(key)!.ok" :size="14" />
                {{ hintOf(key)!.text }}
              </div>
            </div>
          </div>
        </v-expansion-panel-text>
      </v-expansion-panel>

      <!-- キー項目候補: 正規表現パターン一致（読取専用） -->
      <v-expansion-panel :value="1" data-testid="section-candidates">
        <v-expansion-panel-title class="section-title">
          <span class="font-weight-medium">キー項目候補</span>
          <span class="text-body-small text-secondary ml-2"
            >{{ Object.keys(patternMatches).length }}件</span
          >
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          <div
            v-for="(match, key) in patternMatches"
            :key="key"
            class="candidate-row"
            data-testid="candidate-row"
          >
            <span class="text-body-small text-secondary">{{
              match.label
            }}</span>
            <div class="d-flex flex-wrap ga-1 mt-1">
              <v-chip
                v-for="(value, i) in match.values"
                :key="i"
                size="small"
                variant="tonal"
                class="font-mono"
                data-testid="candidate-chip"
              >
                {{ value }}
              </v-chip>
              <span
                v-if="match.values.length === 0"
                class="text-body-small text-secondary"
                >一致なし</span
              >
            </div>
          </div>
        </v-expansion-panel-text>
      </v-expansion-panel>

      <!-- グリッド: DI 認識テーブル -->
      <v-expansion-panel :value="2" data-testid="section-grid">
        <v-expansion-panel-title class="section-title">
          <span class="font-weight-medium">グリッド</span>
          <span class="text-body-small text-secondary ml-2"
            >{{ tables.length }}表</span
          >
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          <div
            v-for="(table, t) in tables"
            :key="t"
            class="table-block"
            data-testid="grid-table"
          >
            <div class="text-body-small text-secondary mb-1">
              表 {{ t + 1 }}（{{ table.row_count }}行 ×
              {{ table.column_count }}列）
            </div>
            <div class="grid-scroller">
              <div
                class="grid"
                :style="{
                  gridTemplateColumns: `repeat(${table.column_count}, minmax(120px, 1fr))`,
                }"
              >
                <template v-for="r in table.row_count" :key="r">
                  <template v-for="c in table.column_count" :key="c">
                    <div
                      v-if="cell(t, r - 1, c - 1)"
                      class="grid-cell"
                      :class="{
                        'grid-cell--header':
                          cell(t, r - 1, c - 1)!.kind === 'columnHeader',
                        'target--active':
                          vm.activeId === cellId(t, r - 1, c - 1),
                      }"
                      :data-target-id="cellId(t, r - 1, c - 1)"
                      data-testid="grid-cell"
                    >
                      <v-text-field
                        :model-value="
                          cellValue(
                            t,
                            r - 1,
                            c - 1,
                            cell(t, r - 1, c - 1)!.content,
                          )
                        "
                        hide-details
                        :aria-label="`${r}行${c}列`"
                        :aria-current="
                          vm.activeId === cellId(t, r - 1, c - 1)
                            ? 'true'
                            : undefined
                        "
                        :maxlength="CORRECTION_MAX_LENGTH"
                        :class="{
                          'input--corrected': isCellCorrected(t, r - 1, c - 1),
                        }"
                        data-testid="cell-input"
                        @update:model-value="
                          (v: string) =>
                            bubble({
                              type: 'cellInput',
                              table: t,
                              row: r - 1,
                              column: c - 1,
                              value: v,
                            })
                        "
                        @focus="
                          bubble({
                            type: 'targetFocus',
                            id: cellId(t, r - 1, c - 1),
                          })
                        "
                      >
                        <template
                          v-if="isCellCorrected(t, r - 1, c - 1)"
                          #append-inner
                        >
                          <v-tooltip text="修正" location="top">
                            <template #activator="{ props: tip }">
                              <PhPencilSimple
                                v-bind="tip"
                                :size="16"
                                role="img"
                                aria-label="修正"
                                class="text-primary"
                                data-testid="corrected-mark"
                              />
                            </template>
                          </v-tooltip>
                        </template>
                      </v-text-field>
                    </div>
                    <div
                      v-else
                      class="grid-cell grid-cell--empty"
                      data-testid="grid-cell-empty"
                    />
                  </template>
                </template>
              </div>
            </div>
          </div>
          <p v-if="tables.length === 0" class="text-body-small text-secondary">
            テーブル未検出
          </p>
        </v-expansion-panel-text>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<style scoped>
.sections :deep(.v-expansion-panel-title) {
  min-height: 40px;
  padding: 0 12px;
}

.sections :deep(.v-expansion-panel-text__wrapper) {
  padding: 4px 12px 12px;
}

.field-row {
  display: grid;
  grid-template-columns: 128px 1fr;
  gap: 8px;
  padding: 6px 0;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.field-row:last-child {
  border-bottom: none;
}

.field-meta {
  display: flex;
  flex-direction: column;
  padding-top: 8px;
  min-width: 0;
}

.field-label {
  overflow-wrap: anywhere;
}

.candidate-row {
  padding: 6px 0;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.candidate-row:last-child {
  border-bottom: none;
}

.table-block + .table-block {
  margin-top: 12px;
}

/* 横は区分内スクロール（右ペイン幅 528px に収まらない列数に備える） */
.grid-scroller {
  overflow-x: auto;
  padding-bottom: 4px;
}

.grid {
  display: grid;
  gap: 4px;
}

.grid-cell--header :deep(.v-field) {
  background: rgb(var(--v-theme-canvas));
  font-weight: 500;
}

/* セルが無い座標は破線の空枠 */
.grid-cell--empty {
  min-height: 36px;
  border: 1px dashed rgba(var(--v-border-color), var(--v-border-opacity));
  border-radius: 4px;
}

/* 人手修正済み（保存済み・下書き）: 左端に主色のアクセント */
.input--corrected :deep(.v-field) {
  box-shadow: inset 3px 0 0 rgb(var(--v-theme-primary));
}

/* キャンバス側と対応する選択中の入力欄。フォーカスが外れても維持する */
.target--active :deep(.v-field) {
  background: rgba(var(--v-theme-primary), 0.1);
  box-shadow: inset 0 0 0 1px rgb(var(--v-theme-primary));
}

.target--active :deep(.input--corrected .v-field) {
  box-shadow:
    inset 3px 0 0 rgb(var(--v-theme-primary)),
    inset 0 0 0 1px rgb(var(--v-theme-primary));
}

.result-editor :deep(.v-field__input) {
  font-size: 0.875rem;
  min-height: 36px;
  padding-top: 6px;
  padding-bottom: 6px;
}
</style>
