import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { describe, expect, it } from 'vitest'

// Vuetify 4 のタイポグラフィクラスは MD3 名（text-body-small 等）だけ。Vuetify 3 までの旧名は
// 定義が無く、書いても無言で効かない（16px 継承になる）ため、混入をここで検出する
const LEGACY = /\btext-(caption|body-[12]|h[1-6]|subtitle-[12]|overline)\b/

const srcDir = join(import.meta.dirname, '../src')

describe('タイポグラフィクラス', () => {
  it('Vuetify 3 までの旧クラス名を使っていない', () => {
    const hits = readdirSync(srcDir, { recursive: true, encoding: 'utf8' })
      .filter((file) => /\.(vue|ts)$/.test(file))
      .flatMap((file) =>
        readFileSync(join(srcDir, file), 'utf8')
          .split('\n')
          .flatMap((line, i) =>
            LEGACY.test(line) ? [`${file}:${i + 1}: ${line.trim()}`] : [],
          ),
      )
    expect(hits).toEqual([])
  })

  // --v-font-body が消えると MD3 クラスの箇所とオーバーレイが無言で Roboto に戻る
  it('main.css が --v-font-body を定義している', () => {
    expect(readFileSync(join(srcDir, 'assets/main.css'), 'utf8')).toMatch(
      /^\s*--v-font-body:\s*\S/m,
    )
  })
})
