import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { defineComponent } from 'vue'

import AppHeader from '../src/components/AppHeader.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { HeaderVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { headerVm } from './fixtures'

const bubble = vi.fn()

// v-app-barはVuetifyレイアウト（v-app）配下が必要なためProbeで包む
const Probe = defineComponent({
  components: { AppHeader },
  props: { vm: { type: Object, required: true } },
  template: '<v-app><AppHeader :vm="vm" /></v-app>',
})

function mountHeader(over: Partial<HeaderVm> = {}) {
  return mount(Probe, {
    props: { vm: headerVm(over) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// メニューの内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('AppHeader', () => {
  it('プロダクト名とユーザー名を表示する', () => {
    const wrapper = mountHeader()
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.text()).toContain('sales01')
  })

  it('ログアウトボタンで logout を bubble する', async () => {
    const wrapper = mountHeader()
    await wrapper.get('[data-testid="user-menu"]').trigger('click')
    // v-menuの内容はteleportされるためdocumentから探す
    const logoutBtn = document.querySelector('[data-testid="logout"]')
    expect(logoutBtn).not.toBeNull()
    ;(logoutBtn as HTMLElement).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'logout' })
  })

  // 文書コンテキスト（ID・種別ラベル）がヘッダに表示される。ラベルは Mediator が display_name か種別コードを決める
  it('文書IDと種別チップを表示する', () => {
    const wrapper = mountHeader({
      documentId: 'doc-1',
      documentTypeLabel: 'カスタム注文書',
    })
    expect(wrapper.get('[data-testid="header-document-id"]').text()).toContain(
      'doc-1',
    )
    expect(
      wrapper.get('[data-testid="header-document-type"]').text(),
    ).toContain('カスタム注文書')
  })

  it('文書未指定ではバッジを出さない', () => {
    expect(
      mountHeader().find('[data-testid="header-document-id"]').exists(),
    ).toBe(false)
  })

  // 文書コンテキストはロゴの右隣（prepend 内）に置く。既定スロットだと prepend / append の
  // auto margin に挟まれて中央に浮く
  it('文書IDバッジと種別チップを prepend 内に描画する', () => {
    const wrapper = mountHeader({
      documentId: 'DOC-001',
      documentTypeLabel: '見積書',
    })
    const prepend = wrapper.get('.v-toolbar__prepend')
    expect(prepend.find('[data-testid="header-document-id"]').exists()).toBe(
      true,
    )
    expect(prepend.find('[data-testid="header-document-type"]').exists()).toBe(
      true,
    )
  })

  // バッジからの再入力は openDocument を bubble する（未保存ガードは Mediator）
  it('バッジメニューから文書IDを変更すると openDocument を bubble する', async () => {
    const wrapper = mountHeader({ documentId: 'doc-1' })
    await wrapper.get('[data-testid="header-document-id"]').trigger('click')
    const input = document.querySelector(
      '[data-testid="header-document-id-input"] input',
    ) as HTMLInputElement
    expect(input).not.toBeNull()
    expect(input.value).toBe('doc-1')
    input.value = 'doc-2'
    input.dispatchEvent(new Event('input'))
    ;(
      document.querySelector(
        '[data-testid="header-document-id-apply"]',
      ) as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({
      type: 'openDocument',
      documentId: 'doc-2',
    })
  })

  // 未認証（公開閲覧）ではロゴだけを表示し、ユーザーメニューを出さない（#149）
  it('未認証ではロゴのみ表示する', () => {
    const wrapper = mountHeader({ authenticated: false, username: null })
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.find('[data-testid="user-menu"]').exists()).toBe(false)
  })
})
