---
status: accepted
date: 2026-10-01
---

# 非 ASCII を含みうる値はヘッダでなく本文で受け、原本ファイル名の本文フィールドを設ける

## 背景

文書登録 API（`POST /api/v1/documents`）は、原本ファイル名を multipart の `file` パートの `filename`（パートヘッダ `Content-Disposition` のパラメータ）から取っていた。Power Automate（PA）の HTTP アクションは、送信前にパートヘッダの非 ASCII 文字を 1 文字ずつ `?` に置き換えるため、日本語のファイル名が `ABC???.pdf` のように化けて保存される。公式ドキュメントに記載はないが Logic Apps でも同じ症状が報告されており、リクエスト全体に `charset=utf-8` を付けても直らない。パートの本文（テキスト）は UTF-8 のまま届くことを実機で確認した。

## 決定

外部連携から受ける値のうち非 ASCII を含みうるものは、HTTP ヘッダ（multipart のパートヘッダを含む）ではなく本文で受ける。文書登録 API に任意のテキストフィールド `original_filename` を追加し、`filename` より優先して原本ファイル名に使う。正規化（basename の取り出し・前後の空白の除去・255 文字での切り詰め）はどちらも同じにし、`original_filename` を正規化した結果が空（空・空白のみ・パス区切りで終わる値など）なら従来どおり `filename` を使う。

## 検討した代替案

- PA で `filename` を percent-encode し、API で復号する — `%20` のような文字列を含む実際のファイル名が復号で失われる。全クライアントの `filename` の解釈が変わり、API が PA の挙動に依存する
- `filename*`（RFC 5987 の UTF-8 表記）を受ける — multipart/form-data では RFC 7578 §4.2 が `filename*` を使わないよう定めており、python-multipart も読まない。パートヘッダを自前で解析する必要がある
- multipart の本文全体を base64 にして `$content` で送る（Microsoft が案内する Logic Apps の回避策） — バイト列の連結に C# のインラインコード（Logic Apps Standard 専用）が要り、PA では組めない

## 影響

- PA のフローは `original_filename` のテキストパートを足して、実際のファイル名を渡す。`file` パートの `filename` は省けない（無いとファイルとして扱われず 422 になる）ため、化けた値のまま送ってよい
- ブラウザ（Viewer の画面登録）は `filename` を UTF-8 のまま送れるため、`original_filename` を送らない
- 外部連携向けに値をヘッダで受ける API を新たに設けるときは、値が ASCII に限られることを確かめる
