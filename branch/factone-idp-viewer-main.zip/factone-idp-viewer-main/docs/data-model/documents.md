# 文書メタデータ（documents）

文書取込の中核テーブル。SaaS内部の主参照キーは文書IDであり、案件ID・ルートIDは保持しない（業務キー/文書キー分離の決定に基づく）。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 内部ID（サーバ採番）。子テーブルの外部キーはこの列を参照する（ADR-0021） |
| document_id | varchar(255) | NOT NULL・UNIQUE(tenant_id, document_id) | 文書ID。呼出側が採番し、SaaS内では採番・解決しない。テナント内でのみ一意 |
| tenant_id | varchar(255) | NOT NULL | テナント識別子。JWT の `tenant_id` クレーム（ADR-0020） |
| document_type | varchar(50) | NOT NULL | 文書種別コード。テナント設定（document_type_configs）に登録済みの値のみ受付（アプリ層検証） |
| blob_ref | varchar(1024) | NOT NULL | Blob格納パス（`{tenant_id}/{document_id}.pdf`） |
| content_sha256 | varchar(64) | NOT NULL | ファイル内容のSHA-256。冪等判定に使用 |
| original_filename | varchar(255) | NULL可 | 原本ファイル名（basename）。登録時の `original_filename` フィールド、無ければ multipart `filename` から取る（Power Automate は `filename` の非 ASCII を `?` に置き換えて送るため。ADR-0025）。原本DLの `Content-Disposition` に使用。列追加前の行は NULL で、DL時は `{document_id}.pdf` にフォールバック。文書メタデータの応答（`DocumentResponse.original_filename`）にも出し、Viewer のヘッダーの文書タイトルに使う（NULL のときは文書IDを表示） |
| received_at | timestamptz | NOT NULL | 受領日時（初回登録時にサーバで記録） |
| created_at | timestamptz | NOT NULL・default now() | 行作成日時 |

## 文書種別（document_type）

- 種別はテナント別設定テーブル `document_type_configs` で管理する（[document-type-configs.md](document-type-configs.md)・ADR-0014）。enum・CHECK制約は廃止済み。
- 登録時の検証はアプリ層で行う: テナント設定に未登録の種別は422で拒否。
- 種別の追加は設定CRUD API（`POST /api/v1/config/document-types`）で行い、コード変更・マイグレーションは不要。
- **単一テーブル+種別列は仮置き**（統合モデル採否が未確定のため）。種別固有属性が必要になった時点で見直す。

## 冪等性

登録API（`POST /api/v1/documents`）の挙動:

- 新規文書ID → 201（Blob保存+行INSERT）
- 同一テナント・同一文書ID・同一内容（sha256・種別一致）→ 200（冪等再送。何も変更しない）
- 同一テナント・同一文書ID・内容不一致 → 409（事故検出。上書きしない）
- 別テナントの同一文書ID → 201（テナント間で独立）

## マイグレーション

Alembic（`api/migrations/`）を正とする。適用は `uv run alembic upgrade head`。テストも同マイグレーションでスキーマ構築する。
