"""IDP抽出のクエリセット定義と、応答のパース・正規化・確信度分離。

生値（DIが返した文字列）と正規化値・確信度を分離して保持する。
クエリセットは確定抽出項目が未確定のため、検証用サンプルPDFの様式に合わせた仮置き。
"""

from dataclasses import dataclass
from datetime import date

from app.models import DocumentType
from app.services.di import QueryFieldResult

# 注文書の最低抽出項目（得意先コード・品目コード・数量・納期・単価）
_ORDER_FIELDS = (
    "customer_code",
    "item_code",
    "quantity",
    "delivery_date",
    "unit_price",
)

QUERY_FIELDS: dict[DocumentType, tuple[str, ...]] = {
    DocumentType.QUOTE: (
        "document_no",
        "customer_code",
        "issue_date",
        "total_amount",
    ),
    DocumentType.ORDER_PROJECT: _ORDER_FIELDS,
    DocumentType.ORDER_ROUTE: _ORDER_FIELDS,
}

_NUMERIC_FIELDS = frozenset({"quantity", "unit_price", "total_amount"})
_DATE_FIELDS = frozenset({"delivery_date", "issue_date"})


@dataclass(frozen=True)
class ParsedExtraction:
    """項目別の生値・正規化値・確信度。キーはクエリセットと同一。"""

    raw: dict[str, str | None]
    normalized: dict[str, str | int | None]
    confidence: dict[str, float | None]


def _normalize(field: str, value: str) -> str | int | None:
    if field in _NUMERIC_FIELDS:
        try:
            return int(value.replace(",", ""))
        except ValueError:
            return None
    if field in _DATE_FIELDS:
        try:
            return date.fromisoformat(value.replace("/", "-")).isoformat()
        except ValueError:
            return None
    return value


def parse_analysis(
    document_type: DocumentType, results: dict[str, QueryFieldResult]
) -> ParsedExtraction:
    raw: dict[str, str | None] = {}
    normalized: dict[str, str | int | None] = {}
    confidence: dict[str, float | None] = {}
    for field in QUERY_FIELDS[document_type]:
        result = results.get(field)
        if result is None or result.value is None:
            raw[field] = None
            normalized[field] = None
            confidence[field] = result.confidence if result else None
            continue
        raw[field] = result.value
        normalized[field] = _normalize(field, result.value)
        confidence[field] = result.confidence
    return ParsedExtraction(raw=raw, normalized=normalized, confidence=confidence)
