<script setup lang="ts">
import {
  PhArrowsHorizontal,
  PhArrowsVertical,
  PhCaretLeft,
  PhCaretRight,
  PhCornersOut,
  PhDownloadSimple,
  PhMagnifyingGlassMinus,
  PhMagnifyingGlassPlus,
} from '@phosphor-icons/vue'
import type { ComponentPublicInstance } from 'vue'
import { onMounted, onUnmounted, ref } from 'vue'

import { fitZoom, type PageSize, type ZoomMode } from '../utils/zoom'
import PageSvg from './PageSvg.vue'

export type PageInfo = PageSize

const props = defineProps<{
  documentId: string
  pages: PageInfo[]
}>()

const emit = defineEmits<{ downloadOriginal: [] }>()

const ZOOM_MIN = 25
const ZOOM_MAX = 200
const ZOOM_STEP = 25
// ズームはコンテナ幅比%（100=幅合わせ）。CSS width制御のためPageSvgのviewBox（DI座標系）は不変。
// モードはフィット3種+手動。初期は全体表示。複数ページは1ページ目の寸法で全ページ同一倍率
const mode = ref<ZoomMode>('page')
const zoom = ref(100)
const currentPage = ref(1)
const scroller = ref<HTMLElement | null>(null)
const pageEls = ref<HTMLElement[]>([])
let resizeObserver: ResizeObserver | null = null

function setPageEl(
  el: Element | ComponentPublicInstance | null,
  index: number,
): void {
  if (el instanceof HTMLElement) pageEls.value[index] = el
}

// v-btn-toggleは選択中ボタンの再クリックでundefinedを渡す（選択解除）。フィットモードは解除せず、
// 現在のモードのまま再計算する（コンテナサイズ変化後の再クリックでズームを追従させるため）
function applyMode(next: ZoomMode | undefined): void {
  const target = next ?? mode.value
  if (target === 'custom') return
  mode.value = target
  const el = scroller.value
  const page = props.pages[0]
  zoom.value =
    el && page ? fitZoom(target, el.clientWidth, el.clientHeight, page) : 100
}

// ±は25の倍数へスナップする（フィット値85%から拡大→100%、縮小→75%）
function stepZoom(delta: number): void {
  mode.value = 'custom'
  const next =
    delta > 0
      ? Math.floor(zoom.value / ZOOM_STEP) * ZOOM_STEP + ZOOM_STEP
      : Math.ceil(zoom.value / ZOOM_STEP) * ZOOM_STEP - ZOOM_STEP
  zoom.value = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, next))
}

onMounted(() => {
  applyMode('page')
  // コンテナサイズ変化（ペイン幅・ウィンドウ）でフィット系モードを再計算する。手動ズームは維持。
  // border-box観測かつ実寸不変なら再計算しない（スクロールバー出入り・初回通知で再フィットが連鎖しないように）
  if (typeof ResizeObserver !== 'undefined' && scroller.value) {
    let lastSize = ''
    resizeObserver = new ResizeObserver(([entry]) => {
      const size = `${entry?.borderBoxSize?.[0]?.inlineSize ?? 0}x${entry?.borderBoxSize?.[0]?.blockSize ?? 0}`
      if (size === lastSize) return
      lastSize = size
      applyMode(mode.value)
    })
    resizeObserver.observe(scroller.value, { box: 'border-box' })
  }
})

onUnmounted(() => {
  resizeObserver?.disconnect()
  resizeObserver = null
})

function goToPage(page: number): void {
  const target = Math.min(props.pages.length, Math.max(1, page))
  currentPage.value = target
  // jsdomはscrollIntoView未実装のため存在確認する
  pageEls.value[target - 1]?.scrollIntoView?.({
    block: 'start',
    behavior: 'smooth',
  })
}

// スクロール位置から表示中ページを判定（コンテナ上端+1/3を基準線とする）
function onScroll(): void {
  const container = scroller.value
  if (!container) return
  const line =
    container.getBoundingClientRect().top + container.clientHeight / 3
  for (let i = pageEls.value.length - 1; i >= 0; i--) {
    const rect = pageEls.value[i]?.getBoundingClientRect()
    if (rect && rect.top <= line) {
      currentPage.value = i + 1
      return
    }
  }
  currentPage.value = 1
}
</script>

<template>
  <div class="document-canvas">
    <div class="canvas-toolbar">
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-prev"
        aria-label="前のページ"
        :disabled="currentPage <= 1"
        @click="goToPage(currentPage - 1)"
      >
        <PhCaretLeft :size="18" />
      </v-btn>
      <span class="font-mono text-body-2" data-testid="canvas-page-indicator">
        {{ currentPage }} / {{ pages.length }}
      </span>
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-next"
        aria-label="次のページ"
        :disabled="currentPage >= pages.length"
        @click="goToPage(currentPage + 1)"
      >
        <PhCaretRight :size="18" />
      </v-btn>

      <v-divider vertical class="mx-2" />

      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-zoom-out"
        aria-label="縮小"
        :disabled="zoom <= ZOOM_MIN"
        @click="stepZoom(-ZOOM_STEP)"
      >
        <PhMagnifyingGlassMinus :size="18" />
      </v-btn>
      <span class="font-mono text-body-2 zoom-value" data-testid="canvas-zoom"
        >{{ zoom }}%</span
      >
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-zoom-in"
        aria-label="拡大"
        :disabled="zoom >= ZOOM_MAX"
        @click="stepZoom(ZOOM_STEP)"
      >
        <PhMagnifyingGlassPlus :size="18" />
      </v-btn>

      <v-divider vertical class="mx-2" />

      <!-- フィット: 幅に合わせる / 高さに合わせる / ページ全体を表示。選択中を強調し、±操作後（custom）は非選択 -->
      <v-btn-toggle
        :model-value="mode"
        density="compact"
        variant="text"
        color="primary"
        @update:model-value="(v) => applyMode(v as ZoomMode | undefined)"
      >
        <v-btn
          icon
          size="small"
          value="width"
          data-testid="canvas-fit-width"
          aria-label="幅に合わせる"
          :aria-pressed="mode === 'width'"
        >
          <v-tooltip activator="parent" location="bottom"
            >幅に合わせる</v-tooltip
          >
          <PhArrowsHorizontal :size="18" />
        </v-btn>
        <v-btn
          icon
          size="small"
          value="height"
          data-testid="canvas-fit-height"
          aria-label="高さに合わせる"
          :aria-pressed="mode === 'height'"
        >
          <v-tooltip activator="parent" location="bottom"
            >高さに合わせる</v-tooltip
          >
          <PhArrowsVertical :size="18" />
        </v-btn>
        <v-btn
          icon
          size="small"
          value="page"
          data-testid="canvas-fit-page"
          aria-label="ページ全体を表示"
          :aria-pressed="mode === 'page'"
        >
          <v-tooltip activator="parent" location="bottom"
            >ページ全体を表示</v-tooltip
          >
          <PhCornersOut :size="18" />
        </v-btn>
      </v-btn-toggle>

      <v-spacer />

      <v-btn
        variant="outlined"
        size="small"
        data-testid="download-original"
        @click="emit('downloadOriginal')"
      >
        <PhDownloadSimple :size="16" class="mr-1" />
        原本DL
      </v-btn>
    </div>

    <div ref="scroller" class="canvas-scroller" @scroll.passive="onScroll">
      <div
        v-for="(page, index) in pages"
        :key="index"
        :ref="(el) => setPageEl(el, index)"
        class="page-frame"
        :style="{ width: `${zoom}%` }"
      >
        <PageSvg
          :document-id="documentId"
          :page="index + 1"
          :width="page.width"
          :height="page.height"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
.document-canvas {
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 100%;
}

.canvas-toolbar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 4px;
  padding: 4px 12px;
  background: rgb(var(--v-theme-surface));
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.zoom-value {
  min-width: 44px;
  text-align: center;
}

/* padding / margin の値は utils/zoom.ts の定数（SCROLLER_PADDING 等）と一致させる */
.canvas-scroller {
  flex: 1;
  min-height: 0;
  overflow: auto;
  /* 縦スクロールバーの有無で内寸幅が変わるとフィット倍率が押下のたびにずれる（37%→36%）ため、溝を常時確保する。
     ponytail: 横スクロールバー（高さ合わせで100%超のとき）の高さは未考慮。必要になれば offsetHeight-clientHeight で補正 */
  scrollbar-gutter: stable;
  background: rgb(var(--v-theme-canvas));
  padding: 24px;
}

.page-frame {
  margin: 0 auto 24px;
  background: rgb(var(--v-theme-surface));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
</style>
