// キャンバスのズームモード。width=幅合わせ / height=高さ合わせ / page=全体表示 / custom=手動（±操作後）
export type ZoomMode = 'width' | 'height' | 'page' | 'custom'

export interface PageSize {
  width: number
  height: number
}

// DocumentCanvas の .canvas-scroller / .page-frame / .page-svg の CSS と一致させる
const SCROLLER_PADDING = 24
const PAGE_FRAME_MARGIN_BOTTOM = 24
const PAGE_BORDER = 1
const HORIZONTAL_CHROME = SCROLLER_PADDING * 2
const VERTICAL_CHROME =
  SCROLLER_PADDING * 2 + PAGE_FRAME_MARGIN_BOTTOM + PAGE_BORDER * 2

// ズーム値はコンテナ内寸幅に対する % （100=幅合わせ）。height は可視高さに1ページが収まる倍率、
// page はそれを 100 で頭打ち。計測不能（jsdom・非表示）のときは幅合わせに倒す
export function fitZoom(
  mode: Exclude<ZoomMode, 'custom'>,
  clientWidth: number,
  clientHeight: number,
  page: PageSize,
): number {
  if (mode === 'width') return 100
  const availWidth = clientWidth - HORIZONTAL_CHROME
  const availHeight = clientHeight - VERTICAL_CHROME
  if (availWidth <= 0 || availHeight <= 0) return 100
  const pageWidthPx = availHeight * (page.width / page.height)
  // 切り上げ側に振れると数 px はみ出すため切り捨て。浮動小数誤差（849.999…）は epsilon で吸収
  const zoom = Math.max(1, Math.floor((pageWidthPx / availWidth) * 100 + 1e-6))
  return mode === 'page' ? Math.min(100, zoom) : zoom
}
