import { describe, expect, it } from 'vitest'

import { fitZoom } from '../src/utils/zoom'

// スクローラの内寸: 幅 = clientWidth - 48（左右 padding）、高さ = clientHeight - 74（上下 padding 48 + 枠下マージン 24 + 枠線 2）
const letter = { width: 8.5, height: 11 }

describe('fitZoom', () => {
  it('width は常に 100', () => {
    expect(fitZoom('width', 1048, 400, letter)).toBe(100)
  })

  it('height は可視高さに 1 ページが収まる幅比 % を返す', () => {
    // 可視高さ 1174-74=1100px → ページ幅 1100*(8.5/11)=850px、内寸幅 1048-48=1000px → 85%
    expect(fitZoom('height', 1048, 1174, letter)).toBe(85)
  })

  it('page は height の倍率を 100 で頭打ちにする', () => {
    // 可視高さ 2274-74=2200px → ページ幅 1700px / 1000px = 170% → page は 100
    expect(fitZoom('height', 1048, 2274, letter)).toBe(170)
    expect(fitZoom('page', 1048, 2274, letter)).toBe(100)
    expect(fitZoom('page', 1048, 1174, letter)).toBe(85)
  })

  it('フィット値は 25〜200 に制限せず、下限は 1', () => {
    // 可視高さ 78-74=4px → 3.09px / 1000px → 0.3% → floor 0 → 下限 1
    expect(fitZoom('height', 1048, 78, letter)).toBe(1)
  })

  it('計測不能（サイズ 0）のときは 100 を返す', () => {
    expect(fitZoom('height', 0, 0, letter)).toBe(100)
    expect(fitZoom('page', 0, 0, letter)).toBe(100)
  })
})
