"""add corrected run type and correction columns to idp_runs

人手修正を idp_runs の corrected 行として追記保存する（#115、ADR-0018）。
base_run_id（修正元）・corrected_by（修正者）・corrections（修正APIのボディ）を追加し、
run_type の CHECK に corrected を加える。

Revision ID: e1c9d4a7b283
Revises: c2f7a1d9e4b3
Create Date: 2026-09-13 23:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "e1c9d4a7b283"
down_revision: str | None = "c2f7a1d9e4b3"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("idp_runs", sa.Column("base_run_id", sa.Uuid(), nullable=True))
    op.add_column(
        "idp_runs", sa.Column("corrected_by", sa.String(length=255), nullable=True)
    )
    op.add_column("idp_runs", sa.Column("corrections", JSONB(), nullable=True))
    op.create_foreign_key(
        "fk_idp_runs_base_run_id", "idp_runs", "idp_runs", ["base_run_id"], ["id"]
    )
    op.drop_constraint("ck_idp_runs_run_type", "idp_runs", type_="check")
    op.create_check_constraint(
        "ck_idp_runs_run_type",
        "idp_runs",
        "run_type IN ('initial', 'rerun', 'corrected')",
    )
    op.create_check_constraint(
        "ck_idp_runs_corrected_base",
        "idp_runs",
        "(run_type = 'corrected') = (base_run_id IS NOT NULL)",
    )
    op.create_check_constraint(
        "ck_idp_runs_corrected_by",
        "idp_runs",
        "(run_type = 'corrected') = (corrected_by IS NOT NULL)",
    )


def downgrade() -> None:
    # corrected 行は旧 CHECK に違反するため削除する（修正結果は失われる）
    op.execute("DELETE FROM idp_runs WHERE run_type = 'corrected'")
    op.drop_constraint("ck_idp_runs_corrected_by", "idp_runs", type_="check")
    op.drop_constraint("ck_idp_runs_corrected_base", "idp_runs", type_="check")
    op.drop_constraint("ck_idp_runs_run_type", "idp_runs", type_="check")
    op.create_check_constraint(
        "ck_idp_runs_run_type", "idp_runs", "run_type IN ('initial', 'rerun')"
    )
    op.drop_constraint("fk_idp_runs_base_run_id", "idp_runs", type_="foreignkey")
    op.drop_column("idp_runs", "corrections")
    op.drop_column("idp_runs", "corrected_by")
    op.drop_column("idp_runs", "base_run_id")
