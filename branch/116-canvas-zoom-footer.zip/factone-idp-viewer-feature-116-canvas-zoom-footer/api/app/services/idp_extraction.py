"""IDP抽出応答のパース・正規化・確信度分離。

生値（DIが返した文字列）と正規化値・確信度を分離して保持する。
対象フィールドと型は文書種別設定（document_type_configs）由来のFieldDefで受け取る。
全文テキストへの正規表現マッチ（PatternDef）も本モジュールで行う。
"""

import copy
import re
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import date
from typing import cast

from app.services.di import DiTable, QueryFieldResult
from app.services.document_type_config import FieldDef, FieldType, PatternDef


@dataclass(frozen=True)
class ParsedExtraction:
    """項目別の生値・正規化値・確信度・読取領域。キーはフィールド定義と同一。"""

    raw: dict[str, str | None]
    normalized: dict[str, str | int | None]
    confidence: dict[str, float | None]
    # {"page_number": int, "polygon": [float, ...]} または None（領域なし・値なし）
    regions: dict[str, dict[str, object] | None]


def _normalize(field_type: FieldType, value: str) -> str | int | None:
    if field_type is FieldType.NUMBER:
        try:
            return int(value.replace(",", ""))
        except ValueError:
            return None
    if field_type is FieldType.DATE:
        try:
            return date.fromisoformat(value.replace("/", "-")).isoformat()
        except ValueError:
            return None
    return value


def tables_to_json(tables: tuple[DiTable, ...]) -> list[dict[str, object]]:
    """テーブル領域（明細仮）をJSON化する。意味付け・正規化は行わない。"""
    serialized = []
    for table in tables:
        data = asdict(table)
        data["cells"] = [
            {**cell, "polygon": list(cell["polygon"]) if cell["polygon"] else None}
            for cell in data["cells"]
        ]
        serialized.append(data)
    return serialized


def parse_analysis(
    fields: Sequence[FieldDef], results: dict[str, QueryFieldResult]
) -> ParsedExtraction:
    raw: dict[str, str | None] = {}
    normalized: dict[str, str | int | None] = {}
    confidence: dict[str, float | None] = {}
    regions: dict[str, dict[str, object] | None] = {}
    for field in fields:
        result = results.get(field.key)
        regions[field.key] = None
        if result is None or result.value is None:
            raw[field.key] = None
            normalized[field.key] = None
            confidence[field.key] = result.confidence if result else None
            continue
        raw[field.key] = result.value
        normalized[field.key] = _normalize(field.type, result.value)
        confidence[field.key] = result.confidence
        if result.page_number is not None and result.polygon is not None:
            regions[field.key] = {
                "page_number": result.page_number,
                "polygon": list(result.polygon),
            }
    return ParsedExtraction(
        raw=raw, normalized=normalized, confidence=confidence, regions=regions
    )


def match_patterns(
    patterns: Sequence[PatternDef], content: str
) -> dict[str, dict[str, object]]:
    """全文テキストに各パターンを適用し、出現順・重複ありの全一致を返す。

    値は一致全体（group 0）。0件でもキーを残す。実行時点のlabel/regexを同梱し、
    設定変更後も当時の条件を再現できるようにする。regexは設定登録時に検証済み。
    長さ0の一致は含めない（`\\d*` 等が文字位置ごとに空文字を生む肥大防止）。
    """
    return {
        p.key: {
            "label": p.label,
            "regex": p.regex,
            "values": [m.group(0) for m in re.finditer(p.regex, content) if m.group(0)],
        }
        for p in patterns
    }


class UnknownCorrectionTarget(ValueError):
    """修正対象のキー・セル座標が base に存在しない。"""


@dataclass(frozen=True)
class CellCorrection:
    """テーブルセルの修正。座標は 0 始まり。"""

    table_index: int
    row_index: int
    column_index: int
    content: str


@dataclass(frozen=True)
class CorrectedValues:
    """base に修正を当てた後の項目値・テーブル。"""

    raw: dict[str, str | None]
    normalized: dict[str, str | int | None]
    confidence: dict[str, float | None]
    tables: list[dict[str, object]]


def apply_corrections(
    base_raw: Mapping[str, str | None],
    base_normalized: Mapping[str, str | int | None],
    base_confidence: Mapping[str, float | None],
    base_tables: Sequence[Mapping[str, object]],
    fields: Mapping[str, str | None],
    table_cells: Sequence[CellCorrection],
    field_types: Mapping[str, FieldType],
) -> CorrectedValues:
    """差分（fields / table_cells）を base にマージする。

    変更キーは現在の設定型で再正規化し（設定に無いキーは string）、確信度は null にする。
    テーブルは構造を維持して content だけ差し替える。base に無いキー・座標は
    UnknownCorrectionTarget。base の引数は変更しない。
    """
    raw = dict(base_raw)
    normalized = dict(base_normalized)
    confidence = dict(base_confidence)
    for key, value in fields.items():
        if key not in raw:
            raise UnknownCorrectionTarget(f"Unknown field key: {key}")
        raw[key] = value
        field_type = field_types.get(key, FieldType.STRING)
        normalized[key] = None if value is None else _normalize(field_type, value)
        confidence[key] = None

    tables = copy.deepcopy([dict(t) for t in base_tables])
    for cell in table_cells:
        target = _find_cell(tables, cell)
        if target is None:
            raise UnknownCorrectionTarget(
                f"Unknown table cell: {cell.table_index}/{cell.row_index}/{cell.column_index}"
            )
        target["content"] = cell.content
    return CorrectedValues(
        raw=raw, normalized=normalized, confidence=confidence, tables=tables
    )


def _find_cell(
    tables: list[dict[str, object]], cell: CellCorrection
) -> dict[str, object] | None:
    if not 0 <= cell.table_index < len(tables):
        return None
    cells = cast(list[dict[str, object]], tables[cell.table_index]["cells"])
    return next(
        (
            c
            for c in cells
            if c["row_index"] == cell.row_index
            and c["column_index"] == cell.column_index
        ),
        None,
    )
