# Keycloak構成管理

Keycloakのrealm定義をconfig-as-codeで管理するディレクトリ。

## 暫定運用ルール

realm設計（realm分離 or 単一realm+テナントクレーム）は未確定のため、確定までは本READMEの暫定運用のみとする。realm設計ドキュメントは確定後に `docs/architecture/` へ作成する。

- **realm定義JSON（`realm/` 配下）を構成管理の正とする。** Keycloak管理コンソールでの手動変更は永続化せず、変更はJSONを編集して再投入する。
- 投入方法: 起動時の `--import-realm` で `realm/` 配下のJSONが自動投入される（ローカルは `compose.yaml` でマウント、Azureは `Containerfile` でイメージへ焼き込み。いずれも同一定義）。
- 既存realmがある場合、`--import-realm` は既定でスキップされる。定義変更を反映するには realm を削除して再起動するか、ローカルではデータボリュームを初期化する（手順は `docs/develop-guide/local-stack.md`）。

## シークレット非含有ルール

- **realm JSONにシークレット（クライアントシークレット・パスワード等）を含めない。**
- **Keycloakのrealmインポートは環境変数置換を行わない**（プレースホルダ文字列がそのまま値になる）。パスワード・クライアントシークレット等の実行時設定が必要な項目は、起動後に `kcadm` を使うスクリプトで設定する（`scripts/local-stack/apply-keycloak-secrets.sh`）。
- 現在のrealm定義:
  - realm本体
  - publicクライアント `factone-viewer`（SPA用。PKCE S256必須・audienceマッパー）
  - confidentialクライアント `factone-integration`（外部システム連携用M2M。client credentials grant・audienceマッパー。シークレットはインポート対象外）
  - テストユーザー `testuser`（パスワードはインポート対象外）
  - ロール・テナント関連は未確定事項の解消後に拡充する。
