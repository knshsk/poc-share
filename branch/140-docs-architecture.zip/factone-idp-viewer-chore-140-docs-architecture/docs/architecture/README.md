# 全体設計ドキュメント

モジュールを横断する全体像（L1）と、モジュールごとの構成（L2）。

## 文書一覧

- [overview.md](overview.md) — L1。システム文脈・コンポーネント構成・主要ユースケース・データの流れ
- `api.md` / `viewer.md` / `auth.md` / `view-url.md` — L2（作成予定。API・Viewer・認証・閲覧 URL）

## 記述方針

- L2 文書は「役割 / 構成 / 主要処理の流れ / 外部依存・設定 / 詳細仕様への導線」の 5 節で書く
- 図は Mermaid（構成図は `flowchart`、処理の流れは `sequenceDiagram`）。図と本文で同じ情報を二重に書かない
- テナント固有の外部システム名は書かない。外部は役割名で表す
- Keycloak realm 設計（realm 分離 or 単一 realm + テナントクレーム）は未確定。確定後に `auth.md` へ反映する
