<script setup lang="ts">
import { PhWarningCircle } from '@phosphor-icons/vue'

import DocumentCanvas from '../components/DocumentCanvas.vue'
import type { PublicVm } from '../mediator/vm'

// 閲覧者向け画面。ページ取得・ダウンロードは Mediator が行い、ここは vm の描画だけ
defineProps<{ vm: PublicVm }>()
</script>

<template>
  <!-- 無効URL / ダウンロード失敗: エラーstate（認証後 Viewer と同じ見た目。再試行は出さない） -->
  <div v-if="vm.error" class="state-screen">
    <PhWarningCircle :size="48" class="text-error mb-4" />
    <p class="text-body-large" data-testid="public-error">{{ vm.error }}</p>
  </div>

  <!-- 閲覧者向けはキャンバス全幅（読取矩形・右ペインなし）。ページ画像の遅延読込は PageSvg の可視化通知が page_view 記録の契機になる -->
  <div v-else class="public-layout">
    <DocumentCanvas v-if="vm.canvas" :vm="vm.canvas" />
    <div v-else class="canvas-loading">
      <v-skeleton-loader type="image" class="page-skeleton" />
    </div>
  </div>
</template>

<style scoped>
/* DocumentView の 2 ペインと同じ高さ計算（app-bar・footer を除く）でキャンバス内スクロールにする */
.public-layout {
  height: calc(100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px));
}
</style>
