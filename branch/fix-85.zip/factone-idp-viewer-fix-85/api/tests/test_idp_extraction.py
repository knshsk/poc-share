"""IDP抽出結果のパース・正規化・確信度分離のテスト。"""

from app.services.di import DiTable, DiTableCell, QueryFieldResult
from app.services.document_type_config import FieldDef, FieldType
from app.services.idp_extraction import parse_analysis, tables_to_json

ORDER_FIELDS = (
    FieldDef(key="customer_code", label="得意先コード", type=FieldType.STRING),
    FieldDef(key="item_code", label="品目コード", type=FieldType.STRING),
    FieldDef(key="quantity", label="数量", type=FieldType.NUMBER),
    FieldDef(key="delivery_date", label="納期", type=FieldType.DATE),
    FieldDef(key="unit_price", label="単価", type=FieldType.NUMBER),
)


class TestParseAnalysis:
    def test_separates_raw_normalized_and_confidence(self) -> None:
        results = {
            "customer_code": QueryFieldResult(value="C-9001", confidence=0.98),
            "item_code": QueryFieldResult(value="P-9001", confidence=0.95),
            "quantity": QueryFieldResult(value="2", confidence=0.99),
            "delivery_date": QueryFieldResult(value="2026-10-30", confidence=0.97),
            "unit_price": QueryFieldResult(value="500,000", confidence=0.96),
        }
        parsed = parse_analysis(ORDER_FIELDS, results)
        assert parsed.raw["unit_price"] == "500,000"
        assert parsed.normalized["unit_price"] == 500000
        assert parsed.confidence["unit_price"] == 0.96

    def test_normalizes_number_fields_by_type(self) -> None:
        fields = (FieldDef(key="anything", label="任意", type=FieldType.NUMBER),)
        results = {"anything": QueryFieldResult(value="1,200", confidence=0.9)}
        parsed = parse_analysis(fields, results)
        assert parsed.normalized["anything"] == 1200

    def test_normalizes_slash_date_to_iso_by_type(self) -> None:
        fields = (FieldDef(key="some_date", label="日付", type=FieldType.DATE),)
        results = {"some_date": QueryFieldResult(value="2026/10/30", confidence=0.9)}
        parsed = parse_analysis(fields, results)
        assert parsed.normalized["some_date"] == "2026-10-30"

    def test_string_field_passes_through(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"code": QueryFieldResult(value="A-001", confidence=0.9)}
        parsed = parse_analysis(fields, results)
        assert parsed.normalized["code"] == "A-001"

    def test_unparseable_number_keeps_raw_and_nulls_normalized(self) -> None:
        fields = (FieldDef(key="quantity", label="数量", type=FieldType.NUMBER),)
        results = {"quantity": QueryFieldResult(value="二個", confidence=0.4)}
        parsed = parse_analysis(fields, results)
        assert parsed.raw["quantity"] == "二個"
        assert parsed.normalized["quantity"] is None
        assert parsed.confidence["quantity"] == 0.4

    def test_unparseable_date_keeps_raw_and_nulls_normalized(self) -> None:
        fields = (FieldDef(key="delivery_date", label="納期", type=FieldType.DATE),)
        results = {"delivery_date": QueryFieldResult(value="月末", confidence=0.3)}
        parsed = parse_analysis(fields, results)
        assert parsed.raw["delivery_date"] == "月末"
        assert parsed.normalized["delivery_date"] is None

    def test_missing_field_yields_none_for_all_views(self) -> None:
        # 必須項目未抽出: 生値・正規化値・確信度すべてNoneで項目自体は返す
        parsed = parse_analysis(ORDER_FIELDS, {})
        assert parsed.raw["customer_code"] is None
        assert parsed.normalized["customer_code"] is None
        assert parsed.confidence["customer_code"] is None

    def test_extra_fields_outside_defs_are_ignored(self) -> None:
        fields = (FieldDef(key="code", label="コード", type=FieldType.STRING),)
        results = {"unexpected": QueryFieldResult(value="x", confidence=0.5)}
        parsed = parse_analysis(fields, results)
        assert "unexpected" not in parsed.raw


class TestTablesToJson:
    def test_serializes_tables_without_interpretation(self) -> None:
        # 意味付けせずJSON化する（明細特定・項目対応はSaaS責務外）
        tables = (
            DiTable(
                row_count=1,
                column_count=2,
                cells=(
                    DiTableCell(
                        row_index=0,
                        column_index=0,
                        content="品目",
                        kind="columnHeader",
                        page_number=1,
                        polygon=(1.0, 2.0),
                    ),
                    DiTableCell(
                        row_index=0,
                        column_index=1,
                        content="数量",
                        kind=None,
                        page_number=None,
                        polygon=None,
                    ),
                ),
            ),
        )
        assert tables_to_json(tables) == [
            {
                "row_count": 1,
                "column_count": 2,
                "cells": [
                    {
                        "row_index": 0,
                        "column_index": 0,
                        "content": "品目",
                        "kind": "columnHeader",
                        "page_number": 1,
                        "polygon": [1.0, 2.0],
                    },
                    {
                        "row_index": 0,
                        "column_index": 1,
                        "content": "数量",
                        "kind": None,
                        "page_number": None,
                        "polygon": None,
                    },
                ],
            }
        ]

    def test_empty_tables_yield_empty_list(self) -> None:
        assert tables_to_json(()) == []
