"""閲覧URL（発行・検証・失効・無認証閲覧）の統合テスト。

セキュリティ検証対象（厚くするテスト領域）。実PostgreSQLコンテナ接続。
"""

import io
from datetime import UTC, datetime, timedelta
from typing import Any

import pypdfium2 as pdfium
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select, text
from sqlalchemy.orm import Session

from app.models import ViewAccessFailure, ViewToken


@pytest.fixture(scope="module")
def pdf_bytes() -> bytes:
    doc = pdfium.PdfDocument.new()
    doc.new_page(612, 792)
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def register(
    client: TestClient,
    document_id: str,
    pdf: bytes,
    document_type: str = "quote",
) -> None:
    response = client.post(
        "/api/documents",
        data={"document_id": document_id, "document_type": document_type},
        files={"file": ("doc.pdf", pdf, "application/pdf")},
    )
    assert response.status_code == 201


def issue(client: TestClient, document_id: str, **payload: Any) -> Any:
    return client.post(f"/api/documents/{document_id}/view-urls", json=payload or None)


def test_issue_view_url_for_quote(doc_client: TestClient, pdf_bytes: bytes) -> None:
    """見積文書への閲覧URL発行が201となり、トークン込みパスと期限を返すことを確認する。"""
    register(doc_client, "vu-quote", pdf_bytes)

    response = issue(doc_client, "vu-quote")

    assert response.status_code == 201
    body = response.json()
    assert body["view_path"].startswith("/view/")
    # トークンは256bit URL-safe（43文字以上）
    assert len(body["view_path"].removeprefix("/view/")) >= 43
    assert "id" in body
    assert "expires_at" in body


def test_issue_rejected_for_non_shareable_type(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """注文書（非共有種別）への発行が403となることを確認する。"""
    register(doc_client, "vu-order", pdf_bytes, document_type="order_project")

    response = issue(doc_client, "vu-order")

    assert response.status_code == 403


def test_issue_for_unknown_document_returns_404(doc_client: TestClient) -> None:
    """存在しない文書への発行が404となることを確認する。"""
    response = issue(doc_client, "vu-none")

    assert response.status_code == 404


def test_issue_requires_auth(doc_client: TestClient, pdf_bytes: bytes) -> None:
    """トークンなしの発行が401となることを確認する。"""
    register(doc_client, "vu-auth", pdf_bytes)
    auth = doc_client.headers.pop("Authorization")

    response = issue(doc_client, "vu-auth")

    assert response.status_code == 401
    doc_client.headers["Authorization"] = auth


def test_token_plaintext_not_stored(
    doc_client: TestClient, pdf_bytes: bytes, test_database_url: str
) -> None:
    """トークン平文がDBに保存されないこと（ハッシュのみ）を確認する。"""
    register(doc_client, "vu-hash", pdf_bytes)
    token = issue(doc_client, "vu-hash").json()["view_path"].removeprefix("/view/")

    engine = create_engine(test_database_url)
    with Session(engine) as session:
        row = session.scalars(select(ViewToken)).one()
        assert row.token_hash != token
        assert len(row.token_hash) == 64  # SHA-256 hex
    engine.dispose()


def test_list_view_urls_excludes_token(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """発行済み一覧が管理情報のみでトークン平文を含まないことを確認する。"""
    register(doc_client, "vu-list", pdf_bytes)
    issue(doc_client, "vu-list")

    response = doc_client.get("/api/documents/vu-list/view-urls")

    assert response.status_code == 200
    items = response.json()
    assert len(items) == 1
    assert "id" in items[0]
    assert "view_path" not in items[0]
    assert "token" not in items[0]


def test_public_view_with_valid_token(doc_client: TestClient, pdf_bytes: bytes) -> None:
    """有効トークンで認証なしのページ閲覧・画像・原本取得ができることを確認する。"""
    register(doc_client, "vu-view", pdf_bytes)
    token = issue(doc_client, "vu-view").json()["view_path"].removeprefix("/view/")
    auth = doc_client.headers.pop("Authorization")

    pages = doc_client.get(f"/view/{token}/pages")
    image = doc_client.get(f"/view/{token}/pages/1/image")
    pdf = doc_client.get(f"/view/{token}/pdf")

    assert pages.status_code == 200
    assert pages.json()["page_count"] == 1
    assert image.status_code == 200
    assert image.headers["content-type"] == "image/png"
    assert pdf.status_code == 200
    doc_client.headers["Authorization"] = auth


def test_public_view_with_unknown_token_returns_404(doc_client: TestClient) -> None:
    """存在しないトークンが404となることを確認する。"""
    response = doc_client.get(f"/view/{'x' * 43}/pages")

    assert response.status_code == 404


def test_public_view_with_expired_token_returns_404(
    doc_client: TestClient, pdf_bytes: bytes, test_database_url: str
) -> None:
    """期限切れトークンが404となることを確認する。"""
    register(doc_client, "vu-exp", pdf_bytes)
    token = issue(doc_client, "vu-exp").json()["view_path"].removeprefix("/view/")

    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(
            text("UPDATE view_tokens SET expires_at = :past"),
            {"past": datetime.now(UTC) - timedelta(seconds=1)},
        )
        conn.commit()
    engine.dispose()

    response = doc_client.get(f"/view/{token}/pages")

    assert response.status_code == 404


def test_revoke_takes_effect_immediately(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """失効操作後、同一トークンでの閲覧が即時404となることを確認する。"""
    register(doc_client, "vu-rev", pdf_bytes)
    body = issue(doc_client, "vu-rev").json()
    token = body["view_path"].removeprefix("/view/")
    assert doc_client.get(f"/view/{token}/pages").status_code == 200

    revoke = doc_client.post(f"/api/view-urls/{body['id']}/revoke")

    assert revoke.status_code == 200
    assert doc_client.get(f"/view/{token}/pages").status_code == 404


def test_invalid_token_failure_is_recorded(
    doc_client: TestClient, test_database_url: str
) -> None:
    """無効トークンの試行が失敗記録に残ることを確認する。"""
    doc_client.get(f"/view/{'y' * 43}/pages")

    engine = create_engine(test_database_url)
    with Session(engine) as session:
        failures = session.scalars(select(ViewAccessFailure)).all()
        assert len(failures) == 1
        # トークン全体は記録しない（先頭断片のみ）
        assert failures[0].token_fragment == "y" * 8
    engine.dispose()


def test_repeated_failures_are_rate_limited(doc_client: TestClient) -> None:
    """無効トークンの連続試行がレート制限（429）となることを確認する。"""
    for _ in range(10):
        assert doc_client.get(f"/view/{'z' * 43}/pages").status_code == 404

    response = doc_client.get(f"/view/{'z' * 43}/pages")

    assert response.status_code == 429


def test_shareable_config_controls_issuance(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """設定でshareable=falseに変えると既存のquoteでも発行拒否となることを確認する。"""
    doc_client.put(
        "/api/config/document-types/quote",
        json={
            "display_name": "見積書",
            "shareable": False,
            "fields": [{"key": "document_no", "label": "文書番号", "type": "string"}],
        },
    )
    register(doc_client, "vu-cfg-1", pdf_bytes)

    response = issue(doc_client, "vu-cfg-1")

    assert response.status_code == 403


def test_shareable_new_type_allows_issuance(
    doc_client: TestClient, pdf_bytes: bytes
) -> None:
    """CRUDで追加したshareable=trueの種別へ発行できることを確認する。"""
    doc_client.post(
        "/api/config/document-types",
        json={
            "type_code": "invoice",
            "display_name": "請求書",
            "shareable": True,
            "fields": [{"key": "invoice_no", "label": "請求書番号", "type": "string"}],
        },
    )
    register(doc_client, "vu-cfg-2", pdf_bytes, document_type="invoice")

    response = issue(doc_client, "vu-cfg-2")

    assert response.status_code == 201
