"""create document_type_configs and seed defaults

Revision ID: 9fd9fa671055
Revises: e7b2c4a1f9d3
Create Date: 2026-09-01 12:00:00.000000

"""

import uuid
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision: str = "9fd9fa671055"
down_revision: str | None = "e7b2c4a1f9d3"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_ORDER_FIELDS = [
    {"key": "customer_code", "label": "得意先コード", "type": "string"},
    {"key": "item_code", "label": "品目コード", "type": "string"},
    {"key": "quantity", "label": "数量", "type": "number"},
    {"key": "delivery_date", "label": "納期", "type": "date"},
    {"key": "unit_price", "label": "単価", "type": "number"},
]

_SEED = [
    (
        "quote",
        "見積書",
        True,
        [
            {"key": "document_no", "label": "文書番号", "type": "string"},
            {"key": "customer_code", "label": "顧客コード", "type": "string"},
            {"key": "issue_date", "label": "発行日", "type": "date"},
            {"key": "total_amount", "label": "合計金額", "type": "number"},
        ],
    ),
    ("order_project", "注文書（プロジェクト）", False, _ORDER_FIELDS),
    ("order_route", "注文書（ルート）", False, _ORDER_FIELDS),
]


def upgrade() -> None:
    table = op.create_table(
        "document_type_configs",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", sa.String(255), nullable=False),
        sa.Column("type_code", sa.String(50), nullable=False),
        sa.Column("display_name", sa.String(100), nullable=False),
        sa.Column("shareable", sa.Boolean(), nullable=False),
        sa.Column("fields", JSONB(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.UniqueConstraint("tenant_id", "type_code", name="uq_document_type_configs"),
    )
    op.drop_constraint("ck_documents_document_type", "documents", type_="check")
    op.bulk_insert(
        table,
        [
            {
                "id": uuid.uuid4(),
                "tenant_id": "default",
                "type_code": code,
                "display_name": name,
                "shareable": shareable,
                "fields": fields,
            }
            for code, name, shareable, fields in _SEED
        ],
    )


def downgrade() -> None:
    op.create_check_constraint(
        "ck_documents_document_type",
        "documents",
        "document_type IN ('quote', 'order_project', 'order_route')",
    )
    op.drop_table("document_type_configs")
