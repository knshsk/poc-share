"""add field labels to idp runs

Revision ID: a3d51c7e8b24
Revises: 9fd9fa671055
Create Date: 2026-09-01 12:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "a3d51c7e8b24"
down_revision: str | None = "9fd9fa671055"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("idp_runs", sa.Column("field_labels", JSONB(), nullable=True))


def downgrade() -> None:
    op.drop_column("idp_runs", "field_labels")
