"""文書種別設定の取得と、fields JSONBの型付き変換。"""

import enum
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import DocumentTypeConfig


class FieldType(enum.StrEnum):
    """抽出フィールドの型。正規化の駆動に使う。"""

    STRING = "string"
    NUMBER = "number"
    DATE = "date"


@dataclass(frozen=True)
class FieldDef:
    """抽出フィールド定義（設定のfields要素の型付き表現）。"""

    key: str
    label: str
    type: FieldType


def get_config(
    session: Session, tenant_id: str, type_code: str
) -> DocumentTypeConfig | None:
    return session.execute(
        select(DocumentTypeConfig).where(
            DocumentTypeConfig.tenant_id == tenant_id,
            DocumentTypeConfig.type_code == type_code,
        )
    ).scalar_one_or_none()


def config_field_defs(config: DocumentTypeConfig) -> tuple[FieldDef, ...]:
    return tuple(
        FieldDef(key=f["key"], label=f["label"], type=FieldType(f["type"]))
        for f in config.fields
    )
