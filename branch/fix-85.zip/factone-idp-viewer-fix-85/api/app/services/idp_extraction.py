"""IDP抽出応答のパース・正規化・確信度分離。

生値（DIが返した文字列）と正規化値・確信度を分離して保持する。
対象フィールドと型は文書種別設定（document_type_configs）由来のFieldDefで受け取る。
"""

from collections.abc import Sequence
from dataclasses import asdict, dataclass
from datetime import date

from app.services.di import DiTable, QueryFieldResult
from app.services.document_type_config import FieldDef, FieldType


@dataclass(frozen=True)
class ParsedExtraction:
    """項目別の生値・正規化値・確信度。キーはフィールド定義と同一。"""

    raw: dict[str, str | None]
    normalized: dict[str, str | int | None]
    confidence: dict[str, float | None]


def _normalize(field_type: FieldType, value: str) -> str | int | None:
    if field_type is FieldType.NUMBER:
        try:
            return int(value.replace(",", ""))
        except ValueError:
            return None
    if field_type is FieldType.DATE:
        try:
            return date.fromisoformat(value.replace("/", "-")).isoformat()
        except ValueError:
            return None
    return value


def tables_to_json(tables: tuple[DiTable, ...]) -> list[dict[str, object]]:
    """テーブル領域（明細仮）をJSON化する。意味付け・正規化は行わない。"""
    serialized = []
    for table in tables:
        data = asdict(table)
        data["cells"] = [
            {**cell, "polygon": list(cell["polygon"]) if cell["polygon"] else None}
            for cell in data["cells"]
        ]
        serialized.append(data)
    return serialized


def parse_analysis(
    fields: Sequence[FieldDef], results: dict[str, QueryFieldResult]
) -> ParsedExtraction:
    raw: dict[str, str | None] = {}
    normalized: dict[str, str | int | None] = {}
    confidence: dict[str, float | None] = {}
    for field in fields:
        result = results.get(field.key)
        if result is None or result.value is None:
            raw[field.key] = None
            normalized[field.key] = None
            confidence[field.key] = result.confidence if result else None
            continue
        raw[field.key] = result.value
        normalized[field.key] = _normalize(field.type, result.value)
        confidence[field.key] = result.confidence
    return ParsedExtraction(raw=raw, normalized=normalized, confidence=confidence)
