---
status: accepted
date: 2026-09-01
---

# 文書種別をテナント別の設定値（document_type_configs）に移行する

## 背景

文書種別（Query Fields・閲覧URL発行可否）は `DocumentType` enum と DB の CHECK 制約、および `QUERY_FIELDS` のハードコードで固定されていた。マルチテナント SaaS としてテナントごとに異なる文書種別を扱う必要があり、コード埋め込みではテナント別の差分を表現できない。

## 決定

文書種別を `document_type_configs` テーブル（tenant_id + type_code で一意）のテナント別設定に移行する。種別ごとに表示名・閲覧URL発行可否（`shareable`）・抽出フィールド定義（key / label / type の JSONB 配列）を保持し、CRUD API（`/api/config/document-types`）で管理する。`DocumentType` enum と CHECK 制約は廃止し、種別コードは自由値としてアプリ層で設定テーブルを参照して検証する。正規化はフィールドの `type`（string / number / date）駆動とする。

ADR-0002 の「注文書は閲覧URL発行禁止」という判断自体は維持し、シードデータのデフォルト値（order_* は shareable=false）として引き継ぐ。強制の所在が enum + CHECK 制約から設定値へ移る。列名は用途を顧客向けに限定しない `shareable` とした。

## 検討した代替案

- 正規化2テーブル（document_types + document_type_fields） — フィールド単独のクエリ・参照要件がなく、コード量だけ増える（YAGNI）
- テナント単位の一括JSONB — 種別単位の削除保護・部分更新が全てアプリロジックになり粒度が粗い
- enum 維持でフィールドのみ設定化 — 種別コード自体をテナントごとに変えられず要件を満たさない

## 影響

- 種別の整合性保証が DB 制約からアプリ層検証（登録時 422・IDP実行時 409）へ移る
- 使用中種別（documents に参照行あり）の削除は 409 で保護する。フィールド定義の更新は自由（過去の IDP 実行ログは実行時点の結果を JSONB で保持済みのため影響なし）
- テナント解決は現状 `settings.tenant_id` 固定のまま。リクエストからのテナント解決導入時に設定参照のスコープをそのまま利用できる
- 設定CRUDの認可は既存認証（CurrentUser）のみ。ロール別制御が必要になった時点で見直す
