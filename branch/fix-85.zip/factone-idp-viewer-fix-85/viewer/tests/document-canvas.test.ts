import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

// 画像取得はapiClient経由のためモックする（キャンバスはナビ・ズーム操作が検証対象）
const getMock = vi
  .fn()
  .mockResolvedValue({ data: new Blob(), error: undefined })
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
}))

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import PageSvg from '../src/components/PageSvg.vue'
import { createAppVuetify } from '../src/plugins/vuetify'

const pages = [
  { width: 8.5, height: 11 },
  { width: 8.5, height: 11 },
  { width: 8.5, height: 11 },
]

function mountCanvas() {
  return mount(DocumentCanvas, {
    props: { documentId: 'doc-1', pages },
    global: { plugins: [createAppVuetify()] },
  })
}

describe('DocumentCanvas', () => {
  // 全ページ分のPageSvgを描画することを確認する
  it('全ページを描画しページ表示を出す', () => {
    const wrapper = mountCanvas()
    expect(wrapper.findAllComponents(PageSvg)).toHaveLength(3)
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('1 / 3')
  })

  // 次/前ページボタンで表示中ページが移動し、境界でクランプされることを確認する
  it('次/前ページで表示中ページが移動する', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="canvas-next"]').trigger('click')
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('2 / 3')
    await wrapper.get('[data-testid="canvas-prev"]').trigger('click')
    await wrapper.get('[data-testid="canvas-prev"]').trigger('click')
    // 1ページ目より前へは行かない（ボタンはdisabledになりクリックは無効）
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('1 / 3')
  })

  // ズームは25%刻み・50〜200%でクランプされ、幅合わせで100%へ戻ることを確認する
  it('ズームと幅合わせが機能する', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('125%')
    await wrapper.get('[data-testid="canvas-fit"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')
    // 下限クランプ（100→75→50→50）
    const zoomOut = wrapper.get('[data-testid="canvas-zoom-out"]')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('50%')
  })

  // 原本DLボタンがイベントを発火することを確認する
  it('原本DLボタンでdownloadOriginalをemitする', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="download-original"]').trigger('click')
    expect(wrapper.emitted('downloadOriginal')).toHaveLength(1)
  })
})
