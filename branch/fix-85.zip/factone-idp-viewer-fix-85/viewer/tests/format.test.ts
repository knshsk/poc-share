import { describe, expect, it } from 'vitest'

import {
  confidenceColor,
  formatConfidence,
  formatDateTime,
} from '../src/utils/format'

describe('format', () => {
  it('確信度を%表示する（null系は-）', () => {
    expect(formatConfidence(0.98)).toBe('98%')
    expect(formatConfidence(0.755)).toBe('76%')
    expect(formatConfidence(null)).toBe('-')
    expect(formatConfidence(undefined)).toBe('-')
  })

  // 90%/80%閾値の3段階（照合の視覚誘導に使用）
  it('確信度を3段階の色トークンへ分類する', () => {
    expect(confidenceColor(0.95)).toBe('success')
    expect(confidenceColor(0.9)).toBe('success')
    expect(confidenceColor(0.85)).toBe('warning')
    expect(confidenceColor(0.8)).toBe('warning')
    expect(confidenceColor(0.79)).toBe('error')
    expect(confidenceColor(null)).toBeUndefined()
  })

  it('日時をロケール文字列にする', () => {
    expect(formatDateTime('2026-08-01T00:00:00Z')).toBe(
      new Date('2026-08-01T00:00:00Z').toLocaleString(),
    )
  })
})
