import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'

import { useDocumentStore } from '../src/stores/document'

describe('documentストア', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  // ヘッダと画面が同じ文書コンテキストを共有するためのストア
  it('初期状態は未指定・未確定', () => {
    const store = useDocumentStore()
    expect(store.documentId).toBe('')
    expect(store.loadedDocumentId).toBeNull()
    expect(store.documentType).toBeNull()
  })

  it('文書ID・種別を保持する', () => {
    const store = useDocumentStore()
    store.documentId = 'doc-1'
    store.loadedDocumentId = 'doc-1'
    store.documentType = 'quote'
    expect(store.documentType).toBe('quote')
  })
})
