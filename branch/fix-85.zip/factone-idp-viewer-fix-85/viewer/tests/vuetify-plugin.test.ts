import { mount } from '@vue/test-utils'
import { defineComponent } from 'vue'
import { describe, expect, it } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// Vuetifyコンポーネントが実要素として解決されることを確認する回帰テスト。
// 未登録だと <v-text-field> 等が未知要素として素通しされ、画面が素のHTMLになる。
describe('Vuetifyプラグイン設定', () => {
  it('v-text-fieldがinput要素として描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-text-field label="文書ID" /></v-app>',
    })

    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.find('input').exists()).toBe(true)
  })

  it('v-btnがbutton要素として描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-btn>表示</v-btn></v-app>',
    })

    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.find('button').exists()).toBe(true)
  })

  // カラートークンはvuetify.tsで一元管理する（コンポーネント側hex直書き禁止の前提）
  it('factoneテーマにパレットトークンが定義される', () => {
    const vuetify = createAppVuetify()
    const colors = vuetify.theme.themes.value.factone!.colors
    expect(colors.primary).toBe('#0F6CBD')
    expect(colors.canvas).toBe('#E9EDF2')
    expect(colors.warning).toBe('#9A6700')
    expect(colors.error).toBe('#D13438')
    expect(colors.success).toBe('#107C10')
  })

  // Vuetify内部アイコン（$close等）がPhosphorコンポーネントとしてSVG描画されることを確認する
  it('アイコンエイリアスがPhosphorのSVGとして描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-icon icon="$close" /></v-app>',
    })
    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })
    expect(wrapper.find('svg').exists()).toBe(true)
  })
})
