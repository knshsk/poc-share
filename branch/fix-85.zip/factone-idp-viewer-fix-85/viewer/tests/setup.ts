// jsdomに存在しないResizeObserverをVuetifyのレイアウトコンポーネントが要求するため補う
class ResizeObserverStub {
  observe(): void {}
  unobserve(): void {}
  disconnect(): void {}
}

globalThis.ResizeObserver =
  ResizeObserverStub as unknown as typeof ResizeObserver

// jsdomに存在しないvisualViewportをVuetifyのオーバーレイ配置（v-menu等）が要求するため補う
globalThis.visualViewport = {
  width: 1280,
  height: 800,
  offsetLeft: 0,
  offsetTop: 0,
  pageLeft: 0,
  pageTop: 0,
  scale: 1,
  addEventListener(): void {},
  removeEventListener(): void {},
  dispatchEvent(): boolean {
    return false
  },
  onresize: null,
  onscroll: null,
} as unknown as VisualViewport
