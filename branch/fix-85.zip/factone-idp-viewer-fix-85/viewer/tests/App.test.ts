import { mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { describe, expect, it } from 'vitest'

import App from '../src/App.vue'
import { createAppVuetify } from '../src/plugins/vuetify'
import { useAuthStore } from '../src/stores/auth'

describe('App', () => {
  // Vuetify・Piniaを組み込んだAppがレンダリングされ、アプリ名が表示されることを確認する
  it('アプリ名を表示する', () => {
    const wrapper = mount(App, {
      global: {
        plugins: [createAppVuetify(), createPinia()],
      },
    })

    expect(wrapper.text()).toContain('FactONE Viewer')
  })

  // 未認証時はログインカードを表示することを確認する
  it('未認証時はログインボタンを表示する', () => {
    const wrapper = mount(App, {
      global: { plugins: [createAppVuetify(), createPinia()] },
    })

    expect(wrapper.text()).toContain('ログイン')
  })

  // 認証済でもデバッグ要素（API呼出・/api/me表示）を持たないことを確認する
  it('認証済時にデバッグ要素を表示しない', async () => {
    window.history.replaceState(null, '', '/')
    const wrapper = mount(App, {
      global: { plugins: [createAppVuetify(), createPinia()] },
    })
    const auth = useAuthStore()
    auth.isAuthenticated = true
    auth.username = 'sales01'
    await wrapper.vm.$nextTick()

    expect(wrapper.text()).not.toContain('API呼出')
    expect(wrapper.text()).not.toContain('/api/me')
  })
})
