<script setup lang="ts">
import { PhCopy, PhLinkSimple } from '@phosphor-icons/vue'
import { onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import type { components } from '../api/schema'
import { formatDateTime } from '../utils/format'

type ViewUrlSummary = components['schemas']['ViewUrlSummary']

const props = defineProps<{
  documentId: string
}>()

const urls = ref<ViewUrlSummary[]>([])
// 発行直後の平文URL。再表示不可（サーバはハッシュのみ保持）のため発行時のみ提示する
const issuedUrl = ref<string | null>(null)
const issuing = ref(false)
const errorMessage = ref<string | null>(null)
// 失効確認ダイアログの対象ID（null=非表示）
const revokeTarget = ref<string | null>(null)

async function loadUrls(): Promise<void> {
  errorMessage.value = null
  urls.value = []
  if (!props.documentId) return

  const { data, error } = await apiClient.GET(
    '/api/documents/{document_id}/view-urls',
    {
      params: { path: { document_id: props.documentId } },
    },
  )
  if (error || !data) {
    errorMessage.value = '閲覧URL一覧を取得できませんでした'
    return
  }
  urls.value = data
}

async function issueUrl(): Promise<void> {
  errorMessage.value = null
  issuing.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/documents/{document_id}/view-urls',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = '閲覧URLの発行に失敗しました'
      return
    }
    issuedUrl.value = `${window.location.origin}${data.view_path}`
    await loadUrls()
  } finally {
    issuing.value = false
  }
}

async function copyIssuedUrl(): Promise<void> {
  if (issuedUrl.value) await navigator.clipboard.writeText(issuedUrl.value)
}

async function revokeUrl(viewUrlId: string): Promise<void> {
  errorMessage.value = null
  const { error } = await apiClient.POST(
    '/api/view-urls/{view_url_id}/revoke',
    {
      params: { path: { view_url_id: viewUrlId } },
    },
  )
  if (error) {
    errorMessage.value = '閲覧URLの失効に失敗しました'
    return
  }
  await loadUrls()
}

async function confirmRevoke(): Promise<void> {
  if (!revokeTarget.value) return
  const target = revokeTarget.value
  revokeTarget.value = null
  await revokeUrl(target)
}

function isExpired(url: ViewUrlSummary): boolean {
  return new Date(url.expires_at).getTime() <= Date.now()
}

function statusLabel(url: ViewUrlSummary): string {
  if (url.revoked) return '失効'
  if (isExpired(url)) return '期限切れ'
  return '有効'
}

function statusColor(url: ViewUrlSummary): string {
  if (url.revoked) return 'error'
  if (isExpired(url)) return 'secondary'
  return 'success'
}

onMounted(() => void loadUrls())
watch(
  () => props.documentId,
  () => {
    issuedUrl.value = null
    void loadUrls()
  },
)
</script>

<template>
  <div>
    <div class="d-flex align-center mb-2">
      <v-btn
        color="primary"
        variant="tonal"
        data-testid="issue-view-url"
        :loading="issuing"
        :disabled="issuing || !documentId"
        @click="issueUrl"
      >
        <PhLinkSimple :size="16" class="mr-1" />
        閲覧URL発行
      </v-btn>
    </div>
    <v-alert
      v-if="errorMessage"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-2"
    >
      {{ errorMessage }}
    </v-alert>

    <div v-if="issuedUrl" class="issued-block mb-3">
      <div class="d-flex align-center ga-2">
        <code class="font-mono issued-url" data-testid="issued-url">{{
          issuedUrl
        }}</code>
        <v-btn
          data-testid="copy-view-url"
          size="small"
          variant="text"
          aria-label="コピー"
          @click="copyIssuedUrl"
        >
          <PhCopy :size="16" class="mr-1" />
          コピー
        </v-btn>
      </div>
      <p class="text-caption text-warning mb-0">
        このURLは再表示できません。今すぐコピーしてください
      </p>
    </div>

    <v-list v-if="urls.length > 0" density="compact" class="pa-0">
      <v-list-item
        v-for="url in urls"
        :key="url.id"
        data-testid="view-url-row"
        class="px-0"
      >
        <v-list-item-title class="font-mono text-body-2">
          {{ formatDateTime(url.issued_at) }}
        </v-list-item-title>
        <v-list-item-subtitle class="font-mono">
          期限: {{ formatDateTime(url.expires_at) }}
        </v-list-item-subtitle>
        <template #append>
          <v-chip size="x-small" variant="tonal" :color="statusColor(url)">
            {{ statusLabel(url) }}
          </v-chip>
          <v-btn
            v-if="!url.revoked && !isExpired(url)"
            data-testid="revoke-view-url"
            size="small"
            variant="text"
            color="error"
            class="ml-2"
            @click="revokeTarget = url.id"
          >
            失効
          </v-btn>
        </template>
      </v-list-item>
    </v-list>

    <!-- 失効は取消不可のため確認ダイアログを挟む -->
    <v-dialog :model-value="revokeTarget !== null" max-width="400">
      <v-card>
        <v-card-title class="text-body-1">
          閲覧URLを失効させますか？
        </v-card-title>
        <v-card-text class="text-body-2 text-secondary">
          失効すると得意先はこのURLで閲覧できなくなります。取消はできません。
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn data-testid="revoke-cancel" @click="revokeTarget = null">
            キャンセル
          </v-btn>
          <v-btn
            color="error"
            variant="flat"
            data-testid="revoke-confirm"
            @click="confirmRevoke"
          >
            失効
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<style scoped>
.issued-url {
  overflow-wrap: anywhere;
  font-size: 0.8125rem;
}
</style>
