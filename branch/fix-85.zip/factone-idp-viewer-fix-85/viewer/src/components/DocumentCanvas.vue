<script setup lang="ts">
import {
  PhArrowsHorizontal,
  PhCaretLeft,
  PhCaretRight,
  PhDownloadSimple,
  PhMagnifyingGlassMinus,
  PhMagnifyingGlassPlus,
} from '@phosphor-icons/vue'
import type { ComponentPublicInstance } from 'vue'
import { ref } from 'vue'

import PageSvg from './PageSvg.vue'

export interface PageInfo {
  width: number
  height: number
}

const props = defineProps<{
  documentId: string
  pages: PageInfo[]
}>()

const emit = defineEmits<{ downloadOriginal: [] }>()

const ZOOM_MIN = 50
const ZOOM_MAX = 200
const ZOOM_STEP = 25
// ズームはコンテナ幅比%（100=幅合わせ）。CSS width制御のためPageSvgのviewBox（DI座標系）は不変
const zoom = ref(100)
const currentPage = ref(1)
const scroller = ref<HTMLElement | null>(null)
const pageEls = ref<HTMLElement[]>([])

function setPageEl(
  el: Element | ComponentPublicInstance | null,
  index: number,
): void {
  if (el instanceof HTMLElement) pageEls.value[index] = el
}

function zoomIn(): void {
  zoom.value = Math.min(ZOOM_MAX, zoom.value + ZOOM_STEP)
}

function zoomOut(): void {
  zoom.value = Math.max(ZOOM_MIN, zoom.value - ZOOM_STEP)
}

function fitWidth(): void {
  zoom.value = 100
}

function goToPage(page: number): void {
  const target = Math.min(props.pages.length, Math.max(1, page))
  currentPage.value = target
  // jsdomはscrollIntoView未実装のため存在確認する
  pageEls.value[target - 1]?.scrollIntoView?.({
    block: 'start',
    behavior: 'smooth',
  })
}

// スクロール位置から表示中ページを判定（コンテナ上端+1/3を基準線とする）
function onScroll(): void {
  const container = scroller.value
  if (!container) return
  const line =
    container.getBoundingClientRect().top + container.clientHeight / 3
  for (let i = pageEls.value.length - 1; i >= 0; i--) {
    const rect = pageEls.value[i]?.getBoundingClientRect()
    if (rect && rect.top <= line) {
      currentPage.value = i + 1
      return
    }
  }
  currentPage.value = 1
}
</script>

<template>
  <div class="document-canvas">
    <div class="canvas-toolbar">
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-prev"
        aria-label="前のページ"
        :disabled="currentPage <= 1"
        @click="goToPage(currentPage - 1)"
      >
        <PhCaretLeft :size="18" />
      </v-btn>
      <span class="font-mono text-body-2" data-testid="canvas-page-indicator">
        {{ currentPage }} / {{ pages.length }}
      </span>
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-next"
        aria-label="次のページ"
        :disabled="currentPage >= pages.length"
        @click="goToPage(currentPage + 1)"
      >
        <PhCaretRight :size="18" />
      </v-btn>

      <v-divider vertical class="mx-2" />

      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-zoom-out"
        aria-label="縮小"
        :disabled="zoom <= ZOOM_MIN"
        @click="zoomOut"
      >
        <PhMagnifyingGlassMinus :size="18" />
      </v-btn>
      <span class="font-mono text-body-2" data-testid="canvas-zoom"
        >{{ zoom }}%</span
      >
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-zoom-in"
        aria-label="拡大"
        :disabled="zoom >= ZOOM_MAX"
        @click="zoomIn"
      >
        <PhMagnifyingGlassPlus :size="18" />
      </v-btn>
      <v-btn
        icon
        size="small"
        variant="text"
        data-testid="canvas-fit"
        aria-label="幅合わせ"
        @click="fitWidth"
      >
        <PhArrowsHorizontal :size="18" />
      </v-btn>

      <v-spacer />

      <v-btn
        variant="outlined"
        size="small"
        data-testid="download-original"
        @click="emit('downloadOriginal')"
      >
        <PhDownloadSimple :size="16" class="mr-1" />
        原本DL
      </v-btn>
    </div>

    <div ref="scroller" class="canvas-scroller" @scroll.passive="onScroll">
      <div
        v-for="(page, index) in pages"
        :key="index"
        :ref="(el) => setPageEl(el, index)"
        class="page-frame"
        :style="{ width: `${zoom}%` }"
      >
        <PageSvg
          :document-id="documentId"
          :page="index + 1"
          :width="page.width"
          :height="page.height"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
.document-canvas {
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 100%;
}

.canvas-toolbar {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 12px;
  background: rgb(var(--v-theme-surface));
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.canvas-scroller {
  flex: 1;
  overflow: auto;
  background: rgb(var(--v-theme-canvas));
  padding: 24px;
}

.page-frame {
  margin: 0 auto 24px;
  background: rgb(var(--v-theme-surface));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
</style>
