<script setup lang="ts">
import { PhArrowsClockwise } from '@phosphor-icons/vue'
import { onMounted, ref, watch } from 'vue'

import { apiClient } from '../api/client'
import type { components } from '../api/schema'
import {
  confidenceColor,
  formatConfidence,
  formatDateTime,
} from '../utils/format'
import ViewUrlPanel from './ViewUrlPanel.vue'

type IdpRun = components['schemas']['IdpRunResponse']

// shareable: 文書種別設定（document_type_configs）の共有可否。閲覧URLタブの表示ゲート
const props = defineProps<{
  documentId: string
  shareable: boolean
}>()

const activeTab = ref<'result' | 'history' | 'urls'>('result')
// 履歴は表示用に実行日時降順で保持する（サーバ応答は昇順）
const runs = ref<IdpRun[]>([])
const selectedRunId = ref<string | null>(null)
const executing = ref(false)
const loadingRuns = ref(false)
const errorMessage = ref<string | null>(null)

function selectedRun(): IdpRun | null {
  return runs.value.find((run) => run.run_id === selectedRunId.value) ?? null
}

async function loadRuns(): Promise<void> {
  errorMessage.value = null
  runs.value = []
  selectedRunId.value = null
  if (!props.documentId) return

  loadingRuns.value = true
  try {
    const { data, error } = await apiClient.GET(
      '/api/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = '実行履歴を取得できませんでした'
      return
    }
    runs.value = [...data.runs].reverse()
    selectedRunId.value = runs.value[0]?.run_id ?? null
  } finally {
    loadingRuns.value = false
  }
}

async function executeIdp(): Promise<void> {
  errorMessage.value = null
  executing.value = true
  try {
    const { data, error } = await apiClient.POST(
      '/api/documents/{document_id}/idp-runs',
      {
        params: { path: { document_id: props.documentId } },
      },
    )
    if (error || !data) {
      errorMessage.value = 'IDP実行に失敗しました'
      return
    }
    runs.value = [data, ...runs.value]
    selectedRunId.value = data.run_id
    activeTab.value = 'result'
  } finally {
    executing.value = false
  }
}

function selectRun(runId: string): void {
  selectedRunId.value = runId
  activeTab.value = 'result'
}

onMounted(() => void loadRuns())
watch(
  () => props.documentId,
  () => void loadRuns(),
)
</script>

<template>
  <div class="work-panel">
    <!-- IDP実行はタブ非依存で常置（K5-5/R1-5の再項目化導線） -->
    <div class="d-flex align-center mb-3">
      <v-btn
        color="primary"
        data-testid="execute-idp"
        :loading="executing"
        :disabled="executing || !documentId"
        @click="executeIdp"
      >
        <PhArrowsClockwise :size="16" class="mr-1" />
        IDP実行
      </v-btn>
    </div>
    <v-alert
      v-if="errorMessage"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-3"
    >
      {{ errorMessage }}
    </v-alert>

    <v-tabs v-model="activeTab" density="compact" color="primary">
      <v-tab value="result" data-testid="tab-result">読取結果</v-tab>
      <v-tab value="history" data-testid="tab-history">実行履歴</v-tab>
      <v-tab v-if="props.shareable" value="urls" data-testid="tab-urls">
        閲覧URL
      </v-tab>
    </v-tabs>

    <v-tabs-window v-model="activeTab" class="pt-3">
      <v-tabs-window-item value="result">
        <v-skeleton-loader v-if="loadingRuns" type="list-item@3" />
        <template v-else-if="selectedRun()">
          <div
            v-if="selectedRun()!.status === 'succeeded'"
            data-testid="run-result"
          >
            <div
              v-for="(value, key) in selectedRun()!.normalized_fields ?? {}"
              :key="key"
              class="field-row"
              data-testid="field-row"
            >
              <div class="d-flex justify-space-between align-baseline">
                <span class="text-caption text-secondary">{{
                  selectedRun()!.field_labels?.[key] ?? key
                }}</span>
                <span
                  class="font-mono text-caption"
                  :class="
                    confidenceColor(selectedRun()!.confidence?.[key])
                      ? `text-${confidenceColor(selectedRun()!.confidence?.[key])}`
                      : ''
                  "
                >
                  {{ formatConfidence(selectedRun()!.confidence?.[key]) }}
                </span>
              </div>
              <div class="text-body-2">{{ value ?? '-' }}</div>
              <v-progress-linear
                :model-value="(selectedRun()!.confidence?.[key] ?? 0) * 100"
                :color="confidenceColor(selectedRun()!.confidence?.[key])"
                :class="
                  confidenceColor(selectedRun()!.confidence?.[key])
                    ? `text-${confidenceColor(selectedRun()!.confidence?.[key])}`
                    : ''
                "
                height="4"
                rounded
                data-testid="confidence-bar"
              />
            </div>
          </div>
          <p v-else class="text-error text-body-2" data-testid="run-error">
            実行失敗: {{ selectedRun()!.error_info ?? '不明なエラー' }}
          </p>
        </template>
        <p v-else class="text-secondary text-body-2">実行結果がありません</p>
      </v-tabs-window-item>

      <v-tabs-window-item value="history">
        <v-list density="compact">
          <v-list-item
            v-for="run in runs"
            :key="run.run_id"
            data-testid="run-row"
            :active="run.run_id === selectedRunId"
            @click="selectRun(run.run_id)"
          >
            <v-list-item-title class="font-mono text-body-2">
              {{ formatDateTime(run.executed_at) }}
            </v-list-item-title>
            <v-list-item-subtitle>
              {{ run.run_type === 'initial' ? '初回' : '再実行' }}
              ・
              <span
                :class="
                  run.status === 'succeeded' ? 'text-success' : 'text-error'
                "
              >
                {{ run.status === 'succeeded' ? '成功' : '失敗' }}
              </span>
            </v-list-item-subtitle>
          </v-list-item>
        </v-list>
        <p v-if="runs.length === 0" class="text-secondary text-body-2">
          実行履歴がありません
        </p>
      </v-tabs-window-item>

      <v-tabs-window-item v-if="props.shareable" value="urls">
        <ViewUrlPanel :document-id="documentId" />
      </v-tabs-window-item>
    </v-tabs-window>
  </div>
</template>

<style scoped>
.field-row {
  padding: 8px 0;
  border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.field-row:last-child {
  border-bottom: none;
}
</style>
