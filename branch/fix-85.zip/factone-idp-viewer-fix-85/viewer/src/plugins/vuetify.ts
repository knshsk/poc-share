import 'vuetify/styles'

import {
  PhArrowDown,
  PhArrowElbowDownLeft,
  PhArrowFatUp,
  PhArrowLeft,
  PhArrowRight,
  PhArrowUp,
  PhBackspace,
  PhCalendarBlank,
  PhCaretDown,
  PhCaretLeft,
  PhCaretLineLeft,
  PhCaretLineRight,
  PhCaretRight,
  PhCaretUp,
  PhCaretUpDown,
  PhCheck,
  PhCheckCircle,
  PhCheckSquare,
  PhCircle,
  PhCommand,
  PhControl,
  PhEyedropper,
  PhInfo,
  PhList,
  PhMinus,
  PhMinusSquare,
  PhOption,
  PhPalette,
  PhPaperclip,
  PhPencilSimple,
  PhPlus,
  PhRadioButton,
  PhSpinner,
  PhSquare,
  PhStar,
  PhStarHalf,
  PhUploadSimple,
  PhWarning,
  PhWarningCircle,
  PhX,
  PhXCircle,
} from '@phosphor-icons/vue'
import type { FunctionalComponent } from 'vue'
import { h } from 'vue'
import type { IconAliases, IconProps, IconSet } from 'vuetify'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

// カラートークンの唯一の定義箇所（Fluent Azureパレット）。
// ここの値を変更するとアプリ全体へ反映される。コンポーネント側での hex 直書きは禁止し、
// color="primary" などのテーマ参照か rgb(var(--v-theme-xxx)) の CSS 変数で参照する。
const factoneColors = {
  primary: '#0F6CBD',
  'primary-darken-1': '#115EA3',
  secondary: '#616161',
  background: '#F7F9FB',
  surface: '#FFFFFF',
  // ドキュメントキャンバス地（ページ画像の背景）・バッジ背景
  canvas: '#E9EDF2',
  success: '#107C10',
  warning: '#9A6700',
  error: '#D13438',
  'on-surface': '#242424',
  'on-canvas': '#424242',
}

// Vuetify内部が使用するアイコンをPhosphorへ差し替える（mdi依存を持たない）
const aliases: IconAliases = {
  collapse: PhCaretUp,
  complete: PhCheck,
  cancel: PhXCircle,
  close: PhX,
  delete: PhXCircle,
  clear: PhXCircle,
  success: PhCheckCircle,
  info: PhInfo,
  warning: PhWarning,
  error: PhWarningCircle,
  prev: PhCaretLeft,
  next: PhCaretRight,
  checkboxOn: PhCheckSquare,
  checkboxOff: PhSquare,
  checkboxIndeterminate: PhMinusSquare,
  delimiter: PhCircle,
  sortAsc: PhArrowUp,
  sortDesc: PhArrowDown,
  expand: PhCaretDown,
  menu: PhList,
  subgroup: PhCaretDown,
  dropdown: PhCaretDown,
  radioOn: PhRadioButton,
  radioOff: PhCircle,
  edit: PhPencilSimple,
  ratingEmpty: PhStar,
  ratingFull: PhStar,
  ratingHalf: PhStarHalf,
  loading: PhSpinner,
  first: PhCaretLineLeft,
  last: PhCaretLineRight,
  unfold: PhCaretUpDown,
  file: PhPaperclip,
  plus: PhPlus,
  minus: PhMinus,
  calendar: PhCalendarBlank,
  treeviewCollapse: PhCaretDown,
  treeviewExpand: PhCaretRight,
  eyeDropper: PhEyedropper,
  upload: PhUploadSimple,
  color: PhPalette,
  // キーボードキー表示用（VHotkey等）
  command: PhCommand,
  ctrl: PhControl,
  space: PhMinus,
  shift: PhArrowFatUp,
  alt: PhOption,
  enter: PhArrowElbowDownLeft,
  arrowup: PhArrowUp,
  arrowdown: PhArrowDown,
  arrowleft: PhArrowLeft,
  arrowright: PhArrowRight,
  backspace: PhBackspace,
}

// エイリアス値（Phosphorコンポーネント）をそのまま描画するアイコンセット。
// 文字列アイコン名は解決しないため、テンプレートでは $alias か Phosphor 直接 import を使う
const phosphor: IconSet = {
  component: (props: IconProps) =>
    h(props.icon as FunctionalComponent, { size: '1.25em' }),
}

// components/directivesを登録しないと<v-btn>等が未知要素として素通し描画される
export function createAppVuetify() {
  return createVuetify({
    components,
    directives,
    theme: {
      defaultTheme: 'factone',
      themes: {
        factone: { dark: false, colors: factoneColors },
      },
    },
    icons: {
      defaultSet: 'phosphor',
      aliases,
      sets: { phosphor },
    },
  })
}
