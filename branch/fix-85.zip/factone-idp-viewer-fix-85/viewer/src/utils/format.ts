// 表示用フォーマッタ。確信度の閾値（0.9/0.8）はここが唯一の定義箇所
export function formatConfidence(value: number | null | undefined): string {
  if (value == null) return '-'
  return `${Math.round(value * 100)}%`
}

export function confidenceColor(
  value: number | null | undefined,
): 'success' | 'warning' | 'error' | undefined {
  if (value == null) return undefined
  if (value >= 0.9) return 'success'
  if (value >= 0.8) return 'warning'
  return 'error'
}

export function formatDateTime(value: string): string {
  return new Date(value).toLocaleString()
}
