<script setup lang="ts">
import { onMounted } from 'vue'

import AppHeader from './components/AppHeader.vue'
import { useAuthStore } from './stores/auth'
import DocumentView from './views/DocumentView.vue'
import PublicView from './views/PublicView.vue'

const auth = useAuthStore()

// 閲覧URL（/view/{token}）は認証なしの顧客閲覧画面（ルーター未導入のためパス判定）
const viewToken = window.location.pathname.startsWith('/view/')
  ? window.location.pathname.split('/')[2]
  : null

onMounted(async () => {
  // ルーター未導入のため、コールバックURLはパスで判定して処理する
  if (window.location.pathname === '/callback') {
    await auth.handleCallback()
    window.history.replaceState({}, '', '/')
  }
})
</script>

<template>
  <v-app>
    <v-main v-if="viewToken">
      <PublicView :token="viewToken" />
    </v-main>

    <template v-else-if="auth.isAuthenticated">
      <AppHeader />
      <v-main class="bg-background">
        <DocumentView />
      </v-main>
    </template>

    <v-main v-else class="bg-background">
      <div class="login-screen">
        <v-card class="login-card pa-8" elevation="2" rounded="lg">
          <div class="text-primary font-weight-bold text-h6 mb-2">
            FactONE Viewer
          </div>
          <p class="text-secondary text-body-2 mb-6">
            プロトタイプ実装中のため、動作は予告なく変更される可能性があります。
          </p>
          <v-btn color="primary" block size="large" @click="auth.login">
            ログイン
          </v-btn>
        </v-card>
      </div>
    </v-main>
  </v-app>
</template>

<style scoped>
.login-screen {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100dvh;
}

.login-card {
  width: 360px;
  max-width: 90vw;
}
</style>
