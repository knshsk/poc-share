# Viewer

## 役割

Vue 3 + VuetifyのSPA。画面は2つあり、テナント利用者向けの認証ありの画面と、閲覧者向けの無認証の画面である。認証ありの画面では、文書の表示・登録・IDP実行・読取結果の確認と修正・閲覧URLの管理を行う。無認証の画面では、文書を表示・ダウンロードする。ビルド成果物はAPIコンテナに同梱され、APIが配信する。

## 構成

```mermaid
flowchart TB
    root["Root.vue（Mediator を保持。bubble の終点）"]
    root --> header["AppHeader（文書タイトル（種別・原本ファイル名・文書 ID）か「文書を開く」・ユーザーメニュー）"]
    root -- "screen=login" --> login["LoginView"]
    root -- "screen=loading" --> loading["LoadingSpinner（起動・コールバック処理中）"]
    root -- "screen=public" --> pub["PublicView"]
    root -- "screen=document" --> docv["DocumentView"]

    pub --> canvas2["DocumentCanvas（ナビ・ズーム・ダウンロード。矩形なし）"]
    canvas2 --> pagesvg2["PageSvg × ページ"]

    subgraph docview["DocumentView（phase で切替）"]
        picker["DocumentPicker（全 phase。開閉は vm.picker.open）"]
        empty["空状態（empty / registering）"]
        reg["DocumentRegisterForm"]
        canvas["DocumentCanvas（ready）"]
        pagesvg["PageSvg × ページ（画像 + 読取矩形）"]
        work["WorkPanel（ready）"]
        editor["ResultEditor（読取結果タブ）"]
        keyfields["KeyFieldList（キー項目の行）"]
        table["ResultTable（表 1 件）"]
        history["実行履歴タブ"]
        urls["ViewUrlPanel（閲覧 URL タブ）"]
        picker --> reg
        canvas --> pagesvg
        work --> editor
        editor --> keyfields
        editor --> table
        work --> history
        work --> urls
    end

    subgraph mediator["mediator/（ステートマシン）"]
        machine["machine.ts（state・遷移表・dispatch）"]
        model["model.ts（Model・draft 純関数）"]
        vm["vm.ts（ViewModel のスライス）"]
        events["events.ts（イベント型）"]
        bubble["bubble.ts（useBubble・BUBBLE）"]
        handlers["handlers/ auth・public・document・runs・viewUrls"]
    end
    root -- "vm を prop で下へ" --> docview
    docview -. "bubble(event) で上へ" .-> root
    root -- "dispatch" --> machine
    machine --> handlers
    handlers --> model
    model --> vm
    handlers --> client["api/client.ts（openapi-fetch、Bearer 付与）"]
    handlers --> oidc["auth/oidc.ts（oidc-client-ts ラッパ）"]
```

ルーティングライブラリは使わない。`Root.vue`はマウント時に`init`（`pathname` / `search`）をMediatorへdispatchし、Mediatorはパスに応じて次のように分岐する。

| パス | 分岐先 |
| --- | --- |
| `/view/{token}` | 公開閲覧。トークンが空ならログイン画面 |
| `/callback` | OIDCコールバック |
| その他 | ログイン画面 |

コールバック後は、復元されたURLに`?document_id=`があれば、その文書を開く。起動処理中とコールバック処理中（状態`booting` / `callback`）は、`vm.screen`が`loading`になる。このときはロゴだけのアプリバーとスピナーを出し、ログインカードは出さない。

Passive Viewとして、各コンポーネントは自分用のViewModel型1つを`vm` propで受け取る。`Root → DocumentView → WorkPanel → ResultEditor`のように、親がViewModelの部分を子へ渡す。操作は`useBubble()`の`bubble(event)`で上へ伝える。描画だけに関わる状態（ズーム・スクロール位置・区分の開閉・送信前のフォーム入力値）はViewが持つ。API呼出・blob URL・clipboard・`history`・`window`イベントは、Viewが持たない。

Chain of Responsibilityとして、`useBubble(handle?)`は`provide/inject`で直近祖先の`bubble`を受け取る。自ノードで処理しないイベントは親へ委譲する。鎖の終点は`Root`で、Mediatorの`dispatch`をprovideする。鎖はVueのコンポーネントの親子関係で解決するため、`v-dialog`などのTeleport越しでも切れない。

Mediator（`mediator/`）は、12状態（`booting / login / callback / public / empty / registering / loadingDocument / documentError / document / executing / saving / confirmDiscard`）のステートマシンである。遷移表はイベント型を主キーとし、`{ in: State[], run }`を持つ。`in`に現状態が無いイベントは、何もせずに捨てる。イベントを受けるか捨てるかのこの判定を、裁定と呼ぶ。

API応答とOIDCの完了は、Mediatorが内部完了イベント（`documentLoaded` / `runCreated`等）として自分へdispatchする。確認ダイアログを出している`confirmDiscard`の間も、完了イベントは受ける（`SETTLING`）。スコープ（`documentId` / `token` / `runId`）が一致しない応答は、古い応答として捨てる。ページ画像と原本DLの失敗では、同じ文書の開き直しも区別する。モデル（`model.ts`）はreactiveで、`vm.ts`がスライスごとの`computed`でViewModelを組む。

`handlers/`と`utils/`のファイルは次のとおり。

| ディレクトリ | ファイル | 内容 |
| --- | --- | --- |
| `handlers/` | `auth.ts` | 起動・ログイン・コールバック・ログアウト |
| `handlers/` | `public.ts` | 公開閲覧のページ取得。認証済みと共用のページ画像・原本DL |
| `handlers/` | `document.ts` | 文書の取得・登録・切替、文書選択ダイアログの開閉 |
| `handlers/` | `runs.ts` | 実行履歴・IDP実行・下書き・確定・未保存ガード・相互ハイライト |
| `handlers/` | `viewUrls.ts` | 閲覧URL |
| `utils/` | `runs.ts` | 実行結果の型付け、読取矩形`overlayRectsByPage`、ハイライトID、`cellKey` / `originalValue` / `cellAt` |
| `utils/` | `zoom.ts` | フィット倍率 |
| `utils/` | `normalize.ts` | 正規化ヒント |
| `utils/` | `download.ts` | `Content-Disposition`からのファイル名 |
| `utils/` | `format.ts` | 確信度・日時の表示用フォーマッタ |
| `utils/` | `motion.ts` | reduced-motion対応 |
| `utils/` | `fieldStatus.ts` | キー項目の状態表示の判定、確信度の閾値`LOW_CONFIDENCE` |
| `utils/` | `table.ts` | 表の描画用の純関数（列幅・空行の塊・数値セルの判定） |
| `utils/` | `spinnerClock.ts` | スピナーの遅延表示の判定 |

API型は、OpenAPIから生成した`api/schema.d.ts`を単一情報源とする。`npm run generate:api`で再生成し、ドリフトはpre-commitで検出する。`api/client.ts`は同一オリジンを前提に、Bearerを付ける。トークンはMediatorが`setAccessToken`で渡し、`api/client.ts`がメモリ上に保持する。

ビルド成果物は、`api/Containerfile`のマルチステージでAPIイメージの`static/`に同梱する。OIDCのauthorityとクライアントIDは、ビルド時に焼き込む。ローカルではVite devサーバとプロキシを使い、`/api`と`/view/{token}/pages|pdf`を8000番へ転送する。

`index.html`は、Vueの起動前に出す起動スプラッシュを含む。ビルドではCSSの`<link>`を`</body>`の直前へ移す（`vite.config.ts`）。CSSの到着前にスプラッシュを描くためである（[viewer/display.md](../viewer/display.md)の「読込中の表示」）。カスケードレイヤーの順は、stylesheetの並びに左右されないよう、`index.html`のheadの最初の`<style>`で全レイヤーを宣言して固定する。APIは応答をgzipで圧縮して返す（[api.md](api.md)）。

## 主要処理の流れ

### 文書表示

1. 文書IDの入力口は、文書選択ダイアログ`DocumentPicker`だけである。ダイアログには「文書を登録」と「文書IDで参照」のタブがある。開閉の状態はMediatorの`documentPickerOpen`が持つ。Viewは、アプリバーの文書タイトル・「文書を開く」・空状態のボタンで`openDocumentPicker`を、閉じるボタンとEscで`closeDocumentPicker`をbubbleする。Mediatorが開閉を受けるのは`empty` / `document` / `documentError`の間だけで、`registering`中は閉じない。開くたびに登録のエラーを消し、書類種別の一覧が空なら取得する。ダイアログを開けるかどうかは、`vm.header.pickable`でViewへ渡す。開けない間、Viewは文書タイトルを押せない表示にする。ログイン直後に`document_id`が無ければ、`callbackDone`が`openDocumentPicker`をdispatchする。参照では`openDocument{documentId}`をbubbleする。ダイアログは、読込の開始（`loadDocument`）で閉じる。
2. Mediatorは、`document`状態で未保存の変更があれば`confirmDiscard`に遷移し、確認を挟む。それ以外は`loadingDocument`に遷移し、`GET /api/v1/documents/{id}`・`GET .../pages`・`GET /api/v1/config/document-types`を並行して取得する。

   `documentLoaded`では、文書メタデータの原本ファイル名（`original_filename`）をモデルへ反映する。原本ファイル名はヘッダの文書タイトルに使う。あわせて文書種別設定の表示名・`shareable`・`fieldDefs`を反映し、`document`状態へ移る。

   設定の取得に失敗したときや、該当する設定が無いときは、種別コードを表示名にする。この場合は`shareable=false`とし、全項目を表示したまま続ける。文書メタデータかページ寸法の取得に失敗したときは`documentError`になり、再試行できる。
3. `DocumentCanvas`は、ページ寸法（インチ）から`PageSvg`を並べる。各ページは表示領域に入ったときに`pageVisible{page}`をbubbleする。Mediatorは`GET .../pages/{page}/image`を取得し、blob URLを`vm.canvas.images`に入れる。取得済みと取得中のページは再要求しない。blob URLは、文書を切り替えたときに一括でrevokeする。取得に失敗したページは`vm.canvas.imageFailed`に記録し、`PageSvg`が紙面に失敗を表示する。この記録は文書の切替で消す。

   読取矩形は、選択中の成功実行の`fields[key].region` / `tables[].cells[].polygon`から、Viewが外接矩形を描く（`utils/runs.ts`）。どちらも`verbose=true`で取得する値である。キー項目は`visible=false`のものと値なしのものを除く。テーブルセルは、`polygon`と`page_number`を持つものをすべて描く。

   原本DLは`downloadOriginal`で、`GET .../pdf`を呼ぶ。応答を待つ間は、ボタンを読込中の表示にし（`vm.canvas.downloading`）、重ねて届いた`downloadOriginal`は捨てる。失敗したときは、表示中の文書と未保存の修正をそのまま残し、スナックバー「ダウンロードできませんでした」を出す（`vm.canvas.downloadFailed`）。座標系とズームは[viewer/display.md](../viewer/display.md)を参照。
4. `document`状態に入ると、`WorkPanel`が現れる。Mediatorは`GET .../idp-runs`でサマリ一覧を昇順で取り、反転して降順で保持する。先頭はAPI応答の末尾にあたる最新の実行で、失敗実行でも対象にする。Mediatorは先頭の実行を`GET .../idp-runs/{run_id}`（`verbose=true`）で取得し、読取結果タブに出す。一覧を取得できなかったときは、`runsLoadFailed`を立ててエラーを表示する。`WorkPanel`はこのフラグで「実行0件」と区別し、IDP実行の強調と空状態の案内を出さない。
5. 新規登録では、`DocumentRegisterForm`が`register{documentId, documentType, file}`をbubbleする。Mediatorは`empty` / `document` / `documentError`で受け、`document`で未保存の変更があれば`confirmDiscard`を挟む。表示中の文書は送信の時点で閉じ（`clearDocument`）、`registering`状態で`POST /api/v1/documents`をmultipartで呼ぶ。送信前に出した要求の応答は、スコープと状態の判定で捨てる。登録後はその文書を開く。失敗すると`empty`に戻り、ダイアログは開いたままエラーを出す。

### IDP実行と修正の確定

1. [IDP実行]で`executeIdp`をbubbleする。未保存の変更があれば`confirmDiscard`になる。無ければ`executing`状態で`POST .../idp-runs`（`verbose=true`）を呼ぶ。`runCreated`では応答をそのまま選択状態にし、履歴の先頭へ追加して`document`へ戻る。このとき再取得はしない。`executing`中の再実行・履歴選択・文書切替は遷移表に無いため、無視される。応答の受信時に`pendingRunId`を更新し、遅れて届いた古い詳細取得の応答は捨てる。
2. `ResultEditor`への入力では、`fieldInput{key, value}` / `cellInput{table, row, column, value}`をbubbleする。キー項目は`KeyFieldList`が、セルは`ResultTable`がbubbleする。Mediatorは元値との差分だけを、モデルのdraftに記録する（`model.ts`の純関数）。number / date型では、Viewが正規化ヒントを出す。ヒントはサーバと同じ規則で、`utils/normalize.ts`が作る。
3. [確定]は、読取結果タブで成功実行を選択中のときだけ表示し、変更が1件以上のときだけ有効になる。[確定]を押すと`confirmCorrections`をbubbleし、`saving`状態で`POST .../idp-runs/{run_id}/corrections`（`verbose=true`）に差分（`{fields, table_cells}`）を送る。`saved`では応答の`corrected`行を選択状態にし、履歴の先頭へ追加する。あわせて下書きをリセットし、スナックバーを出す。[破棄]（`discardDraft`）は下書きをリセットするだけ。
4. 未保存の変更があるまま、履歴選択・IDP実行・文書選択ダイアログからの参照と登録をすると、`confirmDiscard`状態になる。保留した操作を持ったまま、確認ダイアログを出す。タブ切替は対象外。`confirmProceed`では下書きを捨て、保留した操作を再dispatchする。`confirmCancel`では操作だけを捨てる。ブラウザから離脱するときは、`Root`が`beforeunload`の標準警告を出す（`vm.dirty`）。

読取結果タブは、キー項目（Query Fields）・候補値（正規表現の一致値）・表（テーブル領域）の3区分で表示する。各区分の表示・修正済みマーク・アクセシビリティの詳細は、[viewer/result-panel.md](../viewer/result-panel.md)に記す。

### 相互ハイライト

入力欄にフォーカスすると、`targetFocus{id}`をbubbleする。Mediatorは`activeId`を設定し、キャンバスへの連番付き要求（`vm.canvas.scrollRequest`）を出す。これを受けて、`DocumentCanvas`が該当矩形を表示範囲へスクロールする。

矩形をクリックすると、`rectClick{id}`をbubbleする。Enter / Spaceでも同じ。Mediatorは`activeId`を設定して読取結果タブへ切り替え、ペインへの連番付き要求（`vm.editor.focusRequest`）を出す。これを受けて、`ResultEditor`が該当区分を展開し、入力欄へスクロールしてフォーカスする。畳まれた空行のセルが対象のときは、`ResultTable`が先に空行の塊を展開する。

IDの形式は`field:{key}` / `cell:{table}:{row}:{col}`。`activeId`の選択は、履歴選択・IDP実行・確定で解除する。

### 閲覧URLの管理（`ViewUrlPanel`）

タブは、文書種別が`shareable`のときだけ出す。タブを開いたときの`tabChanged{tab: 'urls'}`で、`GET .../view-urls`を取得する。取得は文書ごとに初回だけ行う。一覧には発行日時・期限・状態を表示する。状態は有効 / 期限切れ / 失効済みのいずれかで、期限の判定はViewがクライアント時刻で行う。

発行では`issueViewUrl`で`POST .../view-urls`を呼ぶ。応答の`view_path`に自オリジンを付けて完全URLを表示し、`copyIssuedUrl`でMediatorがクリップボードへ書く。平文は再表示できない。発行後は一覧を再取得する。

失効では、行の[失効させる]ボタン（`revokeViewUrl{viewUrlId}`）で確認ダイアログを出す。`confirmRevoke`で`POST /api/v1/view-urls/{view_url_id}/revoke`を呼ぶ。一括失効は画面から呼ばない。

### 公開閲覧（`PublicView`）

`init`で`/view/{token}`を検出すると`public`状態になり、`GET /view/{token}/pages`でページ寸法を取る。ページ寸法の取得中はスピナーを出す（[viewer/display.md](../viewer/display.md)の「読込中の表示」）。`DocumentCanvas`は右ペインなしの全幅で表示し、ページナビ・ズーム・フィットは認証済み表示と同じ。`vm.canvas.run`がnullのため、読取矩形は出ない。`PageSvg`は表示領域に入ったページの`pageVisible`をbubbleし、Mediatorが`GET /view/{token}/pages/{page}/image`で取得する。この取得がページ単位の閲覧イベントを記録する契機になるため、公開閲覧でも表示領域に入ったページだけを取得する（[ADR-0015](../adr/0015-page-view-event.md)）。

ツールバーの[ダウンロード]は、`GET /view/{token}/pdf`をblobとして受け、`Content-Disposition`のファイル名で保存する。ファイル名が無ければ`document.pdf`で保存する。ボタンの表示名は`vm.canvas.downloadLabel`で、認証済み表示では「原本ダウンロード」になる。

ページ一覧の取得に失敗したときは、「この閲覧URLは無効です」を`DocumentView`と同じエラーstate（アイコンとメッセージ。再試行なし）で表示し、本文を消す（[view-url.md](view-url.md)）。ダウンロードに失敗したときは、本文を残したまま、認証済み表示と同じスナックバー「ダウンロードできませんでした」を出す。

## 外部依存・設定

ビルド時の環境変数は次のとおり。

| 設定 | 既定値 |
| --- | --- |
| `VITE_OIDC_AUTHORITY` | `http://localhost:8080/realms/factone` |
| `VITE_OIDC_CLIENT_ID` | `factone-viewer` |

外部依存はAPIとKeycloakである。APIは同一オリジンで、ローカルではViteプロキシを通す。KeycloakとはOIDCのリダイレクトでやり取りする。

主要ライブラリはVue 3・Vuetify・oidc-client-ts・openapi-fetch・Phosphor Icons・Fontsource（IBM Plex）。テストにはVitestとVue Test Utilsを使う。

## 関連ドキュメント

| 参照先 | 内容 |
| --- | --- |
| [viewer/display.md](../viewer/display.md) | ページ画像とSVGオーバーレイ、座標系、ズーム、遅延読込 |
| [viewer/result-panel.md](../viewer/result-panel.md) | 右ペイン、修正の下書きと確定、相互ハイライト、アクセシビリティ |
| [viewer/README.md（リポジトリ）](../../viewer/README.md) | ディレクトリ構成と配置指針 |
| [develop-guide/viewer.md](../develop-guide/viewer.md) | 起動・テスト・ビルド |
| [requirements/viewer.md](../requirements/viewer.md) | 機能要件VW-xx |

関連するADRは、[ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)、[ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md)、[ADR-0010](../adr/0010-blob-access-full-api-proxy.md)、[ADR-0023](../adr/0023-viewer-root-passive-view-mediator.md)、[ADR-0024](../adr/0024-viewer-typography-contrast-baseline.md)。
