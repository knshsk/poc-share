---
status: accepted
date: 2026-09-13
---

# Document Intelligenceの生応答をBlobにバイト保存する

## 背景

IDP実行ログ（`idp_runs`）は、Query Fieldsの項目値・確信度・テーブル領域・正規表現一致のみをJSONBで保持していた。DI応答のそれ以外の情報（words / lines / paragraphs / 座標等）は捨てていた。今後は、`tables` / `fields`以外を使う機能（座標を使った照合支援など）と、人手修正結果を教師データにしたカスタムモデル学習が見込まれる。そのため、応答を欠落なく残す必要がある。DIのAPIバージョンが変わる可能性もあり、どの版の応答かも残す必要がある。

## 決定

保存する対象は、DIの最終ポーリングGETの応答本文である。これは`status` / `createdDateTime` / `lastUpdatedDateTime` / `analyzeResult`を含む、ラッパ込みのJSONである。SDKの`cls`コールバックでbytesのまま受け取り、Blobの`{tenant_id}/{document_id}/idp-runs/{run_id}.json`に無変換で保存する。

`idp_runs`には、参照パス（`raw_response_ref`）を列として持つ。あわせて`analyzeResult.apiVersion`と`modelId`を、それぞれ`di_api_version`と`di_model_id`の列として持つ。

生応答は、`GET /api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response`がBlobから素通しで返す。Blobの全面非公開とAPIプロキシ方式は、ADR-0010のままとする。

保存順序は、DI成功 → Blob保存 → 実行ログINSERTとする。Blob保存に失敗した場合は500を返し、実行ログを残さない。

## 検討した代替案

| 案 | 却下理由 |
| --- | --- |
| `idp_runs`のJSONB列に保存 | 1実行あたり数百KB〜数MBで、DBが肥大する。JSONBはキー順序・空白を保持せず、「応答のまま」にならない。学習データとして使う際に、Blobへの再配置が必要になる |
| SDKの`AnalyzeResult.as_dict()`を再シリアライズして保存 | ラッパ（`status` / 処理時刻）が落ち、将来のトップレベル項目の追加に追随できない。バイト一致も保証されない |
| 保存しない（必要になったら再実行） | DIの呼出コストが二重になる。修正時点の応答と一致する保証がなく、学習データに使えない |

## 影響

Blobの容量は、実行回数に比例して増える。PoCのデータ保持方針（機能検証に必要な期間のみ）の範囲では問題にならない。

保存した応答はDI Studioの`.ocr.json`と同形のため、カスタムモデルを学習する時はPDFと併せてコピーするだけで使える。

応答の構造はDIのAPIバージョンに依存する。`di_api_version`を見て解釈すること。
