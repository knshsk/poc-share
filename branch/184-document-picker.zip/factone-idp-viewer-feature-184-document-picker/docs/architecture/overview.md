# IDP/Viewer全体像

## IDP/Viewerとは

マルチテナントSaaSで、PDF文書を登録し、抽出エンジンで項目を読み取って人手で修正する。文書は閲覧URLで外部の閲覧者に公開し、閲覧の記録を外部連携システムへ返す。

IDPはIntelligent Document Processing（文書からの項目抽出）の略。認証基盤を指すIdP（Identity Provider）とは別物である。Viewer（画面）とIDP（API）は同一システムの2つの提供形態で、Viewerの「IDP実行」も同じAPIを呼ぶ。テナントの業務キー（案件IDなど）は受領・保持せず、呼出側からは文書IDだけを受け取る。

本PoCでのテナントの利用形態・業務フロー・対象外事項は、[business/](../business/README.md)と[requirements/](../requirements/README.md)に閉じる。本書以下の設計文書には書かない。

## システム文脈

```mermaid
flowchart LR
    tenantUser(["テナント利用者"])
    integration(["外部連携システム"])
    viewer(["閲覧者"])
    sys["IDP/Viewer"]
    idp["IdP（Keycloak）"]
    engine["抽出エンジン（Azure Document Intelligence）"]

    tenantUser -- "ブラウザで Viewer を操作（JWT を提示）" --> sys
    integration -- "API を呼ぶ（JWT を提示）" --> sys
    viewer -- "閲覧 URL を開く（無認証）" --> sys
    tenantUser -- "OIDC ログイン" --> idp
    integration -- "client credentials（M2M）" --> idp
    sys -- "JWT 検証鍵の取得（JWKS）" --> idp
    sys -- "PDF 解析" --> engine
```

| 主体 | 行うこと |
| --- | --- |
| テナント利用者 | 文書の登録・IDP実行・読取結果の修正・閲覧URLの発行と失効を、画面で行う |
| 外部連携システム | テナント側のシステム。文書登録・IDP実行・読取結果取得・閲覧イベントの差分取得を、APIで行う。図のM2Mは、人を介さないシステム間連携を指す |
| 閲覧者 | テナントの顧客など。閲覧URLだけで文書を閲覧・ダウンロードする |

IdPは、利用者と外部連携システムを認証してJWTを発行する。本システムはJWTの検証だけを行い、ログイン画面や資格情報を持たない（[ADR-0006](../adr/0006-keycloak-as-idp.md)）。

抽出エンジンはPDFの文字化・項目抽出を行う。以下ではDIと略す。DIはアダプタ越しに呼び、生応答は保存する（[ADR-0004](../adr/0004-external-system-boundary-adapters.md)）。アダプタは、差し替え可能な薄い呼出層を指す。

## コンポーネント構成

```mermaid
flowchart TB
    subgraph browser["ブラウザ"]
        spa["Viewer SPA（Vue 3 + Vuetify）"]
    end
    subgraph api["API（FastAPI）"]
        routers["routers: documents / idp-runs / view-urls（公開閲覧を含む）/ document-type-configs"]
        static["SPA 静的配信（catch-all）"]
    end
    pg[("PostgreSQL")]
    blob[("Blob Storage")]
    kc["Keycloak"]
    di["Document Intelligence"]

    spa -- "同一オリジン / Bearer JWT" --> routers
    spa -- "OIDC（Authorization Code + PKCE）" --> kc
    api -- "JWKS" --> kc
    routers --> pg
    routers --> blob
    routers --> di
    static -. "index.html / assets" .-> spa
```

APIはViewerのビルド成果物を同梱して配信する。登録済みのAPIルートが常に優先され、どのルートにも一致しないGETだけがSPAへフォールバックする。`/api/**`は、未知のパスでも404のままとなる（[ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)）。

Blobは全面非公開とする。PDF原本とDI生応答は、APIがBlobから読んで返す。ページ画像は、APIが都度生成して返す。ブラウザはBlobへ直接アクセスしない（[ADR-0010](../adr/0010-blob-access-full-api-proxy.md)）。

外部サービスの呼出口は、Pythonの`typing.Protocol`で定義する。対象の外部サービスはBlob・DI・PDFレンダラ・JWT検証鍵の取得で、アプリファクトリ`create_app`で実装を差し込む。ローカルではファイルBlobと未設定のDIで動き、AzureではManaged IDで接続する。

テナントはJWTのクレーム`tenant_id`で解決する。Keycloakは単一realmである。クレームはSPAではユーザー属性から、M2Mではhardcoded claimで載せる（[auth.md](auth.md)、[ADR-0020](../adr/0020-single-realm-tenant-claim.md)）。

Azure上の配置は[azure/README.md](../azure/README.md)を参照。

## 主要ユースケース

### 文書登録からIDP実行まで

```mermaid
sequenceDiagram
    participant C as 外部連携システム / Viewer SPA
    participant A as API
    participant B as Blob
    participant P as PostgreSQL
    participant D as Document Intelligence

    C->>A: POST /api/v1/documents（PDF, document_id, document_type）
    A->>A: document_id の検査（不正なら 422）、PDF 判定（違えば 415）、文書種別が設定済みか（無ければ 422）
    A->>P: 同じ document_id の既存行を確認（あれば以降を行わず 200 / 409）
    A->>B: {tenant_id}/{document_id}.pdf を保存
    A->>P: documents 行を挿入
    A-->>C: 201（既存行と SHA-256・文書種別が両方一致すれば 200、どちらか違えば 409）
    C->>A: POST /api/v1/documents/{document_id}/idp-runs
    A->>P: 既存実行の有無で initial / rerun を判定、文書種別設定を取得（無ければ 409）
    A->>B: PDF を取得
    A->>D: 解析（prebuilt-layout + Query Fields）
    D-->>A: 生応答
    A->>B: {tenant_id}/{document_id}/idp-runs/{run_id}.json に生応答を保存
    A->>A: 生値 / 正規化値 / 確信度 / 読取領域 / テーブル / パターン一致を組み立て
    A->>P: idp_runs 行を挿入（succeeded）
    A-->>C: 201 読取結果
```

DIが失敗したときは、未設定の場合も含めて`failed`行を残し、502を返す。生応答の保存で例外が出たときは、実行ログを残さずに汎用ハンドラが500を返す。

文書種別ごとの読取項目・型・正規表現パターンは、`document_type_configs`の設定に従う（[ADR-0014](../adr/0014-tenant-document-type-config.md)）。

### 読取結果の人手修正

```mermaid
sequenceDiagram
    participant U as テナント利用者
    participant S as Viewer SPA
    participant A as API
    participant P as PostgreSQL

    S->>A: GET .../idp-runs（サマリ一覧）→ GET .../idp-runs/{run_id}（一覧末尾 = 最新の詳細。失敗実行も含む）
    U->>S: キー項目・テーブルセルの値を編集（下書きは元値との差分のみ保持）
    U->>S: 確定
    S->>A: POST .../idp-runs/{run_id}/corrections（fields, table_cells）
    A->>P: base 行を取得（失敗実行は 409）
    A->>A: base の値に差分を適用（base に無いキー・座標は 422）し、根の機械実行に対する累積差分を計算
    A->>P: corrected 行を追記（修正後の値、base_run_id, corrected_by, corrections。読取領域・生応答参照は base から引き継ぐ）
    A-->>S: 201 修正後の読取結果
    S->>S: 応答を選択状態にし、履歴の先頭へ追加
```

修正は既存行を書き換えず、`corrected`行として追記する。base（修正元）は、機械実行でも過去の`corrected`行でもよい。`corrections`は根の機械実行に対する累積差分なので、修正を重ねても1行で全差分が分かる（[ADR-0018](../adr/0018-corrections-as-appended-idp-runs.md)）。根の機械実行とは、baseを遡った先にある`initial` / `rerun`行を指す。

排他制御はしない。同一baseへの並行修正は、両方とも追記される。これはPoCの制限である。

### 閲覧URLの発行から閲覧イベント記録まで

```mermaid
sequenceDiagram
    participant S as Viewer SPA
    participant A as API
    participant P as PostgreSQL
    participant V as 閲覧者

    S->>A: POST /api/v1/documents/{document_id}/view-urls
    A->>A: 文書種別設定の shareable を確認（設定なし・不可なら 403）
    A->>P: view_tokens 行（トークンの SHA-256 のみ）
    A-->>S: 201 {id, view_path: /view/{token}, expires_at}（平文はこの一度だけ）
    S-->>V: 閲覧 URL を共有（システム外）
    V->>A: GET /view/{token}/pages
    A->>A: IP のレート制限（超過は 429）→ トークン検証（ハッシュ一致・未失効・期限内。不成立は失敗を記録して一律 404）
    A->>P: 配信成功時に view_events へ view を記録
    A-->>V: ページ寸法一覧（SPA が描画）
    V->>A: GET /view/{token}/pages/{page}/image（表示領域に入ったページだけ）
    A->>P: 配信成功時に page_view を記録（page 付き）
    A-->>V: PNG（Cache-Control: no-store）
    V->>A: GET /view/{token}/pdf
    A->>P: download を記録（応答生成の直前）
    A-->>V: 原本 PDF
```

URLには文書IDや業務キーを含めない。トークンは256 bitの乱数で、平文はDBに残さない（[ADR-0011](../adr/0011-view-url-opaque-token.md)）。失敗試行は、トークンの先頭8文字とIPだけを`view_access_failures`に残す。

閲覧者が`/view/{token}`を開くと、APIのcatch-allがViewer SPAを返し、SPAが上記のAPIを呼ぶ。有効期限は発行時に指定でき、既定は90日（`FACTONE_VIEW_URL_DEFAULT_TTL_DAYS`）。レート制限は失敗試行だけを数え、既定はIPごとに60秒で10回（`FACTONE_VIEW_URL_MAX_FAILURES` / `FACTONE_VIEW_URL_FAILURE_WINDOW_SECONDS`）。

`page_view`は、ページ画像の遅延取得を契機に記録する（[ADR-0015](../adr/0015-page-view-event.md)）。イベントは文書（内部ID）・発生日時・種別の組で一意になる。衝突したときは記録を捨て、配信だけを成功させる。テナント利用者自身がViewerで閲覧した分は記録しない（[ADR-0012](../adr/0012-no-internal-view-event-history.md)）。

失効には、1件単位（`POST /api/v1/view-urls/{id}/revoke`）と文書単位の一括（`POST .../view-urls/revoke-all`）がある。詳細は[view-url.md](view-url.md)を参照。

### 外部連携システムによる閲覧イベント差分取得

```mermaid
sequenceDiagram
    participant I as 外部連携システム
    participant K as Keycloak
    participant A as API
    participant P as PostgreSQL

    I->>K: client credentials（factone-integration）
    K-->>I: アクセストークン（aud: factone-api）
    I->>A: GET /api/v1/view-events?since=<前回取得時刻>（Bearer）
    A->>P: テナントの全文書の view_events を occurred_at >= since で取得
    A-->>I: イベント一覧（occurred_at, id の昇順）
```

`since`は境界を含む。境界で重複したイベントは、連携側が冪等キー（文書IDと発生日時）で除く前提とし、取りこぼしゼロを優先する（[ADR-0013](../adr/0013-view-event-delta-feed.md)）。

APIは、トークンを発行したクライアントを区別しない。署名（RS256）・issuer・audience・有効期限が正しいJWTであれば、SPA用とM2M用のどちらでも同じ操作ができる。認可は未実装である。

文書単位の一覧は`GET /api/v1/documents/{document_id}/events`で取得する。

## データの流れと保存先

| データ | 保存先 |
| --- | --- |
| PDF原本 | Blobの`{tenant_id}/{document_id}.pdf`。メタデータ（文書種別・SHA-256・元ファイル名・受領日時）はPostgreSQLの`documents` |
| ページ画像 | 保存しない。要求のたびに、APIがpypdfium2で150 dpiのPNGを生成する |
| DI生応答 | Blobの`{tenant_id}/{document_id}/idp-runs/{run_id}.json`。DBには参照パスだけを持つ（[ADR-0019](../adr/0019-raw-di-response-in-blob.md)） |
| 読取結果と人手修正 | PostgreSQLの`idp_runs`。生値と正規化値を分けて持つ |
| 閲覧トークン | PostgreSQLの`view_tokens`で、ハッシュだけを持つ。失敗試行は`view_access_failures` |
| 閲覧イベント | PostgreSQLの`view_events` |
| 文書種別設定 | PostgreSQLの`document_type_configs`。テナント別に持つ |

実行ログ（`idp_runs`）と閲覧イベント（`view_events`）は追記型で、再実行・修正・再閲覧で過去行を上書きしない（[ADR-0005](../adr/0005-append-only-logs-and-raw-normalized-separation.md)）。テーブル定義は[data-model/](../data-model/README.md)を参照。

## モジュール構成の文書

| 文書 | 内容 |
| --- | --- |
| [api.md](api.md) | APIのレイヤ構成・リソース・IDP実行の内部フロー |
| [viewer.md](viewer.md) | 画面・コンポーネント・状態管理 |
| [auth.md](auth.md) | 認証経路・JWT検証・Keycloak realm |
| [view-url.md](view-url.md) | 閲覧URLのライフサイクル・公開閲覧・イベント |
| [../azure/README.md](../azure/README.md) | Azure構成 |
