# 閲覧URLトークン（view_tokens / view_access_failures）

顧客向け見積閲覧URLのトークン管理。「不透明ランダムトークン+DB管理」方式の実装仕様。

## view_tokens

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 管理ID。失効操作に使い、トークンとは無関係 |
| token_hash | varchar(64) | NOT NULL・UNIQUE | トークンのSHA-256ハッシュ。**平文は保存しない**。平文は発行応答で一度だけ返す |
| document_pk | uuid | NOT NULL・FK(documents.id) | 対象文書（内部ID） |
| issued_at | timestamptz | NOT NULL・default now() | 発行日時 |
| expires_at | timestamptz | NOT NULL | 有効期限。発行時に必ず値を入れ、発行リクエストで期限を指定しなければ発行から既定の90日後とする。既定値は設定値で、業務要件確定までの仮置き |
| revoked | bool | NOT NULL | 失効フラグ。発行時はSQLAlchemyの`default=False`がfalseを入れ、DB側の既定値（`server_default`）は無い。即時失効はこの行の更新だけで行う |

トークンは256bitのURL-safe乱数（`secrets.token_urlsafe(32)`）。URL形式は`/view/{token}`で、文書IDと案件IDを含めない。

検証条件は、ハッシュ一致かつ未失効かつ期限内であること。いずれかが欠けても、存在を推測されないよう応答は一律404にする。

発行できるのは共有可の文書種別のみで、`document_type_configs.shareable`で判定する（ADR-0014）。ADR-0002の判断は、シードのデフォルト値として引き継いでいる。

## view_access_failures

| 列 | 型 | 説明 |
| --- | --- | --- |
| id | uuid | PK |
| token_fragment | varchar(8) | 試行トークンの先頭8文字のみ。全体は記録しない |
| client_ip | varchar(64) | 試行元IP |
| occurred_at | timestamptz | 発生日時 |

総当りを検知するための失敗試行記録。あわせて、IP単位のスライディング窓によるレート制限をインメモリで行う。既定では、直近60秒に10回失敗すると429を返す。PoCの単一インスタンスを前提としており、スケールアウト時は外部化が必要。

## 世代管理

発行レコードが、そのまま世代管理台帳になる。1文書に複数のトークンを発行できる。見積改訂履歴の扱いが確定した後に拡張する。
