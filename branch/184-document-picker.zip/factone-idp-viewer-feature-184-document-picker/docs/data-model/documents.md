# 文書メタデータ（documents）

文書取込の中核テーブル。SaaS内部の主参照キーは文書IDであり、案件ID・ルートIDは保持しない。業務キーと文書キーを分離する決定に基づく。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 内部ID（サーバ採番）。子テーブルの外部キーはこの列を参照する（ADR-0021） |
| document_id | varchar(255) | NOT NULL・UNIQUE(tenant_id, document_id) | 文書ID。呼出側が採番し、SaaS内では採番・解決しない。テナント内でのみ一意 |
| tenant_id | varchar(255) | NOT NULL | テナント識別子。JWTの`tenant_id`クレーム（ADR-0020） |
| document_type | varchar(50) | NOT NULL | 文書種別コード。テナント設定（document_type_configs）に登録済みの値のみ受け付ける。検証はアプリ層で行う |
| blob_ref | varchar(1024) | NOT NULL | Blob格納パス（`{tenant_id}/{document_id}.pdf`） |
| content_sha256 | varchar(64) | NOT NULL | ファイル内容のSHA-256。冪等判定に使う |
| original_filename | varchar(255) | NULL可 | 原本ファイル名（basename）。詳細は表の下 |
| received_at | timestamptz | NOT NULL | 受領日時（初回登録時にサーバで記録） |
| created_at | timestamptz | NOT NULL・default now() | 行作成日時 |

`original_filename`は、登録時の`original_filename`フィールドから取り、無ければmultipartの`filename`から取る。フィールドを優先するのは、Power Automateが`filename`の非ASCIIを`?`に置き換えて送るため（ADR-0025）。原本DLの`Content-Disposition`に使う。値がNULLのときは、DL時に`{document_id}.pdf`にフォールバックする。文書メタデータの応答（`DocumentResponse.original_filename`）にも出し、Viewerのヘッダで文書タイトルに使う。NULLのときは文書IDを表示する。

## 文書種別（document_type）

種別は、テナント別設定テーブル`document_type_configs`で管理する（[document-type-configs.md](document-type-configs.md)・ADR-0014）。enumとCHECK制約は使わない。登録時の検証はアプリ層で行い、テナント設定に未登録の種別は422で拒否する。種別の追加は設定CRUD API（`POST /api/v1/config/document-types`）で行い、コード変更やマイグレーションは要らない。

**単一テーブルに種別列を持たせる形は仮置き**である。統合モデルの採否が未確定のためで、種別固有の属性が必要になった時点で見直す。

## 冪等性

登録API（`POST /api/v1/documents`）は、条件に応じて次のように応答する。

| 条件 | 応答 |
| --- | --- |
| 新規の文書ID | 201。Blobを保存し、行をINSERTする |
| 同一テナント・同一文書ID・同一内容（sha256・種別が一致） | 200。冪等な再送として扱い、何も変更しない |
| 同一テナント・同一文書ID・内容が不一致 | 409。事故として検出し、上書きしない |
| 別テナントの同一文書ID | 201。テナント間で独立して扱う |

## マイグレーション

Alembic（`api/migrations/`）を正とする。適用は`uv run alembic upgrade head`で行う。テストも同じマイグレーションでスキーマを構築する。
