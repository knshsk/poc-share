# API設計ドキュメント

API（FastAPI）に関する設計ドキュメントを格納するディレクトリ。

OpenAPIスキーマのエクスポートもここに置く。外部連携システム向けの公開契約はここに固定し、レビュー・共有する。API契約の型共有ではPydanticモデルを単一情報源とし、OpenAPI経由でTypeScript型を生成する。

## バージョニング（ADR-0017）

認証ありAPIは`/api/v1/**`に配置する。バージョンはURLパスで表す。

版を付与する対象は`/api/**`のみ。顧客向け閲覧URL`/view/{token}/**`とヘルスチェック`/health`は無版である。版はメジャーのみ（`v1`, `v2`）とし、破壊的変更を行うときに限り上げる。

破壊的変更に当たるのは、レスポンスのフィールド削除・改名・型変更・意味変更、リクエストの必須化、エンドポイントの削除・パス変更である。一方、フィールド・エンドポイント・エラーcode・任意パラメータの追加は追加的変更として、同一版内で行う。

破壊的変更時は`/api/v2/**`を並行公開し、`/api/v1/**`の廃止期限をこの節に明記する。ただし、外部連携システムが未接続の間は、v1内での破壊的変更を許容する（ADR-0017追記）。

現在の版は`v1`で、廃止予定はない。

## エラー応答（RFC 9457 Problem Details）

全エラー応答は`Content-Type: application/problem+json`で、以下の本文を返す（ADR-0016）。

```json
{
  "type": "/errors/document-not-found",
  "title": "Document not found",
  "status": 404,
  "detail": "Document not found"
}
```

| メンバ | 内容 |
| --- | --- |
| `type` | `/errors/<code>`形式の相対URI。エラー種別の判別にはこの値を使う |
| `title` | エラー種別の短い説明。codeから導出する |
| `status` | HTTPステータスコード |
| `detail` | 発生箇所の説明文 |
| `errors` | 付くのは422 `validation-error`のみ。`loc` / `msg` / `type`の配列 |

### エラーコード一覧

| status | type | 発生条件 |
|---|---|---|
| 401 | `/errors/unauthenticated` | Authorizationヘッダが無いか、`Bearer <トークン>`の形でない |
| 401 | `/errors/invalid-token` | トークン検証失敗 |
| 403 | `/errors/tenant-unresolved` | トークンは正当だが、`tenant_id`クレームが欠落しているか、形式`^[a-z0-9][a-z0-9-]{0,62}$`に合わない |
| 403 | `/errors/view-url-not-allowed` | 共有不可の文書種別に閲覧URLを発行 |
| 404 | `/errors/document-not-found` | 文書が存在しない。他テナントの文書も含む |
| 404 | `/errors/page-not-found` | ページ番号が範囲外 |
| 404 | `/errors/document-type-not-found` | 文書種別設定が存在しない |
| 404 | `/errors/idp-run-not-found` | IDP実行結果が存在しない。他文書のrun_idを指定した場合も含む |
| 404 | `/errors/raw-response-not-found` | 生応答が保存されていない実行結果（失敗実行） |
| 404 | `/errors/view-url-not-found` | 失効操作で指定した閲覧URLが存在しない。他テナントの管理IDを指定した場合も含む |
| 404 | `/errors/not-found` | 閲覧トークンが無効、または未知のAPIパス。トークンの不存在・期限切れ・失効のどれに当たるかは秘匿する |
| 409 | `/errors/document-conflict` | 同一文書IDで内容が異なる再登録 |
| 409 | `/errors/document-type-not-configured` | IDP実行対象の文書種別が未設定 |
| 409 | `/errors/document-type-exists` | 文書種別の重複作成 |
| 409 | `/errors/document-type-in-use` | 使用中の文書種別の削除 |
| 409 | `/errors/idp-run-not-correctable` | 失敗した実行結果（`status=failed`）に修正を要求 |
| 415 | `/errors/unsupported-media-type` | PDF以外のファイル |
| 422 | `/errors/validation-error` | リクエスト検証エラーで、`errors`が付く。文書登録の`document_id`が`/` `\`を含む場合と、`.` `..`そのものの場合も同じtypeになるが、`errors`は付かない |
| 422 | `/errors/unknown-document-type` | 文書登録時の文書種別がテナントに設定されていない |
| 422 | `/errors/unknown-correction-target` | 修正対象のキー・セル座標が、baseの実行結果に存在しない |
| 429 | `/errors/too-many-requests` | 閲覧トークンの失敗が連続したことによるレート制限 |
| 500 | `/errors/pdf-processing-failed` | PDF処理失敗 |
| 500 | `/errors/internal-error` | 未捕捉の内部エラー |
| 502 | `/errors/document-analysis-failed` | Document Intelligenceの呼出失敗 |

上表にない`type`は、FastAPI/Starletteが内部で送出するエラー（例: 405）のものである。値はHTTPステータス句をケバブケースにしたもの（例: `/errors/method-not-allowed`）になる。

422の例を次に示す。

```json
{
  "type": "/errors/validation-error",
  "title": "Validation error",
  "status": 422,
  "detail": "Request validation failed",
  "errors": [
    {"loc": ["path", "page"], "msg": "Input should be a valid integer, unable to parse string as an integer", "type": "int_parsing"}
  ]
}
```
