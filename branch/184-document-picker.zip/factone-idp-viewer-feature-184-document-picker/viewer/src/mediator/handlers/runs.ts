import { apiClient } from '../../api/client'
import { cellAt, cellKey, originalValue, type IdpRun } from '../../utils/runs'
// machine.ts と循環 import。guardDirty は関数宣言で run() 内からだけ呼ぶため安全（const 化しない）
import { guardDirty, type Ctx, type Handlers } from '../machine'
import {
  draftCount,
  resetDraft,
  setCell,
  setField,
  SETTLING,
  toCorrections,
  WORKING,
  type Model,
} from '../model'
import { loadViewUrls } from './viewUrls'

// IDP 実行・確定の応答は詳細と同形。そのままキャッシュして選択状態にし、読取結果タブへ。
// pendingRunId を更新するので、それ以前に要求した詳細取得の応答が遅れて届いても捨てられる
function showRun(model: Model, run: IdpRun): void {
  // 選択はフォーカスが外れても維持する（照合のため）。履歴選択・IDP 実行・確定で解除する
  model.activeId = null
  model.details.set(run.run_id, run)
  model.selectedRun = run
  model.pendingRunId = run.run_id
  model.activeTab = 'result'
}

// 履歴は一覧 API（サマリ）を取り、応答後に反転して実行日時降順で保持する
export function loadRuns(ctx: Ctx): void {
  const m = ctx.model
  const documentId = m.documentId
  m.errors.workPanel = null
  m.runsLoadFailed = false
  m.runsLoading = true
  void apiClient
    .GET('/api/v1/documents/{document_id}/idp-runs', {
      params: { path: { document_id: documentId } },
    })
    .then(
      ({ data, error }) =>
        ctx.dispatch(
          error || !data
            ? { type: 'runsFailed', documentId }
            : { type: 'runsLoaded', documentId, runs: data.runs },
        ),
      () => ctx.dispatch({ type: 'runsFailed', documentId }),
    )
}

// 詳細は Viewer 向け付加情報（label / region / polygon / corrections）込みで取る
function fetchDetail(ctx: Ctx, runId: string): void {
  void apiClient
    .GET('/api/v1/documents/{document_id}/idp-runs/{run_id}', {
      params: {
        path: { document_id: ctx.model.documentId, run_id: runId },
        query: { verbose: true },
      },
    })
    .then(
      ({ data, error }) =>
        ctx.dispatch(
          error || !data
            ? { type: 'runDetailFailed', runId }
            : { type: 'runDetailLoaded', runId, run: data },
        ),
      () => ctx.dispatch({ type: 'runDetailFailed', runId }),
    )
}

// 一覧には項目値・テーブルが無いため run_id ごとに詳細を取る。行は不変なのでキャッシュする
function selectRunById(ctx: Ctx, runId: string): void {
  const m = ctx.model
  m.activeId = null
  m.activeTab = 'result'
  m.errors.workPanel = null
  m.pendingRunId = runId
  const cached = m.details.get(runId)
  if (cached) {
    m.selectedRun = cached
    return
  }
  fetchDetail(ctx, runId)
}

export const runHandlers: Handlers = {
  runsLoaded: {
    in: SETTLING,
    run(ctx, e) {
      const m = ctx.model
      if (e.documentId !== m.documentId) return
      m.runsLoading = false
      m.runsLoadFailed = false
      // 一覧取得中に IDP 実行・確定が完了した場合（showRun が pendingRunId を設定済み）、
      // その選択・表示済みの実行を一覧の書き戻しで消さない。一覧はその実行を先頭に残しマージする
      if (m.pendingRunId !== null) {
        const listIds = new Set(e.runs.map((r) => r.run_id))
        m.runs = [
          ...m.runs.filter((r) => !listIds.has(r.run_id)),
          ...[...e.runs].reverse(),
        ]
        return
      }
      m.runs = [...e.runs].reverse()
      const latest = m.runs[0]
      if (latest) selectRunById(ctx, latest.run_id)
    },
  },
  runsFailed: {
    in: SETTLING,
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.runsLoading = false
      ctx.model.runsLoadFailed = true
      ctx.model.errors.workPanel = '実行履歴を取得できませんでした'
    },
  },
  // 未保存の変更がある履歴選択は、先に読取結果タブへ戻してから確認ダイアログを出す
  // （ダイアログ表示中も直前の結果とアクションバーが見えた状態を保つ）
  selectRun: {
    in: ['document'],
    run(ctx, e) {
      ctx.model.activeTab = 'result'
      if (guardDirty(ctx, e)) return
      selectRunById(ctx, e.runId)
    },
  },
  runDetailLoaded: {
    in: SETTLING,
    run(ctx, e) {
      const m = ctx.model
      // 応答待ちの間に別の実行が選択された場合は古い応答を捨てる（後勝ちの誤表示防止）
      if (m.pendingRunId !== e.runId) return
      m.details.set(e.runId, e.run)
      m.selectedRun = e.run
    },
  },
  runDetailFailed: {
    in: SETTLING,
    run(ctx, e) {
      if (ctx.model.pendingRunId !== e.runId) return
      ctx.model.errors.workPanel = '実行結果を取得できませんでした'
    },
  },
  executeIdp: {
    in: ['document'],
    run(ctx, e) {
      if (guardDirty(ctx, e)) return
      const m = ctx.model
      m.errors.workPanel = null
      ctx.state.value = 'executing'
      void apiClient
        .POST('/api/v1/documents/{document_id}/idp-runs', {
          params: {
            path: { document_id: m.documentId },
            query: { verbose: true },
          },
        })
        .then(
          ({ data, error }) =>
            ctx.dispatch(
              error || !data
                ? { type: 'runFailed' }
                : { type: 'runCreated', run: data },
            ),
          () => ctx.dispatch({ type: 'runFailed' }),
        )
    },
  },
  runCreated: {
    in: ['executing'],
    run(ctx, e) {
      const m = ctx.model
      m.runs = [e.run, ...m.runs]
      showRun(m, e.run)
      ctx.state.value = 'document'
    },
  },
  runFailed: {
    in: ['executing'],
    run(ctx) {
      ctx.model.errors.workPanel = 'IDP実行に失敗しました'
      ctx.state.value = 'document'
    },
  },
  fieldInput: {
    in: WORKING,
    run(ctx, e) {
      const run = ctx.model.selectedRun
      if (!run) return
      setField(ctx.model.draft, e.key, e.value, originalValue(run, e.key))
    },
  },
  cellInput: {
    in: WORKING,
    run(ctx, e) {
      const run = ctx.model.selectedRun
      const cell = run && cellAt(run, e.table, e.row, e.column)
      if (!cell) return
      setCell(
        ctx.model.draft,
        cellKey(e.table, e.row, e.column),
        e.value,
        cell.content,
      )
    },
  },
  discardDraft: {
    in: ['document'],
    run(ctx) {
      resetDraft(ctx.model.draft)
    },
  },
  // 確定: 差分を base（選択中の実行）に対して POST し、応答の corrected 行を選択・履歴追加する
  confirmCorrections: {
    in: ['document'],
    run(ctx) {
      const m = ctx.model
      const base = m.selectedRun
      if (!base || draftCount(m.draft) === 0) return
      m.errors.workPanel = null
      ctx.state.value = 'saving'
      void apiClient
        .POST('/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections', {
          params: {
            path: { document_id: m.documentId, run_id: base.run_id },
            query: { verbose: true },
          },
          body: toCorrections(m.draft),
        })
        .then(
          ({ data, error }) =>
            ctx.dispatch(
              error || !data
                ? { type: 'saveFailed' }
                : { type: 'saved', run: data },
            ),
          () => ctx.dispatch({ type: 'saveFailed' }),
        )
    },
  },
  saved: {
    in: ['saving'],
    run(ctx, e) {
      const m = ctx.model
      m.runs = [e.run, ...m.runs]
      showRun(m, e.run)
      resetDraft(m.draft)
      m.savedSnackbar = true
      ctx.state.value = 'document'
    },
  },
  saveFailed: {
    in: ['saving'],
    run(ctx) {
      ctx.model.errors.workPanel = '修正の保存に失敗しました'
      ctx.state.value = 'document'
    },
  },
  snackbarClosed: {
    in: '*',
    run(ctx) {
      ctx.model.savedSnackbar = false
    },
  },
  // 確認ダイアログ: 続行で下書きを捨ててから保留中の操作を再 dispatch する。取消は操作だけを捨てる
  confirmProceed: {
    in: ['confirmDiscard'],
    run(ctx) {
      const pending = ctx.model.pendingEvent
      ctx.model.pendingEvent = null
      resetDraft(ctx.model.draft)
      ctx.state.value = 'document'
      if (pending) ctx.dispatch(pending)
    },
  },
  confirmCancel: {
    in: ['confirmDiscard'],
    run(ctx) {
      ctx.model.pendingEvent = null
      ctx.state.value = 'document'
    },
  },
  tabChanged: {
    in: WORKING,
    run(ctx, e) {
      ctx.model.activeTab = e.tab
      // 閲覧URLタブは開いたときに一覧を取る（文書ごとに初回だけ。発行・失効後の再取得は viewUrls.ts）
      if (
        e.tab === 'urls' &&
        ctx.model.viewUrls.loadedFor !== ctx.model.documentId
      ) {
        loadViewUrls(ctx)
      }
    },
  },
  // キャンバス側クリック → 読取結果タブへ切り替え、ペインへ「該当入力欄をフォーカス」
  rectClick: {
    in: WORKING,
    run(ctx, e) {
      const m = ctx.model
      m.activeId = e.id
      m.activeTab = 'result'
      m.paneFocus = { id: e.id, seq: ++m.seq }
    },
  },
  // ペイン側フォーカス → キャンバスへ「該当矩形を表示範囲へ」
  targetFocus: {
    in: WORKING,
    run(ctx, e) {
      const m = ctx.model
      m.activeId = e.id
      m.canvasScroll = { id: e.id, seq: ++m.seq }
    },
  },
}
