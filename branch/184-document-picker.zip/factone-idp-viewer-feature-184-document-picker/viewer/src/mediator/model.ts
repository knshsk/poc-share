import type { components } from '../api/schema'
import type { Corrections, IdpRun, IdpRunSummary } from '../utils/runs'
import type { PageSize } from '../utils/zoom'
import type { AppEvent, Tab } from './events'

// ---- ステートマシンの状態 ----
export type State =
  | 'booting'
  | 'login'
  | 'callback'
  | 'public'
  | 'empty'
  | 'registering'
  | 'loadingDocument'
  | 'documentError'
  | 'document'
  | 'executing'
  | 'saving'
  | 'confirmDiscard'

export const WORKING: readonly State[] = ['document', 'executing', 'saving']
// ページ画像の要求・完了は確認ダイアログ表示中も受ける（捨てると imageInflight に残ったページが二度と取れない）
export const VIEWING: readonly State[] = [
  ...WORKING,
  'confirmDiscard',
  'public',
]
// 確認ダイアログ（confirmDiscard）は document の上に重なるモーダルで、進行中の API 要求は生きている。
// 完了イベントはダイアログ中も受ける（捨てると issuing 等が固着し、発行済みの閲覧URLも失われる）
export const SETTLING: readonly State[] = [...WORKING, 'confirmDiscard']
export const AUTHED: readonly State[] = [
  'empty',
  'registering',
  'loadingDocument',
  'documentError',
  ...WORKING,
  'confirmDiscard',
]

// ---- 型 ----
export type DocumentTypeValue =
  components['schemas']['DocumentResponse']['document_type']
export type FieldDef = components['schemas']['FieldDefPayload']
export type ViewUrlSummary = components['schemas']['ViewUrlSummary']
export type TypeItem = Pick<
  components['schemas']['DocumentTypeConfigResponse'],
  'display_name' | 'type_code'
>

// 一発コマンド。同一 ID の再要求（同じ入力欄を再フォーカス等）を watch で検知できるよう連番を付ける
export interface Request {
  id: string
  seq: number
}

// 未確定の修正。元値との差分のみ保持する
export interface Draft {
  fields: Record<string, string | null>
  cells: Record<string, string>
}

export interface LoadedDocument {
  type: DocumentTypeValue
  displayName: string | null
  // 原本ファイル名。ファイル名なしの登録・列追加前の文書は null
  originalFilename: string | null
  shareable: boolean
  fieldDefs: FieldDef[]
  pages: PageSize[]
}

export interface Model {
  viewToken: string | null
  username: string | null
  // 表示要求中の文書 ID（ヘッダの文書タイトルにも出す）。確定は document が非 null になること
  documentId: string
  document: LoadedDocument | null
  publicPages: PageSize[]
  // page → blob URL（現在の文書 / token のもの。切替時に一括 revoke）
  images: Record<number, string>
  // 画像の取得に失敗したページ（紙面に失敗を表示する。文書の切替で消す）
  imageFailed: Record<number, true>
  runs: IdpRunSummary[]
  selectedRun: IdpRun | null
  activeTab: Tab
  runsLoading: boolean
  // 実行履歴の一覧を取得できなかった（実行 0 件と区別する。IDP 実行など他の失敗では立てない）
  runsLoadFailed: boolean
  draft: Draft
  activeId: string | null
  canvasScroll: Request | null
  paneFocus: Request | null
  savedSnackbar: boolean
  // 文書選択ダイアログ（DocumentPicker）の開閉。状態（文書の有無）とは別に持つ
  documentPickerOpen: boolean
  register: { typeItems: TypeItem[]; error: string | null }
  viewUrls: {
    loadedFor: string | null
    urls: ViewUrlSummary[]
    issuedUrl: string | null
    issuing: boolean
    error: string | null
    revokeTarget: string | null
  }
  errors: {
    public: string | null
    document: string | null
    workPanel: string | null
  }
  // ---- 内部（vm に出さない）----
  details: Map<string, IdpRun>
  pendingRunId: string | null
  imageInflight: Set<number>
  pendingEvent: AppEvent | null
  seq: number
  // 文書の読込の世代（clearDocument のたびに 1 増やす）。画像応答のスコープに含め、同じ文書を開き直す前に
  // 出した要求の応答を捨てる
  loadGeneration: number
}

export function initialModel(): Model {
  return {
    viewToken: null,
    username: null,
    documentId: '',
    document: null,
    publicPages: [],
    images: {},
    imageFailed: {},
    runs: [],
    selectedRun: null,
    activeTab: 'result',
    runsLoading: false,
    runsLoadFailed: false,
    draft: { fields: {}, cells: {} },
    activeId: null,
    canvasScroll: null,
    paneFocus: null,
    savedSnackbar: false,
    documentPickerOpen: false,
    register: { typeItems: [], error: null },
    viewUrls: {
      loadedFor: null,
      urls: [],
      issuedUrl: null,
      issuing: false,
      error: null,
      revokeTarget: null,
    },
    errors: { public: null, document: null, workPanel: null },
    details: new Map(),
    pendingRunId: null,
    imageInflight: new Set(),
    pendingEvent: null,
    seq: 0,
    loadGeneration: 0,
  }
}

// 文書切替: 画像 blob を全 revoke し、文書に紐づく状態を初期化する（documentId は呼び出し側が設定する）
export function clearDocument(model: Model): void {
  for (const url of Object.values(model.images)) URL.revokeObjectURL?.(url)
  model.images = {}
  model.imageFailed = {}
  model.imageInflight.clear()
  model.loadGeneration += 1
  model.document = null
  model.runs = []
  model.selectedRun = null
  model.details.clear()
  model.pendingRunId = null
  model.runsLoading = false
  resetDraft(model.draft)
  model.activeId = null
  model.activeTab = 'result'
  model.runsLoadFailed = false
  model.savedSnackbar = false
  model.viewUrls = initialModel().viewUrls
  model.errors.document = null
  model.errors.workPanel = null
  model.pendingEvent = null
}

// ---- draft 純関数（旧 stores/draft.ts）----

// 空欄は「値なし（null）」として扱う。元値と同じに戻ったら差分から外す
export function setField(
  draft: Draft,
  key: string,
  value: string,
  original: string | null,
): void {
  const next = value === '' ? null : value
  if (next === original) delete draft.fields[key]
  else draft.fields[key] = next
}

export function setCell(
  draft: Draft,
  key: string,
  value: string,
  original: string,
): void {
  if (value === original) delete draft.cells[key]
  else draft.cells[key] = value
}

export function resetDraft(draft: Draft): void {
  draft.fields = {}
  draft.cells = {}
}

export function draftCount(draft: Draft): number {
  return Object.keys(draft.fields).length + Object.keys(draft.cells).length
}

export function toCorrections(draft: Draft): Corrections {
  return {
    fields: { ...draft.fields },
    table_cells: Object.entries(draft.cells).map(([key, content]) => {
      // キーは cellKey() 由来の "t:r:c" のみ
      const [t, r, c] = key.split(':').map(Number) as [number, number, number]
      return { table_index: t, row_index: r, column_index: c, content }
    }),
  }
}
