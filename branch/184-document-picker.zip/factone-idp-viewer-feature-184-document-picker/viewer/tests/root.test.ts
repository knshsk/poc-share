import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const signinRedirect = vi.fn()
const signinCallback = vi.fn()
vi.mock('oidc-client-ts', () => ({
  UserManager: class {
    signinRedirect = signinRedirect
    signinCallback = signinCallback
    signoutRedirect = vi.fn()
  },
  WebStorageStateStore: class {},
  InMemoryWebStorage: class {},
}))

const getMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    POST: vi.fn(),
  },
  setAccessToken: vi.fn(),
}))

import { createAppVuetify } from '../src/plugins/vuetify'
import Root from '../src/Root.vue'
import LoginView from '../src/views/LoginView.vue'
import { routeGet, succeededRun } from './fixtures'

function mountRoot() {
  return mount(Root, { global: { plugins: [createAppVuetify()] } })
}

function at(path: string) {
  window.history.replaceState(null, '', path)
}

enableAutoUnmount(afterEach)

beforeEach(() => {
  getMock.mockReset()
  getMock.mockImplementation(routeGet([succeededRun]))
  signinCallback.mockReset()
  signinRedirect.mockReset()
  // jsdom は IntersectionObserver を持たず PageSvg が即座に画像を要求するため、blob URL 生成を仮設する
  URL.createObjectURL = vi.fn().mockReturnValue('blob:mock')
  at('/')
})

afterEach(() => {
  // @ts-expect-error jsdom に無いメソッドを仮設したため削除して戻す
  delete URL.createObjectURL
})

describe('Root', () => {
  it('未認証時はログインカードとアプリ名を表示し、ログインで signinRedirect する', async () => {
    const wrapper = mountRoot()
    // 初回描画は起動処理中（booting）の読込中画面。init 処理後の再描画を待ってから判定する
    await flushPromises()
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.find('.v-app-bar').exists()).toBe(false)
    await wrapper.get('button').trigger('click')
    expect(signinRedirect).toHaveBeenCalledOnce()
  })

  // トークン交換中はログインカードを出さず、ロゴだけのアプリバーとスピナーを出す
  it('コールバック処理中はロゴだけのアプリバーとスピナーを出し、ログインカードを出さない', async () => {
    at('/callback?code=abc')
    signinCallback.mockReturnValue(new Promise(() => {})) // トークン交換が終わらない
    const wrapper = mountRoot()
    await flushPromises()

    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    expect(wrapper.findComponent(LoginView).exists()).toBe(false)
    const bar = wrapper.get('.v-app-bar')
    expect(bar.text()).toContain('FactONE Viewer')
    expect(bar.find('[data-testid="user-menu"]').exists()).toBe(false)
  })

  // コールバック処理後にログイン前URL（document_id付き）へ復元され、その文書を開く
  it('コールバック後にログイン前URLの document_id の文書を開く', async () => {
    at('/callback?code=abc&state=xyz')
    signinCallback.mockImplementation(async () => {
      return {
        access_token: 'token-abc',
        profile: { preferred_username: 'sales01' },
        state: { returnTo: '/?document_id=doc-1' },
      }
    })
    const wrapper = mountRoot()
    await flushPromises()
    await flushPromises()

    expect(window.location.pathname + window.location.search).toBe(
      '/?document_id=doc-1',
    )
    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    expect(wrapper.get('[data-testid="header-document-id"]').text()).toContain(
      'doc-1',
    )
    expect(wrapper.get('[data-testid="user-menu"]').text()).toContain('sales01')
    expect(wrapper.text()).not.toContain('/api/v1/me')
  })

  // フッターはログイン前・認証後・公開閲覧の全状態で表示され、プレースホルダリンクを持つ
  describe('フッター', () => {
    function expectFooter(wrapper: ReturnType<typeof mountRoot>): void {
      const footer = wrapper.get('[data-testid="app-footer"]')
      expect(footer.text()).toContain('FactONE Viewer')
      const links = footer.findAll('a')
      expect(links.map((a) => a.text())).toEqual([
        'プライバシーポリシー',
        'お問い合わせ',
        'ライセンス',
      ])
      expect(links.every((a) => a.attributes('href') === '#')).toBe(true)
    }

    it('未認証時に表示される', () => {
      expectFooter(mountRoot())
    })

    it('認証後に表示される', async () => {
      at('/callback?code=abc')
      signinCallback.mockResolvedValue({ access_token: 't', profile: {} })
      const wrapper = mountRoot()
      await flushPromises()
      expectFooter(wrapper)
    })

    it('公開閲覧（/view/{token}）でも表示される', () => {
      at('/view/tok-123')
      expectFooter(mountRoot())
    })
  })

  // 公開閲覧ではロゴのみのヘッダを表示し、ユーザーメニューを出さない（#149）
  it('公開閲覧（/view/{token}）でロゴのみのヘッダとキャンバスを表示する', async () => {
    at('/view/tok-123')
    const wrapper = mountRoot()
    await flushPromises()
    const bar = wrapper.get('.v-app-bar')
    expect(bar.text()).toContain('FactONE Viewer')
    expect(bar.find('[data-testid="user-menu"]').exists()).toBe(false)
    expect(wrapper.get('[data-testid="download-original"]').text()).toContain(
      'ダウンロード',
    )
  })

  // 未保存の変更があるときはブラウザ離脱に標準警告を出す（beforeunload）。Root が常時登録する
  it('未保存の変更があるとき beforeunload で警告する', async () => {
    at('/callback?code=abc')
    signinCallback.mockResolvedValue({
      access_token: 't',
      profile: {},
      state: { returnTo: '/?document_id=doc-1' },
    })
    const wrapper = mountRoot()
    await flushPromises()
    await flushPromises()

    const clean = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(clean)
    expect(clean.defaultPrevented).toBe(false)

    await wrapper.get('[data-testid="field-input"] input').setValue('A-002')
    const dirty = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(dirty)
    expect(dirty.defaultPrevented).toBe(true)

    wrapper.unmount()
    const after = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(after)
    expect(after.defaultPrevented).toBe(false)
  })
})
