import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { defineComponent } from 'vue'

import AppHeader from '../src/components/AppHeader.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { HeaderVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { headerVm } from './fixtures'

const bubble = vi.fn()

// v-app-barはVuetifyレイアウト（v-app）配下が必要なためProbeで包む
const Probe = defineComponent({
  components: { AppHeader },
  props: { vm: { type: Object, required: true } },
  template: '<v-app><AppHeader :vm="vm" /></v-app>',
})

function mountHeader(over: Partial<HeaderVm> = {}) {
  return mount(Probe, {
    props: { vm: headerVm(over) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// メニューの内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('AppHeader', () => {
  it('プロダクト名とユーザー名を表示する', () => {
    const wrapper = mountHeader()
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.text()).toContain('sales01')
  })

  it('ログアウトボタンで logout を bubble する', async () => {
    const wrapper = mountHeader()
    await wrapper.get('[data-testid="user-menu"]').trigger('click')
    // v-menuの内容はteleportされるためdocumentから探す
    const logoutBtn = document.querySelector('[data-testid="logout"]')
    expect(logoutBtn).not.toBeNull()
    ;(logoutBtn as HTMLElement).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'logout' })
  })

  // 文書タイトル: 原本ファイル名が主表示。文書 ID は小さく添える
  it('原本ファイル名を主表示にし、文書 ID と種別チップを添える', () => {
    const wrapper = mountHeader({
      documentId: 'doc-1',
      documentName: '見積書 A.pdf',
      documentTypeLabel: 'カスタム注文書',
    })
    const name = wrapper.get('[data-testid="header-document-name"]')
    expect(name.text()).toBe('見積書 A.pdf')
    // 長い名前は省略記号で切るため、全文を title に入れる
    expect(name.attributes('title')).toBe('見積書 A.pdf')
    const title = wrapper.get('[data-testid="header-document-id"]')
    expect(title.text()).toContain('doc-1')
    expect(
      wrapper.get('[data-testid="header-document-type"]').text(),
    ).toContain('カスタム注文書')
    // 幅が足りないときに文書 ID 側から省略記号で切るため、全文を title に入れる
    expect(title.get('.doc-id').attributes('title')).toBe('doc-1')
    // ボタンのアクセシブル名はキャレットの見た目でなく操作を表す
    expect(title.get('.d-sr-only').text()).toBe('文書を切り替える')
  })

  // ファイル名の無い文書・読込中は文書 ID を主表示にし、ID を二重に出さない
  it('原本ファイル名が無いときは文書 ID を主表示にする', () => {
    const wrapper = mountHeader({ documentId: 'doc-1', documentName: null })
    expect(wrapper.get('[data-testid="header-document-name"]').text()).toBe(
      'doc-1',
    )
    expect(
      wrapper.get('[data-testid="header-document-id"]').text().split('doc-1'),
    ).toHaveLength(2)
  })

  // 文書が無い（認証済み）ときは、タイトルの位置に文書選択ダイアログを開くボタンを出す
  it('文書未指定では文書タイトルの代わりに「文書を開く」を出す', async () => {
    const wrapper = mountHeader()
    expect(wrapper.find('[data-testid="header-document-id"]').exists()).toBe(
      false,
    )
    const open = wrapper.get('[data-testid="header-open-document"]')
    expect(open.text()).toContain('文書を開く')
    expect(open.attributes('aria-haspopup')).toBe('dialog')
    // 文書タイトル（.doc-title の左右 8px）と余白をそろえ、文書の有無で内容が横にずれないようにする
    expect(open.classes()).toContain('px-2')
    // タイトルと同じく prepend 内（ロゴの右）に置く
    expect(
      wrapper
        .get('.v-toolbar__prepend')
        .find('[data-testid="header-open-document"]')
        .exists(),
    ).toBe(true)
    await open.trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'openDocumentPicker' })
  })

  // 文書タイトル（種別チップを含む）は prepend 内に置く
  it('文書タイトル（種別チップを含む）は prepend 内に置く', () => {
    const wrapper = mountHeader({
      documentId: 'DOC-001',
      documentTypeLabel: '見積書',
    })
    const prepend = wrapper.get('.v-toolbar__prepend')
    expect(prepend.find('[data-testid="header-document-id"]').exists()).toBe(
      true,
    )
    expect(prepend.find('[data-testid="header-document-type"]').exists()).toBe(
      true,
    )
  })

  // 文書タイトルのクリックで文書選択ダイアログを開く（参照タブと ID の初期値は Mediator と DocumentPicker が決める）
  it('文書タイトルのクリックで openDocumentPicker を bubble する', async () => {
    const wrapper = mountHeader({ documentId: 'doc-1' })
    const title = wrapper.get('[data-testid="header-document-id"]')
    expect(title.attributes('aria-haspopup')).toBe('dialog')
    await title.trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'openDocumentPicker' })
    // 文書 ID の切替メニューは廃止した
    expect(
      document.querySelector('[data-testid="header-document-id-input"]'),
    ).toBeNull()
  })

  // 未認証（公開閲覧）ではロゴだけを表示し、ユーザーメニューを出さない（#149）
  it('未認証ではロゴのみ表示する', () => {
    const wrapper = mountHeader({ authenticated: false, username: null })
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.find('[data-testid="user-menu"]').exists()).toBe(false)
    expect(wrapper.find('[data-testid="header-open-document"]').exists()).toBe(
      false,
    )
  })
})
