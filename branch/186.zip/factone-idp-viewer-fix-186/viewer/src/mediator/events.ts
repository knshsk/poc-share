import type { components } from '../api/schema'
import type { Session } from '../auth/oidc'
import type { IdpRun, IdpRunSummary } from '../utils/runs'
import type { PageSize } from '../utils/zoom'

export type Tab = 'result' | 'history' | 'urls'

type DocumentResponse = components['schemas']['DocumentResponse']
type DocumentTypeConfig = components['schemas']['DocumentTypeConfigResponse']
type ViewUrlSummary = components['schemas']['ViewUrlSummary']

// View 発（bubble で階層を上がる）
export type ViewEvent =
  | { type: 'init'; pathname: string; search: string }
  | { type: 'login' }
  | { type: 'logout' }
  | { type: 'openDocument'; documentId: string }
  | { type: 'openDocumentPicker' }
  | { type: 'closeDocumentPicker' }
  | { type: 'register'; documentId: string; documentType: string; file: File }
  | { type: 'retryLoad' }
  | { type: 'downloadOriginal' }
  | { type: 'pageVisible'; page: number }
  | { type: 'executeIdp' }
  | { type: 'selectRun'; runId: string }
  | { type: 'tabChanged'; tab: Tab }
  | { type: 'fieldInput'; key: string; value: string }
  | {
      type: 'cellInput'
      table: number
      row: number
      column: number
      value: string
    }
  | { type: 'discardDraft' }
  | { type: 'confirmCorrections' }
  | { type: 'snackbarClosed' }
  | { type: 'confirmProceed' }
  | { type: 'confirmCancel' }
  | { type: 'rectClick'; id: string }
  | { type: 'targetFocus'; id: string }
  | { type: 'issueViewUrl' }
  | { type: 'copyIssuedUrl' }
  | { type: 'revokeViewUrl'; viewUrlId: string }
  | { type: 'confirmRevoke' }
  | { type: 'cancelRevoke' }

// Mediator 内部完了イベント。API 応答・OIDC 完了を Mediator が自分へ dispatch する。
// documentId / token / runId / scope は古い応答を捨てるためのスコープ
export type InternalEvent =
  | { type: 'callbackDone'; session: Session | null }
  | { type: 'documentTypesLoaded'; items: DocumentTypeConfig[] }
  | { type: 'publicPagesLoaded'; token: string; pages: PageSize[] }
  | { type: 'publicPagesFailed'; token: string }
  | {
      type: 'documentLoaded'
      documentId: string
      document: DocumentResponse
      pages: PageSize[]
      configs: DocumentTypeConfig[] | null
    }
  | { type: 'documentFailed'; documentId: string }
  | { type: 'registered'; documentId: string }
  | { type: 'registerFailed'; message: string }
  | { type: 'pageImageLoaded'; scope: string; page: number; blob: Blob | null }
  | { type: 'runsLoaded'; documentId: string; runs: IdpRunSummary[] }
  | { type: 'runsFailed'; documentId: string }
  | { type: 'runDetailLoaded'; runId: string; run: IdpRun }
  | { type: 'runDetailFailed'; runId: string }
  | { type: 'runCreated'; run: IdpRun }
  | { type: 'runFailed' }
  | { type: 'saved'; run: IdpRun }
  | { type: 'saveFailed' }
  | { type: 'viewUrlsLoaded'; documentId: string; urls: ViewUrlSummary[] }
  | { type: 'viewUrlsFailed'; documentId: string }
  | { type: 'viewUrlIssued'; documentId: string; viewPath: string }
  | { type: 'viewUrlIssueFailed'; documentId: string }
  | { type: 'viewUrlRevoked'; documentId: string }
  | { type: 'viewUrlRevokeFailed'; documentId: string }
  | { type: 'downloadFailed'; scope: string }

export type AppEvent = ViewEvent | InternalEvent
