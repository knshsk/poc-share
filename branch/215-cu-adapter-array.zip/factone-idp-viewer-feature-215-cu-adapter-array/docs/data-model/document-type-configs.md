# 文書種別設定（document_type_configs）

文書種別のテナント別設定。抽出エンジン、抽出項目のキー・ラベル・型、閲覧URL発行可否を種別ごとに保持する（ADR-0014、[ADR-0029](../adr/0029-engine-neutral-extraction-contract.md)、[ADR-0030](../adr/0030-cu-analyzer-per-tenant-type.md)）。設定CRUD API（`/api/v1/config/document-types`）で管理する。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 管理ID |
| tenant_id | varchar(255) | NOT NULL | テナント識別子。JWTの`tenant_id`クレーム（ADR-0020）。シードは`default` |
| type_code | varchar(50) | NOT NULL | 文書種別コード。形式は`^[A-Za-z0-9_]{1,50}$`。`documents.document_type`が参照する |
| display_name | varchar(100) | NOT NULL | 種別表示名（例: 見積書） |
| shareable | bool | NOT NULL | 閲覧URL発行可否 |
| engine | varchar(20) | NOT NULL・default `azure-di` | 抽出エンジン。値は`azure-di`（Document Intelligenceの`prebuilt-layout` + Query Fields）か`azure-cu`（Content Understandingのアナライザ）。IDP実行はこのエンジンを呼ぶ |
| fields | jsonb | NOT NULL | 抽出フィールド定義の配列で、順序を保持する（下記） |
| patterns | jsonb | NOT NULL・default `[]` | 正規表現パターン定義の配列で、順序を保持する（下記）。IDP実行時に、エンジンが返した全文テキストへ適用する |
| created_at | timestamptz | NOT NULL・default now() | 行作成日時 |
| updated_at | timestamptz | NOT NULL・default now() | 行更新日時。更新時の値は、DBではなくSQLAlchemyの`onupdate`がnow()で入れる |

制約としてUNIQUE(`tenant_id`, `type_code`)を持つ。`documents.document_type`とのFKは張らない。種別コードは文字列で参照し、整合はアプリ層で担保する。

## fields要素

| キー | 型 | 説明 |
| --- | --- | --- |
| key | string | 抽出結果のキー。`azure-di`ではQuery Fieldsのキーに、`azure-cu`ではアナライザの項目名になる。形式は`^[A-Za-z0-9_]{1,50}$`で、種別内で一意 |
| label | string | 表示ラベル（例: 顧客コード） |
| type | string | `string` / `number` / `date` / `array`。IDP抽出結果の正規化はこの型に従う。`array`は明細（行の並び）を表し、各行が持つ値と、その正規化に使う型を`properties`で定義する |
| visible | bool | Viewerの読み取り結果に表示するか。省略時は`true`。`false`でも抽出・保存・API返却は行い、Viewerの表示からだけ除く。array型の項目は、この値によらずViewerに表示しない |
| description | string | エンジンへ渡す項目の説明。省略可で、指定するときは1〜1024文字。`azure-di`は使わない。`azure-cu`は項目の説明としてアナライザに渡し、省略時は`label`を渡す |
| properties | array | array型の項目のプロパティ（明細の列）の配列。array型のときだけ必須で、1件以上を指定する。array型以外の項目には指定できない。要素は`key` / `label` / `type` / `description`を持ち、`visible`は持たない。`type`は`string` / `number` / `date`のいずれかで、`array`は指定できない。`key` / `label` / `description`の制約は項目と同じで、`key`はproperties内で一意 |

設定の読み取りは、(tenant_id, type_code)による1行取得と、tenant_idによる一覧取得のみで、JSONB内部への検索は行わない。そのためGINインデックスは要らない。

`visible`は、表示時にViewerが現在の設定を参照して判定する。実行時のスナップショットではない。設定の変更は、過去の実行結果の表示にも反映される。想定しているのは、送信先と送信元のように対で指定すると抽出精度が上がるが、表示は不要な項目である。例は受領注文書の自社名。

## patterns要素

項目の抽出で取得しづらい項目を補うため、エンジンが返した全文テキストに正規表現を適用する。全文テキストは、`azure-di`ではDI応答の`content`、`azure-cu`ではCU応答の`markdown`である。取得しづらい項目の例は、採番規則のある見積番号や、適格請求書発行事業者登録番号である。

| キー | 型 | 説明 |
| --- | --- | --- |
| key | string | 結果のキー。形式は`^[A-Za-z0-9_]{1,50}$`で、patterns内で一意。fieldsのkeyとは別の空間で、重複してよい |
| label | string | 表示ラベル（例: 登録番号） |
| regex | string | Pythonの`re`構文による正規表現で、1〜512文字。登録時に`re.compile`で検証し、失敗すると422 |

実行時にフラグは指定しない。大文字と小文字を区別し、`.`は改行に一致しない。パターン内のインラインフラグ（`(?i)`など）は、Pythonの`re`の仕様どおり有効になる。返す値は一致全体（group 0）である。キャプチャグループは使わず、部分抽出は先読み・後読みで表現する。

正規表現はテナント管理者が入力するもので、Pythonの`re`にはタイムアウトがない。PoCでは、長さ上限とコンパイル検証のみを行う。本番前に、`re2`などバックトラックしないエンジンへの差し替えを検討する。

実在する見積番号かどうかといったマッチ値の妥当性検証は、外部システムの責務とする。SaaS側は検出と返却のみ行う。

設定APIのPUTは`patterns`を全置換する。`patterns`を省略したPUTは`[]`に置換する。全置換する点は`fields`と同じだが、`fields`は省略できず、1件以上が必要である。

## 整合性ルール

使用中の種別、つまり`documents`に参照行がある種別の削除は、409で拒否する。フィールド定義は自由に更新できる。過去のIDP実行ログ（idp_runs）は実行時点の結果をJSONBで保持済みのため、更新の影響を受けない。

設定APIは、選んだエンジンで扱えるスキーマかを保存時に検査する。`engine`が`azure-di`の種別は、`fields`を20件までとし、array型の項目を持てない。20件の上限は、Query Fieldsに指定できる項目数の上限（DIの仕様）に合わせた。違反すると422 `validation-error`で拒否し、理由は`errors[].msg`に入る。`azure-cu`の種別には、この検査を行わない。`engine`に`azure-di` / `azure-cu`以外の値を指定したときも、422 `validation-error`になる。PUTは設定を全置換するため、`engine`を省略したPUTは`azure-di`に戻す。

array型の項目と`properties`の規則に違反したときも、422 `validation-error`になる。当たるのは、array型の項目に`properties`が無いか空のとき、array型以外の項目に`properties`があるとき、`properties`の中で`key`が重複するときである。

文書登録時、テナント設定に未登録の種別は422で拒否する。IDP実行時に文書の種別が設定に未登録の場合は409とする。削除保護があるため通常は発生せず、防御的な措置である。

設定APIは、`display_name`・`fields[].label`・`fields[].description`・`fields[].properties[].label`・`fields[].properties[].description`・`patterns[].label`・`patterns[].regex`のいずれかがNULを含むと、422 `validation-error`で拒否する。PostgreSQLがNULを格納できないためである（ADR-0026）。

## シードデータ

マイグレーションで、以下の2種別を`tenant_id="default"`に投入する。どちらも`engine`は`azure-di`である。注文書はIDP実行後に案件型・ルート型へ分岐するため、実行前の種別は分けない。

| type_code | display_name | shareable | fields |
| --- | --- | --- | --- |
| purchase_order | 注文書 | false | 共通8項目 + `PurchaseOrderId`（注文書ID） |
| quotation | 見積書 | true | 共通8項目 |

共通8項目は次のとおり。Query FieldsのキーはDocument Intelligenceのドキュメントに倣い、PascalCaseとする。

| key | label | type | visible |
| --- | --- | --- | --- |
| SenderCompanyName | 取引先 | string | true |
| ReceiverCompanyName | 自社名 | string | **false** |
| OrderDate | 注文日 | date | true |
| TotalAmount | 合計金額 | number | true |
| DeliveryDate | 納品期限 | date | true |
| DeliveryLocation | 納品場所 | string | true |
| CustomerContactPersonName | 取引先担当者 | string | true |
| QuotationId | 見積書ID | string | true |

`shareable`のデフォルトは、注文書を発行禁止とするADR-0002の判断を引き継ぐ。

両種別の`patterns`に、登録番号（Tコード）を投入する。見積番号は採番規則が未確定のため投入しない。

| key | label | regex |
| --- | --- | --- |
| TCode | 登録番号 | `T\d{13}` |
