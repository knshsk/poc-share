# FactONE IDP/Viewerフロントエンド

Vue 3 + Vuetify製のSPA。ディレクトリ構成は、[create-vue](https://github.com/vuejs/create-vue)が生成する、種類別のタイプベース構造に準拠する。

## ディレクトリ構成

```
viewer/
├── src/                   # アプリケーション本体
│   ├── main.ts            # エントリポイント。アプリ生成とプラグイン登録のみ
│   ├── Root.vue           # 階層の頂点。Mediator を保持し、画面（views/）を vm で切り替える
│   ├── api/               # API クライアント
│   │   ├── client.ts      # openapi-fetch クライアント（setAccessToken で渡された Bearer を付与）
│   │   └── schema.d.ts    # OpenAPI から自動生成した型（手動編集禁止）
│   ├── assets/            # グローバル CSS・静的アセット
│   │   ├── main.css       # フォント定義・アプリ全体の基本スタイル
│   │   └── vuetify-overrides.css # Vuetify 部品の文字サイズ・透明度の上書き（@layer vuetify-overrides）
│   ├── auth/              # 認証
│   │   └── oidc.ts        # oidc-client-ts のラッパ（login / handleCallback / logout）
│   ├── mediator/          # ステートマシン Mediator（状態・モデル・API 呼出・裁定）
│   │   ├── bubble.ts      # useBubble / BUBBLE（Chain of Responsibility の鎖）
│   │   ├── events.ts      # View 発イベントと内部完了イベントの型
│   │   ├── model.ts       # 状態集合・Model・draft 純関数
│   │   ├── vm.ts          # 各 View の ViewModel 型と buildVm
│   │   ├── machine.ts     # createMediator / 遷移表の合成 / dispatch
│   │   └── handlers/      # イベント別の { in: State[], run }（auth / public / document / runs / viewUrls）
│   ├── components/        # UI 部品（LoadingSpinner を除き vm prop + useBubble の Passive View）
│   │   ├── AppHeader.vue      # アプリバー（ロゴ・文書コンテキスト・ユーザメニュー）
│   │   ├── DocumentCanvas.vue # ページ表示＋ナビ/ズーム（幅・全体フィット）＋読取矩形のキャンバス
│   │   ├── DocumentRegisterForm.vue # 文書登録フォーム（定型外フロー向け・開始ダイアログ内）
│   │   ├── KeyFieldList.vue   # キー項目の行
│   │   ├── LoadingSpinner.vue # 読込中のスピナー（遅延表示付き。vm を持たない表示部品）
│   │   ├── PageSvg.vue        # ページ画像 + 読取矩形オーバーレイ（ID・選択中・クリック・可視化通知）
│   │   ├── ResultEditor.vue   # 読取結果タブ（3 区分・候補値・フォーカス処理）
│   │   ├── ResultTable.vue    # 表 1 件
│   │   ├── StartDialog.vue    # 文書ID未指定時の開始ダイアログ（文書を登録 / 文書IDで参照）
│   │   ├── ViewUrlPanel.vue   # 閲覧用 URL 発行・管理（WorkPanel のタブ内）
│   │   └── WorkPanel.vue      # 作業パネル（読取結果・実行履歴・閲覧 URL のタブ、修正の確定・破棄）
│   ├── views/             # 画面単位のコンポーネント
│   │   ├── DocumentView.vue   # ドキュメント閲覧画面（認証あり）
│   │   ├── LoginView.vue      # ログイン画面（未認証）
│   │   └── PublicView.vue     # 公開閲覧画面（閲覧トークン）
│   ├── plugins/           # プラグイン設定
│   │   └── vuetify.ts     # Vuetify テーマ（カラートークンの唯一の定義箇所）・アイコン設定
│   └── utils/             # 表示フォーマッタ等の純粋関数
│       ├── download.ts    # Content-Disposition からファイル名決定（原本DL用）
│       ├── fieldStatus.ts # キー項目の状態の判定
│       ├── format.ts      # 確信度・日時フォーマッタ
│       ├── motion.ts      # prefers-reduced-motion に応じたスクロール挙動
│       ├── normalize.ts   # 正規化ヒント（サーバの _normalize と同規則）
│       ├── runs.ts        # 実行結果 JSON 列の型付け・読取矩形・ハイライト ID・元値取得
│       ├── spinnerClock.ts # スピナーの遅延表示の判定
│       ├── table.ts       # 表の列幅・空行・数値判定
│       └── zoom.ts        # キャンバスのフィット倍率計算
├── tests/                 # Vitest テスト（setup.ts が共通セットアップ、fixtures.ts が共通フィクスチャ）
├── public/                # そのまま配信される静的ファイル
├── index.html             # SPA エントリ HTML（Vue の起動前に出す起動スプラッシュと、カスケードレイヤーの順の宣言を含む）
├── vite.config.ts         # Vite ビルド設定（ビルド出力の CSS の <link> を body 末尾へ移す）
├── vitest.config.ts       # Vitest テスト設定
├── eslint.config.ts       # ESLint 設定
├── tsconfig.json          # TypeScript 設定（app / node に分割）
├── tsconfig.app.json      # src/ 向けの TypeScript 設定
├── tsconfig.node.json     # vite.config.ts 向けの TypeScript 設定
├── package.json           # 依存管理は npm
└── package-lock.json      # npm のロックファイル
```

## 各ディレクトリの責務と配置指針

新しいモジュールをどこに置くか、どこを編集するかを判断するための基準。

### 全体の構造（Passive View + Chain of Responsibility + Mediator）

すべてのコンポーネントは、`Root.vue`を頂点とする1本の階層に置く。`Root`が`mediator/`の`createMediator()`を1つ持ち、`vm`を各画面へ渡す。また、`provide(BUBBLE, dispatch)`で操作の鎖の終点になる。

コンポーネントはPassive View。入力は、自分用のViewModel型（`mediator/vm.ts`）1つを`vm` propで受ける。子には、`vm.canvas`のように部分を渡す。出力は`useBubble()`が返す`bubble(event)`だけで、`defineEmits`は使わない。ストアやinjectでモデルを読まない。

コンポーネントが持ってよい状態は、描画だけに関わるもの（ズーム・スクロール位置・区分の開閉・送信前のフォーム入力値）。API呼出・`URL.createObjectURL`・clipboard・`history`・`window`イベントは、Mediator / Rootだけが行う。

新しい操作を足すときは、次の順に進める。

1. `mediator/events.ts`にイベント型を追加する。
2. `mediator/handlers/`の該当ファイルに`{ in: 受け付ける状態, run }`を追加する。API呼出は、完了イベントを`dispatch`する形で書く。
3. 表示に必要な項目を`mediator/vm.ts`に足す。
4. Viewで`bubble({ type: ... })`を呼ぶ。

テストは`tests/mediator-*.test.ts`（dispatch → state / vm）とViewのテスト（vm → DOM、DOM → bubble）に書く。

### `views/`（画面）

`Root`が`vm.screen`で切り替える画面単位のコンポーネント。レイアウトと、子へのvmの分配を担当し、データ取得は持たない。新しい画面を追加するときは、`views/`に新規ファイルを作成し、`Root.vue`の切り替えと`mediator/vm.ts`の`RootVm.screen`に組み込む。

### `components/`（UI部品）

画面から切り出した再利用可能なUI部品。`vm` propと`useBubble()`だけで動く。ただし`LoadingSpinner`は、vmもbubbleも持たない表示部品で、読込中の各所に置く。画面の一部を部品化するときは、この層に新規ファイルを作成し、`mediator/vm.ts`に部品用のVm型を足して親から渡す。

### `mediator/`（ステートマシンMediator）

状態（`model.ts`の`State`）・モデル・遷移表・API呼出を置く層。`handlers/`はドメイン別（auth / public / document / runs / viewUrls）に分け、`machine.ts`が1つの表に合成する。共有状態を追加するときは、`model.ts`の`Model`に項目を足し、`vm.ts`で表示に必要な形にして渡す。単一コンポーネント内で完結する描画状態は、コンポーネントの`ref`で持つ。

### `api/`（APIクライアント）

バックエンドAPIとの通信を置く層。呼び出すのは`mediator/handlers/`だけ。`schema.d.ts`はOpenAPI定義からの自動生成物のため、手動編集しない。API契約が変わったときは`npm run generate:api`で再生成し、OpenAPI定義と`schema.d.ts`の差分をコミットする。この差分は、pre-commitの差分チェックの対象になる。

### `auth/`（認証）

`oidc-client-ts`のラッパ。Mediatorの`handlers/auth.ts`だけが使う。

### `plugins/`（プラグイン設定）

Vueプラグイン（Vuetify等）の生成・設定を置く層。`main.ts`から登録する。

### スタイル（タイポグラフィ・フォント・入力欄）

文字は14px以上にする（[ADR-0024](../docs/adr/0024-viewer-typography-contrast-baseline.md)）。サイズはVuetify 4のMD3タイポグラフィクラスで指定する（`text-body-medium` 14px / `text-body-large` 16px / `text-title-medium` 16px / `text-title-large` 22pxなど）。14px未満のクラス（`text-body-small` / `text-label-small` / `text-label-medium`）、`size="x-small"`、14px（0.875rem）未満の`font-size`は使わない。Vuetify 3までの旧名（`text-caption` / `text-body-2` / `text-h6`など）は定義が無く、書いても警告は出ず、指定が効かない。`tests/typography-classes.test.ts`が、下限に満たない指定も旧名も検出する。

ラベル・補足・一覧の副題は、`text-secondary`で本文と区別する。文字サイズの差で階層は作らない。

Vuetifyの部品が内部で持つ文字サイズ・透明度（浮動ラベル・`size="small"`のボタンとチップ・プレースホルダ・入力欄の枠）は、`assets/vuetify-overrides.css`の`@layer vuetify-overrides`で上書きする。レイヤーの順は、`index.html`のheadの最初の`<style>`で宣言しており、importの順には左右されない。`tests/css-layers.test.ts`が、この宣言とVuetify本体のスタイルが行うレイヤー宣言との一致と、宣言漏れを検査する。宣言漏れの対象は、アプリとVuetifyのCSSが使うレイヤー。

全体フォントは`assets/main.css`の`--v-font-body`で指定する。ダイアログ・メニュー・ツールチップ・スナックバーは`body`直下へteleportされるため、`.v-application`へのスタイル指定は届かない。

等幅（`.font-mono`）は、文書ID・発行URLなどの識別子に限る。日時・ページ数などの数字は、UIフォントのままにする。IBM Plex Sans JPの数字は既定で等幅のため、桁を揃える指定は要らない。

`v-text-field` / `v-select`の`variant` / `density`は、`plugins/vuetify.ts`の`defaults`（outlined + compact）で統一する。各コンポーネントでは指定しない。

色はテーマ（`plugins/vuetify.ts`）の参照だけで指定する。文字色に使う色は、白地・自色の淡色地・選択行の灰色地のいずれの上でも、ホバーが重なった状態を含めて4.5:1以上にする。このテーマ色は、`tests/vuetify-plugin.test.ts`で検査している。入力欄の枠と表の罫線は、白地とキャンバス地に対して3:1以上にする。例外は`index.html`の起動スプラッシュ。Vuetifyの起動前に描くため、background / primaryを直書きしている。この値がテーマと一致しているかは、`tests/boot-splash.test.ts`が検査する。

### `src/`直下

`main.ts`はエントリポイント。アプリ生成とプラグイン登録のみを行い、ビジネスロジックは書かない。

`Root.vue`は階層の頂点。Mediatorの保持と画面の切り替えだけを担当し、画面の中身は`views/`に置く。

## 起動・テスト

```
npm run dev            # 開発サーバー起動
npm run test           # テスト
npm run build          # 型チェック + ビルド
npm run lint           # lint
npm run generate:api   # OpenAPI エクスポート + TS 型再生成
```
