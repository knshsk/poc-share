# ローカル認証動作手順

Keycloakを使った認証付きの動作確認手順。前提として、[local-stack.md](local-stack.md)・[api.md](api.md)・[viewer.md](viewer.md)のセットアップが完了していること。

## 1. ローカルスタック起動とテストユーザー設定

```bash
podman compose up -d
```

初回起動（またはボリューム初期化後）は、realmインポートの完了を待ってから、テストユーザーのパスワードを設定する。

```bash
./scripts/local-stack/apply-keycloak-secrets.sh
```

このスクリプトは、`.env`の`KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD`で管理者ログインする。続けて、`KC_TEST_USER_PASSWORD`の値をテストユーザー`testuser`のパスワードに、`KC_INTEGRATION_CLIENT_SECRET`の値をM2M連携クライアント`factone-integration`のクライアントシークレットに設定する。realm定義JSONにはシークレットを含めない運用である。Keycloakのrealmインポートは環境変数置換を行わないため、このスクリプトでの設定が必要になる。

### M2M（サーバ間）呼出のトークン取得

外部システム連携用クライアント`factone-integration`（client credentials grant）でトークンを取得できる。

```bash
curl -d 'grant_type=client_credentials&client_id=factone-integration&client_secret=<シークレット>' http://localhost:8080/realms/factone/protocol/openid-connect/token
```

## 2. API・Viewer起動

```bash
cd api
uv run uvicorn --factory app.main:create_app --reload
```

```bash
cd viewer
npm run dev
```

## 3. 動作確認

1. `http://localhost:5173/`を開く。
2. 「ログイン」からKeycloakのログイン画面へ進み、`testuser`と`.env`の`KC_TEST_USER_PASSWORD`の値を入力する。
3. ログインすると、文書閲覧画面に開始ダイアログ（「文書を登録」と「文書IDで参照」のタブ）が開き、ヘッダのユーザーメニューにユーザー名が出る。
4. 「文書IDで参照」タブで文書IDを入力し、「参照」を押す。開始ダイアログは、文書の取得に成功しても失敗しても閉じる。登録されていない文書IDでは「文書を取得できませんでした」と表示される。
5. ヘッダのユーザーメニューの「ログアウト」で未認証状態に戻る。

## 構成メモ

認証フローは認可コードフロー+PKCE（S256必須）で、クライアントは`factone-viewer`（public）。

アクセストークンはViewer側でメモリに保持し、永続化しない。API呼出時には`Authorization: Bearer`を付与する。

API側は、署名・issuer・audience（`factone-api`）・有効期限・`sub`の存在・`tenant_id`クレームを検証する。署名はKeycloakのJWKSで検証し、アルゴリズムはRS256のみを許す。`tenant_id`クレームの形式は`^[a-z0-9][a-z0-9-]{0,62}$`で、欠落または不正のときは403 `tenant-unresolved`を返す。

ローカルのAPI呼出は、Vite devプロキシで同一オリジンにする。プロキシするのは`/api`と`/view/{token}/pages|pdf`で、転送先は`localhost:8000`。

設定は上書きできる。API側は環境変数`FACTONE_OIDC_ISSUER` / `FACTONE_OIDC_AUDIENCE`、Viewer側は`VITE_OIDC_AUTHORITY` / `VITE_OIDC_CLIENT_ID`で上書きする。

テナントの識別はJWTの`tenant_id`クレームで行う（[architecture/auth.md](../architecture/auth.md)）。ロール・文書アクセス認可は未実装で、未確定事項の解消後に対応する。
