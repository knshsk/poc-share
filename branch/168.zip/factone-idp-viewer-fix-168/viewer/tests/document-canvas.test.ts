import { mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import PageSvg from '../src/components/PageSvg.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { CanvasVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { canvasVm, stubResizeObserver, succeededRun } from './fixtures'

const bubble = vi.fn()

function mountCanvas(extra: Partial<CanvasVm> = {}) {
  return mount(DocumentCanvas, {
    props: { vm: canvasVm(extra) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// jsdom は要素サイズを持たないため、スクローラの clientWidth / clientHeight を差し替える
function setScrollerSize(
  wrapper: ReturnType<typeof mountCanvas>,
  clientWidth: number,
  clientHeight: number,
): void {
  const el = wrapper.get('.canvas-scroller').element
  Object.defineProperty(el, 'clientWidth', {
    value: clientWidth,
    configurable: true,
  })
  Object.defineProperty(el, 'clientHeight', {
    value: clientHeight,
    configurable: true,
  })
}

function isActive(
  wrapper: ReturnType<typeof mountCanvas>,
  testId: string,
): boolean {
  return wrapper.get(`[data-testid="${testId}"]`).classes('v-btn--active')
}

function frameWidths(wrapper: ReturnType<typeof mountCanvas>): string[] {
  return wrapper
    .findAll('.page-frame')
    .map((frame) => (frame.element as HTMLElement).style.width)
}

describe('DocumentCanvas', () => {
  beforeEach(() => {
    bubble.mockClear()
  })

  afterEach(() => {
    // @ts-expect-error jsdom に無いメソッドを差し込んだテストの後始末
    delete Element.prototype.scrollIntoView
    vi.unstubAllGlobals()
  })

  // 全ページ分のPageSvgを描画し、page ごとの画像 URL を渡すことを確認する
  it('全ページを描画しページ表示と画像URLを出す', () => {
    const wrapper = mountCanvas({ images: { 2: 'blob:p2' } })
    const svgs = wrapper.findAllComponents(PageSvg)
    expect(svgs).toHaveLength(3)
    expect(svgs[0]!.props('imageUrl')).toBeNull()
    expect(svgs[1]!.props('imageUrl')).toBe('blob:p2')
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('1 / 3')
  })

  // 次/前ページボタンで表示中ページが移動し、境界でクランプされることを確認する
  it('次/前ページで表示中ページが移動する', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="canvas-next"]').trigger('click')
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('2 / 3')
    await wrapper.get('[data-testid="canvas-prev"]').trigger('click')
    await wrapper.get('[data-testid="canvas-prev"]').trigger('click')
    expect(
      wrapper.get('[data-testid="canvas-page-indicator"]').text(),
    ).toContain('1 / 3')
  })

  // 1 ページ文書ではページ送り（前へ・ページ数・次へ）を描画しない。ズーム・フィットは残す
  it('1 ページ文書ではページ送りを出さない', () => {
    const wrapper = mountCanvas({ pages: [{ width: 8.5, height: 11 }] })
    for (const id of ['canvas-prev', 'canvas-page-indicator', 'canvas-next']) {
      expect(wrapper.find(`[data-testid="${id}"]`).exists()).toBe(false)
    }
    expect(wrapper.find('[data-testid="canvas-zoom"]').exists()).toBe(true)
    expect(wrapper.find('[data-testid="canvas-fit-page"]').exists()).toBe(true)
  })

  // v-btn-toggle 内の icon ボタンは左右余白が付かず幅 20px に潰れ、3 つが 1 つの塊に見える
  it('フィットボタンは icon ボタンにしない', () => {
    const wrapper = mountCanvas()
    for (const id of [
      'canvas-fit-width',
      'canvas-fit-height',
      'canvas-fit-page',
    ]) {
      expect(wrapper.get(`[data-testid="${id}"]`).classes()).not.toContain(
        'v-btn--icon',
      )
    }
  })

  // ズームは25%刻み・25〜200%でクランプされ、幅合わせで再計算される（jsdom は計測不能で 100%）ことを確認する
  it('ズームと幅合わせが機能する', async () => {
    const wrapper = mountCanvas()
    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('125%')
    await wrapper.get('[data-testid="canvas-fit-width"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')
    const zoomOut = wrapper.get('[data-testid="canvas-zoom-out"]')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    await zoomOut.trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('25%')
  })

  // 初期表示は全体表示（page）。jsdom ではサイズ計測不能のため倍率は 100% に倒れる
  it('初期モードは全体表示で、±操作で手動（非選択）になる', async () => {
    const wrapper = mountCanvas()
    expect(isActive(wrapper, 'canvas-fit-page')).toBe(true)
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')

    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(isActive(wrapper, 'canvas-fit-page')).toBe(false)
    expect(isActive(wrapper, 'canvas-fit-width')).toBe(false)
    expect(isActive(wrapper, 'canvas-fit-height')).toBe(false)
  })

  // 高さ合わせ・全体表示はスクローラの実寸から倍率を計算し、25〜200% に制限されないことを確認する。
  // letter の実寸 816×1056px、内寸幅 1048-48=1000px（幅合わせ 122%）
  it('高さ合わせと全体表示がスクローラの寸法から倍率を計算する', async () => {
    const wrapper = mountCanvas()
    setScrollerSize(wrapper, 1048, 2274)

    // 可視高さ 2274-74=2200px / 1056px = 208.3…%
    await wrapper.get('[data-testid="canvas-fit-height"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('208%')
    expect(isActive(wrapper, 'canvas-fit-height')).toBe(true)

    // 幅が制約: min(122, 208)
    await wrapper.get('[data-testid="canvas-fit-page"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('122%')
    expect(isActive(wrapper, 'canvas-fit-page')).toBe(true)

    // 高さが制約: 可視高さ 1174-74=1100px / 1056px = 104.1…%
    setScrollerSize(wrapper, 1048, 1174)
    await wrapper.get('[data-testid="canvas-fit-page"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('104%')

    setScrollerSize(wrapper, 1048, 84)
    await wrapper.get('[data-testid="canvas-fit-height"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('1%')
  })

  // ±はフィット値（25の倍数でない）から次の25の倍数へスナップし、下限は25%に丸めることを確認する
  it('±はフィット値から25の倍数へスナップする', async () => {
    const wrapper = mountCanvas()
    // 可視高さ 972-74=898px / 1056px = 85.0…%（幅合わせ 122% より小さい）
    setScrollerSize(wrapper, 1048, 972)
    await wrapper.get('[data-testid="canvas-fit-page"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('85%')

    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('100%')
    await wrapper.get('[data-testid="canvas-zoom-out"]').trigger('click')
    await wrapper.get('[data-testid="canvas-zoom-out"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('50%')

    setScrollerSize(wrapper, 1048, 84)
    await wrapper.get('[data-testid="canvas-fit-height"]').trigger('click')
    expect(
      wrapper.get('[data-testid="canvas-zoom-out"]').attributes('disabled'),
    ).toBeDefined()
    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('25%')
  })

  // ページ枠の幅は倍率 × 1 ページ目の実寸（px）。寸法の違うページも 1 ページ目と同じ幅で並べる
  it('ページ枠の幅は 1 ページ目の実寸 × 倍率で、全ページ同じ', async () => {
    const wrapper = mountCanvas({
      pages: [
        { width: 8.5, height: 11 },
        { width: 11, height: 8.5 },
      ],
    })
    // jsdom は計測不能で 100% → 拡大で 125%。letter の実寸幅 816px × 1.25 = 1020px
    await wrapper.get('[data-testid="canvas-zoom-in"]').trigger('click')
    expect(wrapper.get('[data-testid="canvas-zoom"]').text()).toBe('125%')
    expect(frameWidths(wrapper)).toEqual(['1020px', '1020px'])
  })

  // 右ペインの幅を変えるとスクローラの幅だけが変わる（ResizeObserver で通知）。倍率はページ実寸比なので、
  // 倍率ラベルとページ枠の幅は常に連動する（#168）。letter の実寸 816×1056px、スクローラの高さ 866（可視高さ
  // 792px = 高さ合わせ 75%）、幅 1272 → 864 → 456（内寸幅 1224 / 816 / 408px = 幅合わせ 150 / 100 / 50%）
  it.each([
    [
      '全体表示（高さが制約の間は不変、幅が制約になると縮む）',
      ['canvas-fit-page'],
      [
        ['75%', '612px'],
        ['75%', '612px'],
        ['50%', '408px'],
      ],
    ],
    [
      '幅合わせ',
      ['canvas-fit-width'],
      [
        ['150%', '1224px'],
        ['100%', '816px'],
        ['50%', '408px'],
      ],
    ],
    [
      '高さ合わせ',
      ['canvas-fit-height'],
      [
        ['75%', '612px'],
        ['75%', '612px'],
        ['75%', '612px'],
      ],
    ],
    [
      '手動（全体表示の 75% から拡大）',
      ['canvas-fit-page', 'canvas-zoom-in'],
      [
        ['100%', '816px'],
        ['100%', '816px'],
        ['100%', '816px'],
      ],
    ],
  ])(
    '%s: スクローラの幅が変わっても倍率ラベルとページ幅が連動する',
    async (_, clicks, expected) => {
      const observed = stubResizeObserver()
      const wrapper = mountCanvas({ pages: [{ width: 8.5, height: 11 }] })
      const scroller = wrapper.get('.canvas-scroller').element
      // 監視が無いと、変化しない期待値（全体表示・高さ合わせ・手動）の行はリサイズを経ずに通ってしまう
      expect(observed.has(scroller)).toBe(true)
      const shown = () => [
        wrapper.get('[data-testid="canvas-zoom"]').text(),
        frameWidths(wrapper)[0],
      ]
      // スクローラのサイズを差し替えてから、スクローラを監視している ResizeObserver を発火する
      const resize = async (clientWidth: number) => {
        setScrollerSize(wrapper, clientWidth, 866)
        observed.get(scroller)?.([
          {
            borderBoxSize: [{ inlineSize: clientWidth, blockSize: 866 }],
          } as unknown as ResizeObserverEntry,
        ])
        await wrapper.vm.$nextTick()
      }

      setScrollerSize(wrapper, 1272, 866)
      for (const id of clicks)
        await wrapper.get(`[data-testid="${id}"]`).trigger('click')
      const seen = [shown()]
      await resize(864)
      seen.push(shown())
      await resize(456)
      seen.push(shown())
      expect(seen).toEqual(expected)
    },
  )

  // ダウンロードボタンは文言を vm から出し、downloadOriginal を bubble する
  it('ダウンロードボタンで downloadOriginal を bubble し、文言を差し替えられる', async () => {
    const wrapper = mountCanvas({ downloadLabel: 'ダウンロード' })
    const button = wrapper.get('[data-testid="download-original"]')
    expect(button.text()).toContain('ダウンロード')
    await button.trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'downloadOriginal' })
    expect(
      mountCanvas().get('[data-testid="download-original"]').text(),
    ).toContain('原本ダウンロード')
  })

  // 選択中の成功実行から矩形を作り、page_number ごとに該当ページの PageSvg へ渡す。visible=false は除外
  it('選択中実行の矩形をページごとにPageSvgへ渡す', () => {
    const wrapper = mountCanvas({ run: succeededRun })
    const svgs = wrapper.findAllComponents(PageSvg)
    expect(svgs[0]!.props('rects')?.map((r) => r.id)).toEqual(['cell:0:0:0'])
    expect(svgs[1]!.props('rects')?.map((r) => r.id)).toEqual([
      'field:total_amount',
    ])
    expect(svgs[2]!.props('rects')).toEqual([])

    const hidden = mountCanvas({
      run: succeededRun,
      fieldDefs: [
        { key: 'total_amount', label: '合計', type: 'number', visible: false },
      ],
    })
    expect(hidden.findAllComponents(PageSvg)[1]!.props('rects')).toEqual([])
  })

  it('失敗実行・未選択では矩形を渡さない', () => {
    expect(
      mountCanvas({
        run: { ...succeededRun, status: 'failed', tables: null, fields: null },
      })
        .findAllComponents(PageSvg)
        .every((svg) => svg.props('rects')?.length === 0),
    ).toBe(true)
    expect(
      mountCanvas({ run: null })
        .findAllComponents(PageSvg)
        .every((svg) => svg.props('rects')?.length === 0),
    ).toBe(true)
  })

  // 矩形クリックは PageSvg → DocumentCanvas → 親へと bubble で上がる。activeId は vm から PageSvg へ渡る
  it('矩形クリックが親へ bubble し、activeId を PageSvg へ渡す', async () => {
    const wrapper = mountCanvas({ run: succeededRun, activeId: 'cell:0:0:0' })
    await wrapper.get('[data-rect-id="cell:0:0:0"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'rectClick', id: 'cell:0:0:0' })
    expect(wrapper.findAllComponents(PageSvg)[0]!.props('activeId')).toBe(
      'cell:0:0:0',
    )
  })

  // ペイン側からの要求（scrollRequest）で該当矩形を表示範囲へスクロールする（jsdom には scrollIntoView が無いため差し込む）
  it('scrollRequest で該当矩形を scrollIntoView する', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const wrapper = mountCanvas({ run: succeededRun })

    await wrapper.setProps({
      vm: canvasVm({
        run: succeededRun,
        scrollRequest: { id: 'field:total_amount', seq: 1 },
      }),
    })
    await wrapper.vm.$nextTick()

    expect(scrollSpy).toHaveBeenCalledTimes(1)
    expect(scrollSpy.mock.instances[0]).toBe(
      wrapper.get('[data-rect-id="field:total_amount"]').element,
    )
    expect(scrollSpy).toHaveBeenCalledWith(
      expect.objectContaining({ block: 'center', inline: 'center' }),
    )
  })

  // prefers-reduced-motion: reduce のときはスムーススクロールを使わない
  it('reduced-motion 指定時は behavior auto でスクロールする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    vi.stubGlobal('matchMedia', () => ({ matches: true }))
    const wrapper = mountCanvas({ run: succeededRun })

    await wrapper.setProps({
      vm: canvasVm({
        run: succeededRun,
        scrollRequest: { id: 'field:total_amount', seq: 1 },
      }),
    })
    await wrapper.vm.$nextTick()

    expect(scrollSpy).toHaveBeenCalledWith(
      expect.objectContaining({ behavior: 'auto' }),
    )
  })
})
