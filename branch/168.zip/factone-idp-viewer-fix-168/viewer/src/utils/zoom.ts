// キャンバスのズームモード。width=幅合わせ / height=高さ合わせ / page=全体表示 / custom=手動（±操作後）
export type ZoomMode = 'width' | 'height' | 'page' | 'custom'

export interface PageSize {
  width: number
  height: number
}

// ページ寸法はインチ。倍率 100% = 実寸（CSS の 1 インチ = 96px）
export const PX_PER_INCH = 96

// DocumentCanvas の .canvas-scroller / .page-frame / .page-svg の CSS と一致させる
const SCROLLER_PADDING = 24
const PAGE_FRAME_MARGIN_BOTTOM = 24
const PAGE_BORDER = 1
const HORIZONTAL_CHROME = SCROLLER_PADDING * 2
const VERTICAL_CHROME =
  SCROLLER_PADDING * 2 + PAGE_FRAME_MARGIN_BOTTOM + PAGE_BORDER * 2

// ズーム値はページ実寸に対する %（100=実寸）。コンテナの幅に依らないため、右ペインやウィンドウの幅が変わっても
// ラベルと表示サイズが連動する。width / height はコンテナ内寸に 1 ページの幅 / 高さが収まる倍率、page はその小さいほう。
// 計測不能（jsdom・非表示）のときは 100 に倒す
export function fitZoom(
  mode: Exclude<ZoomMode, 'custom'>,
  clientWidth: number,
  clientHeight: number,
  page: PageSize,
): number {
  const availWidth = clientWidth - HORIZONTAL_CHROME
  const availHeight = clientHeight - VERTICAL_CHROME
  if (availWidth <= 0 || availHeight <= 0) return 100
  const byWidth = availWidth / (page.width * PX_PER_INCH)
  const byHeight = availHeight / (page.height * PX_PER_INCH)
  const scale =
    mode === 'width'
      ? byWidth
      : mode === 'height'
        ? byHeight
        : Math.min(byWidth, byHeight)
  // 切り上げ側に振れると数 px はみ出すため切り捨て。浮動小数誤差（89.999…）は epsilon で吸収
  return Math.max(1, Math.floor(scale * 100 + 1e-6))
}
