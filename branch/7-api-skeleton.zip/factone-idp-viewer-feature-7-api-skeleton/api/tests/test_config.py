from pathlib import Path

import pytest

from app.config import Settings


def test_settings_reads_env_var_with_prefix(monkeypatch: pytest.MonkeyPatch) -> None:
    """FACTONE_ プレフィックス付き環境変数から設定値を読み込めることを確認する。"""
    monkeypatch.setenv("FACTONE_APP_NAME", "factone-test")

    settings = Settings()

    assert settings.app_name == "factone-test"


def test_settings_has_default_app_name() -> None:
    """環境変数・.env が無い場合にデフォルト値が使われることを確認する。"""
    settings = Settings(_env_file=None)

    assert settings.app_name == "factone-api"


def test_settings_reads_dotenv_file(tmp_path: Path) -> None:
    """.env ファイルから設定値を読み込めることを確認する。"""
    env_file = tmp_path / ".env"
    env_file.write_text("FACTONE_APP_NAME=factone-from-dotenv\n", encoding="utf-8")

    settings = Settings(_env_file=env_file)

    assert settings.app_name == "factone-from-dotenv"
