from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """アプリケーション設定。環境変数（FACTONE_ プレフィックス）と .env から読み込む。"""

    model_config = SettingsConfigDict(env_prefix="FACTONE_", env_file=".env")

    app_name: str = "factone-api"
