#!/bin/bash
# PostgreSQL初回起動時にKeycloak用のDB・ユーザーを作成する初期化スクリプト。
# docker-entrypoint-initdb.d 経由で実行される（データボリュームが空の初回のみ）。
# アプリ用DBと同一サーバ内の別DBとする構成は、Azure環境（PostgreSQL共用サーバ内別DB）と揃えている。
set -euo pipefail

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE USER ${KEYCLOAK_DB_USER} WITH PASSWORD '${KEYCLOAK_DB_PASSWORD}';
    CREATE DATABASE keycloak OWNER ${KEYCLOAK_DB_USER};
EOSQL
