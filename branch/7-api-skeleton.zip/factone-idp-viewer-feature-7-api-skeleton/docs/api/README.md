# API設計ドキュメント

API（FastAPI）に関する設計ドキュメントを格納するディレクトリです。

- OpenAPIスキーマのエクスポートを含みます。Power Automate向けの外部公開契約（IF-01/02）はここに固定し、レビュー・共有します。
- API契約の型共有はPydanticモデルを単一情報源とし、OpenAPI経由でTypeScript型を生成します。
