# WSL開発環境構築手順

ローカル開発の前提となるWSL2（Ubuntu 24.04）+ Podman環境を構築する手順です。マシンごとに1回だけ実施します。

日常のスタック起動・停止は [local-stack.md](local-stack.md) を参照してください。

## 前提条件

- Windows 11の社用支給PC（管理者権限で PowerShell を実行できること）
- 社内プロキシのアドレス・ポート・Basic認証の資格情報
- 社内プロキシのCA証明書ファイル（PEM形式。入手方法は社内配布ルールに従ってください）

## 1. WSL2とUbuntu 24.04の導入

PowerShell（管理者）で実行します。

```powershell
wsl --update
wsl --install Ubuntu-24.04
```

- 初回起動時にUbuntuのユーザー名・パスワードを設定します。
- 既定ディストリビューションにする場合は `wsl --set-default Ubuntu-24.04` を実行してください。

### systemdの確認

Podmanのrootless実行（ヘルスチェック等）にsystemdが必要です。Ubuntu 24.04の新規導入では既定で有効ですが、確認しておきます。

```bash
systemctl is-system-running
```

`running` または `degraded` 以外（`offline` 等）の場合は `/etc/wsl.conf` に以下を追記し、PowerShellから `wsl --shutdown` 後に再起動してください。

```ini
[boot]
systemd=true
```

## 2. プロキシ設定

### 2-1. 環境変数

`~/.bashrc` の末尾に追記します（`<user>` `<pass>` `<proxy-host>` `<port>` は実際の値に置換。パスワードに記号を含む場合はURLエンコードが必要です）。

```bash
export http_proxy="http://<user>:<pass>@<proxy-host>:<port>"
export https_proxy="$http_proxy"
export no_proxy="localhost,127.0.0.1"
```

反映は `source ~/.bashrc` または再ログインです。

> **注意:** `~/.bashrc` にプロキシパスワードが平文で残ります。ファイル権限（`chmod 600 ~/.bashrc`）と取り扱いに注意してください。

### 2-2. apt

aptは環境変数を参照しないため個別設定します。`/etc/apt/apt.conf.d/95proxy` を作成します。

```bash
sudo tee /etc/apt/apt.conf.d/95proxy > /dev/null <<'EOF'
Acquire::http::Proxy "http://<user>:<pass>@<proxy-host>:<port>";
Acquire::https::Proxy "http://<user>:<pass>@<proxy-host>:<port>";
EOF
```

### 2-3. プロキシ証明書の配布

社内プロキシは証明書検証（TLSインスペクション）を行うため、CA証明書をWSL内の信頼ストアへ登録します。これを省くと `podman pull` 等がTLSエラーで失敗します。

CA証明書ファイル（PEM形式）をWindows側からWSLへコピーし、登録します（Windowsのダウンロード先が `C:\work\proxy-ca.crt` の場合の例）。

```bash
sudo cp /mnt/c/work/proxy-ca.crt /usr/local/share/ca-certificates/proxy-ca.crt
sudo update-ca-certificates
```

`1 added` と表示されれば登録完了です。拡張子は `.crt` である必要があります。

## 3. Podmanの導入

```bash
sudo apt-get update
sudo apt-get install -y podman podman-compose
```

`podman compose` サブコマンド（podman 4.7以降）が `podman-compose` へ委譲する構成になります。

### compose providerの固定

`podman compose` は委譲先をPATHから探索しますが、WSLはWindows側のPATHも連結するため、Windows側に残っているDocker Desktop等の `docker-compose` を誤って拾うことがあります。委譲先を `podman-compose` に固定します。

```bash
mkdir -p ~/.config/containers
printf '[engine]\ncompose_providers = ["/usr/bin/podman-compose"]\n' > ~/.config/containers/containers.conf
```

## 4. 動作確認

```bash
podman compose version
```

```bash
podman pull docker.io/library/hello-world
```

イメージ取得が成功すれば、プロキシ・証明書設定を含めて疎通確認完了です。

続けて [local-stack.md](local-stack.md) の手順でローカルスタックを起動してください（リポジトリのclone・git設定は済んでいる前提です）。

## トラブルシュート

- **`podman pull` がTLS証明書エラーで失敗する**: プロキシCA証明書が未登録です。「2-3」を実施し、`wsl --shutdown` 後に再試行してください。
- **`407 Proxy Authentication Required`**: プロキシの資格情報が誤っています。パスワードのURLエンコード漏れ（`@` → `%40` 等）を確認してください。
- **aptだけ失敗する**: aptは環境変数を参照しません。「2-2」の設定を確認してください。
- **`podman compose` がWindows側の `docker-compose`（`/mnt/c/...`）を実行して失敗する**: compose providerの探索がWindows側PATHのバイナリを拾っています。「3. compose providerの固定」を実施してください。Windows側のDocker Desktopが不要であればアンインストールを推奨します（有償ライセンス制約により利用不可のため）。
- **`/etc/wsl.conf` の変更が効かない**: PowerShellから `wsl --shutdown` を実行し、WSLを完全再起動してください。
- **ヘルスチェックが動かない・コンテナ状態が `starting` のまま**: systemdが無効の可能性があります。「1」のsystemd確認を実施してください。
