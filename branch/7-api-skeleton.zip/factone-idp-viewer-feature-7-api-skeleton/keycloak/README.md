# Keycloak構成管理

Keycloakのrealm定義をconfig-as-codeで管理するディレクトリです。

## 暫定運用ルール

realm設計（realm分離 or 単一realm+テナントクレーム）は未確定（Q-IDPV-12）のため、確定までは本READMEの暫定運用のみとします。realm設計ドキュメントは確定後に `docs/architecture/` へ作成します。

- **realm定義JSON（`realm/` 配下）を構成管理の正とします。** Keycloak管理コンソールでの手動変更は永続化せず、変更はJSONを編集して再投入します。
- 投入方法: 起動時の `--import-realm` で `realm/` 配下のJSONが自動投入されます（ローカルは `compose.yaml`、Azureも同方式の予定）。
- 既存realmがある場合、`--import-realm` は既定でスキップされます。定義変更を反映するには realm を削除して再起動するか、ローカルではデータボリュームを初期化してください（手順は `docs/develop-guide/local-stack.md`）。

## シークレット非含有ルール

- **realm JSONにシークレット（クライアントシークレット・パスワード等）を含めないでください。**
- シークレットが必要な項目はプレースホルダ+環境変数注入とします（ローカル: `.env`、Azure: Key Vault参照）。
- 現在の初版realm定義は最小構成（realm本体のみ）です。クライアント・ロール・テストユーザーの定義は認証統合の実装時に拡充します。
