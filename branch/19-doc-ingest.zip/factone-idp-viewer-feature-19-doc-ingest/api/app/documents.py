"""文書登録API（IF-01の受付部分）。

冪等性（COM-02）: 同一文書ID・同一内容の再送は200、内容不一致は409。
文書IDは呼出側採番（COM-01）で、SaaS内では採番・解決しない。
"""

import hashlib
from datetime import UTC, datetime
from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
)
from pydantic import BaseModel
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.auth import CurrentUser
from app.blob import BlobStorage
from app.config import Settings
from app.db import get_db_session
from app.models import Document, DocumentType

router = APIRouter()


class DocumentResponse(BaseModel):
    document_id: str
    tenant_id: str
    document_type: DocumentType
    content_sha256: str
    received_at: datetime


def _to_response(doc: Document) -> DocumentResponse:
    return DocumentResponse(
        document_id=doc.document_id,
        tenant_id=doc.tenant_id,
        document_type=DocumentType(doc.document_type),
        content_sha256=doc.content_sha256,
        received_at=doc.received_at,
    )


@router.post(
    "/api/documents",
    response_model=DocumentResponse,
    status_code=201,
    responses={200: {"model": DocumentResponse}},
)
async def register_document(
    request: Request,
    response: Response,
    _user: CurrentUser,
    document_id: Annotated[str, Form(min_length=1, max_length=255)],
    document_type: Annotated[DocumentType, Form()],
    file: UploadFile,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentResponse:
    content = await file.read()
    if file.content_type != "application/pdf" or not content.startswith(b"%PDF"):
        raise HTTPException(status_code=415, detail="Only PDF files are accepted")

    settings: Settings = request.app.state.settings
    blob_storage: BlobStorage = request.app.state.blob_storage
    sha256 = hashlib.sha256(content).hexdigest()

    existing = session.get(Document, document_id)
    if existing is not None:
        return _respond_for_existing(response, existing, sha256, document_type)

    blob_ref = f"{settings.tenant_id}/{document_id}.pdf"
    document = Document(
        document_id=document_id,
        tenant_id=settings.tenant_id,
        document_type=document_type.value,
        blob_ref=blob_ref,
        content_sha256=sha256,
        received_at=datetime.now(UTC),
    )
    blob_storage.save(blob_ref, content)
    session.add(document)
    try:
        session.commit()
    except IntegrityError:
        # 同時登録の競合。既存行と突き合わせて冪等判定へフォールバック
        session.rollback()
        existing = session.get(Document, document_id)
        if existing is None:
            raise
        return _respond_for_existing(response, existing, sha256, document_type)
    return _to_response(document)


def _respond_for_existing(
    response: Response, existing: Document, sha256: str, document_type: DocumentType
) -> DocumentResponse:
    if (
        existing.content_sha256 == sha256
        and existing.document_type == document_type.value
    ):
        # 冪等再送: 既定の201を200へ差し替える
        response.status_code = 200
        return _to_response(existing)
    raise HTTPException(
        status_code=409,
        detail="Document ID already registered with different content",
    )
