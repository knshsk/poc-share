"""Blob保存の境界アダプタ。

外部ストレージ（Azure Blob）への依存をProtocolで分離し、テスト・ローカル開発では差し替える。
"""

from pathlib import Path
from typing import Protocol


class BlobStorage(Protocol):
    """文書バイナリの保存境界。refは相対パス形式（例: {tenant_id}/{document_id}.pdf）。"""

    def save(self, ref: str, data: bytes) -> None: ...


class LocalFileBlobStorage:
    """ローカルファイルシステム保存（ローカル開発用）。"""

    def __init__(self, base_dir: Path) -> None:
        self._base_dir = base_dir

    def save(self, ref: str, data: bytes) -> None:
        path = self._base_dir / ref
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


class AzureBlobStorage:
    """Azure Blob Storage保存（Managed ID認証。Blobは全面非公開・APIプロキシ方式）。"""

    def __init__(self, account_url: str, container: str) -> None:
        from azure.identity import DefaultAzureCredential
        from azure.storage.blob import BlobServiceClient

        service = BlobServiceClient(account_url, credential=DefaultAzureCredential())
        self._container = service.get_container_client(container)

    def save(self, ref: str, data: bytes) -> None:
        self._container.upload_blob(name=ref, data=data, overwrite=False)


def create_blob_storage(
    backend: str, local_dir: str, account_url: str, container: str
) -> BlobStorage:
    if backend == "azure":
        return AzureBlobStorage(account_url, container)
    return LocalFileBlobStorage(Path(local_dir))
