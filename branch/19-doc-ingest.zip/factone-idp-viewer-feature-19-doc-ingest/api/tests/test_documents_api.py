"""文書登録APIの統合テスト（実PostgreSQLコンテナ接続）。

事前に `podman compose up -d postgres` が必要。テスト専用DB（factone_test）を自動作成する。
"""

import time
from collections.abc import Iterator
from typing import Any

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text

from app.auth import StaticKeySource
from app.blob import BlobStorage
from app.config import Settings
from app.db import create_session_factory
from app.main import create_app

TEST_DATABASE_URL = (
    "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone_test"
)
ADMIN_DATABASE_URL = (
    "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone"
)

PDF_BYTES = b"%PDF-1.7 minimal test pdf content"
PDF_BYTES_OTHER = b"%PDF-1.7 different content"


class InMemoryBlobStorage:
    """テスト用のBlobStorageフェイク。"""

    def __init__(self) -> None:
        self.saved: dict[str, bytes] = {}

    def save(self, ref: str, data: bytes) -> None:
        self.saved[ref] = data


@pytest.fixture(scope="session")
def test_database_url() -> str:
    admin_engine = create_engine(ADMIN_DATABASE_URL, isolation_level="AUTOCOMMIT")
    with admin_engine.connect() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM pg_database WHERE datname = 'factone_test'")
        ).scalar()
        if not exists:
            conn.execute(text("CREATE DATABASE factone_test"))
    admin_engine.dispose()

    from alembic import command
    from alembic.config import Config

    config = Config("alembic.ini")
    config.cmd_opts = None
    config.set_main_option("script_location", "migrations")
    # env.py が -x database_url を参照するため、属性として注入する
    config.attributes["database_url"] = TEST_DATABASE_URL
    command.upgrade(config, "head")
    return TEST_DATABASE_URL


@pytest.fixture(scope="module")
def signing_key() -> RSAPrivateKey:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def make_token(key: RSAPrivateKey) -> str:
    claims: dict[str, Any] = {
        "iss": "http://localhost:8080/realms/factone",
        "aud": "factone-api",
        "sub": "integration-client",
        "exp": int(time.time()) + 300,
    }
    return jwt.encode(claims, key, algorithm="RS256")


@pytest.fixture
def blob_storage() -> InMemoryBlobStorage:
    return InMemoryBlobStorage()


@pytest.fixture
def doc_client(
    test_database_url: str,
    signing_key: RSAPrivateKey,
    blob_storage: BlobStorage,
) -> Iterator[TestClient]:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE documents"))
        conn.commit()

    settings = Settings(_env_file=None, database_url=test_database_url)  # type: ignore[call-arg]
    app = create_app(
        settings=settings,
        key_source=StaticKeySource(signing_key.public_key()),
        session_factory=create_session_factory(engine),
        blob_storage=blob_storage,
    )
    client = TestClient(app)
    client.headers["Authorization"] = f"Bearer {make_token(signing_key)}"
    yield client
    engine.dispose()


def post_document(
    client: TestClient,
    document_id: str = "doc-001",
    document_type: str = "quote",
    content: bytes = PDF_BYTES,
    filename: str = "test.pdf",
    content_type: str = "application/pdf",
) -> Any:
    return client.post(
        "/api/documents",
        data={"document_id": document_id, "document_type": document_type},
        files={"file": (filename, content, content_type)},
    )


def test_register_new_document_returns_201(
    doc_client: TestClient, blob_storage: InMemoryBlobStorage
) -> None:
    """新規文書の登録が201となり、Blob保存とメタデータ返却が行われることを確認する。"""
    response = post_document(doc_client)

    assert response.status_code == 201
    body = response.json()
    assert body["document_id"] == "doc-001"
    assert body["document_type"] == "quote"
    assert body["tenant_id"] == "default"
    assert "default/doc-001.pdf" in blob_storage.saved


def test_idempotent_resend_returns_200(doc_client: TestClient) -> None:
    """同一文書ID・同一内容の再送が200（冪等）となることを確認する。"""
    first = post_document(doc_client)
    second = post_document(doc_client)

    assert first.status_code == 201
    assert second.status_code == 200
    assert second.json()["document_id"] == "doc-001"


def test_same_id_different_content_returns_409(doc_client: TestClient) -> None:
    """同一文書IDで内容が異なる登録が409となることを確認する。"""
    post_document(doc_client)

    response = post_document(doc_client, content=PDF_BYTES_OTHER)

    assert response.status_code == 409


def test_same_id_different_type_returns_409(doc_client: TestClient) -> None:
    """同一文書ID・同一内容でも文書種別が異なる登録は409となることを確認する。"""
    post_document(doc_client)

    response = post_document(doc_client, document_type="order_project")

    assert response.status_code == 409


def test_non_pdf_content_returns_415(doc_client: TestClient) -> None:
    """PDF以外のファイルが415となることを確認する。"""
    response = post_document(
        doc_client,
        content=b"not a pdf",
        filename="test.txt",
        content_type="text/plain",
    )

    assert response.status_code == 415


def test_invalid_document_type_returns_422(doc_client: TestClient) -> None:
    """不正な文書種別が422となることを確認する。"""
    response = post_document(doc_client, document_type="invalid-type")

    assert response.status_code == 422


def test_register_requires_auth(
    test_database_url: str, signing_key: RSAPrivateKey, blob_storage: BlobStorage
) -> None:
    """トークンなしの登録が401となることを確認する。"""
    engine = create_engine(test_database_url)
    settings = Settings(_env_file=None, database_url=test_database_url)  # type: ignore[call-arg]
    app = create_app(
        settings=settings,
        key_source=StaticKeySource(signing_key.public_key()),
        session_factory=create_session_factory(engine),
        blob_storage=blob_storage,
    )
    client = TestClient(app)

    response = post_document(client)

    assert response.status_code == 401
    engine.dispose()
