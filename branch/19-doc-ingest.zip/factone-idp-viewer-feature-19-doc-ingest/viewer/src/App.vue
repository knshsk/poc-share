<script setup lang="ts">
import { onMounted, ref } from 'vue'

import { apiClient } from './api/client'
import { useAuthStore } from './auth/store'

const appName = 'FactONE Viewer'
const auth = useAuthStore()
const me = ref<string | null>(null)

onMounted(async () => {
  // ルーター未導入のため、コールバックURLはパスで判定して処理する
  if (window.location.pathname === '/callback') {
    await auth.handleCallback()
    window.history.replaceState({}, '', '/')
  }
})

async function fetchMe(): Promise<void> {
  const { data, error } = await apiClient.GET('/api/me')
  me.value = error ? 'APIエラー' : JSON.stringify(data)
}
</script>

<template>
  <v-app>
    <v-main>
      <v-container>
        <h1>{{ appName }}</h1>
        <template v-if="auth.isAuthenticated">
          <p>ログイン中: {{ auth.username }}</p>
          <p v-if="me">/api/me: {{ me }}</p>
          <v-btn class="mr-2" @click="fetchMe">API呼出</v-btn>
          <v-btn @click="auth.logout">ログアウト</v-btn>
        </template>
        <template v-else>
          <v-btn @click="auth.login">ログイン</v-btn>
        </template>
      </v-container>
    </v-main>
  </v-app>
</template>
