<script setup lang="ts">
// 値の状態表示（キー項目の状態列・明細の詳細欄で共用）。要確認は警告、修正済は鉛筆のアイコンを文言の前に置く。
// 配置（揃え・高さ）は親が決める
import { PhPencilSimple, PhWarning } from '@phosphor-icons/vue'

import type { FieldStatus } from '../utils/fieldStatus'

defineProps<{ status: FieldStatus }>()
</script>

<template>
  <span class="field-status" :class="`field-status--${status.kind}`">
    <PhWarning v-if="status.kind === 'low'" :size="14" aria-hidden="true" />
    <PhPencilSimple
      v-if="status.kind === 'corrected'"
      :size="14"
      aria-hidden="true"
    />
    {{ status.text }}
  </span>
</template>

<style scoped>
.field-status {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  white-space: nowrap;
}

.field-status--ok,
.field-status--empty {
  color: rgb(var(--v-theme-secondary));
}

.field-status--low {
  color: rgb(var(--v-theme-warning));
  font-weight: 500;
}

.field-status--corrected,
.field-status--draft {
  color: rgb(var(--v-theme-primary));
}

.field-status--draft {
  font-weight: 500;
}
</style>
