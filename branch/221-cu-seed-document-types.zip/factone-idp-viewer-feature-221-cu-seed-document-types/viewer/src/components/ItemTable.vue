<script setup lang="ts">
// 読取結果タブの明細（array 型の項目）1 件。ResultTable と同じ罫線付きの表に値の入力欄を並べ、状態はセル内の
// 印（下書きの塗り・修正済の三角・未読取のプレースホルダ・低確信度の警告アイコン）で示す。状態の文言・読取値・
// 正規化ヒントは、表の下の詳細欄に選択中の値の分だけ出す。親（ResultEditor）が項目ごとの props に分けて渡す
import { PhWarning } from '@phosphor-icons/vue'
import { computed, useId } from 'vue'

import { useBubble } from '../mediator/bubble'
import { fieldStatus } from '../utils/fieldStatus'
import { normalizationHint } from '../utils/normalize'
import {
  CORRECTION_MAX_LENGTH,
  itemId,
  itemKey,
  originalValue,
  type FieldResult,
  type ItemField,
} from '../utils/runs'
import { columnTemplate } from '../utils/table'
import FieldStatusBadge from './FieldStatusBadge.vue'

const props = defineProps<{
  item: ItemField
  draftItems: Record<string, string | null>
  // 保存済みの人手修正がある値（itemKey "field:index:property"）
  correctedItems: ReadonlySet<string>
  activeId: string | null
}>()

const bubble = useBubble()
// 表の名前（role="group" のラベル）と、読み上げ用の説明・ヒントの要素 id の接頭辞
const uid = useId()
const hintId = `${uid}-hint`

const rows = computed(() =>
  props.item.rows.map((row, r) =>
    props.item.columns.map((column, c) => {
      const leaf: FieldResult | undefined = row[column.key]
      const id = itemId(props.item.key, r, column.key)
      const key = itemKey(props.item.key, r, column.key)
      const original = originalValue(leaf)
      const read = leaf?.value ?? null
      const drafted = key in props.draftItems
      const value = drafted ? (props.draftItems[key] ?? '') : (original ?? '')
      const base = {
        corrected: props.correctedItems.has(key),
        value: read,
        confidence: leaf?.confidence ?? null,
      }
      const status = fieldStatus({ draft: drafted, ...base })
      const raw = read !== original ? read : null
      const hint = normalizationHint(column.type, value)
      const active = props.activeId === id
      // 読み上げ用の補足（状態・読取値）。印は装飾なので、文言を hidden の要素に置いて aria-describedby で参照する
      const note = [status.text, raw != null ? `読取値 ${raw}` : '']
        .filter(Boolean)
        .join('、')
      const noteId = `${uid}-note-${r}-${c}`
      return {
        row: r,
        column,
        id,
        value,
        // 列幅の計算用の元の値（未読取は空）
        original: original ?? '',
        placeholder: read == null ? '（値なし）' : undefined,
        // 読取値。入力欄の元値と異なるときだけ（キー項目と同じ）
        raw,
        hint,
        status,
        // 下書きに依らない低確信度（警告アイコン・列幅用。入力を始めてもアイコンと余白を保ち、文字をずらさない）
        low: fieldStatus({ draft: false, ...base }).kind === 'low',
        active,
        note,
        noteId,
        // 選択中の値は、詳細欄の正規化ヒントも参照する
        describedBy:
          [note && noteId, active && hint && hintId]
            .filter(Boolean)
            .join(' ') || undefined,
      }
    }),
  ),
)

// 列幅は見出しと元の値だけで決める（下書きを含めると入力中に列が揺れる。ResultTable と同じ）。先頭は行番号の列。
// 低確信度の値は警告アイコンの分（半角 3 文字）を足して数える。未読取は空として数える（プレースホルダで列を広げない）
const columns = computed(
  () =>
    `40px ${columnTemplate(props.item.columns.length, (c) => [
      props.item.columns[c]!.label,
      ...rows.value.map((cells) =>
        cells[c]!.low ? `${cells[c]!.original}   ` : cells[c]!.original,
      ),
    ])}`,
)

const active = computed(
  () => rows.value.flat().find((cell) => cell.active) ?? null,
)

function onInput(r: number, property: string, value: string): void {
  bubble({
    type: 'itemInput',
    field: props.item.key,
    index: r,
    property,
    value,
  })
}
</script>

<template>
  <div
    class="item-block"
    data-testid="item-table"
    role="group"
    :aria-labelledby="`${uid}-label`"
  >
    <!-- 見出しは区分のタイトルが兼ねるため、名前は hidden の要素から参照する -->
    <span :id="`${uid}-label`" hidden>{{ item.label }}</span>
    <!-- 列が多く最小幅を割るときだけ、表の中で横スクロールする。行番号の列は左に残す -->
    <div class="tbl-scroller">
      <div class="tbl" :style="{ '--tbl-columns': columns }">
        <div class="tbl-cell tbl-cell--header tbl-rownum" aria-hidden="true">
          行
        </div>
        <div
          v-for="column in item.columns"
          :key="column.key"
          class="tbl-cell tbl-cell--header"
          :class="{ 'tbl-cell--num': column.type === 'number' }"
          aria-hidden="true"
          data-testid="item-header"
        >
          {{ column.label }}
        </div>
        <template v-for="(cells, r) in rows" :key="r">
          <div class="tbl-cell tbl-rownum" aria-hidden="true">{{ r + 1 }}</div>
          <div
            v-for="cell in cells"
            :key="cell.column.key"
            class="tbl-cell"
            :class="{
              'tbl-cell--num': cell.column.type === 'number',
              'tbl-cell--draft': cell.status.kind === 'draft',
              'tbl-cell--corrected': cell.status.kind === 'corrected',
              'tbl-cell--low': cell.low,
              'target--active': cell.active,
            }"
            :data-target-id="cell.id"
            :title="cell.status.kind === 'corrected' ? '修正済' : undefined"
            data-testid="item-cell"
          >
            <PhWarning
              v-if="cell.low"
              :size="14"
              class="tbl-low"
              aria-hidden="true"
            />
            <input
              :value="cell.value"
              :placeholder="cell.placeholder"
              :aria-label="`${r + 1}行目 ${cell.column.label}`"
              :aria-current="cell.active ? 'true' : undefined"
              :aria-describedby="cell.describedBy"
              :maxlength="CORRECTION_MAX_LENGTH"
              size="1"
              data-testid="item-input"
              @input="
                (e) =>
                  onInput(
                    r,
                    cell.column.key,
                    (e.target as HTMLInputElement).value,
                  )
              "
              @focus="bubble({ type: 'targetFocus', id: cell.id })"
            />
            <span v-if="cell.note" :id="cell.noteId" hidden>{{
              cell.note
            }}</span>
          </div>
        </template>
      </div>
    </div>

    <!-- 選択中の値の詳細: 位置・状態（キー項目と同じ文言とアイコン）・読取値・正規化ヒント -->
    <div class="detail text-body-medium" data-testid="item-detail">
      <template v-if="active">
        <div class="detail-head">
          <span class="font-weight-medium"
            >{{ active.row + 1 }}行目・{{ active.column.label }}</span
          >
          <FieldStatusBadge :status="active.status" data-testid="item-status" />
        </div>
        <div
          v-if="active.raw != null"
          class="text-secondary"
          data-testid="item-raw"
        >
          読取値 {{ active.raw }}
        </div>
        <div
          v-if="active.hint"
          :id="hintId"
          class="d-flex align-center ga-1"
          :class="active.hint.ok ? 'text-secondary font-mono' : 'text-warning'"
          data-testid="item-hint"
        >
          <PhWarning v-if="!active.hint.ok" :size="14" aria-hidden="true" />
          {{ active.hint.text }}
        </div>
      </template>
      <p v-else class="text-secondary">値を選ぶと状態と読取値を表示します</p>
    </div>
  </div>
</template>

<style scoped>
/* 表の見た目は ResultTable.vue にそろえる（罫線の濃さ・行高・余白・下書き・修正済・選択中）。
   違いは、行番号の列・テキストの列見出し・低確信度の印・長い値の省略記号 */
.tbl-scroller {
  overflow-x: auto;
  /* scrollIntoView で入れたセルが、左に残る行番号の列に隠れないようにする */
  scroll-padding-left: 40px;
}

.tbl {
  --tbl-line: 1px solid rgba(var(--v-theme-on-surface), 0.56);
  display: grid;
  grid-template-columns: var(--tbl-columns);
  width: 100%;
  font-size: 0.875rem;
  border-left: var(--tbl-line);
}

.tbl::before {
  content: '';
  grid-column: 1 / -1;
  border-top: var(--tbl-line);
}

.tbl-cell {
  position: relative;
  min-width: 0;
  min-height: 32px;
  border-right: var(--tbl-line);
  border-bottom: var(--tbl-line);
}

.tbl-cell input {
  display: block;
  width: 100%;
  height: 32px;
  padding: 0 4px;
  border: 0;
  outline: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  text-overflow: ellipsis;
}

.tbl-cell input::placeholder {
  color: rgb(var(--v-theme-secondary));
  opacity: 1;
}

/* forced-colors では box-shadow が消えるため、透明の outline を置く（強制配色時だけ見える） */
.tbl-cell input:focus {
  outline: 2px solid transparent;
  outline-offset: -2px;
}

.tbl-cell--header {
  display: flex;
  align-items: center;
  padding: 4px;
  background: rgb(var(--v-theme-canvas));
  font-weight: 500;
  line-height: 1.3;
}

.tbl-cell--header.tbl-cell--num {
  justify-content: flex-end;
  text-align: right;
}

.tbl-cell--num input {
  text-align: right;
}

/* 未保存の下書き: 薄い塗り */
.tbl-cell--draft {
  background: rgba(var(--v-theme-primary), 0.08);
}

/* 保存済みの修正: 右上の三角印（装飾。読み上げは aria-describedby の「修正済」） */
.tbl-cell--corrected::after {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  border-style: solid;
  border-width: 0 8px 8px 0;
  border-color: transparent rgb(var(--v-theme-primary)) transparent transparent;
}

/* フォーカス中と、キャンバスと連動して選択中: 主色の 2px 枠 */
.tbl-cell:focus-within,
.tbl-cell.target--active {
  box-shadow: inset 0 0 0 2px rgb(var(--v-theme-primary));
}

/* 行番号の列: 横スクロールしても左に残す */
.tbl-rownum {
  position: sticky;
  left: 0;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgb(var(--v-theme-canvas));
}

/* 低確信度: セルの左端に警告アイコン（文言は詳細欄と読み上げ） */
.tbl-low {
  position: absolute;
  top: 9px;
  left: 4px;
  color: rgb(var(--v-theme-warning));
  pointer-events: none;
}

.tbl-cell--low input {
  padding-left: 22px;
}

/* 詳細欄 */
.detail {
  min-height: 56px;
  margin-top: 8px;
  padding: 6px 8px;
  border-radius: 4px;
  background: rgb(var(--v-theme-canvas));
}

.detail-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
</style>
