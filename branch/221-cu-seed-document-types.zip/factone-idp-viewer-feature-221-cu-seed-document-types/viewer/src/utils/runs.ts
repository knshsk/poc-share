import type { components } from '../api/schema'

export type IdpRun = components['schemas']['IdpRunResponse']
export type IdpRunSummary = components['schemas']['IdpRunSummary']
export type FieldResult = components['schemas']['FieldResult']
export type Corrections = components['schemas']['CorrectionRequest']
export type TableCell = components['schemas']['LayoutTableCell']
export type ItemsFieldResult = components['schemas']['ItemsFieldResult']

export const RUN_TYPE_LABEL: Record<IdpRunSummary['run_type'], string> = {
  initial: '初回',
  rerun: '再実行',
  corrected: '修正',
}

// 修正文字数の上限。サーバ側 CorrectionText（api/app/routers/idp_runs.py）の max_length と一致させる
export const CORRECTION_MAX_LENGTH = 2000

// キャンバス⇄右ペインの相互ハイライトで使う要素 ID（draft の cellKey "t:r:c" とは別物）
export const fieldId = (key: string): string => `field:${key}`
export const cellId = (table: number, row: number, col: number): string =>
  `cell:${table}:${row}:${col}`

// cellId の逆変換。セル以外の ID（field:…）は null
export function parseCellId(
  id: string,
): { table: number; row: number; column: number } | null {
  const m = /^cell:(\d+):(\d+):(\d+)$/.exec(id)
  return m
    ? { table: Number(m[1]), row: Number(m[2]), column: Number(m[3]) }
    : null
}

// 明細の値のハイライト ID。項目・プロパティのキーは ^[A-Za-z0-9_]{1,50}$ なので ':' で区切れる
export const itemId = (
  field: string,
  index: number,
  property: string,
): string => `item:${field}:${index}:${property}`

// キャンバス上の読取矩形。座標は DI 座標系（インチ）のまま。PageSvg の viewBox と同一単位
export interface OverlayRect {
  id: string
  kind: 'field' | 'cell'
  // アクセシブル名（<title>）。キー項目 = ラベル（無ければキー）、セル = 「表 n の r 行 c 列」、
  // 明細の値 = 「{項目ラベル} {n}行目 {プロパティラベル}」（行・列は 1 始まり）
  label: string
  x: number
  y: number
  width: number
  height: number
}

// DI polygon（x, y の交互配列）の外接矩形
export function polygonToRect(
  polygon: number[],
): Omit<OverlayRect, 'id' | 'kind' | 'label'> {
  const xs = polygon.filter((_, i) => i % 2 === 0)
  const ys = polygon.filter((_, i) => i % 2 === 1)
  const x = Math.min(...xs)
  const y = Math.min(...ys)
  return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y }
}

// 選択中の成功実行からページ番号ごとの矩形を作る。
// セル = polygon あり全件、キー項目・明細の値 = region あり・visible=true（hiddenKeys 外）・value 非 null。
// region / polygon は verbose=true の応答にだけ含まれる。無ければ矩形なし。
// セル → 明細の値 → キー項目の順に並べる（重なり時に後のものが前面）。失敗実行・未選択は空
export function overlayRectsByPage(
  run: IdpRun | null,
  hiddenKeys: ReadonlySet<string>,
): Map<number, OverlayRect[]> {
  const byPage = new Map<number, OverlayRect[]>()
  if (!run || run.status !== 'succeeded') return byPage
  const push = (page: number, rect: OverlayRect): void => {
    const list = byPage.get(page) ?? []
    list.push(rect)
    byPage.set(page, list)
  }
  ;(run.layout_tables ?? []).forEach((table, t) => {
    for (const cell of table.cells) {
      if (!cell.polygon || cell.polygon.length < 4 || cell.page_number == null)
        continue
      push(cell.page_number, {
        id: cellId(t, cell.row_index, cell.column_index),
        kind: 'cell',
        label: `表 ${t + 1} の ${cell.row_index + 1} 行 ${cell.column_index + 1} 列`,
        ...polygonToRect(cell.polygon),
      })
    }
  })
  for (const key of Object.keys(run.fields ?? {})) {
    const field = itemsField(run, key)
    if (!field || hiddenKeys.has(key)) continue
    field.items.forEach((row, i) => {
      for (const [property, leaf] of Object.entries(row)) {
        const region = leaf.region
        if (!region || region.polygon.length < 4 || leaf.value == null) continue
        push(region.page_number, {
          id: itemId(key, i, property),
          kind: 'field',
          label: `${field.label ?? key} ${i + 1}行目 ${field.property_labels?.[property] ?? property}`,
          ...polygonToRect(region.polygon),
        })
      }
    })
  }
  for (const key of Object.keys(run.fields ?? {})) {
    const field = scalarField(run, key)
    const region = field?.region
    if (
      !field ||
      !region ||
      region.polygon.length < 4 ||
      hiddenKeys.has(key) ||
      field.value == null
    )
      continue
    push(region.page_number, {
      id: fieldId(key),
      kind: 'field',
      label: field.label ?? key,
      ...polygonToRect(region.polygon),
    })
  }
  return byPage
}

// 表のセルの下書きキー（table_index:row_index:column_index）。ハイライト ID の cellId とは別物
export function cellKey(t: number, r: number, c: number): string {
  return `${t}:${r}:${c}`
}

// 明細の値の下書きキー（field:index:property）。ハイライト ID の itemId とは別物
export function itemKey(
  field: string,
  index: number,
  property: string,
): string {
  return `${field}:${index}:${property}`
}

// スカラーの項目の読取結果。array 型の項目（明細）は itemsField で扱うため undefined を返す
export function scalarField(run: IdpRun, key: string): FieldResult | undefined {
  const field = run.fields?.[key]
  return field && !('items' in field) ? field : undefined
}

// array 型の項目（明細）の読取結果。スカラーの項目は undefined
export function itemsField(
  run: IdpRun,
  key: string,
): ItemsFieldResult | undefined {
  const field = run.fields?.[key]
  return field && 'items' in field ? field : undefined
}

// 現在の文書種別設定の順に並べる（応答の fields は JSONB 由来でキー順が設定順にならない）。
// 設定に無いキー（設定変更後）は末尾、visible=false は除く
function inConfigOrder(
  keys: string[],
  fieldDefs: { key: string; visible: boolean }[],
): string[] {
  const configured = fieldDefs.map((f) => f.key).filter((k) => keys.includes(k))
  const hidden = new Set(fieldDefs.filter((f) => !f.visible).map((f) => f.key))
  return [...configured, ...keys.filter((k) => !configured.includes(k))].filter(
    (k) => !hidden.has(k),
  )
}

// 表示対象のキー項目（スカラーの項目だけ）
export function visibleFieldKeys(
  run: IdpRun,
  fieldDefs: { key: string; visible: boolean }[],
): string[] {
  return inConfigOrder(
    Object.keys(run.fields ?? {}).filter(
      (k) => scalarField(run, k) !== undefined,
    ),
    fieldDefs,
  )
}

export interface ItemColumn {
  key: string
  label: string
  type: 'string' | 'number' | 'date'
}

export interface ItemField {
  key: string
  label: string
  columns: ItemColumn[]
  rows: Record<string, FieldResult>[]
}

type ItemFieldDef = {
  key: string
  visible: boolean
  properties?: { key: string; type: ItemColumn['type'] }[] | null
}

// 表示対象の明細: 項目の並びはキー項目と同じ規則。列は設定の properties の順で、実行結果に無いプロパティは
// 出さず、設定に無いプロパティ（設定変更後）は末尾に string 型で置く。ラベルは実行時の値、無ければキー
export function itemFields(
  run: IdpRun,
  fieldDefs: ItemFieldDef[],
): ItemField[] {
  const keys = Object.keys(run.fields ?? {}).filter((k) => itemsField(run, k))
  return inConfigOrder(keys, fieldDefs).map((key) => {
    const field = itemsField(run, key)!
    const labels = field.property_labels ?? {}
    // API は各行にスキーマのプロパティを全部そろえるため、列は先頭行のキーで決まる（0 件の項目は表を出さない）
    const present = new Set(Object.keys(field.items[0] ?? {}))
    const configured = (
      fieldDefs.find((f) => f.key === key)?.properties ?? []
    ).filter((p) => present.has(p.key))
    const extra = [...present].filter(
      (k) => !configured.some((p) => p.key === k),
    )
    return {
      key,
      label: field.label ?? key,
      columns: [
        ...configured.map((p) => ({
          key: p.key,
          label: labels[p.key] ?? p.key,
          type: p.type,
        })),
        ...extra.map((k) => ({
          key: k,
          label: labels[k] ?? k,
          type: 'string' as const,
        })),
      ],
      rows: field.items,
    }
  })
}

// 入力欄の元値: 正規化値（文字列化）、無ければエンジンの読取値。差分判定もこの値を基準にする
export function originalValue(
  leaf: FieldResult | null | undefined,
): string | null {
  const normalized = leaf?.normalized_value
  if (normalized != null) return String(normalized)
  return leaf?.value ?? null
}

// cellInput ハンドラが入力ごとに 1 回呼ぶ線形探索（描画側は ResultTable が持つ Map を使うため対象外）
export function cellAt(
  run: IdpRun,
  t: number,
  r: number,
  c: number,
): TableCell | null {
  return (
    run.layout_tables?.[t]?.cells.find(
      (x) => x.row_index === r && x.column_index === c,
    ) ?? null
  )
}
