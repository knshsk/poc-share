import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import DocumentPicker from '../src/components/DocumentPicker.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { DocumentVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import DocumentView from '../src/views/DocumentView.vue'
import { canvasVm, pickerVm, stubResizeObserver, workPanelVm } from './fixtures'

const bubble = vi.fn()

function mountView(over: Partial<DocumentVm> = {}) {
  return mount(DocumentView, {
    props: {
      vm: {
        phase: 'ready',
        error: null,
        picker: pickerVm({ open: false }),
        canvas: canvasVm(),
        workPanel: workPanelVm(),
        ...over,
      },
    },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// ダイアログ内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentView', () => {
  // 文書なし（empty / registering）は空状態を出し、「文書を開く」で文書選択ダイアログを開く。パネルは出さない
  it('empty / registering では空状態を表示し、「文書を開く」で openDocumentPicker を bubble する', async () => {
    for (const phase of ['empty', 'registering'] as const) {
      const wrapper = mountView({ phase, canvas: null, workPanel: null })
      expect(wrapper.get('[data-testid="document-empty"]').text()).toContain(
        '表示中の文書はありません',
      )
      expect(wrapper.findComponent(WorkPanel).exists()).toBe(false)
      expect(wrapper.findComponent(DocumentCanvas).exists()).toBe(false)
      await wrapper.get('[data-testid="document-empty-open"]').trigger('click')
      expect(bubble).toHaveBeenCalledWith({ type: 'openDocumentPicker' })
      bubble.mockClear()
      wrapper.unmount()
    }
  })

  // 文書選択ダイアログは phase に関係なく置く（表示中・取得失敗中もヘッダから開ける）。開閉は vm.picker.open
  it('どの phase でも DocumentPicker に vm.picker を渡す', () => {
    for (const phase of [
      'empty',
      'registering',
      'loading',
      'error',
      'ready',
    ] as const) {
      const picker = pickerVm({ documentId: 'doc-1' })
      const panes = phase === 'ready' ? {} : { canvas: null, workPanel: null }
      const wrapper = mountView({ phase, picker, ...panes })
      expect(wrapper.findComponent(DocumentPicker).props('vm')).toEqual(picker)
      wrapper.unmount()
    }
  })

  // 取得中は 2 ペインの枠を出し、キャンバスと右ペインのそれぞれ中央にスピナーを出す
  it('loading では両ペインにスピナーを表示する', () => {
    const wrapper = mountView({
      phase: 'loading',
      canvas: null,
      workPanel: null,
    })
    expect(wrapper.findAll('[data-testid="loading-spinner"]')).toHaveLength(2)
    expect(wrapper.find('.v-skeleton-loader').exists()).toBe(false)
    expect(wrapper.find('.canvas-loading').exists()).toBe(true)
    expect(wrapper.find('[data-testid="document-empty"]').exists()).toBe(false)
  })

  // 文書取得失敗時はエラーstateと再試行ボタンを表示し、再試行で retryLoad を bubble する
  it('error ではエラーと再試行を表示し、再試行で retryLoad を bubble する', async () => {
    const wrapper = mountView({
      phase: 'error',
      error: '文書を取得できませんでした',
      canvas: null,
      workPanel: null,
    })
    expect(wrapper.get('[data-testid="document-error"]').text()).toContain(
      '文書を取得できませんでした',
    )
    await wrapper.get('[data-testid="document-retry"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'retryLoad' })
  })

  // 表示成功時に DocumentCanvas と WorkPanel へそれぞれの vm スライスを渡す
  it('ready では DocumentCanvas と WorkPanel に vm を渡す', () => {
    const canvas = canvasVm()
    const workPanel = workPanelVm({ shareable: true })
    const wrapper = mountView({ canvas, workPanel })
    expect(wrapper.findComponent(DocumentCanvas).props('vm')).toEqual(canvas)
    expect(wrapper.findComponent(WorkPanel).props('vm')).toEqual(workPanel)
    expect(wrapper.find('[data-testid="tab-urls"]').exists()).toBe(true)
  })

  describe('右ペインの幅', () => {
    // ResizeObserver の差し替えは、assert が途中で落ちても次のテストへ漏らさない
    afterEach(() => vi.unstubAllGlobals())

    // jsdom は要素サイズを持たないため、レイアウト幅（上限の計算元）を差し替える
    function mountSized(layoutWidth: number) {
      const wrapper = mountView()
      const layout = wrapper.get('.document-layout').element
      Object.defineProperty(layout, 'clientWidth', {
        value: layoutWidth,
        configurable: true,
      })
      layout.getBoundingClientRect = () =>
        ({ left: 0, right: layoutWidth }) as DOMRect
      return wrapper
    }
    const splitter = (wrapper: ReturnType<typeof mountView>) =>
      wrapper.get('[data-testid="pane-splitter"]')
    const width = (wrapper: ReturnType<typeof mountView>) =>
      splitter(wrapper).attributes('aria-valuenow')

    // .document-layout の clientWidth を差し替えてから、対応する ResizeObserver コールバックを発火する
    function resizeLayout(
      wrapper: ReturnType<typeof mountView>,
      observed: ReturnType<typeof stubResizeObserver>,
      layoutWidth: number,
    ): void {
      const layoutEl = wrapper.get('.document-layout').element
      Object.defineProperty(layoutEl, 'clientWidth', {
        value: layoutWidth,
        configurable: true,
      })
      observed.get(layoutEl)?.([])
    }

    it('既定は 528px で、境界は separator として操作できる', () => {
      const wrapper = mountSized(1440)
      const s = splitter(wrapper)
      expect(s.attributes()).toMatchObject({
        role: 'separator',
        'aria-orientation': 'vertical',
        'aria-label': '右ペインの幅',
        'aria-controls': 'work-pane',
        'aria-valuenow': '528',
        'aria-valuemin': '400',
        tabindex: '0',
      })
      expect(wrapper.find('#work-pane').exists()).toBe(true)
      // 幅は CSS 変数で渡す（列定義は stylesheet 側）
      expect(wrapper.get('.document-layout').attributes('style')).toContain(
        '--pane-width: 528px',
      )
    })

    // mount 直後（操作なし）でも watch(layout) の初回発火で上限を計測する
    it('mount 直後に aria-valuemax をレイアウト幅から計測する', async () => {
      const wrapper = mountSized(1440)
      await wrapper.vm.$nextTick()
      expect(splitter(wrapper).attributes('aria-valuemax')).toBe('1114')
    })

    it('←で広げ、→で狭め、ダブルクリックで既定に戻す', async () => {
      const wrapper = mountSized(1440)
      await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('544')
      await splitter(wrapper).trigger('keydown', { key: 'ArrowRight' })
      await splitter(wrapper).trigger('keydown', { key: 'ArrowRight' })
      expect(width(wrapper)).toBe('512')
      await splitter(wrapper).trigger('dblclick')
      expect(width(wrapper)).toBe('528')
    })

    // Alt+←/→ はブラウザの戻る/進むのショートカットのため奪わない（.exact で修飾キー付きは無視する）
    it('Alt+← では幅を変えない（ブラウザの戻る/進むを奪わない）', async () => {
      const wrapper = mountSized(1440)
      await splitter(wrapper).trigger('keydown', {
        key: 'ArrowLeft',
        altKey: true,
      })
      expect(width(wrapper)).toBe('528')

      // 幅が変わらないだけでは、.prevent.exact の順（exact 判定より先に preventDefault が走る）に
      // 並べ替えても検出できない。実イベントの defaultPrevented を境界で直接確認する
      const event = new KeyboardEvent('keydown', {
        key: 'ArrowLeft',
        altKey: true,
        cancelable: true,
        bubbles: true,
      })
      splitter(wrapper).element.dispatchEvent(event)
      expect(event.defaultPrevented).toBe(false)
    })

    it('最小 400px と、キャンバスが 320px 残る幅で止まる', async () => {
      const wrapper = mountSized(1000) // 上限 = 1000 - 326 = 674
      for (let i = 0; i < 20; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowRight' })
      expect(width(wrapper)).toBe('400')
      for (let i = 0; i < 40; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('674')
      expect(splitter(wrapper).attributes('aria-valuemax')).toBe('674')
    })

    // 幅を広げた後でウィンドウを縮めたら、実際の幅（shownWidth）は上限へ丸める（CSS の min() で実効幅だけが縮み、
    // aria-valuenow と→キーの起点が実際の幅と食い違うのを防ぐ）。状態自体は縮めない（次の 2 件を参照）
    it('レイアウトが縮んだら現在幅を上限へ丸める', async () => {
      const observed = stubResizeObserver()
      const wrapper = mountSized(1440)
      for (let i = 0; i < 40; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('1114')

      resizeLayout(wrapper, observed, 1100)
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('774')
      expect(splitter(wrapper).attributes('aria-valuemax')).toBe('774')
    })

    // 境界に一度も触れていない（操作していない）間は状態（利用者が決めた幅）を書き換えない。
    // レイアウトを縮めて（960px 以下の縦積みになる幅も含む）から広げ直すと既定 528 に戻る
    it('未操作なら、レイアウトが縮んでも既定幅の状態は変わらない（広げ直すと既定に戻る）', async () => {
      const observed = stubResizeObserver()
      const wrapper = mountSized(1536)
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('528')

      resizeLayout(wrapper, observed, 768) // 960px 以下（縦積み。境界は非表示）
      await wrapper.vm.$nextTick()

      resizeLayout(wrapper, observed, 1536)
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('528')
    })

    // 操作で変えた幅も同様に状態を保つ。縮めている間は上限に従い、広げ直すと操作した幅に戻る
    it('操作で変えた幅も、レイアウトを広げ直すと元に戻る', async () => {
      const observed = stubResizeObserver()
      const wrapper = mountSized(1440) // 上限 1114
      for (let i = 0; i < 11; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('704') // 528 + 16 * 11

      resizeLayout(wrapper, observed, 1000) // 上限 674 に縮む
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('674')

      resizeLayout(wrapper, observed, 1440) // 上限 1114 に戻る
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('704')
    })

    // ドラッグ: 幅 = レイアウト右端 − ポインタ位置 − 境界の半分。離したら追従をやめる
    it('ドラッグでポインタ位置に合わせて幅を変える', async () => {
      const wrapper = mountSized(1440)
      const el = splitter(wrapper).element as HTMLElement
      el.setPointerCapture = vi.fn()
      await splitter(wrapper).trigger('pointerdown', { pointerId: 1 })
      expect(el.setPointerCapture).toHaveBeenCalledWith(1)
      el.dispatchEvent(new MouseEvent('pointermove', { clientX: 800 }))
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('637')
      el.dispatchEvent(new Event('lostpointercapture'))
      el.dispatchEvent(new MouseEvent('pointermove', { clientX: 600 }))
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('637')
    })

    // 右・中ボタンではドラッグを開始しない（左ボタンだけ）。button は MouseEvent の getter-only
    // プロパティのため trigger() 後の代入では上書きできず、コンストラクタの init dict で渡す
    it('左ボタン以外の pointerdown ではドラッグを開始しない', () => {
      const wrapper = mountSized(1440)
      const el = splitter(wrapper).element as HTMLElement
      el.setPointerCapture = vi.fn()
      const down = new MouseEvent('pointerdown', { button: 2, bubbles: true })
      Object.defineProperty(down, 'pointerId', { value: 1 })
      el.dispatchEvent(down)
      expect(el.setPointerCapture).not.toHaveBeenCalled()
    })
  })
})
