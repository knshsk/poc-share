import { mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import ItemTable from '../src/components/ItemTable.vue'
import { BUBBLE } from '../src/mediator/bubble'
import { createAppVuetify } from '../src/plugins/vuetify'
import { itemFields } from '../src/utils/runs'
import { itemsFieldDefs, itemsRun } from './fixtures'

const bubble = vi.fn()
const item = itemFields(itemsRun, itemsFieldDefs)[0]!

type Props = InstanceType<typeof ItemTable>['$props']

function mountTable(over: Partial<Props> = {}, attachTo?: HTMLElement) {
  return mount(ItemTable, {
    props: {
      item,
      draftItems: {},
      correctedItems: new Set<string>(),
      activeId: null,
      ...over,
    } as Props,
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
    attachTo,
  })
}

const cellAt = (w: ReturnType<typeof mountTable>, r: number, p: string) =>
  w.get(`[data-target-id="item:LineItems:${r}:${p}"]`)
const inputAt = (w: ReturnType<typeof mountTable>, r: number, p: string) =>
  w.get(`[data-target-id="item:LineItems:${r}:${p}"] input`)
const byId = (w: ReturnType<typeof mountTable>, id: string) =>
  w.get(`[id="${id}"]`)

describe('ItemTable', () => {
  beforeEach(() => {
    bubble.mockClear()
  })

  it('列見出しをプロパティのラベルで並べ、行番号と元の値を出し、number 型を右寄せにする', () => {
    const wrapper = mountTable()
    expect(
      wrapper.findAll('[data-testid="item-header"]').map((h) => h.text()),
    ).toEqual(['品名', '数量', '単価'])
    expect(wrapper.findAll('.tbl-rownum').map((c) => c.text())).toEqual([
      '行',
      '1',
      '2',
    ])
    // 元の値は正規化値の文字列（無ければ読取値）
    expect(
      (inputAt(wrapper, 0, 'UnitPrice').element as HTMLInputElement).value,
    ).toBe('1180')
    expect(cellAt(wrapper, 0, 'Quantity').classes()).toContain('tbl-cell--num')
    expect(cellAt(wrapper, 0, 'ProductName').classes()).not.toContain(
      'tbl-cell--num',
    )
    expect(wrapper.get('[data-testid="item-table"]').attributes('role')).toBe(
      'group',
    )
  })

  it('未読取はプレースホルダ、低確信度は警告アイコン、修正済は三角印、下書きは塗り（下書きが修正済より優先）', () => {
    const wrapper = mountTable({
      correctedItems: new Set([
        'LineItems:1:UnitPrice',
        'LineItems:0:UnitPrice',
      ]),
      draftItems: { 'LineItems:0:UnitPrice': '1200' },
    })
    expect(inputAt(wrapper, 1, 'ProductName').attributes('placeholder')).toBe(
      '（値なし）',
    )
    const low = cellAt(wrapper, 0, 'Quantity')
    expect(low.classes()).toContain('tbl-cell--low')
    expect(low.find('.tbl-low').exists()).toBe(true)
    const corrected = cellAt(wrapper, 1, 'UnitPrice')
    expect(corrected.classes()).toContain('tbl-cell--corrected')
    expect(corrected.attributes('title')).toBe('修正済')
    const drafted = cellAt(wrapper, 0, 'UnitPrice')
    expect(drafted.classes()).toContain('tbl-cell--draft')
    expect(drafted.classes()).not.toContain('tbl-cell--corrected')
    expect(
      (inputAt(wrapper, 0, 'UnitPrice').element as HTMLInputElement).value,
    ).toBe('1200')
  })

  // 入力を始めても警告アイコンと左の余白を残す（消えると入力中の文字が左へずれる）
  it('下書きのある低確信度の値は、塗りと警告アイコンを両方付ける', () => {
    const wrapper = mountTable({ draftItems: { 'LineItems:0:Quantity': '1' } })
    const low = cellAt(wrapper, 0, 'Quantity')
    expect(low.classes()).toEqual(
      expect.arrayContaining(['tbl-cell--low', 'tbl-cell--draft']),
    )
    expect(low.find('.tbl-low').exists()).toBe(true)
  })

  it('入力で itemInput、フォーカスで targetFocus を bubble する', async () => {
    const wrapper = mountTable()
    await inputAt(wrapper, 1, 'Quantity').setValue('5')
    expect(bubble).toHaveBeenCalledWith({
      type: 'itemInput',
      field: 'LineItems',
      index: 1,
      property: 'Quantity',
      value: '5',
    })
    await inputAt(wrapper, 1, 'Quantity').trigger('focus')
    expect(bubble).toHaveBeenCalledWith({
      type: 'targetFocus',
      id: 'item:LineItems:1:Quantity',
    })
  })

  it('セルの読み上げ名は「n行目 ラベル」で、状態と読取値を aria-describedby で参照する', () => {
    const wrapper = mountTable()
    const quantity = inputAt(wrapper, 0, 'Quantity')
    expect(quantity.attributes('aria-label')).toBe('1行目 数量')
    expect(byId(wrapper, quantity.attributes('aria-describedby')!).text()).toBe(
      '要確認 62%',
    )
    const price = inputAt(wrapper, 0, 'UnitPrice')
    expect(byId(wrapper, price.attributes('aria-describedby')!).text()).toBe(
      '90%、読取値 ¥1,180',
    )
    // 確信度を持たず読取値も同じ値は、説明を持たない
    expect(
      inputAt(wrapper, 1, 'Quantity').attributes('aria-describedby'),
    ).toBeUndefined()
  })

  it('activeId の値に aria-current と選択中クラスを付け、詳細欄に位置・状態・読取値を出す', () => {
    const wrapper = mountTable({ activeId: 'item:LineItems:0:UnitPrice' })
    expect(inputAt(wrapper, 0, 'UnitPrice').attributes('aria-current')).toBe(
      'true',
    )
    expect(cellAt(wrapper, 0, 'UnitPrice').classes()).toContain(
      'target--active',
    )
    expect(
      inputAt(wrapper, 0, 'Quantity').attributes('aria-current'),
    ).toBeUndefined()
    const detail = wrapper.get('[data-testid="item-detail"]')
    expect(detail.text()).toContain('1行目・単価')
    expect(detail.get('[data-testid="item-status"]').text()).toBe('90%')
    expect(detail.get('[data-testid="item-raw"]').text()).toBe('読取値 ¥1,180')
  })

  it('選択中の値が無いときは詳細欄に案内を出す', () => {
    const wrapper = mountTable({ activeId: 'field:order_no' })
    expect(wrapper.get('[data-testid="item-detail"]').text()).toBe(
      '値を選ぶと状態と読取値を表示します',
    )
  })

  it('未読取の値を選ぶと詳細欄の状態は「未読取」で、読取値は出さない', () => {
    const wrapper = mountTable({ activeId: 'item:LineItems:1:ProductName' })
    const detail = wrapper.get('[data-testid="item-detail"]')
    expect(detail.text()).toContain('2行目・品名')
    expect(detail.get('[data-testid="item-status"]').text()).toBe('未読取')
    expect(detail.find('[data-testid="item-raw"]').exists()).toBe(false)
  })

  it('選択中の値の正規化ヒントを詳細欄に出し、入力欄から参照する', () => {
    const wrapper = mountTable({
      activeId: 'item:LineItems:0:Quantity',
      draftItems: { 'LineItems:0:Quantity': 'abc' },
    })
    const hint = wrapper.get('[data-testid="item-hint"]')
    expect(hint.text()).toBe('数値として解釈できません')
    expect(
      inputAt(wrapper, 0, 'Quantity')
        .attributes('aria-describedby')!
        .split(' '),
    ).toContain(hint.attributes('id'))
    expect(wrapper.get('[data-testid="item-status"]').text()).toBe('未保存')
  })

  // 入力のたびに下書きが変わっても、入力欄の要素は同じまま（作り直すとフォーカスが外れる）
  it('下書きの更新で入力欄が作り直されず、フォーカスが残る', async () => {
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountTable({}, host)
    try {
      const input = inputAt(wrapper, 0, 'ProductName')
        .element as HTMLInputElement
      input.focus()
      await wrapper.setProps({
        draftItems: { 'LineItems:0:ProductName': 'ボ' },
      })
      await wrapper.setProps({
        draftItems: { 'LineItems:0:ProductName': 'ボー' },
      })
      expect(inputAt(wrapper, 0, 'ProductName').element).toBe(input)
      expect(document.activeElement).toBe(input)
    } finally {
      wrapper.unmount()
      host.remove()
    }
  })
})
