import { describe, expect, it } from 'vitest'

import {
  cellId,
  fieldId,
  itemFields,
  itemId,
  itemKey,
  originalValue,
  overlayRectsByPage,
  parseCellId,
  polygonToRect,
  scalarField,
  visibleFieldKeys,
  type IdpRun,
} from '../src/utils/runs'

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  engine: 'azure-di',
  engine_info: { api_version: '2024-11-30', model_id: 'prebuilt-layout' },
  error_info: null,
  fields: {
    TotalAmount: {
      value: '1,200,000',
      normalized_value: null,
      confidence: null,
      label: '合計金額',
      region: {
        page_number: 1,
        polygon: [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1],
      },
    },
    Note: {
      value: null,
      normalized_value: null,
      confidence: null,
      region: { page_number: 1, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
    },
    Hidden: {
      value: 'x',
      normalized_value: null,
      confidence: null,
      region: { page_number: 1, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
    },
    NoRegion: {
      value: 'y',
      normalized_value: null,
      confidence: null,
      region: null,
    },
  },
  layout_tables: [
    {
      row_count: 2,
      column_count: 1,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'h',
          kind: 'columnHeader',
          page_number: 1,
          polygon: [1, 2, 3, 2, 3, 2.5, 1, 2.5],
        },
        {
          row_index: 1,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'v',
          kind: null,
          page_number: 2,
          polygon: [1, 3, 3, 3, 3, 3.5, 1, 3.5],
        },
      ],
    },
    {
      row_count: 1,
      column_count: 1,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'n',
          kind: null,
          page_number: null,
          polygon: null,
        },
      ],
    },
  ],
  pattern_matches: null,
  corrections: null,
}

describe('ID', () => {
  it('field/cell の ID を組み立てる', () => {
    expect(fieldId('TotalAmount')).toBe('field:TotalAmount')
    expect(cellId(0, 2, 3)).toBe('cell:0:2:3')
  })
})

describe('polygonToRect', () => {
  // DI polygon（x,y の交互配列・インチ）を外接矩形に変換する。座標は無変換
  it('polygon の外接矩形を返す', () => {
    expect(polygonToRect([6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1])).toEqual({
      x: 6.8,
      y: 2.9,
      width: expect.closeTo(0.5, 6),
      height: expect.closeTo(0.2, 6),
    })
  })

  it('傾いた四角形でも min/max で囲む', () => {
    expect(polygonToRect([1, 0, 2, 1, 1, 2, 0, 1])).toEqual({
      x: 0,
      y: 0,
      width: 2,
      height: 2,
    })
  })
})

describe('overlayRectsByPage', () => {
  // セル = polygon あり全件、キー項目 = 領域あり・visible・value 非 null。セルを先、キー項目を後。ページ番号で分ける
  it('成功実行からページごとの矩形を生成する', () => {
    const byPage = overlayRectsByPage(run, new Set(['Hidden']))

    expect([...byPage.keys()].sort()).toEqual([1, 2])
    expect(byPage.get(1)?.map((r) => r.id)).toEqual([
      'cell:0:0:0',
      'field:TotalAmount',
    ])
    expect(byPage.get(1)?.[0]).toEqual({
      id: 'cell:0:0:0',
      kind: 'cell',
      label: '表 1 の 1 行 1 列',
      x: 1,
      y: 2,
      width: 2,
      height: 0.5,
    })
    expect(byPage.get(1)?.[1]).toEqual({
      id: 'field:TotalAmount',
      kind: 'field',
      label: '合計金額',
      x: 6.8,
      y: 2.9,
      width: expect.closeTo(0.5, 6),
      height: expect.closeTo(0.2, 6),
    })
    expect(byPage.get(2)?.map((r) => r.id)).toEqual(['cell:0:1:0'])
  })

  // ラベル未設定（非 verbose 応答など）のキー項目はキー名をアクセシブル名にする
  it('label の無いキー項目はキー名をラベルにする', () => {
    const noLabel = { ...run.fields!.TotalAmount!, label: undefined }
    const byPage = overlayRectsByPage(
      { ...run, fields: { ...run.fields, TotalAmount: noLabel } },
      new Set(),
    )
    expect(
      byPage.get(1)?.find((r) => r.id === 'field:TotalAmount')?.label,
    ).toBe('TotalAmount')
  })

  // 非 verbose 応答（region キー自体が無い）でもキー項目の矩形を作らず落ちない
  it('region の無い応答ではキー項目の矩形を作らない', () => {
    const byPage = overlayRectsByPage(
      {
        ...run,
        fields: {
          TotalAmount: { value: '1', normalized_value: null, confidence: null },
        },
      },
      new Set(),
    )
    expect(byPage.get(1)?.map((r) => r.id)).toEqual(['cell:0:0:0'])
  })

  // polygon が退化（4未満）しているセルは Math.min(...[]) が Infinity にならないよう除外する
  it('polygonが退化したセルは矩形化しない', () => {
    const degenerate: IdpRun = {
      ...run,
      fields: null,
      layout_tables: [
        {
          row_count: 1,
          column_count: 1,
          cells: [
            {
              row_index: 0,
              column_index: 0,
              row_span: 1,
              column_span: 1,
              content: 'n',
              kind: null,
              page_number: 1,
              polygon: [],
            },
          ],
        },
      ],
    }
    expect(overlayRectsByPage(degenerate, new Set()).size).toBe(0)
  })

  it('失敗実行・未選択は空', () => {
    expect(overlayRectsByPage(null, new Set()).size).toBe(0)
    expect(
      overlayRectsByPage(
        { ...run, status: 'failed', layout_tables: null, fields: null },
        new Set(),
      ).size,
    ).toBe(0)
  })
})

describe('parseCellId', () => {
  it('cellId の逆変換。セル以外の ID は null', () => {
    expect(parseCellId(cellId(1, 7, 2))).toEqual({
      table: 1,
      row: 7,
      column: 2,
    })
    expect(parseCellId('field:total')).toBeNull()
    expect(parseCellId('cell:1:x:2')).toBeNull()
  })
})

describe('visibleFieldKeys', () => {
  // 応答の fields は JSONB 由来でキー順が設定順にならない。設定の順に並べ、設定に無いキーは末尾、visible=false は除く
  it('文書種別設定の順に並べ、未設定のキーは末尾、非表示は除く', () => {
    const run = {
      fields: { Note: {}, Total: {}, Hidden: {}, Extra: {} },
    } as unknown as IdpRun
    const defs = [
      { key: 'Total', visible: true },
      { key: 'Missing', visible: true },
      { key: 'Note', visible: true },
      { key: 'Hidden', visible: false },
    ]
    expect(visibleFieldKeys(run, defs)).toEqual(['Total', 'Note', 'Extra'])
    expect(
      visibleFieldKeys({ fields: null } as unknown as IdpRun, defs),
    ).toEqual([])
  })
})

describe('array 型の項目（明細）', () => {
  const leaf = (
    value: string | null,
    normalized: string | number | null,
    confidence: number | null,
    polygon?: number[],
  ) => ({
    value,
    normalized_value: normalized,
    confidence,
    ...(polygon ? { region: { page_number: 1, polygon } } : {}),
  })
  const withItems = {
    ...run,
    fields: {
      ...run.fields,
      LineItems: {
        label: '明細',
        property_labels: {
          ProductName: '品名',
          Quantity: '数量',
          Extra: '備考',
        },
        items: [
          {
            ProductName: leaf(
              'ボールペン',
              'ボールペン',
              0.95,
              [1, 5, 3, 5, 3, 6, 1, 6],
            ),
            Quantity: leaf('12', 12, 0.7, [4, 5, 5, 5, 5, 6, 4, 6]),
            Extra: leaf(null, null, null),
          },
          {
            ProductName: leaf(null, null, null),
            Quantity: leaf('3', 3, null, [4, 7, 5, 7, 5, 8, 4, 8]),
            Extra: leaf('x', 'x', 0.9),
          },
        ],
      },
      Fees: { label: null, property_labels: null, items: [] },
    },
  } as IdpRun
  const defs = [
    {
      key: 'Fees',
      visible: true,
      properties: [{ key: 'Amount', type: 'number' as const }],
    },
    {
      key: 'LineItems',
      visible: true,
      properties: [
        { key: 'Quantity', type: 'number' as const },
        { key: 'ProductName', type: 'string' as const },
        { key: 'Removed', type: 'string' as const },
      ],
    },
  ]

  it('visibleFieldKeys・scalarField は明細の項目を扱わない', () => {
    expect(visibleFieldKeys(withItems, [])).not.toContain('LineItems')
    expect(scalarField(withItems, 'LineItems')).toBeUndefined()
  })

  it('itemId / itemKey', () => {
    expect(itemId('LineItems', 2, 'Quantity')).toBe('item:LineItems:2:Quantity')
    expect(itemKey('LineItems', 2, 'Quantity')).toBe('LineItems:2:Quantity')
  })

  // 項目は設定の順（設定に無い項目は末尾、visible=false は除く）。列は設定の properties の順で、実行結果に
  // 無いプロパティは出さず、設定に無いプロパティは末尾に string で置く。ラベルは実行時の値、無ければキー
  it('itemFields は項目と列を設定の順に並べる', () => {
    const fields = itemFields(withItems, defs)
    expect(fields.map((f) => f.key)).toEqual(['Fees', 'LineItems'])
    expect(fields[0]).toEqual({
      key: 'Fees',
      label: 'Fees',
      columns: [],
      rows: [],
    })
    expect(fields[1]!.label).toBe('明細')
    expect(fields[1]!.columns).toEqual([
      { key: 'Quantity', label: '数量', type: 'number' },
      { key: 'ProductName', label: '品名', type: 'string' },
      { key: 'Extra', label: '備考', type: 'string' },
    ])
    expect(fields[1]!.rows).toHaveLength(2)
  })

  it('itemFields は visible=false の項目を除き、設定に無い項目は末尾に置く', () => {
    expect(
      itemFields(withItems, [{ key: 'LineItems', visible: false }]).map(
        (f) => f.key,
      ),
    ).toEqual(['Fees'])
    expect(itemFields(withItems, []).map((f) => f.key)).toEqual([
      'LineItems',
      'Fees',
    ])
  })

  // 入力欄の元値（キー項目・明細で共通）。正規化値の文字列、無ければ読取値、両方無ければ null
  it('originalValue は正規化値の文字列、無ければ読取値', () => {
    expect(originalValue(leaf('12', 12, 0.7))).toBe('12')
    expect(originalValue(leaf('1.5', null, 0.7))).toBe('1.5')
    expect(originalValue(leaf(null, null, null))).toBeNull()
    expect(originalValue(undefined)).toBeNull()
  })

  // 明細の値の矩形はキー項目と同じ条件（region あり・値あり・非表示でない）。セル → 明細 → キー項目の順
  it('overlayRectsByPage は明細の値の矩形をセルとキー項目の間に作る', () => {
    const page1 =
      overlayRectsByPage(withItems, new Set(['Hidden'])).get(1) ?? []
    expect(page1.map((r) => r.id)).toEqual([
      'cell:0:0:0',
      'item:LineItems:0:ProductName',
      'item:LineItems:0:Quantity',
      'item:LineItems:1:Quantity',
      'field:TotalAmount',
    ])
    expect(page1[1]).toEqual({
      id: 'item:LineItems:0:ProductName',
      kind: 'field',
      label: '明細 1行目 品名',
      x: 1,
      y: 5,
      width: 2,
      height: 1,
    })
    expect(page1[3]?.label).toBe('明細 2行目 数量')
  })

  it('overlayRectsByPage は非表示の明細の項目の矩形を作らない', () => {
    const rects = [
      ...overlayRectsByPage(withItems, new Set(['LineItems'])).values(),
    ].flat()
    expect(rects.some((r) => r.id.startsWith('item:'))).toBe(false)
  })
})
