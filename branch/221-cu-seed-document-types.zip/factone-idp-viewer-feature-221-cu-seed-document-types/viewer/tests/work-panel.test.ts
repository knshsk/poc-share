import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import ResultEditor from '../src/components/ResultEditor.vue'
import ViewUrlPanel from '../src/components/ViewUrlPanel.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { WorkPanelVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import {
  correctedRun,
  editorVm,
  failedRun,
  succeededRun,
  toSummary,
  workPanelVm,
} from './fixtures'

const bubble = vi.fn()

function mountPanel(over: Partial<WorkPanelVm> = {}, attachTo?: HTMLElement) {
  return mount(WorkPanel, {
    props: { vm: workPanelVm(over) },
    attachTo,
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// 成功実行を選択中（読取結果タブ・editor あり）の vm
function withEditor(over: Partial<WorkPanelVm> = {}) {
  return {
    runs: [toSummary(succeededRun)],
    selectedRun: succeededRun,
    editor: editorVm({ run: succeededRun }),
    ...over,
  }
}

// ダイアログ・スナックバーはbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('WorkPanel', () => {
  it('IDP実行ボタンで executeIdp を bubble し、実行中は無効化する', async () => {
    const wrapper = mountPanel()
    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'executeIdp' })

    const executing = mountPanel({ executing: true })
    expect(
      executing.get('[data-testid="execute-idp"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('エラーメッセージを表示する', () => {
    expect(mountPanel({ error: 'IDP実行に失敗しました' }).text()).toContain(
      'IDP実行に失敗しました',
    )
  })

  // 成功実行選択時、ResultEditor に editor を渡し、チップに区分と日時が出る。アクションバーは変更0件で無効
  it('成功実行の editor とチップ・アクションバーを表示する', () => {
    const wrapper = mountPanel(withEditor())
    expect(wrapper.findComponent(ResultEditor).props('vm')).toEqual(
      editorVm({ run: succeededRun }),
    )
    expect(wrapper.get('[data-testid="showing-run"]').text()).toContain('初回')
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 0件',
    )
    expect(
      wrapper.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeDefined()
    expect(
      wrapper.get('[data-testid="discard-draft"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('失敗実行選択時はエラー情報を出し、アクションバーを出さない', () => {
    const wrapper = mountPanel({
      runs: [toSummary(failedRun)],
      selectedRun: failedRun,
    })
    expect(wrapper.get('[data-testid="run-error"]').text()).toContain(
      'DI request failed',
    )
    expect(wrapper.find('[data-testid="confirm-corrections"]').exists()).toBe(
      false,
    )
  })

  it('実行未選択は「実行結果がありません」と IDP実行 への案内、取得中はスピナー', () => {
    const text = mountPanel().text()
    expect(text).toContain('実行結果がありません')
    expect(text).toContain('「IDP実行」で読取を開始します')
    const loading = mountPanel({ loadingRuns: true })
    expect(loading.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    expect(loading.find('.v-skeleton-loader').exists()).toBe(false)
  })

  // 一覧の取得中は実行履歴タブにも中身が無いため、タブに関わらず本文全体をスピナーにする
  it('一覧・最初の結果の取得中は、実行履歴タブでも本文をスピナーにする', () => {
    const wrapper = mountPanel({ loadingRuns: true, activeTab: 'history' })
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    expect(wrapper.text()).not.toContain('実行履歴がありません')
    expect(wrapper.find('.v-window').exists()).toBe(false)
  })

  // IDP実行は再項目化用のまれな操作なので outlined。一覧を取得できていて実行が 1 件も無い文書だけは
  // 唯一の次操作なので塗りにして案内を出す。取得中と一覧の取得失敗は該当しない。
  // IDP 実行の失敗（error だけが立つ）では、実行 0 件のままなので塗りと案内を残す
  it('IDP実行ボタンは一覧取得済みで実行 0 件のときだけ塗りにして案内を出す', () => {
    for (const over of [{}, { error: 'IDP実行に失敗しました' }]) {
      const wrapper = mountPanel(over)
      expect(wrapper.get('[data-testid="execute-idp"]').classes()).toContain(
        'v-btn--variant-flat',
      )
      expect(wrapper.text()).toContain('「IDP実行」で読取を開始します')
    }

    for (const over of [
      { loadingRuns: true },
      { runsLoadFailed: true, error: '実行履歴を取得できませんでした' },
      withEditor(),
    ]) {
      const wrapper = mountPanel(over)
      expect(wrapper.get('[data-testid="execute-idp"]').classes()).toContain(
        'v-btn--variant-outlined',
      )
      expect(wrapper.text()).not.toContain('「IDP実行」で読取を開始します')
    }
  })

  // 確定は主操作なので small にしない
  it('確定・破棄は通常サイズで表示する', () => {
    const wrapper = mountPanel(withEditor())
    for (const id of ['confirm-corrections', 'discard-draft']) {
      expect(wrapper.get(`[data-testid="${id}"]`).classes()).toContain(
        'v-btn--size-default',
      )
    }
  })

  // 修正行を表示中は「修正（修正者）」+ 日時になる。日時は別枠で、省略記号で削れない
  it('表示中の結果に区分と修正者を表示し、日時は省略されない別枠にする', () => {
    const wrapper = mountPanel({
      runs: [toSummary(correctedRun)],
      selectedRun: correctedRun,
      editor: editorVm({ run: correctedRun }),
    })
    const showing = wrapper.get('[data-testid="showing-run"]')
    expect(showing.text()).toContain('表示中')
    expect(showing.text()).toContain('修正（testuser）')
    const date = showing.get('[data-testid="showing-run-date"]')
    expect(date.text()).toBeTruthy()
    // 狭い幅では区分・修正者側だけを省略記号で切るため、全文（区分+日時）を title に入れる
    const label = showing.get('.showing-label')
    expect(label.attributes('title')).toBe(`${label.text()} ${date.text()}`)
  })

  // runs は新しい順。先頭以外を表示しているときは「過去の結果」を警告色で出す
  it('最新の結果は「最新」、それ以外は「過去の結果」を表示する', () => {
    const runs = [toSummary(correctedRun), toSummary(succeededRun)]
    const latest = mountPanel({ runs, selectedRun: correctedRun })
    const latestAge = latest.get('[data-testid="showing-run-age"]')
    expect(latestAge.text()).toBe('最新')
    expect(latestAge.classes()).not.toContain('text-warning')

    const past = mountPanel({
      runs,
      selectedRun: succeededRun,
      editor: editorVm({ run: succeededRun }),
    })
    const pastAge = past.get('[data-testid="showing-run-age"]')
    expect(pastAge.text()).toBe('過去の結果')
    expect(pastAge.classes()).toContain('text-warning')
  })

  // 「表示中」をクリックすると実行履歴タブへ。履歴の先頭行にも「最新」を付ける
  it('表示中のクリックで実行履歴タブへ移り、履歴の先頭行に「最新」を付ける', async () => {
    const wrapper = mountPanel({
      runs: [toSummary(correctedRun), toSummary(succeededRun)],
      selectedRun: correctedRun,
      activeTab: 'history',
    })
    await wrapper.get('[data-testid="showing-run"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'tabChanged', tab: 'history' })

    const rows = wrapper.findAll('[data-testid="run-row"]')
    expect(rows[0]!.text()).toContain('最新')
    expect(rows[1]!.text()).not.toContain('最新')
  })

  // 履歴は区分「初回/再実行/修正」・成否・修正者を表示し、行クリックで selectRun を bubble する
  it('履歴タブに区分と修正者を表示し、行クリックで selectRun を bubble する', async () => {
    const wrapper = mountPanel({
      runs: [correctedRun, failedRun, succeededRun].map(toSummary),
      selectedRun: correctedRun,
      activeTab: 'history',
    })
    const rows = wrapper.findAll('[data-testid="run-row"]')
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('修正')
    expect(rows[0]!.text()).toContain('testuser')
    expect(rows[1]!.text()).toContain('再実行')
    expect(rows[1]!.text()).toContain('失敗')
    expect(rows[2]!.text()).toContain('初回')
    expect(wrapper.text()).not.toContain('prebuilt-layout')
    expect(rows[0]!.classes()).toContain('v-list-item--active')

    await rows[2]!.trigger('click')
    expect(bubble).toHaveBeenCalledWith({
      type: 'selectRun',
      runId: succeededRun.run_id,
    })
  })

  // 副題の中の「成功 / 失敗」は色で状態を示すため、Vuetify が副題に掛ける透明度（medium-emphasis）で薄めない。
  // 本文との区別は secondary 色で付ける（WCAG 1.4.3・ADR-0024）
  it('実行履歴の副題は 14px の secondary 色で、透明度を掛けない', () => {
    const wrapper = mountPanel({
      runs: [succeededRun].map(toSummary),
      selectedRun: succeededRun,
      activeTab: 'history',
    })
    const row = wrapper.get('[data-testid="run-row"]')
    expect(row.get('.v-list-item-subtitle').classes()).toEqual(
      expect.arrayContaining(['text-body-medium', 'text-secondary']),
    )
    expect(row.element.closest('.v-list')!.getAttribute('style')).toContain(
      '--v-list-item-subtitle-opacity: 1',
    )
  })

  it('履歴が無いときは「実行履歴がありません」', () => {
    expect(mountPanel({ activeTab: 'history' }).text()).toContain(
      '実行履歴がありません',
    )
  })

  // タブは vm.activeTab で選択され、クリックで tabChanged を bubble する
  it('タブ選択は vm に従い、クリックで tabChanged を bubble する', async () => {
    const wrapper = mountPanel({ activeTab: 'history' })
    expect(wrapper.get('[data-testid="tab-history"]').classes()).toContain(
      'v-tab--selected',
    )
    await wrapper.get('[data-testid="tab-result"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'tabChanged', tab: 'result' })
  })

  // 閲覧URLタブは設定のshareableで表示制御し、ViewUrlPanel に vm.viewUrls を渡す（#81・ADR-0002）
  it('shareable=trueで閲覧URLタブを表示し、falseでは表示しない', () => {
    expect(mountPanel().find('[data-testid="tab-urls"]').exists()).toBe(false)
    const shareable = mountPanel({ shareable: true, activeTab: 'urls' })
    expect(shareable.find('[data-testid="tab-urls"]').exists()).toBe(true)
    expect(shareable.findComponent(ViewUrlPanel).props('vm')).toEqual(
      workPanelVm().viewUrls,
    )
  })

  // 変更ありで確定・破棄が有効になり、それぞれ bubble する。保存中は無効
  it('変更があれば確定・破棄を有効化して bubble し、保存中は無効化する', async () => {
    const wrapper = mountPanel(withEditor({ draftCount: 2 }))
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 2件',
    )
    await wrapper.get('[data-testid="discard-draft"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'discardDraft' })
    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmCorrections' })

    const saving = mountPanel(withEditor({ draftCount: 2, saving: true }))
    expect(
      saving.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeDefined()
  })

  // 未保存の変更の確認ダイアログ: vm.confirmDiscard で表示し、キャンセル / 破棄して続行を bubble する
  it('confirmDiscard で確認ダイアログを出し、cancel / proceed を bubble する', () => {
    mountPanel(withEditor({ draftCount: 1, confirmDiscard: true }))
    const dialog = document.querySelector('[data-testid="discard-dialog"]')
    expect(dialog?.textContent).toContain('未保存の変更を破棄しますか？')
    expect(dialog?.textContent).toContain('変更 1件')
    // ダイアログのアクセシブル名はタイトル要素（aria-labelledby）
    const titleId = document
      .querySelector('[role="dialog"]')
      ?.getAttribute('aria-labelledby')
    expect(titleId).toBeTruthy()
    expect(document.getElementById(titleId!)?.textContent).toContain(
      '未保存の変更を破棄しますか？',
    )
    ;(
      document.querySelector('[data-testid="discard-cancel"]') as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmCancel' })
    ;(
      document.querySelector('[data-testid="discard-proceed"]') as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmProceed' })
  })

  // 戻せないのは、開いた時点でフォーカスが無い（クリックでボタンにフォーカスが当たらないブラウザ）、履歴の行が
  // 読取結果タブへの切替で隠れた、破棄して続行した IDP実行が無効になった、のいずれか。jsdom は非表示の要素や
  // loading 中（tabindex="-1"）の無効なボタンにもフォーカスを当てるため、ここでは 1 つ目で確かめる
  it('確認ダイアログを閉じたとき、開く前の要素へ戻せなければ選択中のタブへフォーカスを移す', async () => {
    const vm = withEditor({ draftCount: 1, activeTab: 'history' })
    const wrapper = mountPanel(vm, document.body)
    await flushPromises()
    await wrapper.setProps({ vm: workPanelVm({ ...vm, confirmDiscard: true }) })
    document
      .querySelector<HTMLElement>('[data-testid="discard-cancel"]')!
      .focus()
    await wrapper.setProps({ vm: workPanelVm(vm) })
    expect(document.activeElement).toBe(
      wrapper.get('[data-testid="tab-history"]').element,
    )
  })

  it('savedSnackbar で「修正を保存しました」を表示する', () => {
    mountPanel(withEditor({ savedSnackbar: true }))
    expect(document.body.textContent).toContain('修正を保存しました')
  })

  // ResultEditor の操作は WorkPanel を素通りして親へ bubble する（Chain of Responsibility）
  it('ResultEditor の入力が親へ bubble する', async () => {
    const wrapper = mountPanel(withEditor())
    await wrapper.get('[data-testid="field-input"] input').setValue('A-002')
    expect(bubble).toHaveBeenCalledWith({
      type: 'fieldInput',
      key: 'order_no',
      value: 'A-002',
    })
  })
})
