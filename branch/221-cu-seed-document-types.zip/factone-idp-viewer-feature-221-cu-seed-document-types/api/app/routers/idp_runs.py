"""IDP実行API（項目抽出の実行と履歴参照）。

実行区分（初回/再実行）は同一文書IDの既存実行有無からサーバ側で判定する。
実行ログは追記型で、エンジンの失敗時もエラー情報付きで記録する。
"""

import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Annotated, Any, cast

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field, StringConstraints, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import Document, IdpRun, IdpRunStatus, IdpRunType
from app.routers.documents import _get_document_or_404
from app.services.blob import BlobStorage
from app.services.document_type_config import (
    config_field_defs,
    config_pattern_defs,
    get_config,
)
from app.services.engine import (
    DocumentAnalyzer,
    EngineError,
    EngineName,
    SchemaOwner,
)
from app.services.idp_extraction import (
    CellCorrection,
    ItemCorrection,
    UnknownCorrectionTarget,
    apply_corrections,
    build_fields,
    layout_tables_to_json,
    match_patterns,
)

router = APIRouter(responses=problem_responses(401, 403, 422))


class IdpRunSummary(BaseModel):
    """一覧用の軽量項目。項目値・テーブル・領域は詳細（IdpRunResponse）で取得する。"""

    run_id: uuid.UUID
    document_id: str
    run_type: IdpRunType
    status: IdpRunStatus
    executed_at: datetime
    # corrected 行のみ非 null（修正元の実行結果と修正者）
    base_run_id: uuid.UUID | None
    corrected_by: str | None
    engine: EngineName
    # エンジン固有のメタ情報（DIは api_version / model_id）。失敗実行は null
    engine_info: dict[str, str | None] | None
    error_info: str | None


# NUL は PostgreSQL の jsonb に格納できないため拒否する（改行・TAB などは受け付ける）
CorrectionText = Annotated[
    str, StringConstraints(max_length=2000, pattern=r"^[^\x00]*$")
]


class LayoutTableCellCorrection(BaseModel):
    table_index: int = Field(ge=0)
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    content: CorrectionText


class ItemCorrectionPayload(BaseModel):
    """明細（array 型の項目）の値の修正。index は 0 始まりで、base での行番号。"""

    field: str
    index: int = Field(ge=0)
    property: str
    value: CorrectionText | None


class CorrectionRequest(BaseModel):
    """読取結果の差分修正。変更した項目・明細の値・セルだけを送る（サーバがbaseとマージする）。"""

    fields: dict[str, CorrectionText | None] = {}
    items: list[ItemCorrectionPayload] = []
    layout_table_cells: list[LayoutTableCellCorrection] = []

    @model_validator(mode="after")
    def _require_changes_and_unique_targets(self) -> CorrectionRequest:
        if not self.fields and not self.items and not self.layout_table_cells:
            raise ValueError("fields, items or layout_table_cells is required")
        targets = [(i.field, i.index, i.property) for i in self.items]
        if len(targets) != len(set(targets)):
            raise ValueError("items contains duplicate targets")
        coords = [
            (c.table_index, c.row_index, c.column_index)
            for c in self.layout_table_cells
        ]
        if len(coords) != len(set(coords)):
            raise ValueError("layout_table_cells contains duplicate coordinates")
        return self


class FieldRegion(BaseModel):
    """項目の読取領域（インチ単位、SVG の viewBox と同一座標系）。エンジンが返した根拠の領域の先頭。"""

    page_number: int
    polygon: list[float]


class FieldResult(BaseModel):
    """項目別の読取結果。label / region は verbose=true のときだけ含まれる（Viewer 向け）。"""

    value: str | None
    normalized_value: str | int | None
    confidence: float | None
    label: str | None = None
    region: FieldRegion | None = None


class ItemsFieldResult(BaseModel):
    """array 型の項目（明細）の読取結果。行ごとに、プロパティの key → 葉。

    label / property_labels と各葉の region は verbose=true のときだけ含まれる（Viewer 向け）。
    """

    items: list[dict[str, FieldResult]]
    label: str | None = None
    property_labels: dict[str, str] | None = None


class PatternMatch(BaseModel):
    """正規表現パターンの一致結果。実行時点の label / regex を同梱する。"""

    label: str
    regex: str
    values: list[str]


class LayoutTableCell(BaseModel):
    """レイアウト認識のテーブルセル。polygon は verbose=true のときだけ含まれる（Viewer 向け）。span は結合なしで 1。"""

    row_index: int
    column_index: int
    row_span: int
    column_span: int
    kind: str | None
    content: str
    page_number: int | None
    polygon: list[float] | None = None


class LayoutTable(BaseModel):
    """レイアウト認識のテーブル（エンジンが返せる場合の補助出力）。"""

    row_count: int
    column_count: int
    cells: list[LayoutTableCell]


class IdpRunResponse(IdpRunSummary):
    """実行結果の詳細。失敗実行は fields / pattern_matches / layout_tables が null。

    verbose=true のときだけ fields[].label / fields[].region / layout_tables[].cells[].polygon /
    corrections を含む（Viewer のハイライト・修正 UI 向け）。外部連携システムは既定（verbose=false）を使う。
    array 型の項目は items の形（ItemsFieldResult）で返る。
    """

    fields: dict[str, FieldResult | ItemsFieldResult] | None
    pattern_matches: dict[str, PatternMatch] | None
    layout_tables: list[LayoutTable] | None
    # corrected 行のみ非 null。根の機械実行に対する人手差分の累積（修正ボディと同じ形）
    corrections: CorrectionRequest | None = None


class IdpRunListResponse(BaseModel):
    document_id: str
    runs: list[IdpRunSummary]


def _to_summary(run: IdpRun) -> IdpRunSummary:
    return IdpRunSummary(
        run_id=run.id,
        document_id=run.document.document_id,
        run_type=IdpRunType(run.run_type),
        status=IdpRunStatus(run.status),
        executed_at=run.executed_at,
        base_run_id=run.base_run_id,
        corrected_by=run.corrected_by,
        engine=EngineName(run.engine),
        engine_info=run.engine_info,
        error_info=run.error_info,
    )


def _to_response(run: IdpRun, verbose: bool) -> IdpRunResponse:
    """DB 列から素の dict を組み立て、IdpRunResponse.model_validate で一括検証する。
    verbose 専用キーは verbose のときだけ dict にセットする。Pydantic は dict 由来の
    ネストモデルでも「渡したキーだけ」を fields_set にするため、ルートの
    response_model_exclude_unset=True で未セット分（label/region/polygon/corrections）が
    応答から落ちる性質は維持される。"""
    data: dict[str, object] = {
        **_to_summary(run).model_dump(),
        "fields": _to_fields(run, verbose),
        "pattern_matches": run.pattern_matches,
        "layout_tables": None
        if run.layout_tables is None
        else [_to_table(t, verbose) for t in run.layout_tables],
    }
    if verbose:
        # 明細の修正（items）追加前に保存された行にはキーが無い。モデルの既定値に頼ると exclude_unset で落ちるため明示的に入れる
        data["corrections"] = (
            None if run.corrections is None else {"items": [], **run.corrections}
        )
    return IdpRunResponse.model_validate(data)


def _to_fields(run: IdpRun, verbose: bool) -> dict[str, dict[str, object]] | None:
    if run.fields is None:
        return None
    # region / label / property_labels は Viewer 向け（verbose=true のときだけ返す）
    leaf_keys = (
        "value",
        "normalized_value",
        "confidence",
        *(("region",) if verbose else ()),
    )

    def leaf(data: dict[str, Any]) -> dict[str, object]:
        return {k: data[k] for k in leaf_keys}

    fields: dict[str, dict[str, object]] = {}
    for key, field in run.fields.items():
        data: dict[str, object] = (
            {
                "items": [
                    {prop: leaf(value) for prop, value in row.items()}
                    for row in field["items"]
                ]
            }
            if "items" in field
            else leaf(field)
        )
        if verbose:
            data |= {k: field[k] for k in ("label", "property_labels") if k in field}
        fields[key] = data
    return fields


def _to_table(table: dict[str, object], verbose: bool) -> dict[str, object]:
    cells = []
    for cell in cast(list[dict[str, object]], table["cells"]):
        # span 追加（#151）前に保存された行にはキーが無い。モデルの既定値に頼ると exclude_unset で落ちるため明示的に入れる
        data = {
            **cell,
            "row_span": cell.get("row_span", 1),
            "column_span": cell.get("column_span", 1),
        }
        if not verbose:
            data.pop("polygon", None)
        cells.append(data)
    return {**table, "cells": cells}


def _analyzer_for(request: Request, engine: EngineName) -> DocumentAnalyzer:
    """エンジンの表から実装を引く。この環境で組み立てていないエンジンは未設定として扱う（502）。"""
    analyzers: Mapping[EngineName, DocumentAnalyzer] = (
        request.app.state.document_analyzers
    )
    analyzer = analyzers.get(engine)
    if analyzer is None:
        raise EngineError(f"{engine.value} endpoint is not configured")
    return analyzer


def _determine_run_type(session: Session, document_pk: uuid.UUID) -> IdpRunType:
    exists = session.execute(
        select(IdpRun.id).where(IdpRun.document_pk == document_pk).limit(1)
    ).first()
    return IdpRunType.RERUN if exists else IdpRunType.INITIAL


@router.post(
    "/api/v1/documents/{document_id}/idp-runs",
    response_model=IdpRunResponse,
    response_model_exclude_unset=True,
    status_code=201,
    responses=problem_responses(404, 409, 502),
)
def execute_idp_run(
    request: Request,
    user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    verbose: bool = False,
) -> IdpRunResponse:
    document: Document = _get_document_or_404(session, user.tenant_id, document_id)
    blob_storage: BlobStorage = request.app.state.blob_storage

    run_type = _determine_run_type(session, document.id)
    config = get_config(session, user.tenant_id, document.document_type)
    if config is None:
        raise ProblemException(
            409,
            "document-type-not-configured",
            "Document type is not configured for this tenant",
        )
    schema = config_field_defs(config)
    engine = EngineName(config.engine)
    # 生応答のBlobパスに実行IDを使うため、INSERT前に採番する
    run_id = uuid.uuid4()
    run = IdpRun(
        id=run_id,
        document_pk=document.id,
        run_type=run_type.value,
        executed_at=datetime.now(UTC),
        engine=engine.value,
    )
    try:
        results = _analyzer_for(request, engine).analyze(
            blob_storage.load(document.blob_ref),
            schema,
            SchemaOwner(tenant_id=user.tenant_id, type_code=document.document_type),
        )
    except EngineError as exc:
        run.status = IdpRunStatus.FAILED.value
        run.error_info = str(exc)
        session.add(run)
        session.commit()
        raise ProblemException(
            502, "document-analysis-failed", "Document analysis failed"
        ) from exc

    # 生応答はBlobに無変換で保存し、DBには参照のみ持つ（ADR-0019）。保存失敗は500で実行ログを残さない
    raw_response_ref = f"{user.tenant_id}/{document_id}/idp-runs/{run_id}.json"
    blob_storage.save(raw_response_ref, results.raw_response)

    run.status = IdpRunStatus.SUCCEEDED.value
    run.fields = build_fields(schema, results.fields)
    run.layout_tables = layout_tables_to_json(results.layout_tables)
    run.pattern_matches = match_patterns(config_pattern_defs(config), results.content)
    run.engine_info = results.engine_info
    run.raw_response_ref = raw_response_ref
    session.add(run)
    session.commit()
    return _to_response(run, verbose)


@router.get(
    "/api/v1/documents/{document_id}/idp-runs",
    response_model=IdpRunListResponse,
    responses=problem_responses(404),
)
def list_idp_runs(
    user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunListResponse:
    document = _get_document_or_404(session, user.tenant_id, document_id)
    runs = (
        session.execute(
            select(IdpRun)
            .where(IdpRun.document_pk == document.id)
            .order_by(IdpRun.executed_at, IdpRun.id)
        )
        .scalars()
        .all()
    )
    return IdpRunListResponse(
        document_id=document_id, runs=[_to_summary(run) for run in runs]
    )


def _get_run_or_404(session: Session, document: Document, run_id: uuid.UUID) -> IdpRun:
    run = session.get(IdpRun, run_id)
    # 他文書の実行IDは存在自体を秘匿するため404
    if run is None or run.document_pk != document.id:
        raise ProblemException(404, "idp-run-not-found", "IDP run not found")
    return run


@router.get(
    "/api/v1/documents/{document_id}/idp-runs/latest",
    response_model=IdpRunResponse,
    response_model_exclude_unset=True,
    responses=problem_responses(404),
)
def get_latest_idp_run(
    user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    run_type: IdpRunType | None = None,
    verbose: bool = False,
) -> IdpRunResponse:
    """最新の成功実行を返す。run_type 指定で区分を絞る（失敗実行は対象外）。verbose で Viewer 向けの付加情報を含める。"""
    document = _get_document_or_404(session, user.tenant_id, document_id)
    stmt = select(IdpRun).where(
        IdpRun.document_pk == document.id,
        IdpRun.status == IdpRunStatus.SUCCEEDED.value,
    )
    if run_type is not None:
        stmt = stmt.where(IdpRun.run_type == run_type.value)
    run = session.execute(
        stmt.order_by(IdpRun.executed_at.desc(), IdpRun.id.desc()).limit(1)
    ).scalar_one_or_none()
    if run is None:
        raise ProblemException(404, "idp-run-not-found", "IDP run not found")
    return _to_response(run, verbose)


@router.get(
    "/api/v1/documents/{document_id}/idp-runs/{run_id}",
    response_model=IdpRunResponse,
    response_model_exclude_unset=True,
    responses=problem_responses(404),
)
def get_idp_run(
    user: CurrentUser,
    document_id: str,
    run_id: uuid.UUID,
    session: Annotated[Session, Depends(get_db_session)],
    verbose: bool = False,
) -> IdpRunResponse:
    document = _get_document_or_404(session, user.tenant_id, document_id)
    return _to_response(_get_run_or_404(session, document, run_id), verbose)


@router.get(
    "/api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response",
    responses=problem_responses(404),
)
def get_raw_response(
    request: Request,
    user: CurrentUser,
    document_id: str,
    run_id: uuid.UUID,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    """DI生応答（最終ポーリング応答本文）をBlobから無変換で返す。失敗実行は参照が無く404。"""
    document = _get_document_or_404(session, user.tenant_id, document_id)
    run = _get_run_or_404(session, document, run_id)
    if run.raw_response_ref is None:
        raise ProblemException(
            404, "raw-response-not-found", "Raw response is not available"
        )
    blob_storage: BlobStorage = request.app.state.blob_storage
    return Response(
        content=blob_storage.load(run.raw_response_ref), media_type="application/json"
    )


def _accumulate_corrections(
    base: dict[str, object] | None, body: CorrectionRequest
) -> dict[str, object]:
    """base の累積差分（機械実行なら None）に今回の差分を重ねる。同一キー・同一明細の値・同一セル座標は今回の値で上書き。"""
    if not base:
        return body.model_dump()
    prev = CorrectionRequest.model_validate(base)
    items = {(i.field, i.index, i.property): i for i in (*prev.items, *body.items)}
    cells = {
        (c.table_index, c.row_index, c.column_index): c
        for c in (*prev.layout_table_cells, *body.layout_table_cells)
    }
    return CorrectionRequest(
        fields={**prev.fields, **body.fields},
        items=list(items.values()),
        layout_table_cells=list(cells.values()),
    ).model_dump()


@router.post(
    "/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections",
    response_model=IdpRunResponse,
    response_model_exclude_unset=True,
    status_code=201,
    responses=problem_responses(404, 409),
)
def create_correction(
    user: CurrentUser,
    document_id: str,
    run_id: uuid.UUID,
    body: CorrectionRequest,
    session: Annotated[Session, Depends(get_db_session)],
    verbose: bool = False,
) -> IdpRunResponse:
    """base（run_id）に差分を当てたcorrected行を追記する（ADR-0018）。

    正規化は現在の文書種別設定の型で行う。排他制御は行わず、同一baseへの並行修正は両方追記される。
    """
    document: Document = _get_document_or_404(session, user.tenant_id, document_id)
    base = _get_run_or_404(session, document, run_id)
    if base.status != IdpRunStatus.SUCCEEDED.value:
        raise ProblemException(
            409, "idp-run-not-correctable", "Failed IDP run cannot be corrected"
        )
    config = get_config(session, user.tenant_id, document.document_type)
    defs = config_field_defs(config) if config else ()
    field_types = {f.key: f.type for f in defs}
    property_types = {f.key: {p.key: p.type for p in f.properties} for f in defs}
    try:
        values = apply_corrections(
            base.fields or {},
            base.layout_tables or [],
            body.fields,
            [CellCorrection(**c.model_dump()) for c in body.layout_table_cells],
            field_types,
            items=[ItemCorrection(**i.model_dump()) for i in body.items],
            property_types=property_types,
        )
    except UnknownCorrectionTarget as exc:
        raise ProblemException(422, "unknown-correction-target", str(exc)) from exc

    run = IdpRun(
        document_pk=document.id,
        run_type=IdpRunType.CORRECTED.value,
        status=IdpRunStatus.SUCCEEDED.value,
        executed_at=datetime.now(UTC),
        engine=base.engine,
        engine_info=base.engine_info,
        fields=values.fields,
        layout_tables=values.layout_tables,
        pattern_matches=base.pattern_matches,
        raw_response_ref=base.raw_response_ref,
        base_run_id=base.id,
        corrected_by=user.username or user.sub,
        corrections=_accumulate_corrections(base.corrections, body),
    )
    session.add(run)
    session.commit()
    return _to_response(run, verbose)
