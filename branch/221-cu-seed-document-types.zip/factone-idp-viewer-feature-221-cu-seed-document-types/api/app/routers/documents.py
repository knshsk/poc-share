"""文書登録API（Power Automate連携の受付部分）。

冪等性: 同一文書ID・同一内容の再送は200、内容不一致は409。
文書IDは呼出側採番で、SaaS内では採番・解決しない。
"""

import hashlib
import re
import uuid
from datetime import UTC, datetime
from typing import Annotated
from urllib.parse import quote

from fastapi import (
    APIRouter,
    Depends,
    Form,
    Request,
    Response,
    UploadFile,
)
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import Document
from app.services.blob import BlobStorage
from app.services.document_type_config import get_config
from app.services.pdf_render import PdfProcessingError, PdfRenderer

router = APIRouter(responses=problem_responses(401, 403, 422))

# 制御文字（一般カテゴリ Cc）と双方向制御文字（Bidi_Control）。原本ファイル名からは除き
# （表示順の偽装を防ぐ）、document_id では拒否する（document_id は生応答の Blob 名に使い、
# Azure は Blob 名の制御文字を受け付けない）
_UNSAFE_CHARS = re.compile(
    r"[\x00-\x1f\x7f-\x9f\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]"
)


class DocumentResponse(BaseModel):
    document_id: str
    tenant_id: str
    document_type: str
    content_sha256: str
    received_at: datetime
    # 原本ファイル名（basename）。登録時の original_filename、無ければ file の filename。
    # どちらも無い登録・列追加前の行は null
    original_filename: str | None


def _to_response(doc: Document) -> DocumentResponse:
    return DocumentResponse(
        document_id=doc.document_id,
        tenant_id=doc.tenant_id,
        document_type=doc.document_type,
        content_sha256=doc.content_sha256,
        received_at=doc.received_at,
        original_filename=doc.original_filename,
    )


@router.post(
    "/api/v1/documents",
    response_model=DocumentResponse,
    status_code=201,
    responses={200: {"model": DocumentResponse}, **problem_responses(409, 415)},
)
async def register_document(
    request: Request,
    response: Response,
    user: CurrentUser,
    document_id: Annotated[str, Form(min_length=1, max_length=255)],
    document_type: Annotated[str, Form(min_length=1, max_length=50)],
    file: UploadFile,
    session: Annotated[Session, Depends(get_db_session)],
    original_filename: Annotated[
        str | None,
        Form(
            description=(
                "原本のファイル名。指定時はMIMEヘッダフィールドのfilenameより優先する。"
            )
        ),
    ] = None,
) -> DocumentResponse:
    # Blob パスの区切りに使うため `/` `\` と `.` `..` そのものを拒否する（テナント境界越えの防止）。
    # pydantic-core の既定正規表現エンジン（rust-regex）が否定先読みを未サポートのため
    # Form(pattern=...) ではなく明示チェックにする
    if "/" in document_id or "\\" in document_id or document_id in (".", ".."):
        raise ProblemException(
            422, "validation-error", "document_id contains an invalid path segment"
        )
    if _UNSAFE_CHARS.search(document_id):
        raise ProblemException(
            422,
            "validation-error",
            "document_id contains a control or bidirectional control character",
        )

    content = await file.read()
    if file.content_type != "application/pdf" or not content.startswith(b"%PDF"):
        raise ProblemException(
            415, "unsupported-media-type", "Only PDF files are accepted"
        )
    # 開けないPDF（破損・閲覧パスワード付き）を登録すると、表示できないまま文書IDを使い続ける。
    # Viewerが文書を開くときに最初に呼ぶページ寸法の取得と同じ処理で、開けるかを確かめる
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        renderer.get_page_sizes(content)
    except PdfProcessingError:
        raise ProblemException(
            422, "invalid-pdf", "Failed to open PDF (corrupted or password-protected)"
        ) from None

    if get_config(session, user.tenant_id, document_type) is None:
        raise ProblemException(
            422, "unknown-document-type", "Unknown document type for this tenant"
        )
    blob_storage: BlobStorage = request.app.state.blob_storage
    sha256 = hashlib.sha256(content).hexdigest()

    existing = find_document(session, user.tenant_id, document_id)
    if existing is not None:
        return _respond_for_existing(response, existing, sha256, document_type)

    # Blob 名は INSERT 前に採番した内部 ID から作る。呼出側採番の document_id から作ると、
    # 挿入失敗で残った Blob や同時登録と同名になり、上書き不可の Azure では保存が失敗し続ける
    document_pk = uuid.uuid4()
    blob_ref = f"{user.tenant_id}/{document_pk}.pdf"
    document = Document(
        id=document_pk,
        document_id=document_id,
        tenant_id=user.tenant_id,
        document_type=document_type,
        blob_ref=blob_ref,
        content_sha256=sha256,
        original_filename=_original_filename(original_filename)
        or _original_filename(file.filename),
        received_at=datetime.now(UTC),
    )
    blob_storage.save(blob_ref, content)
    session.add(document)
    try:
        session.commit()
    except IntegrityError:
        # 同時登録の競合。既存行と突き合わせて冪等判定へフォールバック
        session.rollback()
        existing = find_document(session, user.tenant_id, document_id)
        if existing is None:
            raise
        return _respond_for_existing(response, existing, sha256, document_type)
    return _to_response(document)


def _original_filename(filename: str | None) -> str | None:
    """ファイル名から basename を取り出し（Windows/POSIX 区切り両対応）、制御文字・双方向制御文字を
    除いて 255 文字で切り詰める。空は None。"""
    name = _UNSAFE_CHARS.sub("", re.split(r"[\\/]", filename or "")[-1]).strip()
    return name[:255] or None


def pdf_response(document: Document, pdf: bytes) -> Response:
    """原本PDFの添付応答。保存名はアップロード時のファイル名（RFC 6266/5987）、未保存なら document_id.pdf。

    応答ヘッダは latin-1 で符号化されるため、filename には文書IDの ASCII 印字可能文字以外と
    `"` `\\` を `_` に置き換えた代替名を入れ、保存名は常に filename* で渡す。
    """
    name = document.original_filename or f"{document.document_id}.pdf"
    fallback = re.sub(r'[^\x20-\x7e]|["\\]', "_", document.document_id)
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{fallback}.pdf"; '
            f"filename*=UTF-8''{quote(name, safe='')}"
        },
    )


class PageInfo(BaseModel):
    width: float
    height: float


class PagesResponse(BaseModel):
    page_count: int
    pages: list[PageInfo]


def find_document(
    session: Session, tenant_id: str, document_id: str
) -> Document | None:
    """テナント内の文書を呼出側採番 ID で引く（document_id はテナント内でのみ一意）。

    NUL を含む ID は PostgreSQL に渡せず、登録でも拒否するため、照会せずに該当なしとする。
    """
    if "\x00" in document_id:
        return None
    return session.scalars(
        select(Document).where(
            Document.tenant_id == tenant_id, Document.document_id == document_id
        )
    ).one_or_none()


def _get_document_or_404(
    session: Session, tenant_id: str, document_id: str
) -> Document:
    document = find_document(session, tenant_id, document_id)
    # テナント不一致は存在自体を秘匿するため404（他テナント文書IDの受入観点に対応）
    if document is None:
        raise ProblemException(404, "document-not-found", "Document not found")
    return document


def _load_pdf(request: Request, document: Document) -> bytes:
    blob_storage: BlobStorage = request.app.state.blob_storage
    return blob_storage.load(document.blob_ref)


@router.get(
    "/api/v1/documents/{document_id}",
    response_model=DocumentResponse,
    responses=problem_responses(404),
)
def get_document(
    user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> DocumentResponse:
    return _to_response(_get_document_or_404(session, user.tenant_id, document_id))


@router.get(
    "/api/v1/documents/{document_id}/pages",
    response_model=PagesResponse,
    responses=problem_responses(404, 500),
)
def get_pages(
    request: Request,
    user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> PagesResponse:
    document = _get_document_or_404(session, user.tenant_id, document_id)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        sizes = renderer.get_page_sizes(_load_pdf(request, document))
    except PdfProcessingError as exc:
        raise ProblemException(
            500, "pdf-processing-failed", "Failed to process PDF"
        ) from exc
    return PagesResponse(
        page_count=len(sizes),
        pages=[PageInfo(width=size.width, height=size.height) for size in sizes],
    )


@router.get(
    "/api/v1/documents/{document_id}/pages/{page}/image",
    responses=problem_responses(404, 500),
)
def get_page_image(
    request: Request,
    user: CurrentUser,
    document_id: str,
    page: int,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document = _get_document_or_404(session, user.tenant_id, document_id)
    renderer: PdfRenderer = request.app.state.pdf_renderer
    try:
        png = renderer.render_page_png(_load_pdf(request, document), page - 1)
    except IndexError:
        raise ProblemException(404, "page-not-found", "Page not found") from None
    except PdfProcessingError as exc:
        raise ProblemException(
            500, "pdf-processing-failed", "Failed to process PDF"
        ) from exc
    return Response(content=png, media_type="image/png")


@router.get("/api/v1/documents/{document_id}/pdf", responses=problem_responses(404))
def get_original_pdf(
    request: Request,
    user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> Response:
    document = _get_document_or_404(session, user.tenant_id, document_id)
    return pdf_response(document, _load_pdf(request, document))


def _respond_for_existing(
    response: Response, existing: Document, sha256: str, document_type: str
) -> DocumentResponse:
    if existing.content_sha256 == sha256 and existing.document_type == document_type:
        # 冪等再送: 既定の201を200へ差し替える
        response.status_code = 200
        return _to_response(existing)
    raise ProblemException(
        409,
        "document-conflict",
        "Document ID already registered with different content",
    )
