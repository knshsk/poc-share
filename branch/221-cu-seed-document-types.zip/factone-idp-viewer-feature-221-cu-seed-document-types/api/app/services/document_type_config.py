"""文書種別設定の取得と、fields JSONBの型付き変換。"""

import enum
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import DocumentTypeConfig


class FieldType(enum.StrEnum):
    """抽出フィールドの型。正規化の駆動に使う。array は明細（オブジェクトのリスト）。"""

    STRING = "string"
    NUMBER = "number"
    DATE = "date"
    ARRAY = "array"


@dataclass(frozen=True)
class FieldDef:
    """抽出フィールド定義（設定のfields要素の型付き表現）。descriptionはエンジンへ渡す項目の説明。

    properties は array 型の項目だけが持つプロパティ（明細の列。型はスカラー）。
    """

    key: str
    label: str
    type: FieldType
    description: str | None = None
    properties: tuple[FieldDef, ...] = ()


@dataclass(frozen=True)
class PatternDef:
    """正規表現パターン定義（設定のpatterns要素の型付き表現）。"""

    key: str
    label: str
    regex: str


def get_config(
    session: Session, tenant_id: str, type_code: str
) -> DocumentTypeConfig | None:
    # NUL を含むコードは PostgreSQL に渡せず、作成時の形式検査で弾くため存在しない。照会せずに該当なしとする
    if "\x00" in type_code:
        return None
    return session.execute(
        select(DocumentTypeConfig).where(
            DocumentTypeConfig.tenant_id == tenant_id,
            DocumentTypeConfig.type_code == type_code,
        )
    ).scalar_one_or_none()


def _field_def(field: Mapping[str, Any]) -> FieldDef:
    # visible（Viewer表示可否）は設定APIの応答でViewerが参照する。抽出側は使わない
    return FieldDef(
        key=field["key"],
        label=field["label"],
        type=FieldType(field["type"]),
        description=field.get("description"),
        properties=tuple(_field_def(p) for p in field.get("properties") or ()),
    )


def config_field_defs(config: DocumentTypeConfig) -> tuple[FieldDef, ...]:
    return tuple(_field_def(f) for f in config.fields)


def config_pattern_defs(config: DocumentTypeConfig) -> tuple[PatternDef, ...]:
    return tuple(
        PatternDef(key=p["key"], label=p["label"], regex=p["regex"])
        for p in config.patterns
    )
