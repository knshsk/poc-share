"""Azure AI Content Understanding のアダプタ（ADR-0030）。

アナライザはテナント×文書種別ごとに 1 つ持ち、tags の定義のハッシュが今のスキーマと違えば
実行時に置き換える。解析は最終ポーリングの応答本文を bytes のまま取り、spans で全文から
切り出した原文を生値にする。PDF の座標はインチで返るため、単位の変換はしない。
モデルの別名とデプロイの対応は、アナライザを作る前にリソースの既定へ設定し、解析のリクエストでも渡す。
"""

import hashlib
import json
import logging
import re
from collections.abc import Iterable, Mapping, Sequence
from typing import Any, cast

from app.services.document_type_config import FieldDef, FieldType
from app.services.engine import (
    AnalysisResult,
    EngineError,
    LeafResult,
    Region,
    Rows,
    SchemaOwner,
)

logger = logging.getLogger(__name__)

ANALYZER_PREFIX = "factone_"
DEFINITION_TAG = "factone_definition"
# アナライザが参照するモデルの別名。デプロイとの対応は、リソースの既定（作成の前）と解析のリクエストで渡す。
# デプロイのモデルが自動で更新されても、アナライザの定義（とハッシュ）は変わらない
COMPLETION_ALIAS = "prebuilt-analyzer-completion"
EMBEDDING_ALIAS = "prebuilt-analyzer-embedding"
PROCESSING_LOCATION = "geography"

_SOURCE = re.compile(r"D\(([^)]*)\)")
_TYPED_VALUE_KEYS = ("valueString", "valueDate", "valueNumber", "valueInteger")


def analyzer_id(owner: SchemaOwner) -> str:
    """テナント×文書種別のアナライザ ID。CU の ID 制約に収めるため、組をハッシュにする。"""
    digest = hashlib.sha256(
        f"{owner.tenant_id}\0{owner.type_code}".encode()
    ).hexdigest()
    return f"{ANALYZER_PREFIX}{digest[:32]}"


def _field_schema(field: FieldDef) -> dict[str, Any]:
    # description が無い項目は label を説明として渡す
    description = field.description or field.label
    if field.type is FieldType.ARRAY:
        return {
            "type": "array",
            "method": "generate",
            "description": description,
            "items": {
                "type": "object",
                "method": "generate",
                "properties": {p.key: _field_schema(p) for p in field.properties},
            },
        }
    return {"type": field.type.value, "method": "extract", "description": description}


def analyzer_definition(schema: Sequence[FieldDef]) -> dict[str, Any]:
    """アナライザの定義（tags と description を除く。定義のハッシュの対象）。"""
    return {
        "baseAnalyzerId": "prebuilt-document",
        "config": {"returnDetails": False, "estimateFieldSourceAndConfidence": True},
        "processingLocation": PROCESSING_LOCATION,
        "models": {"completion": COMPLETION_ALIAS, "embedding": EMBEDDING_ALIAS},
        "fieldSchema": {"fields": {f.key: _field_schema(f) for f in schema}},
    }


def definition_hash(definition: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(definition, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()


def parse_source(source: str | None) -> Region | None:
    """`D(page,x1,y1,…,x4,y4)` / `D(page,left,top,width,height)` を `;` でつないだ根拠の領域を、
    先頭の領域と同じページの外接矩形 1 つにまとめる。解析できなければ None。"""
    boxes: list[tuple[int, list[float], list[float]]] = []
    for match in _SOURCE.finditer(source or ""):
        try:
            numbers = [float(n) for n in match.group(1).split(",")]
        except ValueError:
            return None
        page, coords = int(numbers[0]), numbers[1:]
        if len(coords) == 4:
            left, top, width, height = coords
            boxes.append((page, [left, left + width], [top, top + height]))
        elif len(coords) == 8:
            boxes.append((page, coords[0::2], coords[1::2]))
        else:
            return None
    if not boxes:
        return None
    page = boxes[0][0]
    xs = [x for p, bx, _ in boxes if p == page for x in bx]
    ys = [y for p, _, by in boxes if p == page for y in by]
    left, top, right, bottom = min(xs), min(ys), max(xs), max(ys)
    return Region(
        page_number=page,
        polygon=(left, top, right, top, right, bottom, left, bottom),
    )


def _leaf(field: Mapping[str, Any], markdown: str) -> LeafResult:
    spans = field.get("spans") or []
    value: str | None
    if spans:
        # 複数行にわたる値は span が分かれる。つなげると CU の valueString と一致する
        value = "".join(
            markdown[s["offset"] : s["offset"] + s["length"]] for s in spans
        )
    else:
        typed = next(
            (field[k] for k in _TYPED_VALUE_KEYS if field.get(k) is not None), None
        )
        value = None if typed is None else str(typed)
    return LeafResult(
        value=value,
        confidence=field.get("confidence"),
        region=parse_source(field.get("source")),
    )


def _fields(
    raw_fields: Mapping[str, Any], markdown: str
) -> dict[str, LeafResult | Rows]:
    fields: dict[str, LeafResult | Rows] = {}
    for key, field in raw_fields.items():
        if field.get("type") == "array":
            fields[key] = tuple(
                {
                    prop: _leaf(value, markdown)
                    for prop, value in (item.get("valueObject") or {}).items()
                }
                for item in field.get("valueArray") or []
            )
        else:
            fields[key] = _leaf(field, markdown)
    return fields


def _model_name(usage: Mapping[str, Any] | None) -> str | None:
    # usage.tokens のキーは「<モデル名>-input」「<モデル名>-output」
    for key in (usage or {}).get("tokens") or {}:
        for suffix in ("-input", "-output"):
            if key.endswith(suffix):
                return str(key[: -len(suffix)])
    return None


def build_analysis_result(
    raw_response: bytes, analyzer_id: str, definition_hash: str
) -> AnalysisResult:
    """最終ポーリングの応答本文（id / status / result / usage）から AnalysisResult を組み立てる。
    本文が JSON でない・想定外の形のときも、実行の失敗として EngineError にそろえる。"""
    try:
        return _convert(raw_response, analyzer_id, definition_hash)
    except (ValueError, TypeError, LookupError, AttributeError, OverflowError) as exc:
        raise EngineError(
            f"unexpected Content Understanding response: {exc!r}"
        ) from exc


def _convert(
    raw_response: bytes, analyzer_id: str, definition_hash: str
) -> AnalysisResult:
    body = json.loads(raw_response)
    result = body["result"]
    # span の offset / length を Python の文字列の添字として使うため、code point 単位に限る
    if result.get("stringEncoding") != "codePoint":
        raise EngineError(f"unexpected stringEncoding: {result.get('stringEncoding')}")
    contents = result.get("contents") or []
    if not contents:
        raise EngineError("Content Understanding returned no contents")
    content = contents[0]
    if content.get("unit") != "inch":
        raise EngineError(f"unexpected unit: {content.get('unit')}")
    markdown = content.get("markdown") or ""
    return AnalysisResult(
        fields=_fields(content.get("fields") or {}, markdown),
        layout_tables=(),
        content=markdown,
        engine_info={
            "api_version": result.get("apiVersion"),
            "analyzer_id": analyzer_id,
            "definition_hash": definition_hash,
            "model": _model_name(body.get("usage")),
        },
        raw_response=raw_response,
    )


def _error_detail(poller: Any) -> str:
    """失敗した解析の応答本文にある error（原因）。最終ポーリングが読めない場合は空。"""
    from azure.core.exceptions import AzureError

    try:
        return f": {json.loads(poller.result())['error']}"
    except AzureError, TypeError, ValueError, LookupError:
        return ""


def stale_analyzer_ids(
    existing: Iterable[str], owners: Iterable[SchemaOwner]
) -> list[str]:
    """factone_ で始まり、azure-cu の文書種別設定に対応しないアナライザ ID（掃除の候補）。"""
    expected = {analyzer_id(o) for o in owners}
    return sorted(
        i for i in existing if i.startswith(ANALYZER_PREFIX) and i not in expected
    )


class ContentUnderstandingAnalyzer:
    """Azure AI Content Understanding 実装。認証は Entra（DefaultAzureCredential）のみ。"""

    def __init__(
        self,
        endpoint: str,
        completion_deployment: str,
        embedding_deployment: str,
        timeout_seconds: int,
    ) -> None:
        from azure.ai.contentunderstanding import ContentUnderstandingClient
        from azure.identity import DefaultAzureCredential

        self._client = ContentUnderstandingClient(endpoint, DefaultAzureCredential())
        self._model_deployments = {
            COMPLETION_ALIAS: completion_deployment,
            EMBEDDING_ALIAS: embedding_deployment,
        }
        self._timeout_seconds = timeout_seconds

    def analyze(
        self, pdf: bytes, schema: tuple[FieldDef, ...], schema_owner: SchemaOwner
    ) -> AnalysisResult:
        from azure.core.exceptions import AzureError

        if not all(self._model_deployments.values()):
            raise EngineError(
                "Content Understanding model deployments are not configured"
            )
        definition = analyzer_definition(schema)
        digest = definition_hash(definition)
        target = analyzer_id(schema_owner)
        try:
            self._ensure_analyzer(target, definition, digest, schema_owner)
            raw_response = self._analyze(target, pdf)
        except AzureError as exc:
            raise EngineError(str(exc)) from exc
        return build_analysis_result(raw_response, target, digest)

    def _ensure_analyzer(
        self,
        target: str,
        definition: dict[str, Any],
        digest: str,
        owner: SchemaOwner,
    ) -> None:
        """定義のハッシュが一致する ready のアナライザが無ければ、作成（置き換え）して完了を待つ。"""
        from azure.core.exceptions import ResourceNotFoundError

        try:
            current = self._client.get_analyzer(target)
            if (
                current.status == "ready"
                and (current.tags or {}).get(DEFINITION_TAG) == digest
            ):
                return
        except ResourceNotFoundError:
            pass
        # CU はリソースの既定が未設定だとアナライザを作らせない（DefaultsNotSet）。別名をこの環境の
        # デプロイに対応させる（マージパッチで冪等）。解析のリクエストでも model_deployments は渡す
        self._client.update_defaults(model_deployments=dict(self._model_deployments))
        poller = self._client.begin_create_analyzer(
            target,
            {
                **definition,
                # ポータルで見分けるための説明。ハッシュの対象外
                "description": f"factone {owner.tenant_id}/{owner.type_code}",
                "tags": {DEFINITION_TAG: digest},
            },
            allow_replace=True,
        )
        poller.wait(timeout=self._timeout_seconds)
        if not poller.done():
            raise EngineError("Content Understanding analyzer creation timed out")
        created = poller.result()
        if created.status != "ready":
            raise EngineError(
                f"Content Understanding analyzer creation {created.status}"
            )

    def _analyze(self, target: str, pdf: bytes) -> bytes:
        from azure.ai.contentunderstanding.models import AnalysisInput
        from azure.core.exceptions import AzureError

        # 最終ポーリングGETの応答本文をbytesのまま受け取る（生応答として保存する。ADR-0019）
        def capture(pipeline_response: Any, _deserialized: Any, _headers: Any) -> bytes:
            return cast(bytes, pipeline_response.http_response.content)

        poller = self._client.begin_analyze(
            target,
            inputs=[AnalysisInput(data=pdf, mime_type="application/pdf")],
            model_deployments=self._model_deployments,
            processing_location=PROCESSING_LOCATION,
            cls=capture,
        )
        # result(timeout)はタイムアウト時に例外を出さず未完了応答を返すため、done()で判定する
        poller.wait(timeout=self._timeout_seconds)
        if not poller.done():
            raise EngineError("Content Understanding request timed out")
        # 最終ポーリングが失敗（5xx・本文が JSON でない等）しても、SDK の wait() は例外を出さない。
        # result() は最後の応答を JSON として読むため、例外を出すか手前の応答（Running の本文）や
        # None を返す。result() の前に状態で成功を確かめる
        status = poller.status()
        if status.lower() != "succeeded":
            raise EngineError(
                f"Content Understanding analysis {status}{_error_detail(poller)}"
            )
        try:
            raw_response = poller.result()
        except ValueError as exc:
            raise EngineError(
                f"Content Understanding analysis response is unreadable: {exc!r}"
            ) from exc
        if not isinstance(raw_response, bytes):
            raise EngineError("Content Understanding analysis returned no body")
        # 生応答は Blob に保存するので、CU 側の結果（最大 24 時間残る）は消す。失敗しても実行は続ける
        try:
            self._client.delete_result(poller.operation_id)
        except AzureError, ValueError:
            logger.warning(
                "Content Understanding の解析結果を削除できなかった", exc_info=True
            )
        return raw_response
