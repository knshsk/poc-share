"""Document Intelligence のアダプタ（prebuilt-layout + Query Fields）。

文書種別設定のスキーマのキーを Query Fields に渡す。DI は PDF の座標をインチで返すため、
座標は変換せずに Region へ入れる。テストではエンジン境界（engine.py）ごとフェイクに差し替える。
"""

import io
from typing import Any, cast

from app.services.document_type_config import FieldDef
from app.services.engine import (
    AnalysisResult,
    EngineError,
    LayoutTable,
    LayoutTableCell,
    LeafResult,
    Region,
    Rows,
    SchemaOwner,
)

# Query Fields に指定できる項目数の上限（DI の仕様）。文書種別設定の保存時に検査する
MAX_QUERY_FIELDS = 20


def _first_region(bounding_regions: Any) -> Region | None:
    """boundingRegions[0] を採る（項目・セルは通常 1 領域）。無ければ None。"""
    if not bounding_regions:
        return None
    first = bounding_regions[0]
    return Region(page_number=first.page_number, polygon=tuple(first.polygon))


def extract_tables(tables: Any) -> tuple[LayoutTable, ...]:
    """layout 応答の tables を LayoutTable へ変換する。複数認識時は全件返す。"""
    extracted: list[LayoutTable] = []
    for table in tables or []:
        cells = []
        for cell in table.cells or []:
            region = _first_region(cell.bounding_regions)
            cells.append(
                LayoutTableCell(
                    row_index=cell.row_index,
                    column_index=cell.column_index,
                    content=cell.content,
                    kind=cell.kind,
                    page_number=region.page_number if region else None,
                    polygon=region.polygon if region else None,
                    row_span=cell.row_span or 1,
                    column_span=cell.column_span or 1,
                )
            )
        extracted.append(
            LayoutTable(
                row_count=table.row_count,
                column_count=table.column_count,
                cells=tuple(cells),
            )
        )
    return tuple(extracted)


def build_analysis_result(result: Any, raw_response: bytes) -> AnalysisResult:
    """SDK の AnalyzeResult と応答本文から AnalysisResult を組み立てる。

    documents の要素はすべて読み、同じキーが複数の要素にあれば後の要素の値を採る。
    """
    fields: dict[str, LeafResult | Rows] = {}
    for document in result.documents or []:
        for name, field in (document.fields or {}).items():
            fields[name] = LeafResult(
                value=field.content,
                confidence=field.confidence,
                region=_first_region(field.bounding_regions),
            )
    return AnalysisResult(
        fields=fields,
        layout_tables=extract_tables(result.tables),
        content=result.content or "",
        engine_info={"api_version": result.api_version, "model_id": result.model_id},
        raw_response=raw_response,
    )


class AzureDocumentAnalyzer:
    """Azure Document Intelligence 実装（prebuilt-layout + Query Fields）。

    api_key 未設定時は Managed ID（DefaultAzureCredential）で認証する。
    """

    def __init__(self, endpoint: str, api_key: str, timeout_seconds: int) -> None:
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        from azure.core.credentials import AzureKeyCredential

        credential: object
        if api_key:
            credential = AzureKeyCredential(api_key)
        else:
            from azure.identity import DefaultAzureCredential

            credential = DefaultAzureCredential()
        self._client = DocumentIntelligenceClient(endpoint, credential)
        self._timeout_seconds = timeout_seconds

    def analyze(
        self, pdf: bytes, schema: tuple[FieldDef, ...], schema_owner: SchemaOwner
    ) -> AnalysisResult:
        from azure.ai.documentintelligence.models import DocumentAnalysisFeature
        from azure.core.exceptions import AzureError

        # 最終ポーリングGETの応答本文をbytesのまま受け取るため、デシリアライズ結果と併せて返す
        def capture(
            pipeline_response: Any, deserialized: Any, _headers: Any
        ) -> tuple[Any, bytes]:
            return deserialized, pipeline_response.http_response.content

        try:
            poller = self._client.begin_analyze_document(
                "prebuilt-layout",
                io.BytesIO(pdf),
                content_type="application/pdf",
                features=[DocumentAnalysisFeature.QUERY_FIELDS],
                query_fields=[f.key for f in schema],
                cls=capture,
            )
            # result(timeout)はタイムアウト時に例外を出さず未完了応答を返すため、done()で判定する
            poller.wait(timeout=self._timeout_seconds)
            if not poller.done():
                raise EngineError("Document Intelligence request timed out")
            deserialized, raw_response = cast(tuple[Any, bytes], poller.result())
        except AzureError as exc:
            raise EngineError(str(exc)) from exc
        return build_analysis_result(deserialized, raw_response)
