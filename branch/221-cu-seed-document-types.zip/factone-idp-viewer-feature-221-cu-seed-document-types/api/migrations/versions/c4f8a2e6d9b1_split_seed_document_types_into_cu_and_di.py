"""シードの注文書・見積書を CU の種別にし、DI の種別を _di の種別コードで残す

default テナントの DI の purchase_order / quotation を purchase_order_di / quotation_di に改名し、
参照する文書の document_type も書き換える。見積書は CU・DI の両方に版数（RevisionNumber）を足す。
空いた purchase_order / quotation には、ヘッダ項目のキー・ラベル・型・表示有無を DI と同じにし、
明細（LineItems）を足した CU の種別を入れる（#221）。downgrade は CU の種別を参照する文書があれば止める。

Revision ID: c4f8a2e6d9b1
Revises: e8c3a7d5f1b2
Create Date: 2026-10-29 12:00:00.000000

"""

import json
import uuid
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision: str = "c4f8a2e6d9b1"
down_revision: str | None = "e8c3a7d5f1b2"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLE = sa.table(
    "document_type_configs",
    sa.column("id", UUID(as_uuid=True)),
    sa.column("tenant_id", sa.String),
    sa.column("type_code", sa.String),
    sa.column("display_name", sa.String),
    sa.column("shareable", sa.Boolean),
    sa.column("engine", sa.String),
    sa.column("fields", JSONB),
    sa.column("patterns", JSONB),
)

_PATTERNS = [{"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}]

# 見積書の版数。帳票では「第2版」のように書かれるため string 型とする（DI の種別には説明を付けない）
_REVISION = {"key": "RevisionNumber", "label": "版数", "type": "string"}


def _common_fields(document: str) -> list[dict]:
    """DI のシード（b7e3d2a9c1f5）の共通 8 項目に、CU に渡す英語の説明を付けたもの。"""
    if document == "purchase order":
        sender = (
            "Name of the company that issued this purchase order (the buyer). "
            "Exclude department names. Do not return the addressee company."
        )
        contact = "Name of the person in charge on the buyer's side."
        quotation = (
            "Number of the quotation this order is based on. "
            "Not the purchase order number."
        )
        delivery = "Delivery due date for the whole order, if stated as a single date."
    else:
        sender = (
            "Name of the company that issued this quotation. "
            "Exclude department names. Do not return the addressee company."
        )
        contact = "Name of the contact person at the addressee company."
        quotation = "Number the issuer assigned to this quotation."
        delivery = (
            "Delivery due date stated in this quotation, if stated as a single date."
        )
    return [
        {
            "key": "SenderCompanyName",
            "label": "取引先",
            "type": "string",
            "description": sender,
        },
        {
            "key": "ReceiverCompanyName",
            "label": "自社名",
            "type": "string",
            "visible": False,
            "description": f"Name of the company this {document} is addressed to.",
        },
        {
            "key": "OrderDate",
            "label": "注文日",
            "type": "date",
            "description": (
                f"Date this {document} was issued. "
                "May be written in the Japanese era calendar."
            ),
        },
        {
            "key": "TotalAmount",
            "label": "合計金額",
            "type": "number",
            "description": "Total amount including consumption tax.",
        },
        {
            "key": "DeliveryDate",
            "label": "納品期限",
            "type": "date",
            "description": delivery,
        },
        {
            "key": "DeliveryLocation",
            "label": "納品場所",
            "type": "string",
            "description": "Place where the goods are to be delivered.",
        },
        {
            "key": "CustomerContactPersonName",
            "label": "取引先担当者",
            "type": "string",
            "description": contact,
        },
        {
            "key": "QuotationId",
            "label": "見積書ID",
            "type": "string",
            "description": quotation,
        },
    ]


_LINE_ITEMS = {
    "key": "LineItems",
    "label": "明細",
    "type": "array",
    "description": (
        "Line items. One element per row of the line item table, top to bottom. "
        "Exclude subtotal, tax and total rows."
    ),
    "properties": [
        {
            "key": "ItemCode",
            "label": "品番",
            "type": "string",
            "description": "Item code of the row.",
        },
        {
            "key": "ItemName",
            "label": "品名",
            "type": "string",
            "description": "Item name of the row.",
        },
        {
            "key": "Quantity",
            "label": "数量",
            "type": "number",
            "description": "Quantity of the row.",
        },
        {
            "key": "UnitName",
            "label": "単位",
            "type": "string",
            "description": "Unit of measure of the row.",
        },
        {
            "key": "UnitPrice",
            "label": "単価",
            "type": "number",
            "description": "Unit price of the row.",
        },
        {
            "key": "LineAmount",
            "label": "金額",
            "type": "number",
            "description": "Line amount of the row.",
        },
    ],
}

_CU_SEED = [
    (
        "purchase_order",
        "注文書",
        False,
        [
            *_common_fields("purchase order"),
            {
                "key": "PurchaseOrderId",
                "label": "注文書ID",
                "type": "string",
                "description": (
                    "Order number the buyer assigned to this purchase order. "
                    "Not the quotation number."
                ),
            },
            _LINE_ITEMS,
        ],
    ),
    (
        "quotation",
        "見積書",
        True,
        [
            *_common_fields("quotation"),
            {**_REVISION, "description": "Revision number of this quotation."},
            _LINE_ITEMS,
        ],
    ),
]


def _rename(old: str, new: str, display_name: str) -> None:
    op.execute(
        _TABLE.update()
        .where(
            _TABLE.c.tenant_id == "default",
            _TABLE.c.type_code == old,
            _TABLE.c.engine == "azure-di",
        )
        .values(type_code=new, display_name=display_name)
    )
    op.execute(
        sa.text(
            "UPDATE documents SET document_type = :new "
            "WHERE tenant_id = 'default' AND document_type = :old"
        ).bindparams(new=new, old=old)
    )


def upgrade() -> None:
    for code, name, *_ in _CU_SEED:
        _rename(code, f"{code}_di", f"{name}（DI）")
    op.execute(
        sa.text(
            "UPDATE document_type_configs SET fields = fields || CAST(:f AS jsonb) "
            "WHERE tenant_id = 'default' AND type_code = 'quotation_di' "
            'AND NOT fields @> \'[{"key": "RevisionNumber"}]\''
        ).bindparams(f=json.dumps([_REVISION], ensure_ascii=False))
    )
    op.bulk_insert(
        _TABLE,
        [
            {
                "id": uuid.uuid4(),
                "tenant_id": "default",
                "type_code": code,
                "display_name": name,
                "shareable": shareable,
                "engine": "azure-cu",
                "fields": fields,
                "patterns": _PATTERNS,
            }
            for code, name, shareable, fields in _CU_SEED
        ],
    )


def downgrade() -> None:
    # CU の種別の文書を DI の種別へ移すと、明細（items）を持つ実行と種別のエンジンが食い違う。黙って移さずに止める
    in_use = op.get_bind().scalar(
        sa.text(
            "SELECT EXISTS (SELECT 1 FROM documents WHERE tenant_id = 'default' "
            "AND document_type IN ('purchase_order', 'quotation'))"
        )
    )
    if in_use:
        raise RuntimeError(
            "documents reference the azure-cu seed document types; cannot downgrade"
        )
    op.execute(
        _TABLE.delete().where(
            _TABLE.c.tenant_id == "default",
            _TABLE.c.type_code.in_([code for code, *_ in _CU_SEED]),
            _TABLE.c.engine == "azure-cu",
        )
    )
    op.execute(
        "UPDATE document_type_configs SET fields = (SELECT jsonb_agg(f ORDER BY i) "
        "FROM jsonb_array_elements(fields) WITH ORDINALITY AS t(f, i) "
        "WHERE f ->> 'key' <> 'RevisionNumber') "
        "WHERE tenant_id = 'default' AND type_code = 'quotation_di'"
    )
    for code, name, *_ in _CU_SEED:
        _rename(f"{code}_di", code, name)
