"""document_type_configs に engine を追加する

抽出エンジンを文書種別の単位で選ぶ（ADR-0029）。既存の行は azure-di になる。
既定値はDB側にも残し、エンジンを指定しない投入（シード・テスト）でも NOT NULL を満たす。

Revision ID: a1e5c8f2d7b4
Revises: c4d931791740
Create Date: 2026-10-09 12:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "a1e5c8f2d7b4"
down_revision: str | None = "c4d931791740"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "document_type_configs",
        sa.Column(
            "engine", sa.String(length=20), nullable=False, server_default="azure-di"
        ),
    )


def downgrade() -> None:
    op.drop_column("document_type_configs", "engine")
