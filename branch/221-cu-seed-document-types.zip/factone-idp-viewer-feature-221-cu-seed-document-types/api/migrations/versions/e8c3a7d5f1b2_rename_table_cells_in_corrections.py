"""保存済みの corrections の table_cells を layout_table_cells に改名する

修正APIのボディのキー名変更（ADR-0029）に合わせて、corrected 行が保存している累積差分の
キーを書き換える。連鎖修正は base の corrections を読んで重ねるため、旧いキーが残ると
移行前の修正が累積から落ちる。

Revision ID: e8c3a7d5f1b2
Revises: b6d2f9a4c8e1
Create Date: 2026-10-09 13:00:00.000000

"""

from collections.abc import Sequence

from alembic import op

revision: str = "e8c3a7d5f1b2"
down_revision: str | None = "b6d2f9a4c8e1"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _rename(old: str, new: str) -> None:
    op.execute(
        f"""
        UPDATE idp_runs
        SET corrections = (corrections - '{old}')
            || jsonb_build_object('{new}', COALESCE(corrections -> '{old}', '[]'::jsonb))
        WHERE corrections IS NOT NULL
        """
    )


def upgrade() -> None:
    _rename("table_cells", "layout_table_cells")


def downgrade() -> None:
    _rename("layout_table_cells", "table_cells")
