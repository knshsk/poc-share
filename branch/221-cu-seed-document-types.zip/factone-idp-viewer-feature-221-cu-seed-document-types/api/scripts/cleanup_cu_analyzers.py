"""削除した文書種別・テナントの設定に残った Content Understanding のアナライザを消す（ADR-0030）。

使い方: uv run python scripts/cleanup_cu_analyzers.py [--apply]

既定は消さずに候補を表示する。--apply を付けたときだけ消す。接続先は FACTONE_DATABASE_URL と
FACTONE_CU_ENDPOINT（認証は DefaultAzureCredential）。Azure では API のコンテナで実行する。
"""

import argparse
import sys

from sqlalchemy import select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.db import create_db_engine
from app.models import DocumentTypeConfig
from app.services.cu import stale_analyzer_ids
from app.services.engine import EngineName, SchemaOwner


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="削除した文書種別・テナントの設定に残った Content Understanding のアナライザを消す"
    )
    parser.add_argument("--apply", action="store_true", help="候補を実際に削除する")
    args = parser.parse_args(argv)
    settings = Settings()
    if not settings.cu_endpoint:
        print("FACTONE_CU_ENDPOINT が設定されていない", file=sys.stderr)
        return 1

    from azure.ai.contentunderstanding import ContentUnderstandingClient
    from azure.identity import DefaultAzureCredential

    client = ContentUnderstandingClient(settings.cu_endpoint, DefaultAzureCredential())
    # アナライザを先に取り、DB は後で読む。その間に作られた文書種別を候補にしないため
    existing = [a.analyzer_id for a in client.list_analyzers()]
    with Session(create_db_engine(settings.database_url)) as session:
        owners = [
            SchemaOwner(tenant_id=tenant_id, type_code=type_code)
            for tenant_id, type_code in session.execute(
                select(
                    DocumentTypeConfig.tenant_id, DocumentTypeConfig.type_code
                ).where(DocumentTypeConfig.engine == EngineName.AZURE_CU.value)
            )
        ]
    # 対象を見せる。パスワードは表示しない
    url = make_url(settings.database_url)
    print(f"CU エンドポイント: {settings.cu_endpoint}")
    print(f"DB: {url.host} / {url.database}")
    print(f"azure-cu の文書種別: {len(owners)} 件")
    if not owners:
        print(
            "azure-cu の文書種別設定が 0 件。接続先の DB を確かめること。--apply は行わない",
            file=sys.stderr,
        )
        if args.apply:
            return 1
    stale = stale_analyzer_ids(existing, owners)
    for target in stale:
        print(target)
        if args.apply:
            client.delete_analyzer(target)
    print(
        f"{len(stale)} 件{'を削除した' if args.apply else 'が削除の候補（--apply で削除する）'}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
