"""文書種別設定CRUD APIのテスト。"""

import pytest
from fastapi.testclient import TestClient

VALID_FIELDS = [
    {"key": "invoice_no", "label": "請求書番号", "type": "string"},
    {"key": "billing_amount", "label": "請求金額", "type": "number"},
    {"key": "due_date", "label": "支払期日", "type": "date"},
]
VALID_PAYLOAD = {
    "type_code": "invoice",
    "display_name": "請求書",
    "shareable": True,
    "fields": VALID_FIELDS,
}
LINE_ITEMS = {
    "key": "LineItems",
    "label": "明細",
    "type": "array",
    "properties": [
        {"key": "ProductName", "label": "品名", "type": "string"},
        {"key": "Quantity", "label": "数量", "type": "number", "description": "注文数"},
    ],
}
CU_PAYLOAD = {
    **VALID_PAYLOAD,
    "type_code": "order_cu",
    "engine": "azure-cu",
    "fields": [*VALID_FIELDS, LINE_ITEMS],
}


def _fields(count: int) -> list[dict[str, object]]:
    return [
        {"key": f"field_{i}", "label": f"項目{i}", "type": "string"}
        for i in range(count)
    ]


class TestList:
    def test_returns_seeded_configs(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types")
        assert response.status_code == 200
        body = response.json()
        codes = {c["type_code"] for c in body}
        assert codes == {"purchase_order", "quotation"}
        # シードはReceiverCompanyNameのみvisible=false。未指定はtrue補完される（#91）
        hidden = {f["key"] for c in body for f in c["fields"] if not f["visible"]}
        assert hidden == {"ReceiverCompanyName"}

    def test_requires_auth(self, doc_client: TestClient) -> None:
        response = doc_client.get(
            "/api/v1/config/document-types", headers={"Authorization": "Bearer bad"}
        )
        assert response.status_code == 401


class TestCreate:
    def test_creates_new_config(self, doc_client: TestClient) -> None:
        response = doc_client.post("/api/v1/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 201
        body = response.json()
        assert body["type_code"] == "invoice"
        # visible省略時はtrue補完して応答される（#91）
        assert body["fields"] == [
            {**f, "visible": True, "description": None, "properties": None}
            for f in VALID_FIELDS
        ]
        assert body["engine"] == "azure-di"

    def test_cu_accepts_array_field(self, doc_client: TestClient) -> None:
        response = doc_client.post("/api/v1/config/document-types", json=CU_PAYLOAD)
        assert response.status_code == 201
        body = response.json()
        assert body["engine"] == "azure-cu"
        line_items = body["fields"][-1]
        assert line_items["type"] == "array"
        assert line_items["properties"] == [
            {
                "key": "ProductName",
                "label": "品名",
                "type": "string",
                "description": None,
            },
            {
                "key": "Quantity",
                "label": "数量",
                "type": "number",
                "description": "注文数",
            },
        ]
        assert body["fields"][0]["properties"] is None

    def test_di_rejects_array_field(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**CU_PAYLOAD, "engine": "azure-di"},
        )
        assert response.status_code == 422
        assert any(
            "does not support array" in e["msg"] for e in response.json()["errors"]
        )

    @pytest.mark.parametrize(
        "field",
        [
            {**LINE_ITEMS, "properties": []},
            {k: v for k, v in LINE_ITEMS.items() if k != "properties"},
            {**VALID_FIELDS[0], "properties": LINE_ITEMS["properties"]},
            {
                **LINE_ITEMS,
                "properties": [
                    LINE_ITEMS["properties"][0],
                    LINE_ITEMS["properties"][0],
                ],
            },
            {
                **LINE_ITEMS,
                "properties": [{"key": "Nested", "label": "入れ子", "type": "array"}],
            },
            {
                **LINE_ITEMS,
                "properties": [{"key": "Bad-Key", "label": "不正", "type": "string"}],
            },
            {
                **LINE_ITEMS,
                "properties": [
                    {
                        "key": "Note",
                        "label": "備考",
                        "type": "string",
                        "description": "",
                    }
                ],
            },
            {
                **LINE_ITEMS,
                "properties": [{"key": "Note", "label": "備\x00考", "type": "string"}],
            },
        ],
        ids=[
            "empty_properties",
            "missing_properties",
            "properties_on_scalar",
            "duplicate_property_key",
            "nested_array",
            "invalid_property_key",
            "empty_property_description",
            "nul_in_property_label",
        ],
    )
    def test_invalid_array_field_returns_422(
        self, doc_client: TestClient, field: dict[str, object]
    ) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**CU_PAYLOAD, "fields": [*VALID_FIELDS, field]},
        )
        assert response.status_code == 422
        assert response.json()["type"] == "/errors/validation-error"

    # visible省略時はtrue補完、false指定は保持して応答されることを確認する（#91）
    def test_visible_defaults_true_and_roundtrips_false(
        self, doc_client: TestClient
    ) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [
                {"key": "invoice_no", "label": "請求書番号", "type": "string"},
                {
                    "key": "own_company",
                    "label": "自社名",
                    "type": "string",
                    "visible": False,
                },
            ],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 201
        assert [f["visible"] for f in response.json()["fields"]] == [True, False]

        fetched = doc_client.get("/api/v1/config/document-types/invoice")
        assert fetched.status_code == 200
        assert [f["visible"] for f in fetched.json()["fields"]] == [True, False]

    def test_duplicate_type_code_returns_409(self, doc_client: TestClient) -> None:
        assert (
            doc_client.post(
                "/api/v1/config/document-types", json=VALID_PAYLOAD
            ).status_code
            == 201
        )
        response = doc_client.post("/api/v1/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 409

    def test_invalid_type_code_returns_422(self, doc_client: TestClient) -> None:
        payload = {**VALID_PAYLOAD, "type_code": "Invalid-Code"}
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_pascal_case_key_and_type_code_accepted(
        self, doc_client: TestClient
    ) -> None:
        payload = {
            **VALID_PAYLOAD,
            "type_code": "PurchaseOrder",
            "fields": [{"key": "InvoiceNo", "label": "請求書番号", "type": "string"}],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 201
        assert response.json()["fields"][0]["key"] == "InvoiceNo"

    def test_empty_fields_returns_422(self, doc_client: TestClient) -> None:
        payload = {**VALID_PAYLOAD, "fields": []}
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_duplicate_field_key_returns_422(self, doc_client: TestClient) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [
                {"key": "invoice_no", "label": "請求書番号", "type": "string"},
                {"key": "invoice_no", "label": "重複キー", "type": "string"},
            ],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_invalid_field_type_returns_422(self, doc_client: TestClient) -> None:
        payload = {
            **VALID_PAYLOAD,
            "fields": [{"key": "invoice_no", "label": "番号", "type": "boolean"}],
        }
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422

    def test_patterns_default_empty(self, doc_client: TestClient) -> None:
        # patterns省略時は空配列で応答する（既存クライアント互換）
        response = doc_client.post("/api/v1/config/document-types", json=VALID_PAYLOAD)
        assert response.status_code == 201
        assert response.json()["patterns"] == []

    def test_patterns_roundtrip(self, doc_client: TestClient) -> None:
        patterns = [{"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}]
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**VALID_PAYLOAD, "patterns": patterns},
        )
        assert response.status_code == 201
        assert response.json()["patterns"] == patterns
        listed = doc_client.get("/api/v1/config/document-types/invoice").json()
        assert listed["patterns"] == patterns

    def test_invalid_regex_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [{"key": "Bad", "label": "不正", "regex": "("}],
            },
        )
        assert response.status_code == 422

    def test_too_long_regex_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [{"key": "Long", "label": "長い", "regex": "a" * 513}],
            },
        )
        assert response.status_code == 422

    def test_duplicate_pattern_key_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [
                    {"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"},
                    {"key": "TCode", "label": "重複", "regex": r"T\d{13}"},
                ],
            },
        )
        assert response.status_code == 422

    def test_pattern_key_may_equal_field_key(self, doc_client: TestClient) -> None:
        # fieldsとpatternsのkeyは別空間。重複を許す
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={
                **VALID_PAYLOAD,
                "patterns": [
                    {"key": "invoice_no", "label": "請求書番号", "regex": r"INV-\d+"}
                ],
            },
        )
        assert response.status_code == 201

    def test_description_roundtrips(self, doc_client: TestClient) -> None:
        fields = [{**VALID_FIELDS[0], "description": "請求書の右上にある番号"}]
        response = doc_client.post(
            "/api/v1/config/document-types", json={**VALID_PAYLOAD, "fields": fields}
        )
        assert response.status_code == 201
        assert response.json()["fields"][0]["description"] == "請求書の右上にある番号"

    @pytest.mark.parametrize("description", ["", "x" * 1025])
    def test_description_out_of_range_returns_422(
        self, doc_client: TestClient, description: str
    ) -> None:
        fields = [{**VALID_FIELDS[0], "description": description}]
        response = doc_client.post(
            "/api/v1/config/document-types", json={**VALID_PAYLOAD, "fields": fields}
        )
        assert response.status_code == 422
        assert response.json()["type"] == "/errors/validation-error"

    def test_description_of_1024_chars_is_accepted(
        self, doc_client: TestClient
    ) -> None:
        fields = [{**VALID_FIELDS[0], "description": "x" * 1024}]
        response = doc_client.post(
            "/api/v1/config/document-types", json={**VALID_PAYLOAD, "fields": fields}
        )
        assert response.status_code == 201

    def test_unknown_engine_returns_422(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**VALID_PAYLOAD, "engine": "azure-xx"},
        )
        assert response.status_code == 422

    def test_di_accepts_20_fields(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**VALID_PAYLOAD, "engine": "azure-di", "fields": _fields(20)},
        )
        assert response.status_code == 201

    def test_di_rejects_21_fields(self, doc_client: TestClient) -> None:
        response = doc_client.post(
            "/api/v1/config/document-types",
            json={**VALID_PAYLOAD, "fields": _fields(21)},
        )
        assert response.status_code == 422
        body = response.json()
        assert body["type"] == "/errors/validation-error"
        assert any("at most 20" in e["msg"] for e in body["errors"])

    @pytest.mark.parametrize(
        "payload",
        [
            {**VALID_PAYLOAD, "display_name": "請求\x00書"},
            {
                **VALID_PAYLOAD,
                "fields": [
                    {"key": "invoice_no", "label": "請求書\x00番号", "type": "string"}
                ],
            },
            {
                **VALID_PAYLOAD,
                "fields": [
                    {
                        "key": "invoice_no",
                        "label": "請求書番号",
                        "type": "string",
                        "description": "番\x00号",
                    }
                ],
            },
            {
                **VALID_PAYLOAD,
                "patterns": [
                    {"key": "TCode", "label": "登録\x00番号", "regex": r"T\d{13}"}
                ],
            },
            {
                **VALID_PAYLOAD,
                "patterns": [{"key": "TCode", "label": "登録番号", "regex": "T\x00"}],
            },
        ],
        ids=[
            "display_name",
            "field_label",
            "field_description",
            "pattern_label",
            "pattern_regex",
        ],
    )
    def test_nul_in_text_returns_422(
        self, doc_client: TestClient, payload: dict[str, object]
    ) -> None:
        response = doc_client.post("/api/v1/config/document-types", json=payload)
        assert response.status_code == 422
        assert response.json()["type"] == "/errors/validation-error"


class TestGet:
    def test_returns_single_config(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types/quotation")
        assert response.status_code == 200
        body = response.json()
        assert body["display_name"] == "見積書"
        assert body["shareable"] is True

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types/unknown")
        assert response.status_code == 404

    def test_nul_in_type_code_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.get("/api/v1/config/document-types/quota%00tion")
        assert response.status_code == 404
        assert response.json()["type"] == "/errors/document-type-not-found"


class TestUpdate:
    def test_replaces_config(self, doc_client: TestClient) -> None:
        payload = {
            "display_name": "見積書（改）",
            "shareable": False,
            "fields": [{"key": "document_no", "label": "番号", "type": "string"}],
        }
        response = doc_client.put(
            "/api/v1/config/document-types/quotation", json=payload
        )
        assert response.status_code == 200
        body = response.json()
        assert body["display_name"] == "見積書（改）"
        assert body["shareable"] is False
        assert len(body["fields"]) == 1

    def test_put_without_engine_resets_to_azure_di(
        self, doc_client: TestClient
    ) -> None:
        # PUT は全置換。engine を省略すると既定値 azure-di になる
        response = doc_client.put(
            "/api/v1/config/document-types/quotation",
            json={"display_name": "見積書", "shareable": True, "fields": VALID_FIELDS},
        )
        assert response.status_code == 200
        assert response.json()["engine"] == "azure-di"

    def test_put_with_21_fields_for_di_returns_422(
        self, doc_client: TestClient
    ) -> None:
        response = doc_client.put(
            "/api/v1/config/document-types/quotation",
            json={"display_name": "見積書", "shareable": True, "fields": _fields(21)},
        )
        assert response.status_code == 422

    def test_replaces_patterns(self, doc_client: TestClient) -> None:
        patterns = [{"key": "QuotationNo", "label": "見積番号", "regex": r"Q-\d{6}"}]
        response = doc_client.put(
            "/api/v1/config/document-types/purchase_order",
            json={
                "display_name": "注文書",
                "shareable": False,
                "fields": VALID_FIELDS,
                "patterns": patterns,
            },
        )
        assert response.status_code == 200
        assert response.json()["patterns"] == patterns

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        payload = {
            "display_name": "x",
            "shareable": False,
            "fields": VALID_PAYLOAD["fields"],
        }
        response = doc_client.put("/api/v1/config/document-types/unknown", json=payload)
        assert response.status_code == 404


class TestDelete:
    def test_deletes_unused_config(self, doc_client: TestClient) -> None:
        response = doc_client.delete("/api/v1/config/document-types/purchase_order")
        assert response.status_code == 204
        assert (
            doc_client.get("/api/v1/config/document-types/purchase_order").status_code
            == 404
        )

    def test_config_in_use_returns_409(
        self, doc_client: TestClient, pdf_bytes: bytes
    ) -> None:
        register = doc_client.post(
            "/api/v1/documents",
            data={"document_id": "cfg-del-1", "document_type": "quotation"},
            files={"file": ("doc.pdf", pdf_bytes, "application/pdf")},
        )
        assert register.status_code == 201
        response = doc_client.delete("/api/v1/config/document-types/quotation")
        assert response.status_code == 409

    def test_unknown_type_returns_404(self, doc_client: TestClient) -> None:
        response = doc_client.delete("/api/v1/config/document-types/unknown")
        assert response.status_code == 404
