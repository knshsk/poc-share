"""Content Understanding アダプタのテスト。

SDK のクライアントはフェイク（_FakeClient）に差し替える。結果の変換は、合成の注文書
（samples/order-project-001.pdf）を CU で解析した実際の生応答（fixtures/cu）で確かめる。
"""

import json
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from azure.core.exceptions import HttpResponseError

from app.core.config import Settings
from app.main import default_analyzers
from app.services.cu import (
    COMPLETION_ALIAS,
    DEFINITION_TAG,
    EMBEDDING_ALIAS,
    ContentUnderstandingAnalyzer,
    analyzer_definition,
    analyzer_id,
    build_analysis_result,
    definition_hash,
    parse_source,
    stale_analyzer_ids,
)
from app.services.document_type_config import FieldDef, FieldType
from app.services.engine import EngineError, EngineName, LeafResult, Region, SchemaOwner
from app.services.idp_extraction import build_fields

FIXTURE = Path(__file__).parent / "fixtures" / "cu" / "order-project-001.result.json"
RAW = FIXTURE.read_bytes()
OWNER = SchemaOwner(tenant_id="default", type_code="order_cu")
SCHEMA = (
    FieldDef(key="BuyerAddress", label="発注元住所", type=FieldType.STRING),
    FieldDef(
        key="GrandTotalAmount",
        label="合計金額",
        type=FieldType.NUMBER,
        description="Overall total amount",
    ),
    FieldDef(
        key="LineItems",
        label="明細",
        type=FieldType.ARRAY,
        properties=(
            FieldDef(key="ProductName", label="品名", type=FieldType.STRING),
            FieldDef(key="Quantity", label="数量", type=FieldType.NUMBER),
            FieldDef(key="UnitPriceAmount", label="単価", type=FieldType.NUMBER),
        ),
    ),
)


class TestAnalyzerId:
    def test_is_short_and_safe_for_any_tenant(self) -> None:
        for tenant in ("default", "テナント/株式会社", "x" * 255):
            target = analyzer_id(SchemaOwner(tenant_id=tenant, type_code="order_cu"))
            assert re.fullmatch(r"factone_[0-9a-f]{32}", target)

    def test_differs_by_tenant_and_type(self) -> None:
        ids = {
            analyzer_id(SchemaOwner("a", "t1")),
            analyzer_id(SchemaOwner("a", "t2")),
            analyzer_id(SchemaOwner("b", "t1")),
        }
        assert len(ids) == 3


class TestAnalyzerDefinition:
    def test_translates_scalar_and_array_fields(self) -> None:
        definition = analyzer_definition(SCHEMA)
        assert definition["baseAnalyzerId"] == "prebuilt-document"
        assert definition["config"] == {
            "returnDetails": False,
            "estimateFieldSourceAndConfidence": True,
        }
        assert definition["processingLocation"] == "geography"
        assert definition["models"] == {
            "completion": COMPLETION_ALIAS,
            "embedding": EMBEDDING_ALIAS,
        }
        fields = definition["fieldSchema"]["fields"]
        assert fields["BuyerAddress"] == {
            "type": "string",
            "method": "extract",
            "description": "発注元住所",
        }
        assert fields["GrandTotalAmount"]["description"] == "Overall total amount"
        assert fields["LineItems"] == {
            "type": "array",
            "method": "generate",
            "description": "明細",
            "items": {
                "type": "object",
                "method": "generate",
                "properties": {
                    "ProductName": {
                        "type": "string",
                        "method": "extract",
                        "description": "品名",
                    },
                    "Quantity": {
                        "type": "number",
                        "method": "extract",
                        "description": "数量",
                    },
                    "UnitPriceAmount": {
                        "type": "number",
                        "method": "extract",
                        "description": "単価",
                    },
                },
            },
        }

    def test_hash_is_stable_and_follows_the_schema(self) -> None:
        definition = analyzer_definition(SCHEMA)
        reordered = json.loads(json.dumps(definition, sort_keys=True))
        assert definition_hash(definition) == definition_hash(reordered)
        changed = analyzer_definition(
            (FieldDef(key="BuyerAddress", label="住所", type=FieldType.STRING),)
        )
        assert definition_hash(changed) != definition_hash(definition)


class TestParseSource:
    def test_quad(self) -> None:
        assert parse_source("D(1,1.0,2.0,3.0,2.1,3.0,4.0,1.0,4.0)") == Region(
            page_number=1, polygon=(1.0, 2.0, 3.0, 2.0, 3.0, 4.0, 1.0, 4.0)
        )

    def test_box(self) -> None:
        assert parse_source("D(2,1.0,2.0,3.0,0.5)") == Region(
            page_number=2, polygon=(1.0, 2.0, 4.0, 2.0, 4.0, 2.5, 1.0, 2.5)
        )

    def test_regions_on_the_first_page_are_merged(self) -> None:
        source = (
            "D(1,4.8942,3.5411,7.6263,3.5335,7.6267,3.6938,4.8946,3.7014);"
            "D(1,4.8946,3.7900,5.6059,3.7956,5.6048,3.9325,4.8936,3.9269);"
            "D(2,0.1,0.1,0.2,0.1,0.2,0.2,0.1,0.2)"
        )
        assert parse_source(source) == Region(
            page_number=1,
            polygon=(4.8936, 3.5335, 7.6267, 3.5335, 7.6267, 3.9325, 4.8936, 3.9325),
        )

    @pytest.mark.parametrize("source", [None, "", "D(1,a,b)", "D(1,1,2,3)", "X"])
    def test_unparseable_source_has_no_region(self, source: str | None) -> None:
        assert parse_source(source) is None


def _body(fields: dict[str, Any]) -> bytes:
    return json.dumps(
        {
            "id": "op-1",
            "status": "Succeeded",
            "result": {
                "apiVersion": "2025-11-01",
                "stringEncoding": "codePoint",
                "contents": [{"markdown": "", "unit": "inch", "fields": fields}],
            },
        }
    ).encode()


class TestBuildAnalysisResult:
    def test_converts_the_sample_response(self) -> None:
        result = build_analysis_result(RAW, "factone_x", "hash-x")

        address = result.fields["BuyerAddress"]
        assert isinstance(address, LeafResult)
        # 2 つの span をつなげた原文。2 行にわたる領域は外接矩形 1 つにまとまる
        assert address.value == "東京都千代田区架空町1-2-3サンプルビル5F"
        assert address.confidence == 0.865
        assert address.region == Region(
            page_number=1,
            polygon=(4.8936, 3.5335, 7.6267, 3.5335, 7.6267, 3.9325, 4.8936, 3.9325),
        )
        total = result.fields["GrandTotalAmount"]
        assert isinstance(total, LeafResult)
        assert total.value == "¥ 74,800 -"

        rows = result.fields["LineItems"]
        assert isinstance(rows, tuple)
        assert len(rows) == 5
        assert rows[0]["Quantity"].value == "10"
        assert rows[0]["Quantity"].confidence == 0.72
        assert rows[0]["UnitPriceAmount"].value == "3,300"

        assert result.content.startswith("# 注文書")
        assert result.layout_tables == ()
        assert result.engine_info == {
            "api_version": "2025-11-01",
            "analyzer_id": "factone_x",
            "definition_hash": "hash-x",
            "model": "gpt-5.4-mini",
        }
        assert result.raw_response == RAW

    def test_flows_into_build_fields(self) -> None:
        built = build_fields(SCHEMA, build_analysis_result(RAW, "a", "h").fields)
        first = built["LineItems"]["items"][0]  # type: ignore[index]
        assert first["Quantity"]["normalized_value"] == 10
        assert first["UnitPriceAmount"]["normalized_value"] == 3300

    def test_typed_value_is_used_without_spans(self) -> None:
        body = _body(
            {"Total": {"type": "number", "valueNumber": 74800, "confidence": 0.9}}
        )
        leaf = build_analysis_result(body, "a", "h").fields["Total"]
        assert isinstance(leaf, LeafResult)
        assert leaf.value == "74800"
        assert leaf.region is None

    def test_array_without_rows_is_empty(self) -> None:
        body = _body({"LineItems": {"type": "array"}})
        assert build_analysis_result(body, "a", "h").fields["LineItems"] == ()

    @pytest.mark.parametrize(
        ("patch", "message"),
        [
            ({"result": {"stringEncoding": "utf16"}}, "stringEncoding"),
            ({"contents": [{"unit": "pixel"}]}, "unit"),
            ({"contents": []}, "contents"),
        ],
    )
    def test_unexpected_response_raises(
        self, patch: dict[str, Any], message: str
    ) -> None:
        body = json.loads(_body({}))
        if "result" in patch:
            body["result"].update(patch["result"])
        if "contents" in patch:
            body["result"]["contents"] = [
                {**body["result"]["contents"][0], **c} for c in patch["contents"]
            ]
        with pytest.raises(EngineError, match=message):
            build_analysis_result(json.dumps(body).encode(), "a", "h")

    @pytest.mark.parametrize(
        "raw",
        [
            b"not json",
            b"",
            b"[]",
            b'{"status": "Succeeded"}',
            _body({"X": "not an object"}),
            _body({"X": {"spans": [{"offset": "a"}]}}),
        ],
        ids=[
            "not_json",
            "empty",
            "not_an_object",
            "no_result",
            "bad_field",
            "bad_span",
        ],
    )
    def test_malformed_response_raises(self, raw: bytes) -> None:
        with pytest.raises(EngineError, match="unexpected"):
            build_analysis_result(raw, "a", "h")


class _Poller:
    def __init__(
        self,
        result: Any = None,
        done: bool = True,
        status: str = "Succeeded",
        operation_id: str | None = "op-1",
        result_error: Exception | None = None,
    ) -> None:
        self._result = result
        self._result_error = result_error
        self._done = done
        self._status = status
        self._operation_id = operation_id

    @property
    def operation_id(self) -> str:
        if self._operation_id is None:
            raise ValueError("Could not extract operation ID")
        return self._operation_id

    def status(self) -> str:
        return self._status

    def wait(self, timeout: float | None = None) -> None:
        pass

    def done(self) -> bool:
        return self._done

    def result(self) -> Any:
        if self._result_error is not None:
            raise self._result_error
        return self._result


class _FakeClient:
    """ContentUnderstandingClient のフェイク。呼出を記録する。"""

    def __init__(self, existing: Any = None) -> None:
        self.existing = existing
        self.created: list[tuple[str, dict[str, Any], bool | None]] = []
        self.calls: list[str] = []
        self.defaults: list[dict[str, str]] = []
        self.defaults_error: Exception | None = None
        self.create_poller = _Poller(SimpleNamespace(status="ready"))
        self.analyze_poller = _Poller(RAW)
        self.analyze_kwargs: dict[str, Any] = {}
        self.deleted: list[str] = []
        self.analyze_error: Exception | None = None
        self.delete_error: Exception | None = None

    def get_analyzer(self, analyzer_id: str) -> Any:
        from azure.core.exceptions import ResourceNotFoundError

        if self.existing is None:
            raise ResourceNotFoundError("not found")
        return self.existing

    def update_defaults(self, *, model_deployments: dict[str, str]) -> None:
        self.calls.append("update_defaults")
        if self.defaults_error is not None:
            raise self.defaults_error
        self.defaults.append(model_deployments)

    def begin_create_analyzer(
        self,
        analyzer_id: str,
        resource: dict[str, Any],
        *,
        allow_replace: bool | None = None,
    ) -> _Poller:
        self.calls.append("begin_create_analyzer")
        self.created.append((analyzer_id, resource, allow_replace))
        return self.create_poller

    def begin_analyze(self, analyzer_id: str, **kwargs: Any) -> _Poller:
        if self.analyze_error is not None:
            raise self.analyze_error
        self.analyze_kwargs = {"analyzer_id": analyzer_id, **kwargs}
        return self.analyze_poller

    def delete_result(self, operation_id: str) -> None:
        if self.delete_error is not None:
            raise self.delete_error
        self.deleted.append(operation_id)


def _analyzer(
    client: _FakeClient, deployments: tuple[str, str] = ("gpt-4o", "emb")
) -> ContentUnderstandingAnalyzer:
    # SDK クライアント生成（認証）を避けるため __init__ を通さずフェイクを差し込む
    analyzer = ContentUnderstandingAnalyzer.__new__(ContentUnderstandingAnalyzer)
    analyzer._client = client  # type: ignore[assignment]
    analyzer._model_deployments = {
        COMPLETION_ALIAS: deployments[0],
        EMBEDDING_ALIAS: deployments[1],
    }
    analyzer._timeout_seconds = 1
    return analyzer


def _ready_with(digest: str) -> SimpleNamespace:
    return SimpleNamespace(status="ready", tags={DEFINITION_TAG: digest})


class TestContentUnderstandingAnalyzer:
    def test_creates_missing_analyzer_and_analyzes(self) -> None:
        client = _FakeClient()

        result = _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

        target, resource, allow_replace = client.created[0]
        digest = definition_hash(analyzer_definition(SCHEMA))
        assert target == analyzer_id(OWNER)
        assert allow_replace is True
        assert resource["tags"] == {DEFINITION_TAG: digest}
        assert resource["description"] == "factone default/order_cu"
        assert resource["fieldSchema"] == analyzer_definition(SCHEMA)["fieldSchema"]
        kwargs = client.analyze_kwargs
        assert kwargs["analyzer_id"] == target
        assert kwargs["model_deployments"] == {
            COMPLETION_ALIAS: "gpt-4o",
            EMBEDDING_ALIAS: "emb",
        }
        assert kwargs["processing_location"] == "geography"
        # cls は最終ポーリングの応答本文を bytes のまま返す
        captured = kwargs["cls"](
            SimpleNamespace(http_response=SimpleNamespace(content=b"x")), None, None
        )
        assert captured == b"x"
        assert kwargs["inputs"][0].data == b"%PDF"
        assert kwargs["inputs"][0].mime_type == "application/pdf"
        assert client.deleted == ["op-1"]
        assert result.engine_info["definition_hash"] == digest
        # CU はリソースの既定が未設定だとアナライザを作れない。作成の前に別名とデプロイの対応を設定する
        assert client.defaults == [{COMPLETION_ALIAS: "gpt-4o", EMBEDDING_ALIAS: "emb"}]
        assert client.calls == ["update_defaults", "begin_create_analyzer"]

    def test_matching_ready_analyzer_is_reused(self) -> None:
        digest = definition_hash(analyzer_definition(SCHEMA))
        client = _FakeClient(existing=_ready_with(digest))

        _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

        assert client.created == []
        assert client.calls == []

    def test_failed_defaults_update_stops_before_creation(self) -> None:
        client = _FakeClient()
        client.defaults_error = HttpResponseError("DefaultsNotSet")
        with pytest.raises(EngineError, match="DefaultsNotSet"):
            _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)
        assert client.created == []

    @pytest.mark.parametrize(
        ("status", "tag"),
        [("ready", "old"), ("ready", None), ("failed", "current")],
        ids=["hash_mismatch", "no_tags", "not_ready"],
    )
    def test_stale_analyzer_is_replaced(self, status: str, tag: str | None) -> None:
        digest = definition_hash(analyzer_definition(SCHEMA))
        tags = (
            None
            if tag is None
            else {DEFINITION_TAG: digest if tag == "current" else tag}
        )
        client = _FakeClient(existing=SimpleNamespace(status=status, tags=tags))

        _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

        assert len(client.created) == 1

    def test_failed_creation_raises(self) -> None:
        client = _FakeClient()
        client.create_poller = _Poller(SimpleNamespace(status="failed"))
        with pytest.raises(EngineError, match="failed"):
            _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

    def test_creation_timeout_raises(self) -> None:
        client = _FakeClient()
        client.create_poller = _Poller(done=False)
        with pytest.raises(EngineError, match="timed out"):
            _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

    def test_analysis_timeout_raises(self) -> None:
        client = _FakeClient()
        client.analyze_poller = _Poller(done=False)
        with pytest.raises(EngineError, match="timed out"):
            _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

    @pytest.mark.parametrize(
        ("result", "status", "result_error", "message"),
        [
            (RAW, "Failed", None, "Failed"),
            (
                b'{"status": "Failed", "error": {"message": "bad model"}}',
                "Failed",
                None,
                "bad model",
            ),
            # 最終ポーリングが失敗すると、手前の Running の本文や None が result() に残る
            (b'{"status": "Running"}', "Running", None, "Running"),
            (None, "Running", None, "Running"),
            (None, "Succeeded", None, "no body"),
            # result() は最後の応答を JSON として読むため、5xx の HTML や非 JSON では例外になる。
            # 状態を先に見るので、原因の状態を残したまま EngineError になる
            (None, "Failed", ValueError("Expecting value"), "Failed"),
            (None, "InProgress", ValueError("Expecting value"), "InProgress"),
            (None, "Failed", HttpResponseError("503"), "Failed"),
            (None, "Succeeded", ValueError("Expecting value"), "unreadable"),
        ],
        ids=[
            "failed",
            "failed_with_error",
            "stale_running_body",
            "no_body",
            "succeeded_without_body",
            "failed_unreadable_body",
            "in_progress_unreadable_body",
            "failed_result_azure_error",
            "succeeded_unreadable_body",
        ],
    )
    def test_unsuccessful_polling_raises(
        self,
        result: bytes | None,
        status: str,
        result_error: Exception | None,
        message: str,
    ) -> None:
        client = _FakeClient()
        client.analyze_poller = _Poller(
            result, status=status, result_error=result_error
        )
        with pytest.raises(EngineError, match=message):
            _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

    def test_azure_error_is_converted(self) -> None:
        client = _FakeClient()
        client.analyze_error = HttpResponseError("boom")
        with pytest.raises(EngineError, match="boom"):
            _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

    def test_delete_failure_does_not_fail_the_run(self) -> None:
        client = _FakeClient()
        client.delete_error = HttpResponseError("gone")

        result = _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

        assert result.raw_response == RAW

    def test_unreadable_operation_id_does_not_fail_the_run(self) -> None:
        client = _FakeClient()
        client.analyze_poller = _Poller(RAW, operation_id=None)

        result = _analyzer(client).analyze(b"%PDF", SCHEMA, OWNER)

        assert result.raw_response == RAW
        assert client.deleted == []

    def test_missing_deployments_raise(self) -> None:
        with pytest.raises(EngineError, match="deployments"):
            _analyzer(_FakeClient(), deployments=("", "")).analyze(
                b"%PDF", SCHEMA, OWNER
            )


def test_stale_analyzer_ids_keeps_only_configured_ones() -> None:
    keep = analyzer_id(OWNER)
    drop = analyzer_id(SchemaOwner("default", "removed"))
    assert stale_analyzer_ids([keep, drop, "prebuilt-invoice", "mine"], [OWNER]) == [
        drop
    ]


def test_default_analyzers_registers_cu_only_with_endpoint() -> None:
    settings = Settings(_env_file=None)  # type: ignore[call-arg]
    assert default_analyzers(settings) == {}
    with_cu = Settings(
        _env_file=None,  # type: ignore[call-arg]
        cu_endpoint="https://example.cognitiveservices.azure.com/",
        cu_completion_deployment="gpt-4o",
        cu_embedding_deployment="text-embedding-3-large",
    )
    assert set(default_analyzers(with_cu)) == {EngineName.AZURE_CU}
