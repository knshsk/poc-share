"""マイグレーションのデータ移行テスト。

次の 4 つを対象にする。
- documents 内部 UUID 主キー化（d7e4b2c9a1f6）: 旧スキーマ（e1c9d4a7b283）に文書・トークン・
  イベント・実行ログを入れてから upgrade し、子テーブルの document_pk が documents.id で
  埋まること、旧 document_id 列が消えることを確認する。
- idp_runs の項目値の集約（b6d2f9a4c8e1）: 並列 5 列と di_* 列が fields / engine / engine_info に
  まとまり、downgrade で元に戻ることを確認する。
- 保存済み corrections のキー改名（e8c3a7d5f1b2）: table_cells が layout_table_cells に書き換わり、
  downgrade で戻ることを確認する。
- シード種別の CU / DI への分割（c4f8a2e6d9b1）: DI の purchase_order / quotation が _di に改名され、
  文書も追従し、CU の purchase_order / quotation が入ること、downgrade で戻ることを確認する。
"""

import json
import uuid
from typing import Any

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import Connection, Engine, create_engine, text

from app.routers.document_type_configs import DocumentTypeConfigBody
from tests.conftest import DEFAULT_CONFIGS, _seed_default_configs, alembic_config

PREVIOUS = "e1c9d4a7b283"
TARGET = "d7e4b2c9a1f6"
CHILD_TABLES = ("view_tokens", "view_events", "idp_runs")


def test_upgrade_fills_document_pk_from_legacy_rows(test_database_url: str) -> None:
    """旧スキーマの行が新外部キーへ移行されることを確認する（downgrade → 投入 → upgrade）。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.downgrade(config, PREVIOUS)

    token_id, event_id, run_id = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    with engine.begin() as conn:
        conn.execute(
            text(
                "INSERT INTO documents (document_id, tenant_id, document_type, blob_ref, "
                "content_sha256, received_at) VALUES ('mig-doc', 'default', 'quotation', "
                "'default/mig-doc.pdf', 'sha', now())"
            )
        )
        conn.execute(
            text(
                "INSERT INTO view_tokens (id, token_hash, document_id, expires_at, revoked) "
                "VALUES (:id, 'hash-mig', 'mig-doc', now() + interval '1 day', false)"
            ),
            {"id": token_id},
        )
        conn.execute(
            text(
                "INSERT INTO view_events (id, document_id, view_token_id, event_type, "
                "occurred_at, client_ip, user_agent) "
                "VALUES (:id, 'mig-doc', :token_id, 'view', now(), '127.0.0.1', 'ua')"
            ),
            {"id": event_id, "token_id": token_id},
        )
        conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_id, run_type, status, executed_at) "
                "VALUES (:id, 'mig-doc', 'initial', 'failed', now())"
            ),
            {"id": run_id},
        )

    command.upgrade(config, TARGET)

    with engine.connect() as conn:
        document_pk = conn.execute(
            text(
                "SELECT id FROM documents "
                "WHERE tenant_id = 'default' AND document_id = 'mig-doc'"
            )
        ).scalar_one()
        for table in CHILD_TABLES:
            assert (
                conn.execute(text(f"SELECT document_pk FROM {table}")).scalar_one()
                == document_pk
            )
        legacy_columns = conn.execute(
            text(
                "SELECT count(*) FROM information_schema.columns "
                "WHERE table_name IN ('view_tokens', 'view_events', 'idp_runs') "
                "AND column_name = 'document_id'"
            )
        ).scalar_one()
        assert legacy_columns == 0
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    engine.dispose()


def test_downgrade_and_upgrade_round_trip(test_database_url: str) -> None:
    """空データで downgrade / upgrade を往復できることを確認する。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    engine.dispose()

    command.downgrade(config, PREVIOUS)
    command.upgrade(config, "head")


FOLD_PREVIOUS = "a1e5c8f2d7b4"
FOLD_TARGET = "b6d2f9a4c8e1"
RAW = {"TotalAmount": "1,200,000", "QuotationId": None}
NORMALIZED = {"TotalAmount": 1200000, "QuotationId": None}
CONFIDENCE = {"TotalAmount": 0.96, "QuotationId": None}
LABELS = {"TotalAmount": "合計金額", "QuotationId": "見積書ID"}
REGIONS = {
    "TotalAmount": {"page_number": 1, "polygon": [1.0, 2.0, 3.0, 2.0]},
    "QuotationId": None,
}


def test_idp_runs_columns_are_folded_into_fields(test_database_url: str) -> None:
    """並列 5 列と di_* 列が fields / engine / engine_info にまとまり、downgrade で元に戻ることを確認する。

    ラベル列を持たない旧い成功行（field_labels が NULL）は、label が null の葉になる。
    """
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.downgrade(config, FOLD_PREVIOUS)

    document_pk = uuid.uuid4()
    succeeded_id, unlabeled_id, failed_id = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    insert_run = text(
        "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at, "
        "raw_fields, normalized_fields, confidence, field_labels, field_regions, "
        "tables, di_api_version, di_model_id) VALUES (:id, :doc, :run_type, "
        "'succeeded', now(), CAST(:raw AS jsonb), CAST(:normalized AS jsonb), "
        "CAST(:confidence AS jsonb), CAST(:labels AS jsonb), CAST(:regions AS jsonb), "
        "'[]'::jsonb, '2024-11-30', 'prebuilt-layout')"
    )
    with engine.begin() as conn:
        conn.execute(
            text(
                "INSERT INTO documents (id, document_id, tenant_id, document_type, "
                "blob_ref, content_sha256, received_at) VALUES (:id, 'mig-doc', "
                "'default', 'quotation', 'default/mig.pdf', 'sha', now())"
            ),
            {"id": document_pk},
        )
        conn.execute(
            insert_run,
            {
                "id": succeeded_id,
                "doc": document_pk,
                "run_type": "initial",
                "raw": json.dumps(RAW),
                "normalized": json.dumps(NORMALIZED),
                "confidence": json.dumps(CONFIDENCE),
                "labels": json.dumps(LABELS),
                "regions": json.dumps(REGIONS),
            },
        )
        conn.execute(
            insert_run,
            {
                "id": unlabeled_id,
                "doc": document_pk,
                "run_type": "rerun",
                "raw": json.dumps(RAW),
                "normalized": json.dumps(NORMALIZED),
                "confidence": json.dumps(CONFIDENCE),
                "labels": None,
                "regions": None,
            },
        )
        conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at, "
                "error_info) VALUES (:id, :doc, 'rerun', 'failed', now(), 'boom')"
            ),
            {"id": failed_id, "doc": document_pk},
        )

    command.upgrade(config, FOLD_TARGET)

    with engine.connect() as conn:
        rows = {
            row.id: row
            for row in conn.execute(
                text(
                    "SELECT id, engine, engine_info, fields, layout_tables FROM idp_runs"
                )
            )
        }
    succeeded = rows[succeeded_id]
    assert succeeded.engine == "azure-di"
    assert succeeded.engine_info == {
        "api_version": "2024-11-30",
        "model_id": "prebuilt-layout",
    }
    assert succeeded.fields == {
        "TotalAmount": {
            "label": "合計金額",
            "value": "1,200,000",
            "normalized_value": 1200000,
            "confidence": 0.96,
            "region": {"page_number": 1, "polygon": [1.0, 2.0, 3.0, 2.0]},
        },
        "QuotationId": {
            "label": "見積書ID",
            "value": None,
            "normalized_value": None,
            "confidence": None,
            "region": None,
        },
    }
    assert succeeded.layout_tables == []
    assert rows[unlabeled_id].fields["TotalAmount"]["label"] is None
    assert rows[unlabeled_id].fields["TotalAmount"]["region"] is None
    failed = rows[failed_id]
    assert failed.engine == "azure-di"
    assert failed.engine_info is None
    assert failed.fields is None

    command.downgrade(config, FOLD_PREVIOUS)

    with engine.connect() as conn:
        restored = conn.execute(
            text(
                "SELECT raw_fields, normalized_fields, confidence, field_labels, "
                "field_regions, di_api_version, di_model_id, tables FROM idp_runs "
                "WHERE id = :id"
            ),
            {"id": succeeded_id},
        ).one()
    assert restored.raw_fields == RAW
    assert restored.normalized_fields == NORMALIZED
    assert restored.confidence == CONFIDENCE
    assert restored.field_labels == LABELS
    assert restored.field_regions == REGIONS
    assert restored.di_api_version == "2024-11-30"
    assert restored.di_model_id == "prebuilt-layout"
    assert restored.tables == []

    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.upgrade(config, "head")
    engine.dispose()


RENAME_PREVIOUS = "b6d2f9a4c8e1"
RENAME_TARGET = "e8c3a7d5f1b2"


def test_corrections_table_cells_key_is_renamed(test_database_url: str) -> None:
    """保存済みの corrections.table_cells が layout_table_cells に書き換わり、downgrade で戻ることを確認する。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.downgrade(config, RENAME_PREVIOUS)

    document_pk, base_id, corrected_id = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    cells = [{"table_index": 0, "row_index": 1, "column_index": 0, "content": "A"}]
    with engine.begin() as conn:
        conn.execute(
            text(
                "INSERT INTO documents (id, document_id, tenant_id, document_type, "
                "blob_ref, content_sha256, received_at) VALUES (:id, 'mig-doc', "
                "'default', 'quotation', 'default/mig.pdf', 'sha', now())"
            ),
            {"id": document_pk},
        )
        conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at, "
                "engine) VALUES (:id, :doc, 'initial', 'succeeded', now(), 'azure-di')"
            ),
            {"id": base_id, "doc": document_pk},
        )
        conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at, "
                "engine, base_run_id, corrected_by, corrections) VALUES (:id, :doc, "
                "'corrected', 'succeeded', now(), 'azure-di', :base, 'u', "
                "CAST(:corrections AS jsonb))"
            ),
            {
                "id": corrected_id,
                "doc": document_pk,
                "base": base_id,
                "corrections": json.dumps({"fields": {"X": "1"}, "table_cells": cells}),
            },
        )

    command.upgrade(config, RENAME_TARGET)
    with engine.connect() as conn:
        upgraded = conn.execute(
            text("SELECT corrections FROM idp_runs WHERE id = :id"),
            {"id": corrected_id},
        ).scalar_one()
    assert upgraded == {"fields": {"X": "1"}, "layout_table_cells": cells}

    command.downgrade(config, RENAME_PREVIOUS)
    with engine.connect() as conn:
        restored = conn.execute(
            text("SELECT corrections FROM idp_runs WHERE id = :id"),
            {"id": corrected_id},
        ).scalar_one()
    assert restored == {"fields": {"X": "1"}, "table_cells": cells}

    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.upgrade(config, "head")
    engine.dispose()


def test_fold_downgrade_refuses_rows_with_items(test_database_url: str) -> None:
    """array 型の値（items）を持つ行があると、b6d2f9a4c8e1 の downgrade は止まり、DB は head のまま残る。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    document_pk = uuid.uuid4()
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
        conn.execute(
            text(
                "INSERT INTO documents (id, document_id, tenant_id, document_type, "
                "blob_ref, content_sha256, received_at) VALUES (:id, 'mig-doc', "
                "'default', 'order_cu', 'default/mig.pdf', 'sha', now())"
            ),
            {"id": document_pk},
        )
        conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at, "
                "engine, fields) VALUES (gen_random_uuid(), :doc, 'initial', 'succeeded', "
                "now(), 'azure-cu', CAST(:fields AS jsonb))"
            ),
            {
                "doc": document_pk,
                "fields": json.dumps(
                    {"LineItems": {"label": "明細", "property_labels": {}, "items": []}}
                ),
            },
        )

    with pytest.raises(RuntimeError, match="items"):
        command.downgrade(config, FOLD_PREVIOUS)

    with engine.connect() as conn:
        assert conn.execute(text("SELECT count(*) FROM idp_runs")).scalar_one() == 1
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.upgrade(config, "head")
    engine.dispose()


SEED_PREVIOUS = "e8c3a7d5f1b2"
SEED_TARGET = "c4f8a2e6d9b1"
# 見積書の 2 種別に足す版数（DI の種別には説明を付けない）
REVISION = {"key": "RevisionNumber", "label": "版数", "type": "string"}


def _configs(conn: Connection, tenant_id: str) -> dict[str, dict[str, Any]]:
    rows = conn.execute(
        text(
            "SELECT type_code, display_name, shareable, engine, fields, patterns "
            "FROM document_type_configs WHERE tenant_id = :t"
        ),
        {"t": tenant_id},
    ).mappings()
    return {r["type_code"]: dict(r) for r in rows}


def _document_types(conn: Connection) -> dict[str, str]:
    rows = conn.execute(text("SELECT document_id, document_type FROM documents"))
    return {document_id: document_type for document_id, document_type in rows}


def _prepare_seed_previous(config: Config, engine: Engine) -> None:
    """SEED_PREVIOUS に下げ、DI のシード種別（conftest と同じ）と文書を入れる。"""
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.downgrade(config, SEED_PREVIOUS)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE document_type_configs"))
        _seed_default_configs(conn)
        _seed_default_configs(conn, "other")
        for document_id, tenant_id, document_type in (
            ("po-1", "default", "purchase_order"),
            ("q-1", "default", "quotation"),
            ("po-other", "other", "purchase_order"),
        ):
            conn.execute(
                text(
                    "INSERT INTO documents (id, document_id, tenant_id, document_type, "
                    "blob_ref, content_sha256, received_at) VALUES (gen_random_uuid(), "
                    ":d, :t, :type, 'x.pdf', 'sha', now())"
                ),
                {"d": document_id, "t": tenant_id, "type": document_type},
            )


def test_seed_document_types_are_split_into_cu_and_di(test_database_url: str) -> None:
    """default の DI 種別が _di に改名されて文書も追従し、CU の種別が入る。downgrade で戻る。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    _prepare_seed_previous(config, engine)

    command.upgrade(config, SEED_TARGET)
    with engine.connect() as conn:
        configs = _configs(conn, "default")
        other = _configs(conn, "other")
        documents = _document_types(conn)
    assert {code: c["engine"] for code, c in configs.items()} == {
        "purchase_order": "azure-cu",
        "quotation": "azure-cu",
        "purchase_order_di": "azure-di",
        "quotation_di": "azure-di",
    }
    assert configs["purchase_order_di"]["display_name"] == "注文書（DI）"
    assert configs["quotation_di"]["display_name"] == "見積書（DI）"
    for code, name, shareable, seed_fields in DEFAULT_CONFIGS:
        di, cu = configs[f"{code}_di"], configs[code]
        di_fields = [*seed_fields, REVISION] if code == "quotation" else seed_fields
        assert di["fields"] == di_fields
        assert (cu["display_name"], cu["shareable"]) == (name, shareable)
        # パターンは DI のシード（a9c3e5d7b1f2）と同じ登録番号。conftest の DI 種別はパターンを持たない
        assert cu["patterns"] == [
            {"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}
        ]
        # ヘッダ項目は DI と同じキー・ラベル・型・表示有無で、明細は LineItems の 1 項目だけ足す
        header = [
            {k: v for k, v in f.items() if k != "description"}
            for f in cu["fields"][:-1]
        ]
        assert header == di_fields
        line_items = cu["fields"][-1]
        assert (line_items["key"], line_items["type"]) == ("LineItems", "array")
        assert [p["key"] for p in line_items["properties"]] == [
            "ItemCode",
            "ItemName",
            "Quantity",
            "UnitName",
            "UnitPrice",
            "LineAmount",
        ]
        descriptions = [f["description"] for f in cu["fields"]] + [
            p["description"] for p in line_items["properties"]
        ]
        assert all(d and d.isascii() for d in descriptions)
        # 設定 API が受け付ける形であること（azure-cu の検査を含む）
        DocumentTypeConfigBody.model_validate(cu)
    assert {code: c["engine"] for code, c in other.items()} == {
        "purchase_order": "azure-di",
        "quotation": "azure-di",
    }
    assert documents == {
        "po-1": "purchase_order_di",
        "q-1": "quotation_di",
        "po-other": "purchase_order",
    }

    command.downgrade(config, SEED_PREVIOUS)
    with engine.connect() as conn:
        restored = _configs(conn, "default")
        documents = _document_types(conn)
    assert {code: (c["display_name"], c["engine"]) for code, c in restored.items()} == {
        "purchase_order": ("注文書", "azure-di"),
        "quotation": ("見積書", "azure-di"),
    }
    assert {code: c["fields"] for code, c in restored.items()} == {
        code: fields for code, _, _, fields in DEFAULT_CONFIGS
    }
    assert documents == {
        "po-1": "purchase_order",
        "q-1": "quotation",
        "po-other": "purchase_order",
    }

    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.upgrade(config, "head")
    engine.dispose()


def test_seed_downgrade_refuses_documents_of_cu_types(test_database_url: str) -> None:
    """CU のシード種別を参照する文書があると、c4f8a2e6d9b1 の downgrade は止まる。"""
    config = alembic_config(test_database_url)
    engine = create_engine(test_database_url)
    _prepare_seed_previous(config, engine)
    command.upgrade(config, SEED_TARGET)
    with engine.begin() as conn:
        conn.execute(
            text(
                "INSERT INTO documents (id, document_id, tenant_id, document_type, "
                "blob_ref, content_sha256, received_at) VALUES (gen_random_uuid(), "
                "'po-cu', 'default', 'purchase_order', 'x.pdf', 'sha', now())"
            )
        )

    with pytest.raises(RuntimeError, match="azure-cu"):
        command.downgrade(config, SEED_PREVIOUS)

    with engine.connect() as conn:
        assert _configs(conn, "default")["purchase_order"]["engine"] == "azure-cu"
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
    command.upgrade(config, "head")
    engine.dispose()
