# Azure構成

IDP/ViewerをAzure上で動かすためのリソース構成と、各サービスの設計判断。インフラ定義の正は`bicep/`のBicepモジュールであり、本書は構成の解説と判断の根拠を記す。デプロイ手順は[develop-guide/deploy.md](../develop-guide/deploy.md)を参照。

## 役割

PoC用の単一環境。リソースグループ1つとリージョン1つ（既定`japaneast`）を使い、各アプリはレプリカ1固定で動かす。

バックエンドサービスはネットワーク分離をせず、パブリックエンドポイントを認証・匿名アクセス無効・TLS強制で守る（[ADR-0007](../adr/0007-no-network-isolation-for-poc.md)）。認証はStorage・DI・Content Understanding・ACRがManaged ID、PostgreSQLがパスワードである。ファイアウォール規則を持つのはPostgreSQLのみ。Viewerの静的ファイルはAPIコンテナが同梱して配信し、フロント専用のホスティングは持たない（[ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)）。

## トポロジ

```mermaid
flowchart TB
    subgraph rg["リソースグループ（既定 factone-poc-rg）"]
        subgraph cae["Container Apps Environment（CAE: factone-poc-cae）"]
            api["Container App: api<br/>FastAPI + Viewer 静的ファイル<br/>port 8000 / external ingress"]
            kc["Container App: keycloak<br/>realm 焼き込みイメージ<br/>port 8080 / external ingress"]
        end
        log["Log Analytics"]
        pg[("PostgreSQL Flexible Server<br/>DB: factone / keycloak")]
        st[("Storage Account<br/>コンテナ: documents")]
        di["Document Intelligence"]
        cu["Content Understanding<br/>gpt-4o / text-embedding-3-large"]
        kv["Key Vault<br/>postgres-admin-password"]
        acr["Container Registry<br/>factone-api / factone-keycloak"]
        idApi["Managed ID: api"]
        idKc["Managed ID: keycloak"]
    end
    user(["テナント利用者 / 閲覧者 / 外部連携システム"])

    user -- HTTPS --> api
    user -- HTTPS（OIDC） --> kc
    api -- JWKS 取得（HTTPS） --> kc
    api -- SSL / パスワード --> pg
    kc -- SSL / パスワード --> pg
    api -- Managed ID --> st
    api -- Managed ID --> di
    api -- Managed ID --> cu
    acr -. イメージ pull（Managed ID）.-> api
    acr -. イメージ pull（Managed ID）.-> kc
    cae --> log
    idApi -.-> api
    idKc -.-> kc
```

デプロイはコアインフラとアプリ層の2段階。`main.bicep`は、`apiImage` / `keycloakImage`が空のときアプリ層（Container App 2つ）を作らない。APIのOIDC issuerはKeycloakモジュールの出力から組むため、アプリ層は両イメージを同時に指定する。初回は次の順に実行する。

1. `scripts/deploy-infra.sh`でコアのみをデプロイする。`FACTONE_POSTGRES_ADMIN_PASSWORD`が必須。
2. `scripts/build-images.sh`でACRのクラウドビルドを行う。
3. `scripts/deploy-apps.sh`でアプリ層をデプロイする。`FACTONE_POSTGRES_ADMIN_PASSWORD`と`FACTONE_KEYCLOAK_ADMIN_PASSWORD`が必須。

リソース名は環境名（既定`poc`）を含む。グローバルに一意な名前が要るStorage・PostgreSQL・Key Vault・Document Intelligence・Content Understanding・ACRの名前は、リソースグループIDに由来する一意のサフィックスも含む。形式（ハイフンの有無・サフィックス長）は、リソース種別の命名制約に合わせて異なる。同名のリソースグループへ再デプロイすると、名前が再現する。

Keycloakの公開ホスト名は`factone-<環境名>-keycloak.<Environment の既定ドメイン>`で決定的に決まり、APIのOIDC issuerに使う。`build-images.sh`は`bicep/main.bicepparam`の`environmentName`から同じ規則でホスト名を組み、Viewerのビルド引数`VITE_OIDC_AUTHORITY`に渡す。`VITE_OIDC_CLIENT_ID`は渡さず、Viewerの既定値`factone-viewer`を使う。この値はrealmのクライアントIDと同じである。

両Container Appのリビジョンはデプロイ時刻をサフィックスにして毎回更新し、同名タグでもイメージを再pullさせる。

## サービス別の設計

Bicepモジュール1つにつき1小節。各小節は「目的 / 主要設定 / IDと権限 / PoC上の簡略化」の順。

### Storage（`modules/storage.bicep`）

PDF原本と抽出エンジンの生応答の保存先。コンテナ`documents`に、`{tenant_id}/{id}.pdf`と`{tenant_id}/{document_id}/idp-runs/{run_id}.json`のパスで置く。`id`は`documents`の内部IDである。ページ画像は保存せず、APIがオンデマンドで生成する。

主要設定はStorageV2、Standard_LRS、`allowBlobPublicAccess: false`。TLS 1.2以上・HTTPSのみとし、コンテナの公開アクセスはNoneにする。

APIのManaged IDにStorage Blob Data Contributorを割り当てる。アプリは`DefaultAzureCredential`で接続する（`api/app/services/blob.py`）。

PoC上の簡略化として、冗長化はLRSとし、ネットワーク制限・ライフサイクル管理・論理削除は設けない。

### PostgreSQL Flexible Server（`modules/postgresql.bicep`）

アプリ用DB`factone`とKeycloak用DB`keycloak`を同一サーバに置く。

主要設定はPostgreSQL 17、Standard_B1ms（Burstable）、ストレージ32 GB。バックアップ保持は7日で、geo冗長バックアップは無効。ファイアウォール規則は「Azureサービス許可（0.0.0.0）」の1件。

Managed IDは使わず、管理者ユーザーのパスワードで認証する。APIは`FACTONE_DATABASE_URL`（Container Appのシークレット）で、Keycloakは`KC_DB_URL` / `KC_DB_USERNAME` / `KC_DB_PASSWORD`で接続する。いずれも接続文字列で`sslmode=require`を指定する。サーバ側のSSL強制設定はBicepに置かず、既定値に依存する。

PoC上の簡略化として、API・Keycloakとも管理者ユーザーで接続する。本番化時は専用DBユーザーへ分離する。Container Apps（Consumption）のアウトバウンドIPが固定でないため、ファイアウォール規則が広い。スキーマはAPIコンテナの起動時に`alembic upgrade head`で適用する。

### Key Vault（`modules/keyvault.bicep`）

PostgreSQL管理者パスワードを、シークレット`postgres-admin-password`として保管する。参照するのは運用者で、デプロイ後にパスワードを確認する用途に使う。アプリやデプロイスクリプトは読まない。

主要設定はstandard SKU、RBAC認可（アクセスポリシー不使用）、パブリックアクセス有効。

APIのManaged IDにKey Vault Secrets Userを割り当てる。

PoC上の簡略化として、アプリは現状Key Vaultを読まない。DB接続文字列は、BicepがContainer Appのシークレットに直接渡す。ロール付与は将来の参照に備えたもの。パージ保護はなく、削除後90日は名前が予約される（[develop-guide/deploy.md](../develop-guide/deploy.md)の再デプロイ時の注意）。

### Document Intelligence（`modules/document-intelligence.bicep`）

PDFの文字化・項目抽出を行う抽出エンジン。

主要設定はkind FormRecognizer、S0、カスタムサブドメイン、パブリックアクセス有効。カスタムサブドメインはManaged ID認証に必須。

APIのManaged IDにCognitive Services Userを割り当てる。`FACTONE_DI_API_KEY`は設定せず、`DefaultAzureCredential`で認証する（`api/app/services/di.py`）。

PoC上の簡略化として、ネットワーク制限は設けない。使用モデルは`prebuilt-layout`にQuery Fieldsアドオンを付けたもののみで、アドオン分の課金が加わる。

### Content Understanding（`modules/content-understanding.bicep`）

`azure-cu`の抽出エンジン。Azure AI Content Understanding（CU）を、Foundryリソースの機能として呼ぶ。アナライザはBicepでは作らない。APIがIDP実行の際に、テナント×文書種別ごとに作成し、定義がずれていれば置き換える（[ADR-0030](../adr/0030-cu-analyzer-per-tenant-type.md)）。

主要設定はkind AIServices、S0、カスタムサブドメイン、パブリックアクセス有効、`disableLocalAuth: true`（キー認証の無効化）。リソースの中に、CUが使うモデルのデプロイを2つ置く。

| デプロイ名 | モデル・版 | 種類・容量 | 版の自動更新 |
| --- | --- | --- | --- |
| `gpt-4o`（チャット補完） | gpt-4o `2024-11-20` | Standard、30（千TPM） | `versionUpgradeOption: OnceCurrentVersionExpired` |
| `text-embedding-3-large`（埋め込み） | text-embedding-3-large `1` | Standard、30（千TPM） | 指定なし（Azureの既定に従う） |

モデル・版・容量は、このシステムが選んだ値であり、モジュールに直接書いている。同じアカウントのデプロイは並行して作れないため（Azureの制約）、埋め込みは補完の後に作る。

`OnceCurrentVersionExpired`は、今の版が退役した時点で後継の版へ更新する指定である。Azureの既定（`OnceNewDefaultVersionAvailable`）では、新しい既定の版が決まった時点で、退役前でも更新されうる。Azureのモデル退役スケジュールでは、gpt-4o `2024-11-20`は2027-04-14に退役し、gpt-5.1へ自動で更新される。後継はAzureの判断で変わりうる。埋め込みのデプロイは`versionUpgradeOption`を指定していないため、Azureの既定に従い、新しい既定の版が決まると自動で更新されうる。どちらの更新でも、アナライザはモデルを別名で参照するため、アナライザの定義は変わらない。

APIのManaged IDにCognitive Services Userを割り当てる。キー認証は無効なので、APIは`DefaultAzureCredential`で認証する（`api/app/services/cu.py`）。ローカルの開発では`az login`の資格情報で呼ぶ（[develop-guide/api.md](../develop-guide/api.md)）。API Container Appには、`FACTONE_CU_ENDPOINT`（アカウントのエンドポイント）、`FACTONE_CU_COMPLETION_DEPLOYMENT`と`FACTONE_CU_EMBEDDING_DEPLOYMENT`（2つのデプロイ名）を渡す。

CUのリソースの既定（defaults）には、モデルの別名（`prebuilt-analyzer-completion` / `prebuilt-analyzer-embedding`）とデプロイの対応を置く。CUは、既定が未設定だとアナライザの作成を拒否する（`DefaultsNotSet`）。APIは、アナライザを作成・置き換える直前に、`FACTONE_CU_COMPLETION_DEPLOYMENT` / `FACTONE_CU_EMBEDDING_DEPLOYMENT`の値で既定を設定する。そのため、既定を手作業で設定する手順（`PATCH /contentunderstanding/defaults`）は要らない。既定はリソース全体で1つなので、デプロイ名が異なる環境の間でCUリソースを共有しない。

アナライザの作成は、デプロイが存在していても`DeploymentIdNotFound`（`Validation of existing deployment failed: the OpenAI deployment <デプロイ名> does not exist`）で失敗することがある。原因は分かっていない。失敗した実行の`error_info`には、このエラーが残る。このエラーで失敗したときは、IDP実行をやり直す。やり直して成功した例がある（[ADR-0030](../adr/0030-cu-analyzer-per-tenant-type.md)）。

データの所在として、リソースとデプロイはリソースグループのリージョン（既定`japaneast`）に置き、デプロイの種類はリージョン内で処理するStandardとする。アナライザの定義と解析のリクエストの両方で、`processingLocation: geography`を指定する。ただし、自前のアナライザの抽出の段階にこの指定が効くかは、資料で確認できていない。

Standardのデプロイは使用量に応じた課金で、呼び出していない間は課金されない（Azureの料金体系）。

PoC上の簡略化として、ネットワーク制限は設けない。

#### アナライザの掃除

文書種別設定を削除したときや、`engine`を`azure-di`へ変えたときも、CUのアナライザは残る。テナントの設定をまとめて消したときも同じである。残ったアナライザは、APIのコンテナで運用スクリプト`scripts/cleanup_cu_analyzers.py`を実行して消す。スクリプトは、APIと同じ環境変数（`FACTONE_DATABASE_URL` / `FACTONE_CU_ENDPOINT`）で接続先を決める。

1. APIのコンテナへ接続する。

```bash
az containerapp exec --name factone-poc-api --resource-group factone-poc-rg --command bash
```

2. コンテナ内で、`--apply`を付けずにスクリプトを実行する。この実行では削除せず、接続先（CUのエンドポイント、DBのホストとデータベース名）、`azure-cu`の文書種別設定の件数、削除の候補を表示する。候補は、IDが`factone_`で始まり、DBの`azure-cu`の文書種別設定のどれにも対応しないアナライザである。

```bash
uv run python scripts/cleanup_cu_analyzers.py
```

3. 表示を確かめた後、`--apply`を付けて実行し、候補を削除する。

```bash
uv run python scripts/cleanup_cu_analyzers.py --apply
```

`azure-cu`の文書種別設定が0件のときは、接続先のDBを取り違えたおそれがあるため、警告を出す。この場合は`--apply`を付けても削除せず、終了コード1で終わる。

### Container Registry（`modules/acr.bicep`）

`factone-api`と`factone-keycloak`のイメージを保管する。ビルドは`az acr build`によるクラウドビルドで、ローカルにコンテナ基盤を要しない。

主要設定はBasic SKU、管理者ユーザー無効。

APIとKeycloakのManaged IDそれぞれにAcrPullを割り当てる。

PoC上の簡略化として、イメージの脆弱性スキャン・保持ポリシーは設けない。

### Container Apps Environment（`modules/container-apps-env.bicep`）

`api`と`keycloak`の実行基盤。コンテナログをLog Analyticsへ送る。

主要設定はConsumption。Log AnalyticsはPerGB2018で、保持は30日。

EnvironmentからLog Analyticsへの接続は共有キー方式で、Bicepが`listKeys()`で取得して渡す。

PoC上の簡略化として、VNet統合はしない（[ADR-0007](../adr/0007-no-network-isolation-for-poc.md)）。ログ保持は最短。

### Managed Identity（`modules/identities.bicep`）

API用とKeycloak用のユーザー割当Managed ID。

主要設定として、ユーザー割当IDを2つ持つ。APIのIDはクライアントIDを`AZURE_CLIENT_ID`としてコンテナに渡し、`DefaultAzureCredential`に選ばせる。

権限の付与は`app-roles.bicep`で行う。

PoC上の簡略化として、システム割当ではなくユーザー割当を使う。理由は、ACR pullにアプリ作成前のロール付与が必要なためである。システム割当はアプリ作成時に生成されるので、この順序が成立しない。

### ロール付与（`modules/app-roles.bicep`）

Managed IDへの組み込みロール割当をまとめる。主要設定として、次のロールを割り当てる。

| 割当先のID | ロール | 対象 |
| --- | --- | --- |
| API | Storage Blob Data Contributor | Storage |
| API | Cognitive Services User | DI |
| API | Cognitive Services User | Content Understanding |
| API | Key Vault Secrets User | Key Vault |
| API | AcrPull | ACR |
| Keycloak | AcrPull | ACR |

すべてリソーススコープの割当。

PoC上の簡略化として、最小権限の見直しは対象外とする。Blobは読み書きにContributorが必要である。

### Keycloak Container App（`modules/keycloak-app.bicep`）

IdP。realm定義を焼き込んだイメージを動かす。イメージの定義は`keycloak/Containerfile`で、realmは`--import-realm`で起動時に投入する。

主要設定はexternal ingress、port 8080、CPU 0.5 / メモリ1 Gi、レプリカ1、プローブなし。`KC_HOSTNAME`に`https://<公開 FQDN>`を設定し、`KC_PROXY_HEADERS=xforwarded`と`KC_HTTP_ENABLED=true`でingressのTLS終端配下で動かす。管理者はブートストラップ環境変数で作り、ユーザー名の既定は`admin`。

KeycloakのManaged IDを使い、権限はACR pullのみ。DBはパスワードで認証する。

PoC上の簡略化として、管理者パスワードとDBパスワードはContainer Appのシークレットに置く。realm内のクライアントシークレットとテストユーザーのパスワードは、デプロイ後に`kcadm`で手動投入する（[develop-guide/deploy.md](../develop-guide/deploy.md)）。テナントの追加・無効化もrealm定義には含めない。代わりに`scripts/tenant.sh`を`KC_SERVER`でAzureのKeycloakに向けて実行する（[develop-guide/tenant.md](../develop-guide/tenant.md)）。

### API Container App（`modules/api-app.bicep`）

FastAPI本体とViewer静的ファイルの配信。

応答のgzip圧縮はアプリ（`GZipMiddleware`）で行い、ingressの設定には依存しない（[architecture/api.md](../architecture/api.md)）。

主要設定はexternal ingress、port 8000、CPU 0.5 / メモリ1 Gi、レプリカ1固定、Readiness probe `/health`。Bicepが環境変数として渡すのは、表で値の出どころが「Bicep」の設定である。それ以外の設定はBicepが渡さず、`api/app/core/config.py`の既定値で動く。表の「既定値」の行は、その一部を挙げたもの。

| 設定 | 値の出どころ |
| --- | --- |
| `FACTONE_DATABASE_URL` | Bicep（シークレット） |
| `FACTONE_OIDC_ISSUER` | Bicep |
| `FACTONE_BLOB_BACKEND=azure` | Bicep |
| `FACTONE_BLOB_ACCOUNT_URL` | Bicep |
| `FACTONE_DI_ENDPOINT` | Bicep |
| `FACTONE_CU_ENDPOINT` | Bicep |
| `FACTONE_CU_COMPLETION_DEPLOYMENT` / `FACTONE_CU_EMBEDDING_DEPLOYMENT` | Bicep |
| `AZURE_CLIENT_ID` | Bicep |
| `FACTONE_OIDC_AUDIENCE=factone-api` | 既定値 |
| `FACTONE_BLOB_CONTAINER=documents` | 既定値 |
| `FACTONE_DI_TIMEOUT_SECONDS=120` | 既定値 |
| `FACTONE_CU_TIMEOUT_SECONDS=120` | 既定値 |
| `FACTONE_VIEW_URL_*` | 既定値 |

起動時に`alembic upgrade head`を実行してから、uvicornを起動する。

APIのManaged IDを使い、権限の対象はStorage / DI / Content Understanding / Key Vault / ACR。

PoC上の簡略化として、レプリカを1に固定する。閲覧URLの失敗レート制限がインメモリで、起動時マイグレーションも単一プロセス前提のためである。スケールアウトするときは、レート制限の外部化とマイグレーションの分離が必要。

## 通信・認証経路

| 経路 | 内容 |
| --- | --- |
| API → Storage / Document Intelligence / Content Understanding | Managed ID（`DefaultAzureCredential`。`AZURE_CLIENT_ID`でユーザー割当IDを選択） |
| API → Key Vault | ロールは付与済みだが、現状は読まない |
| API → PostgreSQL | パスワード認証。接続文字列はContainer Appのシークレット。`sslmode=require` |
| API → Keycloak | JWT検証用のJWKS取得（HTTPS、公開エンドポイント） |
| Keycloak → PostgreSQL | パスワード認証。`sslmode=require` |
| Container Apps → ACR | Managed IDのAcrPull |
| 外部 → api / keycloak | Container Appsのexternal ingress（TLS終端）。ネットワーク制限なし |

## 関連ドキュメント

| 参照先 | 内容 |
| --- | --- |
| `bicep/main.bicep` | インフラ定義の正。リソースグループスコープの定義で、各モジュールを呼び出す |
| `bicep/modules/` | インフラ定義の正。リソースごとのBicepモジュール |
| `bicep/main.bicepparam` | `bicep/main.bicep`に渡すパラメータの値 |
| `scripts/deploy-infra.sh` / `build-images.sh` / `deploy-apps.sh` | デプロイの実体 |
| [develop-guide/deploy.md](../develop-guide/deploy.md) | デプロイの前提条件・使い方・トラブルシュート |
| `api/Containerfile` | APIイメージの定義。Viewerをビルドし、成果物をイメージに同梱する |
| `keycloak/Containerfile` | Keycloakイメージの定義。realm定義をイメージに焼き込む |
| [ADR-0007](../adr/0007-no-network-isolation-for-poc.md) | ネットワーク非分離 |
| [ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md) | ViewerをAPIのContainer Appに同居させて配信する |
| [ADR-0010](../adr/0010-blob-access-full-api-proxy.md) | BlobへのアクセスをAPIでプロキシする |
| [ADR-0030](../adr/0030-cu-analyzer-per-tenant-type.md) | Content Understandingのアナライザをテナント×文書種別ごとに持つ |
| [architecture/auth.md](../architecture/auth.md) | 認証の全体 |
