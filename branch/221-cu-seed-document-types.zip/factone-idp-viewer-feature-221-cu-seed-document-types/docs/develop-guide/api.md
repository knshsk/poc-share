# API開発ガイド

バックエンドAPI（`api/`）の起動・テスト実行手順。

## 前提条件

[uv](https://docs.astral.sh/uv/)がインストールされていること。

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Python本体はuvが自動で取得するため、個別インストールは不要。

## セットアップ

```bash
cd api
uv sync
```

依存パッケージと仮想環境（`api/.venv/`）が作成される。

## データベースのマイグレーション

スキーマはAlembicで管理する。ローカルスタックのPostgreSQL起動後、初回およびスキーマ変更時に適用する。

```bash
cd api
uv run alembic upgrade head
```

モデル（`app/models.py`）を変更したときは、次のコマンドでマイグレーションを作成する。

```bash
cd api
uv run alembic revision --autogenerate -m "<変更内容>"
```

## 起動

```bash
cd api
uv run uvicorn --factory app.main:create_app --reload
```

起動後、`http://127.0.0.1:8000/health`にアクセスして`{"status": "ok"}`が返れば成功。

## テスト実行

```bash
cd api
uv run pytest
```

## API契約の型共有（OpenAPI → TypeScript）

API契約はPydanticモデルを単一情報源とし、次のファイルを生成物としてコミットする。

| 生成物 | 内容 |
| --- | --- |
| `docs/api/openapi.json` | OpenAPIスキーマのエクスポート。外部向け契約レビュー・共有用の正 |
| `viewer/src/api/schema.d.ts` | openapi-typescriptによるTypeScript型 |

APIのエンドポイントやモデルを変更したら、再生成してコミットする。

```bash
cd viewer
npm run generate:api
```

生成物が古いまま（ドリフト）だと、pre-commitの「API契約生成物の差分チェック」が失敗する。

## 設定

アプリケーション設定は`app/core/config.py`の`Settings`で管理する。設定は、環境変数（プレフィックス`FACTONE_`）か、リポジトリルートの`.env`ファイルから読み込む。読み込みは起動ディレクトリに依存しない。ローカルスタック用の変数（`POSTGRES_*`等）も同じファイルに集約し、`FACTONE_`プレフィックスの有無で区別する。

アプリケーション名を変更する例を示す。

```bash
FACTONE_APP_NAME=my-api uv run uvicorn --factory app.main:create_app
```

### Document Intelligence接続

IDP実行APIを実サービスに接続する場合は、リポジトリルートの`.env`に次を設定する。Document Intelligenceのエンドポイントが未設定のときは、実行APIが502を返す。

```bash
# APIキー未設定時はManaged ID認証（Azure上での実行向け）
FACTONE_DI_ENDPOINT=https://<resource-name>.cognitiveservices.azure.com/
FACTONE_DI_API_KEY=<key>
```

### Content Understanding接続

`engine`が`azure-cu`の文書種別をローカルから実サービスで実行する場合は、リポジトリルートの`.env`に次を設定する。`FACTONE_CU_ENDPOINT`が未設定のときは、`azure-cu`の種別の実行APIが502を返す。シードの`purchase_order` / `quotation`は`azure-cu`の種別なので、ローカルでこの2種別をIDP実行するにはこの設定が要る。デプロイ名には、Content Understandingのリソースに置いたチャット補完モデルと埋め込みモデルのデプロイ名を指定する。APIは、アナライザを作る直前に、このデプロイ名をリソースの既定に設定する。既定はリソース全体で1つなので、Azure上のAPIと同じリソースを使うときは、同じデプロイ名を指定する。

```bash
FACTONE_CU_ENDPOINT=https://<resource-name>.cognitiveservices.azure.com/
FACTONE_CU_COMPLETION_DEPLOYMENT=gpt-4o
FACTONE_CU_EMBEDDING_DEPLOYMENT=text-embedding-3-large
```

リソースのキー認証は無効なので、APIキーの設定は無い。APIは`DefaultAzureCredential`で認証し、ローカルでは`az login`の資格情報で呼ぶ。そのため事前に、自分のユーザーへ、リソースのCognitive Services Userロールを付ける。

```bash
az role assignment create --role "Cognitive Services User" --assignee "$(az ad signed-in-user show --query id -o tsv)" --scope "$(az cognitiveservices account show -g <リソースグループ> -n <アカウント名> --query id -o tsv)"
```
