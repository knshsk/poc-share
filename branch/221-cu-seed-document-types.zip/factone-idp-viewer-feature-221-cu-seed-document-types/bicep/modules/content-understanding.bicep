// Azure AI Content Understanding（Foundryリソース）とモデルのデプロイ
// キー認証は無効にし、Entra（APIのManaged ID / ローカルのaz login）だけで呼ぶ

@description('アカウント名（エンドポイントのサブドメインに使用・グローバル一意）')
param accountName string

param location string

resource account 'Microsoft.CognitiveServices/accounts@2025-06-01' = {
  name: accountName
  location: location
  kind: 'AIServices'
  sku: {
    name: 'S0'
  }
  properties: {
    customSubDomainName: accountName
    publicNetworkAccess: 'Enabled'
    disableLocalAuth: true
  }
}

resource completion 'Microsoft.CognitiveServices/accounts/deployments@2025-06-01' = {
  parent: account
  name: 'gpt-4o'
  sku: {
    name: 'Standard'
    capacity: 30
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: 'gpt-4o'
      version: '2024-11-20'
    }
    // 退役日にだけ後継へ更新する（既定の OnceNewDefaultVersionAvailable は、新しい既定の版が決まると退役前でも更新されうる）
    versionUpgradeOption: 'OnceCurrentVersionExpired'
  }
}

resource embedding 'Microsoft.CognitiveServices/accounts/deployments@2025-06-01' = {
  parent: account
  name: 'text-embedding-3-large'
  // 同じアカウントのデプロイは並行して作れないため、補完のデプロイの後に作る
  dependsOn: [completion]
  sku: {
    name: 'Standard'
    capacity: 30
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: 'text-embedding-3-large'
      version: '1'
    }
  }
}

output accountName string = account.name
output endpoint string = account.properties.endpoint
output completionDeploymentName string = completion.name
output embeddingDeploymentName string = embedding.name
