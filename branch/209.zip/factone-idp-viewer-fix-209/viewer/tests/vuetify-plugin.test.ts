import { mount } from '@vue/test-utils'
import { defineComponent } from 'vue'
import { describe, expect, it } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// Vuetifyコンポーネントが実要素として解決されることを確認する回帰テスト。
// 未登録だと <v-text-field> 等が未知要素として素通しされ、画面が素のHTMLになる。
describe('Vuetifyプラグイン設定', () => {
  it('v-text-fieldがinput要素として描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-text-field label="文書ID" /></v-app>',
    })

    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.find('input').exists()).toBe(true)
  })

  it('v-btnがbutton要素として描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-btn>表示</v-btn></v-app>',
    })

    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.find('button').exists()).toBe(true)
  })

  // 入力欄の variant / density は defaults で統一する（コンポーネント側では指定しない）
  it('v-text-field / v-select は props 無しで outlined + compact になる', () => {
    const Probe = defineComponent({
      template:
        '<v-app><v-text-field label="文書ID" /><v-select label="書類種別" /></v-app>',
    })
    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })

    const fields = wrapper.findAll('.v-field')
    expect(fields).toHaveLength(2)
    for (const field of fields) {
      expect(field.classes()).toContain('v-field--variant-outlined')
    }
    for (const input of wrapper.findAll('.v-input')) {
      expect(input.classes()).toContain('v-input--density-compact')
    }
  })

  // カラートークンはvuetify.tsで一元管理する（コンポーネント側hex直書き禁止の前提）
  it('factoneテーマにパレットトークンが定義される', () => {
    const vuetify = createAppVuetify()
    const colors = vuetify.theme.themes.value.factone!.colors
    expect(colors.primary).toBe('#0E65B0')
    expect(colors.canvas).toBe('#E9EDF2')
    expect(colors.warning).toBe('#885B00')
    expect(colors.error).toBe('#BC2A2E')
    expect(colors.success).toBe('#0F730F')
  })

  // Vuetify内部アイコン（$close等）がPhosphorコンポーネントとしてSVG描画されることを確認する
  it('アイコンエイリアスがPhosphorのSVGとして描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-icon icon="$close" /></v-app>',
    })
    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })
    expect(wrapper.find('svg').exists()).toBe(true)
  })

  // v-file-upload のファイル項目は、アイコンの既定値に文字列の mdi-file-document を使う。
  // Phosphor のアイコンセットは文字列のアイコン名を解決しないため、既定値をエイリアスへ差し替える
  it('ファイル項目のアイコンがPhosphorのSVGとして描画される', () => {
    const Probe = defineComponent({
      template: '<v-app><v-file-upload-item /></v-app>',
    })
    const wrapper = mount(Probe, {
      global: { plugins: [createAppVuetify()] },
    })
    expect(wrapper.find('.v-avatar svg').exists()).toBe(true)
  })

  // Vuetifyが出す既定の文言（閉じるボタンの名前など）も、画面の他の文言と同じく日本語にする
  it('Vuetifyの既定の文言が日本語になる', () => {
    expect(createAppVuetify().locale.t('$vuetify.close')).toBe('閉じる')
  })
})

// WCAG 2.2 の相対輝度とコントラスト比（ADR-0024 の基準の検査用）
type Rgb = [number, number, number]
const hexToRgb = (hex: string): Rgb =>
  [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as Rgb
const channel = (c: number): number => {
  const s = c / 255
  return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
}
const luminance = ([r, g, b]: Rgb): number =>
  0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)
const contrast = (a: Rgb, b: Rgb): number => {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x) as [
    number,
    number,
  ]
  return (hi + 0.05) / (lo + 0.05)
}
// 背景 bg に色 fg を不透明度 alpha で重ねた色（丸めない）
const over = (fg: Rgb, bg: Rgb, alpha: number): Rgb =>
  fg.map((c, i) => alpha * c + (1 - alpha) * bg[i]!) as Rgb

describe('テーマ色のコントラスト（WCAG 2.2 AA・ADR-0024）', () => {
  // themes.value.factone は未マージの生定義（variables に high-emphasis-opacity 等の既定値が入らない）。
  // 既定の light テーマとの deep merge 後の値は computedThemes 側にのみ入る（Vuetify 4.1.11 の実装で確認済み）
  const theme = createAppVuetify().theme.computedThemes.value.factone!
  const variable = (key: string): number => Number(theme.variables[key])
  const white = hexToRgb(theme.colors.surface!)
  const onSurface = hexToRgb(theme.colors['on-surface']!)
  // Vuetify の状態のオーバーレイ（選択・ホバー）は、文字色（on-surface × high-emphasis）を各状態の不透明度で重ねる
  const overlay = (opacity: number): Rgb =>
    over(onSurface, white, variable('high-emphasis-opacity') * opacity)
  const activated = variable('activated-opacity')
  const hover = variable('hover-opacity')

  it('contrast は WCAG の既知の値を返す', () => {
    expect(contrast([0, 0, 0], [255, 255, 255])).toBeCloseTo(21, 5)
    expect(contrast([118, 118, 118], [255, 255, 255])).toBeCloseTo(4.54, 2)
  })

  // 文字色に使う色は、白地・自色の淡色地（tonal のチップ・通知・ボタン）・選択行の地のいずれでも、
  // ホバーが重なった状態を含めて 4.5:1 以上
  it.each(['primary', 'secondary', 'warning', 'error', 'success'])(
    '%s は白・淡色・選択行の地で、ホバー時も 4.5:1 以上',
    (name) => {
      const color = hexToRgb(theme.colors[name]!)
      const backgrounds: [string, Rgb][] = [
        ['白', white],
        ['tonal の淡色', over(color, white, activated)],
        [
          'ホバー中のボタンの中の tonal の淡色',
          over(color, overlay(hover), activated),
        ],
        ['tonal のボタンのホバー', over(color, white, activated + hover)],
        ['選択行', overlay(activated)],
        ['選択行 + ホバー', overlay(activated + hover)],
      ]
      for (const [label, background] of backgrounds) {
        expect(contrast(color, background), label).toBeGreaterThanOrEqual(4.5)
      }
    },
  )

  // Vuetify は補助の文字（未入力の入力欄のラベル・一覧の副題など）に on-surface × high-emphasis × medium-emphasis を使う
  it('medium-emphasis の文字は白・選択行の地で、ホバー時も 4.5:1 以上', () => {
    const alpha =
      variable('high-emphasis-opacity') * variable('medium-emphasis-opacity')
    const backgrounds: [string, Rgb][] = [
      ['白', white],
      ['選択行', overlay(activated)],
      ['選択行 + ホバー', overlay(activated + hover)],
    ]
    for (const [label, background] of backgrounds) {
      expect(
        contrast(over(onSurface, background, alpha), background),
        label,
      ).toBeGreaterThanOrEqual(4.5)
    }
  })
})
