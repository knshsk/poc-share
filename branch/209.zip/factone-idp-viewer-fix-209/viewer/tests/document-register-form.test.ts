import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { RegisterVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { configs, registerVm } from './fixtures'

const pdf = new File(['%PDF-1.4'], 'order.pdf', { type: 'application/pdf' })
const bubble = vi.fn()

// フォーカスを確かめるテストは attachTo で document に置く
function mountForm(over: Partial<RegisterVm> = {}, attachTo?: HTMLElement) {
  return mount(DocumentRegisterForm, {
    props: { vm: registerVm(over) },
    attachTo,
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// PDFを選んだ状態にする
async function selectPdf(wrapper: ReturnType<typeof mountForm>) {
  await wrapper
    .findComponent({ name: 'VFileUpload' })
    .vm.$emit('update:modelValue', pdf)
  await flushPromises()
}

// 文書ID・種別・PDFを入力済みにする
async function fillForm(wrapper: ReturnType<typeof mountForm>) {
  await wrapper
    .get('[data-testid="register-document-id"] input')
    .setValue('doc-9')
  await wrapper
    .findComponent({ name: 'VSelect' })
    .vm.$emit('update:modelValue', 'quotation')
  await selectPdf(wrapper)
}

enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentRegisterForm', () => {
  // 種別一覧は vm から受け取り、display_name を選択肢として表示する
  it('vm の種別一覧を選択肢に表示する', () => {
    const select = mountForm().findComponent({ name: 'VSelect' })
    expect(select.props('items')).toEqual(configs)
    expect(select.props('itemTitle')).toBe('display_name')
    expect(select.props('itemValue')).toBe('type_code')
  })

  // 選択肢が無いのは、種別一覧の取得に失敗したときと、テナントに種別が無いとき
  it('選択肢が無いときの文言を指定する', () => {
    const select = mountForm().findComponent({ name: 'VSelect' })
    expect(select.props('noDataText')).toBe('選択できる書類種別がありません')
  })

  // 送信は入力値を register として bubble する（multipart 化と API 呼出は Mediator）
  it('送信で register を bubble する', async () => {
    const wrapper = mountForm()
    await fillForm(wrapper)
    await wrapper.get('form').trigger('submit')
    expect(bubble).toHaveBeenCalledWith({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
  })

  // 未入力（文書ID・種別・PDFのいずれか欠落）では登録ボタンを無効化し、送信しない
  it('未入力では登録ボタンを無効化し送信しない', async () => {
    const wrapper = mountForm()
    const button = wrapper.get<HTMLButtonElement>(
      '[data-testid="register-submit"]',
    )
    expect(button.element.disabled).toBe(true)
    await wrapper.get('form').trigger('submit')
    expect(bubble).not.toHaveBeenCalled()

    await fillForm(wrapper)
    expect(button.element.disabled).toBe(false)
  })

  // ドロップゾーンはPDFのみ受け付け（D&Dはaccept属性が効かないためfilter-by-typeで絞る）、選択後はゾーン内にファイル名を表示する
  it('ドロップゾーンはPDFのみ受け付け選択後はゾーン内にファイル名を表示する', async () => {
    const wrapper = mountForm()
    expect(
      wrapper.findComponent({ name: 'VFileUpload' }).props('filterByType'),
    ).toBe('application/pdf')
    expect(
      wrapper
        .findComponent({ name: 'VFileUploadDropzone' })
        .props('insetFileList'),
    ).toBe(true)

    await selectPdf(wrapper)
    expect(wrapper.get('.v-file-upload-dropzone').text()).toContain('order.pdf')
  })

  // 未選択の枠は、PDFを選ぶボタン（Tabで止まり、Enter・Spaceで選択画面を開く）としてスクリーンリーダーに伝える。
  // 透明なネイティブのファイル入力は、Tabで止まってもフォーカスが見えないため描画から外す
  it('未選択の枠をボタンとして伝え、ファイル入力にはフォーカスを当てない', () => {
    const wrapper = mountForm()
    const zone = wrapper.get('.v-file-upload-dropzone')
    expect(zone.attributes('role')).toBe('button')
    expect(zone.attributes('tabindex')).toBe('0')
    expect(
      wrapper.get<HTMLInputElement>('input[type="file"]').element.style.display,
    ).toBe('none')
  })

  // 選択後の枠の中には解除・変更のボタンがあるため、枠はボタンにせず、Tabでも止めない
  it('選択後の枠はボタンにせず、Tabで止めない', async () => {
    const wrapper = mountForm()
    await selectPdf(wrapper)
    const zone = wrapper.get('.v-file-upload-dropzone')
    expect(zone.attributes('role')).toBeUndefined()
    expect(zone.attributes('tabindex')).toBe('-1')
  })

  // 解除ボタンはアイコンだけなので、名前で用途を伝える
  it('解除ボタンに名前を付ける', async () => {
    const wrapper = mountForm()
    await selectPdf(wrapper)
    expect(
      wrapper.get('.v-file-upload-item button').attributes('aria-label'),
    ).toBe('PDFの選択を解除')
  })

  // 枠はEnter・Spaceでファイル選択を開き、キーの既定の動作を止める。解除ボタンのEnter・Spaceが枠に伝わると、
  // 解除されずに選択画面が開く。Escはダイアログを閉じるキーなので止めない
  it.each([
    ['Enter', false],
    [' ', false],
    ['Escape', true],
  ])(
    '解除ボタンで %j キーを押したとき、枠に伝わるのは Escape だけ（%s）',
    async (key, propagates) => {
      const wrapper = mountForm()
      await selectPdf(wrapper)
      const reachedZone = vi.fn()
      wrapper
        .get('.v-file-upload-dropzone')
        .element.addEventListener('keydown', reachedZone)
      wrapper
        .get('.v-file-upload-item button')
        .element.dispatchEvent(
          new KeyboardEvent('keydown', { key, bubbles: true }),
        )
      expect(reachedZone).toHaveBeenCalledTimes(propagates ? 1 : 0)
    },
  )

  // 解除すると押したボタンが消え、フォーカスがbodyに落ちる。続けてPDFを選び直せるよう、枠へ移す
  it('解除すると選択を消し、フォーカスを枠へ移す', async () => {
    const wrapper = mountForm({}, document.body)
    await selectPdf(wrapper)
    await wrapper.get('.v-file-upload-item button').trigger('click')
    await flushPromises()
    expect(wrapper.find('.v-file-upload-item').exists()).toBe(false)
    expect(document.activeElement).toBe(
      wrapper.get('.v-file-upload-dropzone').element,
    )
  })

  // 種別一覧を取得できなかったことを表示し、再試行は Mediator へ bubble する
  it('種別一覧の取得に失敗すると失敗を表示し、再試行で retryDocumentTypes を bubble する', async () => {
    expect(
      mountForm().find('[data-testid="register-types-error"]').exists(),
    ).toBe(false)

    const wrapper = mountForm({ typeItems: [], typesFailed: true })
    const alert = wrapper.get('[data-testid="register-types-error"]')
    expect(alert.text()).toContain('書類種別')
    await wrapper.get('[data-testid="register-types-retry"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'retryDocumentTypes' })
  })

  // 応答待ちの間は loading にする（disabled にすると、押した直後にフォーカスが外れる）
  it('再試行の応答待ちは、再試行ボタンを loading にする', () => {
    const retry = mountForm({
      typeItems: [],
      typesFailed: true,
      typesLoading: true,
    }).get<HTMLButtonElement>('[data-testid="register-types-retry"]')
    expect(retry.classes()).toContain('v-btn--loading')
    expect(retry.element.disabled).toBe(false)
  })

  // 取得できると、押した再試行ボタンが失敗の表示ごと消えてフォーカスが body に落ちる。続けて選べるよう書類種別へ移す
  it('再試行で取得できると、書類種別へフォーカスを移す', async () => {
    const wrapper = mountForm(
      { typeItems: [], typesFailed: true },
      document.body,
    )
    wrapper
      .get<HTMLButtonElement>('[data-testid="register-types-retry"]')
      .element.focus()
    await wrapper.setProps({ vm: registerVm() })
    await flushPromises()
    expect(document.activeElement).toBe(
      wrapper.get('[data-testid="register-document-type"] input').element,
    )
  })

  // 応答待ちの間に文書IDを打ち始めていれば、取得できてもフォーカスを奪わない
  it('再試行の応答待ちに別の入力欄へ移っていれば、取得できてもフォーカスを動かさない', async () => {
    const wrapper = mountForm(
      { typeItems: [], typesFailed: true },
      document.body,
    )
    const idInput = wrapper.get<HTMLInputElement>(
      '[data-testid="register-document-id"] input',
    ).element
    idInput.focus()
    await wrapper.setProps({ vm: registerVm() })
    await flushPromises()
    expect(document.activeElement).toBe(idInput)
  })

  it('vm のエラーを表示し、送信中はボタンを loading にする', () => {
    const wrapper = mountForm({
      error: '文書IDは別の内容で登録済みです',
      submitting: true,
    })
    expect(wrapper.get('[data-testid="register-error"]').text()).toContain(
      '文書IDは別の内容で登録済み',
    )
    expect(wrapper.get('[data-testid="register-submit"]').classes()).toContain(
      'v-btn--loading',
    )
  })
})
