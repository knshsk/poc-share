import { flushPromises } from '@vue/test-utils'
import { User, type UserManagerSettings } from 'oidc-client-ts'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const signinRedirect = vi.fn()
const signinCallback = vi.fn()
const signoutRedirect = vi.fn()
const getUser = vi.fn()
const signinSilent = vi.fn()
// UserManager に渡した設定と、期限前の通知（addAccessTokenExpiring）に登録した処理
let settings: UserManagerSettings | undefined
let onExpiring: (() => void) | undefined

// User・ストアは本物を使い、通信とタイマーを持つ UserManager だけを差し替える
vi.mock('oidc-client-ts', async (importOriginal) => ({
  ...(await importOriginal<typeof import('oidc-client-ts')>()),
  UserManager: class {
    constructor(s: UserManagerSettings) {
      settings = s
    }
    signinRedirect = signinRedirect
    signinCallback = signinCallback
    signoutRedirect = signoutRedirect
    getUser = getUser
    signinSilent = signinSilent
    events = {
      addAccessTokenExpiring: (cb: () => void) => {
        onExpiring = cb
      },
    }
  },
}))

import { createOidc, resolveReturnTo } from '../src/auth/oidc'

// 残り seconds 秒で期限が切れるユーザー（expires_in は現在時刻から計算される）
function userExpiringIn(seconds: number, accessToken: string): User {
  return new User({
    access_token: accessToken,
    refresh_token: 'refresh',
    token_type: 'Bearer',
    profile: {
      iss: 'http://localhost:8080/realms/factone',
      sub: 'user-1',
      aud: 'factone-viewer',
      exp: 0,
      iat: 0,
    },
    expires_at: Math.floor(Date.now() / 1000) + seconds,
  })
}

beforeEach(() => {
  vi.resetAllMocks()
  settings = undefined
  onExpiring = undefined
  window.history.replaceState(null, '', '/')
})

describe('createOidc', () => {
  // ログイン前の URL（パス＋クエリ）を state に保存し、コールバック後に復元できるようにする
  it('login() はログイン前 URL を state に入れて signinRedirect する', async () => {
    window.history.replaceState(null, '', '/?document_id=doc-1')

    await createOidc().login()

    expect(signinRedirect).toHaveBeenCalledWith({
      state: { returnTo: '/?document_id=doc-1' },
    })
  })

  // コールバックで state の復元先へ replaceState し、ユーザー名を返す
  it('handleCallback() は復元先 URL へ遷移しセッションを返す', async () => {
    window.history.replaceState(null, '', '/callback?code=abc&state=xyz')
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: { preferred_username: 'testuser' },
      state: { returnTo: '/?document_id=doc-1' },
    })

    const session = await createOidc().handleCallback()

    expect(window.location.pathname + window.location.search).toBe(
      '/?document_id=doc-1',
    )
    expect(session).toEqual({ username: 'testuser' })
  })

  it('handleCallback() はユーザーが無ければ null を返す', async () => {
    signinCallback.mockResolvedValue(null)
    expect(await createOidc().handleCallback()).toBeNull()
  })

  it('logout() は signoutRedirect する', async () => {
    await createOidc().logout()
    expect(signoutRedirect).toHaveBeenCalledOnce()
  })
})

describe('accessToken', () => {
  it('ユーザーが無ければ null（未ログイン）', async () => {
    getUser.mockResolvedValue(null)
    expect(await createOidc().accessToken()).toBeNull()
    expect(signinSilent).not.toHaveBeenCalled()
  })

  // 要求のたびに更新しない（Keycloak への要求を増やさない）
  it('期限まで余裕があれば手元のトークンを返し、更新しない', async () => {
    getUser.mockResolvedValue(userExpiringIn(300, 'token-old'))
    expect(await createOidc().accessToken()).toBe('token-old')
    expect(signinSilent).not.toHaveBeenCalled()
  })

  // スリープ復帰や定期更新の失敗の後は、期限切れのトークンが残っている。送信中に切れるトークンも送らない
  it.each([
    ['期限切れ', -10],
    ['期限直前', 30],
  ])('%sのトークンは更新してから新しいトークンを返す', async (_, seconds) => {
    getUser.mockResolvedValue(userExpiringIn(seconds, 'token-old'))
    signinSilent.mockResolvedValue(userExpiringIn(300, 'token-new'))
    expect(await createOidc().accessToken()).toBe('token-new')
    expect(signinSilent).toHaveBeenCalledOnce()
  })

  // 期限内なら手元のトークンで通る。期限切れなら API が 401 を返し、画面は操作ごとの失敗を表示する
  it('更新に失敗したら手元のトークンを返す', async () => {
    getUser.mockResolvedValue(userExpiringIn(30, 'token-old'))
    signinSilent.mockRejectedValue(new Error('Failed to fetch'))
    expect(await createOidc().accessToken()).toBe('token-old')
  })

  // 期限前の通知は、更新に失敗した後にもう一度来るとは限らない。次の API 呼出で更新し直す
  it('更新に失敗した後の呼出で更新し直す', async () => {
    getUser.mockResolvedValue(userExpiringIn(-10, 'token-old'))
    signinSilent
      .mockRejectedValueOnce(new Error('Failed to fetch'))
      .mockResolvedValueOnce(userExpiringIn(300, 'token-new'))
    const oidc = createOidc()

    await oidc.accessToken()

    expect(await oidc.accessToken()).toBe('token-new')
    expect(signinSilent).toHaveBeenCalledTimes(2)
  })

  // API を呼ばない間も期限前に更新し、Keycloak のセッションを保つ（入力中の修正を後で確定できるように）。
  // ライブラリの自動更新を併用すると、更新要求が 2 本になる
  it('期限前の通知で更新する（ライブラリの自動更新は使わない）', () => {
    signinSilent.mockResolvedValue(userExpiringIn(300, 'token-new'))
    createOidc()

    expect(settings?.automaticSilentRenew).toBe(false)
    onExpiring?.()
    expect(signinSilent).toHaveBeenCalledOnce()
  })

  // 期限前の通知と API 呼出（並行する画像の取得など）が重なっても、更新要求は 1 本にまとめる
  it('更新中の呼出は同じ更新の完了を待つ', async () => {
    getUser.mockResolvedValue(userExpiringIn(-10, 'token-old'))
    let resolve!: (user: User) => void
    signinSilent.mockReturnValue(new Promise<User>((r) => (resolve = r)))
    const oidc = createOidc()

    onExpiring?.()
    const tokens = Promise.all([oidc.accessToken(), oidc.accessToken()])
    await flushPromises()
    resolve(userExpiringIn(300, 'token-new'))

    expect(await tokens).toEqual(['token-new', 'token-new'])
    expect(signinSilent).toHaveBeenCalledOnce()
  })
})

// state なし・不正値（外部 URL・スキーム相対・相対パスでない・文字列でない）は "/" へフォールバックする（オープンリダイレクト防止）
describe('resolveReturnTo', () => {
  it.each([
    ['state なし', undefined, '/'],
    ['外部 URL', { returnTo: 'https://evil.example/' }, '/'],
    ['スキーム相対 URL', { returnTo: '//evil.example/' }, '/'],
    ['相対パスでない', { returnTo: 'foo' }, '/'],
    ['文字列でない', { returnTo: 1 }, '/'],
    ['正常', { returnTo: '/?document_id=doc-1' }, '/?document_id=doc-1'],
  ])('%s のとき %s', (_label, state, expected) => {
    expect(resolveReturnTo(state)).toBe(expected)
  })
})
