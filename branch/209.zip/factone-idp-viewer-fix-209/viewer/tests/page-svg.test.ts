import { mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { nextTick } from 'vue'

import PageSvg from '../src/components/PageSvg.vue'
import { BUBBLE } from '../src/mediator/bubble'
import { createAppVuetify } from '../src/plugins/vuetify'

// jsdomに存在しないIntersectionObserverのスタブ。trigger()で交差通知を模擬する
class IntersectionObserverStub {
  static instances: IntersectionObserverStub[] = []
  disconnected = false
  private readonly callback: IntersectionObserverCallback

  constructor(callback: IntersectionObserverCallback) {
    this.callback = callback
    IntersectionObserverStub.instances.push(this)
  }

  observe(): void {}
  disconnect(): void {
    this.disconnected = true
  }

  trigger(isIntersecting: boolean): void {
    this.callback(
      [{ isIntersecting } as IntersectionObserverEntry],
      this as unknown as IntersectionObserver,
    )
  }
}

const bubble = vi.fn()

function mountSvg(
  props: Record<string, unknown> = {},
  options: { attachTo?: HTMLElement } = {},
) {
  return mount(PageSvg, {
    props: { page: 1, width: 8.5, height: 11, ...props },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
    ...options,
  })
}

const rects = [
  {
    id: 'cell:0:1:0',
    kind: 'cell' as const,
    label: '表 1 の 2 行 1 列',
    x: 1,
    y: 3,
    width: 2,
    height: 0.5,
  },
  {
    id: 'field:TotalAmount',
    kind: 'field' as const,
    label: '合計金額',
    x: 6.8,
    y: 2.9,
    width: 0.5,
    height: 0.2,
  },
]

describe('PageSvg', () => {
  beforeEach(() => {
    bubble.mockClear()
    IntersectionObserverStub.instances = []
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  // viewBoxがDI座標系（インチ単位のページ寸法）と一致することを確認する
  it('viewBoxをページ寸法（インチ）で設定する', () => {
    const wrapper = mountSvg()
    expect(wrapper.find('svg').attributes('viewBox')).toBe('0 0 8.5 11')
  })

  // DI polygonの矩形がインチ座標のまま無変換でrect要素になることを確認する
  it('読取矩形をDI座標のままrect描画する', () => {
    const wrapper = mountSvg({
      rects: [
        {
          id: 'field:a',
          kind: 'field',
          label: 'a',
          x: 1.0,
          y: 2.5,
          width: 3.0,
          height: 0.25,
        },
      ],
    })
    const rect = wrapper.find('rect')
    expect(rect.attributes('x')).toBe('1')
    expect(rect.attributes('y')).toBe('2.5')
    expect(rect.attributes('width')).toBe('3')
    expect(rect.attributes('height')).toBe('0.25')
  })

  // 画像の取得は Mediator の責務。View は取得中（imageLoading）だけスピナーを重ね、blob URL が来たら表示する
  it('取得中だけ紙面にスピナーを重ね、imageUrl が来たら image を描画してスピナーを消す', async () => {
    const wrapper = mountSvg() // jsdom は IntersectionObserver が無いので mount 時に pageVisible を bubble 済み
    await nextTick()
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(false)

    await wrapper.setProps({ imageLoading: true })
    expect(wrapper.find('image').exists()).toBe(false)
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    expect(wrapper.get('svg.page-svg').classes()).not.toContain(
      'page-svg--loading',
    )

    await wrapper.setProps({ imageLoading: false, imageUrl: 'blob:mock' })
    expect(wrapper.find('image').attributes('href')).toBe('blob:mock')
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(false)
  })

  // 再試行の応答待ちは失敗の表示を残し、ボタンを loading にする（disabled にすると押した直後にフォーカスが外れる）
  it('失敗と再試行ボタンを表示し、押すと retryPageImage を bubble して、応答待ちはボタンを loading にする', async () => {
    const wrapper = mountSvg({ page: 2, imageFailed: true })
    expect(wrapper.get('[data-testid="page-image-failed"]').text()).toContain(
      'ページを表示できませんでした',
    )
    const retry = wrapper.get('[data-testid="page-image-retry"]')
    await retry.trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'retryPageImage', page: 2 })

    await wrapper.setProps({ imageLoading: true })
    expect(wrapper.find('[data-testid="page-image-failed"]').exists()).toBe(
      true,
    )
    expect(retry.classes()).toContain('v-btn--loading')
    expect(retry.attributes('disabled')).toBeUndefined()
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(false)
  })

  // キーボードでは、紙面の読取矩形より先に再試行ボタンへ移る
  it('再試行ボタンを読取矩形より前に置く', () => {
    const wrapper = mountSvg({ imageFailed: true, rects })
    const focusables = wrapper
      .get('.page')
      .element.querySelectorAll('button, [tabindex="0"]')
    expect(focusables[0]?.getAttribute('data-testid')).toBe('page-image-retry')
  })

  // 取得できると押したボタンが失敗の表示ごと消え、フォーカスが body に落ちる。落ちたときだけページへ移す
  it('再試行の成功でボタンが消えたら、フォーカスをページへ移す', async () => {
    const wrapper = mountSvg(
      { page: 2, imageFailed: true },
      { attachTo: document.body },
    )
    const retry = wrapper.get('[data-testid="page-image-retry"]')
    ;(retry.element as HTMLElement).focus()
    await wrapper.setProps({ imageFailed: false, imageUrl: 'blob:mock' })
    const page = wrapper.get('.page')
    expect(document.activeElement).toBe(page.element)
    expect(page.attributes('role')).toBe('group')
    expect(page.attributes('aria-label')).toBe('2ページ目')
    wrapper.unmount()
  })

  it('応答待ちの間にほかの要素へ移っていれば、成功してもフォーカスを奪わない', async () => {
    const other = document.createElement('input')
    document.body.appendChild(other)
    const wrapper = mountSvg({ imageFailed: true }, { attachTo: document.body })
    other.focus()
    await wrapper.setProps({ imageFailed: false, imageUrl: 'blob:mock' })
    expect(document.activeElement).toBe(other)
    wrapper.unmount()
    other.remove()
  })

  // IntersectionObserver未定義（jsdom既定）では即時に可視化を通知する
  it('IntersectionObserver未定義時は即時に pageVisible を bubble する', () => {
    mountSvg({ page: 2 })
    expect(bubble).toHaveBeenCalledWith({ type: 'pageVisible', page: 2 })
  })

  // 表示領域に入るまで通知せず、入った時に1回だけ通知する
  // （閲覧URL経由ではこの取得がpage_view記録になるため、未表示ページを要求してはならない）
  it('表示領域に入るまで pageVisible を出さず、入った時に1回だけ出す', () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    mountSvg({ page: 3 })

    expect(bubble).not.toHaveBeenCalled()
    const observer = IntersectionObserverStub.instances[0]
    if (!observer) throw new Error('observer not created')

    observer.trigger(false)
    expect(bubble).not.toHaveBeenCalled()

    observer.trigger(true)
    expect(bubble).toHaveBeenCalledTimes(1)
    expect(bubble).toHaveBeenCalledWith({ type: 'pageVisible', page: 3 })
    expect(observer.disconnected).toBe(true)

    observer.trigger(true)
    expect(bubble).toHaveBeenCalledTimes(1)
  })

  // アンマウント時に監視を解除する（未表示のまま離脱した場合の要求抑止）
  it('アンマウント時にIntersectionObserverを解除する', () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    const wrapper = mountSvg()
    wrapper.unmount()
    expect(IntersectionObserverStub.instances[0]?.disconnected).toBe(true)
    expect(bubble).not.toHaveBeenCalled()
  })

  // 矩形は ID 付きで、種別クラス（field は破線・cell は実線）と選択中クラスを持ち、クリックで rectClick を bubble する
  it('矩形にIDと種別・選択中クラスを付け、クリックで rectClick を bubble する', async () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    const wrapper = mountSvg({ rects, activeId: 'field:TotalAmount' })

    const els = wrapper.findAll('rect')
    expect(els).toHaveLength(2)
    expect(els[0]!.attributes('data-rect-id')).toBe('cell:0:1:0')
    expect(els[0]!.classes()).toContain('overlay-rect--cell')
    expect(els[0]!.classes()).not.toContain('overlay-rect--active')
    expect(els[1]!.classes()).toContain('overlay-rect--field')
    expect(els[1]!.classes()).toContain('overlay-rect--active')

    await els[0]!.trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'rectClick', id: 'cell:0:1:0' })
  })

  // 矩形は <title> でアクセシブル名を持ち、Tab で到達して Enter / Space でクリックと同じ選択ができる
  it('矩形に title を付け、Enter / Space で rectClick を bubble する', async () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    const wrapper = mountSvg({ rects: [rects[1]!] })

    const rect = wrapper.get('rect')
    expect(rect.get('title').text()).toBe('合計金額')
    expect(rect.attributes('tabindex')).toBe('0')
    expect(rect.attributes('role')).toBe('button')

    await rect.trigger('keydown', { key: 'Enter' })
    await rect.trigger('keydown', { key: ' ' })
    await rect.trigger('keydown', { key: 'a' })
    expect(bubble.mock.calls).toEqual([
      [{ type: 'rectClick', id: 'field:TotalAmount' }],
      [{ type: 'rectClick', id: 'field:TotalAmount' }],
    ])
  })

  it('activeId 未指定・rects 未指定でも描画できる', () => {
    vi.stubGlobal('IntersectionObserver', IntersectionObserverStub)
    expect(mountSvg().findAll('rect')).toHaveLength(0)
  })
})
