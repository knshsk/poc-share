import { afterEach, describe, expect, it } from 'vitest'

import { apiClient, setTokenSource } from '../src/api/client'

// 要求は送らず、付けた Authorization ヘッダだけを記録する（openapi-fetch の要求単位の fetch）。
// テストの Request は相対 URL を解決できないため、baseUrl を絶対 URL にする
function recordAuthorization(seen: (string | null)[]) {
  return {
    baseUrl: 'http://localhost',
    fetch: async (request: Request): Promise<Response> => {
      seen.push(request.headers.get('Authorization'))
      return new Response('[]', {
        headers: { 'Content-Type': 'application/json' },
      })
    },
  }
}

afterEach(() => {
  setTokenSource(null)
})

describe('apiClient のトークン付与', () => {
  // ログイン時のトークンを使い続けると、寿命（300 秒）を過ぎた要求がすべて 401 になる（#209）
  it('要求ごとに取得元からトークンを取り直して付ける', async () => {
    const tokens = ['token-1', 'token-2']
    setTokenSource(async () => tokens.shift() ?? null)
    const seen: (string | null)[] = []
    const options = recordAuthorization(seen)

    await apiClient.GET('/api/v1/config/document-types', options)
    await apiClient.GET('/api/v1/config/document-types', options)

    expect(seen).toEqual(['Bearer token-1', 'Bearer token-2'])
  })

  // 未ログイン・公開閲覧では取得元が無い。取得元がトークンを返さない（ユーザー無し）ときも付けない
  it('取得元もトークンも無ければ Authorization を付けない', async () => {
    const seen: (string | null)[] = []
    const options = recordAuthorization(seen)

    await apiClient.GET('/api/v1/config/document-types', options)
    setTokenSource(async () => null)
    await apiClient.GET('/api/v1/config/document-types', options)

    expect(seen).toEqual([null, null])
  })
})
