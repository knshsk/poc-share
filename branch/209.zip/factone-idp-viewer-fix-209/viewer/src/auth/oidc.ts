import {
  InMemoryWebStorage,
  UserManager,
  WebStorageStateStore,
  type User,
} from 'oidc-client-ts'

export interface Session {
  username: string | null
}

export interface Oidc {
  login(): Promise<void>
  handleCallback(): Promise<Session | null>
  // API 呼出ごとに呼ぶ。期限が近ければ更新してから返す。未ログインなら null
  accessToken(): Promise<string | null>
  logout(): Promise<void>
}

// 期限のこの秒数前からアクセストークンを更新する。期限前の通知と API 呼出時の判定で共通
const RENEW_BEFORE_SECONDS = 60

// アクセストークンはメモリ保持（localStorage 等へ永続化しない）
function createUserManager(): UserManager {
  return new UserManager({
    // 空文字（ビルド引数未指定）でも既定値へフォールバックさせるため || を使う
    authority:
      import.meta.env.VITE_OIDC_AUTHORITY ||
      'http://localhost:8080/realms/factone',
    client_id: import.meta.env.VITE_OIDC_CLIENT_ID || 'factone-viewer',
    redirect_uri: `${window.location.origin}/callback`,
    post_logout_redirect_uri: window.location.origin,
    scope: 'openid',
    userStore: new WebStorageStateStore({ store: new InMemoryWebStorage() }),
    // 更新は createOidc の renew に一本化する（ライブラリの自動更新と並ぶと更新要求が 2 本になる）
    automaticSilentRenew: false,
    accessTokenExpiringNotificationTimeInSeconds: RENEW_BEFORE_SECONDS,
  })
}

// コールバック後の復元先。同一オリジンの相対パス（"/"始まり・"//"不可）のみ許可し、
// 不正値はトップへフォールバックする（オープンリダイレクト防止）
export function resolveReturnTo(state: unknown): string {
  const returnTo = (state as { returnTo?: unknown } | undefined)?.returnTo
  if (typeof returnTo !== 'string') return '/'
  if (!returnTo.startsWith('/') || returnTo.startsWith('//')) return '/'
  return returnTo
}

export function createOidc(): Oidc {
  const userManager = createUserManager()
  // 実行中の更新（refresh token で取り直す）。期限前の通知と API 呼出が重なっても要求を 1 本にする。
  // 失敗しても次の API 呼出で更新し直す（期限前の通知は、失敗の後にもう一度来るとは限らない）
  let renewing: Promise<User | null> | null = null
  function renew(): Promise<User | null> {
    renewing ??= userManager
      .signinSilent()
      .catch(() => null)
      .finally(() => {
        renewing = null
      })
    return renewing
  }
  // API を呼ばない間も期限前に更新し、Keycloak のセッションを保つ
  userManager.events.addAccessTokenExpiring(() => void renew())
  return {
    async login() {
      // ログイン前 URL（?document_id= 等）を state に保存し、コールバック後に復元する
      await userManager.signinRedirect({
        state: {
          returnTo: `${window.location.pathname}${window.location.search}`,
        },
      })
    },
    async handleCallback() {
      const user = await userManager.signinCallback()
      // 認証済みへ遷移すると Mediator が location.search の document_id を読むため、URL 復元を先に行う
      window.history.replaceState({}, '', resolveReturnTo(user?.state))
      if (!user) return null
      return { username: user.profile?.preferred_username ?? null }
    },
    async accessToken() {
      const user = await userManager.getUser()
      if (!user) return null
      if ((user.expires_in ?? 0) > RENEW_BEFORE_SECONDS) {
        return user.access_token
      }
      // 更新に失敗したら手元のトークンで送る（期限内なら通り、切れていれば API が 401 を返す）
      return ((await renew()) ?? user).access_token
    },
    async logout() {
      await userManager.signoutRedirect()
    },
  }
}
