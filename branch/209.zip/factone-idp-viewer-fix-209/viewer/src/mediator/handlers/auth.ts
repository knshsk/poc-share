import { setTokenSource } from '../../api/client'
import type { Handlers } from '../machine'
import { AUTHED, clearDocument } from '../model'
import { loadPublicPages } from './public'

export const authHandlers: Handlers = {
  // ルーター未導入のためパスで分岐する: /view/{token} は無認証の公開閲覧、/callback は OIDC コールバック、他はログイン画面
  init: {
    in: ['booting'],
    run(ctx, e) {
      const token = e.pathname.split('/')[2]
      if (e.pathname.startsWith('/view/') && token) {
        ctx.model.viewToken = token
        ctx.state.value = 'public'
        loadPublicPages(ctx)
        return
      }
      if (e.pathname === '/callback') {
        ctx.state.value = 'callback'
        void ctx.oidc.handleCallback().then(
          (session) => ctx.dispatch({ type: 'callbackDone', session }),
          () => ctx.dispatch({ type: 'callbackDone', session: null }),
        )
        return
      }
      ctx.state.value = 'login'
    },
  },
  login: {
    in: ['login'],
    run(ctx) {
      void ctx.oidc.login()
    },
  },
  callbackDone: {
    in: ['callback'],
    run(ctx, e) {
      if (!e.session) {
        ctx.state.value = 'login'
        return
      }
      // 要求ごとに oidc から取り直す（期限が近ければ更新したトークンになる）
      setTokenSource(() => ctx.oidc.accessToken())
      ctx.model.username = e.session.username
      ctx.state.value = 'empty'
      // 復元後 URL（oidc.handleCallback が replaceState 済み）に文書 ID があればその文書を開く
      const documentId = new URLSearchParams(window.location.search).get(
        'document_id',
      )
      if (documentId) {
        ctx.dispatch({ type: 'openDocument', documentId })
        return
      }
      // 文書 ID が無ければ文書選択ダイアログを開く（登録フォームの種別一覧もここで取る）
      ctx.dispatch({ type: 'openDocumentPicker' })
    },
  },
  logout: {
    in: AUTHED,
    run(ctx) {
      setTokenSource(null)
      ctx.model.username = null
      clearDocument(ctx.model)
      ctx.model.documentId = ''
      ctx.state.value = 'login'
      void ctx.oidc.logout()
    },
  },
}
