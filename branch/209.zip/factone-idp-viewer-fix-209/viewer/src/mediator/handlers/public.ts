import { apiClient } from '../../api/client'
import { filenameFromDisposition, saveBlob } from '../../utils/download'
import type { Ctx, Handlers } from '../machine'
import { VIEWING, type Model } from '../model'

export function loadPublicPages(ctx: Ctx): void {
  const token = ctx.model.viewToken
  if (!token) return
  void apiClient
    .GET('/view/{token}/pages', { params: { path: { token } } })
    .then(
      ({ data, error }) =>
        ctx.dispatch(
          error || !data
            ? { type: 'publicPagesFailed', token }
            : { type: 'publicPagesLoaded', token, pages: data.pages },
        ),
      () => ctx.dispatch({ type: 'publicPagesFailed', token }),
    )
}

// 画像・原本の取得元は公開閲覧（token）と認証済み（documentId）で分かれる。scope は古い応答を捨てる鍵。
// 同じ文書の開き直しも区別するため読込の世代を含める
function scopeOf(model: Model): string {
  return `${model.viewToken ?? model.documentId}#${model.loadGeneration}`
}

async function fetchImage(model: Model, page: number): Promise<Blob | null> {
  if (model.viewToken) {
    const { data, error } = await apiClient.GET(
      '/view/{token}/pages/{page}/image',
      {
        params: { path: { token: model.viewToken, page } },
        parseAs: 'blob',
      },
    )
    return error ? null : data
  }
  const { data, error } = await apiClient.GET(
    '/api/v1/documents/{document_id}/pages/{page}/image',
    {
      params: { path: { document_id: model.documentId, page } },
      parseAs: 'blob',
    },
  )
  return error ? null : data
}

async function fetchPdf(
  model: Model,
): Promise<{ blob: Blob | null; disposition: string | null }> {
  const { data, error, response } = model.viewToken
    ? await apiClient.GET('/view/{token}/pdf', {
        params: { path: { token: model.viewToken } },
        parseAs: 'blob',
      })
    : await apiClient.GET('/api/v1/documents/{document_id}/pdf', {
        params: { path: { document_id: model.documentId } },
        parseAs: 'blob',
      })
  // 失敗応答は response を持たないモックがあるため、成功時だけヘッダを読む
  if (error || !data) return { blob: null, disposition: null }
  return {
    blob: data,
    disposition: response.headers.get('content-disposition'),
  }
}

// 再試行の失敗は、押してからこの時間が経つまで反映しない（ボタンは loading のまま、押下は捨てる）。
// 失敗がすぐ返るとき（回線断・429）でも連打の要求を 1 ページあたり 1 秒に 1 回までにし、押したことも見せる
const RETRY_HOLD_MS = 1000

// 取得済み・取得中のページは要求しない（再表示・連打で要求を重ねない）。holdMs は失敗の反映を遅らせる
// 最短時間で、要求の時点から数える。成功は待たずに反映する
function requestPageImage(ctx: Ctx, page: number, holdMs = 0): void {
  const m = ctx.model
  if (m.images[page] || m.imageLoading[page]) return
  m.imageLoading[page] = true
  const scope = scopeOf(m)
  const held =
    holdMs > 0 ? new Promise((resolve) => setTimeout(resolve, holdMs)) : null
  const settle = async (blob: Blob | null): Promise<void> => {
    if (!blob && held) await held
    ctx.dispatch({ type: 'pageImageLoaded', scope, page, blob })
  }
  void fetchImage(m, page).then(settle, () => settle(null))
}

export const publicHandlers: Handlers = {
  publicPagesLoaded: {
    in: ['public'],
    run(ctx, e) {
      if (e.token !== ctx.model.viewToken) return
      ctx.model.publicPages = e.pages
    },
  },
  publicPagesFailed: {
    in: ['public'],
    run(ctx, e) {
      if (e.token !== ctx.model.viewToken) return
      ctx.model.errors.public = 'この閲覧URLは無効です'
    },
  },
  // 表示領域に入ったページだけ取得する（閲覧URL経由ではこの取得が page_view 記録になる。ADR-0015）
  pageVisible: {
    in: VIEWING,
    run(ctx, e) {
      requestPageImage(ctx, e.page)
    },
  },
  // 取得に失敗したページの取り直し（PageSvg の可視化通知は 1 回だけなので、利用者の操作で取り直す）
  retryPageImage: {
    in: VIEWING,
    run(ctx, e) {
      requestPageImage(ctx, e.page, RETRY_HOLD_MS)
    },
  },
  pageImageLoaded: {
    in: VIEWING,
    run(ctx, e) {
      const m = ctx.model
      // 文書 / token が切り替わった後の応答は捨てる（blob URL を作らずリークも防ぐ。失敗も記録しない）
      if (e.scope !== scopeOf(m)) return
      delete m.imageLoading[e.page]
      if (e.blob) {
        m.images[e.page] = URL.createObjectURL(e.blob)
        delete m.imageFailed[e.page]
        return
      }
      // HTTP エラー・通信失敗。紙面に失敗と再試行ボタンを表示する
      m.imageFailed[e.page] = true
    },
  },
  // 応答待ちの間の再要求は捨てる（連打で取得要求を重ねない。閲覧URL経由では要求ごとに download が記録される）
  downloadOriginal: {
    in: VIEWING,
    run(ctx) {
      const m = ctx.model
      if (m.downloading) return
      m.downloading = true
      m.downloadFailed = false
      const fallback = m.viewToken ? 'document.pdf' : `${m.documentId}.pdf`
      const scope = scopeOf(m)
      void fetchPdf(m).then(
        ({ blob, disposition }) => {
          if (!blob) {
            ctx.dispatch({ type: 'downloadFailed', scope })
            return
          }
          ctx.dispatch({ type: 'downloaded', scope })
          saveBlob(blob, filenameFromDisposition(disposition, fallback))
        },
        () => ctx.dispatch({ type: 'downloadFailed', scope }),
      )
    },
  },
  // 文書 / token が切り替わった後の完了は捨てる（応答待ちは切替で解いてあり、切替後の文書の表示を変えない）
  downloaded: {
    in: VIEWING,
    run(ctx, e) {
      if (e.scope !== scopeOf(ctx.model)) return
      ctx.model.downloading = false
    },
  },
  // 失敗は通知だけにする（表示中の文書・未保存の修正・実行中の処理はそのまま）
  downloadFailed: {
    in: VIEWING,
    run(ctx, e) {
      if (e.scope !== scopeOf(ctx.model)) return
      ctx.model.downloading = false
      ctx.model.downloadFailed = true
    },
  },
}
