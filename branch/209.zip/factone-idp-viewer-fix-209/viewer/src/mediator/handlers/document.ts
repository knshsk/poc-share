import { apiClient } from '../../api/client'
import type { Problem } from '../events'
// machine.ts と循環 import。guardDirty は関数宣言で run() 内からだけ呼ぶため安全（const 化しない）
import { guardDirty, type Ctx, type Handlers } from '../machine'
import { AUTHED, clearDocument, PICKABLE } from '../model'
import { loadRuns } from './runs'

// 文書切替。文書選択ダイアログを閉じ、画像 blob を全 revoke し文書系の状態を初期化してから、
// 文書・ページ・種別設定を並行取得する
export function loadDocument(ctx: Ctx, documentId: string): void {
  ctx.model.documentPickerOpen = false
  clearDocument(ctx.model)
  ctx.model.documentId = documentId
  ctx.state.value = 'loadingDocument'
  void Promise.all([
    apiClient.GET('/api/v1/documents/{document_id}', {
      params: { path: { document_id: documentId } },
    }),
    apiClient.GET('/api/v1/documents/{document_id}/pages', {
      params: { path: { document_id: documentId } },
    }),
    apiClient.GET('/api/v1/config/document-types'),
  ]).then(
    ([doc, pages, configs]) => {
      if (doc.error || !doc.data || pages.error || !pages.data) {
        ctx.dispatch({ type: 'documentFailed', documentId })
        return
      }
      ctx.dispatch({
        type: 'documentLoaded',
        documentId,
        document: doc.data,
        pages: pages.data.pages,
        configs: configs.data ?? null,
      })
    },
    () => ctx.dispatch({ type: 'documentFailed', documentId }),
  )
}

// 登録の失敗の文言。失敗の種類は Problem Details の type で見分け、detail（API の英語の説明文）は出さない
function registerErrorMessage(problem?: Problem): string {
  switch (problem?.type) {
    case '/errors/document-conflict':
      return '文書IDは別の内容で登録済みです'
    // 画面では書類種別を一覧から選び、PDF も必須なので、検証エラーは文書IDに限られる。
    // errors が付くのは長さの超過、付かないのは使えない文字（/ \ と制御文字、. と .. そのもの）
    case '/errors/validation-error':
      return problem.errors
        ? '文書IDは255文字以内で入力してください'
        : '文書IDに使用できない文字が含まれています'
    case '/errors/unsupported-media-type':
      return 'PDFではないファイルが選択されています'
    case '/errors/invalid-pdf':
      return 'PDFを開けません。壊れているか、閲覧パスワードが設定されています'
    case '/errors/unknown-document-type':
      return '選んだ書類種別は削除されています。書類種別を選び直してください'
    default:
      return '登録に失敗しました'
  }
}

// 登録フォームの種別一覧を取る。取得済み・応答待ちなら取らない（開き直しと再試行が重なっても要求は 1 本）
function loadDocumentTypes(ctx: Ctx): void {
  const register = ctx.model.register
  if (register.typeItems.length > 0 || register.typesLoading) return
  register.typesLoading = true
  void apiClient.GET('/api/v1/config/document-types').then(
    ({ data, error }) =>
      ctx.dispatch(
        error || !data
          ? { type: 'documentTypesFailed' }
          : { type: 'documentTypesLoaded', items: data },
      ),
    () => ctx.dispatch({ type: 'documentTypesFailed' }),
  )
}

export const documentHandlers: Handlers = {
  // 種別一覧の応答は、ダイアログを閉じた後や読込中にも受ける（捨てると応答待ちのまま固まり、二度と取り直せない）
  documentTypesLoaded: {
    in: AUTHED,
    run(ctx, e) {
      const register = ctx.model.register
      register.typeItems = e.items
      register.typesLoading = false
      register.typesFailed = false
    },
  },
  documentTypesFailed: {
    in: AUTHED,
    run(ctx) {
      ctx.model.register.typesLoading = false
      ctx.model.register.typesFailed = true
    },
  },
  openDocument: {
    in: PICKABLE,
    run(ctx, e) {
      // 未保存の修正があれば確認ダイアログ（confirmProceed で再 dispatch される）
      if (ctx.state.value === 'document' && guardDirty(ctx, e)) return
      loadDocument(ctx, e.documentId)
    },
  },
  // 開くたびに前回の登録エラーを消す。種別一覧が無ければ取る（document_id 付きの URL で入ったとき・前回の取得失敗）
  openDocumentPicker: {
    in: PICKABLE,
    run(ctx) {
      ctx.model.documentPickerOpen = true
      ctx.model.register.error = null
      loadDocumentTypes(ctx)
    },
  },
  // 種別一覧の取得に失敗したときの、登録フォームの再試行
  retryDocumentTypes: {
    in: PICKABLE,
    run(ctx) {
      loadDocumentTypes(ctx)
    },
  },
  // registering では受けない（送信中は × と Esc で閉じない）
  closeDocumentPicker: {
    in: PICKABLE,
    run(ctx) {
      ctx.model.documentPickerOpen = false
    },
  },
  // 定型外フロー向けの手動登録。送信先は既存の POST /api/v1/documents（Power Automate と同一 API）。
  // 表示中の文書は送信の時点で閉じる（前の文書の完了イベントを registering で受けずに済む）
  register: {
    in: PICKABLE,
    run(ctx, e) {
      // 未保存の修正があれば確認ダイアログ（confirmProceed で再 dispatch される）
      if (ctx.state.value === 'document' && guardDirty(ctx, e)) return
      clearDocument(ctx.model)
      ctx.model.documentId = ''
      ctx.model.register.error = null
      ctx.state.value = 'registering'
      const form = new FormData()
      form.set('document_id', e.documentId)
      form.set('document_type', e.documentType)
      form.set('file', e.file)
      void apiClient
        .POST('/api/v1/documents', {
          // OpenAPI 型は binary=string だが実体は File。multipart 化は bodySerializer で行う
          body: {
            document_id: e.documentId,
            document_type: e.documentType,
            file: e.file as unknown as string,
          },
          bodySerializer: () => form,
        })
        .then(
          ({ data, error }) => {
            if (error || !data) {
              ctx.dispatch({ type: 'registerFailed', problem: error })
              return
            }
            // 200（同一内容の再送）も登録済みとして成功扱い
            ctx.dispatch({ type: 'registered', documentId: data.document_id })
          },
          () => ctx.dispatch({ type: 'registerFailed' }),
        )
    },
  },
  registered: {
    in: ['registering'],
    run(ctx, e) {
      loadDocument(ctx, e.documentId)
    },
  },
  registerFailed: {
    in: ['registering'],
    run(ctx, e) {
      ctx.model.register.error = registerErrorMessage(e.problem)
      ctx.state.value = 'empty'
      // 一覧の取得後に、選んだ種別の設定が削除された。一覧を取り直して選び直せるようにする
      if (e.problem?.type === '/errors/unknown-document-type') {
        ctx.model.register.typeItems = []
        loadDocumentTypes(ctx)
      }
    },
  },
  documentLoaded: {
    in: ['loadingDocument'],
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      // 種別設定（display_name・shareable・fields）を反映する。設定取得失敗・設定なしは
      // 表示名フォールバック（種別コード）・共有不可・全項目表示のまま継続する
      const config = e.configs?.find(
        (c) => c.type_code === e.document.document_type,
      )
      ctx.model.document = {
        type: e.document.document_type,
        displayName: config?.display_name ?? null,
        originalFilename: e.document.original_filename,
        shareable: config?.shareable ?? false,
        fieldDefs: config?.fields ?? [],
        pages: e.pages,
      }
      ctx.state.value = 'document'
      loadRuns(ctx)
    },
  },
  documentFailed: {
    in: ['loadingDocument'],
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.errors.document = '文書を取得できませんでした'
      ctx.state.value = 'documentError'
    },
  },
  retryLoad: {
    in: ['documentError'],
    run(ctx) {
      loadDocument(ctx, ctx.model.documentId)
    },
  },
}
