import { computed, type ComputedRef, type Ref } from 'vue'

import type { IdpRun, IdpRunSummary } from '../utils/runs'
import type { PageSize } from '../utils/zoom'
import type { Tab } from './events'
import {
  AUTHED,
  draftCount,
  PICKABLE,
  type FieldDef,
  type Model,
  type Request,
  type State,
} from './model'

// 各 View が受け取る ViewModel。View は自分の型 1 つだけを prop で受け、子には部分を渡す

export interface HeaderVm {
  documentId: string
  // 原本ファイル名。null（読込中・ファイル名の無い文書）のとき View は文書 ID を主表示にする
  documentName: string | null
  documentTypeLabel: string | null
  authenticated: boolean
  // 文書選択ダイアログを開ける（Mediator が openDocumentPicker を受ける）。false の間、文書タイトルは押せない表示
  pickable: boolean
  username: string | null
}

export interface CanvasVm {
  pages: PageSize[]
  run: IdpRun | null
  fieldDefs: FieldDef[]
  images: Record<number, string>
  // 画像を取得中のページ（紙面のスピナーと、再試行ボタンの loading）
  imageLoading: Record<number, true>
  // 画像の取得に失敗したページ（紙面に失敗と再試行ボタンを表示する）
  imageFailed: Record<number, true>
  activeId: string | null
  scrollRequest: Request | null
  downloadLabel: string
  // 原本の応答待ち（ボタンを loading にする）と取得失敗の通知
  downloading: boolean
  downloadFailed: boolean
}

export interface PublicVm {
  error: string | null
  canvas: CanvasVm | null
}

// 登録フォーム。種別一覧とその取得状態・登録エラーはモデルのまま渡し、送信中は状態（registering）から作る
export type RegisterVm = Model['register'] & { submitting: boolean }

// 文書選択ダイアログ。documentId は表示中（または取得に失敗した）文書の ID で、空なら登録タブ、
// あれば参照タブにこの ID を入れて開く
export interface PickerVm {
  open: boolean
  documentId: string
  register: RegisterVm
}

export interface EditorVm {
  run: IdpRun
  fieldDefs: FieldDef[]
  draftFields: Record<string, string | null>
  draftCells: Record<string, string>
  activeId: string | null
  focusRequest: Request | null
}

export type ViewUrlsVm = Omit<Model['viewUrls'], 'loadedFor'>

export interface WorkPanelVm {
  runs: IdpRunSummary[]
  selectedRun: IdpRun | null
  activeTab: Tab
  executing: boolean
  saving: boolean
  loadingRuns: boolean
  runsLoadFailed: boolean
  error: string | null
  shareable: boolean
  draftCount: number
  savedSnackbar: boolean
  confirmDiscard: boolean
  editor: EditorVm | null
  viewUrls: ViewUrlsVm
}

export interface DocumentVm {
  phase: 'empty' | 'registering' | 'loading' | 'error' | 'ready'
  error: string | null
  picker: PickerVm
  canvas: CanvasVm | null
  workPanel: WorkPanelVm | null
}

export interface RootVm {
  screen: 'login' | 'loading' | 'public' | 'document'
  header: HeaderVm
  public: PublicVm | null
  document: DocumentVm | null
  dirty: boolean
}

// state → DocumentVm.phase。表に無い状態（document / executing / saving / confirmDiscard）は ready
const PHASE: Partial<Record<State, DocumentVm['phase']>> = {
  empty: 'empty',
  registering: 'registering',
  loadingDocument: 'loading',
  documentError: 'error',
}

// state → RootVm.screen。表に無い状態（AUTHED）は document。起動処理（booting）とコールバック処理中（callback）は
// 読込中の画面にする（ログインカードを出さない）
const SCREEN: Partial<Record<State, RootVm['screen']>> = {
  booting: 'loading',
  callback: 'loading',
  login: 'login',
  public: 'public',
}

// スライスごとに computed を分け、変化した部分だけ参照が変わるようにする
// （draft 入力で canvas の参照は変わらず、DocumentCanvas / PageSvg は再描画されない）
export function buildVm(state: Ref<State>, model: Model): ComputedRef<RootVm> {
  const header = computed<HeaderVm>(() => ({
    documentId: model.documentId,
    // || null: 空文字が来ても null に寄せる防御（列追加前の行は null、API も空文字を None に正規化して
    // 返すため通常は空文字は来ない）。?? だと空文字がそのまま残り、主表示の `??` と ID 表示の `v-if` が
    // 食い違ってタイトルが空になる（AppHeader.vue）
    documentName: model.document?.originalFilename || null,
    documentTypeLabel: model.document
      ? (model.document.displayName ?? model.document.type)
      : null,
    authenticated: AUTHED.includes(state.value),
    pickable: PICKABLE.includes(state.value),
    username: model.username,
  }))

  const publicCanvas = computed<CanvasVm | null>(() =>
    model.publicPages.length === 0
      ? null
      : {
          pages: model.publicPages,
          run: null,
          fieldDefs: [],
          images: model.images,
          imageLoading: model.imageLoading,
          imageFailed: model.imageFailed,
          activeId: null,
          scrollRequest: null,
          downloadLabel: 'ダウンロード',
          downloading: model.downloading,
          downloadFailed: model.downloadFailed,
        },
  )

  const publicVm = computed<PublicVm | null>(() =>
    state.value === 'public'
      ? { error: model.errors.public, canvas: publicCanvas.value }
      : null,
  )

  const documentCanvas = computed<CanvasVm | null>(() => {
    const doc = model.document
    if (!doc) return null
    return {
      pages: doc.pages,
      run: model.selectedRun,
      fieldDefs: doc.fieldDefs,
      images: model.images,
      imageLoading: model.imageLoading,
      imageFailed: model.imageFailed,
      activeId: model.activeId,
      scrollRequest: model.canvasScroll,
      downloadLabel: '原本ダウンロード',
      downloading: model.downloading,
      downloadFailed: model.downloadFailed,
    }
  })

  const register = computed<RegisterVm>(() => ({
    ...model.register,
    submitting: state.value === 'registering',
  }))

  const picker = computed<PickerVm>(() => ({
    open: model.documentPickerOpen,
    documentId: model.documentId,
    register: register.value,
  }))

  const editor = computed<EditorVm | null>(() => {
    const run = model.selectedRun
    const doc = model.document
    if (!run || !doc || run.status !== 'succeeded') return null
    return {
      run,
      fieldDefs: doc.fieldDefs,
      draftFields: model.draft.fields,
      draftCells: model.draft.cells,
      activeId: model.activeId,
      focusRequest: model.paneFocus,
    }
  })

  const viewUrls = computed<ViewUrlsVm>(() => model.viewUrls)

  const workPanel = computed<WorkPanelVm | null>(() => {
    const doc = model.document
    if (!doc) return null
    return {
      runs: model.runs,
      selectedRun: model.selectedRun,
      activeTab: model.activeTab,
      executing: state.value === 'executing',
      saving: state.value === 'saving',
      // 一覧の取得中と、一覧の取得後に最初の詳細を待っている間
      // （結果のある文書で「実行結果がありません」を一瞬出さない）。詳細の取得に失敗したらエラー表示に譲る
      loadingRuns:
        model.runsLoading ||
        (model.pendingRunId !== null &&
          model.selectedRun === null &&
          model.errors.workPanel === null),
      runsLoadFailed: model.runsLoadFailed,
      error: model.errors.workPanel,
      shareable: doc.shareable,
      draftCount: draftCount(model.draft),
      savedSnackbar: model.savedSnackbar,
      confirmDiscard: state.value === 'confirmDiscard',
      editor: editor.value,
      viewUrls: viewUrls.value,
    }
  })

  const documentVm = computed<DocumentVm | null>(() => {
    if (!AUTHED.includes(state.value)) return null
    const phase = PHASE[state.value] ?? 'ready'
    return {
      phase,
      error: model.errors.document,
      picker: picker.value,
      canvas: phase === 'ready' ? documentCanvas.value : null,
      workPanel: phase === 'ready' ? workPanel.value : null,
    }
  })

  return computed<RootVm>(() => ({
    screen: SCREEN[state.value] ?? 'document',
    header: header.value,
    public: publicVm.value,
    document: documentVm.value,
    dirty: draftCount(model.draft) > 0,
  }))
}
