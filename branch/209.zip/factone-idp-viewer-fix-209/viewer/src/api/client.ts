import createClient from 'openapi-fetch'

import type { paths } from './schema'

// 同一オリジン前提（本番はContainer Apps同居配信、ローカルはVite devプロキシ）
export const apiClient = createClient<paths>({ baseUrl: '/' })

// アクセストークンの取得元。Mediator が OIDC コールバック後に設定し、ログアウトで外す。
// トークンは更新されるため保持せず、要求ごとに取得元から取り直す
type TokenSource = () => Promise<string | null>
let tokenSource: TokenSource | null = null

export function setTokenSource(source: TokenSource | null): void {
  tokenSource = source
}

apiClient.use({
  async onRequest({ request }) {
    const token = await tokenSource?.()
    if (token) {
      request.headers.set('Authorization', `Bearer ${token}`)
    }
    return request
  },
})
