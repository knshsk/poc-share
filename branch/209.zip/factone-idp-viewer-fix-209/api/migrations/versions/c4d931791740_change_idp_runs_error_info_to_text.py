"""idp_runs.error_info を text にする

DI の例外メッセージを切り詰めずに保存する（ADR-0028）。varchar から text への変更では、
PostgreSQL は表を書き換えない。

downgrade は、2048 文字を超える値があると失敗する（旧スキーマでは表現できない）。

Revision ID: c4d931791740
Revises: d7e4b2c9a1f6
Create Date: 2026-10-04 12:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "c4d931791740"
down_revision: str | None = "d7e4b2c9a1f6"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.alter_column("idp_runs", "error_info", type_=sa.Text())


def downgrade() -> None:
    op.alter_column("idp_runs", "error_info", type_=sa.String(2048))
