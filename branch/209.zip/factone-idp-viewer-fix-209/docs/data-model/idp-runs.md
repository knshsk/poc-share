# IDP実行ログ（idp_runs）

Document Intelligenceによる項目抽出の実行履歴と、Viewerからの人手修正結果。追記型であり、再実行や修正で過去の結果を上書きしない。

API応答（`IdpRunResponse`）は本テーブルの列をそのまま返さず、`fields[key] = {value, normalized_value, confidence}`に組み直す。`field_labels` / `field_regions` / セルの`polygon` / `corrections`は、クエリ`verbose=true`のときだけ返す。返す位置は、それぞれ`fields[key].label` / `fields[key].region` / `tables[].cells[].polygon` / `corrections`である（[ADR-0022](../adr/0022-idp-run-response-single-schema-verbose.md)）。応答の正は[api/openapi.json](../api/openapi.json)。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 実行ID（サーバ採番） |
| document_pk | uuid | NOT NULL・FK(documents.id) | 対象文書（内部ID）。API応答の`document_id`はdocuments経由で返す |
| run_type | varchar(20) | NOT NULL・CHECK | `initial`（初回）/ `rerun`（再実行）/ `corrected`（人手修正）。初回か再実行かは、同一文書IDの既存実行の有無からサーバ側で自動判定する。失敗した実行と修正行も既存実行に数える |
| status | varchar(20) | NOT NULL・CHECK | `succeeded` / `failed` |
| executed_at | timestamptz | NOT NULL | 実行日時（サーバで記録） |
| raw_fields | jsonb | NULL可 | 項目別の生値で、DIが返した文字列そのまま。失敗時はNULL |
| normalized_fields | jsonb | NULL可 | 項目別の正規化値（下記「正規化規則」）。正規化できない値はnull |
| confidence | jsonb | NULL可 | 項目別確信度（0〜1）。APIは返却・記録のみで、閾値判定には使用しない。Viewerは確信度0.8未満の値に「要確認」を表示する（[result-panel.md](../viewer/result-panel.md)） |
| field_labels | jsonb | NULL可 | 項目別の表示ラベル。実行時点の文書種別設定`fields[].label`のスナップショット。失敗時はNULL |
| tables | jsonb | NULL可 | DIが認識したテーブル領域（明細仮）の配列。成功時はテーブル未検出でも空配列、失敗時はNULL |
| pattern_matches | jsonb | NULL可 | 文書種別設定の`patterns`をDI全文テキストに適用した結果（下記）。成功時はパターン未設定でも空オブジェクト、失敗時はNULL |
| field_regions | jsonb | NULL可 | 項目別の読取領域（下記）。成功時はキーを全項目分持ち、領域なし・値なしの項目はnull。失敗時はNULL |
| di_api_version | varchar(20) | NULL可 | DI応答の`analyzeResult.apiVersion`（例: `2024-11-30`）。失敗時はNULL |
| di_model_id | varchar(100) | NULL可 | DI応答の`analyzeResult.modelId`（現在は`prebuilt-layout`）。失敗時はNULL |
| raw_response_ref | varchar(1024) | NULL可 | 生応答のBlobパス`{tenant_id}/{document_id}/idp-runs/{run_id}.json`。失敗時はNULL |
| base_run_id | uuid | NULL可・FK(idp_runs)・CHECK | 修正元の実行結果。`corrected`行のみ非NULL（`ck_idp_runs_corrected_base`） |
| corrected_by | varchar(255) | NULL可・CHECK | 修正者。JWTの`preferred_username`で、無い場合は`sub`。`corrected`行のみ非NULL（`ck_idp_runs_corrected_by`） |
| corrections | jsonb | NULL可 | 根の機械実行に対する人手差分の累積（下記）。`corrected`行のみ非NULL |
| error_info | text | NULL可 | 失敗時のエラー情報。DIの例外メッセージを切り詰めずに保存する（ADR-0028） |

生値・正規化値・確信度は分離して保持する。生OCR結果と正規化値を分離する方針に基づく。JSONのキーは、実行時点の文書種別設定の`fields[].key`と一致する。未抽出の項目もキーを残し、値をnullにする。

### 正規化規則

型は文書種別設定の`fields[].type`。どの型の値もまずNFKC正規化し、`string`はその結果を正規化値とする。`number` / `date`はさらに次を適用し、当てはまらなければnullとする。実装は`api/app/services/idp_extraction.py`の`_normalize`で、Viewerの`viewer/src/utils/normalize.ts`も同じ規則に従う。

- `number`: `¥` `円` `,` `、`と空白を除いて整数化する（例: `￥74,800` → `74800`、`７４，８００` → `74800`）。小数はnull
- `date`: 西暦`YYYY[-/.年]M[-/.月]D[日]`または和暦`(令和|平成|昭和|R|H|S)N[-/.年]M[-/.月]D[日]`（`元`可）を`YYYY-MM-DD`にする。どちらも月・日のゼロ埋めは任意で、要素の間の空白を許容する（例: `令和 8年 9月 4日` → `2026-09-04`）。暦上存在しない日付はnull

### tables（テーブル領域）の構造

各要素は`row_count` / `column_count` / `cells`を持つ。複数のテーブルを認識したときは、全件を保持する。

`cells`の各要素は、`row_index` / `column_index` / `row_span` / `column_span` / `content` / `kind` / `page_number` / `polygon`を持つ。`row_span` / `column_span`は結合セルの行数・列数。`row_span` / `column_span`のキーを持たないセルには、APIが1を補う。`kind`は`columnHeader`などの値で、無い場合はnull。`polygon`は座標配列で、無い場合はnull。API応答で`polygon`を返すのは、`verbose=true`のときのみ。

DIの認識結果は、意味付けせずに素通しする。どのテーブルが明細領域か、どの列・行がSAP入力項目の何に相当するかの判断は、SaaS側の責務外である。利用側で解釈する。

### pattern_matches（正規表現マッチ結果）の構造

キーは設定の`patterns[].key`。値は、実行時点の`label` / `regex`と、全文テキストへの一致値の配列。

```json
{
  "TCode": {"label": "登録番号", "regex": "T\\d{13}", "values": ["T1234567890123"]},
  "QuotationNo": {"label": "見積番号", "regex": "Q-\\d{6}", "values": []}
}
```

`values`は出現順に並べ、重複を除去しない。同じ文字列が複数箇所にあれば、その回数分並ぶ。一致が0件でもキーを残す。

長さ0の一致は`values`に含めない。`\d*`などが空文字に一致した場合がこれにあたる。空文字は情報を持たず、文字位置ごとに1件生成されて結果が肥大するためである。

実行時点の`label` / `regex`を同梱するため、設定を変更した後も当時の条件を再現できる。一致値の妥当性検証は、外部システムの責務とする（PoC）。

### field_regions（項目別読取領域）の構造

キーはQuery Fieldsのキー。値は、DI応答`documents[].fields[key].boundingRegions[0]`の`pageNumber` / `polygon`である。`documents`の要素はすべて読み、同じキーが複数の要素にあれば後の要素の値を採る。単位はインチで、SVGのviewBoxと同一の座標系。

```json
{
  "TotalAmount": {"page_number": 1, "polygon": [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1]},
  "QuotationId": null
}
```

Viewerで、キャンバスと右ペインを相互にハイライトするときのデータ源になる。API応答では、`verbose=true`のとき`fields[key].region`として返す。領域が無い項目と未抽出の項目はnull。

### 生応答の保存（Blob）

DIの最終ポーリングGETの応答本文を、bytesのままBlob `{tenant_id}/{document_id}/idp-runs/{run_id}.json`に保存する。応答本文は`status` / `createdDateTime` / `lastUpdatedDateTime` / `analyzeResult`を含むラッパ込みのJSONで、再シリアライズしない（ADR-0019）。

用途は、`tables` / `fields`以外の情報（words / lines / paragraphsなど）を使う将来機能への互換と、カスタムモデルの学習データである。学習データとしては、DI Studioの`.ocr.json`と同形になる。

保存は次の順に行う。

1. DIの実行が成功する。
2. Blobへ保存する。
3. 実行ログをINSERTする。

Blobへの保存が失敗すると500となり、実行ログは残さない。Blobのコンテンツタイプは設定せず、取得APIが`application/json`で返す。

### corrected行（人手修正）の値

人手修正は、`base_run_id`の実行結果に差分を当てた新しい行として追記する（ADR-0018）。`corrected`行をbaseにした再修正（連鎖）も許す。排他制御は行わず、同一baseへの並行修正は両方とも追記され、`latest`は新しい方を返す。この扱いはPoCの制限である。

| 列 | 値 |
| --- | --- |
| status | `succeeded`固定 |
| executed_at | 確定日時（サーバ時刻） |
| error_info | NULL |
| raw_fields | baseの値に`corrections.fields`を上書きしたもの |
| normalized_fields | 変更したキーのみ再正規化する。型は**現在の**文書種別設定`fields[].type`を参照する。実行ログが型を保持していないためである。設定に無いキーは`string`として扱う。正規化できない入力も受理し、nullにする。未変更のキーはbaseの値を維持 |
| confidence | 変更したキーはnull。人手の値に機械の確信度は付けない。未変更のキーはbaseの値を維持 |
| field_labels / pattern_matches / field_regions | baseからコピーする。修正したキーの`field_regions`もbaseの領域を維持し、DIが読んだ場所へ遷移できるようにする |
| tables | baseの構造（`row_count` / `column_count` / セルの`kind` / `row_span` / `column_span` / `page_number` / `polygon`）を維持し、`corrections.table_cells`の`content`だけを差し替える |
| di_api_version / di_model_id / raw_response_ref | baseからコピーする。修正行からも元のDI応答へ辿れる。学習用に「修正済み値 + 元OCR」の対を取得できる |

### corrections（累積差分）の構造

修正APIのリクエストボディと同じ形。内容はbaseの種類によって異なる。

| base | 保存する差分 |
| --- | --- |
| 機械実行 | リクエストボディそのまま |
| `corrected`行 | baseの`corrections`に今回のボディを重ねた累積差分 |

重ねるときは、同一キー・同一セル座標を今回の値で上書きする。セルはbaseの並びを維持し、新しい座標を末尾に追加する。連鎖修正のどの世代を見ても、「根の機械実行から人が変えたキー / セル」の全体が分かる。1世代分の差分が必要な場合は、base行の値と比較して復元する。

```json
{
  "fields": {"TotalAmount": "1,250,000", "DeliveryDate": null},
  "table_cells": [
    {"table_index": 0, "row_index": 2, "column_index": 3, "content": "10"}
  ]
}
```

| キー | 値 | 省略時 |
| --- | --- | --- |
| `fields` | キーから文字列またはnullへの対応。nullは「値なし」への訂正を表す | `{}` |
| `table_cells` | `table_index` / `row_index` / `column_index`（0始まりの整数）と`content`（文字列。空文字可）の組の配列 | `[]` |

文字列は各2000文字が上限。`fields`と`table_cells`の両方が空の場合、同一セル座標が重複する場合、値の文字列がNULを含む場合は、422 `validation-error`となる。値がbaseと同一かどうかは検査しない。クライアントが差分のみを送る前提である。省略したキーは、上の表の「省略時」の値を補って保存する。保存形状を一定にするためである。

## 抽出方式

抽出にはprebuilt-layout+Query Fieldsを使う。学習やラベリングなしで、項目を指定した抽出と項目別の確信度を取得できる。

Query Fieldsに指定する項目は、文書の種別に対応する文書種別設定の`fields[].key`である。項目はテナントと文書種別ごとに設定で決まる。シードの項目は[document-type-configs.md](document-type-configs.md)の「シードデータ」にある。

WBS原価データは、様式が確定するまで対象外とする。

応答は同期で返す。非同期化の要否は、処理時間とサイズ上限が確定した後に再検討する。タイムアウトは設定値`FACTONE_DI_TIMEOUT_SECONDS`で、既定は120秒。超過したときはDI失敗（`DiError`）として扱う。

正規表現パターンマッチは、Query Fieldsで取得しづらい項目（見積番号・Tコードなど）を補うためのもの。文書種別設定の`patterns`を、DI応答の全文テキスト（`content`）に`re.finditer`で適用する。全一致は`pattern_matches`に保存する。

## API

以下のAPIは、いずれもJWT必須。

`POST /api/v1/documents/{document_id}/idp-runs`は、登録済みの文書に対して抽出を実行し、結果を履歴に追記して返す。DI失敗時は502を返し、失敗した実行もerror_info付きで記録する。

`GET /api/v1/documents/{document_id}/idp-runs`は、実行履歴の一覧を実行日時の昇順で返す。返すのはサマリ項目（`run_id` / `document_id` / `run_type` / `status` / `executed_at` / `base_run_id` / `corrected_by` / `di_api_version` / `di_model_id` / `error_info`）のみで、項目値・テーブル・領域・パターン一致は含めない。

`GET /api/v1/documents/{document_id}/idp-runs/latest`は、最新の成功実行を詳細で返す。最新とは、`executed_at`の降順に並べ、同時刻は`id`の降順とした先頭である。任意のクエリ`run_type=initial|rerun|corrected`で区分を絞れる。該当が無ければ404 `idp-run-not-found`。

`GET /api/v1/documents/{document_id}/idp-runs/{run_id}`は、実行結果の詳細を返す。詳細は項目値・確信度・テーブル・パターン一致を含む。ラベルと領域は`verbose=true`のときだけ含む。他文書のrun_idや存在しないrun_idは404 `idp-run-not-found`。

`GET /api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response`は、生応答を`application/json`で無変換のまま返す。他文書のrun_idや存在しないrun_idは404 `idp-run-not-found`、失敗した実行は404 `raw-response-not-found`。

`POST /api/v1/documents/{document_id}/idp-runs/{run_id}/corrections`は、`run_id`をbaseとして人手修正を`corrected`行で追記し、201で詳細を返す。baseが失敗した実行なら409 `idp-run-not-correctable`、baseに無いキーやセル座標は422 `unknown-correction-target`。他文書のrun_idや存在しないrun_idは404 `idp-run-not-found`。
