# 認証・認可

## 役割

誰が何を使って本システムに認証されるかを定める。認証はIdP（Keycloak）が発行するJWTの検証に一本化し、本システムはログイン画面・資格情報・セッションを持たない。

認可のうちテナント分離は、JWTのクレームで行う。ロール・文書単位のアクセス制御は未実装で、認証済みなら全操作ができる。閲覧者は認証せず、閲覧URLの不透明トークンだけで文書に到達する。

## 構成

```mermaid
flowchart LR
    spa["Viewer SPA"]
    integ["外部連携システム"]
    viewer(["閲覧者"])
    kc["Keycloak realm factone"]
    api["API"]

    spa -- "Authorization Code + PKCE（client: factone-viewer）" --> kc
    integ -- "client credentials（client: factone-integration）" --> kc
    spa -- "Bearer JWT" --> api
    integ -- "Bearer JWT" --> api
    viewer -- "/view/{token}（無認証）" --> api
    api -- "JWKS 取得" --> kc
```

APIはJWTの発行元クライアントを区別しない。issuer・audience・有効期限・署名が正しければ、SPA用でもM2M用でも同じ操作ができる。

SPA側の画面には「ログイン」ボタンだけがあり、資格情報はKeycloakのログイン画面で入力する。SPAはリダイレクトで往復するだけ。

## 主要処理の流れ

### テナント利用者（SPA）のログイン

1. 未認証のSPAは、「ログイン」で`oidc-client-ts`の`signinRedirect`を呼ぶ。scopeは`openid`、`redirect_uri`は`{origin}/callback`。ログイン前のURL（`?document_id=`を含む）をstateに入れる。
2. Keycloakでログインした後、`/callback`に戻る。SPAは`signinCallback`でトークンを受け取り、stateのURLへ復元する。オープンリダイレクトを防ぐため、復元先は同一オリジンの相対パス（`/`始まりかつ`//`始まりでない）に限る。
3. アクセストークンはメモリだけに保持し、localStorage等には書かない（[ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md)）。コールバックの後、Mediatorはトークンの取得元を`api/client.ts`の`setTokenSource`に渡す。取得元は`auth/oidc.ts`の`accessToken`である。`api/client.ts`はトークンを持たず、API呼出のたびに取得元からトークンを得て`Authorization: Bearer`に付ける。
4. ログアウトでは、Mediatorがトークンの取得元（`setTokenSource(null)`）とユーザー名を消し、`login`状態へ遷移する。続けて`auth/oidc.ts`の`signoutRedirect`を呼ぶ。戻り先は自オリジン。

### アクセストークンの更新（SPA）

アクセストークンの寿命は、Keycloakの設定で決まる（値は後述の「外部依存・設定」）。SPAはトークン応答の`expires_in`から期限を求め、APIはトークンの`exp`で期限切れを判定する。SPAは、期限の60秒前にrefresh tokenでアクセストークンを更新する。この60秒は、SPAの`auth/oidc.ts`で定める値である。期限前の通知は`oidc-client-ts`の`addAccessTokenExpiring`で受ける。

API呼出のたびに、`accessToken`はトークンの残り時間を確かめる。残りが60秒以下なら、更新してから新しいトークンを返す。スリープから復帰した直後のように、期限切れのトークンが残っている場合も同じである。期限前の更新とAPI呼出時の更新が重なっても、Keycloakへの更新要求は1本にまとめる。ライブラリの自動更新（`automaticSilentRenew`）は使わない。自動更新を使うと、API呼出時の更新とは別に要求を出すためである。

更新に失敗したときは、保持しているトークンを返す。期限内なら要求は通り、期限切れならAPIが401を返す。期限前の通知は失敗の後にもう一度来るとは限らないため、次のAPI呼出で更新し直す。

タブを開いている間は期限前の更新が続くため、KeycloakのSSOセッションはアイドル時間では切れず、最大寿命まで続く。アイドル時間は、Keycloakへの最後のトークンの更新から数える。APIはKeycloakに問い合わせないので、APIへの要求では数え直さない。PCのスリープ中はタイマーが止まって更新も止まるため、最後の更新からアイドル時間が過ぎるとSSOセッションは切れる。アイドル時間と最大寿命は、どちらもKeycloakの設定で決まる。SSOセッションが切れた後は更新に失敗し、APIは401を返す。このとき画面は操作ごとの失敗を表示する。再読込してログインし直すまで、APIを呼ぶ操作は失敗し続ける。

### 外部連携システム（M2M）

`factone-integration`のclient credentials grantで、Keycloakのトークンエンドポイントからアクセストークンを得る。そのトークンをBearerに付けてAPIを呼ぶ。クライアントシークレットはrealm定義に含めず、起動後に投入する（後述）。

### JWT検証（API、`core/auth.py`）

1. `Authorization: Bearer`が無ければ401 `unauthenticated`。
2. `KeySource.get_verification_key(token)`で検証鍵を得る。`create_app`に指定が無ければ`JwksKeySource`を使い、Keycloakの`{issuer}/protocol/openid-connect/certs`から取る。鍵は`PyJWKClient`がキャッシュする。テストでは`StaticKeySource`を引数で注入する。
3. `jwt.decode`で検証する。アルゴリズムはRS256のみ。`iss`が`FACTONE_OIDC_ISSUER`に、`aud`が`FACTONE_OIDC_AUDIENCE`（既定`factone-api`）に一致することを確かめる。必須クレームは`exp` / `iss` / `aud` / `sub`。失敗は401 `invalid-token`。
4. `AuthenticatedUser(sub, username, tenant_id)`を返す。`username`は`preferred_username`で、無ければ空文字。人手修正の`corrected_by`には`username`を記録し、空なら`sub`を記録する。

audienceは、realmの両クライアントに付けたaudienceマッパー（`factone-api-audience`）がアクセストークンに入れる。

### テナント解決

テナントは、アクセストークンのクレーム`tenant_id`で解決する。単一realmとクレームを組み合わせた方式である（[ADR-0020](../adr/0020-single-realm-tenant-claim.md)）。`core/auth.py`はJWT検証後に`tenant_id`を取り、`AuthenticatedUser.tenant_id`に載せる。

`tenant_id`が欠落している場合、文字列でない場合、形式`^[a-z0-9][a-z0-9-]{0,62}$`に合わない場合は、403 `tenant-unresolved`を返す。署名・iss・audは正当なので、401にはしない。全APIは文書・文書種別設定・閲覧URL・実行ログをこの値で絞り、不一致は404にして存在を秘匿する。

SPA利用者の場合は、ユーザー属性`tenant_id`を、`factone-viewer`のuser-attributeマッパー`tenant-id`がクレームに載せる。この属性はrealmのユーザープロファイルで宣言し、編集できるのは管理者だけ。1ユーザーは1テナントにだけ所属する。

外部連携システムの場合は、テナントごとのconfidentialクライアント`factone-integration-<tenant_id>`が持つhardcoded claimマッパー`tenant-id`が載せる。realm定義に含まれるのは`default`テナントの`factone-integration`だけで、他は`scripts/tenant.sh`で作る（[develop-guide/tenant.md](../develop-guide/tenant.md)）。

閲覧者はテナントを持たない。閲覧URLのトークンから文書を引き、その文書がテナントを持つ。

### 閲覧者

閲覧者は認証しない。閲覧URLの不透明トークン（256 bitの乱数）が唯一の鍵で、APIはハッシュ一致・未失効・期限内を確認する（[ADR-0011](../adr/0011-view-url-opaque-token.md)、[view-url.md](view-url.md)）。

## 外部依存・設定

Keycloakのrealmは`factone`で、`keycloak/realm/factone.json`が正。管理コンソールでの変更はJSONに反映されず、realmを再作成すると失われる。運用ルールは[keycloak/README.md](../../keycloak/README.md)にある。

realm設定は、`sslRequired: external`、セルフ登録無効、メールでのログイン可、総当り防御有効。ユーザープロファイルには属性`tenant_id`を置き、形式は`^[a-z0-9][a-z0-9-]{0,62}$`、編集は管理者のみとする。

`factone-viewer`はpublicクライアントで、standard flow（認可コード）を使う。PKCE S256は必須で、direct access grantは無効。redirect URI（`http://localhost:5173/*`）・web origin（`http://localhost:5173`）・ログアウト後の戻り先は、realm定義ではローカルの値だけを持つ。AzureのURLはデプロイ後に`kcadm`で追加するため、稼働中のrealmはJSONと完全には一致しない。マッパー`tenant-id`は、ユーザー属性をaccess tokenのクレーム`tenant_id`に載せる。

トークンとセッションの寿命はrealm定義で指定せず、Keycloakの既定値を使う。アクセストークンは300秒、SSOセッションはアイドル30分・最大10時間である。refresh tokenの期限は、SSOセッションの期限と同じである。SPAは期限の60秒前に更新するため、アクセストークンの寿命は60秒より長くする必要がある。60秒以下にすると、更新の1秒後には次の期限前の通知が来て、更新が止まらなくなる。Keycloakは更新のたびに新しいrefresh tokenを返す。ただし、使用済みのrefresh tokenを失効させる設定（Revoke Refresh Token）は有効にしていない。

`factone-integration`はconfidentialクライアントで、service accounts（client credentials）だけを使う。シークレットはrealm定義に含めない。マッパー`tenant-id`は、hardcodedで`tenant_id=default`を載せる。

両クライアントには、audienceマッパー`factone-api-audience`を付ける。realmロールは無い。テストユーザーは`testuser`で、属性は`tenant_id=default`。パスワードは定義に含めない。

realmのインポートは環境変数を置換しない。そのため、`testuser`のパスワードと`factone-integration`のシークレットは、起動後に`kcadm`で設定する。ローカルでは`scripts/local-stack/apply-keycloak-secrets.sh`を使う。このスクリプトは`.env`の`KC_BOOTSTRAP_ADMIN_USERNAME` / `KC_BOOTSTRAP_ADMIN_PASSWORD`で管理者としてログインし、`KC_TEST_USER_PASSWORD` / `KC_INTEGRATION_CLIENT_SECRET`を投入する。Azureでは[develop-guide/deploy.md](../develop-guide/deploy.md)の手順で設定する。

APIとViewerの設定は次のとおり。Viewerの設定はビルド時に渡す。

| 対象 | 設定 | 既定値 |
| --- | --- | --- |
| API | `FACTONE_OIDC_ISSUER` | `http://localhost:8080/realms/factone` |
| API | `FACTONE_OIDC_AUDIENCE` | `factone-api` |
| Viewer | `VITE_OIDC_AUTHORITY` | `http://localhost:8080/realms/factone` |
| Viewer | `VITE_OIDC_CLIENT_ID` | `factone-viewer` |

ローカルでは、Vite devサーバのプロキシ（`/api`と`/view/{token}/pages|pdf`）でAPI呼出を同一オリジンにする。AzureではAPIがSPAを同梱配信するため、同一オリジンになる。

## 関連ドキュメント

| 参照先 | 内容 |
| --- | --- |
| [develop-guide/auth.md](../develop-guide/auth.md) | ローカルでの動作確認・M2Mのトークン取得例 |
| [keycloak/README.md](../../keycloak/README.md) | realm運用ルール |
| [ADR-0006](../adr/0006-keycloak-as-idp.md) | Keycloak採用 |
| [ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md) | SPAのOIDC + PKCE |
| [ADR-0010](../adr/0010-blob-access-full-api-proxy.md) | BlobのAPIプロキシ |
| [ADR-0011](../adr/0011-view-url-opaque-token.md) | 不透明トークン |
| [azure/README.md](../azure/README.md) | Keycloak Container App、Managed ID |
