# 文書表示（ページ画像+SVGオーバーレイ）

文書ID指定でのPDF表示の実現方式。決定済みの「ページ画像+SVGオーバーレイ方式」の実装仕様を記載する。

## 構成

- PDFの各ページをAPI側でPNGに変換（pypdfium2・150dpi・オンデマンド変換）し、APIプロキシ配信する
- Viewerは `<svg>` の `image` 要素としてページ画像を表示し、読取矩形を同一SVG内の `rect` で重畳する
- Blobは全面非公開のため、画像・原本PDFともAPI経由でfetchし、blob URLで表示・DLする
- ページ画像は表示領域に入った時のみ取得する（遅延読込）。閲覧URL経由ではこの取得がページ単位の閲覧イベント（`page_view`）の記録契機になる（[ADR-0015](../adr/0015-page-view-event.md)）。View（`PageSvg`）は可視化を `pageVisible` で Mediator へ伝え、Mediator が取得して blob URL を `vm.canvas.images` に入れる（文書切替で一括 revoke）

## 座標系整合

Document Intelligenceのpolygon座標（ページ単位・インチ）とSVGを無変換で整合させる。

- `GET /api/v1/documents/{id}/pages` がページ寸法を**インチ単位**で返す（ポイント値÷72）
- SVGの `viewBox` を `0 0 {幅インチ} {高さインチ}` に設定
- これによりDIのpolygon座標をそのまま `rect` の座標に使える（変換ロジック不要）
- PNGの描画解像度（150dpi）はviewBoxと独立しており、表示品質のみに影響する
- 読取矩形は DI の `polygon`（x, y の交互配列）の外接矩形（`viewer/src/utils/runs.ts` の `polygonToRect`）。結合セルは `row_span` / `column_span` を応答に持つが描画は起点セルのみ（span による矩形拡張は未対応）

## キャンバスのズーム

ズーム値はスクローラ内寸幅に対するページ幅の比（%、100 = 幅合わせ）。`PageSvg` の `viewBox` は不変で、ページ枠の CSS `width` だけを変える。

- モード: `width`（幅に合わせる）/ `height`（高さに合わせる）/ `page`（ページ全体を表示）/ `custom`（手動）。初期表示は `page`
- `height` はスクローラの可視高さ（上下 padding 24px×2・ページ枠の下マージン 24px・枠線 1px×2 を除く）に 1 ページの高さが収まる倍率。`page` は `min(100, height の倍率)`。計算は `viewer/src/utils/zoom.ts` の `fitZoom`
- ± は 25 の倍数へスナップし（例: フィット値 85% から拡大 → 100%、縮小 → 75%）、25〜200% に制限する。フィット計算値は制限しない（最小 1）。± 操作で `custom` になりフィットの選択が外れる
- スクローラの `ResizeObserver`（border-box 観測・実寸不変なら無視）で、`custom` 以外はコンテナサイズ変化（右ペイン幅・ウィンドウ）時に再計算する。フィットはアニメーションせず即時反映する
- 複数ページ文書は 1 ページ目の寸法で計算し、全ページ同一倍率で描画する
- 公開閲覧（`/view/{token}`）も同じ `DocumentCanvas`（`vm.canvas`。token / 文書 ID の区別は Mediator が持ちキャンバスは知らない）を使い、ページ送り（複数ページ文書のみ）・ズーム・フィット・ダウンロードを提供する。読取矩形は描画しない
- ツールバーのページ送り（前へ・ページ数・次へ）は複数ページ文書のときだけ表示する。フィット 3 ボタンは `v-btn-toggle` 内で幅を確保するため `icon` 指定をしない（`icon` だと左右余白が付かず幅 20px に潰れる）
- 計測不能（サイズ 0）のときは 100（幅合わせ）に倒す
- スクローラは `scrollbar-gutter: stable` で縦スクロールバーの有無に関わらず内寸幅を一定にする（フィット前後で測定値が変わらず、押下のたびに倍率がずれない）

## 読取矩形のオーバーレイと相互ハイライト

キャンバス上の読取領域と右ペインの入力欄を相互に連動させる（右ペイン側は [result-panel.md](result-panel.md) を参照）。矩形の元データ（`region` / `polygon`）は `verbose=true` の応答にだけ含まれる。

- 矩形の生成元は選択中の成功実行（Mediator のモデル `selectedRun` が `vm.canvas.run` として `DocumentCanvas` へ渡る）。失敗実行・未選択は矩形なし
- セル = `tables[].cells[]` の `polygon` あり全件（ID `cell:{table}:{row}:{col}`、実線）。キー項目 = `fields[key].region` あり・設定で `visible=true`・`fields[key].value` が非 null のもの（ID `field:{key}`、破線）。`page_number` ごとに該当ページの `PageSvg` へ渡し、セルを先・キー項目を後に描画する（重なり時にキー項目が前面）。生成は `viewer/src/utils/runs.ts` の `overlayRectsByPage`
- `PageSvg` は矩形に `data-rect-id` を付け、`activeId` と一致する矩形とキーボードフォーカス中（`:focus-visible`）の矩形を primary 32% の塗り + `primary-darken-1` の太枠で強調する。ホバーで塗りを強める。ブラウザ既定のフォーカスリングは viewBox の拡大で巨大化するため `outline: none` で常に消す。semantic color（warning 等）は使わない
- 矩形は `<title>` でツールチップ兼アクセシブル名を持つ（キー項目 = `fields[key].label`、無ければキー。セル = 「表 n の r 行 c 列」、1 始まり。`OverlayRect.label`）。`tabindex="0"` + `role="button"` で Tab 到達でき、Enter / Space でクリックと同じ選択を行う
- 状態は Mediator のモデル（`activeId` と、ペイン→キャンバスの「矩形を表示範囲へ」要求 `vm.canvas.scrollRequest`・キャンバス→ペインの「入力欄をフォーカス」要求 `vm.editor.focusRequest`。連番付きで同一 ID の再要求を検知）
- ペイン → キャンバス: 入力欄フォーカスで `targetFocus` を bubble し、Mediator が `activeId` を設定して、該当矩形を `scrollIntoView({block: 'center'})` で表示範囲へ。`behavior` はページ移動と同様 `prefers-reduced-motion: reduce` のとき `auto`、それ以外 `smooth`（`viewer/src/utils/motion.ts` の `scrollBehavior`）
- キャンバス → ペイン: 矩形クリックで `rectClick` を bubble し、Mediator が `activeId` を設定して、読取結果タブへ切り替えて該当入力欄をフォーカスする
- 選択はフォーカスが外れても維持し、履歴選択・IDP実行・確定で解除する

## 文書ID未指定時の開始画面

起動パラメータ `document_id` が無い場合は開始ダイアログ（`StartDialog`）を表示し、2つのタブのいずれかで表示対象を決める。初期表示は「文書を登録」タブ。両タブは同じ高さに揃え、切替でダイアログの高さが変わらないようにする。

- 文書を登録（定型外フロー向け）: 書類種別（`GET /api/v1/config/document-types` の `display_name` から選択）・文書ID・PDFを入力し `POST /api/v1/documents` へ送信する。PDFはドロップゾーン（Vuetify `v-file-upload`）へのドラッグ＆ドロップ、またはゾーンのクリックで開くOSのファイル選択で指定する。ドラッグ＆ドロップは `accept` 属性が効かないため `filter-by-type` でPDF以外を拒否する。選択後はゾーン内にファイル名・サイズを表示し、変更・解除できる。3項目が揃うまで登録ボタンは無効。成功（201／同一内容の再送200）時はその文書IDを表示対象にする。409（別内容で登録済み）・415・422はエラー表示し再入力可
- 文書IDで参照: 文書IDを入力して表示する。タブ切替時に入力欄へフォーカスし、未入力の間は参照ボタンを無効にする

## 画面レイアウト（認証後・公開閲覧）

- アプリバー（`AppHeader`）は左からロゴ・縦の区切り線・文書タイトルを並べ、右端にユーザーメニューを置く。文書タイトルは種別チップ + 原本ファイル名（16px / ウェイト 500）+ 文書 ID（小・等幅）のテキストボタンで、クリックすると文書 ID の再入力メニューを開く。原本ファイル名が無い文書（ファイル名なしの登録・列追加前の行）と読込中は文書 ID を主表示にする。長いファイル名は省略記号で切り、全文を `title` 属性に入れる。文書タイトルは `v-app-bar` の `prepend` スロット内に置く（既定スロットだと `prepend` / `append` の auto margin に挟まれて中央に浮く）。ロゴの左余白は 16px（フッターの左余白と揃える）
- 右ペイン（作業パネル）の幅は 528px。幅 960px 未満は縦積み（作業パネルが上・キャンバスが下）
- 2 ペインの高さは `calc(100dvh - var(--v-layout-top) - var(--v-layout-bottom))`、行は `grid-template-rows: minmax(0, 1fr)` で固定する（auto 行だとコンテンツで行が伸び、ペイン内スクロールが効かずフィット計算も反復する）。`--v-layout-top` / `--v-layout-bottom` は Vuetify が `v-main` に設定する（子孫から継承で参照できる。`v-main` の外では 0px にフォールバックする）app-bar（`comfortable` 密度 56px）とフッター（32px）の占有高さで、ペイン内スクロールにする
- 公開閲覧（`/view/{token}`）はロゴだけのアプリバー（`AppHeader`。未認証のためユーザーメニューなし）+ キャンバス全幅（右ペインなし）。高さ計算は 2 ペインと同じ。取得中はページスケルトン、無効 URL / ダウンロード失敗は認証後と同じエラー state（再試行なし）
- フッター（`v-footer app`、32px）は `Root.vue` に置き、ログイン前・認証後・公開閲覧（`/view/{token}`）の全状態で表示する。左に「FactONE Viewer」、右にプレースホルダリンク「プライバシーポリシー」「お問い合わせ」「ライセンス」（`href="#"`。文言・遷移先は後続で確定）

## エンドポイント

| パス | 内容 |
| --- | --- |
| `POST /api/v1/documents` | 文書登録（multipart: `document_id`・`document_type`・`file`）。Power Automateと画面登録で共用 |
| `GET /api/v1/documents/{document_id}` | 文書メタデータ |
| `GET /api/v1/documents/{document_id}/pages` | ページ数+各ページ寸法（インチ） |
| `GET /api/v1/documents/{document_id}/pages/{page}/image` | ページPNG（pageは1始まり） |
| `GET /api/v1/documents/{document_id}/pdf` | 原本PDF（DL用） |

- すべてJWT必須。存在しない文書ID・テナント不一致は404（存在を秘匿）
- 破損PDFは500+`Failed to process PDF`
- URLに拡張子を含めない（形式はContent-Typeが正。将来の形式変更・追加はヘッダ/クエリで対応）

## 実装ノート

- 変換タイミングはオンデマンド開始（決定済み）。性能問題が顕在化したら取込時の事前変換へ移行
