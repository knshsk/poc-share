import { flushPromises } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
  setAccessToken: vi.fn(),
}))

import { createMediator, type Mediator } from '../src/mediator/machine'
import { documentResponse, fakeOidc, routeGet } from './fixtures'

// 認証済みの開始画面（start）から始める
function atStart(): Mediator {
  const m = createMediator(fakeOidc())
  m.state.value = 'start'
  return m
}

async function opened(documentType = 'quotation'): Promise<Mediator> {
  getMock.mockImplementation(routeGet([], documentType))
  const m = atStart()
  m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
  await flushPromises()
  return m
}

const pdf = new File(['%PDF-1.4'], 'order.pdf', { type: 'application/pdf' })

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
  getMock.mockImplementation(routeGet())
  URL.createObjectURL = vi.fn().mockReturnValue('blob:mock')
  URL.revokeObjectURL = vi.fn()
})

afterEach(() => {
  // @ts-expect-error jsdom に無いメソッドを仮設したため削除して戻す
  delete URL.createObjectURL
  // @ts-expect-error 同上の理由
  delete URL.revokeObjectURL
})

describe('Mediator（文書）', () => {
  // 文書・ページ・種別設定を並行取得し、種別設定から表示名・shareable・fieldDefs を反映する
  it('openDocument で 3 API を並行取得し ready になる', async () => {
    const m = atStart()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.state.value).toBe('loadingDocument')
    expect(m.vm.value.document?.phase).toBe('loading')
    expect(m.vm.value.header.documentId).toBe('doc-1')
    await flushPromises()

    expect(getMock.mock.calls.map(([p]) => p)).toEqual(
      expect.arrayContaining([
        '/api/v1/documents/{document_id}',
        '/api/v1/documents/{document_id}/pages',
        '/api/v1/config/document-types',
      ]),
    )
    expect(m.state.value).toBe('document')
    const doc = m.vm.value.document!
    expect(doc.phase).toBe('ready')
    expect(doc.canvas).toMatchObject({
      pages: [{ width: 8.5, height: 11 }],
      downloadLabel: '原本DL',
    })
    expect(doc.workPanel?.shareable).toBe(true)
    expect(doc.canvas?.fieldDefs).toEqual([
      { key: 'total_amount', label: '合計金額', type: 'number', visible: true },
      { key: 'own_company', label: '自社名', type: 'string', visible: false },
    ])
    expect(m.vm.value.header.documentTypeLabel).toBe('御見積書')
  })

  // 設定取得失敗・設定に無い種別は表示名なし（種別コード）・shareable=false・全項目表示へ倒す（安全側）
  it('設定が無いときは種別コード表示・shareable=false・fieldDefs 空にフォールバックする', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/config/document-types'
        ? Promise.resolve({ data: undefined, error: { detail: 'x' } })
        : routeGet()(path),
    )
    const a = atStart()
    a.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(a.vm.value.header.documentTypeLabel).toBe('quotation')
    expect(a.vm.value.document?.workPanel?.shareable).toBe(false)
    expect(a.vm.value.document?.canvas?.fieldDefs).toEqual([])

    const b = await opened('unknown_type')
    expect(b.vm.value.header.documentTypeLabel).toBe('unknown_type')
    expect(b.vm.value.document?.workPanel?.shareable).toBe(false)
  })

  // 原本ファイル名はヘッダーの文書タイトルに使う。読込中とファイル名の無い文書は null（View が文書 ID を出す）
  it('原本ファイル名を header.documentName に渡す', async () => {
    const m = atStart()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.vm.value.header.documentName).toBeNull()
    await flushPromises()
    expect(m.vm.value.header.documentName).toBe('見積書 A.pdf')

    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}'
        ? Promise.resolve({
            data: documentResponse('quotation', null),
            error: undefined,
          })
        : routeGet()(path),
    )
    const noName = atStart()
    noName.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(noName.vm.value.header.documentName).toBeNull()
  })

  it('同じ文書 ID を再入力すると再取得する', async () => {
    const m = await opened()
    const docCalls = () =>
      getMock.mock.calls.filter(
        ([p]) => p === '/api/v1/documents/{document_id}',
      ).length
    expect(docCalls()).toBe(1)

    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()

    expect(docCalls()).toBe(2)
    expect(m.state.value).toBe('document')
  })

  it('文書取得失敗はエラー state になり retryLoad で再取得する', async () => {
    getMock.mockImplementation(() =>
      Promise.resolve({ data: undefined, error: { detail: 'x' } }),
    )
    const m = atStart()
    m.dispatch({ type: 'openDocument', documentId: 'doc-x' })
    await flushPromises()

    expect(m.state.value).toBe('documentError')
    expect(m.vm.value.document).toMatchObject({
      phase: 'error',
      error: '文書を取得できませんでした',
    })

    getMock.mockImplementation(routeGet())
    m.dispatch({ type: 'retryLoad' })
    await flushPromises()
    expect(m.state.value).toBe('document')
    expect(m.vm.value.document?.error).toBeNull()
  })

  // 別文書へ切り替えた後に届いた古い応答（documentId 不一致）は捨てる
  it('切替後に届いた古い文書応答は捨てる', async () => {
    let resolveOld: (v: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}') {
        return new Promise((resolve) => {
          resolveOld = resolve
        })
      }
      return routeGet()(path)
    })
    const m = atStart()
    m.dispatch({ type: 'openDocument', documentId: 'doc-old' })
    await flushPromises()
    const resolveFirst = resolveOld

    getMock.mockImplementation(routeGet())
    m.state.value = 'documentError'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(m.state.value).toBe('document')

    resolveFirst({ data: { document_id: 'doc-old' }, error: undefined })
    await flushPromises()
    expect(m.vm.value.header.documentId).toBe('doc-1')
    expect(m.state.value).toBe('document')
  })

  it('文書切替で画像 URL を revoke し images を空にする', async () => {
    const m = await opened()
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.images).toEqual({ 1: 'blob:mock' })

    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()

    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:mock')
    expect(m.vm.value.document?.canvas?.images).toEqual({})
  })

  // 文書切替後に届いた古い画像応答は捨て、blob URL を作らない（リーク防止）
  it('切替後に届いた古い画像応答は blob URL を作らない', async () => {
    let resolveImage: (v: unknown) => void = () => {}
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages/{page}/image'
        ? new Promise((resolve) => {
            resolveImage = resolve
          })
        : routeGet()(path),
    )
    m.dispatch({ type: 'pageVisible', page: 1 })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()

    resolveImage({ data: new Blob(), error: undefined })
    await flushPromises()

    expect(URL.createObjectURL).not.toHaveBeenCalled()
    expect(m.vm.value.document?.canvas?.images).toEqual({})
  })

  it('認証済みの画像取得は /api/v1 系エンドポイントを使う', async () => {
    const m = await opened()
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/pages/{page}/image',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1', page: 1 } },
        parseAs: 'blob',
      }),
    )
  })

  it('原本取得失敗は全画面エラー「原本を取得できませんでした」（再試行あり）', async () => {
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pdf'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet()(path),
    )
    m.dispatch({ type: 'downloadOriginal' })
    await flushPromises()

    expect(m.state.value).toBe('documentError')
    expect(m.vm.value.document?.error).toBe('原本を取得できませんでした')
  })

  // 登録: multipart で POST し、成功したらその文書を開く
  it('register で multipart POST し、成功した文書を開く', async () => {
    postMock.mockResolvedValue({
      data: { document_id: 'doc-9', document_type: 'quotation' },
      error: undefined,
    })
    const m = atStart()
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    expect(m.state.value).toBe('registering')
    expect(m.vm.value.document?.register.submitting).toBe(true)
    await flushPromises()

    const [path, options] = postMock.mock.calls[0]!
    expect(path).toBe('/api/v1/documents')
    const body = options.bodySerializer(options.body) as FormData
    expect(body).toBeInstanceOf(FormData)
    expect(body.get('document_id')).toBe('doc-9')
    expect(body.get('document_type')).toBe('quotation')
    expect(body.get('file')).toBe(pdf)
    expect(m.vm.value.header.documentId).toBe('doc-9')
    expect(m.state.value).toBe('document')
  })

  it('register の 409 は専用文言、他は Problem Details の detail、例外は既定文言', async () => {
    const cases: [unknown, string][] = [
      [{ status: 409, detail: 'x' }, '文書IDは別の内容で登録済みです'],
      [
        { status: 422, detail: 'Unknown document type for this tenant' },
        'Unknown document type for this tenant',
      ],
      [{ status: 500 }, '登録に失敗しました'],
    ]
    for (const [error, message] of cases) {
      postMock.mockResolvedValue({ data: undefined, error })
      const m = atStart()
      m.dispatch({
        type: 'register',
        documentId: 'doc-9',
        documentType: 'quotation',
        file: pdf,
      })
      await flushPromises()
      expect(m.state.value).toBe('start')
      expect(m.vm.value.document?.register.error).toBe(message)
    }

    postMock.mockRejectedValue(new Error('network'))
    const m = atStart()
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    await flushPromises()
    expect(m.vm.value.document?.register.error).toBe('登録に失敗しました')
  })

  it('documentTypesLoaded は登録フォームの種別一覧になる', () => {
    const m = atStart()
    m.dispatch({
      type: 'documentTypesLoaded',
      items: [
        {
          type_code: 'quotation',
          display_name: '御見積書',
          shareable: true,
          fields: [],
          patterns: [],
          created_at: '',
          updated_at: '',
        },
      ],
    })
    expect(m.vm.value.document?.register.typeItems).toHaveLength(1)
  })

  // 裁定: 取得中は openDocument / register を受けない
  it('loadingDocument 中は openDocument と register を無視する', async () => {
    const m = atStart()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    expect(m.vm.value.header.documentId).toBe('doc-1')
    expect(postMock).not.toHaveBeenCalled()
    await flushPromises()
    expect(m.state.value).toBe('document')
  })
})
