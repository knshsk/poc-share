# Viewer

## 役割

Vue 3 + Vuetify の SPA。テナント利用者向けに文書の表示・登録・IDP 実行・読取結果の確認と修正・閲覧 URL の管理を行う認証ありの画面と、閲覧者向けに文書を表示・ダウンロードする無認証の画面の 2 つを持つ。ビルド成果物は API コンテナに同梱され、API が配信する。

## 構成

```mermaid
flowchart TB
    root["Root.vue（Mediator を保持。bubble の終点）"]
    root --> header["AppHeader（文書 ID・切替入力・ユーザーメニュー）"]
    root -- "screen=login" --> login["LoginView"]
    root -- "screen=public" --> pub["PublicView"]
    root -- "screen=document" --> docv["DocumentView"]

    pub --> canvas2["DocumentCanvas（ナビ・ズーム・ダウンロード。矩形なし）"]
    canvas2 --> pagesvg2["PageSvg × ページ"]

    subgraph docview["DocumentView（phase で切替）"]
        start["StartDialog（start / registering）"]
        reg["DocumentRegisterForm"]
        canvas["DocumentCanvas（ready）"]
        pagesvg["PageSvg × ページ（画像 + 読取矩形）"]
        work["WorkPanel（ready）"]
        editor["ResultEditor（読取結果タブ）"]
        history["実行履歴タブ"]
        urls["ViewUrlPanel（閲覧 URL タブ）"]
        start --> reg
        canvas --> pagesvg
        work --> editor
        work --> history
        work --> urls
    end

    subgraph mediator["mediator/（ステートマシン）"]
        machine["machine.ts（state・遷移表・dispatch）"]
        model["model.ts（Model・draft 純関数）"]
        vm["vm.ts（ViewModel のスライス）"]
        handlers["handlers/ auth・public・document・runs・viewUrls"]
    end
    root -- "vm を prop で下へ" --> docview
    docview -. "bubble(event) で上へ" .-> root
    root -- "dispatch" --> machine
    machine --> handlers
    handlers --> model
    model --> vm
    handlers --> client["api/client.ts（openapi-fetch、Bearer 付与）"]
    handlers --> oidc["auth/oidc.ts（oidc-client-ts ラッパ）"]
```

- ルーティングライブラリは使わない。`Root.vue` がマウント時に `init`（`pathname` / `search`）を Mediator へ dispatch し、Mediator が `/view/{token}`（公開閲覧。トークンが空ならログイン画面）・`/callback`（OIDC コールバック）・その他（ログイン画面）に分岐する。コールバック後は復元された URL の `?document_id=` があればその文書を開く
- Passive View: 各コンポーネントは自分用の ViewModel 型 1 つを `vm` prop で受け（`Root → DocumentView → WorkPanel → ResultEditor` のように親が部分を渡す）、操作は `useBubble()` の `bubble(event)` で上へ伝える。描画だけに関わる状態（ズーム・スクロール位置・区分の開閉・送信前のフォーム入力値）は View が持ち、API 呼出・blob URL・clipboard・`history`・`window` イベントは持たない
- Chain of Responsibility: `useBubble(handle?)` は `provide/inject` で直近祖先の `bubble` を受け取り、自ノードで処理しなければ親へ委譲する。`Root` が Mediator の `dispatch` を鎖の終点として provide する。Vue のコンポーネント親子で解決するため、`v-dialog` 等の Teleport 越しでも鎖は切れない
- Mediator（`mediator/`）: 12 状態（`booting / login / callback / public / start / registering / loadingDocument / documentError / document / executing / saving / confirmDiscard`）のステートマシン。遷移表はイベント型を主キーに `{ in: State[], run }` を持ち、`in` に現状態が無いイベントは黙って捨てる（裁定）。API 応答と OIDC 完了は内部完了イベント（`documentLoaded` / `runCreated` 等）として自分へ dispatch し（確認ダイアログ中の `confirmDiscard` でも完了イベントは受ける = `SETTLING`）、`documentId` / `token` / `runId` のスコープ不一致で古い応答を捨てる。モデル（`model.ts`）は reactive で、`vm.ts` がスライスごとの `computed` で ViewModel を組む
- `handlers/`: `auth.ts`（起動・ログイン・コールバック・ログアウト）、`public.ts`（公開閲覧のページ取得と、認証済みと共用のページ画像・原本 DL）、`document.ts`（文書の取得・登録・切替）、`runs.ts`（実行履歴・IDP 実行・下書き・確定・未保存ガード・相互ハイライト）、`viewUrls.ts`（閲覧 URL）
- `utils/`: `runs.ts`（実行結果の型付け、読取矩形 `overlayRectsByPage`、ハイライト ID、`cellKey` / `originalValue` / `cellAt`）、`zoom.ts`（フィット倍率）、`normalize.ts`（正規化ヒント）、`download.ts`（`Content-Disposition` からのファイル名）、`format.ts`、`motion.ts`（reduced-motion 対応）
- API 型は OpenAPI から生成した `api/schema.d.ts` が単一情報源。`npm run generate:api` で再生成し、ドリフトは pre-commit で検出する。`api/client.ts` が同一オリジン前提で Bearer を付ける（トークンは Mediator が `setAccessToken` で渡す。メモリ保持）
- ビルド成果物は `api/Containerfile` のマルチステージで API イメージの `static/` に同梱する。OIDC の authority とクライアント ID はビルド時に焼き込む。ローカルは Vite dev サーバ + プロキシ（`/api` と `/view/{token}/pages|pdf` を 8000 番へ）

## 主要処理の流れ

### 文書表示

1. 文書 ID の入力口は 2 つ。文書未指定時は開始ダイアログ `StartDialog`（文書を登録 / 文書IDで参照のタブ）、表示中は `AppHeader` の切替入力。いずれも `openDocument{documentId}` を bubble する
2. Mediator は `document` 状態で未保存の変更があれば `confirmDiscard` に遷移して確認を挟み、それ以外は `loadingDocument` に遷移して `GET /api/v1/documents/{id}`、`GET .../pages`、`GET /api/v1/config/document-types` を並行取得する。`documentLoaded` で文書種別設定から表示名・`shareable`・`fieldDefs` をモデルへ反映し `document` 状態へ。設定が取れないときは種別コードを表示名にし、`shareable=false`・全項目表示に倒す。失敗は `documentError`（再試行あり）
3. `DocumentCanvas` がページ寸法（インチ）から `PageSvg` を並べる。各ページは表示領域に入ったときに `pageVisible{page}` を bubble し、Mediator が `GET .../pages/{page}/image` を取得して blob URL を `vm.canvas.images` に入れる（取得済み・取得中は再要求しない。文書切替で一括 revoke）。読取矩形は選択中の成功実行の `fields[key].region` / `tables[].cells[].polygon`（`verbose=true` で取得）から View が外接矩形を描く（`utils/runs.ts`。キー項目は `visible=false` と値なしを除く。テーブルセルは全件）。原本 DL は `downloadOriginal` → `GET .../pdf`。座標系とズームは [viewer/display.md](../viewer/display.md)
4. `document` 状態に入ると `WorkPanel` が現れ、Mediator が `GET .../idp-runs` でサマリ一覧（昇順）を取って反転し降順で保持する。先頭（= API 応答の末尾、最新。失敗実行も含む）を `GET .../idp-runs/{run_id}`（`verbose=true`）で取得して読取結果タブに表示する
5. 新規登録は `DocumentRegisterForm` が `register{documentId, documentType, file}` を bubble し、Mediator が `registering` 状態で `POST /api/v1/documents` を multipart で呼ぶ。登録後はその文書を開く

### IDP 実行と修正の確定

1. [IDP 実行] → `executeIdp`。未保存の変更があれば `confirmDiscard`、無ければ `executing` 状態で `POST .../idp-runs`（`verbose=true`）。`runCreated` で応答をそのまま選択状態にし、履歴の先頭へ追加して `document` へ戻る（再取得しない）。`executing` 中の再実行・履歴選択・文書切替は遷移表に無く無視される。応答受信時に `pendingRunId` を更新し、遅れて届いた古い詳細取得は捨てる
2. `ResultEditor` の入力は `fieldInput{key, value}` / `cellInput{table, row, column, value}` を bubble し、Mediator が元値との差分だけをモデルの draft に記録する（`model.ts` の純関数）。number / date 型は View が正規化ヒントを表示する（サーバと同規則の `utils/normalize.ts`）
3. [確定]（読取結果タブ・成功実行選択中・変更 1 件以上のときだけ表示）→ `confirmCorrections` → `saving` 状態で `POST .../idp-runs/{run_id}/corrections`（`verbose=true`）に差分（`{fields, table_cells}`）を送る。`saved` で応答の `corrected` 行を選択状態にして履歴の先頭へ追加し、下書きをリセットしてスナックバーを出す。[破棄]（`discardDraft`）は下書きのリセットのみ
4. 未保存の変更があるまま履歴選択・IDP 実行・ヘッダからの文書切替をすると `confirmDiscard` 状態になり、保留した操作を持ったまま確認ダイアログを出す（タブ切替は対象外）。`confirmProceed` で下書きを捨てて保留した操作を再 dispatch、`confirmCancel` で操作だけを捨てる。ブラウザ離脱は `Root` が `beforeunload` の標準警告を出す（`vm.dirty`）

読取結果タブはキー項目（Query Fields）・キー項目候補（正規表現の一致値）・グリッド（テーブル領域）の 3 区分で表示する。詳細（各区分の表示・修正済みマーク・アクセシビリティ）は [viewer/result-panel.md](../viewer/result-panel.md)。

### 相互ハイライト

入力欄のフォーカスで `targetFocus{id}` → Mediator が `activeId` とキャンバスへの連番付き要求（`vm.canvas.scrollRequest`）を出し、`DocumentCanvas` が該当矩形を表示範囲へスクロール。矩形のクリック（Enter / Space も）で `rectClick{id}` → Mediator が `activeId` を設定して読取結果タブへ切り替え、ペインへの連番付き要求（`vm.editor.focusRequest`）を出す。`ResultEditor` が該当区分を展開して入力欄へスクロール・フォーカスする。ID は `field:{key}` / `cell:{table}:{row}:{col}`。選択は履歴選択・IDP 実行・確定で解除する。

### 閲覧 URL の管理（`ViewUrlPanel`）

文書種別が `shareable` のときだけタブを出す。タブを開いた `tabChanged{tab: 'urls'}` で（文書ごとに初回だけ）`GET .../view-urls` を取り、一覧（発行日時・期限・状態: 有効 / 期限切れ / 失効。期限判定は View がクライアント時刻で行う）を表示する。発行（`issueViewUrl` → `POST .../view-urls`）の応答 `view_path` に自オリジンを付けて完全 URL を表示し、`copyIssuedUrl` で Mediator がクリップボードへ書く（平文は再表示できない）。発行後は一覧を再取得する。失効は `revokeViewUrl{viewUrlId}` で確認ダイアログを出し、`confirmRevoke` で `POST /api/v1/view-urls/{view_url_id}/revoke`。一括失効は画面から呼ばない。

### 公開閲覧（`PublicView`）

`init` で `/view/{token}` を検出すると `public` 状態になり `GET /view/{token}/pages` でページ寸法を取る。`DocumentCanvas` を全幅（右ペインなし）で表示し、ページナビ・ズーム・フィットは認証済み表示と同じ。`vm.canvas.run` が null のため読取矩形は出ない。`PageSvg` が表示領域に入ったページの `pageVisible` を bubble し、Mediator が `GET /view/{token}/pages/{page}/image` で取得する（遅延読込は変えない。[ADR-0015](../adr/0015-page-view-event.md)）。ツールバーの [ダウンロード]（`vm.canvas.downloadLabel`。認証済み表示は「原本DL」）は `GET /view/{token}/pdf` を blob として受け、`Content-Disposition` のファイル名（無ければ `document.pdf`）で保存する。取得中はページスケルトン。ページ一覧の取得失敗は「この閲覧URLは無効です」、ダウンロード失敗は「ダウンロードできませんでした」を `DocumentView` と同じエラー state（アイコン + メッセージ。再試行なし）で表示し、いずれも本文を消す（[view-url.md](view-url.md)）。

## 外部依存・設定

- ビルド時環境変数: `VITE_OIDC_AUTHORITY`（既定 `http://localhost:8080/realms/factone`）、`VITE_OIDC_CLIENT_ID`（既定 `factone-viewer`）
- API（同一オリジン。ローカルは Vite プロキシ）、Keycloak（OIDC リダイレクト）
- 主要ライブラリ: Vue 3、Vuetify、oidc-client-ts、openapi-fetch、Phosphor Icons、Fontsource（IBM Plex）。テストは Vitest + Vue Test Utils

## 詳細仕様への導線

- [viewer/display.md](../viewer/display.md)（ページ画像 + SVG オーバーレイ、座標系、ズーム、遅延読込）、[viewer/result-panel.md](../viewer/result-panel.md)（右ペイン、修正の下書きと確定、相互ハイライト、アクセシビリティ）
- [viewer/README.md（リポジトリ）](../../viewer/README.md)（ディレクトリ構成と配置指針）、[develop-guide/viewer.md](../develop-guide/viewer.md)（起動・テスト・ビルド）
- [requirements/viewer.md](../requirements/viewer.md)（機能要件 VW-xx）
- [ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)、[ADR-0009](../adr/0009-browser-auth-spa-oidc-pkce.md)、[ADR-0010](../adr/0010-blob-access-full-api-proxy.md)、[ADR-0023](../adr/0023-viewer-root-passive-view-mediator.md)
