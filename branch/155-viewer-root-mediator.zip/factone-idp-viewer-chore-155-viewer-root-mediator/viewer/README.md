# FactONE IDP/Viewer フロントエンド

Vue 3 + Vuetify 製の SPA。ディレクトリ構成は [create-vue](https://github.com/vuejs/create-vue) が生成するタイプベース（種類別）構造に準拠する。

## ディレクトリ構成

```
viewer/
├── src/                   # アプリケーション本体
│   ├── main.ts            # エントリポイント。アプリ生成とプラグイン登録のみ
│   ├── Root.vue           # 階層の頂点。Mediator を保持し、画面（views/）を vm で切り替える
│   ├── api/               # API クライアント
│   │   ├── client.ts      # openapi-fetch クライアント（setAccessToken で渡された Bearer を付与）
│   │   └── schema.d.ts    # OpenAPI から自動生成した型（手動編集禁止）
│   ├── assets/            # グローバル CSS・静的アセット
│   │   └── main.css       # フォント定義・アプリ全体の基本スタイル
│   ├── auth/              # 認証
│   │   └── oidc.ts        # oidc-client-ts のラッパ（login / handleCallback / logout）
│   ├── mediator/          # ステートマシン Mediator（状態・モデル・API 呼出・裁定）
│   │   ├── bubble.ts      # useBubble / BUBBLE（Chain of Responsibility の鎖）
│   │   ├── events.ts      # View 発イベントと内部完了イベントの型
│   │   ├── model.ts       # 状態集合・Model・draft 純関数
│   │   ├── vm.ts          # 各 View の ViewModel 型と buildVm
│   │   ├── machine.ts     # createMediator / 遷移表の合成 / dispatch
│   │   └── handlers/      # イベント別の { in: State[], run }（auth / public / document / runs / viewUrls）
│   ├── components/        # UI 部品（すべて vm prop + useBubble の Passive View）
│   │   ├── AppHeader.vue      # アプリバー（ロゴ・文書コンテキスト・ユーザメニュー）
│   │   ├── DocumentCanvas.vue # ページ表示＋ナビ/ズーム（幅・高さ・全体フィット）＋読取矩形のキャンバス
│   │   ├── DocumentRegisterForm.vue # 文書登録フォーム（定型外フロー向け・開始ダイアログ内）
│   │   ├── PageSvg.vue        # ページ画像 + 読取矩形オーバーレイ（ID・選択中・クリック・可視化通知）
│   │   ├── ResultEditor.vue   # 読取結果タブ本体（キー項目 / キー項目候補 / グリッドの3区分と編集）
│   │   ├── StartDialog.vue    # 文書ID未指定時の開始ダイアログ（文書を登録 / 文書IDで参照）
│   │   ├── ViewUrlPanel.vue   # 閲覧用 URL 発行・管理（WorkPanel のタブ内）
│   │   └── WorkPanel.vue      # 作業パネル（読取結果・実行履歴・閲覧 URL のタブ、修正の確定・破棄）
│   ├── views/             # 画面単位のコンポーネント
│   │   ├── DocumentView.vue   # ドキュメント閲覧画面（認証あり）
│   │   ├── LoginView.vue      # ログイン画面（未認証）
│   │   └── PublicView.vue     # 公開閲覧画面（閲覧トークン）
│   ├── plugins/           # プラグイン設定
│   │   └── vuetify.ts     # Vuetify テーマ（カラートークンの唯一の定義箇所）・アイコン設定
│   └── utils/             # 表示フォーマッタ等の純粋関数
│       ├── download.ts    # Content-Disposition からファイル名決定（原本DL用）
│       ├── format.ts      # 確信度・日時フォーマッタ
│       ├── motion.ts      # prefers-reduced-motion に応じたスクロール挙動
│       ├── normalize.ts   # 正規化ヒント（サーバの _normalize と同規則）
│       ├── runs.ts        # 実行結果 JSON 列の型付け・読取矩形・ハイライト ID・元値取得
│       └── zoom.ts        # キャンバスのフィット倍率計算
├── tests/                 # Vitest テスト（setup.ts が共通セットアップ、fixtures.ts が共通フィクスチャ）
├── public/                # そのまま配信される静的ファイル
├── index.html             # SPA エントリ HTML
├── vite.config.ts         # Vite ビルド設定
├── vitest.config.ts       # Vitest テスト設定
├── eslint.config.ts       # ESLint 設定
├── tsconfig.json          # TypeScript 設定（app / node に分割）
└── package.json           # 依存管理は npm
```

## 各ディレクトリの責務と配置指針

新しいモジュールをどこに置くか・どこを編集するかの判断基準。

### 全体の構造（Passive View + Chain of Responsibility + Mediator）

- すべてのコンポーネントは `Root.vue` を頂点とする 1 本の階層に置く。`Root` が `mediator/` の `createMediator()` を 1 つ持ち、`vm` を各画面へ渡し、`provide(BUBBLE, dispatch)` で操作の鎖の終点になる
- コンポーネントは Passive View。入力は自分用の ViewModel 型（`mediator/vm.ts`）1 つを `vm` prop で受け、子には `vm.canvas` のように部分を渡す。出力は `useBubble()` が返す `bubble(event)` だけで、`defineEmits` は使わない。ストアや inject でモデルを読まない
- コンポーネントが持ってよい状態は描画だけに関わるもの（ズーム・スクロール位置・区分の開閉・送信前のフォーム入力値）。API 呼出・`URL.createObjectURL`・clipboard・`history`・`window` イベントは Mediator / Root だけが行う
- **新しい操作を足すとき**: `mediator/events.ts` にイベント型を追加 → `mediator/handlers/` の該当ファイルに `{ in: 受け付ける状態, run }` を追加（API 呼出は完了イベントを `dispatch` する形で書く）→ 表示に必要な項目を `mediator/vm.ts` に足す → View で `bubble({ type: ... })` を呼ぶ。テストは `tests/mediator-*.test.ts`（dispatch → state / vm）と View のテスト（vm → DOM、DOM → bubble）に書く

### `views/` — 画面

- `Root` が `vm.screen` で切り替える画面単位のコンポーネント。レイアウトと子への vm の分配を担当し、データ取得は持たない
- **新しい画面を追加するとき**: ここに新規ファイルを作成し、`Root.vue` の切り替えと `mediator/vm.ts` の `RootVm.screen` に組み込む

### `components/` — UI 部品

- 画面から切り出した再利用可能な UI 部品。`vm` prop と `useBubble()` だけで動く
- **画面の一部を部品化するとき**: ここに新規ファイルを作成し、`mediator/vm.ts` に部品用の Vm 型を足して親から渡す

### `mediator/` — ステートマシン Mediator

- 状態（`model.ts` の `State`）・モデル・遷移表・API 呼出を置く層。`handlers/` はドメイン別（auth / public / document / runs / viewUrls）に分け、`machine.ts` が 1 つの表に合成する
- **共有状態を追加するとき**: `model.ts` の `Model` に項目を足し、`vm.ts` で表示に必要な形にして渡す。単一コンポーネント内で完結する描画状態はコンポーネントの `ref` で持つ

### `api/` — API クライアント

- バックエンド API との通信を置く層。呼び出すのは `mediator/handlers/` だけ
- `schema.d.ts` は OpenAPI 定義からの自動生成物のため手動編集しない。**API 契約が変わったときは `npm run generate:api` で再生成**し、差分をコミットする（pre-commit の差分チェック対象）

### `auth/` — 認証

- `oidc-client-ts` のラッパ。Mediator の `handlers/auth.ts` だけが使う

### `plugins/` — プラグイン設定

- Vue プラグイン（Vuetify 等）の生成・設定を置く層。`main.ts` から登録する

### `src/` 直下

- `main.ts`: エントリポイント。アプリ生成とプラグイン登録のみを行い、ビジネスロジックは書きません
- `Root.vue`: 階層の頂点。Mediator の保持と画面の切り替えだけを担当し、画面の中身は `views/` に置く

## 起動・テスト

```
npm run dev            # 開発サーバー起動
npm run test           # テスト
npm run build          # 型チェック + ビルド
npm run lint           # lint
npm run generate:api   # OpenAPI エクスポート + TS 型再生成
```
