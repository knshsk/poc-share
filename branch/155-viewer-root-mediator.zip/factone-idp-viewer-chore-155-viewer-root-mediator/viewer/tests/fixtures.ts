import { vi } from 'vitest'

import type {
  CanvasVm,
  EditorVm,
  HeaderVm,
  RegisterVm,
  ViewUrlsVm,
  WorkPanelVm,
} from '../src/mediator/vm'
import type { IdpRun, IdpRunSummary } from '../src/utils/runs'

// ---- IDP 実行結果 ----
export const succeededRun: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-08-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  fields: {
    order_no: { value: 'A-001', normalized_value: 'A-001', confidence: 0.98 },
    total_amount: {
      value: '1,000',
      normalized_value: 1000,
      confidence: 0.75,
      region: { page_number: 2, polygon: [1, 1, 2, 1, 2, 2, 1, 2] },
    },
  },
  tables: [
    {
      row_count: 1,
      column_count: 1,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'c',
          kind: null,
          page_number: 1,
          polygon: [3, 3, 4, 3, 4, 4, 3, 4],
        },
      ],
    },
  ],
  pattern_matches: {},
  corrections: null,
}

export const failedRun: IdpRun = {
  ...succeededRun,
  run_id: '22222222-2222-2222-2222-222222222222',
  run_type: 'rerun',
  status: 'failed',
  executed_at: '2026-08-02T00:00:00Z',
  fields: null,
  tables: null,
  pattern_matches: null,
  error_info: 'DI request failed',
}

export const correctedRun: IdpRun = {
  ...succeededRun,
  run_id: '33333333-3333-3333-3333-333333333333',
  run_type: 'corrected',
  executed_at: '2026-08-03T00:00:00Z',
  base_run_id: succeededRun.run_id,
  corrected_by: 'testuser',
  fields: {
    order_no: { value: 'A-002', normalized_value: 'A-002', confidence: null },
    total_amount: { value: '1,000', normalized_value: 1000, confidence: 0.75 },
  },
  corrections: { fields: { order_no: 'A-002' }, table_cells: [] },
}

// 一覧はサマリ（項目値・テーブルを含まない）
export function toSummary(run: IdpRun): IdpRunSummary {
  return {
    run_id: run.run_id,
    document_id: run.document_id,
    run_type: run.run_type,
    status: run.status,
    executed_at: run.executed_at,
    base_run_id: run.base_run_id,
    corrected_by: run.corrected_by,
    di_api_version: run.di_api_version,
    di_model_id: run.di_model_id,
    error_info: run.error_info,
  }
}

// ---- 文書・設定 ----
export const configs = [
  {
    type_code: 'quotation',
    display_name: '御見積書',
    shareable: true,
    fields: [
      { key: 'total_amount', label: '合計金額', type: 'number', visible: true },
      { key: 'own_company', label: '自社名', type: 'string', visible: false },
    ],
    patterns: [],
    created_at: '2026-08-01T00:00:00Z',
    updated_at: '2026-08-01T00:00:00Z',
  },
  {
    type_code: 'purchase_order',
    display_name: '注文書（案件）',
    shareable: false,
    fields: [],
    patterns: [],
    created_at: '2026-08-01T00:00:00Z',
    updated_at: '2026-08-01T00:00:00Z',
  },
]

export const pages = [{ width: 8.5, height: 11 }]

export function documentResponse(documentType = 'quotation') {
  return {
    document_id: 'doc-1',
    tenant_id: 'tenant-1',
    document_type: documentType,
    content_sha256: 'x'.repeat(64),
    received_at: '2026-08-01T00:00:00Z',
  }
}

// GET のパス別ルータ。Mediator テストは getMock.mockImplementation(routeGet(runs)) で使う
export function routeGet(runs: IdpRun[] = [], documentType = 'quotation') {
  return (
    path: string,
    options?: { params?: { path?: { run_id?: string; page?: number } } },
  ) => {
    const ok = (data: unknown) => Promise.resolve({ data, error: undefined })
    switch (path) {
      case '/api/v1/documents/{document_id}':
        return ok(documentResponse(documentType))
      case '/api/v1/documents/{document_id}/pages':
        return ok({ page_count: pages.length, pages })
      case '/api/v1/config/document-types':
        return ok(configs)
      case '/api/v1/documents/{document_id}/idp-runs':
        return ok({ document_id: 'doc-1', runs: runs.map(toSummary) })
      case '/api/v1/documents/{document_id}/idp-runs/{run_id}': {
        const run = runs.find((r) => r.run_id === options?.params?.path?.run_id)
        return run
          ? ok(run)
          : Promise.resolve({ data: undefined, error: { status: 404 } })
      }
      case '/api/v1/documents/{document_id}/view-urls':
        return ok([])
      case '/view/{token}/pages':
        return ok({ page_count: pages.length, pages })
      case '/view/{token}/pages/{page}/image':
      case '/api/v1/documents/{document_id}/pages/{page}/image':
      case '/view/{token}/pdf':
      case '/api/v1/documents/{document_id}/pdf':
        return Promise.resolve({
          data: new Blob(),
          error: undefined,
          response: { headers: new Headers() },
        })
      default:
        return Promise.resolve({ data: undefined, error: {} })
    }
  }
}

// ---- 認証 ----
export const session = { accessToken: 'token-abc', username: 'testuser' }

export function fakeOidc() {
  return {
    login: vi.fn().mockResolvedValue(undefined),
    handleCallback: vi.fn().mockResolvedValue(session),
    logout: vi.fn().mockResolvedValue(undefined),
  }
}

// ---- View テスト用の vm ビルダ（必要な項目だけ上書きする）----
export function headerVm(over: Partial<HeaderVm> = {}): HeaderVm {
  return {
    documentId: '',
    documentTypeLabel: null,
    authenticated: true,
    username: 'sales01',
    ...over,
  }
}

export function canvasVm(over: Partial<CanvasVm> = {}): CanvasVm {
  return {
    pages: [
      { width: 8.5, height: 11 },
      { width: 8.5, height: 11 },
      { width: 8.5, height: 11 },
    ],
    run: null,
    fieldDefs: [],
    images: {},
    activeId: null,
    scrollRequest: null,
    downloadLabel: '原本DL',
    ...over,
  }
}

export function registerVm(over: Partial<RegisterVm> = {}): RegisterVm {
  return { typeItems: configs, submitting: false, error: null, ...over }
}

export function editorVm(over: Partial<EditorVm> = {}): EditorVm {
  return {
    run: succeededRun,
    fieldDefs: [],
    draftFields: {},
    draftCells: {},
    activeId: null,
    focusRequest: null,
    ...over,
  }
}

export function viewUrlsVm(over: Partial<ViewUrlsVm> = {}): ViewUrlsVm {
  return {
    urls: [],
    issuedUrl: null,
    issuing: false,
    error: null,
    revokeTarget: null,
    ...over,
  }
}

export function workPanelVm(over: Partial<WorkPanelVm> = {}): WorkPanelVm {
  return {
    runs: [],
    selectedRun: null,
    activeTab: 'result',
    executing: false,
    saving: false,
    loadingRuns: false,
    error: null,
    shareable: false,
    draftCount: 0,
    savedSnackbar: false,
    confirmDiscard: false,
    editor: null,
    viewUrls: viewUrlsVm(),
    ...over,
  }
}
