import { mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import ResultEditor from '../src/components/ResultEditor.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { EditorVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import type { IdpRun } from '../src/utils/runs'
import { editorVm } from './fixtures'

const run: IdpRun = {
  run_id: '11111111-1111-1111-1111-111111111111',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: '2024-11-30',
  di_model_id: 'prebuilt-layout',
  error_info: null,
  fields: {
    TotalAmount: {
      value: '1,200,000',
      normalized_value: 1200000,
      confidence: 0.96,
      label: '合計金額',
      region: null,
    },
    DeliveryDate: {
      value: '2026-10-30',
      normalized_value: '2026-10-30',
      confidence: 0.85,
      label: '納品期限',
      region: null,
    },
    Note: {
      value: null,
      normalized_value: null,
      confidence: null,
      region: null,
    },
    Hidden: {
      value: 'secret',
      normalized_value: 'secret',
      confidence: 0.5,
      region: null,
    },
  },
  tables: [
    {
      row_count: 2,
      column_count: 2,
      cells: [
        {
          row_index: 0,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: '品目',
          kind: 'columnHeader',
          page_number: 1,
          polygon: [1, 2, 3, 2],
        },
        {
          row_index: 1,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'P-9001',
          kind: null,
          page_number: 1,
          polygon: [1, 3, 3, 3],
        },
      ],
    },
  ],
  pattern_matches: {
    TCode: { label: '登録番号', regex: 'T\\d{13}', values: ['T1234567890123'] },
    QuotationNo: { label: '見積番号', regex: 'Q-\\d{6}', values: [] },
  },
  corrections: null,
}

const fieldDefs = [
  {
    key: 'TotalAmount',
    label: '合計金額',
    type: 'number' as const,
    visible: true,
  },
  {
    key: 'DeliveryDate',
    label: '納品期限',
    type: 'date' as const,
    visible: true,
  },
  { key: 'Note', label: '備考', type: 'string' as const, visible: true },
  { key: 'Hidden', label: '非表示', type: 'string' as const, visible: false },
]

const bubble = vi.fn()

function vmOf(over: Partial<EditorVm> = {}, runOver: Partial<IdpRun> = {}) {
  return editorVm({ run: { ...run, ...runOver }, fieldDefs, ...over })
}

function mountEditor(
  over: Partial<EditorVm> = {},
  runOver: Partial<IdpRun> = {},
  attachTo?: HTMLElement,
) {
  return mount(ResultEditor, {
    props: { vm: vmOf(over, runOver) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
    attachTo,
  })
}

function fieldInputs(wrapper: ReturnType<typeof mountEditor>) {
  return wrapper.findAll('[data-testid="field-input"] input')
}

function cellInputs(wrapper: ReturnType<typeof mountEditor>) {
  return wrapper.findAll('[data-testid="cell-input"] input')
}

describe('ResultEditor', () => {
  beforeEach(() => {
    bubble.mockClear()
  })

  afterEach(() => {
    // @ts-expect-error jsdom に無いメソッドを差し込んだテストの後始末
    delete Element.prototype.scrollIntoView
    vi.unstubAllGlobals()
  })

  // キー項目は文書種別設定の順・visible=true のみ。ラベルは fields[key].label（無ければキー）、値は正規化値（無ければ fields[key].value）、null は空欄
  it('キー項目を設定の順に描画し、visible=false を除外する', () => {
    const wrapper = mountEditor()
    const rows = wrapper.findAll('[data-testid="field-row"]')
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('合計金額')
    expect(rows[0]!.text()).toContain('96%')
    expect(rows[2]!.text()).toContain('Note')
    expect(wrapper.text()).not.toContain('secret')

    const inputs = fieldInputs(wrapper)
    expect((inputs[0]!.element as HTMLInputElement).value).toBe('1200000')
    expect((inputs[2]!.element as HTMLInputElement).value).toBe('')
    expect(inputs[2]!.attributes('placeholder')).toBe('（値なし）')
    expect(inputs[0]!.attributes('aria-label')).toBe('合計金額')
    expect(wrapper.findAll('[data-testid="confidence-bar"]')).toHaveLength(3)
  })

  // fields は JSONB 由来でキー順が設定順と一致しない。表示は fieldDefs の順に並び、設定に無いキーは末尾に来る
  it('キー項目を文書種別設定の順に描画する（fields のキー順とは無関係）', () => {
    const wrapper = mountEditor(
      {},
      {
        fields: {
          Note: run.fields!.Note!,
          DeliveryDate: run.fields!.DeliveryDate!,
          TotalAmount: run.fields!.TotalAmount!,
          Hidden: run.fields!.Hidden!,
          Extra: { value: 'e', normalized_value: null, confidence: null },
        },
      },
    )
    const rows = wrapper.findAll('[data-testid="field-row"]')
    expect(rows.map((r) => r.text().slice(0, 4))).toEqual([
      '合計金額',
      '納品期限',
      'Note',
      'Extr',
    ])
  })

  // 正規化値と DI の読取値が異なる項目だけ「読取値 …」を補足表示し、入力欄の aria-describedby で紐付ける
  it('正規化値が読取値と異なるとき読取値を補足表示する', () => {
    const wrapper = mountEditor(
      {},
      {
        fields: {
          ...run.fields,
          DeliveryDate: {
            ...run.fields!.DeliveryDate!,
            value: '令和 8年 9月 4日',
            normalized_value: '2026-09-04',
          },
          Note: {
            ...run.fields!.Note!,
            value: '約120万',
            normalized_value: null,
          },
        },
      },
    )
    const inputs = fieldInputs(wrapper)
    expect((inputs[1]!.element as HTMLInputElement).value).toBe('2026-09-04')
    expect((inputs[2]!.element as HTMLInputElement).value).toBe('約120万')
    const raws = wrapper.findAll('[data-testid="raw-value"]')
    expect(raws.map((r) => r.text())).toEqual([
      '読取値 1,200,000',
      '読取値 令和 8年 9月 4日',
    ])
    expect(inputs[0]!.attributes('aria-describedby')).toBe(
      raws[0]!.attributes('id'),
    )
    expect(inputs[2]!.attributes('aria-describedby')).toBeUndefined()
  })

  // 入力は fieldInput / cellInput を bubble するだけ（差分の判定は Mediator）。表示値は vm.draftFields / draftCells を優先する
  it('入力で fieldInput / cellInput を bubble し、下書きの値を表示する', async () => {
    const wrapper = mountEditor()
    await fieldInputs(wrapper)[0]!.setValue('1,250,000')
    expect(bubble).toHaveBeenCalledWith({
      type: 'fieldInput',
      key: 'TotalAmount',
      value: '1,250,000',
    })
    await cellInputs(wrapper)[1]!.setValue('P-9002')
    expect(bubble).toHaveBeenCalledWith({
      type: 'cellInput',
      table: 0,
      row: 1,
      column: 0,
      value: 'P-9002',
    })

    await wrapper.setProps({
      vm: vmOf({
        draftFields: { DeliveryDate: null },
        draftCells: { '0:1:0': 'P-9002' },
      }),
    })
    expect((fieldInputs(wrapper)[1]!.element as HTMLInputElement).value).toBe(
      '',
    )
    expect((cellInputs(wrapper)[1]!.element as HTMLInputElement).value).toBe(
      'P-9002',
    )
  })

  // number / date は入力中に正規化の可否を行内表示する（string・正規化値と同表記は出さない）
  it('正規化ヒントを型別に表示する', async () => {
    const wrapper = mountEditor()
    expect(wrapper.findAll('[data-testid="normalization-hint"]')).toHaveLength(
      0,
    )
    await wrapper.setProps({
      vm: vmOf({
        draftFields: { TotalAmount: '1,250,000', DeliveryDate: '2026/11/1' },
      }),
    })
    expect(wrapper.text()).toContain('正規化値 1250000')
    expect(wrapper.text()).toContain('正規化値 2026-11-01')

    await wrapper.setProps({
      vm: vmOf({
        draftFields: {
          TotalAmount: '約120万',
          DeliveryDate: '来月',
          Note: 'メモ',
        },
      }),
    })
    expect(wrapper.text()).toContain('数値として解釈できません')
    expect(wrapper.text()).toContain('日付として解釈できません')
    expect(wrapper.findAll('[data-testid="normalization-hint"]')).toHaveLength(
      2,
    )
  })

  // 修正済みマークは保存済み corrections と未保存の下書きの両方に付く
  it('保存済み修正と下書きに修正済みマークを付ける', async () => {
    const wrapper = mountEditor(
      {},
      {
        corrections: {
          fields: { DeliveryDate: '2026-11-01' },
          table_cells: [
            {
              table_index: 0,
              row_index: 1,
              column_index: 0,
              content: 'P-9002',
            },
          ],
        },
      },
    )
    expect(wrapper.findAll('[data-testid="corrected-mark"]')).toHaveLength(2)

    await wrapper.setProps({
      vm: vmOf(
        { draftFields: { TotalAmount: '1' } },
        {
          corrections: {
            fields: { DeliveryDate: '2026-11-01' },
            table_cells: [
              {
                table_index: 0,
                row_index: 1,
                column_index: 0,
                content: 'P-9002',
              },
            ],
          },
        },
      ),
    })
    expect(wrapper.findAll('[data-testid="corrected-mark"]')).toHaveLength(3)
  })

  it('修正済みマークに role=img と aria-label を付ける', () => {
    const wrapper = mountEditor(
      {},
      {
        corrections: {
          fields: { DeliveryDate: '2026-11-01' },
          table_cells: [],
        },
      },
    )
    const mark = wrapper.get('[data-testid="corrected-mark"]')
    expect(mark.attributes('role')).toBe('img')
    expect(mark.attributes('aria-label')).toBe('修正')
  })

  // hide-details のため messages スロットが使えず、ヒントは aria-describedby で入力欄に紐付ける
  it('正規化ヒントを aria-describedby で入力欄に紐付ける', () => {
    const wrapper = mountEditor({
      draftFields: { TotalAmount: '1,250,000', DeliveryDate: '2026/11/1' },
    })
    const inputs = fieldInputs(wrapper)
    const hints = wrapper.findAll('[data-testid="normalization-hint"]')
    expect(hints[0]!.attributes('id')).toBeTruthy()
    expect(inputs[0]!.attributes('aria-describedby')).toBe(
      `${wrapper.get('[data-testid="raw-value"]').attributes('id')} ${hints[0]!.attributes('id')}`,
    )
    expect(inputs[1]!.attributes('aria-describedby')).toBe(
      hints[1]!.attributes('id'),
    )
    expect(hints[0]!.attributes('id')).not.toBe(hints[1]!.attributes('id'))
    expect(inputs[2]!.attributes('aria-describedby')).toBeUndefined()
  })

  it('修正入力欄に maxlength=2000 を付ける', () => {
    const wrapper = mountEditor()
    expect(fieldInputs(wrapper)[0]!.attributes('maxlength')).toBe('2000')
    expect(cellInputs(wrapper)[0]!.attributes('maxlength')).toBe('2000')
  })

  // 選択中の入力欄は色以外の手掛かりとして aria-current を持ち、target--active クラスが付く
  it('activeId の入力欄に aria-current と選択中クラスを付ける', async () => {
    const wrapper = mountEditor({ activeId: 'field:DeliveryDate' })
    const inputs = fieldInputs(wrapper)
    expect(inputs[0]!.attributes('aria-current')).toBeUndefined()
    expect(inputs[1]!.attributes('aria-current')).toBe('true')
    expect(
      wrapper.get('[data-target-id="field:DeliveryDate"]').classes(),
    ).toContain('target--active')

    await wrapper.setProps({ vm: vmOf({ activeId: 'cell:0:1:0' }) })
    expect(fieldInputs(wrapper)[1]!.attributes('aria-current')).toBeUndefined()
    expect(cellInputs(wrapper)[1]!.attributes('aria-current')).toBe('true')
    expect(wrapper.get('[data-target-id="cell:0:1:0"]').classes()).toContain(
      'target--active',
    )
  })

  it('キー項目候補をチップで表示し、0件は一致なしと表示する', () => {
    const wrapper = mountEditor()
    const rows = wrapper.findAll('[data-testid="candidate-row"]')
    expect(rows).toHaveLength(2)
    expect(rows[0]!.text()).toContain('登録番号')
    expect(rows[0]!.findAll('[data-testid="candidate-chip"]')).toHaveLength(1)
    expect(rows[0]!.text()).toContain('T1234567890123')
    expect(rows[1]!.text()).toContain('一致なし')
    expect(wrapper.text()).not.toContain('\\d{13}')
    expect(wrapper.find('[data-testid="candidate-row"] input').exists()).toBe(
      false,
    )
  })

  // グリッドは row_count × column_count。セルは編集可、ヘッダは区別、無い座標は空枠
  it('グリッドを描画する', () => {
    const wrapper = mountEditor()
    expect(wrapper.get('[data-testid="section-grid"]').text()).toContain(
      '表 1（2行 × 2列）',
    )
    const cells = wrapper.findAll('[data-testid="grid-cell"]')
    expect(cells).toHaveLength(2)
    expect(wrapper.findAll('[data-testid="grid-cell-empty"]')).toHaveLength(2)
    expect(cells[0]!.classes()).toContain('grid-cell--header')
    expect(cells[1]!.classes()).not.toContain('grid-cell--header')
    const inputs = cellInputs(wrapper)
    expect((inputs[1]!.element as HTMLInputElement).value).toBe('P-9001')
    expect(inputs[1]!.attributes('aria-label')).toBe('2行1列')
  })

  it('テーブルが無いときはテーブル未検出と表示する', () => {
    const wrapper = mountEditor({}, { tables: [] })
    expect(wrapper.get('[data-testid="section-grid"]').text()).toContain(
      'テーブル未検出',
    )
  })

  // 入力欄フォーカスで targetFocus を bubble する（選択の保持は Mediator）
  it('入力欄フォーカスで targetFocus を bubble する', async () => {
    const wrapper = mountEditor()
    await fieldInputs(wrapper)[0]!.trigger('focus')
    expect(bubble).toHaveBeenCalledWith({
      type: 'targetFocus',
      id: 'field:TotalAmount',
    })
    await cellInputs(wrapper)[1]!.trigger('focus')
    expect(bubble).toHaveBeenCalledWith({
      type: 'targetFocus',
      id: 'cell:0:1:0',
    })
  })

  // キャンバス側の要求（focusRequest）で該当入力欄へスクロールしフォーカスする
  it('focusRequest で該当入力欄を scrollIntoView してフォーカスする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, {}, host)
    try {
      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:1:0', seq: 1 } }),
      })
      await wrapper.vm.$nextTick()

      const input = cellInputs(wrapper)[1]!.element
      expect(document.activeElement).toBe(input)
      expect(scrollSpy).toHaveBeenCalledTimes(1)
      expect(scrollSpy.mock.instances[0]).toBe(input)
      expect(scrollSpy).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'smooth' }),
      )
    } finally {
      wrapper.unmount()
      host.remove()
    }
  })

  it('reduced-motion 指定時は behavior auto でスクロールする', async () => {
    const scrollSpy = vi.fn()
    Element.prototype.scrollIntoView = scrollSpy
    vi.stubGlobal('matchMedia', () => ({ matches: true }))
    const wrapper = mountEditor()
    await wrapper.setProps({
      vm: vmOf({ focusRequest: { id: 'field:TotalAmount', seq: 1 } }),
    })
    await wrapper.vm.$nextTick()
    expect(scrollSpy).toHaveBeenCalledWith(
      expect.objectContaining({ behavior: 'auto' }),
    )
  })

  // 折りたたみ中の区分に focusRequest が来たら区分を開いてからフォーカスする
  it('折りたたみ中の区分への focusRequest で区分を開いてフォーカスする', async () => {
    Element.prototype.scrollIntoView = vi.fn()
    const host = document.createElement('div')
    document.body.appendChild(host)
    const wrapper = mountEditor({}, {}, host)
    try {
      await wrapper
        .get('[data-testid="section-grid"] .v-expansion-panel-title')
        .trigger('click')
      await wrapper.vm.$nextTick()

      await wrapper.setProps({
        vm: vmOf({ focusRequest: { id: 'cell:0:1:0', seq: 1 } }),
      })
      await wrapper.vm.$nextTick()

      expect(document.activeElement).toBe(cellInputs(wrapper)[1]!.element)
      expect(wrapper.get('[data-testid="section-grid"]').classes()).toContain(
        'v-expansion-panel--active',
      )
    } finally {
      wrapper.unmount()
      host.remove()
    }
  })
})
