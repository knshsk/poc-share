import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { PublicVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import PublicView from '../src/views/PublicView.vue'
import { canvasVm } from './fixtures'

function mountView(vm: PublicVm) {
  return mount(PublicView, {
    props: { vm },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: vi.fn() },
    },
  })
}

describe('PublicView', () => {
  // ページ取得中はスケルトン、取得後は DocumentCanvas に vm.canvas を渡す（#149）
  it('canvas が無い間はスケルトン、あればキャンバスを表示する', () => {
    const loading = mountView({ error: null, canvas: null })
    expect(loading.find('.v-skeleton-loader').exists()).toBe(true)
    expect(loading.findComponent(DocumentCanvas).exists()).toBe(false)

    const canvas = canvasVm({ downloadLabel: 'ダウンロード' })
    const ready = mountView({ error: null, canvas })
    expect(ready.findComponent(DocumentCanvas).props('vm')).toEqual(canvas)
    expect(ready.get('[data-testid="download-original"]').text()).toContain(
      'ダウンロード',
    )
    expect(ready.find('.v-skeleton-loader').exists()).toBe(false)
  })

  // 無効な閲覧URL / ダウンロード失敗はエラーstateを表示し、本文を出さない（再試行なし）
  it('エラーがあればエラーstateを表示し本文を消す', () => {
    const wrapper = mountView({
      error: 'この閲覧URLは無効です',
      canvas: canvasVm(),
    })
    expect(wrapper.get('[data-testid="public-error"]').text()).toContain(
      'この閲覧URLは無効です',
    )
    expect(wrapper.findComponent(DocumentCanvas).exists()).toBe(false)
    expect(wrapper.find('button').exists()).toBe(false)
  })
})
