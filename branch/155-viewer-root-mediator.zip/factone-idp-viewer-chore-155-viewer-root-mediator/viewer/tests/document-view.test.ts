import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import StartDialog from '../src/components/StartDialog.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { DocumentVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import DocumentView from '../src/views/DocumentView.vue'
import { canvasVm, registerVm, workPanelVm } from './fixtures'

const bubble = vi.fn()

function mountView(over: Partial<DocumentVm> = {}) {
  return mount(DocumentView, {
    props: {
      vm: {
        phase: 'ready',
        error: null,
        register: registerVm(),
        canvas: canvasVm(),
        workPanel: workPanelVm(),
        ...over,
      },
    },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// ダイアログ内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentView', () => {
  // 文書ID未指定（start / registering）は開始ダイアログだけを表示し、登録フォームへ vm.register を渡す
  it('start / registering では開始ダイアログを表示しパネルを出さない', () => {
    for (const phase of ['start', 'registering'] as const) {
      const wrapper = mountView({ phase, canvas: null, workPanel: null })
      expect(wrapper.findComponent(StartDialog).props('vm')).toEqual(
        registerVm(),
      )
      expect(wrapper.findComponent(WorkPanel).exists()).toBe(false)
      expect(wrapper.findComponent(DocumentCanvas).exists()).toBe(false)
      wrapper.unmount()
    }
  })

  // 取得中は 2 ペインにスケルトンを出す
  it('loading では両ペインにスケルトンを表示する', () => {
    const wrapper = mountView({
      phase: 'loading',
      canvas: null,
      workPanel: null,
    })
    expect(wrapper.findAll('.v-skeleton-loader')).toHaveLength(2)
    expect(wrapper.findComponent(StartDialog).exists()).toBe(false)
  })

  // 文書取得失敗時はエラーstateと再試行ボタンを表示し、再試行で retryLoad を bubble する
  it('error ではエラーと再試行を表示し、再試行で retryLoad を bubble する', async () => {
    const wrapper = mountView({
      phase: 'error',
      error: '文書を取得できませんでした',
      canvas: null,
      workPanel: null,
    })
    expect(wrapper.get('[data-testid="document-error"]').text()).toContain(
      '文書を取得できませんでした',
    )
    await wrapper.get('[data-testid="document-retry"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'retryLoad' })
  })

  // 表示成功時に DocumentCanvas と WorkPanel へそれぞれの vm スライスを渡す
  it('ready では DocumentCanvas と WorkPanel に vm を渡す', () => {
    const canvas = canvasVm()
    const workPanel = workPanelVm({ shareable: true })
    const wrapper = mountView({ canvas, workPanel })
    expect(wrapper.findComponent(DocumentCanvas).props('vm')).toEqual(canvas)
    expect(wrapper.findComponent(WorkPanel).props('vm')).toEqual(workPanel)
    expect(wrapper.find('[data-testid="tab-urls"]').exists()).toBe(true)
  })
})
