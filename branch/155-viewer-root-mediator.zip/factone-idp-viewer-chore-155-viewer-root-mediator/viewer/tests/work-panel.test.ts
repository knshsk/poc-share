import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import ResultEditor from '../src/components/ResultEditor.vue'
import ViewUrlPanel from '../src/components/ViewUrlPanel.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { WorkPanelVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import {
  correctedRun,
  editorVm,
  failedRun,
  succeededRun,
  toSummary,
  workPanelVm,
} from './fixtures'

const bubble = vi.fn()

function mountPanel(over: Partial<WorkPanelVm> = {}) {
  return mount(WorkPanel, {
    props: { vm: workPanelVm(over) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// 成功実行を選択中（読取結果タブ・editor あり）の vm
function withEditor(over: Partial<WorkPanelVm> = {}) {
  return {
    runs: [toSummary(succeededRun)],
    selectedRun: succeededRun,
    editor: editorVm({ run: succeededRun }),
    ...over,
  }
}

// ダイアログ・スナックバーはbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('WorkPanel', () => {
  it('IDP実行ボタンで executeIdp を bubble し、実行中は無効化する', async () => {
    const wrapper = mountPanel()
    await wrapper.get('[data-testid="execute-idp"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'executeIdp' })

    const executing = mountPanel({ executing: true })
    expect(
      executing.get('[data-testid="execute-idp"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('エラーメッセージを表示する', () => {
    expect(mountPanel({ error: 'IDP実行に失敗しました' }).text()).toContain(
      'IDP実行に失敗しました',
    )
  })

  // 成功実行選択時、ResultEditor に editor を渡し、チップに区分と日時が出る。アクションバーは変更0件で無効
  it('成功実行の editor とチップ・アクションバーを表示する', () => {
    const wrapper = mountPanel(withEditor())
    expect(wrapper.findComponent(ResultEditor).props('vm')).toEqual(
      editorVm({ run: succeededRun }),
    )
    expect(wrapper.get('[data-testid="selected-run-chip"]').text()).toContain(
      '初回',
    )
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 0件',
    )
    expect(
      wrapper.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeDefined()
    expect(
      wrapper.get('[data-testid="discard-draft"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('失敗実行選択時はエラー情報を出し、アクションバーを出さない', () => {
    const wrapper = mountPanel({
      runs: [toSummary(failedRun)],
      selectedRun: failedRun,
    })
    expect(wrapper.get('[data-testid="run-error"]').text()).toContain(
      'DI request failed',
    )
    expect(wrapper.find('[data-testid="confirm-corrections"]').exists()).toBe(
      false,
    )
  })

  it('実行未選択は「実行結果がありません」、取得中はスケルトン', () => {
    expect(mountPanel().text()).toContain('実行結果がありません')
    expect(
      mountPanel({ loadingRuns: true }).find('.v-skeleton-loader').exists(),
    ).toBe(true)
  })

  // 修正行を選択するとチップが「修正 · 日時 · 修正者」になる
  it('修正行のチップに修正者を表示する', () => {
    const wrapper = mountPanel({
      runs: [toSummary(correctedRun)],
      selectedRun: correctedRun,
      editor: editorVm({ run: correctedRun }),
    })
    const chip = wrapper.get('[data-testid="selected-run-chip"]')
    expect(chip.text()).toContain('修正')
    expect(chip.text()).toContain('testuser')
  })

  // 履歴は区分「初回/再実行/修正」・成否・修正者を表示し、行クリックで selectRun を bubble する
  it('履歴タブに区分と修正者を表示し、行クリックで selectRun を bubble する', async () => {
    const wrapper = mountPanel({
      runs: [correctedRun, failedRun, succeededRun].map(toSummary),
      selectedRun: correctedRun,
      activeTab: 'history',
    })
    const rows = wrapper.findAll('[data-testid="run-row"]')
    expect(rows).toHaveLength(3)
    expect(rows[0]!.text()).toContain('修正')
    expect(rows[0]!.text()).toContain('testuser')
    expect(rows[1]!.text()).toContain('再実行')
    expect(rows[1]!.text()).toContain('失敗')
    expect(rows[2]!.text()).toContain('初回')
    expect(wrapper.text()).not.toContain('prebuilt-layout')
    expect(rows[0]!.classes()).toContain('v-list-item--active')

    await rows[2]!.trigger('click')
    expect(bubble).toHaveBeenCalledWith({
      type: 'selectRun',
      runId: succeededRun.run_id,
    })
  })

  it('履歴が無いときは「実行履歴がありません」', () => {
    expect(mountPanel({ activeTab: 'history' }).text()).toContain(
      '実行履歴がありません',
    )
  })

  // タブは vm.activeTab で選択され、クリックで tabChanged を bubble する
  it('タブ選択は vm に従い、クリックで tabChanged を bubble する', async () => {
    const wrapper = mountPanel({ activeTab: 'history' })
    expect(wrapper.get('[data-testid="tab-history"]').classes()).toContain(
      'v-tab--selected',
    )
    await wrapper.get('[data-testid="tab-result"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'tabChanged', tab: 'result' })
  })

  // 閲覧URLタブは設定のshareableで表示制御し、ViewUrlPanel に vm.viewUrls を渡す（#81・ADR-0002）
  it('shareable=trueで閲覧URLタブを表示し、falseでは表示しない', () => {
    expect(mountPanel().find('[data-testid="tab-urls"]').exists()).toBe(false)
    const shareable = mountPanel({ shareable: true, activeTab: 'urls' })
    expect(shareable.find('[data-testid="tab-urls"]').exists()).toBe(true)
    expect(shareable.findComponent(ViewUrlPanel).props('vm')).toEqual(
      workPanelVm().viewUrls,
    )
  })

  // 変更ありで確定・破棄が有効になり、それぞれ bubble する。保存中は無効
  it('変更があれば確定・破棄を有効化して bubble し、保存中は無効化する', async () => {
    const wrapper = mountPanel(withEditor({ draftCount: 2 }))
    expect(wrapper.get('[data-testid="change-count"]').text()).toContain(
      '変更 2件',
    )
    await wrapper.get('[data-testid="discard-draft"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'discardDraft' })
    await wrapper.get('[data-testid="confirm-corrections"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmCorrections' })

    const saving = mountPanel(withEditor({ draftCount: 2, saving: true }))
    expect(
      saving.get('[data-testid="confirm-corrections"]').attributes('disabled'),
    ).toBeDefined()
  })

  // 未保存の変更の確認ダイアログ: vm.confirmDiscard で表示し、キャンセル / 破棄して続行を bubble する
  it('confirmDiscard で確認ダイアログを出し、cancel / proceed を bubble する', () => {
    mountPanel(withEditor({ draftCount: 1, confirmDiscard: true }))
    const dialog = document.querySelector('[data-testid="discard-dialog"]')
    expect(dialog?.textContent).toContain('未保存の変更を破棄しますか？')
    expect(dialog?.textContent).toContain('変更 1件')
    // ダイアログのアクセシブル名はタイトル要素（aria-labelledby）
    const titleId = document
      .querySelector('[role="dialog"]')
      ?.getAttribute('aria-labelledby')
    expect(titleId).toBeTruthy()
    expect(document.getElementById(titleId!)?.textContent).toContain(
      '未保存の変更を破棄しますか？',
    )
    ;(
      document.querySelector('[data-testid="discard-cancel"]') as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmCancel' })
    ;(
      document.querySelector('[data-testid="discard-proceed"]') as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'confirmProceed' })
  })

  it('savedSnackbar で「修正を保存しました」を表示する', () => {
    mountPanel(withEditor({ savedSnackbar: true }))
    expect(document.body.textContent).toContain('修正を保存しました')
  })

  // ResultEditor の操作は WorkPanel を素通りして親へ bubble する（Chain of Responsibility）
  it('ResultEditor の入力が親へ bubble する', async () => {
    const wrapper = mountPanel(withEditor())
    await wrapper.get('[data-testid="field-input"] input').setValue('A-002')
    expect(bubble).toHaveBeenCalledWith({
      type: 'fieldInput',
      key: 'order_no',
      value: 'A-002',
    })
  })
})
