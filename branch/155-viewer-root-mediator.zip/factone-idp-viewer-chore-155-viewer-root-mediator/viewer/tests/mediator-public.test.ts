import { flushPromises } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const getMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
  setAccessToken: vi.fn(),
}))

import { createMediator, type Mediator } from '../src/mediator/machine'
import { fakeOidc, pages, routeGet } from './fixtures'

function openPublic(): Mediator {
  const m = createMediator(fakeOidc())
  m.dispatch({ type: 'init', pathname: '/view/tok-1', search: '' })
  return m
}

const createObjectURL = vi.fn().mockReturnValue('blob:mock')

beforeEach(() => {
  getMock.mockReset()
  getMock.mockImplementation(routeGet())
  createObjectURL.mockClear()
  URL.createObjectURL = createObjectURL
})

afterEach(() => {
  // @ts-expect-error jsdom に無いメソッドを仮設したため削除して戻す
  delete URL.createObjectURL
})

describe('Mediator（公開閲覧）', () => {
  it('ページ取得後にキャンバス（ダウンロード文言・矩形なし）を出す', async () => {
    const m = openPublic()
    expect(m.vm.value.public?.canvas).toBeNull()
    await flushPromises()

    expect(m.vm.value.public?.canvas).toMatchObject({
      pages,
      run: null,
      downloadLabel: 'ダウンロード',
    })
    expect(m.vm.value.header.documentId).toBe('')
  })

  it('ページ取得失敗は「この閲覧URLは無効です」', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/view/{token}/pages'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet()(path),
    )
    const m = openPublic()
    await flushPromises()
    expect(m.vm.value.public?.error).toBe('この閲覧URLは無効です')
  })

  // 表示領域に入ったページだけ取得し、取得済み・取得中は再要求しない。応答は blob URL にして images へ
  it('pageVisible で /view 系の画像を 1 回だけ取得し images へ入れる', async () => {
    const m = openPublic()
    await flushPromises()

    m.dispatch({ type: 'pageVisible', page: 1 })
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()

    const imageCalls = getMock.mock.calls.filter(
      ([path]) => path === '/view/{token}/pages/{page}/image',
    )
    expect(imageCalls).toHaveLength(1)
    expect(imageCalls[0]![1]).toMatchObject({
      params: { path: { token: 'tok-1', page: 1 } },
      parseAs: 'blob',
    })
    expect(m.vm.value.public?.canvas?.images).toEqual({ 1: 'blob:mock' })
  })

  it('画像取得失敗は images に入れず、blob URL も作らない', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/view/{token}/pages/{page}/image'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet()(path),
    )
    const m = openPublic()
    await flushPromises()
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()

    expect(createObjectURL).not.toHaveBeenCalled()
    expect(m.vm.value.public?.canvas?.images).toEqual({})
  })

  it('ダウンロード失敗は「ダウンロードできませんでした」で本文を消す', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/view/{token}/pdf'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet()(path),
    )
    const m = openPublic()
    await flushPromises()

    m.dispatch({ type: 'downloadOriginal' })
    await flushPromises()

    expect(m.vm.value.public?.error).toBe('ダウンロードできませんでした')
  })

  // 公開閲覧では認証系・文書系のイベントを受けない（裁定）
  it('公開閲覧中は executeIdp / openDocument を無視する', async () => {
    const m = openPublic()
    await flushPromises()
    m.dispatch({ type: 'executeIdp' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.state.value).toBe('public')
    expect(getMock.mock.calls.map(([p]) => p)).not.toContain(
      '/api/v1/documents/{document_id}',
    )
  })
})
