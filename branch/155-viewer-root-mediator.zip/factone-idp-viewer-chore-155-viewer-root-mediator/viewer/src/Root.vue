<script setup lang="ts">
import { onMounted, onUnmounted, provide } from 'vue'

import AppHeader from './components/AppHeader.vue'
import { BUBBLE } from './mediator/bubble'
import { createMediator } from './mediator/machine'
import DocumentView from './views/DocumentView.vue'
import LoginView from './views/LoginView.vue'
import PublicView from './views/PublicView.vue'

// 階層の頂点。Mediator を 1 つ持ち、bubble の鎖の終点として dispatch を provide し、vm を各画面へスライスして渡す
const mediator = createMediator()
const vm = mediator.vm
provide(BUBBLE, mediator.dispatch)

// ブラウザ離脱時の標準警告（文言はブラウザ固定）。未保存の変更は vm.dirty で判定する
function onBeforeUnload(event: BeforeUnloadEvent): void {
  if (!vm.value.dirty) return
  event.preventDefault()
  event.returnValue = ''
}

onMounted(() => {
  window.addEventListener('beforeunload', onBeforeUnload)
  // ルーター未導入のためパス（/view/{token}・/callback・その他）の判定は Mediator の init に任せる
  mediator.dispatch({
    type: 'init',
    pathname: window.location.pathname,
    search: window.location.search,
  })
})

onUnmounted(() => {
  window.removeEventListener('beforeunload', onBeforeUnload)
})
</script>

<template>
  <v-app>
    <!-- ログイン画面はアプリバーなし。公開閲覧はロゴのみ（vm.header.authenticated=false） -->
    <AppHeader v-if="vm.screen !== 'login'" :vm="vm.header" />
    <v-main class="bg-background">
      <PublicView v-if="vm.screen === 'public' && vm.public" :vm="vm.public" />
      <DocumentView
        v-else-if="vm.screen === 'document' && vm.document"
        :vm="vm.document"
      />
      <LoginView v-else />
    </v-main>

    <!-- 下端表示領域。全状態で表示。リンクはプレースホルダ（文言・遷移先は後続で確定） -->
    <v-footer
      app
      height="32"
      color="surface"
      class="app-footer text-caption text-secondary py-0"
      data-testid="app-footer"
    >
      <span>FactONE Viewer</span>
      <v-spacer />
      <a href="#" class="footer-link">プライバシーポリシー</a>
      <a href="#" class="footer-link">お問い合わせ</a>
      <a href="#" class="footer-link">ライセンス</a>
    </v-footer>
  </v-app>
</template>

<style scoped>
.app-footer {
  gap: 16px;
  border-top: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.footer-link {
  color: inherit;
  text-decoration: none;
}

.footer-link:hover {
  text-decoration: underline;
}
</style>
