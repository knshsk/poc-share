import { computed, type ComputedRef, type Ref } from 'vue'

import type { IdpRun, IdpRunSummary } from '../utils/runs'
import type { PageSize } from '../utils/zoom'
import type { Tab } from './events'
import {
  AUTHED,
  draftCount,
  type FieldDef,
  type Model,
  type Request,
  type State,
  type TypeItem,
} from './model'

// 各 View が受け取る ViewModel。View は自分の型 1 つだけを prop で受け、子には部分を渡す

export interface HeaderVm {
  documentId: string
  documentTypeLabel: string | null
  authenticated: boolean
  username: string | null
}

export interface CanvasVm {
  pages: PageSize[]
  run: IdpRun | null
  fieldDefs: FieldDef[]
  images: Record<number, string>
  activeId: string | null
  scrollRequest: Request | null
  downloadLabel: string
}

export interface PublicVm {
  error: string | null
  canvas: CanvasVm | null
}

export interface RegisterVm {
  typeItems: TypeItem[]
  submitting: boolean
  error: string | null
}

export interface EditorVm {
  run: IdpRun
  fieldDefs: FieldDef[]
  draftFields: Record<string, string | null>
  draftCells: Record<string, string>
  activeId: string | null
  focusRequest: Request | null
}

export type ViewUrlsVm = Omit<Model['viewUrls'], 'loadedFor'>

export interface WorkPanelVm {
  runs: IdpRunSummary[]
  selectedRun: IdpRun | null
  activeTab: Tab
  executing: boolean
  saving: boolean
  loadingRuns: boolean
  error: string | null
  shareable: boolean
  draftCount: number
  savedSnackbar: boolean
  confirmDiscard: boolean
  editor: EditorVm | null
  viewUrls: ViewUrlsVm
}

export interface DocumentVm {
  phase: 'start' | 'registering' | 'loading' | 'error' | 'ready'
  error: string | null
  register: RegisterVm
  canvas: CanvasVm | null
  workPanel: WorkPanelVm | null
}

export interface RootVm {
  screen: 'login' | 'public' | 'document'
  header: HeaderVm
  public: PublicVm | null
  document: DocumentVm | null
  dirty: boolean
}

// state → DocumentVm.phase。表に無い状態（document / executing / saving / confirmDiscard）は ready
const PHASE: Partial<Record<State, DocumentVm['phase']>> = {
  start: 'start',
  registering: 'registering',
  loadingDocument: 'loading',
  documentError: 'error',
}

// スライスごとに computed を分け、変化した部分だけ参照が変わるようにする
// （draft 入力で canvas の参照は変わらず、DocumentCanvas / PageSvg は再描画されない）
export function buildVm(state: Ref<State>, model: Model): ComputedRef<RootVm> {
  const header = computed<HeaderVm>(() => ({
    documentId: model.documentId,
    documentTypeLabel: model.document
      ? (model.document.displayName ?? model.document.type)
      : null,
    authenticated: AUTHED.includes(state.value),
    username: model.username,
  }))

  const publicCanvas = computed<CanvasVm | null>(() =>
    model.publicPages.length === 0
      ? null
      : {
          pages: model.publicPages,
          run: null,
          fieldDefs: [],
          images: model.images,
          activeId: null,
          scrollRequest: null,
          downloadLabel: 'ダウンロード',
        },
  )

  const publicVm = computed<PublicVm | null>(() =>
    state.value === 'public'
      ? { error: model.errors.public, canvas: publicCanvas.value }
      : null,
  )

  const documentCanvas = computed<CanvasVm | null>(() => {
    const doc = model.document
    if (!doc) return null
    return {
      pages: doc.pages,
      run: model.selectedRun,
      fieldDefs: doc.fieldDefs,
      images: model.images,
      activeId: model.activeId,
      scrollRequest: model.canvasScroll,
      downloadLabel: '原本DL',
    }
  })

  const register = computed<RegisterVm>(() => ({
    typeItems: model.register.typeItems,
    submitting: state.value === 'registering',
    error: model.register.error,
  }))

  const editor = computed<EditorVm | null>(() => {
    const run = model.selectedRun
    const doc = model.document
    if (!run || !doc || run.status !== 'succeeded') return null
    return {
      run,
      fieldDefs: doc.fieldDefs,
      draftFields: model.draft.fields,
      draftCells: model.draft.cells,
      activeId: model.activeId,
      focusRequest: model.paneFocus,
    }
  })

  const viewUrls = computed<ViewUrlsVm>(() => model.viewUrls)

  const workPanel = computed<WorkPanelVm | null>(() => {
    const doc = model.document
    if (!doc) return null
    return {
      runs: model.runs,
      selectedRun: model.selectedRun,
      activeTab: model.activeTab,
      executing: state.value === 'executing',
      saving: state.value === 'saving',
      loadingRuns: model.runsLoading,
      error: model.errors.workPanel,
      shareable: doc.shareable,
      draftCount: draftCount(model.draft),
      savedSnackbar: model.savedSnackbar,
      confirmDiscard: state.value === 'confirmDiscard',
      editor: editor.value,
      viewUrls: viewUrls.value,
    }
  })

  const documentVm = computed<DocumentVm | null>(() => {
    if (!AUTHED.includes(state.value)) return null
    const phase = PHASE[state.value] ?? 'ready'
    return {
      phase,
      error: model.errors.document,
      register: register.value,
      canvas: phase === 'ready' ? documentCanvas.value : null,
      workPanel: phase === 'ready' ? workPanel.value : null,
    }
  })

  return computed<RootVm>(() => ({
    screen:
      state.value === 'public'
        ? 'public'
        : AUTHED.includes(state.value)
          ? 'document'
          : 'login',
    header: header.value,
    public: publicVm.value,
    document: documentVm.value,
    dirty: draftCount(model.draft) > 0,
  }))
}
