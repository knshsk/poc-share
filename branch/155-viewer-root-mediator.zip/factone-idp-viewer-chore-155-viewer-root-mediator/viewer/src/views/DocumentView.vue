<script setup lang="ts">
import { PhWarningCircle } from '@phosphor-icons/vue'

import DocumentCanvas from '../components/DocumentCanvas.vue'
import StartDialog from '../components/StartDialog.vue'
import WorkPanel from '../components/WorkPanel.vue'
import { useBubble } from '../mediator/bubble'
import type { DocumentVm } from '../mediator/vm'

// 認証済み画面。文書の取得・切替・URL パラメータの読取は Mediator が行い、ここは phase に応じた配置だけ
defineProps<{ vm: DocumentVm }>()

const bubble = useBubble()
</script>

<template>
  <!-- 文書ID未指定: 開始ダイアログ（文書を登録 / 文書IDで参照） -->
  <StartDialog
    v-if="vm.phase === 'start' || vm.phase === 'registering'"
    :vm="vm.register"
  />

  <!-- 取得失敗: エラーstate -->
  <div v-else-if="vm.phase === 'error'" class="state-screen">
    <PhWarningCircle :size="48" class="text-error mb-4" />
    <p class="text-body-1 mb-4" data-testid="document-error">
      {{ vm.error }}
    </p>
    <v-btn
      color="primary"
      variant="outlined"
      data-testid="document-retry"
      @click="bubble({ type: 'retryLoad' })"
    >
      再試行
    </v-btn>
  </div>

  <!-- 2ペイン: 左キャンバス / 右作業パネル -->
  <div v-else class="document-layout">
    <section class="canvas-pane">
      <DocumentCanvas v-if="vm.canvas" :vm="vm.canvas" />
      <div v-else class="canvas-loading">
        <v-skeleton-loader type="image" class="page-skeleton" />
      </div>
    </section>

    <aside class="work-pane">
      <WorkPanel v-if="vm.workPanel" :vm="vm.workPanel" />
      <v-skeleton-loader v-else type="article" />
    </aside>
  </div>
</template>

<style scoped>
/* アプリバー・フッターを除いた高さで2ペインを固定し、ペイン内スクロールにする。
   --v-layout-top / --v-layout-bottom は Vuetify が v-main に設定する（子孫から継承で参照できる。
   v-main の外では 0px にフォールバックする）（app-bar 56px・footer 32px） */
.document-layout {
  display: grid;
  grid-template-columns: 1fr 528px;
  /* 行を minmax(0, 1fr) で固定する。auto 行だとコンテンツ（ページ高さ）で行が伸びてペイン内スクロールが
     効かず、キャンバスの ResizeObserver がズーム変更のたびに発火してフィットが1%ずつ反復収束する */
  grid-template-rows: minmax(0, 1fr);
  height: calc(100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px));
}

.canvas-pane {
  min-width: 0;
  min-height: 0;
}

.work-pane {
  min-height: 0;
  overflow: hidden;
  background: rgb(var(--v-theme-surface));
  border-left: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* 幅960px未満は縦積みフォールバック（作業パネルが上・キャンバスが下）。
   作業パネルは縦積み時も内部でスクロールする（固定高さでheight:100%を効かせる） */
@media (max-width: 960px) {
  .document-layout {
    display: flex;
    flex-direction: column-reverse;
    height: auto;
  }

  .canvas-pane {
    min-height: 60vh;
  }

  .work-pane {
    border-left: none;
    border-bottom: 1px solid
      rgba(var(--v-border-color), var(--v-border-opacity));
    height: 60vh;
  }
}
</style>
