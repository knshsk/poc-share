<script setup lang="ts">
import { useBubble } from '../mediator/bubble'

// 未認証時の画面。資格情報の入力は Keycloak 側で行うため、ここはログイン開始の通知だけ
const bubble = useBubble()
</script>

<template>
  <div class="login-screen">
    <v-card class="login-card pa-8" elevation="2" rounded="lg">
      <div class="text-primary font-weight-bold text-h6 mb-2">
        FactONE Viewer
      </div>
      <p class="text-secondary text-body-2 mb-6">
        プロトタイプ実装中のため、動作は予告なく変更される可能性があります。
      </p>
      <v-btn
        color="primary"
        block
        size="large"
        @click="bubble({ type: 'login' })"
      >
        ログイン
      </v-btn>
    </v-card>
  </div>
</template>

<style scoped>
.login-screen {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: calc(
    100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px)
  );
}

.login-card {
  width: 360px;
  max-width: 90vw;
}
</style>
