<script setup lang="ts">
import { PhFileDashed } from '@phosphor-icons/vue'
import { ref } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { RegisterVm } from '../mediator/vm'

// 定型外フロー向けの手動登録フォーム。送信前の入力値は描画パラメータとして View が持ち、
// 送信時に register を bubble する（multipart 化・API 呼出・エラー文言は Mediator）
defineProps<{ vm: RegisterVm }>()

const bubble = useBubble()
const documentId = ref('')
const documentType = ref<string | null>(null)
const file = ref<File>()

function submit(): void {
  const type = documentType.value
  const pdf = file.value
  if (!documentId.value || !type || !pdf) return
  bubble({
    type: 'register',
    documentId: documentId.value,
    documentType: type,
    file: pdf,
  })
}
</script>

<template>
  <v-form @submit.prevent="submit">
    <v-select
      v-model="documentType"
      :items="vm.typeItems"
      item-title="display_name"
      item-value="type_code"
      label="書類種別"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-document-type"
    />
    <v-text-field
      v-model="documentId"
      label="文書ID"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-document-id"
    />
    <!-- ドロップゾーン: D&D は accept 属性が効かないため filter-by-type で PDF 以外を拒否する。
         選択後はゾーン内にファイル名を表示し（inset-file-list）、高さを変えずに差し替え・解除できる -->
    <v-file-upload
      v-model="file"
      :icon="PhFileDashed"
      title="PDFファイルをドラッグ＆ドロップ、またはクリックして選択"
      browse-text="ファイルを変更"
      filter-by-type="application/pdf"
      density="comfortable"
      hide-browse
      inset-file-list
      clearable
      show-size
      class="register-dropzone mb-4"
      data-testid="register-file"
    />
    <v-alert
      v-if="vm.error"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-4"
      data-testid="register-error"
    >
      {{ vm.error }}
    </v-alert>
    <div class="d-flex justify-center">
      <v-btn
        type="submit"
        color="primary"
        min-width="120"
        :loading="vm.submitting"
        :disabled="!documentId || !documentType || !file"
        data-testid="register-submit"
      >
        登録
      </v-btn>
    </div>
  </v-form>
</template>

<style scoped>
/* ドロップゾーン: 空/選択済みで高さを固定し、Vuetify 既定の見出しサイズを補助文言相当へ落とす */
.register-dropzone :deep(.v-file-upload-dropzone) {
  min-height: 168px;
  padding: 24px 16px;
}

.register-dropzone :deep(.v-file-upload-title) {
  font-size: 0.875rem;
  font-weight: 400;
  color: rgb(var(--v-theme-secondary));
}

.register-dropzone :deep(.v-file-upload-icon) {
  color: rgb(var(--v-theme-secondary));
  opacity: 1;
  margin-bottom: 0.25rem;
}
</style>
