# 閲覧・DLイベント（view_events）

閲覧URL経由の閲覧・ダウンロード記録（VWR-03）。追記型（更新・削除しない）。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | |
| document_id | varchar(255) | NOT NULL・FK(documents) | 対象文書。**案件IDは保持しない**（外部連携側が文書IDから解決） |
| view_token_id | uuid | NOT NULL・FK(view_tokens) | どの閲覧URL経由か（発行台帳との紐付け） |
| event_type | varchar(20) | NOT NULL・CHECK | `view`（閲覧）/ `download`（原本DL） |
| occurred_at | timestamptz | NOT NULL | 発生日時（配信時にサーバで記録） |
| client_ip | varchar(64) | NOT NULL | 端末情報 |
| user_agent | varchar(512) | NOT NULL | 端末情報 |

- **UNIQUE(document_id, occurred_at, event_type)** — 冪等キー（COM-02: 文書ID+イベント発生日時）のDB制約。衝突時は挿入スキップ（配信は成功させ、記録の重複だけ防ぐ）

## 記録ポイント

APIプロキシ配信が唯一の関門である決定に基づき、公開閲覧経路の配信成功時にのみ記録する。

| 経路 | イベント |
| --- | --- |
| `GET /view/{token}/pages` 成功 | view（文書を開いた=1閲覧） |
| `GET /view/{token}/pdf` 成功 | download |
| `GET /view/{token}/pages/{page}/image` | 記録しない（viewの一部。二重記録防止） |
| 無効トークンのアクセス | 記録しない（失敗記録 `view_access_failures` 側に残る） |
| 社内（認証済み）表示 | **記録しない**（社内閲覧イベントの履歴化要否が未確定のための仮置き） |

## 取得

- `GET /api/documents/{document_id}/events`（JWT必須）— 検証用一覧
- 外部連携（Power Automate日次取得・IF-04）は取得方式の確定後に実装
