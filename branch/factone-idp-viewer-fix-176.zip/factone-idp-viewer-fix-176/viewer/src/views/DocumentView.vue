<script setup lang="ts">
import { PhWarningCircle } from '@phosphor-icons/vue'
import { computed, onUnmounted, ref, watch } from 'vue'

import DocumentCanvas from '../components/DocumentCanvas.vue'
import LoadingSpinner from '../components/LoadingSpinner.vue'
import StartDialog from '../components/StartDialog.vue'
import WorkPanel from '../components/WorkPanel.vue'
import { useBubble } from '../mediator/bubble'
import type { DocumentVm } from '../mediator/vm'

// 認証済み画面。文書の取得・切替・URL パラメータの読取は Mediator が行い、ここは phase に応じた配置だけ
defineProps<{ vm: DocumentVm }>()

const bubble = useBubble()

// 右ペインの幅は描画状態（保存しない）。上限はレイアウト幅からキャンバス 320px と境界 6px を残した幅
const PANE_DEFAULT = 528
const PANE_MIN = 400
const RESERVED = 326
const SPLITTER = 6
const STEP = 16

const layout = ref<HTMLElement | null>(null)
// 利用者が決めた幅。ウィンドウが狭い間も書き換えない（広げ直せば元の幅に戻る）
const paneWidth = ref(PANE_DEFAULT)
// 上限 = レイアウト幅 − キャンバス 320px − 境界 6px。レイアウトを計測できるまでは既定幅を仮に置く
const paneMax = ref(PANE_DEFAULT)
// 実際に表示される幅（CSS の min() と同じ計算）。aria-valuenow とキー操作の基準にする
const shownWidth = computed(() => Math.min(paneWidth.value, paneMax.value))

// 上限を計測し直す（ウィンドウを縮めたときに CSS の min() が実効幅を丸める。状態＝paneWidth はここでは
// 変えない。計測不能（jsdom・非表示でサイズ 0）のときは据え置く）
function syncMax(): void {
  const width = layout.value?.clientWidth ?? 0
  if (width === 0) return
  paneMax.value = Math.max(PANE_MIN, width - RESERVED)
}

function setPaneWidth(width: number): void {
  syncMax()
  paneWidth.value = Math.round(
    Math.min(paneMax.value, Math.max(PANE_MIN, width)),
  )
}

// レイアウトは phase によって出入りする。現れたら計測し、大きさの変化（ウィンドウ幅）に追従する。
// ResizeObserver の無い環境に備えて存在を確認する（DocumentCanvas と同じ）
let resizeObserver: ResizeObserver | null = null
watch(layout, (el) => {
  resizeObserver?.disconnect()
  resizeObserver = null
  if (!el) return
  syncMax()
  if (typeof ResizeObserver !== 'undefined') {
    resizeObserver = new ResizeObserver(syncMax)
    resizeObserver.observe(el)
  }
})

onUnmounted(() => resizeObserver?.disconnect())

// ポインタを要素に捕捉して要素自身の pointermove で追従する（window へのリスナーは足さない）。
// 離す・中断のどちらでも lostpointercapture が来るので、そこで追従をやめる
function startDrag(event: PointerEvent): void {
  if (event.button !== 0) return
  const el = event.currentTarget as HTMLElement
  const right = layout.value?.getBoundingClientRect().right ?? 0
  const move = (e: PointerEvent): void =>
    setPaneWidth(right - e.clientX - SPLITTER / 2)
  el.setPointerCapture(event.pointerId)
  el.addEventListener('pointermove', move)
  el.addEventListener(
    'lostpointercapture',
    () => el.removeEventListener('pointermove', move),
    { once: true },
  )
}
</script>

<template>
  <!-- 文書ID未指定: 開始ダイアログ（文書を登録 / 文書IDで参照） -->
  <StartDialog
    v-if="vm.phase === 'start' || vm.phase === 'registering'"
    :vm="vm.register"
  />

  <!-- 取得失敗: エラーstate -->
  <div v-else-if="vm.phase === 'error'" class="state-screen">
    <PhWarningCircle :size="48" class="text-error mb-4" />
    <p class="text-body-large mb-4" data-testid="document-error">
      {{ vm.error }}
    </p>
    <v-btn
      color="primary"
      variant="outlined"
      data-testid="document-retry"
      @click="bubble({ type: 'retryLoad' })"
    >
      再試行
    </v-btn>
  </div>

  <!-- 2ペイン: 左キャンバス / 境界 / 右作業パネル -->
  <div
    v-else
    ref="layout"
    class="document-layout"
    :style="{ '--pane-width': `${paneWidth}px` }"
  >
    <section class="canvas-pane">
      <DocumentCanvas v-if="vm.canvas" :vm="vm.canvas" />
      <div v-else class="loading-area canvas-loading">
        <LoadingSpinner />
      </div>
    </section>

    <!-- 境界: ドラッグ / ←→（16px）で右ペインの幅を変える。ダブルクリックで既定に戻す -->
    <div
      class="pane-splitter"
      role="separator"
      aria-orientation="vertical"
      aria-label="右ペインの幅"
      aria-controls="work-pane"
      :aria-valuenow="shownWidth"
      :aria-valuemin="PANE_MIN"
      :aria-valuemax="paneMax"
      tabindex="0"
      data-testid="pane-splitter"
      @pointerdown="startDrag"
      @dblclick="setPaneWidth(PANE_DEFAULT)"
      @keydown.left.exact.prevent="setPaneWidth(shownWidth + STEP)"
      @keydown.right.exact.prevent="setPaneWidth(shownWidth - STEP)"
    />

    <aside id="work-pane" class="work-pane">
      <WorkPanel v-if="vm.workPanel" :vm="vm.workPanel" />
      <div v-else class="loading-area">
        <LoadingSpinner />
      </div>
    </aside>
  </div>
</template>

<style scoped>
/* アプリバー・フッターを除いた高さで2ペインを固定し、ペイン内スクロールにする。
   --v-layout-top / --v-layout-bottom は Vuetify が v-main に設定する（子孫から継承で参照できる。
   v-main の外では 0px にフォールバックする）（app-bar 56px・footer 32px） */
.document-layout {
  display: grid;
  /* キャンバス | 境界 6px | 右ペイン。326px = キャンバスの最小 320px + 境界 6px */
  grid-template-columns: minmax(0, 1fr) 6px min(
      var(--pane-width),
      calc(100% - 326px)
    );
  /* 行を minmax(0, 1fr) で固定する。auto 行だとコンテンツ（ページ高さ）で行が伸びてペイン内スクロールが
     効かず、キャンバスの ResizeObserver がズーム変更のたびに発火してフィットが1%ずつ反復収束する */
  grid-template-rows: minmax(0, 1fr);
  height: calc(100dvh - var(--v-layout-top, 0px) - var(--v-layout-bottom, 0px));
}

.canvas-pane {
  min-width: 0;
  min-height: 0;
}

.work-pane {
  min-height: 0;
  overflow: hidden;
  background: rgb(var(--v-theme-surface));
}

/* 境界。幅 6px のつまみ、ホバー / フォーカスで主色 */
.pane-splitter {
  cursor: col-resize;
  background: rgba(var(--v-border-color), var(--v-border-opacity));
  touch-action: none;
  user-select: none;
  transition: background 0.12s ease;
}

.pane-splitter:hover,
.pane-splitter:focus-visible {
  background: rgb(var(--v-theme-primary));
}

/* forced-colors では背景色が消えるため、透明の outline を置く（強制配色時だけ見える） */
.pane-splitter:focus-visible {
  outline: 2px solid transparent;
}

/* 幅 960px 以下は縦積みフォールバック（作業パネルが上・キャンバスが下）。
   作業パネルは縦積み時も内部でスクロールする（固定高さでheight:100%を効かせる） */
@media (max-width: 960px) {
  .document-layout {
    display: flex;
    flex-direction: column-reverse;
    height: auto;
  }

  .canvas-pane {
    min-height: 60vh;
  }

  .work-pane {
    border-bottom: 1px solid
      rgba(var(--v-border-color), var(--v-border-opacity));
    height: 60vh;
  }

  .pane-splitter {
    display: none;
  }
}
</style>
