import { apiClient } from '../../api/client'
// machine.ts と循環 import。guardDirty は関数宣言で run() 内からだけ呼ぶため安全（const 化しない）
import { guardDirty, type Ctx, type Handlers } from '../machine'
import { AUTHED, clearDocument } from '../model'
import { loadRuns } from './runs'

// 文書切替。画像 blob を全 revoke し文書系の状態を初期化してから、文書・ページ・種別設定を並行取得する
export function loadDocument(ctx: Ctx, documentId: string): void {
  clearDocument(ctx.model)
  ctx.model.documentId = documentId
  ctx.state.value = 'loadingDocument'
  void Promise.all([
    apiClient.GET('/api/v1/documents/{document_id}', {
      params: { path: { document_id: documentId } },
    }),
    apiClient.GET('/api/v1/documents/{document_id}/pages', {
      params: { path: { document_id: documentId } },
    }),
    apiClient.GET('/api/v1/config/document-types'),
  ]).then(
    ([doc, pages, configs]) => {
      if (doc.error || !doc.data || pages.error || !pages.data) {
        ctx.dispatch({ type: 'documentFailed', documentId })
        return
      }
      ctx.dispatch({
        type: 'documentLoaded',
        documentId,
        document: doc.data,
        pages: pages.data.pages,
        configs: configs.data ?? null,
      })
    },
    () => ctx.dispatch({ type: 'documentFailed', documentId }),
  )
}

export const documentHandlers: Handlers = {
  documentTypesLoaded: {
    in: AUTHED,
    run(ctx, e) {
      ctx.model.register.typeItems = e.items
    },
  },
  openDocument: {
    in: ['start', 'document', 'documentError'],
    run(ctx, e) {
      // 未保存の修正があれば確認ダイアログ（confirmProceed で再 dispatch される）
      if (ctx.state.value === 'document' && guardDirty(ctx, e)) return
      loadDocument(ctx, e.documentId)
    },
  },
  // 定型外フロー向けの手動登録。送信先は既存の POST /api/v1/documents（Power Automate と同一 API）
  register: {
    in: ['start'],
    run(ctx, e) {
      ctx.model.register.error = null
      ctx.state.value = 'registering'
      const form = new FormData()
      form.set('document_id', e.documentId)
      form.set('document_type', e.documentType)
      form.set('file', e.file)
      void apiClient
        .POST('/api/v1/documents', {
          // OpenAPI 型は binary=string だが実体は File。multipart 化は bodySerializer で行う
          body: {
            document_id: e.documentId,
            document_type: e.documentType,
            file: e.file as unknown as string,
          },
          bodySerializer: () => form,
        })
        .then(
          ({ data, error }) => {
            if (error || !data) {
              ctx.dispatch({
                type: 'registerFailed',
                message:
                  error?.status === 409
                    ? '文書IDは別の内容で登録済みです'
                    : (error?.detail ?? '登録に失敗しました'),
              })
              return
            }
            // 200（同一内容の再送）も登録済みとして成功扱い
            ctx.dispatch({ type: 'registered', documentId: data.document_id })
          },
          () =>
            ctx.dispatch({
              type: 'registerFailed',
              message: '登録に失敗しました',
            }),
        )
    },
  },
  registered: {
    in: ['registering'],
    run(ctx, e) {
      loadDocument(ctx, e.documentId)
    },
  },
  registerFailed: {
    in: ['registering'],
    run(ctx, e) {
      ctx.model.register.error = e.message
      ctx.state.value = 'start'
    },
  },
  documentLoaded: {
    in: ['loadingDocument'],
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      // 種別設定（display_name・shareable・fields）を反映する。設定取得失敗・設定なしは
      // 表示名フォールバック（種別コード）・共有不可・全項目表示のまま継続する
      const config = e.configs?.find(
        (c) => c.type_code === e.document.document_type,
      )
      ctx.model.document = {
        type: e.document.document_type,
        displayName: config?.display_name ?? null,
        originalFilename: e.document.original_filename,
        shareable: config?.shareable ?? false,
        fieldDefs: config?.fields ?? [],
        pages: e.pages,
      }
      ctx.state.value = 'document'
      loadRuns(ctx)
    },
  },
  documentFailed: {
    in: ['loadingDocument'],
    run(ctx, e) {
      if (e.documentId !== ctx.model.documentId) return
      ctx.model.errors.document = '文書を取得できませんでした'
      ctx.state.value = 'documentError'
    },
  },
  retryLoad: {
    in: ['documentError'],
    run(ctx) {
      loadDocument(ctx, ctx.model.documentId)
    },
  },
}
