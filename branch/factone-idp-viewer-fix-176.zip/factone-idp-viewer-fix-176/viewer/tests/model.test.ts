import { describe, expect, it, vi } from 'vitest'

import {
  clearDocument,
  draftCount,
  initialModel,
  resetDraft,
  setCell,
  setField,
  toCorrections,
  type Draft,
} from '../src/mediator/model'
import { cellAt, cellKey, originalValue, type IdpRun } from '../src/utils/runs'

function draft(): Draft {
  return { fields: {}, cells: {} }
}

describe('draft 純関数', () => {
  // 差分のみ保持し、元値に戻ったら差分から外す。空欄は null（値なし）
  it('setField は元値との差分だけを保持し、空欄は null にする', () => {
    const d = draft()
    setField(d, 'TotalAmount', '1,250,000', '1,200,000')
    setField(d, 'Note', '', null)
    expect(d.fields).toEqual({ TotalAmount: '1,250,000' })
    expect(draftCount(d)).toBe(1)

    setField(d, 'Note', 'x', null)
    expect(d.fields).toEqual({ TotalAmount: '1,250,000', Note: 'x' })
    setField(d, 'Note', '', null)
    expect(d.fields).toEqual({ TotalAmount: '1,250,000' })

    setField(d, 'DeliveryDate', '', '2026-10-30')
    expect(d.fields.DeliveryDate).toBeNull()
    setField(d, 'TotalAmount', '1,200,000', '1,200,000')
    expect(d.fields).toEqual({ DeliveryDate: null })
  })

  it('setCell は元値との差分だけを保持する', () => {
    const d = draft()
    setCell(d, cellKey(0, 1, 0), 'P-9002', 'P-9001')
    expect(d.cells).toEqual({ '0:1:0': 'P-9002' })
    setCell(d, cellKey(0, 1, 0), 'P-9001', 'P-9001')
    expect(d.cells).toEqual({})
  })

  it('toCorrections は API のボディ形式（fields + table_cells）を返す', () => {
    const d = draft()
    setField(d, 'TotalAmount', '1,250,000', '1,200,000')
    setField(d, 'DeliveryDate', '', '2026-10-30')
    setCell(d, cellKey(0, 2, 3), '10', '1')
    expect(toCorrections(d)).toEqual({
      fields: { TotalAmount: '1,250,000', DeliveryDate: null },
      table_cells: [
        { table_index: 0, row_index: 2, column_index: 3, content: '10' },
      ],
    })
  })

  it('resetDraft で下書きが空になる', () => {
    const d = draft()
    setField(d, 'a', 'x', null)
    setCell(d, '0:0:0', 'y', 'z')
    resetDraft(d)
    expect(draftCount(d)).toBe(0)
  })
})

const run = {
  run_id: 'r-1',
  document_id: 'doc-1',
  run_type: 'initial',
  status: 'succeeded',
  executed_at: '2026-09-01T00:00:00Z',
  base_run_id: null,
  corrected_by: null,
  di_api_version: null,
  di_model_id: null,
  error_info: null,
  fields: {
    TotalAmount: {
      value: '1,200,000',
      normalized_value: 1200000,
      confidence: 0.9,
    },
    Note: { value: '約120万', normalized_value: null, confidence: null },
    Empty: { value: null, normalized_value: null, confidence: null },
  },
  tables: [
    {
      row_count: 2,
      column_count: 1,
      cells: [
        {
          row_index: 1,
          column_index: 0,
          row_span: 1,
          column_span: 1,
          content: 'P-9001',
          kind: null,
          page_number: 1,
        },
      ],
    },
  ],
  pattern_matches: null,
} as unknown as IdpRun

describe('utils/runs の元値取得', () => {
  // 入力欄の元値は正規化値（文字列化）、無ければ読取値、両方無ければ null
  it('originalValue は正規化値を優先し、無ければ読取値を返す', () => {
    expect(originalValue(run, 'TotalAmount')).toBe('1200000')
    expect(originalValue(run, 'Note')).toBe('約120万')
    expect(originalValue(run, 'Empty')).toBeNull()
    expect(originalValue(run, 'Missing')).toBeNull()
  })

  it('cellAt は座標に一致するセルを返し、無ければ null', () => {
    expect(cellAt(run, 0, 1, 0)?.content).toBe('P-9001')
    expect(cellAt(run, 0, 0, 0)).toBeNull()
    expect(cellAt(run, 1, 0, 0)).toBeNull()
  })
})

describe('clearDocument', () => {
  // 文書切替で文書系の状態を初期化し、ページ画像の blob URL を revoke する
  it('文書系の状態を初期化し画像 URL を revoke する', () => {
    const revoke = vi.fn()
    URL.revokeObjectURL = revoke
    const model = initialModel()
    model.images = { 1: 'blob:a', 2: 'blob:b' }
    model.imageInflight.add(3)
    model.selectedRun = run
    model.details.set('r-1', run)
    model.pendingRunId = 'r-1'
    model.runs = [run]
    setField(model.draft, 'a', 'x', null)
    model.activeId = 'field:a'
    model.activeTab = 'history'
    model.errors.document = 'x'
    model.errors.workPanel = 'y'
    model.viewUrls.issuedUrl = 'u'

    clearDocument(model)

    expect(revoke.mock.calls.map(([u]) => u)).toEqual(['blob:a', 'blob:b'])
    expect(model.images).toEqual({})
    expect(model.imageInflight.size).toBe(0)
    expect(model.selectedRun).toBeNull()
    expect(model.details.size).toBe(0)
    expect(model.pendingRunId).toBeNull()
    expect(model.runs).toEqual([])
    expect(draftCount(model.draft)).toBe(0)
    expect(model.activeId).toBeNull()
    expect(model.activeTab).toBe('result')
    expect(model.errors).toEqual({
      public: null,
      document: null,
      workPanel: null,
    })
    expect(model.viewUrls.issuedUrl).toBeNull()
    // @ts-expect-error jsdom に無いメソッドを仮設したため削除して戻す
    delete URL.revokeObjectURL
  })
})
