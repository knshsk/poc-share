import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import StartDialog from '../src/components/StartDialog.vue'
import { BUBBLE } from '../src/mediator/bubble'
import { createAppVuetify } from '../src/plugins/vuetify'
import { registerVm } from './fixtures'

const bubble = vi.fn()

function mountDialog() {
  return mount(StartDialog, {
    props: { vm: registerVm() },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// v-dialogの内容はbodyへteleportされるためdocumentから探す
function q<T extends Element = HTMLElement>(selector: string): T | null {
  return document.querySelector<T>(selector)
}

async function openViewTab() {
  q('[data-testid="start-tab-view"]')!.click()
  await flushPromises()
}

enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('StartDialog', () => {
  // 初期表示は「文書を登録」タブで、登録フォームに vm を渡し文書ID参照欄は出さない
  it('初期表示は登録タブで登録フォームを表示する', () => {
    const wrapper = mountDialog()
    expect(q('[data-testid="start-tab-register"]')).not.toBeNull()
    expect(q('[data-testid="start-tab-view"]')).not.toBeNull()
    expect(wrapper.findComponent(DocumentRegisterForm).props('vm')).toEqual(
      registerVm(),
    )
    expect(q('[data-testid="document-id-input"]')).toBeNull()
  })

  // 参照タブへ切り替えると文書ID入力欄を表示し、入力欄へフォーカスする
  it('参照タブ切替で文書ID入力欄を表示しフォーカスする', async () => {
    mountDialog()
    await openViewTab()
    const input = q<HTMLInputElement>('[data-testid="document-id-input"] input')
    expect(input).not.toBeNull()
    expect(document.activeElement).toBe(input)
  })

  it('文書ID未入力では参照ボタンを無効化する', async () => {
    mountDialog()
    await openViewTab()
    const button = q<HTMLButtonElement>('[data-testid="document-id-apply"]')!
    expect(button.disabled).toBe(true)

    const input = q<HTMLInputElement>(
      '[data-testid="document-id-input"] input',
    )!
    input.value = 'doc-1'
    input.dispatchEvent(new Event('input'))
    await flushPromises()
    expect(button.disabled).toBe(false)
  })

  // 参照ボタンで入力した文書IDを openDocument として bubble する
  it('参照で入力した文書IDを openDocument で bubble する', async () => {
    mountDialog()
    await openViewTab()
    const input = q<HTMLInputElement>(
      '[data-testid="document-id-input"] input',
    )!
    input.value = 'doc-1'
    input.dispatchEvent(new Event('input'))
    await flushPromises()
    q('[data-testid="document-id-apply"]')!.click()
    await flushPromises()
    expect(bubble).toHaveBeenCalledWith({
      type: 'openDocument',
      documentId: 'doc-1',
    })
  })
})
