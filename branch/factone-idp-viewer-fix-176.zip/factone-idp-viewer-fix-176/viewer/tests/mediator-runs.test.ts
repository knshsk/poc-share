import { flushPromises } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
  setAccessToken: vi.fn(),
}))

import { createMediator, type Mediator } from '../src/mediator/machine'
import type { IdpRun } from '../src/utils/runs'
import {
  correctedRun,
  failedRun,
  fakeOidc,
  routeGet,
  succeededRun,
  toSummary,
} from './fixtures'

// 文書 doc-1 を開いて履歴取得まで済ませた Mediator
async function opened(runs: IdpRun[] = []): Promise<Mediator> {
  getMock.mockImplementation(routeGet(runs))
  const m = createMediator(fakeOidc())
  m.state.value = 'start'
  m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
  await flushPromises()
  return m
}

const wp = (m: Mediator) => m.vm.value.document!.workPanel!
const detailCalls = () =>
  getMock.mock.calls.filter(
    ([path]) => path === '/api/v1/documents/{document_id}/idp-runs/{run_id}',
  )

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
})

describe('Mediator（実行履歴と選択）', () => {
  // 文書表示後に一覧を取得し、最新（API 応答の末尾）の詳細を verbose で取得して表示する
  it('文書表示後に一覧を取得し、最新実行の詳細を verbose で取得する', async () => {
    const m = await opened([succeededRun, failedRun])

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs',
      expect.objectContaining({ params: { path: { document_id: 'doc-1' } } }),
    )
    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}',
      expect.objectContaining({
        params: {
          path: { document_id: 'doc-1', run_id: failedRun.run_id },
          query: { verbose: true },
        },
      }),
    )
    expect(wp(m).runs.map((r) => r.run_id)).toEqual([
      failedRun.run_id,
      succeededRun.run_id,
    ])
    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)
    expect(wp(m).editor).toBeNull()
    expect(wp(m).loadingRuns).toBe(false)
  })

  // 一覧の応答後、最初の詳細を待っている間も loadingRuns を立てる（結果のある文書で
  // 「実行結果がありません」を一瞬出さないため）
  it('一覧の応答後、最初の詳細を待つ間も loadingRuns を立てる', async () => {
    let resolveDetail: (v: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return Promise.resolve({
          data: { document_id: 'doc-1', runs: [toSummary(succeededRun)] },
          error: undefined,
        })
      }
      if (path === '/api/v1/documents/{document_id}/idp-runs/{run_id}') {
        return new Promise((resolve) => {
          resolveDetail = resolve
        })
      }
      return routeGet()(path)
    })
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(wp(m).selectedRun).toBeNull()
    expect(wp(m).loadingRuns).toBe(true)

    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()
    expect(wp(m).selectedRun?.run_id).toBe(succeededRun.run_id)
    expect(wp(m).loadingRuns).toBe(false)
  })

  // 実行 0 件の文書は最初の詳細取得が発生しないため loadingRuns を立てない（noRuns の塗りボタンが出る）
  it('実行 0 件の文書では loadingRuns を立てない', async () => {
    const m = await opened([])
    expect(wp(m).runs).toEqual([])
    expect(wp(m).loadingRuns).toBe(false)
  })

  it('一覧取得失敗は「実行履歴を取得できませんでした」', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/idp-runs'
        ? Promise.resolve({ data: undefined, error: { status: 500 } })
        : routeGet()(path),
    )
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(wp(m).error).toBe('実行履歴を取得できませんでした')
    expect(wp(m).loadingRuns).toBe(false)
    expect(wp(m).runsLoadFailed).toBe(true)
  })

  // 取得失敗フラグは一覧の取得に成功した文書・切り替えた先の文書へ持ち越さない
  it('runsLoadFailed は取得成功と文書切替で false に戻る', async () => {
    expect(wp(await opened([succeededRun])).runsLoadFailed).toBe(false)

    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/idp-runs'
        ? Promise.resolve({ data: undefined, error: { status: 500 } })
        : routeGet()(path),
    )
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(wp(m).runsLoadFailed).toBe(true)

    getMock.mockImplementation(routeGet([succeededRun]))
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()
    expect(wp(m).runsLoadFailed).toBe(false)
  })

  it('履歴選択で詳細を取得し、成功実行なら editor を出す', async () => {
    const m = await opened([succeededRun, failedRun])
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    await flushPromises()

    expect(wp(m).selectedRun?.run_id).toBe(succeededRun.run_id)
    expect(wp(m).editor?.run.run_id).toBe(succeededRun.run_id)
    expect(wp(m).activeTab).toBe('result')
  })

  it('詳細取得失敗は「実行結果を取得できませんでした」', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/idp-runs'
        ? Promise.resolve({
            data: { document_id: 'doc-1', runs: [toSummary(succeededRun)] },
            error: undefined,
          })
        : path === '/api/v1/documents/{document_id}/idp-runs/{run_id}'
          ? Promise.resolve({ data: undefined, error: { status: 500 } })
          : routeGet()(path),
    )
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(wp(m).error).toBe('実行結果を取得できませんでした')
    // 詳細の取得に失敗したらエラー表示に譲る（loadingRuns は立てたままにしない）
    expect(wp(m).loadingRuns).toBe(false)
  })

  it('取得済みの詳細はキャッシュし再取得しない', async () => {
    const m = await opened([succeededRun, failedRun])
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    await flushPromises()
    m.dispatch({ type: 'selectRun', runId: failedRun.run_id })
    await flushPromises()
    expect(detailCalls()).toHaveLength(2)
  })

  // 応答待ちの間に別の実行を選択した場合、遅れて届いた古い応答で表示を上書きしない
  it('応答待ち中に別の実行を選択した場合は古い応答を捨てる', async () => {
    let resolveDetail: (v: unknown) => void = () => {}
    getMock.mockImplementation(
      (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
        if (path === '/api/v1/documents/{document_id}/idp-runs') {
          return Promise.resolve({
            data: {
              document_id: 'doc-1',
              runs: [succeededRun, failedRun].map(toSummary),
            },
            error: undefined,
          })
        }
        if (options?.params?.path?.run_id === succeededRun.run_id) {
          return new Promise((resolve) => {
            resolveDetail = resolve
          })
        }
        return routeGet([failedRun])(path, options)
      },
    )
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()

    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    m.dispatch({ type: 'selectRun', runId: failedRun.run_id })
    await flushPromises()
    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()

    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)
  })

  // 確認ダイアログ表示中も完了イベントは受ける（捨てると表示中の実行が古いまま固着する）
  it('confirmDiscard 中に届いた詳細応答も受け取る', async () => {
    let resolveDetail: (v: unknown) => void = () => {}
    getMock.mockImplementation(
      (path: string, options?: { params?: { path?: { run_id?: string } } }) => {
        if (path === '/api/v1/documents/{document_id}/idp-runs') {
          return Promise.resolve({
            data: {
              document_id: 'doc-1',
              runs: [succeededRun, failedRun].map(toSummary),
            },
            error: undefined,
          })
        }
        if (options?.params?.path?.run_id === succeededRun.run_id) {
          return new Promise((resolve) => {
            resolveDetail = resolve
          })
        }
        return routeGet([failedRun])(path, options)
      },
    )
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)

    // succeededRun の詳細取得を保留したまま、選択中の failedRun に下書きを作って executeIdp で確認ダイアログへ
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    m.dispatch({ type: 'executeIdp' })
    expect(m.state.value).toBe('confirmDiscard')

    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()

    expect(wp(m).selectedRun?.run_id).toBe(succeededRun.run_id)
    expect(m.state.value).toBe('confirmDiscard')
  })
})

describe('Mediator（IDP 実行）', () => {
  it('executeIdp は verbose で POST し、応答を選択して履歴の先頭へ入れる', async () => {
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })
    const m = await opened([failedRun])

    m.dispatch({ type: 'executeIdp' })
    expect(m.state.value).toBe('executing')
    expect(wp(m).executing).toBe(true)
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1' }, query: { verbose: true } },
      }),
    )
    expect(m.state.value).toBe('document')
    expect(wp(m).runs.map((r) => r.run_id)).toEqual([
      succeededRun.run_id,
      failedRun.run_id,
    ])
    expect(wp(m).editor?.run.run_id).toBe(succeededRun.run_id)
    expect(wp(m).activeTab).toBe('result')
  })

  it('POST 失敗・ネットワーク例外は「IDP実行に失敗しました」で document へ戻る', async () => {
    postMock.mockResolvedValue({ data: undefined, error: { detail: 'x' } })
    const a = await opened()
    a.dispatch({ type: 'executeIdp' })
    await flushPromises()
    expect(a.state.value).toBe('document')
    expect(wp(a).error).toBe('IDP実行に失敗しました')

    postMock.mockRejectedValue(new Error('network'))
    const b = await opened()
    b.dispatch({ type: 'executeIdp' })
    await flushPromises()
    expect(wp(b).error).toBe('IDP実行に失敗しました')
  })

  // 一覧取得中に IDP 実行が完了した場合、遅れて届く一覧応答で選択・表示中の実行を上書きせずマージする
  it('一覧取得中に IDP 実行が完了した場合は選択を維持して一覧をマージする', async () => {
    let resolveList: (v: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return new Promise((resolve) => {
          resolveList = resolve
        })
      }
      return routeGet()(path)
    })
    postMock.mockResolvedValue({ data: succeededRun, error: undefined })
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()

    m.dispatch({ type: 'executeIdp' })
    await flushPromises()
    resolveList({
      data: { document_id: 'doc-1', runs: [toSummary(failedRun)] },
      error: undefined,
    })
    await flushPromises()

    expect(wp(m).selectedRun?.run_id).toBe(succeededRun.run_id)
    expect(wp(m).runs.map((r) => r.run_id)).toEqual([
      succeededRun.run_id,
      failedRun.run_id,
    ])
  })

  // IDP 実行の応答後に、それ以前に要求した詳細取得の応答が届いても上書きしない（#114 持ち越し）
  it('IDP 実行後に遅れて届いた詳細応答で表示を上書きしない', async () => {
    let resolveDetail: (v: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}/idp-runs') {
        return Promise.resolve({
          data: { document_id: 'doc-1', runs: [toSummary(succeededRun)] },
          error: undefined,
        })
      }
      if (path === '/api/v1/documents/{document_id}/idp-runs/{run_id}') {
        return new Promise((resolve) => {
          resolveDetail = resolve
        })
      }
      return routeGet()(path)
    })
    postMock.mockResolvedValue({ data: failedRun, error: undefined })
    const m = createMediator(fakeOidc())
    m.state.value = 'start'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    m.dispatch({ type: 'executeIdp' })
    await flushPromises()
    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)

    resolveDetail({ data: succeededRun, error: undefined })
    await flushPromises()
    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)
  })

  // 裁定: 実行中は二重実行・履歴選択・文書切替を受けない
  it('executing 中は executeIdp / selectRun / openDocument を無視する', async () => {
    postMock.mockImplementation(() => new Promise(() => {}))
    const m = await opened([succeededRun])
    m.dispatch({ type: 'executeIdp' })
    m.dispatch({ type: 'executeIdp' })
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()

    expect(postMock).toHaveBeenCalledTimes(1)
    expect(m.state.value).toBe('executing')
    expect(m.vm.value.header.documentId).toBe('doc-1')
  })
})

describe('Mediator（下書きと確定）', () => {
  it('fieldInput / cellInput で差分が増減し、discardDraft で消える', async () => {
    const m = await opened([succeededRun])
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    expect(wp(m).draftCount).toBe(1)
    expect(wp(m).editor?.draftFields).toEqual({ order_no: 'A-002' })
    expect(m.vm.value.dirty).toBe(true)

    m.dispatch({ type: 'cellInput', table: 0, row: 0, column: 0, value: 'x' })
    expect(wp(m).editor?.draftCells).toEqual({ '0:0:0': 'x' })
    expect(wp(m).draftCount).toBe(2)

    // 元値（正規化値）に戻すと差分から外れる。存在しないセルは無視
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-001' })
    m.dispatch({ type: 'cellInput', table: 0, row: 9, column: 9, value: 'y' })
    expect(wp(m).draftCount).toBe(1)

    m.dispatch({ type: 'discardDraft' })
    expect(wp(m).draftCount).toBe(0)
    expect(m.vm.value.dirty).toBe(false)
  })

  it('confirmCorrections で差分を POST し、応答の修正行を選択・履歴追加し、下書きをリセットしてスナックバーを出す', async () => {
    postMock.mockResolvedValue({ data: correctedRun, error: undefined })
    const m = await opened([succeededRun])
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })

    m.dispatch({ type: 'confirmCorrections' })
    expect(m.state.value).toBe('saving')
    expect(wp(m).saving).toBe(true)
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections',
      expect.objectContaining({
        params: {
          path: { document_id: 'doc-1', run_id: succeededRun.run_id },
          query: { verbose: true },
        },
        body: { fields: { order_no: 'A-002' }, table_cells: [] },
      }),
    )
    expect(m.state.value).toBe('document')
    expect(wp(m).selectedRun?.run_id).toBe(correctedRun.run_id)
    expect(wp(m).runs[0]?.run_id).toBe(correctedRun.run_id)
    expect(wp(m).draftCount).toBe(0)
    expect(wp(m).savedSnackbar).toBe(true)

    m.dispatch({ type: 'snackbarClosed' })
    expect(wp(m).savedSnackbar).toBe(false)
  })

  it('確定失敗は「修正の保存に失敗しました」で下書きを保持する', async () => {
    postMock.mockResolvedValue({ data: undefined, error: { status: 422 } })
    const m = await opened([succeededRun])
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    m.dispatch({ type: 'confirmCorrections' })
    await flushPromises()

    expect(m.state.value).toBe('document')
    expect(wp(m).error).toBe('修正の保存に失敗しました')
    expect(wp(m).draftCount).toBe(1)
  })

  it('変更なしの confirmCorrections と saving 中の再送は無視する', async () => {
    postMock.mockImplementation(() => new Promise(() => {}))
    const m = await opened([succeededRun])
    m.dispatch({ type: 'confirmCorrections' })
    expect(postMock).not.toHaveBeenCalled()

    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    m.dispatch({ type: 'confirmCorrections' })
    m.dispatch({ type: 'confirmCorrections' })
    expect(postMock).toHaveBeenCalledTimes(1)
    expect(m.state.value).toBe('saving')
  })
})

describe('Mediator（未保存ガード）', () => {
  it('未保存の変更がある履歴選択は confirmDiscard になり、cancel で維持・proceed で破棄して続行する', async () => {
    const m = await opened([succeededRun, failedRun])
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    await flushPromises()
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })

    m.dispatch({ type: 'selectRun', runId: failedRun.run_id })
    expect(m.state.value).toBe('confirmDiscard')
    expect(wp(m).confirmDiscard).toBe(true)
    expect(wp(m).activeTab).toBe('result')
    expect(wp(m).selectedRun?.run_id).toBe(succeededRun.run_id)

    m.dispatch({ type: 'confirmCancel' })
    expect(m.state.value).toBe('document')
    expect(wp(m).draftCount).toBe(1)
    expect(wp(m).selectedRun?.run_id).toBe(succeededRun.run_id)

    m.dispatch({ type: 'selectRun', runId: failedRun.run_id })
    m.dispatch({ type: 'confirmProceed' })
    await flushPromises()
    expect(m.state.value).toBe('document')
    expect(wp(m).draftCount).toBe(0)
    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)
  })

  it('未保存の変更がある IDP 実行と文書切替も confirmDiscard を挟む', async () => {
    postMock.mockResolvedValue({ data: failedRun, error: undefined })
    const m = await opened([succeededRun])
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })

    m.dispatch({ type: 'executeIdp' })
    expect(postMock).not.toHaveBeenCalled()
    m.dispatch({ type: 'confirmProceed' })
    await flushPromises()
    expect(postMock).toHaveBeenCalledTimes(1)
    expect(wp(m).selectedRun?.run_id).toBe(failedRun.run_id)

    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    expect(m.state.value).toBe('confirmDiscard')
    expect(m.vm.value.header.documentId).toBe('doc-1')
    m.dispatch({ type: 'confirmProceed' })
    expect(m.vm.value.header.documentId).toBe('doc-2')
    expect(m.state.value).toBe('loadingDocument')
  })

  // 裁定: ダイアログ表示中は confirmProceed / confirmCancel 以外の操作を受けない（画像完了は受ける）
  it('confirmDiscard 中は executeIdp を無視し、pageImageLoaded は受ける', async () => {
    URL.createObjectURL = vi.fn().mockReturnValue('blob:late')
    postMock.mockResolvedValue({ data: failedRun, error: undefined })
    const m = await opened([succeededRun])
    m.dispatch({ type: 'pageVisible', page: 1 })
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-002' })
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    expect(m.state.value).toBe('confirmDiscard')

    m.dispatch({ type: 'executeIdp' })
    expect(postMock).not.toHaveBeenCalled()
    await flushPromises()
    expect(m.vm.value.document?.canvas?.images).toEqual({ 1: 'blob:late' })
    // @ts-expect-error jsdom に無いメソッドを仮設したため削除して戻す
    delete URL.createObjectURL
  })
})

describe('Mediator（相互ハイライト・タブ）', () => {
  it('rectClick は activeId と読取結果タブへの切替とペインへの連番付き要求', async () => {
    const m = await opened([succeededRun])
    m.dispatch({ type: 'tabChanged', tab: 'history' })
    expect(wp(m).activeTab).toBe('history')

    m.dispatch({ type: 'rectClick', id: 'cell:0:0:0' })
    expect(wp(m).activeTab).toBe('result')
    expect(wp(m).editor?.activeId).toBe('cell:0:0:0')
    expect(wp(m).editor?.focusRequest).toEqual({ id: 'cell:0:0:0', seq: 1 })
    expect(m.vm.value.document?.canvas?.activeId).toBe('cell:0:0:0')

    m.dispatch({ type: 'rectClick', id: 'cell:0:0:0' })
    expect(wp(m).editor?.focusRequest?.seq).toBe(2)
  })

  it('targetFocus は activeId とキャンバスへの連番付き要求', async () => {
    const m = await opened([succeededRun])
    m.dispatch({ type: 'targetFocus', id: 'field:order_no' })
    expect(m.vm.value.document?.canvas).toMatchObject({
      activeId: 'field:order_no',
      scrollRequest: { id: 'field:order_no', seq: 1 },
    })
    expect(wp(m).editor?.focusRequest).toBeNull()
  })

  // 選択はフォーカスが外れても維持し、履歴選択・IDP 実行・確定で解除する
  it('履歴選択・IDP 実行・確定で activeId を解除する', async () => {
    postMock.mockResolvedValue({ data: correctedRun, error: undefined })
    const m = await opened([succeededRun, failedRun])
    m.dispatch({ type: 'targetFocus', id: 'field:order_no' })
    m.dispatch({ type: 'selectRun', runId: succeededRun.run_id })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.activeId).toBeNull()

    m.dispatch({ type: 'targetFocus', id: 'field:order_no' })
    m.dispatch({ type: 'executeIdp' })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.activeId).toBeNull()

    m.dispatch({ type: 'targetFocus', id: 'field:order_no' })
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-009' })
    m.dispatch({ type: 'confirmCorrections' })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.activeId).toBeNull()
  })
})
