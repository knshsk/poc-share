# Viewer 開発ガイド

フロントエンド（`viewer/`）の起動・テスト実行手順。

## 前提条件

- Node.js 24（LTS）がインストールされていること

WSL2環境では [nvm](https://github.com/nvm-sh/nvm) でのインストールを推奨する。

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
nvm install --lts
```

## セットアップ

```bash
cd viewer
npm install
```

## 起動（開発サーバ）

```bash
cd viewer
npm run dev
```

表示されたURL（既定: `http://localhost:5173/`）にアクセスして画面が表示されれば成功。

## テスト実行

```bash
cd viewer
npm run test
```

Vitest + Vue Test Utils を使用している。設定は `viewer/vitest.config.ts` を参照。

## ビルド

```bash
cd viewer
npm run build
```

型検査（vue-tsc）とプロダクションビルドを実行し、`viewer/dist/` に成果物を出力する。

## 構成メモ

- フレームワーク: Vue 3 + TypeScript（Vite）
- UI: Vuetify（`src/main.ts` でプラグイン登録）。アイコンは Phosphor Icons
- 状態管理: Pinia は使わない。`src/mediator/` のステートマシン（`createMediator()`）が状態・API 呼出・裁定を持ち、各コンポーネントは `vm` prop と `useBubble()` だけで動く Passive View（[architecture/viewer.md](../architecture/viewer.md)、[ADR-0023](../adr/0023-viewer-root-passive-view-mediator.md)）
