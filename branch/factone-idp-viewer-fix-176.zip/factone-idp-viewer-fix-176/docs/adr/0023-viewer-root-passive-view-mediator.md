---
status: accepted
date: 2026-09-17
---

# Viewer を Root 階層 + Passive View + Chain of Responsibility + ステートマシン Mediator で構成する

## 背景

Viewer は 10 コンポーネントと 4 つの Pinia ストアから成り、API 呼出（17 箇所）・状態フラグ（25 個）・非同期のレース裁定が 6 コンポーネントに散在していた。`WorkPanel` が事実上のコントローラ（一覧・詳細取得・キャッシュ・未保存ガード・`beforeunload`）になり、木を横断する連携はストア経由で暗黙化していた（`draft.guard` の発火は `AppHeader` と `WorkPanel`、解決ダイアログは `WorkPanel`。`highlight` の連番付き要求を 3 コンポーネントが `watch`）。画面遷移は `App.vue` のパス分岐と `document.documentId / loadedDocumentId` の二相が暗黙のステートマシンを成し、どの状態でどの操作を受けるかがコードから読み取れなかった。

## 決定

- 全コンポーネントを `Root.vue` を頂点とする 1 本の階層に置く（`Root → AppHeader / LoginView / PublicView / DocumentView → …`）
- 各コンポーネントは MVP の Passive View とする。入力は自分用の ViewModel 型 1 つを `vm` prop で受け、親が部分を子へ渡す。出力は `useBubble()` が返す `bubble(event)` だけ。描画だけに関わる状態（ズーム・スクロール位置・区分の開閉・送信前のフォーム入力値）は View が持ち、API 呼出・`URL.createObjectURL`・clipboard・`history`・`window` イベントは持たない
- 操作は Chain of Responsibility で階層を上へバブリングさせる。`useBubble(handle?)` は `provide/inject` で直近祖先の `bubble` を受け取り、自ノードの `handle` が `true` を返せば停止、それ以外は親へ委譲する。`Root` が Mediator の `dispatch` を鎖の終点として provide する
- Mediator（`viewer/src/mediator/`）はステートマシンとして振る舞う。12 の状態（`booting / login / callback / public / start / registering / loadingDocument / documentError / document / executing / saving / confirmDiscard`）と、イベント型を主キーにした遷移表 `{ in: State[], run }` を持ち、`in` に現状態が無いイベントは黙って捨てる（裁定）。API 応答と OIDC 完了は内部完了イベントとして Mediator が自分へ dispatch し、状態遷移は完了イベント側で同期的に行う。古い応答は「状態が `in` の外」「スコープ（`documentId` / `token` / `runId`）不一致」の 2 段で捨てる。確認ダイアログ（`confirmDiscard`）表示中も API の完了イベントは受ける（`SETTLING`）
- ViewModel はスライスごとの `computed` で組み、変化した部分だけ参照が変わるようにする（draft 入力でキャンバスは再描画されない）
- Pinia は撤去する。4 ストアは Mediator のモデルと `auth/oidc.ts`（`oidc-client-ts` のラッパ）に吸収する

## 検討した代替案

- Pinia ストアを残して Mediator を足す — `draft.guard` / `highlight` のイベント化したストアが残り、View からストアを読む経路と vm の二重経路になる。却下
- emits の明示中継 — 鎖がテンプレートに見える利点はあるが、階層数 × 子数の再 emit が要る。却下
- DOM `CustomEvent` のバブリング — Vuetify の dialog / menu / snackbar は body へ Teleport され DOM の祖先関係が切れるため、Root に届かない。却下
- XState 等のステートマシンライブラリ — 12 状態・49 イベントの規模に対して依存追加が過剰。イベント主キーの表と `in` ガードで足りる。却下
- readonly のモデルを inject して View が読む — 中継は要らなくなるが View がモデルを直接読む Supervising Controller になり、Passive View から外れる。却下
- 単一 Pinia ストアを Mediator にする — devtools で状態を追えるが、View から `useMediator()` を呼べてしまい Passive View を構造的に強制できない。却下

## 影響

- View のテストは `vm` を与えて DOM を検証し、操作は provide したスパイへの `bubble` 呼出で検証する。挙動（レース・失敗・未保存ガード）のテストは Mediator 単体テスト（`tests/mediator-*.test.ts`）に集約する
- 裁定による挙動差: `executing` / `saving` 中の履歴選択・文書切替・再実行は無視する（従来はボタン無効化だけで履歴クリックとヘッダ切替が通っていた）。`beforeunload` の警告は `Root` が常時登録し `vm.dirty` で判定する。ヘッダで表示中と同じ文書 ID を再入力すると再取得する。loadingDocument / registering 中のヘッダからの文書切替は無視する（旧実装は取得中でも切り替えていた）
- 新しい操作を足すときは `mediator/events.ts` にイベントを追加し、`handlers/` に `{ in, run }` を書き、必要なら `vm.ts` に表示項目を足してから View を書く。View に API 呼出やストア参照を書かない
- Vue devtools でストアの状態を見ることはできなくなる。必要なら `Root` の `vm` を devtools のコンポーネント state から見る
