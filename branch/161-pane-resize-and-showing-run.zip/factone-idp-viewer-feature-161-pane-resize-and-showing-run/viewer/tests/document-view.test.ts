import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentCanvas from '../src/components/DocumentCanvas.vue'
import StartDialog from '../src/components/StartDialog.vue'
import WorkPanel from '../src/components/WorkPanel.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { DocumentVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import DocumentView from '../src/views/DocumentView.vue'
import { canvasVm, registerVm, workPanelVm } from './fixtures'

const bubble = vi.fn()

function mountView(over: Partial<DocumentVm> = {}) {
  return mount(DocumentView, {
    props: {
      vm: {
        phase: 'ready',
        error: null,
        register: registerVm(),
        canvas: canvasVm(),
        workPanel: workPanelVm(),
        ...over,
      },
    },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// ダイアログ内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentView', () => {
  // 文書ID未指定（start / registering）は開始ダイアログだけを表示し、登録フォームへ vm.register を渡す
  it('start / registering では開始ダイアログを表示しパネルを出さない', () => {
    for (const phase of ['start', 'registering'] as const) {
      const wrapper = mountView({ phase, canvas: null, workPanel: null })
      expect(wrapper.findComponent(StartDialog).props('vm')).toEqual(
        registerVm(),
      )
      expect(wrapper.findComponent(WorkPanel).exists()).toBe(false)
      expect(wrapper.findComponent(DocumentCanvas).exists()).toBe(false)
      wrapper.unmount()
    }
  })

  // 取得中は 2 ペインにスケルトンを出す
  it('loading では両ペインにスケルトンを表示する', () => {
    const wrapper = mountView({
      phase: 'loading',
      canvas: null,
      workPanel: null,
    })
    expect(wrapper.findAll('.v-skeleton-loader')).toHaveLength(2)
    expect(wrapper.findComponent(StartDialog).exists()).toBe(false)
  })

  // 文書取得失敗時はエラーstateと再試行ボタンを表示し、再試行で retryLoad を bubble する
  it('error ではエラーと再試行を表示し、再試行で retryLoad を bubble する', async () => {
    const wrapper = mountView({
      phase: 'error',
      error: '文書を取得できませんでした',
      canvas: null,
      workPanel: null,
    })
    expect(wrapper.get('[data-testid="document-error"]').text()).toContain(
      '文書を取得できませんでした',
    )
    await wrapper.get('[data-testid="document-retry"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'retryLoad' })
  })

  // 表示成功時に DocumentCanvas と WorkPanel へそれぞれの vm スライスを渡す
  it('ready では DocumentCanvas と WorkPanel に vm を渡す', () => {
    const canvas = canvasVm()
    const workPanel = workPanelVm({ shareable: true })
    const wrapper = mountView({ canvas, workPanel })
    expect(wrapper.findComponent(DocumentCanvas).props('vm')).toEqual(canvas)
    expect(wrapper.findComponent(WorkPanel).props('vm')).toEqual(workPanel)
    expect(wrapper.find('[data-testid="tab-urls"]').exists()).toBe(true)
  })

  describe('右ペインの幅', () => {
    // ResizeObserver の差し替えは、assert が途中で落ちても次のテストへ漏らさない
    afterEach(() => vi.unstubAllGlobals())

    // jsdom は要素サイズを持たないため、レイアウト幅（上限の計算元）を差し替える
    function mountSized(layoutWidth: number) {
      const wrapper = mountView()
      const layout = wrapper.get('.document-layout').element
      Object.defineProperty(layout, 'clientWidth', {
        value: layoutWidth,
        configurable: true,
      })
      layout.getBoundingClientRect = () =>
        ({ left: 0, right: layoutWidth }) as DOMRect
      return wrapper
    }
    const splitter = (wrapper: ReturnType<typeof mountView>) =>
      wrapper.get('[data-testid="pane-splitter"]')
    const width = (wrapper: ReturnType<typeof mountView>) =>
      splitter(wrapper).attributes('aria-valuenow')

    it('既定は 528px で、境界は separator として操作できる', () => {
      const wrapper = mountSized(1440)
      const s = splitter(wrapper)
      expect(s.attributes()).toMatchObject({
        role: 'separator',
        'aria-orientation': 'vertical',
        'aria-label': '右ペインの幅',
        'aria-controls': 'work-pane',
        'aria-valuenow': '528',
        'aria-valuemin': '400',
        tabindex: '0',
      })
      expect(wrapper.find('#work-pane').exists()).toBe(true)
      // 幅は CSS 変数で渡す（列定義は stylesheet 側）
      expect(wrapper.get('.document-layout').attributes('style')).toContain(
        '--pane-width: 528px',
      )
    })

    it('←で広げ、→で狭め、ダブルクリックで既定に戻す', async () => {
      const wrapper = mountSized(1440)
      await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('544')
      await splitter(wrapper).trigger('keydown', { key: 'ArrowRight' })
      await splitter(wrapper).trigger('keydown', { key: 'ArrowRight' })
      expect(width(wrapper)).toBe('512')
      await splitter(wrapper).trigger('dblclick')
      expect(width(wrapper)).toBe('528')
    })

    it('最小 400px と、キャンバスが 320px 残る幅で止まる', async () => {
      const wrapper = mountSized(1000) // 上限 = 1000 - 326 = 674
      for (let i = 0; i < 20; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowRight' })
      expect(width(wrapper)).toBe('400')
      for (let i = 0; i < 40; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('674')
      expect(splitter(wrapper).attributes('aria-valuemax')).toBe('674')
    })

    // 幅を広げた後でウィンドウを縮めたら、状態も上限へ丸める（CSS の min() で実効幅だけが縮み、
    // aria-valuenow と→キーの起点が実際の幅と食い違うのを防ぐ）
    it('レイアウトが縮んだら現在幅を上限へ丸める', async () => {
      // DocumentCanvas も自身のスクローラに ResizeObserver を使う（mount で実体を持つ）ため、
      // 単一のコールバック変数だと後勝ちで DocumentCanvas 側に上書きされる。observe() 対象の
      // 要素で紐付け、.document-layout を監視しているコールバックだけを取り出す
      const observed = new Map<Element, () => void>()
      vi.stubGlobal(
        'ResizeObserver',
        class {
          callback: () => void
          constructor(callback: () => void) {
            this.callback = callback
          }
          observe(el: Element): void {
            observed.set(el, this.callback)
          }
          disconnect(): void {}
        },
      )
      const wrapper = mountSized(1440)
      for (let i = 0; i < 40; i++)
        await splitter(wrapper).trigger('keydown', { key: 'ArrowLeft' })
      expect(width(wrapper)).toBe('1114')

      const layoutEl = wrapper.get('.document-layout').element
      Object.defineProperty(layoutEl, 'clientWidth', {
        value: 1100,
        configurable: true,
      })
      observed.get(layoutEl)?.()
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('774')
      expect(splitter(wrapper).attributes('aria-valuemax')).toBe('774')
    })

    // ドラッグ: 幅 = レイアウト右端 − ポインタ位置 − 境界の半分。離したら追従をやめる
    it('ドラッグでポインタ位置に合わせて幅を変える', async () => {
      const wrapper = mountSized(1440)
      const el = splitter(wrapper).element as HTMLElement
      el.setPointerCapture = vi.fn()
      await splitter(wrapper).trigger('pointerdown', { pointerId: 1 })
      expect(el.setPointerCapture).toHaveBeenCalledWith(1)
      el.dispatchEvent(new MouseEvent('pointermove', { clientX: 800 }))
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('637')
      el.dispatchEvent(new Event('lostpointercapture'))
      el.dispatchEvent(new MouseEvent('pointermove', { clientX: 600 }))
      await wrapper.vm.$nextTick()
      expect(width(wrapper)).toBe('637')
    })
  })
})
