import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { defineComponent } from 'vue'

import AppHeader from '../src/components/AppHeader.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { HeaderVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { headerVm } from './fixtures'

const bubble = vi.fn()

// v-app-barはVuetifyレイアウト（v-app）配下が必要なためProbeで包む
const Probe = defineComponent({
  components: { AppHeader },
  props: { vm: { type: Object, required: true } },
  template: '<v-app><AppHeader :vm="vm" /></v-app>',
})

function mountHeader(over: Partial<HeaderVm> = {}) {
  return mount(Probe, {
    props: { vm: headerVm(over) },
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// メニューの内容はbodyへteleportされるため、テスト間で残らないようunmountする
enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('AppHeader', () => {
  it('プロダクト名とユーザー名を表示する', () => {
    const wrapper = mountHeader()
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.text()).toContain('sales01')
  })

  it('ログアウトボタンで logout を bubble する', async () => {
    const wrapper = mountHeader()
    await wrapper.get('[data-testid="user-menu"]').trigger('click')
    // v-menuの内容はteleportされるためdocumentから探す
    const logoutBtn = document.querySelector('[data-testid="logout"]')
    expect(logoutBtn).not.toBeNull()
    ;(logoutBtn as HTMLElement).click()
    expect(bubble).toHaveBeenCalledWith({ type: 'logout' })
  })

  // 文書タイトル: 原本ファイル名が主表示。文書 ID は小さく添える
  it('原本ファイル名を主表示にし、文書 ID と種別チップを添える', () => {
    const wrapper = mountHeader({
      documentId: 'doc-1',
      documentName: '見積書 A.pdf',
      documentTypeLabel: 'カスタム注文書',
    })
    const name = wrapper.get('[data-testid="header-document-name"]')
    expect(name.text()).toBe('見積書 A.pdf')
    // 長い名前は省略記号で切るため、全文を title に入れる
    expect(name.attributes('title')).toBe('見積書 A.pdf')
    const title = wrapper.get('[data-testid="header-document-id"]')
    expect(title.text()).toContain('doc-1')
    expect(
      wrapper.get('[data-testid="header-document-type"]').text(),
    ).toContain('カスタム注文書')
  })

  // ファイル名の無い文書・読込中は文書 ID を主表示にし、ID を二重に出さない
  it('原本ファイル名が無いときは文書 ID を主表示にする', () => {
    const wrapper = mountHeader({ documentId: 'doc-1', documentName: null })
    expect(wrapper.get('[data-testid="header-document-name"]').text()).toBe(
      'doc-1',
    )
    expect(
      wrapper.get('[data-testid="header-document-id"]').text().split('doc-1'),
    ).toHaveLength(2)
  })

  it('文書未指定では文書タイトルを出さない', () => {
    expect(
      mountHeader().find('[data-testid="header-document-id"]').exists(),
    ).toBe(false)
  })

  // 文書タイトル（種別チップを含む）は prepend 内に置く
  it('文書タイトル（種別チップを含む）は prepend 内に置く', () => {
    const wrapper = mountHeader({
      documentId: 'DOC-001',
      documentTypeLabel: '見積書',
    })
    const prepend = wrapper.get('.v-toolbar__prepend')
    expect(prepend.find('[data-testid="header-document-id"]').exists()).toBe(
      true,
    )
    expect(prepend.find('[data-testid="header-document-type"]').exists()).toBe(
      true,
    )
  })

  // 文書タイトルからの再入力は openDocument を bubble する（未保存ガードは Mediator）
  it('文書タイトルのメニューから文書IDを変更すると openDocument を bubble する', async () => {
    const wrapper = mountHeader({ documentId: 'doc-1' })
    await wrapper.get('[data-testid="header-document-id"]').trigger('click')
    const input = document.querySelector(
      '[data-testid="header-document-id-input"] input',
    ) as HTMLInputElement
    expect(input).not.toBeNull()
    expect(input.value).toBe('doc-1')
    input.value = 'doc-2'
    input.dispatchEvent(new Event('input'))
    ;(
      document.querySelector(
        '[data-testid="header-document-id-apply"]',
      ) as HTMLElement
    ).click()
    expect(bubble).toHaveBeenCalledWith({
      type: 'openDocument',
      documentId: 'doc-2',
    })
  })

  // 未認証（公開閲覧）ではロゴだけを表示し、ユーザーメニューを出さない（#149）
  it('未認証ではロゴのみ表示する', () => {
    const wrapper = mountHeader({ authenticated: false, username: null })
    expect(wrapper.text()).toContain('FactONE Viewer')
    expect(wrapper.find('[data-testid="user-menu"]').exists()).toBe(false)
  })
})
