<script setup lang="ts">
import { PhCaretDown, PhSignOut, PhUserCircle } from '@phosphor-icons/vue'
import { ref } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { HeaderVm } from '../mediator/vm'

const props = defineProps<{ vm: HeaderVm }>()

const bubble = useBubble()
const editId = ref('')

function openEdit(): void {
  editId.value = props.vm.documentId
}

// 未保存の修正があるときの確認は Mediator が裁定する（confirmDiscard）
function applyEditId(): void {
  if (editId.value) {
    bubble({ type: 'openDocument', documentId: editId.value })
  }
}
</script>

<template>
  <v-app-bar flat border density="comfortable" color="surface">
    <template #prepend>
      <span class="app-logo text-primary">FactONE Viewer</span>

      <!-- 文書タイトル: 種別チップ + 原本ファイル名（無ければ文書 ID）+ 文書 ID。クリックで文書 ID を再入力する。
           prepend 内に置く（既定スロットだと prepend / append の auto margin に挟まれて中央に浮く） -->
      <template v-if="vm.documentId">
        <v-divider vertical inset class="mx-4" />
        <v-menu location="bottom" :close-on-content-click="false">
          <template #activator="{ props: menuProps }">
            <v-btn
              v-bind="menuProps"
              variant="text"
              class="text-none doc-title"
              data-testid="header-document-id"
              @click="openEdit"
            >
              <!-- 種別設定（display_name）を表示する。設定未取得時は種別コードをフォールバック表示 -->
              <v-chip
                v-if="vm.documentTypeLabel"
                size="small"
                color="primary"
                variant="tonal"
                class="mr-2"
                data-testid="header-document-type"
              >
                {{ vm.documentTypeLabel }}
              </v-chip>
              <span
                class="doc-name text-title-medium"
                :title="vm.documentName ?? vm.documentId"
                data-testid="header-document-name"
                >{{ vm.documentName ?? vm.documentId }}</span
              >
              <span
                v-if="vm.documentName"
                class="font-mono text-body-small text-secondary ml-3"
                >{{ vm.documentId }}</span
              >
              <PhCaretDown :size="14" class="ml-2 text-secondary" />
            </v-btn>
          </template>
          <v-card class="pa-3 d-flex ga-2" min-width="320">
            <v-text-field
              v-model="editId"
              label="文書ID"
              hide-details
              data-testid="header-document-id-input"
              @keyup.enter="applyEditId"
            />
            <v-btn
              color="primary"
              data-testid="header-document-id-apply"
              @click="applyEditId"
            >
              表示
            </v-btn>
          </v-card>
        </v-menu>
      </template>
    </template>

    <!-- 公開閲覧（/view/{token}）は未認証のためユーザーメニューを出さない（ロゴのみ） -->
    <template v-if="vm.authenticated" #append>
      <v-menu location="bottom end">
        <template #activator="{ props: menuProps }">
          <v-btn
            v-bind="menuProps"
            variant="text"
            data-testid="user-menu"
            class="text-none"
          >
            <PhUserCircle :size="20" class="mr-1" />
            {{ vm.username ?? '' }}
          </v-btn>
        </template>
        <v-list density="compact">
          <v-list-item data-testid="logout" @click="bubble({ type: 'logout' })">
            <template #prepend>
              <PhSignOut :size="18" class="mr-2" />
            </template>
            <v-list-item-title>ログアウト</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </template>
  </v-app-bar>
</template>

<style scoped>
.app-logo {
  /* app-bar の枠 1px + prepend の余白 4px と合わせて左端から 16px（フッターの左余白と揃える） */
  margin-left: 11px;
  font-weight: 700;
  font-size: 1rem;
  letter-spacing: 0.02em;
}

.doc-title {
  padding: 0 8px;
  min-width: 0;
}

/* 長いファイル名は省略記号で切る（全文は title 属性） */
.doc-name {
  max-width: 40vw;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
