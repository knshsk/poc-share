import { flushPromises } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
  setAccessToken: vi.fn(),
}))

import { createMediator, type Mediator } from '../src/mediator/machine'
import {
  configs,
  documentResponse,
  fakeOidc,
  routeGet,
  succeededRun,
} from './fixtures'

// 認証済みの文書なし（empty）から始める
function atEmpty(): Mediator {
  const m = createMediator(fakeOidc())
  m.state.value = 'empty'
  return m
}

async function opened(documentType = 'quotation'): Promise<Mediator> {
  getMock.mockImplementation(routeGet([], documentType))
  const m = atEmpty()
  m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
  await flushPromises()
  return m
}

const pdf = new File(['%PDF-1.4'], 'order.pdf', { type: 'application/pdf' })

// 登録の失敗応答。API が返す Problem Details の本文
const problems = {
  conflict: {
    type: '/errors/document-conflict',
    title: 'Document conflict',
    status: 409,
    detail: 'Document ID already registered with different content',
  },
  tooLong: {
    type: '/errors/validation-error',
    title: 'Validation error',
    status: 422,
    detail: 'Request validation failed',
    errors: [
      {
        loc: ['body', 'document_id'],
        msg: 'String should have at most 255 characters',
        type: 'string_too_long',
      },
    ],
  },
  invalidPath: {
    type: '/errors/validation-error',
    title: 'Validation error',
    status: 422,
    detail: 'document_id contains an invalid path segment',
  },
  notPdf: {
    type: '/errors/unsupported-media-type',
    title: 'Unsupported media type',
    status: 415,
    detail: 'Only PDF files are accepted',
  },
  invalidPdf: {
    type: '/errors/invalid-pdf',
    title: 'Invalid pdf',
    status: 422,
    detail: 'Failed to open PDF (corrupted or password-protected)',
  },
  unknownType: {
    type: '/errors/unknown-document-type',
    title: 'Unknown document type',
    status: 422,
    detail: 'Unknown document type for this tenant',
  },
  internal: {
    type: '/errors/internal-error',
    title: 'Internal error',
    status: 500,
    detail: 'Internal server error',
  },
}

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
  getMock.mockImplementation(routeGet())
  URL.createObjectURL = vi.fn().mockReturnValue('blob:mock')
  URL.revokeObjectURL = vi.fn()
})

afterEach(() => {
  // @ts-expect-error jsdom に無いメソッドを仮設したため削除して戻す
  delete URL.createObjectURL
  // @ts-expect-error 同上の理由
  delete URL.revokeObjectURL
})

describe('Mediator（文書）', () => {
  // 文書・ページ・種別設定を並行取得し、種別設定から表示名・shareable・fieldDefs を反映する
  it('openDocument で 3 API を並行取得し ready になる', async () => {
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.state.value).toBe('loadingDocument')
    expect(m.vm.value.document?.phase).toBe('loading')
    expect(m.vm.value.header.documentId).toBe('doc-1')
    await flushPromises()

    expect(getMock.mock.calls.map(([p]) => p)).toEqual(
      expect.arrayContaining([
        '/api/v1/documents/{document_id}',
        '/api/v1/documents/{document_id}/pages',
        '/api/v1/config/document-types',
      ]),
    )
    expect(m.state.value).toBe('document')
    const doc = m.vm.value.document!
    expect(doc.phase).toBe('ready')
    expect(doc.canvas).toMatchObject({
      pages: [{ width: 8.5, height: 11 }],
      downloadLabel: '原本ダウンロード',
    })
    expect(doc.workPanel?.shareable).toBe(true)
    expect(doc.canvas?.fieldDefs).toEqual([
      { key: 'total_amount', label: '合計金額', type: 'number', visible: true },
      { key: 'own_company', label: '自社名', type: 'string', visible: false },
    ])
    expect(m.vm.value.header.documentTypeLabel).toBe('御見積書')
  })

  // 設定取得失敗・設定に無い種別は表示名なし（種別コード）・shareable=false・全項目表示へ倒す（安全側）
  it('設定が無いときは種別コード表示・shareable=false・fieldDefs 空にフォールバックする', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/config/document-types'
        ? Promise.resolve({ data: undefined, error: { detail: 'x' } })
        : routeGet()(path),
    )
    const a = atEmpty()
    a.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(a.vm.value.header.documentTypeLabel).toBe('quotation')
    expect(a.vm.value.document?.workPanel?.shareable).toBe(false)
    expect(a.vm.value.document?.canvas?.fieldDefs).toEqual([])

    const b = await opened('unknown_type')
    expect(b.vm.value.header.documentTypeLabel).toBe('unknown_type')
    expect(b.vm.value.document?.workPanel?.shareable).toBe(false)
  })

  // 原本ファイル名はヘッダーの文書タイトルに使う。読込中とファイル名の無い文書は null（View が文書 ID を出す）
  it('原本ファイル名を header.documentName に渡す', async () => {
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.vm.value.header.documentName).toBeNull()
    await flushPromises()
    expect(m.vm.value.header.documentName).toBe('見積書 A.pdf')

    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}'
        ? Promise.resolve({
            data: documentResponse('quotation', null),
            error: undefined,
          })
        : routeGet()(path),
    )
    const noName = atEmpty()
    noName.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    // 読込に成功した上で null（失敗して document が無いだけでも null になるため、成功を確認する）
    expect(noName.state.value).toBe('document')
    expect(noName.vm.value.header.documentName).toBeNull()
  })

  it('同じ文書 ID を再入力すると再取得する', async () => {
    const m = await opened()
    const docCalls = () =>
      getMock.mock.calls.filter(
        ([p]) => p === '/api/v1/documents/{document_id}',
      ).length
    expect(docCalls()).toBe(1)

    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()

    expect(docCalls()).toBe(2)
    expect(m.state.value).toBe('document')
  })

  it('文書取得失敗はエラー state になり retryLoad で再取得する', async () => {
    getMock.mockImplementation(() =>
      Promise.resolve({ data: undefined, error: { detail: 'x' } }),
    )
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-x' })
    await flushPromises()

    expect(m.state.value).toBe('documentError')
    expect(m.vm.value.document).toMatchObject({
      phase: 'error',
      error: '文書を取得できませんでした',
    })

    getMock.mockImplementation(routeGet())
    m.dispatch({ type: 'retryLoad' })
    await flushPromises()
    expect(m.state.value).toBe('document')
    expect(m.vm.value.document?.error).toBeNull()
  })

  // 別文書へ切り替えた後に届いた古い応答（documentId 不一致）は捨てる
  it('切替後に届いた古い文書応答は捨てる', async () => {
    let resolveOld: (v: unknown) => void = () => {}
    getMock.mockImplementation((path: string) => {
      if (path === '/api/v1/documents/{document_id}') {
        return new Promise((resolve) => {
          resolveOld = resolve
        })
      }
      return routeGet()(path)
    })
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-old' })
    await flushPromises()
    const resolveFirst = resolveOld

    getMock.mockImplementation(routeGet())
    m.state.value = 'documentError'
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(m.state.value).toBe('document')

    resolveFirst({ data: { document_id: 'doc-old' }, error: undefined })
    await flushPromises()
    expect(m.vm.value.header.documentId).toBe('doc-1')
    expect(m.state.value).toBe('document')
  })

  it('文書切替で画像 URL を revoke し images を空にする', async () => {
    const m = await opened()
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.images).toEqual({ 1: 'blob:mock' })

    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()

    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:mock')
    expect(m.vm.value.document?.canvas?.images).toEqual({})
  })

  // 文書切替後に届いた古い画像応答は捨て、blob URL を作らない（リーク防止）
  it('切替後に届いた古い画像応答は blob URL を作らない', async () => {
    let resolveImage: (v: unknown) => void = () => {}
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages/{page}/image'
        ? new Promise((resolve) => {
            resolveImage = resolve
          })
        : routeGet()(path),
    )
    m.dispatch({ type: 'pageVisible', page: 1 })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()

    resolveImage({ data: new Blob(), error: undefined })
    await flushPromises()

    expect(URL.createObjectURL).not.toHaveBeenCalled()
    expect(m.vm.value.document?.canvas?.images).toEqual({})
  })

  it('認証済みの画像取得は /api/v1 系エンドポイントを使う', async () => {
    const m = await opened()
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/v1/documents/{document_id}/pages/{page}/image',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1', page: 1 } },
        parseAs: 'blob',
      }),
    )
  })

  // 画像の取得失敗はページごとに記録し、紙面に失敗を表示させる。文書の切替で消す
  it('画像取得の失敗を imageFailed に記録し、文書切替で消す', async () => {
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages/{page}/image'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet()(path),
    )
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({ 1: true })
    expect(m.vm.value.document?.canvas?.images).toEqual({})

    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({})
  })

  it('失敗したページを取り直して成功したら失敗の記録を消す', async () => {
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages/{page}/image'
        ? Promise.reject(new Error('network'))
        : routeGet()(path),
    )
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({ 1: true })

    getMock.mockImplementation(routeGet())
    m.dispatch({ type: 'pageVisible', page: 1 })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.images).toEqual({ 1: 'blob:mock' })
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({})
  })

  // 文書切替の後に届いた古い失敗応答は、新しい文書の失敗として記録しない
  it('切替後に届いた古い画像の失敗応答は記録しない', async () => {
    let rejectImage: (e: unknown) => void = () => {}
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages/{page}/image'
        ? new Promise((_, reject) => {
            rejectImage = reject
          })
        : routeGet()(path),
    )
    m.dispatch({ type: 'pageVisible', page: 1 })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    await flushPromises()

    rejectImage(new Error('late'))
    await flushPromises()
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({})
  })

  // 同じ文書を開き直す前に出した画像要求の応答は、開き直した後の紙面に反映しない（応答の順に依らない）
  async function reopenWithPendingImages(m: Mediator) {
    const pending: {
      resolve: (v: unknown) => void
      reject: (e: unknown) => void
    }[] = []
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages/{page}/image'
        ? new Promise((resolve, reject) => {
            pending.push({ resolve, reject })
          })
        : routeGet()(path),
    )
    m.dispatch({ type: 'pageVisible', page: 1 }) // 開き直す前の要求（応答待ちのまま）
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' }) // 同じ文書を開き直す
    await flushPromises()
    m.dispatch({ type: 'pageVisible', page: 1 }) // 開き直した後の要求
    const [before, after] = pending as [
      (typeof pending)[number],
      (typeof pending)[number],
    ]
    return { before, after }
  }

  it('開き直す前の画像要求が後から失敗しても、読込済みの紙面に失敗を出さない', async () => {
    const m = await opened()
    const { before, after } = await reopenWithPendingImages(m)
    after.resolve({ data: new Blob(), error: undefined })
    await flushPromises()
    before.reject(new Error('timeout'))
    await flushPromises()
    expect(m.vm.value.document?.canvas?.images).toEqual({ 1: 'blob:mock' })
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({})
  })

  it('開き直す前の画像要求が先に失敗しても、開き直した後の要求の成功を表示する', async () => {
    const m = await opened()
    const { before, after } = await reopenWithPendingImages(m)
    before.reject(new Error('timeout'))
    await flushPromises()
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({})
    after.resolve({ data: new Blob(), error: undefined })
    await flushPromises()
    expect(m.vm.value.document?.canvas?.images).toEqual({ 1: 'blob:mock' })
    expect(m.vm.value.document?.canvas?.imageFailed).toEqual({})
  })

  // 原本の取得に失敗しても文書の表示は変えず、通知で知らせる（未保存の修正も残る）
  it('原本の取得に失敗しても表示と未保存の修正を残し、失敗を通知する', async () => {
    getMock.mockImplementation(routeGet([succeededRun]))
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-009' })
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pdf'
        ? Promise.resolve({ data: undefined, error: {} })
        : routeGet([succeededRun])(path),
    )
    m.dispatch({ type: 'downloadOriginal' })
    await flushPromises()

    expect(m.state.value).toBe('document')
    expect(m.vm.value.document?.error).toBeNull()
    expect(m.vm.value.dirty).toBe(true)
    expect(m.vm.value.document?.canvas?.downloading).toBe(false)
    expect(m.vm.value.document?.canvas?.downloadFailed).toBe(true)

    m.dispatch({ type: 'snackbarClosed' })
    expect(m.vm.value.document?.canvas?.downloadFailed).toBe(false)
  })

  // 応答を待つ間の再要求は捨てる（連打で原本の取得要求を重ねない）。完了後は再び取得できる
  it('原本の応答を待つ間の downloadOriginal は捨て、完了後は再び取得する', async () => {
    const click = vi
      .spyOn(HTMLAnchorElement.prototype, 'click')
      .mockImplementation(() => {})
    let finishPdf: () => void = () => {}
    const m = await opened()
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pdf'
        ? new Promise((resolve) => {
            finishPdf = () =>
              resolve({
                data: new Blob(),
                error: undefined,
                response: { headers: new Headers() },
              })
          })
        : routeGet()(path),
    )
    const pdfRequests = () =>
      getMock.mock.calls.filter(
        ([path]) => path === '/api/v1/documents/{document_id}/pdf',
      ).length

    m.dispatch({ type: 'downloadOriginal' })
    m.dispatch({ type: 'downloadOriginal' })
    expect(pdfRequests()).toBe(1)
    expect(m.vm.value.document?.canvas?.downloading).toBe(true)

    finishPdf()
    await flushPromises()
    expect(click).toHaveBeenCalledTimes(1)
    expect(m.vm.value.document?.canvas?.downloading).toBe(false)
    m.dispatch({ type: 'downloadOriginal' })
    expect(pdfRequests()).toBe(2)
    click.mockRestore()
  })

  // 切替前の文書の原本取得が後から失敗しても、切替後の文書の表示は変えない（同じ文書の開き直しも区別する）
  it.each(['doc-2', 'doc-1'])(
    '%s を開いた後に届いた、開く前の原本取得の失敗は捨てる',
    async (documentId) => {
      let failPdf: () => void = () => {}
      const m = await opened()
      getMock.mockImplementation((path: string) =>
        path === '/api/v1/documents/{document_id}/pdf'
          ? new Promise((resolve) => {
              failPdf = () => resolve({ data: undefined, error: {} })
            })
          : routeGet()(path),
      )
      m.dispatch({ type: 'downloadOriginal' })
      m.dispatch({ type: 'openDocument', documentId })
      await flushPromises()
      expect(m.vm.value.document?.canvas?.downloading).toBe(false)

      failPdf()
      await flushPromises()
      expect(m.state.value).toBe('document')
      expect(m.vm.value.document?.error).toBeNull()
      expect(m.vm.value.document?.canvas?.downloadFailed).toBe(false)
    },
  )

  // 登録: multipart で POST し、成功したらその文書を開く
  it('register で multipart POST し、成功した文書を開く', async () => {
    postMock.mockResolvedValue({
      data: { document_id: 'doc-9', document_type: 'quotation' },
      error: undefined,
    })
    const m = atEmpty()
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    expect(m.state.value).toBe('registering')
    expect(m.vm.value.document?.picker.register.submitting).toBe(true)
    await flushPromises()

    const [path, options] = postMock.mock.calls[0]!
    expect(path).toBe('/api/v1/documents')
    const body = options.bodySerializer(options.body) as FormData
    expect(body).toBeInstanceOf(FormData)
    expect(body.get('document_id')).toBe('doc-9')
    expect(body.get('document_type')).toBe('quotation')
    expect(body.get('file')).toBe(pdf)
    expect(m.vm.value.header.documentId).toBe('doc-9')
    expect(m.state.value).toBe('document')
  })

  // 失敗の種類は Problem Details の type で見分け、detail（API の英語の説明文）は出さない
  it('register の失敗は type ごとの文言、それ以外と例外は既定文言', async () => {
    const cases: [unknown, string][] = [
      [problems.conflict, '文書IDは別の内容で登録済みです'],
      [problems.tooLong, '文書IDは255文字以内で入力してください'],
      [problems.invalidPath, '文書IDに使用できない文字が含まれています'],
      [problems.notPdf, 'PDFではないファイルが選択されています'],
      [
        problems.invalidPdf,
        'PDFを開けません。壊れているか、閲覧パスワードが設定されています',
      ],
      [
        problems.unknownType,
        '選んだ書類種別は削除されています。書類種別を選び直してください',
      ],
      [problems.internal, '登録に失敗しました'],
    ]
    for (const [error, message] of cases) {
      postMock.mockResolvedValue({ data: undefined, error })
      const m = atEmpty()
      m.dispatch({
        type: 'register',
        documentId: 'doc-9',
        documentType: 'quotation',
        file: pdf,
      })
      await flushPromises()
      expect(m.state.value).toBe('empty')
      expect(m.vm.value.document?.picker.register.error).toBe(message)
    }

    postMock.mockRejectedValue(new Error('network'))
    const m = atEmpty()
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    await flushPromises()
    expect(m.vm.value.document?.picker.register.error).toBe(
      '登録に失敗しました',
    )
  })

  it('documentTypesLoaded は登録フォームの種別一覧になる', () => {
    const m = atEmpty()
    m.dispatch({
      type: 'documentTypesLoaded',
      items: [
        {
          type_code: 'quotation',
          display_name: '御見積書',
          shareable: true,
          fields: [],
          patterns: [],
          created_at: '',
          updated_at: '',
        },
      ],
    })
    expect(m.vm.value.document?.picker.register.typeItems).toHaveLength(1)
  })

  // 裁定: 取得中は openDocument / register を受けない
  it('loadingDocument 中は openDocument と register を無視する', async () => {
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-2' })
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    expect(m.vm.value.header.documentId).toBe('doc-1')
    expect(postMock).not.toHaveBeenCalled()
    await flushPromises()
    expect(m.state.value).toBe('document')
  })
})

describe('Mediator（文書選択ダイアログ）', () => {
  const typeCalls = () =>
    getMock.mock.calls.filter(
      ([path]) => path === '/api/v1/config/document-types',
    ).length

  it('openDocumentPicker / closeDocumentPicker で開閉する', () => {
    const m = atEmpty()
    expect(m.vm.value.document?.picker).toMatchObject({
      open: false,
      documentId: '',
    })
    m.dispatch({ type: 'openDocumentPicker' })
    expect(m.vm.value.document?.picker.open).toBe(true)
    m.dispatch({ type: 'closeDocumentPicker' })
    expect(m.vm.value.document?.picker.open).toBe(false)
  })

  // 裁定: 読込中・実行中・保存中・確認中・送信中は開かない。送信中は閉じない（× と Esc を捨てる）。
  // ヘッダの文書タイトルは header.pickable で押せる・押せないを表すため、開ける状態と一致させる
  it('文書なし・表示中・取得失敗でだけ開き（header.pickable も同じ）、送信中は閉じない', () => {
    const cases = [
      ['empty', true],
      ['document', true],
      ['documentError', true],
      ['loadingDocument', false],
      ['executing', false],
      ['saving', false],
      ['confirmDiscard', false],
      ['registering', false],
    ] as const
    for (const [state, pickable] of cases) {
      const m = atEmpty()
      m.state.value = state
      expect(m.vm.value.header.pickable, state).toBe(pickable)
      m.dispatch({ type: 'openDocumentPicker' })
      expect(m.vm.value.document?.picker.open, state).toBe(pickable)
    }
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    m.state.value = 'registering'
    m.dispatch({ type: 'closeDocumentPicker' })
    expect(m.vm.value.document?.picker.open).toBe(true)
  })

  // document_id 付きの URL で入ったときなど、種別一覧が無ければ開いたときに取る（取得済みなら取り直さない）
  it('種別一覧が空のときだけ、開いたときに取得する', async () => {
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    await flushPromises()
    expect(typeCalls()).toBe(1)
    expect(m.vm.value.document?.picker.register.typeItems).toEqual(configs)

    m.dispatch({ type: 'closeDocumentPicker' })
    m.dispatch({ type: 'openDocumentPicker' })
    await flushPromises()
    expect(typeCalls()).toBe(1)
  })

  // 失敗は応答の error でも例外でも登録フォームに出し、取得中の表示は戻す
  it('種別一覧の取得に失敗すると、登録フォームに失敗を出す', async () => {
    const failures = {
      'error 応答': () =>
        Promise.resolve({ data: undefined, error: { status: 500 } }),
      例外: () => Promise.reject(new Error('network')),
    }
    for (const [kind, fail] of Object.entries(failures)) {
      getMock.mockImplementation((path: string) =>
        path === '/api/v1/config/document-types' ? fail() : routeGet()(path),
      )
      const m = atEmpty()
      m.dispatch({ type: 'openDocumentPicker' })
      expect(m.vm.value.document?.picker.register, kind).toMatchObject({
        typesLoading: true,
        typesFailed: false,
      })
      await flushPromises()
      expect(m.vm.value.document?.picker.register, kind).toMatchObject({
        typeItems: [],
        typesLoading: false,
        typesFailed: true,
      })
    }
  })

  // 再試行の間も失敗の表示は残し（再試行ボタンを読込中にする）、取得できたら消す
  it('再試行で種別一覧を取り直し、取得できると失敗の表示を消す', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/config/document-types'
        ? Promise.resolve({ data: undefined, error: { status: 500 } })
        : routeGet()(path),
    )
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    await flushPromises()

    getMock.mockImplementation(routeGet())
    m.dispatch({ type: 'retryDocumentTypes' })
    expect(m.vm.value.document?.picker.register).toMatchObject({
      typesLoading: true,
      typesFailed: true,
    })
    await flushPromises()
    expect(m.vm.value.document?.picker.register).toMatchObject({
      typeItems: configs,
      typesLoading: false,
      typesFailed: false,
    })
  })

  // 応答前に開き直し・再試行が重なっても、要求は 1 本だけ出す（応答はマイクロタスクで届くため、同期の dispatch の間は応答待ち）
  it('取得中は、開き直しても再試行しても種別一覧を重ねて取得しない', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/config/document-types'
        ? Promise.reject(new Error('network'))
        : routeGet()(path),
    )
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    m.dispatch({ type: 'closeDocumentPicker' })
    m.dispatch({ type: 'openDocumentPicker' })
    m.dispatch({ type: 'retryDocumentTypes' })
    expect(typeCalls()).toBe(1)

    await flushPromises()
    m.dispatch({ type: 'retryDocumentTypes' })
    m.dispatch({ type: 'retryDocumentTypes' })
    expect(typeCalls()).toBe(2)
  })

  // 応答はダイアログを閉じた後も受ける。読込中に届いた失敗を捨てると取得中のまま固まり、二度と取り直せない
  it('種別一覧の取得失敗が文書の読込中に届いても受け、開き直すと取り直す', async () => {
    let failTypes!: (e: unknown) => void
    getMock.mockImplementationOnce(
      () =>
        new Promise((_, reject) => {
          failTypes = reject
        }),
    )
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.state.value).toBe('loadingDocument')
    failTypes(new Error('network'))
    await flushPromises()
    expect(m.state.value).toBe('document')
    expect(m.vm.value.document?.picker.register.typesFailed).toBe(true)

    m.dispatch({ type: 'openDocumentPicker' })
    await flushPromises()
    expect(m.vm.value.document?.picker.register).toMatchObject({
      typeItems: configs,
      typesFailed: false,
    })
  })

  // 登録に失敗してもダイアログは開いたまま（入力を残して再送できる）。開き直すとエラーを消す
  it('登録の失敗後もダイアログは開いたままで、開き直すとエラーを消す', async () => {
    postMock.mockResolvedValue({ data: undefined, error: problems.conflict })
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    await flushPromises()
    expect(m.state.value).toBe('empty')
    expect(m.vm.value.document?.picker.open).toBe(true)
    expect(m.vm.value.document?.picker.register.error).toBe(
      '文書IDは別の内容で登録済みです',
    )

    m.dispatch({ type: 'closeDocumentPicker' })
    m.dispatch({ type: 'openDocumentPicker' })
    expect(m.vm.value.document?.picker.register.error).toBeNull()
  })

  // 一覧の取得後に選んだ種別の設定が削除されていたら、一覧を取り直して選び直せるようにする。他の失敗では取り直さない
  it('登録が unknown-document-type で失敗したときだけ、種別一覧を取り直す', async () => {
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    await flushPromises()
    const register = {
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    } as const

    postMock.mockResolvedValue({ data: undefined, error: problems.conflict })
    m.dispatch(register)
    await flushPromises()
    expect(typeCalls()).toBe(1)

    const remaining = configs.filter((c) => c.type_code !== 'quotation')
    getMock.mockResolvedValueOnce({ data: remaining, error: undefined })
    postMock.mockResolvedValue({ data: undefined, error: problems.unknownType })
    m.dispatch(register)
    await flushPromises()
    expect(m.vm.value.document?.picker.register.typeItems).toEqual(remaining)
  })

  // 参照で読込を始めると閉じる。表示中の文書 ID は参照欄の初期値として vm に出す
  it('参照で読込を始めるとダイアログを閉じ、picker.documentId は表示中の文書 ID になる', async () => {
    const m = atEmpty()
    m.dispatch({ type: 'openDocumentPicker' })
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    expect(m.state.value).toBe('loadingDocument')
    expect(m.vm.value.document?.picker.open).toBe(false)
    await flushPromises()

    m.dispatch({ type: 'openDocumentPicker' })
    expect(m.vm.value.document?.picker).toMatchObject({
      open: true,
      documentId: 'doc-1',
    })
  })

  // 表示中の文書から登録すると、送信の時点で文書を閉じる（背面は空状態）。成功で登録した文書を開いて閉じる
  it('表示中の文書から登録すると、送信の時点で文書を閉じて registering になる', async () => {
    const m = await opened()
    m.dispatch({ type: 'openDocumentPicker' })
    let respond!: (value: unknown) => void
    postMock.mockReturnValue(
      new Promise((resolve) => {
        respond = resolve
      }),
    )
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    expect(m.state.value).toBe('registering')
    expect(m.vm.value.header.documentId).toBe('')
    expect(m.vm.value.document).toMatchObject({
      phase: 'registering',
      canvas: null,
      workPanel: null,
    })
    expect(m.vm.value.document?.picker.open).toBe(true)

    respond({
      data: { document_id: 'doc-9', document_type: 'quotation' },
      error: undefined,
    })
    await flushPromises()
    expect(m.state.value).toBe('document')
    expect(m.vm.value.header.documentId).toBe('doc-9')
    expect(m.vm.value.document?.picker.open).toBe(false)
  })

  // 表示中の文書から登録して失敗すると、文書は閉じたまま（背面は空状態）で、ダイアログは開いたままエラーを出す
  it('表示中の文書から登録して失敗すると、empty に戻りダイアログは開いたままエラーを出す', async () => {
    const m = await opened()
    m.dispatch({ type: 'openDocumentPicker' })
    postMock.mockResolvedValue({ data: undefined, error: problems.conflict })
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    await flushPromises()

    expect(m.state.value).toBe('empty')
    expect(m.vm.value.header.documentId).toBe('')
    expect(m.vm.value.document?.phase).toBe('empty')
    expect(m.vm.value.document?.picker).toMatchObject({
      open: true,
      documentId: '',
    })
    expect(m.vm.value.document?.picker.register.error).toBe(
      '文書IDは別の内容で登録済みです',
    )
  })

  // 登録はできたが文書の取得に失敗した → 取得失敗画面からダイアログを開いて登録し直す
  it('取得失敗画面からダイアログを開いて登録し直せる', async () => {
    getMock.mockImplementation((path: string) =>
      path === '/api/v1/documents/{document_id}/pages'
        ? Promise.resolve({ data: undefined, error: { status: 500 } })
        : routeGet()(path),
    )
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    expect(m.state.value).toBe('documentError')
    m.dispatch({ type: 'openDocumentPicker' })
    expect(m.vm.value.document?.picker).toMatchObject({
      open: true,
      documentId: 'doc-1',
    })

    getMock.mockImplementation(routeGet())
    postMock.mockResolvedValue({
      data: { document_id: 'doc-9', document_type: 'quotation' },
      error: undefined,
    })
    m.dispatch({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
    expect(m.state.value).toBe('registering')
    expect(m.vm.value.document?.error).toBeNull()
    await flushPromises()
    expect(m.state.value).toBe('document')
    expect(m.vm.value.header.documentId).toBe('doc-9')
  })

  // 未保存の修正があれば送信前に破棄確認を挟む。キャンセルでダイアログ（入力）に戻り、続行で登録する
  it('未保存の修正があると登録の前に破棄確認を挟む', async () => {
    getMock.mockImplementation(routeGet([succeededRun]))
    const m = atEmpty()
    m.dispatch({ type: 'openDocument', documentId: 'doc-1' })
    await flushPromises()
    m.dispatch({ type: 'fieldInput', key: 'order_no', value: 'A-009' })
    m.dispatch({ type: 'openDocumentPicker' })
    const register = {
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    } as const

    m.dispatch(register)
    expect(m.state.value).toBe('confirmDiscard')
    expect(postMock).not.toHaveBeenCalled()
    m.dispatch({ type: 'confirmCancel' })
    expect(m.state.value).toBe('document')
    expect(m.vm.value.header.documentId).toBe('doc-1')
    expect(m.vm.value.document?.picker.open).toBe(true)

    postMock.mockResolvedValue({
      data: { document_id: 'doc-9', document_type: 'quotation' },
      error: undefined,
    })
    m.dispatch(register)
    m.dispatch({ type: 'confirmProceed' })
    expect(postMock).toHaveBeenCalledOnce()
    await flushPromises()
    expect(m.vm.value.header.documentId).toBe('doc-9')
  })
})
