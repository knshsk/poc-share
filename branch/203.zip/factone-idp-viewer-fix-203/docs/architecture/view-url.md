# 閲覧URLと公開閲覧

## 役割

共有可の文書種別の文書に、認証なしで閲覧できるURLを発行する。閲覧者の行動（閲覧・ページ閲覧・ダウンロード）を追記型のイベントとして記録し、テナント利用者と外部連携システムへ提供する。

URLには文書IDや業務キーを含めない。推測できないこと（256 bitの乱数）と、総当りを抑えること（一律404・失敗記録・レート制限）を担保する。

## 構成

```mermaid
flowchart LR
    panel["Viewer: ViewUrlPanel"]
    pub["閲覧者ブラウザ: PublicView"]
    integ["外部連携システム"]
    api["API: routers/view_urls.py"]
    tokens[("view_tokens")]
    events[("view_events")]
    failures[("view_access_failures")]
    blob[("Blob: PDF 原本")]
    limiter["FailureRateLimiter（インメモリ）"]

    panel -- "発行 / 一覧 / 失効（Bearer）" --> api
    pub -- "/view/{token}/*（無認証）" --> api
    integ -- "イベント差分取得（Bearer）" --> api
    api --> tokens
    api --> events
    api --> failures
    api --> blob
    api --> limiter
```

認証ありの管理APIと無認証の公開APIを、同じルーターに置く。公開API 3本は、すべて`_resolve_token`を通り、検証とPDF読込を行う。これは規約で、強制する仕組みはない。

一括失効はViewerから呼ばない。外部連携システム向けで、見積改訂時に旧版のURLを差し替える用途である。

閲覧者が`/view/{token}`を開くと、次の順に処理が進む。SPAは認証を経ずに、公開APIだけを呼ぶ。

1. APIのcatch-allがViewer SPAを返す。catch-allはビルド成果物があるときだけ登録する。ローカルではVite devサーバが返す。
2. `Root.vue`が起動時に、Mediatorへ`init`をdispatchする。
3. Mediatorがパスから`public`状態へ遷移し、`PublicView`を表示する。トークンが空ならログイン画面を表示する。

## 主要処理の流れ

### トークンのライフサイクル

```mermaid
flowchart LR
    issue["発行"] --> valid["有効"]
    valid -- "revoke / revoke-all" --> revoked["失効"]
    valid -- "expires_at 経過" --> expired["期限切れ"]
```

発行（`POST /api/v1/documents/{document_id}/view-urls`）では、文書が無ければ404を返す。文書種別設定の`shareable`を確認し、設定が無いか共有不可なら403 `view-url-not-allowed`を返す（[ADR-0002](../adr/0002-document-type-shareability.md)）。トークンは`secrets.token_urlsafe(32)`（256 bit）で生成し、DBにはSHA-256だけを保存する。期限はリクエストの`expires_at`で、妥当性は検証しない。指定が無ければ、発行時刻に既定の90日を足す。応答`{id, view_path: /view/{token}, expires_at}`で、平文のトークンを一度だけ返す。

一覧（`GET .../view-urls`）は、`id` / `issued_at` / `expires_at` / `revoked`を返す。並び順は未規定。

検証では、ハッシュが一致し、未失効で、`expires_at`が現在時刻より後であることを確かめる。どれかが欠けても一律404 `not-found`を返し、存在を推測させない。

1件の失効は`POST /api/v1/view-urls/{view_url_id}/revoke`で行う。`revoked`を立てるだけで即時に失効し、応答は`{status: revoked}`。対象は管理IDで指定する。管理IDは発行応答の`id`で、トークンとは無関係なUUIDである。URLの所属文書のテナントがJWTのテナントと一致しなければ404を返す。

一括失効は`POST .../view-urls/revoke-all`で行い、文書の未失効トークンをすべて失効させる。応答は`{status, revoked_count}`。対象が0件でも200を返し、冪等である。

1文書に複数のトークンを発行できる。発行レコードの並びが、そのままその文書に発行した閲覧URLの履歴になる。履歴には、見積改訂ごとの旧版・新版が並ぶ。

### 公開閲覧と閲覧イベント

```mermaid
sequenceDiagram
    participant V as 閲覧者ブラウザ（PublicView）
    participant A as API
    participant P as PostgreSQL
    participant B as Blob

    V->>A: GET /view/{token}/pages
    A->>A: IP が制限中なら 429
    A->>P: ハッシュで view_tokens を検索、未失効・期限内か
    alt 無効
        A->>P: view_access_failures に先頭 8 文字と IP を記録（DB）、FailureRateLimiter の失敗回数を加算（インメモリ）
        A-->>V: 404
    end
    A->>B: PDF を読む（公開 API 3 本すべてで行う）
    A->>A: ページ寸法を計算
    A->>P: view を記録
    A-->>V: ページ寸法一覧
    loop 表示領域に入ったページ
        V->>A: GET /view/{token}/pages/{page}/image
        A->>A: 同じ検証 → PNG を生成
        A->>P: page_view（page 付き）を記録
        A-->>V: PNG（Cache-Control: no-store）
    end
    V->>A: GET /view/{token}/pdf
    A->>P: download を記録
    A-->>V: PDF（元ファイル名で Content-Disposition）
```

`view`と`page_view`は、ページ寸法の計算やPNGの生成に成功した後に記録する。PDF処理に失敗して500になった要求は記録しない。`download`はBlob読込後、応答生成の直前に記録する。

`view_events`は、文書（内部ID）・発生日時（マイクロ秒精度）・種別の組で一意。`page`は一意キーに含まれないため、同一時刻の別ページの`page_view`は片方が捨てられる。衝突したときは記録を捨て、配信は成功させる。

`page_view`の契機は、SPAの遅延読込である。SPAは`IntersectionObserver`で、表示領域に入ったページだけの画像を取得する。非対応環境では全ページを即時に取得する。APIはページ画像の応答に`Cache-Control: no-store`を付け、ブラウザキャッシュによる取りこぼしを防ぐ（[ADR-0015](../adr/0015-page-view-event.md)）。

テナント利用者がViewer上で見る、認証ありのページ画像・PDFは記録しない（[ADR-0012](../adr/0012-no-internal-view-event-history.md)）。

イベントには`client_ip`・`user_agent`・`page`を保存する。`client_ip`は`request.client.host`から取り、APIのコードは`X-Forwarded-For`を読まない。ただしuvicornは既定で、接続元が127.0.0.1の要求に限り、`X-Forwarded-For`の値を`request.client.host`にする。接続元が127.0.0.1ではないプロキシの配下では、`client_ip`はプロキシのIPになる。IPアドレスとして解釈できない値と、ゾーンID付きのIPv6アドレスは、`unknown`として保存する。`user_agent`は、512文字を超える分を切り詰めて保存する（[ADR-0028](../adr/0028-values-exceeding-column-length.md)）。`view_token_id`は内部管理値で、APIには出さない。

`PublicView`は、ページ一覧の取得に失敗すると、404 / 429 / 500を区別せず「この閲覧URLは無効です」と表示する。ダウンロードに失敗したときは、本文を残したまま、スナックバーで「ダウンロードできませんでした」と表示する。ページ画像の取得に失敗したときは、`PageSvg`がそのページの紙面に失敗を表示する。`ViewUrlPanel`の有効 / 期限切れの表示は、クライアントの時刻で判定する。

### イベントの提供

文書別のイベントは、`GET /api/v1/documents/{document_id}/events`で取得する。`occurred_at`の昇順で返し、同時刻の並びは未規定。

横断差分は、`GET /api/v1/view-events?since=<日時>`で取得する。JWTのテナントの全文書を対象に、`occurred_at >= since`のイベントを`occurred_at, id`の昇順で返す。境界の時刻は含む。`since`を省略すると全件を返す。件数の上限とページングは無い。境界で重複したイベントは、連携側が冪等キー（文書IDと発生日時）で除く前提とし、取りこぼしゼロを優先する（[ADR-0013](../adr/0013-view-event-delta-feed.md)）。

### 防御

一律404として、トークン不一致・失効・期限切れ・文書不在を区別しない。

失敗試行の記録として、`view_access_failures`にトークンの先頭8文字とIPを保存する。総当りの検知用で、トークン全体は保存しない。IPの扱いは閲覧イベントの`client_ip`と同じで、レート制限もこの値を単位にする。

レート制限は、IPごとのスライディング窓で行う。直近`FACTONE_VIEW_URL_FAILURE_WINDOW_SECONDS`（60）秒の失敗が`FACTONE_VIEW_URL_MAX_FAILURES`（10）回に達すると、そのIPからの公開APIを429 `too-many-requests`にする。成功した要求は数えない。制限はトークンの検証より先に判定するため、制限中のIPからは有効なトークンの要求も429になる。制限の状態はインメモリ（`FailureRateLimiter`）に持つため、プロセスを再起動すると消え、単一レプリカを前提とする。スケールアウトするときは外部化が必要。

429になった要求は、イベントも失敗記録も残さず、窓も延長しない。制限は、直近`FACTONE_VIEW_URL_FAILURE_WINDOW_SECONDS`（60）秒の失敗が`FACTONE_VIEW_URL_MAX_FAILURES`（10）回を下回った時点で解除される。

## 外部依存・設定

| 設定 | 既定値 |
| --- | --- |
| `FACTONE_VIEW_URL_DEFAULT_TTL_DAYS` | 90 |
| `FACTONE_VIEW_URL_MAX_FAILURES` | 10 |
| `FACTONE_VIEW_URL_FAILURE_WINDOW_SECONDS` | 60 |

ほかに、文書種別設定の`shareable`（[data-model/document-type-configs.md](../data-model/document-type-configs.md)）、Blob（PDF原本）、pypdfium2（ページ画像）に依存する。

## 関連ドキュメント

| 参照先 | 内容 |
| --- | --- |
| [data-model/view-tokens.md](../data-model/view-tokens.md) | `view_tokens` / `view_access_failures` |
| [data-model/view-events.md](../data-model/view-events.md) | `view_events` |
| [viewer/display.md](../viewer/display.md) | ページ画像の遅延読込・座標系 |
| [viewer.md](viewer.md) | `PublicView` / `ViewUrlPanel` |
| [api/README.md](../api/README.md) | `/view/**`はパスにバージョンを含めない |

関連するADRは、[ADR-0002](../adr/0002-document-type-shareability.md)、[ADR-0011](../adr/0011-view-url-opaque-token.md)、[ADR-0012](../adr/0012-no-internal-view-event-history.md)、[ADR-0013](../adr/0013-view-event-delta-feed.md)、[ADR-0015](../adr/0015-page-view-event.md)、[ADR-0028](../adr/0028-values-exceeding-column-length.md)。
