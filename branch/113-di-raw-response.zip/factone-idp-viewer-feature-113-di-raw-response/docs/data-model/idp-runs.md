# IDP実行ログ（idp_runs）

Document Intelligenceによる項目抽出の実行履歴。追記型（再実行で過去結果を上書きしない）。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 実行ID（サーバ採番） |
| document_id | varchar(255) | NOT NULL・FK(documents) | 対象文書 |
| run_type | varchar(20) | NOT NULL・CHECK | `initial`（初回）/ `rerun`（再実行）。同一文書IDの既存実行有無からサーバ側で自動判定（失敗実行も既存実行に数える） |
| status | varchar(20) | NOT NULL・CHECK | `succeeded` / `failed` |
| executed_at | timestamptz | NOT NULL | 実行日時（サーバで記録） |
| raw_fields | jsonb | NULL可 | 項目別の生値（DIが返した文字列そのまま）。失敗時はNULL |
| normalized_fields | jsonb | NULL可 | 項目別の正規化値（数値はカンマ除去して整数化、日付はISO 8601化）。正規化不能な値はnull |
| confidence | jsonb | NULL可 | 項目別確信度（0〜1）。返却・記録のみで閾値判定には使用しない |
| tables | jsonb | NULL可 | DIが認識したテーブル領域（明細仮）の配列。成功時はテーブル未検出でも空配列、失敗時はNULL |
| pattern_matches | jsonb | NULL可 | 文書種別設定の `patterns` をDI全文テキストに適用した結果（下記）。成功時はパターン未設定でも空オブジェクト、失敗時はNULL |
| field_regions | jsonb | NULL可 | 項目別の読取領域（下記）。成功時はキーを全項目分持ち、領域なし・値なしの項目はnull。失敗時はNULL |
| di_api_version | varchar(20) | NULL可 | DI応答の `analyzeResult.apiVersion`（例 `2024-11-30`）。失敗時はNULL |
| di_model_id | varchar(100) | NULL可 | DI応答の `analyzeResult.modelId`（現在 `prebuilt-layout`）。失敗時はNULL |
| raw_response_ref | varchar(1024) | NULL可 | 生応答のBlobパス `{tenant_id}/{document_id}/idp-runs/{run_id}.json`。失敗時はNULL |
| error_info | varchar(2048) | NULL可 | 失敗時のエラー情報 |

- 生値・正規化値・確信度を分離保持する（生OCR結果と正規化値の分離方針に基づく）
- JSONのキーは文書種別ごとのクエリセット（`api/app/services/idp_extraction.py`）と一致する。未抽出項目もキーを残し、値はnull

### tables（テーブル領域）の構造

- 各要素は `row_count` / `column_count` / `cells` を持つ。複数テーブル認識時は全件保持する
- `cells` の各要素は `row_index` / `column_index` / `content` / `kind`（`columnHeader` 等、無い場合null）/ `page_number` / `polygon`（座標配列。無い場合null）
- DIの認識結果を意味付けせず素通しする。どのテーブルが明細領域か、どの列・行がSAP入力項目の何に相当するかの判断はSaaS側の責務外（利用側で解釈する）

### pattern_matches（正規表現マッチ結果）の構造

キーは設定の `patterns[].key`。値は実行時点の `label` / `regex` と、全文テキストへの一致値の配列。

```json
{
  "TCode": {"label": "登録番号", "regex": "T\\d{13}", "values": ["T1234567890123"]},
  "QuotationNo": {"label": "見積番号", "regex": "Q-\\d{6}", "values": []}
}
```

- `values` は出現順で、重複を除去しない（同一文字列が複数箇所にあればその回数分並ぶ）。0件でもキーを残す
- 長さ 0 の一致（`\d*` 等が空文字に一致した場合）は `values` に含めない。空文字は情報を持たず、文字位置ごとに 1 件生成されて結果が肥大するため
- 実行時点の `label` / `regex` を同梱するため、設定変更後も当時の条件を再現できる
- 一致値の妥当性検証は外部システムの責務（PoC）

### field_regions（項目別読取領域）の構造

キーは Query Fields のキー。値は DI 応答 `documents[0].fields[key].boundingRegions[0]` の `pageNumber` / `polygon`（インチ単位。SVG の viewBox と同一座標系）。

```json
{
  "TotalAmount": {"page_number": 1, "polygon": [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1]},
  "QuotationId": null
}
```

- Viewer のキャンバス⇄右ペイン相互ハイライトのデータ源。領域が無い項目・未抽出の項目は null

### 生応答の保存（Blob）

- DI の最終ポーリング GET の応答本文（`status` / `createdDateTime` / `lastUpdatedDateTime` / `analyzeResult` を含むラッパ込み JSON）を bytes のまま Blob `{tenant_id}/{document_id}/idp-runs/{run_id}.json` に保存する。再シリアライズしない（ADR-0019）
- 用途: `tables` / `fields` 以外の情報（words / lines / paragraphs 等）を使う将来機能への互換、カスタムモデル学習データ（DI Studio の `.ocr.json` と同形）
- 保存順序は DI 成功 → Blob 保存 → 実行ログ INSERT。Blob 保存失敗は 500 で実行ログを残さない
- Blob のコンテンツタイプは設定しない。取得 API が `application/json` で返す

## 抽出方式

- prebuilt-layout+Query Fields（学習・ラベリングなしで項目指定抽出と項目別確信度を取得）
- クエリセットは文書種別ごとに固定。確定抽出項目が未確定のため、検証用サンプルPDFの様式に合わせた仮置き
  - 注文書（案件型・ルート型）: 得意先コード・品目コード・数量・納期・単価
  - 見積: 文書番号・得意先コード・発行日・合計金額
- WBS原価データは様式確定まで対象外
- 同期応答（非同期化の要否は処理時間・サイズ上限の確定後に再検討）。タイムアウトは設定値 `FACTONE_DI_TIMEOUT_SECONDS`（既定120秒）
- 正規表現パターンマッチ: 文書種別設定の `patterns` を DI 応答の全文テキスト（`content`）に `re.finditer` で適用し、全一致を `pattern_matches` に保存する。Query Fields で取得しづらい項目（見積番号・Tコード等）の補完用

## API

- `POST /api/v1/documents/{document_id}/idp-runs`（JWT必須）— 登録済文書に対して抽出を実行し、結果を履歴に追記して返す。DI失敗時は502を返し、失敗実行もerror_info付きで記録する
- `GET /api/v1/documents/{document_id}/idp-runs`（JWT必須）— 実行履歴一覧（実行日時昇順）
- `GET /api/v1/documents/{document_id}/idp-runs/{run_id}/raw-response`（JWT必須）— 生応答を `application/json` で無変換返却。他文書の run_id・不在は404 `idp-run-not-found`、失敗実行は404 `raw-response-not-found`
