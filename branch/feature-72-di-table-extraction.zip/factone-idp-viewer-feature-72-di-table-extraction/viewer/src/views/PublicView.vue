<script setup lang="ts">
import { onMounted, ref } from 'vue'

import { apiClient } from '../api/client'
import PageSvg from '../components/PageSvg.vue'

interface PageInfo {
  width: number
  height: number
}

const props = defineProps<{ token: string }>()

const pages = ref<PageInfo[]>([])
const errorMessage = ref<string | null>(null)

onMounted(async () => {
  const { data, error } = await apiClient.GET('/view/{token}/pages', {
    params: { path: { token: props.token } },
  })
  if (error || !data) {
    errorMessage.value = 'この閲覧URLは無効です'
    return
  }
  pages.value = data.pages
})

async function download(): Promise<void> {
  const { data, error } = await apiClient.GET('/view/{token}/pdf', {
    params: { path: { token: props.token } },
    parseAs: 'blob',
  })
  if (error || !data) {
    errorMessage.value = 'ダウンロードできませんでした'
    return
  }
  const url = URL.createObjectURL(data)
  const link = document.createElement('a')
  link.href = url
  link.download = 'document.pdf'
  link.click()
  URL.revokeObjectURL(url)
}
</script>

<template>
  <v-container>
    <p v-if="errorMessage">{{ errorMessage }}</p>
    <template v-else>
      <v-btn :disabled="pages.length === 0" @click="download"
        >ダウンロード</v-btn
      >
      <div v-for="(page, index) in pages" :key="index" class="my-4">
        <PageSvg
          :token="token"
          :page="index + 1"
          :width="page.width"
          :height="page.height"
        />
      </div>
    </template>
  </v-container>
</template>
