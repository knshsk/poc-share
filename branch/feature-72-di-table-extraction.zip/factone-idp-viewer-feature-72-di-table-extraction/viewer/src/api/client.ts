import createClient from 'openapi-fetch'

import { useAuthStore } from '../stores/auth'
import type { paths } from './schema'

// 同一オリジン前提（本番はContainer Apps同居配信、ローカルはVite devプロキシ）
export const apiClient = createClient<paths>({ baseUrl: '/' })

apiClient.use({
  onRequest({ request }) {
    const auth = useAuthStore()
    if (auth.accessToken) {
      request.headers.set('Authorization', `Bearer ${auth.accessToken}`)
    }
    return request
  },
})
