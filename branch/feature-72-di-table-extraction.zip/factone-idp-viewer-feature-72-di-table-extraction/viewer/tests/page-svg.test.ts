import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

// 画像取得はapiClient経由のためモックする（コンポーネントは座標系整合が検証対象）
const getMock = vi
  .fn()
  .mockResolvedValue({ data: new Blob(), error: undefined })
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
  },
}))

import PageSvg from '../src/components/PageSvg.vue'

describe('PageSvg', () => {
  // viewBoxがDI座標系（インチ単位のページ寸法）と一致することを確認する
  it('viewBoxをページ寸法（インチ）で設定する', () => {
    const wrapper = mount(PageSvg, {
      props: { documentId: 'doc-1', page: 1, width: 8.5, height: 11 },
    })

    const svg = wrapper.find('svg')
    expect(svg.attributes('viewBox')).toBe('0 0 8.5 11')
  })

  // DI polygonの矩形がインチ座標のまま無変換でrect要素になることを確認する
  it('読取矩形をDI座標のままrect描画する', () => {
    const wrapper = mount(PageSvg, {
      props: {
        documentId: 'doc-1',
        page: 1,
        width: 8.5,
        height: 11,
        rects: [{ x: 1.0, y: 2.5, width: 3.0, height: 0.25 }],
      },
    })

    const rect = wrapper.find('rect')
    expect(rect.attributes('x')).toBe('1')
    expect(rect.attributes('y')).toBe('2.5')
    expect(rect.attributes('width')).toBe('3')
    expect(rect.attributes('height')).toBe('0.25')
  })

  // token指定時は無認証の閲覧URL用エンドポイントから画像を取得することを確認する
  it('token指定時は/view系エンドポイントを呼ぶ', async () => {
    mount(PageSvg, {
      props: { token: 'tok-abc', page: 2, width: 8.5, height: 11 },
    })
    await new Promise((resolve) => setTimeout(resolve))

    expect(getMock).toHaveBeenCalledWith(
      '/view/{token}/pages/{page}/image',
      expect.objectContaining({
        params: { path: { token: 'tok-abc', page: 2 } },
      }),
    )
  })
})
