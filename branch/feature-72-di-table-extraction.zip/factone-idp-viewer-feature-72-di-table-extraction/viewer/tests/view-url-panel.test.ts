import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// API呼出はapiClient経由のためモックする（パネルは発行・一覧・失効の操作と表示が検証対象）
const getMock = vi.fn()
const postMock = vi.fn()
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return postMock
    },
  },
}))

import ViewUrlPanel from '../src/components/ViewUrlPanel.vue'

const activeUrl = {
  id: '11111111-1111-1111-1111-111111111111',
  issued_at: '2026-08-01T00:00:00Z',
  expires_at: '2099-08-31T00:00:00Z',
  revoked: false,
}

const revokedUrl = {
  id: '22222222-2222-2222-2222-222222222222',
  issued_at: '2026-08-02T00:00:00Z',
  expires_at: '2099-08-31T00:00:00Z',
  revoked: true,
}

function mountPanel() {
  return mount(ViewUrlPanel, {
    props: { documentId: 'doc-1' },
    global: { plugins: [createAppVuetify()] },
  })
}

beforeEach(() => {
  getMock.mockReset()
  postMock.mockReset()
  getMock.mockResolvedValue({ data: [], error: undefined })
})

describe('ViewUrlPanel', () => {
  // 文書表示時に発行済み閲覧URLの一覧を自動取得し、状態（有効/失効）を表示することを確認する
  it('マウント時に一覧取得し発行済みURLと状態を表示する', async () => {
    getMock.mockResolvedValue({
      data: [activeUrl, revokedUrl],
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()

    expect(getMock).toHaveBeenCalledWith(
      '/api/documents/{document_id}/view-urls',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1' } },
      }),
    )
    const rows = wrapper.findAll('[data-testid="view-url-row"]')
    expect(rows).toHaveLength(2)
    expect(rows[0]!.text()).toContain('有効')
    expect(rows[1]!.text()).toContain('失効')
  })

  // 発行ボタンでPOSTし、発行された閲覧URLが絶対URLで表示されることを確認する
  it('発行ボタンでPOSTし発行URLを絶対URLで表示する', async () => {
    postMock.mockResolvedValue({
      data: {
        id: activeUrl.id,
        view_path: '/view/tok-abc',
        expires_at: activeUrl.expires_at,
      },
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="issue-view-url"]').trigger('click')
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/documents/{document_id}/view-urls',
      expect.objectContaining({
        params: { path: { document_id: 'doc-1' } },
      }),
    )
    expect(wrapper.get('[data-testid="issued-url"]').text()).toContain(
      `${window.location.origin}/view/tok-abc`,
    )
    // 発行後は一覧を再取得する
    expect(getMock).toHaveBeenCalledTimes(2)
  })

  // コピー操作で発行URLがクリップボードへ書き込まれることを確認する
  it('コピー操作で発行URLをクリップボードへ書き込む', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.assign(navigator, { clipboard: { writeText } })
    postMock.mockResolvedValue({
      data: {
        id: activeUrl.id,
        view_path: '/view/tok-abc',
        expires_at: activeUrl.expires_at,
      },
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()
    await wrapper.get('[data-testid="issue-view-url"]').trigger('click')
    await flushPromises()

    await wrapper.get('[data-testid="copy-view-url"]').trigger('click')

    expect(writeText).toHaveBeenCalledWith(
      `${window.location.origin}/view/tok-abc`,
    )
  })

  // 失効ボタンで失効APIを呼び、一覧が再取得されることを確認する
  it('失効ボタンでrevokeし一覧を再取得する', async () => {
    getMock.mockResolvedValue({ data: [activeUrl], error: undefined })
    postMock.mockResolvedValue({
      data: { status: 'revoked' },
      error: undefined,
    })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="revoke-view-url"]').trigger('click')
    await flushPromises()

    expect(postMock).toHaveBeenCalledWith(
      '/api/view-urls/{view_url_id}/revoke',
      expect.objectContaining({
        params: { path: { view_url_id: activeUrl.id } },
      }),
    )
    // マウント時+失効後で一覧取得2回
    expect(getMock).toHaveBeenCalledTimes(2)
  })

  // 失効済みURLの行には失効ボタンを表示しないことを確認する
  it('失効済みURLには失効ボタンを表示しない', async () => {
    getMock.mockResolvedValue({ data: [revokedUrl], error: undefined })

    const wrapper = mountPanel()
    await flushPromises()

    expect(wrapper.find('[data-testid="revoke-view-url"]').exists()).toBe(false)
  })

  // 発行失敗（API呼出エラー）時にエラーメッセージが表示されることを確認する
  it('発行失敗時にエラーメッセージを表示する', async () => {
    postMock.mockResolvedValue({
      data: undefined,
      error: { detail: 'View URLs cannot be issued for this document type' },
    })

    const wrapper = mountPanel()
    await flushPromises()

    await wrapper.get('[data-testid="issue-view-url"]').trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('閲覧URLの発行に失敗しました')
  })
})
