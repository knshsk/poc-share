import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { createAppVuetify } from '../src/plugins/vuetify'

// API呼出はapiClient経由のためモックする（画面はパネル組込が検証対象）
// 文書種別は閲覧URLパネルの表示ゲートに使う（既定: 見積）
let documentType = 'quote'
const getMock = vi.fn().mockImplementation((path: string) => {
  if (path === '/api/documents/{document_id}') {
    return Promise.resolve({
      data: {
        document_id: 'doc-1',
        tenant_id: 'tenant-1',
        document_type: documentType,
        content_sha256: 'x'.repeat(64),
        received_at: '2026-08-01T00:00:00Z',
      },
      error: undefined,
    })
  }
  if (path === '/api/documents/{document_id}/view-urls') {
    return Promise.resolve({ data: [], error: undefined })
  }
  if (path === '/api/documents/{document_id}/pages') {
    return Promise.resolve({
      data: { document_id: 'doc-1', pages: [{ width: 8.5, height: 11 }] },
      error: undefined,
    })
  }
  if (path === '/api/documents/{document_id}/pages/{page}/image') {
    return Promise.resolve({ data: new Blob(), error: undefined })
  }
  return Promise.resolve({
    data: { document_id: 'doc-1', runs: [] },
    error: undefined,
  })
})
vi.mock('../src/api/client', () => ({
  apiClient: {
    get GET() {
      return getMock
    },
    get POST() {
      return vi.fn()
    },
  },
}))

import DocumentView from '../src/views/DocumentView.vue'
import IdpRunPanel from '../src/components/IdpRunPanel.vue'
import ViewUrlPanel from '../src/components/ViewUrlPanel.vue'

describe('DocumentView', () => {
  beforeEach(() => {
    documentType = 'quote'
    getMock.mockClear()
  })

  // 文書表示時にIDP実行パネルが文書IDを引き渡されて組み込まれることを確認する
  it('文書表示時にIdpRunPanelを表示する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mount(DocumentView, {
      global: { plugins: [createAppVuetify()] },
    })
    await flushPromises()

    const panel = wrapper.findComponent(IdpRunPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('documentId')).toBe('doc-1')
  })

  // 文書未表示（文書ID未入力）ではパネルを表示しないことを確認する
  it('文書未表示ではIdpRunPanelを表示しない', () => {
    window.history.replaceState(null, '', '/')

    const wrapper = mount(DocumentView, {
      global: { plugins: [createAppVuetify()] },
    })

    expect(wrapper.findComponent(IdpRunPanel).exists()).toBe(false)
  })

  // 見積文書では閲覧URLパネルが文書IDを引き渡されて組み込まれることを確認する
  it('見積文書ではViewUrlPanelを表示する', async () => {
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mount(DocumentView, {
      global: { plugins: [createAppVuetify()] },
    })
    await flushPromises()

    const panel = wrapper.findComponent(ViewUrlPanel)
    expect(panel.exists()).toBe(true)
    expect(panel.props('documentId')).toBe('doc-1')
  })

  // 注文書は顧客へ開示しないため、閲覧URLパネルを表示しないことを確認する（ADR-0002）
  it('注文書種別ではViewUrlPanelを表示しない', async () => {
    documentType = 'order_project'
    window.history.replaceState(null, '', '?document_id=doc-1')

    const wrapper = mount(DocumentView, {
      global: { plugins: [createAppVuetify()] },
    })
    await flushPromises()

    expect(wrapper.findComponent(ViewUrlPanel).exists()).toBe(false)
    // 注文書でもIDP実行パネルは表示される
    expect(wrapper.findComponent(IdpRunPanel).exists()).toBe(true)
  })
})
