"""IDP実行APIの統合テスト（実PostgreSQLコンテナ接続）。

事前に `podman compose up -d postgres` が必要。
共有フィクスチャ（doc_client・fake_analyzer等）は conftest.py を参照。
"""

from typing import Any

from fastapi.testclient import TestClient

from app.services.di import DiError, DiTable, DiTableCell
from tests.conftest import FakeDocumentAnalyzer
from tests.test_documents_api import post_document

ORDER_RESULTS = {
    "customer_code": ("C-9001", 0.98),
    "item_code": ("P-9001", 0.95),
    "quantity": ("2", 0.99),
    "delivery_date": ("2026-10-30", 0.97),
    "unit_price": ("500,000", 0.96),
}

ORDER_TABLES = (
    DiTable(
        row_count=2,
        column_count=2,
        cells=(
            DiTableCell(
                row_index=0,
                column_index=0,
                content="品目",
                kind="columnHeader",
                page_number=1,
                polygon=(1.0, 2.0, 3.0, 2.0),
            ),
            DiTableCell(
                row_index=1,
                column_index=0,
                content="P-9001",
                kind=None,
                page_number=1,
                polygon=(1.0, 3.0, 3.0, 3.0),
            ),
        ),
    ),
    DiTable(row_count=1, column_count=1, cells=()),
)


def run_idp(client: TestClient, document_id: str = "doc-001") -> Any:
    return client.post(f"/api/documents/{document_id}/idp-runs")


def test_first_run_returns_extraction_with_confidence(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """初回実行が201となり、生値・正規化値・確信度が項目別に返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="order_project")

    response = run_idp(doc_client)

    assert response.status_code == 201
    body = response.json()
    assert body["document_id"] == "doc-001"
    assert body["run_type"] == "initial"
    assert body["status"] == "succeeded"
    assert body["raw_fields"]["unit_price"] == "500,000"
    assert body["normalized_fields"]["unit_price"] == 500000
    assert body["confidence"]["unit_price"] == 0.96
    assert body["error_info"] is None
    assert body["run_id"]
    assert body["executed_at"]


def test_rerun_is_distinguished_and_appended(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """再実行がrerunとして区別され、履歴が上書きされず追記されることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="order_project")

    first = run_idp(doc_client)
    second = run_idp(doc_client)

    assert first.json()["run_type"] == "initial"
    assert second.json()["run_type"] == "rerun"
    assert first.json()["run_id"] != second.json()["run_id"]

    listing = doc_client.get("/api/documents/doc-001/idp-runs")
    assert listing.status_code == 200
    runs = listing.json()["runs"]
    assert len(runs) == 2
    assert [run["run_type"] for run in runs] == ["initial", "rerun"]


def test_run_on_unknown_document_returns_404(doc_client: TestClient) -> None:
    response = run_idp(doc_client, document_id="no-such-doc")
    assert response.status_code == 404


def test_di_failure_returns_502_and_records_failed_run(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """DI障害時に502となり、失敗実行がエラー情報付きで履歴に記録されることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="order_project")

    response = run_idp(doc_client)

    assert response.status_code == 502
    runs = doc_client.get("/api/documents/doc-001/idp-runs").json()["runs"]
    assert len(runs) == 1
    assert runs[0]["status"] == "failed"
    assert runs[0]["error_info"] == "service unavailable"
    assert runs[0]["raw_fields"] is None


def test_failed_run_then_success_counts_as_rerun(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行も履歴に数え、次の実行はrerunとなることを確認する。"""
    fake_analyzer.error = DiError("timeout")
    post_document(doc_client, document_type="order_project")
    run_idp(doc_client)

    fake_analyzer.error = None
    fake_analyzer.results = ORDER_RESULTS
    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["run_type"] == "rerun"


def test_run_requires_authentication(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    post_document(doc_client, document_type="order_project")
    doc_client.headers.pop("Authorization")

    assert run_idp(doc_client).status_code == 401
    assert doc_client.get("/api/documents/doc-001/idp-runs").status_code == 401


def test_list_runs_on_unknown_document_returns_404(doc_client: TestClient) -> None:
    response = doc_client.get("/api/documents/no-such-doc/idp-runs")
    assert response.status_code == 404


def test_analyzer_receives_query_fields_for_document_type(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """文書種別に対応するクエリセットでDIが呼ばれることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="order_route")

    run_idp(doc_client)

    assert fake_analyzer.calls
    _, query_fields = fake_analyzer.calls[0]
    assert "delivery_date" in query_fields


def test_run_returns_all_recognized_tables(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """認識されたテーブル領域（明細仮）が全件、実行応答と履歴の両方に返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.tables = ORDER_TABLES
    post_document(doc_client, document_type="order_project")

    response = run_idp(doc_client)

    assert response.status_code == 201
    tables = response.json()["tables"]
    assert len(tables) == 2
    header = tables[0]["cells"][0]
    assert tables[0]["row_count"] == 2
    assert tables[0]["column_count"] == 2
    assert header["content"] == "品目"
    assert header["kind"] == "columnHeader"
    assert header["page_number"] == 1
    assert header["polygon"] == [1.0, 2.0, 3.0, 2.0]

    listed = doc_client.get("/api/documents/doc-001/idp-runs").json()["runs"]
    assert listed[0]["tables"] == tables


def test_run_without_tables_returns_empty_list(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """成功実行でテーブル未検出の場合は空配列（Noneではない）を確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="order_project")

    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["tables"] == []


def test_failed_run_has_no_tables(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はtablesがNoneであることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="order_project")

    run_idp(doc_client)

    runs = doc_client.get("/api/documents/doc-001/idp-runs").json()["runs"]
    assert runs[0]["tables"] is None
