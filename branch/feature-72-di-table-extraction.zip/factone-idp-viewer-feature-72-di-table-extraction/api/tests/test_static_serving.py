"""フロント同居配信（StaticFiles+SPAフォールバック）のテスト。

viewer/dist をビルドせず、一時ディレクトリの擬似成果物で検証する。
"""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app
from tests.conftest import InMemoryBlobStorage


@pytest.fixture
def static_dir(tmp_path: Path) -> Path:
    (tmp_path / "index.html").write_text("<html>SPA INDEX</html>", encoding="utf-8")
    assets = tmp_path / "assets"
    assets.mkdir()
    (assets / "app.js").write_text("console.log('app')", encoding="utf-8")
    return tmp_path


@pytest.fixture
def static_client(static_dir: Path) -> TestClient:
    settings = Settings(_env_file=None, static_dir=str(static_dir))  # type: ignore[call-arg]
    app = create_app(settings=settings, blob_storage=InMemoryBlobStorage())
    return TestClient(app)


def test_root_serves_index(static_client: TestClient) -> None:
    """ルートパスでSPAのindex.htmlが返ることを確認する。"""
    response = static_client.get("/")

    assert response.status_code == 200
    assert "SPA INDEX" in response.text


def test_asset_files_are_served(static_client: TestClient) -> None:
    """ビルド成果物（assets配下）が配信されることを確認する。"""
    response = static_client.get("/assets/app.js")

    assert response.status_code == 200
    assert "console.log" in response.text


def test_spa_routes_fall_back_to_index(static_client: TestClient) -> None:
    """SPAのクライアントサイドルート（/view/{token}・/callback）がindex.htmlへフォールバックすることを確認する。"""
    for path in ["/view/some-token", "/callback"]:
        response = static_client.get(path)
        assert response.status_code == 200
        assert "SPA INDEX" in response.text


def test_api_routes_take_precedence(static_client: TestClient) -> None:
    """API経路（/health・/api・/view/{token}/pages）がSPAフォールバックに食われないことを確認する。"""
    assert static_client.get("/health").json() == {"status": "ok"}
    # 認証なしのAPIアクセスは401（SPAの200ではない）
    assert static_client.get("/api/me").status_code == 401
    # 公開閲覧APIは404（無効トークン。SPAフォールバックの200ではない）
    assert static_client.get(f"/view/{'x' * 43}/pages").status_code == 404


def test_no_static_dir_keeps_api_only(tmp_path: Path) -> None:
    """static_dir未存在時は従来どおりAPIのみ（ルートは404）を確認する。"""
    settings = Settings(  # type: ignore[call-arg]
        _env_file=None, static_dir=str(tmp_path / "missing")
    )
    app = create_app(settings=settings, blob_storage=InMemoryBlobStorage())
    client = TestClient(app)

    assert client.get("/").status_code == 404
    assert client.get("/health").status_code == 200
