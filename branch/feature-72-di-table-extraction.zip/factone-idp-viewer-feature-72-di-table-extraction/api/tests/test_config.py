from pathlib import Path

import pytest

from app.core.config import Settings


def test_settings_reads_env_var_with_prefix(monkeypatch: pytest.MonkeyPatch) -> None:
    """FACTONE_ プレフィックス付き環境変数から設定値を読み込めることを確認する。"""
    monkeypatch.setenv("FACTONE_APP_NAME", "factone-test")

    settings = Settings()

    assert settings.app_name == "factone-test"


def test_settings_has_default_app_name() -> None:
    """環境変数・.env が無い場合にデフォルト値が使われることを確認する。"""
    # _env_file はpydantic-settingsの実行時専用引数で型定義に現れないため型検査を除外
    settings = Settings(_env_file=None)  # type: ignore[call-arg]

    assert settings.app_name == "factone-api"


def test_default_env_file_is_repo_root_anchored() -> None:
    """既定の .env 参照先がcwdに依存せずリポジトリルート固定であることを確認する。"""
    env_file = Settings.model_config["env_file"]

    assert isinstance(env_file, Path)
    assert env_file.is_absolute()
    assert env_file.name == ".env"
    # リポジトリルートの目印（compose.yaml）と同じディレクトリを指すこと
    assert (env_file.parent / "compose.yaml").exists()


def test_settings_reads_dotenv_file(tmp_path: Path) -> None:
    """.env ファイルから設定値を読み込めることを確認する。"""
    env_file = tmp_path / ".env"
    env_file.write_text("FACTONE_APP_NAME=factone-from-dotenv\n", encoding="utf-8")

    settings = Settings(_env_file=env_file)  # type: ignore[call-arg]

    assert settings.app_name == "factone-from-dotenv"
