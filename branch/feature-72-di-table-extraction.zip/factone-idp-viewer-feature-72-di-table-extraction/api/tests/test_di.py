"""Document Intelligence境界のテーブル抽出テスト。

Azure SDKの解析結果（duck-typedスタブ）からDiTableへの変換を検証する。
"""

from types import SimpleNamespace
from typing import Any

from app.services.di import extract_tables


def _region(page_number: int, polygon: list[float]) -> SimpleNamespace:
    return SimpleNamespace(page_number=page_number, polygon=polygon)


def _cell(
    row_index: int,
    column_index: int,
    content: str,
    kind: str | None = None,
    bounding_regions: list[SimpleNamespace] | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        row_index=row_index,
        column_index=column_index,
        content=content,
        kind=kind,
        bounding_regions=bounding_regions,
    )


def _table(
    row_count: int, column_count: int, cells: list[SimpleNamespace]
) -> SimpleNamespace:
    return SimpleNamespace(row_count=row_count, column_count=column_count, cells=cells)


class TestExtractTables:
    def test_extracts_all_recognized_tables(self) -> None:
        # 複数テーブル認識時は全件返す（明細領域の特定はSaaS責務外）
        tables: list[Any] = [
            _table(
                2,
                2,
                [
                    _cell(
                        0,
                        0,
                        "品目",
                        kind="columnHeader",
                        bounding_regions=[_region(1, [1.0, 2.0, 3.0, 2.0])],
                    ),
                    _cell(
                        1,
                        0,
                        "P-9001",
                        bounding_regions=[_region(1, [1.0, 3.0, 3.0, 3.0])],
                    ),
                ],
            ),
            _table(1, 1, [_cell(0, 0, "備考")]),
        ]
        extracted = extract_tables(tables)
        assert len(extracted) == 2
        first = extracted[0]
        assert first.row_count == 2
        assert first.column_count == 2
        header = first.cells[0]
        assert header.row_index == 0
        assert header.column_index == 0
        assert header.content == "品目"
        assert header.kind == "columnHeader"
        assert header.page_number == 1
        assert header.polygon == (1.0, 2.0, 3.0, 2.0)
        assert extracted[1].cells[0].content == "備考"

    def test_cell_without_bounding_regions_has_no_position(self) -> None:
        tables: list[Any] = [_table(1, 1, [_cell(0, 0, "x", bounding_regions=None)])]
        cell = extract_tables(tables)[0].cells[0]
        assert cell.page_number is None
        assert cell.polygon is None

    def test_no_tables_yields_empty(self) -> None:
        # layout応答にtablesが無い（None）場合は空
        assert extract_tables(None) == ()
        assert extract_tables([]) == ()
