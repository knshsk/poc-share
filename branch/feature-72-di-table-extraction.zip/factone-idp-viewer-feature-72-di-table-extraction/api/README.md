# FactONE IDP/Viewer API

FastAPI 製バックエンド API。ディレクトリ構成は FastAPI 公式の [Bigger Applications](https://fastapi.tiangolo.com/tutorial/bigger-applications/) に準拠したレイヤー型構造を採用しています。

## ディレクトリ構成

```
api/
├── app/                   # アプリケーション本体
│   ├── main.py            # アプリファクトリ（create_app）。DI の組み立てとルーター登録
│   ├── models.py          # SQLAlchemy ORM モデル（全テーブル定義）
│   ├── core/              # 横断基盤（全ルーターが依存する共通機能）
│   │   ├── config.py      # 設定（環境変数、pydantic-settings）
│   │   ├── auth.py        # OIDC/JWT 認証
│   │   ├── db.py          # DB エンジン・セッションファクトリ
│   │   └── static_serving.py  # SPA 静的配信マウント
│   ├── routers/           # API エンドポイント（リクエスト/レスポンススキーマ同居）
│   │   ├── documents.py   # ドキュメント登録・取得・ページ画像
│   │   ├── idp_runs.py    # IDP 実行・履歴
│   │   └── view_urls.py   # 閲覧用 URL 発行・管理・公開閲覧・イベント記録
│   └── services/          # 外部サービス連携・ドメイン処理
│       ├── blob.py        # Blob ストレージ（Azure Blob / ローカルファイル）
│       ├── di.py          # Azure Document Intelligence クライアント
│       ├── idp_extraction.py  # DI 応答のパース・正規化
│       └── pdf_render.py  # PDF レンダリング（pypdfium2）
├── migrations/            # Alembic マイグレーション
├── scripts/               # 運用スクリプト（OpenAPI エクスポート等）
├── tests/                 # pytest テスト
├── alembic.ini
├── Containerfile
└── pyproject.toml         # 依存管理は uv
```

## 各ディレクトリの責務と配置指針

新しいモジュールをどこに置くか・どこを編集するかの判断基準です。

### `routers/` — API エンドポイント

- HTTP エンドポイント（`APIRouter`）を定義する層。リクエスト/レスポンスの Pydantic スキーマとエンドポイント固有のヘルパーも同じファイルに置きます
- **新規エンドポイントを追加するとき**: 既存の機能領域に属するなら該当ファイルへ追記、新しい機能領域なら新規ファイルを作成し `main.py` で `include_router` します

### `services/` — 外部連携・ドメイン処理

- 外部サービス（Blob ストレージ、Document Intelligence など）とのやり取りや、データ変換・パースなどの処理を置く層。FastAPI に依存しません
- **外部サービス連携や変換ロジックを追加するとき**: ここに新規ファイルを作成します。ルーターからは関数・クラスを import して使います

### `core/` — 横断基盤

- 認証・設定・DB 接続など、複数のルーターが共通で依存する基盤を置く層です
- **全体に関わる共通機能を追加するとき**: ここに置きます。特定機能でしか使わないものは `services/` へ

### `app/` 直下

- `main.py`: アプリファクトリ。依存オブジェクトの組み立てとルーター登録のみを行い、ビジネスロジックは書きません
- `models.py`: SQLAlchemy ORM モデル。**テーブルを追加するときはここに追記**し、Alembic マイグレーションを作成します（`migrations/env.py` が `app.models.Base` を参照）

## 起動・テスト

```
uv run uvicorn app.main:create_app --factory   # 起動
uv run pytest                                   # テスト
uv run ruff check app tests                     # lint
```
