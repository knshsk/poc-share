"""add tables to idp runs

Revision ID: e7b2c4a1f9d3
Revises: c41d8a92e510
Create Date: 2026-09-01 09:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "e7b2c4a1f9d3"
down_revision: str | None = "c41d8a92e510"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("idp_runs", sa.Column("tables", JSONB(), nullable=True))


def downgrade() -> None:
    op.drop_column("idp_runs", "tables")
