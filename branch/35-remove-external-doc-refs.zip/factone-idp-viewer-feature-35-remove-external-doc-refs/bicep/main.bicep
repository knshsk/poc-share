// FactONE IDP/Viewer コアインフラ（PoC・単一環境）
// リソースグループスコープ。デプロイは scripts/deploy-infra.sh を使用してください。
// ネットワーク隔離なし（パブリックエンドポイント＋サービス側制御）。
// 将来のVNet+Private Endpoint導入時はモジュール単位でネットワーク層を後付けする。

@description('環境名。リソース名の一部に使用（名前長制約のため4文字以内）')
@maxLength(4)
param environmentName string = 'poc'

@description('デプロイ先リージョン')
param location string = resourceGroup().location

@description('PostgreSQL管理者ユーザー名')
param postgresAdminLogin string

@description('PostgreSQL管理者パスワード（Key Vaultにも格納される）')
@secure()
param postgresAdminPassword string

// グローバル一意性が必要なリソース名に付与するサフィックス
var uniqueSuffix = uniqueString(resourceGroup().id)

module storage 'modules/storage.bicep' = {
  name: 'storage'
  params: {
    location: location
    storageAccountName: 'factone${environmentName}${take(uniqueSuffix, 8)}'
  }
}

module postgresql 'modules/postgresql.bicep' = {
  name: 'postgresql'
  params: {
    location: location
    serverName: 'factone-${environmentName}-pg-${uniqueSuffix}'
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
  }
}

module keyVault 'modules/keyvault.bicep' = {
  name: 'keyvault'
  params: {
    location: location
    keyVaultName: 'factone-${environmentName}-kv-${take(uniqueSuffix, 6)}'
    postgresAdminPassword: postgresAdminPassword
  }
}

module documentIntelligence 'modules/document-intelligence.bicep' = {
  name: 'document-intelligence'
  params: {
    location: location
    accountName: 'factone-${environmentName}-di-${uniqueSuffix}'
  }
}

module registry 'modules/acr.bicep' = {
  name: 'acr'
  params: {
    location: location
    registryName: 'factone${environmentName}acr${take(uniqueSuffix, 8)}'
  }
}

module containerAppsEnv 'modules/container-apps-env.bicep' = {
  name: 'container-apps-env'
  params: {
    location: location
    environmentName: 'factone-${environmentName}-cae'
    logAnalyticsName: 'factone-${environmentName}-log'
  }
}

module identities 'modules/identities.bicep' = {
  name: 'identities'
  params: {
    location: location
    apiIdentityName: 'factone-${environmentName}-api-id'
    keycloakIdentityName: 'factone-${environmentName}-kc-id'
  }
}

module appRoles 'modules/app-roles.bicep' = {
  name: 'app-roles'
  params: {
    apiPrincipalId: identities.outputs.apiPrincipalId
    keycloakPrincipalId: identities.outputs.keycloakPrincipalId
    storageAccountName: storage.outputs.storageAccountName
    documentIntelligenceName: 'factone-${environmentName}-di-${uniqueSuffix}'
    keyVaultName: keyVault.outputs.keyVaultName
    registryName: registry.outputs.registryName
  }
}

// ---- アプリ層（イメージビルド後の2回目以降のデプロイで有効化）----

@description('APIコンテナイメージ。空文字ならアプリ層をスキップ（初回=コアのみのデプロイ）')
param apiImage string = ''

@description('Keycloakコンテナイメージ。空文字ならスキップ')
param keycloakImage string = ''

@description('Keycloakブートストラップ管理者ユーザー名')
param keycloakAdminUser string = 'admin'

@description('Keycloakブートストラップ管理者パスワード（アプリ層デプロイ時必須）')
@secure()
param keycloakAdminPassword string = ''

@description('デプロイ時刻（リビジョンサフィックス用。既定で自動設定）')
param deployedAt string = utcNow('yyyyMMddHHmmss')

module keycloakApp 'modules/keycloak-app.bicep' = if (keycloakImage != '') {
  name: 'keycloak-app'
  dependsOn: [appRoles]
  params: {
    location: location
    appName: 'factone-${environmentName}-keycloak'
    environmentId: containerAppsEnv.outputs.environmentId
    image: keycloakImage
    revisionSuffix: 'r${deployedAt}'
    registryServer: registry.outputs.loginServer
    identityId: identities.outputs.keycloakIdentityId
    postgresFqdn: postgresql.outputs.serverFqdn
    dbUser: postgresAdminLogin
    dbPassword: postgresAdminPassword
    adminUser: keycloakAdminUser
    adminPassword: keycloakAdminPassword
    // Container AppsのFQDNは {アプリ名}.{Environmentのデフォルトドメイン} で決定的
    hostname: 'factone-${environmentName}-keycloak.${containerAppsEnv.outputs.defaultDomain}'
  }
}

module apiApp 'modules/api-app.bicep' = if (apiImage != '') {
  name: 'api-app'
  dependsOn: [appRoles]
  params: {
    location: location
    appName: 'factone-${environmentName}-api'
    environmentId: containerAppsEnv.outputs.environmentId
    image: apiImage
    revisionSuffix: 'r${deployedAt}'
    registryServer: registry.outputs.loginServer
    identityId: identities.outputs.apiIdentityId
    identityClientId: identities.outputs.apiClientId
    databaseUrl: 'postgresql+psycopg://${postgresAdminLogin}:${postgresAdminPassword}@${postgresql.outputs.serverFqdn}:5432/factone?sslmode=require'
    oidcIssuer: 'https://${keycloakApp!.outputs.fqdn}/realms/factone'
    blobAccountUrl: 'https://${storage.outputs.storageAccountName}.blob.${az.environment().suffixes.storage}'
  }
}

output storageAccountName string = storage.outputs.storageAccountName
output postgresServerFqdn string = postgresql.outputs.serverFqdn
output keyVaultName string = keyVault.outputs.keyVaultName
output documentIntelligenceEndpoint string = documentIntelligence.outputs.endpoint
output registryLoginServer string = registry.outputs.loginServer
output apiFqdn string = apiImage != '' ? apiApp!.outputs.fqdn : ''
output keycloakFqdn string = keycloakImage != '' ? keycloakApp!.outputs.fqdn : ''
