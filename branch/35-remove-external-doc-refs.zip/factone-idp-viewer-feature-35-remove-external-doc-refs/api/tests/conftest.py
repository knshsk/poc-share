import time
from collections.abc import Iterator
from typing import Any

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text

from app.auth import StaticKeySource
from app.config import Settings
from app.db import create_session_factory
from app.main import create_app

TEST_DATABASE_URL = (
    "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone_test"
)
ADMIN_DATABASE_URL = (
    "postgresql+psycopg://factone:changeme-postgres@localhost:5432/factone"
)


class InMemoryBlobStorage:
    """テスト用のBlobStorageフェイク。"""

    def __init__(self) -> None:
        self.saved: dict[str, bytes] = {}

    def save(self, ref: str, data: bytes) -> None:
        self.saved[ref] = data

    def load(self, ref: str) -> bytes:
        return self.saved[ref]


def make_token(key: RSAPrivateKey) -> str:
    claims: dict[str, Any] = {
        "iss": "http://localhost:8080/realms/factone",
        "aud": "factone-api",
        "sub": "test-user",
        "preferred_username": "testuser",
        "exp": int(time.time()) + 300,
    }
    return jwt.encode(claims, key, algorithm="RS256")


@pytest.fixture
def client() -> TestClient:
    return TestClient(create_app())


@pytest.fixture(scope="session")
def test_database_url() -> str:
    admin_engine = create_engine(ADMIN_DATABASE_URL, isolation_level="AUTOCOMMIT")
    with admin_engine.connect() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM pg_database WHERE datname = 'factone_test'")
        ).scalar()
        if not exists:
            conn.execute(text("CREATE DATABASE factone_test"))
    admin_engine.dispose()

    from alembic import command
    from alembic.config import Config

    config = Config("alembic.ini")
    config.set_main_option("script_location", "migrations")
    config.attributes["database_url"] = TEST_DATABASE_URL
    command.upgrade(config, "head")
    return TEST_DATABASE_URL


@pytest.fixture(scope="session")
def signing_key() -> RSAPrivateKey:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture
def blob_storage() -> InMemoryBlobStorage:
    return InMemoryBlobStorage()


@pytest.fixture
def doc_client(
    test_database_url: str,
    signing_key: RSAPrivateKey,
    blob_storage: InMemoryBlobStorage,
) -> Iterator[TestClient]:
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE documents CASCADE"))
        conn.execute(text("TRUNCATE TABLE view_access_failures"))
        conn.commit()

    settings = Settings(_env_file=None, database_url=test_database_url)  # type: ignore[call-arg]
    app = create_app(
        settings=settings,
        key_source=StaticKeySource(signing_key.public_key()),
        session_factory=create_session_factory(engine),
        blob_storage=blob_storage,
    )
    client = TestClient(app)
    client.headers["Authorization"] = f"Bearer {make_token(signing_key)}"
    yield client
    engine.dispose()
