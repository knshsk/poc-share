import { describe, expect, it } from 'vitest'

import {
  CAUTION_CONFIDENCE,
  fieldStatus,
  type FieldStatusKind,
  isConfidenceFlag,
  WARNING_CONFIDENCE,
} from '../src/utils/fieldStatus'

const base = { draft: false, corrected: false, value: 'x', confidence: 0.92 }

describe('fieldStatus', () => {
  // 0.8 以上は何も出さない。0.5 以上 0.8 未満は要確認、0.5 未満は要注意（境界は「未満」）
  it('確信度で ok / warning / caution に分け、文言に確信度を入れる', () => {
    expect(WARNING_CONFIDENCE).toBe(0.8)
    expect(CAUTION_CONFIDENCE).toBe(0.5)
    expect(fieldStatus(base)).toEqual({ kind: 'ok', text: '' })
    expect(fieldStatus({ ...base, confidence: 0.8 })).toEqual({
      kind: 'ok',
      text: '',
    })
    // ％は formatConfidence で丸める（0.799 は 80%）
    expect(fieldStatus({ ...base, confidence: 0.799 })).toEqual({
      kind: 'warning',
      text: '要確認（確信度 80%）',
    })
    expect(fieldStatus({ ...base, confidence: 0.62 })).toEqual({
      kind: 'warning',
      text: '要確認（確信度 62%）',
    })
    expect(fieldStatus({ ...base, confidence: 0.5 })).toEqual({
      kind: 'warning',
      text: '要確認（確信度 50%）',
    })
    expect(fieldStatus({ ...base, confidence: 0.499 })).toEqual({
      kind: 'caution',
      text: '要注意（確信度 50%）',
    })
    expect(fieldStatus({ ...base, confidence: 0.42 })).toEqual({
      kind: 'caution',
      text: '要注意（確信度 42%）',
    })
    expect(fieldStatus({ ...base, confidence: 0 })).toEqual({
      kind: 'caution',
      text: '要注意（確信度 0%）',
    })
  })

  // 優先順位: 未保存 > 修正済 > 未読取 > 確信度
  it('未保存・修正済・未読取を確信度より優先する', () => {
    expect(
      fieldStatus({
        draft: true,
        corrected: true,
        value: null,
        confidence: 0.1,
      }),
    ).toEqual({ kind: 'draft', text: '未保存' })
    expect(
      fieldStatus({ ...base, corrected: true, value: null, confidence: null }),
    ).toEqual({ kind: 'corrected', text: '修正済' })
    expect(fieldStatus({ ...base, corrected: true, confidence: 0.1 })).toEqual({
      kind: 'corrected',
      text: '修正済',
    })
    expect(fieldStatus({ ...base, value: null, confidence: 0 })).toEqual({
      kind: 'empty',
      text: '未読取',
    })
  })

  // 確信度を持たない値に「要注意（確信度 0%）」を出さない
  it('値があり確信度が null なら表示なし', () => {
    expect(fieldStatus({ ...base, confidence: null })).toEqual({
      kind: 'ok',
      text: '',
    })
  })

  it('要確認・要注意だけを確信度の印とする', () => {
    const kinds: FieldStatusKind[] = [
      'draft',
      'corrected',
      'empty',
      'warning',
      'caution',
      'ok',
    ]
    expect(kinds.filter(isConfidenceFlag)).toEqual(['warning', 'caution'])
  })
})
