import { formatConfidence } from './format'

// 確信度の閾値はここが唯一の定義。全エンジン共通の暫定の運用値（ADR-0031）
// これ未満を「要確認」にする
export const WARNING_CONFIDENCE = 0.8
// これ未満を「要注意」にする（入力欄を赤枠で強調する）
export const CAUTION_CONFIDENCE = 0.5

export type FieldStatusKind =
  'draft' | 'corrected' | 'empty' | 'warning' | 'caution' | 'ok'

export interface FieldStatus {
  kind: FieldStatusKind
  text: string
}

// 確信度で注意を促す状態。アイコンで示し、文言は title（ツールチップ）・読み上げ・明細の詳細欄に出す
export function isConfidenceFlag(
  kind: FieldStatusKind,
): kind is 'warning' | 'caution' {
  return kind === 'warning' || kind === 'caution'
}

// 値の状態表示。優先順位は 未保存 > 修正済 > 未読取 > 確信度
export function fieldStatus(input: {
  draft: boolean // 未保存の下書きがある
  corrected: boolean // 保存済みの人手修正に含まれる
  value: string | null // 抽出エンジンの読取値
  confidence: number | null
}): FieldStatus {
  if (input.draft) return { kind: 'draft', text: '未保存' }
  if (input.corrected) return { kind: 'corrected', text: '修正済' }
  if (input.value == null) return { kind: 'empty', text: '未読取' }
  // 確信度を持たない値と、閾値以上の値には何も出さない
  if (input.confidence == null || input.confidence >= WARNING_CONFIDENCE)
    return { kind: 'ok', text: '' }
  const percent = formatConfidence(input.confidence)
  return input.confidence < CAUTION_CONFIDENCE
    ? { kind: 'caution', text: `要注意（確信度 ${percent}）` }
    : { kind: 'warning', text: `要確認（確信度 ${percent}）` }
}
