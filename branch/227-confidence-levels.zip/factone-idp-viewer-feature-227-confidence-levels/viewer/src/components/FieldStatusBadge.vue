<script setup lang="ts">
// 値の状態表示（キー項目の状態列・明細の詳細欄で共用）。要確認は黄の三角、要注意は赤の丸、修正済は鉛筆のアイコン。
// 要確認・要注意は既定ではアイコンだけを見せ、文言は title（ツールチップ）と読み上げ用の見えないテキストに置く。
// labelled のとき（明細の詳細欄）は、アイコンに文言を添える。配置（揃え・高さ）は親が決める
import { PhPencilSimple, PhWarning, PhWarningCircle } from '@phosphor-icons/vue'
import { computed } from 'vue'

import { type FieldStatus, isConfidenceFlag } from '../utils/fieldStatus'

const props = defineProps<{ status: FieldStatus; labelled?: boolean }>()

// アイコンだけで示す（文言を見せない）
const iconOnly = computed(
  () => isConfidenceFlag(props.status.kind) && !props.labelled,
)
// 文言の無いアイコンは 14px では小さいため 16px にする
const iconSize = computed(() => (iconOnly.value ? 16 : 14))
</script>

<template>
  <span
    class="field-status"
    :class="`field-status--${status.kind}`"
    :title="iconOnly ? status.text : undefined"
  >
    <PhWarning
      v-if="status.kind === 'warning'"
      :size="iconSize"
      aria-hidden="true"
    />
    <PhWarningCircle
      v-if="status.kind === 'caution'"
      :size="iconSize"
      aria-hidden="true"
    />
    <PhPencilSimple
      v-if="status.kind === 'corrected'"
      :size="14"
      aria-hidden="true"
    />
    <span v-if="iconOnly" class="d-sr-only">{{ status.text }}</span>
    <template v-else>{{ status.text }}</template>
  </span>
</template>

<style scoped>
.field-status {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  white-space: nowrap;
}

.field-status--ok,
.field-status--empty {
  color: rgb(var(--v-theme-secondary));
}

.field-status--warning {
  color: rgb(var(--v-theme-warning));
  font-weight: 500;
}

.field-status--caution {
  color: rgb(var(--v-theme-error));
  font-weight: 500;
}

.field-status--corrected,
.field-status--draft {
  color: rgb(var(--v-theme-primary));
}

.field-status--draft {
  font-weight: 500;
}
</style>
