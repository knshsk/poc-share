<script setup lang="ts">
import { PhFileDashed } from '@phosphor-icons/vue'
import { ref, watch } from 'vue'

import { useBubble } from '../mediator/bubble'
import type { RegisterVm } from '../mediator/vm'

// 定型外フロー向けの手動登録フォーム。送信前の入力値は描画パラメータとして View が持ち、
// 送信時に register を bubble する（multipart 化・API 呼出・登録エラーの文言は Mediator）
const props = defineProps<{ vm: RegisterVm }>()

const bubble = useBubble()
const documentId = ref('')
const documentType = ref<string | null>(null)
const file = ref<File>()
const typeSelectRef = ref<{ focus: () => void } | null>(null)

// 再試行で種別一覧を取得できると、押した再試行ボタンが失敗の表示ごと消え、フォーカスが body に落ちる。
// 落ちたときだけ書類種別へ移す（応答待ちの間に別の入力欄へ移っていれば奪わない）。表示が消えた後の DOM で判定する
watch(
  () => props.vm.typesFailed,
  (failed) => {
    if (!failed && document.activeElement === document.body) {
      typeSelectRef.value?.focus()
    }
  },
  { flush: 'post' },
)

function submit(): void {
  const type = documentType.value
  const pdf = file.value
  if (!documentId.value || !type || !pdf) return
  bubble({
    type: 'register',
    documentId: documentId.value,
    documentType: type,
    file: pdf,
  })
}
</script>

<template>
  <v-form @submit.prevent="submit">
    <!-- 種別一覧を取得できなかったとき。再試行の応答待ちはボタンを loading にする（disabled にしない） -->
    <v-alert
      v-if="vm.typesFailed"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-3"
      data-testid="register-types-error"
    >
      書類種別の一覧を取得できませんでした
      <template #append>
        <v-btn
          variant="text"
          size="small"
          :loading="vm.typesLoading"
          data-testid="register-types-retry"
          @click="bubble({ type: 'retryDocumentTypes' })"
        >
          再試行
        </v-btn>
      </template>
    </v-alert>
    <v-select
      ref="typeSelectRef"
      v-model="documentType"
      :items="vm.typeItems"
      item-title="display_name"
      item-value="type_code"
      label="書類種別"
      no-data-text="選択できる書類種別がありません"
      class="mb-3"
      hide-details
      data-testid="register-document-type"
    />
    <v-text-field
      v-model="documentId"
      label="文書ID"
      class="mb-3"
      hide-details
      data-testid="register-document-id"
    />
    <!-- ドロップゾーン: D&D は accept 属性が効かないため filter-by-type で PDF 以外を拒否する。
         選択後はゾーン内にファイル名を表示し（inset-file-list）、高さを変えずに差し替え・解除できる -->
    <v-file-upload
      v-model="file"
      :icon="PhFileDashed"
      title="PDFファイルをドラッグ＆ドロップ、またはクリックして選択"
      browse-text="ファイルを変更"
      filter-by-type="application/pdf"
      density="comfortable"
      hide-browse
      inset-file-list
      clearable
      show-size
      class="register-dropzone mb-4"
      data-testid="register-file"
    />
    <v-alert
      v-if="vm.error"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-4"
      data-testid="register-error"
    >
      {{ vm.error }}
    </v-alert>
    <div class="d-flex justify-center">
      <v-btn
        type="submit"
        color="primary"
        min-width="120"
        :loading="vm.submitting"
        :disabled="!documentId || !documentType || !file"
        data-testid="register-submit"
      >
        登録
      </v-btn>
    </div>
  </v-form>
</template>

<style scoped>
/* ドロップゾーン: 空/選択済みで高さを固定し、Vuetify 既定の見出しサイズを補助文言相当へ落とす */
.register-dropzone :deep(.v-file-upload-dropzone) {
  min-height: 168px;
  padding: 24px 16px;
}

.register-dropzone :deep(.v-file-upload-title) {
  font-size: 0.875rem;
  font-weight: 400;
  color: rgb(var(--v-theme-secondary));
}

.register-dropzone :deep(.v-file-upload-icon) {
  color: rgb(var(--v-theme-secondary));
  opacity: 1;
  margin-bottom: 0.25rem;
}
</style>
