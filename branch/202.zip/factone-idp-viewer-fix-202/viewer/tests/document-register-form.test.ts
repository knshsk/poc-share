import { enableAutoUnmount, flushPromises, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import DocumentRegisterForm from '../src/components/DocumentRegisterForm.vue'
import { BUBBLE } from '../src/mediator/bubble'
import type { RegisterVm } from '../src/mediator/vm'
import { createAppVuetify } from '../src/plugins/vuetify'
import { configs, registerVm } from './fixtures'

const pdf = new File(['%PDF-1.4'], 'order.pdf', { type: 'application/pdf' })
const bubble = vi.fn()

// フォーカスを確かめるテストは attachTo で document に置く
function mountForm(over: Partial<RegisterVm> = {}, attachTo?: HTMLElement) {
  return mount(DocumentRegisterForm, {
    props: { vm: registerVm(over) },
    attachTo,
    global: {
      plugins: [createAppVuetify()],
      provide: { [BUBBLE as symbol]: bubble },
    },
  })
}

// 文書ID・種別・PDFを入力済みにする
async function fillForm(wrapper: ReturnType<typeof mountForm>) {
  await wrapper
    .get('[data-testid="register-document-id"] input')
    .setValue('doc-9')
  await wrapper
    .findComponent({ name: 'VSelect' })
    .vm.$emit('update:modelValue', 'quotation')
  await wrapper
    .findComponent({ name: 'VFileUpload' })
    .vm.$emit('update:modelValue', pdf)
  await flushPromises()
}

enableAutoUnmount(afterEach)

beforeEach(() => {
  bubble.mockClear()
})

describe('DocumentRegisterForm', () => {
  // 種別一覧は vm から受け取り、display_name を選択肢として表示する
  it('vm の種別一覧を選択肢に表示する', () => {
    const select = mountForm().findComponent({ name: 'VSelect' })
    expect(select.props('items')).toEqual(configs)
    expect(select.props('itemTitle')).toBe('display_name')
    expect(select.props('itemValue')).toBe('type_code')
  })

  // 選択肢が無いのは、種別一覧の取得に失敗したときと、テナントに種別が無いとき
  it('選択肢が無いときの文言を指定する', () => {
    const select = mountForm().findComponent({ name: 'VSelect' })
    expect(select.props('noDataText')).toBe('選択できる書類種別がありません')
  })

  // 送信は入力値を register として bubble する（multipart 化と API 呼出は Mediator）
  it('送信で register を bubble する', async () => {
    const wrapper = mountForm()
    await fillForm(wrapper)
    await wrapper.get('form').trigger('submit')
    expect(bubble).toHaveBeenCalledWith({
      type: 'register',
      documentId: 'doc-9',
      documentType: 'quotation',
      file: pdf,
    })
  })

  // 未入力（文書ID・種別・PDFのいずれか欠落）では登録ボタンを無効化し、送信しない
  it('未入力では登録ボタンを無効化し送信しない', async () => {
    const wrapper = mountForm()
    const button = wrapper.get<HTMLButtonElement>(
      '[data-testid="register-submit"]',
    )
    expect(button.element.disabled).toBe(true)
    await wrapper.get('form').trigger('submit')
    expect(bubble).not.toHaveBeenCalled()

    await fillForm(wrapper)
    expect(button.element.disabled).toBe(false)
  })

  // ドロップゾーンはPDFのみ受け付け（D&Dはaccept属性が効かないためfilter-by-typeで絞る）、選択後はゾーン内にファイル名を表示する
  it('ドロップゾーンはPDFのみ受け付け選択後はゾーン内にファイル名を表示する', async () => {
    const wrapper = mountForm()
    const upload = wrapper.findComponent({ name: 'VFileUpload' })
    expect(upload.props('filterByType')).toBe('application/pdf')
    expect(upload.props('insetFileList')).toBe(true)

    await upload.vm.$emit('update:modelValue', pdf)
    await flushPromises()
    expect(wrapper.get('.v-file-upload-dropzone').text()).toContain('order.pdf')
  })

  // 種別一覧を取得できなかったことを表示し、再試行は Mediator へ bubble する
  it('種別一覧の取得に失敗すると失敗を表示し、再試行で retryDocumentTypes を bubble する', async () => {
    expect(
      mountForm().find('[data-testid="register-types-error"]').exists(),
    ).toBe(false)

    const wrapper = mountForm({ typeItems: [], typesFailed: true })
    const alert = wrapper.get('[data-testid="register-types-error"]')
    expect(alert.text()).toContain('書類種別')
    await wrapper.get('[data-testid="register-types-retry"]').trigger('click')
    expect(bubble).toHaveBeenCalledWith({ type: 'retryDocumentTypes' })
  })

  // 応答待ちの間は loading にする（disabled にすると、押した直後にフォーカスが外れる）
  it('再試行の応答待ちは、再試行ボタンを loading にする', () => {
    const retry = mountForm({
      typeItems: [],
      typesFailed: true,
      typesLoading: true,
    }).get<HTMLButtonElement>('[data-testid="register-types-retry"]')
    expect(retry.classes()).toContain('v-btn--loading')
    expect(retry.element.disabled).toBe(false)
  })

  // 取得できると、押した再試行ボタンが失敗の表示ごと消えてフォーカスが body に落ちる。続けて選べるよう書類種別へ移す
  it('再試行で取得できると、書類種別へフォーカスを移す', async () => {
    const wrapper = mountForm(
      { typeItems: [], typesFailed: true },
      document.body,
    )
    wrapper
      .get<HTMLButtonElement>('[data-testid="register-types-retry"]')
      .element.focus()
    await wrapper.setProps({ vm: registerVm() })
    await flushPromises()
    expect(document.activeElement).toBe(
      wrapper.get('[data-testid="register-document-type"] input').element,
    )
  })

  // 応答待ちの間に文書IDを打ち始めていれば、取得できてもフォーカスを奪わない
  it('再試行の応答待ちに別の入力欄へ移っていれば、取得できてもフォーカスを動かさない', async () => {
    const wrapper = mountForm(
      { typeItems: [], typesFailed: true },
      document.body,
    )
    const idInput = wrapper.get<HTMLInputElement>(
      '[data-testid="register-document-id"] input',
    ).element
    idInput.focus()
    await wrapper.setProps({ vm: registerVm() })
    await flushPromises()
    expect(document.activeElement).toBe(idInput)
  })

  it('vm のエラーを表示し、送信中はボタンを loading にする', () => {
    const wrapper = mountForm({
      error: '文書IDは別の内容で登録済みです',
      submitting: true,
    })
    expect(wrapper.get('[data-testid="register-error"]').text()).toContain(
      '文書IDは別の内容で登録済み',
    )
    expect(wrapper.get('[data-testid="register-submit"]').classes()).toContain(
      'v-btn--loading',
    )
  })
})
