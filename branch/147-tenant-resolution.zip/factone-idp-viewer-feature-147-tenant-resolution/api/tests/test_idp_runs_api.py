"""IDP実行APIの統合テスト（実PostgreSQLコンテナ接続）。

事前に `podman compose up -d postgres` が必要。
共有フィクスチャ（doc_client・fake_analyzer等）は conftest.py を参照。
"""

from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text

from app.services.di import DiError, DiTable, DiTableCell
from tests.conftest import FakeDocumentAnalyzer, InMemoryBlobStorage
from tests.test_documents_api import post_document

ORDER_RESULTS = {
    "SenderCompanyName": ("株式会社サンプル商事", 0.98),
    "PurchaseOrderId": ("PO-2026-9101", 0.95),
    "DeliveryDate": ("2026-10-30", 0.97),
    "TotalAmount": ("1,200,000", 0.96),
}

ORDER_TABLES = (
    DiTable(
        row_count=2,
        column_count=2,
        cells=(
            DiTableCell(
                row_index=0,
                column_index=0,
                content="品目",
                kind="columnHeader",
                page_number=1,
                polygon=(1.0, 2.0, 3.0, 2.0),
            ),
            DiTableCell(
                row_index=1,
                column_index=0,
                content="P-9001",
                kind=None,
                page_number=1,
                polygon=(1.0, 3.0, 3.0, 3.0),
            ),
        ),
    ),
    DiTable(row_count=1, column_count=1, cells=()),
)


def run_idp(client: TestClient, document_id: str = "doc-001") -> Any:
    return client.post(f"/api/v1/documents/{document_id}/idp-runs")


def get_run(client: TestClient, document_id: str, run_id: str) -> Any:
    return client.get(f"/api/v1/documents/{document_id}/idp-runs/{run_id}")


def post_correction(
    client: TestClient, document_id: str, run_id: str, body: dict[str, Any]
) -> Any:
    return client.post(
        f"/api/v1/documents/{document_id}/idp-runs/{run_id}/corrections", json=body
    )


def _run_with_tables(
    client: TestClient,
    fake_analyzer: FakeDocumentAnalyzer,
    document_id: str = "doc-001",
) -> Any:
    """注文書を登録して成功実行を1回行い、その応答JSONを返す。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.tables = ORDER_TABLES
    fake_analyzer.regions = {"TotalAmount": (1, (6.8, 2.9, 7.3, 2.9))}
    fake_analyzer.content = "T1234567890123"
    post_document(client, document_id=document_id, document_type="purchase_order")
    return run_idp(client, document_id).json()


def test_first_run_returns_extraction_with_confidence(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """初回実行が201となり、生値・正規化値・確信度が項目別に返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    body = response.json()
    assert body["document_id"] == "doc-001"
    assert body["run_type"] == "initial"
    assert body["status"] == "succeeded"
    assert body["raw_fields"]["TotalAmount"] == "1,200,000"
    assert body["normalized_fields"]["TotalAmount"] == 1200000
    assert body["confidence"]["TotalAmount"] == 0.96
    assert body["error_info"] is None
    assert body["run_id"]
    assert body["executed_at"]


def test_rerun_is_distinguished_and_appended(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """再実行がrerunとして区別され、履歴が上書きされず追記されることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    first = run_idp(doc_client)
    second = run_idp(doc_client)

    assert first.json()["run_type"] == "initial"
    assert second.json()["run_type"] == "rerun"
    assert first.json()["run_id"] != second.json()["run_id"]

    listing = doc_client.get("/api/v1/documents/doc-001/idp-runs")
    assert listing.status_code == 200
    runs = listing.json()["runs"]
    assert len(runs) == 2
    assert [run["run_type"] for run in runs] == ["initial", "rerun"]


def test_run_on_unknown_document_returns_404(doc_client: TestClient) -> None:
    response = run_idp(doc_client, document_id="no-such-doc")
    assert response.status_code == 404


def test_di_failure_returns_502_and_records_failed_run(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """DI障害時に502となり、失敗実行がエラー情報付きで履歴に記録されることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 502
    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert len(runs) == 1
    assert runs[0]["status"] == "failed"
    assert runs[0]["error_info"] == "service unavailable"
    assert (
        get_run(doc_client, "doc-001", runs[0]["run_id"]).json()["raw_fields"] is None
    )


def test_failed_run_then_success_counts_as_rerun(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行も履歴に数え、次の実行はrerunとなることを確認する。"""
    fake_analyzer.error = DiError("timeout")
    post_document(doc_client, document_type="purchase_order")
    run_idp(doc_client)

    fake_analyzer.error = None
    fake_analyzer.results = ORDER_RESULTS
    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["run_type"] == "rerun"


def test_run_requires_authentication(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    post_document(doc_client, document_type="purchase_order")
    doc_client.headers.pop("Authorization")

    assert run_idp(doc_client).status_code == 401
    assert doc_client.get("/api/v1/documents/doc-001/idp-runs").status_code == 401


def test_list_runs_on_unknown_document_returns_404(doc_client: TestClient) -> None:
    response = doc_client.get("/api/v1/documents/no-such-doc/idp-runs")
    assert response.status_code == 404


def test_analyzer_receives_query_fields_for_document_type(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """文書種別に対応するクエリセットでDIが呼ばれることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="quotation")

    run_idp(doc_client)

    assert fake_analyzer.calls
    _, query_fields = fake_analyzer.calls[0]
    assert "QuotationId" in query_fields
    assert "PurchaseOrderId" not in query_fields


def test_run_returns_all_recognized_tables(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """認識されたテーブル領域（明細仮）が全件、実行応答と履歴の両方に返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.tables = ORDER_TABLES
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    tables = response.json()["tables"]
    assert len(tables) == 2
    header = tables[0]["cells"][0]
    assert tables[0]["row_count"] == 2
    assert tables[0]["column_count"] == 2
    assert header["content"] == "品目"
    assert header["kind"] == "columnHeader"
    assert header["page_number"] == 1
    assert header["polygon"] == [1.0, 2.0, 3.0, 2.0]

    run_id = response.json()["run_id"]
    assert get_run(doc_client, "doc-001", run_id).json()["tables"] == tables


def test_run_without_tables_returns_empty_list(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """成功実行でテーブル未検出の場合は空配列（Noneではない）を確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["tables"] == []


def test_failed_run_has_no_tables(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はtablesがNoneであることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    run_idp(doc_client)

    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert get_run(doc_client, "doc-001", runs[0]["run_id"]).json()["tables"] is None


def test_query_fields_come_from_config(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """設定を書き換えると次回実行のquery_fieldsに反映されることを確認する。"""
    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "special_field", "label": "特殊項目", "type": "string"}],
        },
    )
    post_document(doc_client, document_id="idp-cfg-1", document_type="quotation")
    fake_analyzer.results = {"special_field": ("value-1", 0.9)}
    response = run_idp(doc_client, "idp-cfg-1")
    assert response.status_code == 201
    assert fake_analyzer.calls[-1][1] == ("special_field",)
    assert response.json()["raw_fields"] == {"special_field": "value-1"}


def test_run_returns_field_labels_snapshot(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """成功実行の応答と履歴に実行時点のラベル（key→label）が返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    labels = response.json()["field_labels"]
    assert labels["TotalAmount"] == "合計金額"
    assert labels["DeliveryDate"] == "納品期限"

    run_id = response.json()["run_id"]
    assert get_run(doc_client, "doc-001", run_id).json()["field_labels"] == labels


def test_field_labels_keep_run_time_value_after_config_change(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """設定のラベル変更後も過去実行は実行時点のラベルを保持することを確認する。"""
    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
        },
    )
    post_document(doc_client, document_id="idp-lbl-1", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9)}
    run_idp(doc_client, "idp-lbl-1")

    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "総額", "type": "number"}],
        },
    )
    run_idp(doc_client, "idp-lbl-1")

    runs = doc_client.get("/api/v1/documents/idp-lbl-1/idp-runs").json()["runs"]
    first = get_run(doc_client, "idp-lbl-1", runs[0]["run_id"]).json()
    second = get_run(doc_client, "idp-lbl-1", runs[1]["run_id"]).json()
    assert first["field_labels"] == {"amount": "金額"}
    assert second["field_labels"] == {"amount": "総額"}


def test_failed_run_has_no_field_labels(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はfield_labelsがNoneであることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    run_idp(doc_client)

    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    detail = get_run(doc_client, "doc-001", runs[0]["run_id"]).json()
    assert detail["field_labels"] is None


def test_unregistered_document_type_returns_409(
    doc_client: TestClient, test_database_url: str
) -> None:
    """設定削除後の残存文書の実行は409（削除保護があるため通常発生しないが防御的に）。"""
    post_document(doc_client, document_id="idp-cfg-2", document_type="quotation")
    engine = create_engine(test_database_url)
    with engine.connect() as conn:
        conn.execute(
            text("DELETE FROM document_type_configs WHERE type_code = 'quotation'")
        )
        conn.commit()
    engine.dispose()
    response = run_idp(doc_client, "idp-cfg-2")
    assert response.status_code == 409


def _put_quotation_with_tcode(client: TestClient) -> None:
    client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
            "patterns": [{"key": "TCode", "label": "登録番号", "regex": r"T\d{13}"}],
        },
    )


def test_run_returns_pattern_matches_in_order_with_duplicates(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """全文中のTコードを出現順・重複ありで返し、履歴にも同じ内容が保存されることを確認する。"""
    _put_quotation_with_tcode(doc_client)
    post_document(doc_client, document_id="idp-pat-1", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9)}
    fake_analyzer.content = "登録番号 T1234567890123\n合計 100\nT1234567890123"

    response = run_idp(doc_client, "idp-pat-1")

    assert response.status_code == 201
    expected = {
        "TCode": {
            "label": "登録番号",
            "regex": r"T\d{13}",
            "values": ["T1234567890123", "T1234567890123"],
        }
    }
    assert response.json()["pattern_matches"] == expected
    detail = get_run(doc_client, "idp-pat-1", response.json()["run_id"]).json()
    assert detail["pattern_matches"] == expected


def test_run_without_patterns_returns_empty_dict(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """パターン未設定の種別（テストシードは patterns なし）では空dictを返すことを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.content = "T1234567890123"
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    assert response.json()["pattern_matches"] == {}


def test_pattern_matches_keep_run_time_regex_after_config_change(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """設定のregex変更後も過去実行は実行時点のregexと結果を保持することを確認する。"""
    _put_quotation_with_tcode(doc_client)
    post_document(doc_client, document_id="idp-pat-2", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9)}
    fake_analyzer.content = "T1234567890123 Q-000001"
    run_idp(doc_client, "idp-pat-2")

    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
            "patterns": [
                {"key": "QuotationNo", "label": "見積番号", "regex": r"Q-\d{6}"}
            ],
        },
    )
    run_idp(doc_client, "idp-pat-2")

    runs = doc_client.get("/api/v1/documents/idp-pat-2/idp-runs").json()["runs"]
    first = get_run(doc_client, "idp-pat-2", runs[0]["run_id"]).json()
    second = get_run(doc_client, "idp-pat-2", runs[1]["run_id"]).json()
    assert list(first["pattern_matches"]) == ["TCode"]
    assert second["pattern_matches"] == {
        "QuotationNo": {
            "label": "見積番号",
            "regex": r"Q-\d{6}",
            "values": ["Q-000001"],
        }
    }


def test_failed_run_has_no_pattern_matches(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """失敗実行はpattern_matchesがNoneであることを確認する。"""
    _put_quotation_with_tcode(doc_client)
    post_document(doc_client, document_id="idp-pat-3", document_type="quotation")
    fake_analyzer.error = DiError("service unavailable")

    run_idp(doc_client, "idp-pat-3")

    runs = doc_client.get("/api/v1/documents/idp-pat-3/idp-runs").json()["runs"]
    detail = get_run(doc_client, "idp-pat-3", runs[0]["run_id"]).json()
    assert detail["pattern_matches"] is None


def test_run_saves_raw_response_to_blob_and_records_di_info(
    doc_client: TestClient,
    fake_analyzer: FakeDocumentAnalyzer,
    blob_storage: InMemoryBlobStorage,
) -> None:
    """成功実行で生応答が {tenant}/{doc}/idp-runs/{run_id}.json にバイト一致で保存され、
    DIのAPIバージョン・モデルIDが応答と履歴に記録されることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.raw_response = (
        b'{"status":"succeeded","analyzeResult":{"content":"x"}}'
    )
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    assert response.status_code == 201
    body = response.json()
    run_id = body["run_id"]
    assert blob_storage.saved[f"default/doc-001/idp-runs/{run_id}.json"] == (
        b'{"status":"succeeded","analyzeResult":{"content":"x"}}'
    )
    assert body["di_api_version"] == "2024-11-30"
    assert body["di_model_id"] == "prebuilt-layout"
    assert "raw_response_ref" not in body

    listed = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    assert listed[0]["di_api_version"] == "2024-11-30"
    assert listed[0]["di_model_id"] == "prebuilt-layout"


def test_failed_run_saves_nothing_and_has_no_di_info(
    doc_client: TestClient,
    fake_analyzer: FakeDocumentAnalyzer,
    blob_storage: InMemoryBlobStorage,
) -> None:
    """失敗実行は生応答を保存せず、DI情報・領域がNoneであることを確認する。"""
    fake_analyzer.error = DiError("service unavailable")
    post_document(doc_client, document_type="purchase_order")

    run_idp(doc_client)

    assert [ref for ref in blob_storage.saved if "/idp-runs/" in ref] == []
    run = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"][0]
    assert run["di_api_version"] is None
    assert run["di_model_id"] is None
    assert get_run(doc_client, "doc-001", run["run_id"]).json()["field_regions"] is None


def test_run_returns_field_regions(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """領域ありの項目は {page_number, polygon}、領域なし・値なしの項目はnullで返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.regions = {
        "TotalAmount": (1, (6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1)),
    }
    post_document(doc_client, document_type="purchase_order")

    response = run_idp(doc_client)

    regions = response.json()["field_regions"]
    assert regions["TotalAmount"] == {
        "page_number": 1,
        "polygon": [6.8, 2.9, 7.3, 2.9, 7.3, 3.1, 6.8, 3.1],
    }
    assert regions["SenderCompanyName"] is None  # 値あり・領域なし
    assert regions["QuotationId"] is None  # 未抽出
    run_id = response.json()["run_id"]
    assert get_run(doc_client, "doc-001", run_id).json()["field_regions"] == regions


def test_raw_response_endpoint_returns_saved_bytes(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """保存した生応答がそのままのbytesで application/json として返ることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.raw_response = (
        b'{"status": "succeeded", "analyzeResult": {"pages": []}}'
    )
    post_document(doc_client, document_type="purchase_order")
    run_id = run_idp(doc_client).json()["run_id"]

    response = doc_client.get(
        f"/api/v1/documents/doc-001/idp-runs/{run_id}/raw-response"
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/json")
    assert (
        response.content == b'{"status": "succeeded", "analyzeResult": {"pages": []}}'
    )


def test_raw_response_for_failed_run_returns_404(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    fake_analyzer.error = DiError("timeout")
    post_document(doc_client, document_type="purchase_order")
    run_idp(doc_client)
    run_id = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"][0][
        "run_id"
    ]

    response = doc_client.get(
        f"/api/v1/documents/doc-001/idp-runs/{run_id}/raw-response"
    )

    assert response.status_code == 404
    assert response.json()["type"] == "/errors/raw-response-not-found"


def test_raw_response_for_unknown_or_foreign_run_returns_404(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """存在しないrun_id・他文書のrun_idはいずれも404 idp-run-not-found（存在を秘匿）。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_id="doc-a", document_type="purchase_order")
    post_document(doc_client, document_id="doc-b", document_type="purchase_order")
    run_id = run_idp(doc_client, "doc-a").json()["run_id"]

    unknown = doc_client.get(
        "/api/v1/documents/doc-a/idp-runs/00000000-0000-4000-8000-000000000000/raw-response"
    )
    foreign = doc_client.get(f"/api/v1/documents/doc-b/idp-runs/{run_id}/raw-response")

    assert unknown.status_code == 404
    assert unknown.json()["type"] == "/errors/idp-run-not-found"
    assert foreign.status_code == 404
    assert foreign.json()["type"] == "/errors/idp-run-not-found"


def test_raw_response_requires_authentication(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")
    run_id = run_idp(doc_client).json()["run_id"]
    doc_client.headers.pop("Authorization")

    response = doc_client.get(
        f"/api/v1/documents/doc-001/idp-runs/{run_id}/raw-response"
    )

    assert response.status_code == 401


def test_get_run_returns_full_detail(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """詳細取得が実行応答と同じ内容（項目値・テーブル・領域を含む）を返すことを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.tables = ORDER_TABLES
    post_document(doc_client, document_type="purchase_order")
    created = run_idp(doc_client).json()

    response = get_run(doc_client, "doc-001", created["run_id"])

    assert response.status_code == 200
    assert response.json() == created


def test_get_run_unknown_or_foreign_returns_404(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """存在しないrun_id・他文書のrun_idは404 idp-run-not-found（存在を秘匿）。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_id="doc-a", document_type="purchase_order")
    post_document(doc_client, document_id="doc-b", document_type="purchase_order")
    run_id = run_idp(doc_client, "doc-a").json()["run_id"]

    unknown = get_run(doc_client, "doc-a", "00000000-0000-4000-8000-000000000000")
    foreign = get_run(doc_client, "doc-b", run_id)

    assert unknown.status_code == 404
    assert unknown.json()["type"] == "/errors/idp-run-not-found"
    assert foreign.status_code == 404
    assert foreign.json()["type"] == "/errors/idp-run-not-found"


def test_latest_returns_newest_succeeded_run(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """latest は成功実行のうち最新を返し、後続の失敗実行は無視されることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")
    run_idp(doc_client)
    second = run_idp(doc_client).json()
    fake_analyzer.error = DiError("timeout")
    run_idp(doc_client)

    response = doc_client.get("/api/v1/documents/doc-001/idp-runs/latest")

    assert response.status_code == 200
    assert response.json() == second


def test_latest_filters_by_run_type(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")
    first = run_idp(doc_client).json()
    second = run_idp(doc_client).json()

    initial = doc_client.get(
        "/api/v1/documents/doc-001/idp-runs/latest", params={"run_type": "initial"}
    )
    rerun = doc_client.get(
        "/api/v1/documents/doc-001/idp-runs/latest", params={"run_type": "rerun"}
    )
    invalid = doc_client.get(
        "/api/v1/documents/doc-001/idp-runs/latest", params={"run_type": "bogus"}
    )

    assert initial.json()["run_id"] == first["run_id"]
    assert rerun.json()["run_id"] == second["run_id"]
    assert invalid.status_code == 422
    assert invalid.json()["type"] == "/errors/validation-error"


def test_latest_returns_404_without_succeeded_run(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """実行なし・失敗実行のみのときは404 idp-run-not-found。"""
    post_document(doc_client, document_type="purchase_order")

    none = doc_client.get("/api/v1/documents/doc-001/idp-runs/latest")

    fake_analyzer.error = DiError("timeout")
    run_idp(doc_client)
    failed_only = doc_client.get("/api/v1/documents/doc-001/idp-runs/latest")

    assert none.status_code == 404
    assert none.json()["type"] == "/errors/idp-run-not-found"
    assert failed_only.status_code == 404


def test_detail_and_latest_require_authentication(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")
    run_id = run_idp(doc_client).json()["run_id"]
    doc_client.headers.pop("Authorization")

    assert get_run(doc_client, "doc-001", run_id).status_code == 401
    assert (
        doc_client.get("/api/v1/documents/doc-001/idp-runs/latest").status_code == 401
    )


def test_list_returns_summaries_without_heavy_fields(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """一覧は軽量項目のみを返し、項目値・テーブル・領域・パターン一致を含まないことを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    fake_analyzer.tables = ORDER_TABLES
    post_document(doc_client, document_type="purchase_order")
    created = run_idp(doc_client).json()

    listing = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()

    assert listing["document_id"] == "doc-001"
    assert listing["runs"] == [
        {
            "run_id": created["run_id"],
            "document_id": "doc-001",
            "run_type": "initial",
            "status": "succeeded",
            "executed_at": created["executed_at"],
            "base_run_id": None,
            "corrected_by": None,
            "di_api_version": "2024-11-30",
            "di_model_id": "prebuilt-layout",
            "error_info": None,
        }
    ]


def test_corrected_row_requires_base_and_corrector(
    doc_client: TestClient, test_database_url: str
) -> None:
    """corrected 行は base_run_id と corrected_by が必須で、機械実行は両方 NULL であることを DB 制約で確認する。"""
    from sqlalchemy.exc import IntegrityError

    post_document(doc_client, document_type="purchase_order")
    engine = create_engine(test_database_url)
    insert = text(
        "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at, "
        "base_run_id, corrected_by) VALUES (gen_random_uuid(), "
        "(SELECT id FROM documents WHERE document_id = 'doc-001'), :run_type, "
        "'succeeded', now(), :base, :by)"
    )
    with engine.connect() as conn:
        base_id = conn.execute(
            text(
                "INSERT INTO idp_runs (id, document_pk, run_type, status, executed_at) "
                "VALUES (gen_random_uuid(), "
                "(SELECT id FROM documents WHERE document_id = 'doc-001'), "
                "'initial', 'succeeded', now()) RETURNING id"
            )
        ).scalar_one()
        conn.commit()
        for params in (
            {"run_type": "corrected", "base": None, "by": "u"},
            {"run_type": "corrected", "base": base_id, "by": None},
            {"run_type": "rerun", "base": base_id, "by": None},
            {"run_type": "rerun", "base": None, "by": "u"},
        ):
            with pytest.raises(IntegrityError):
                conn.execute(insert, params)
            conn.rollback()
        conn.execute(insert, {"run_type": "corrected", "base": base_id, "by": "u"})
        conn.commit()
    engine.dispose()


def test_machine_run_has_no_correction_fields(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """機械実行の詳細は base_run_id / corrected_by / corrections が null であることを確認する。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    body = run_idp(doc_client).json()

    assert body["base_run_id"] is None
    assert body["corrected_by"] is None
    assert body["corrections"] is None


def test_correction_merges_fields_and_cells_and_copies_base(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """修正行は差分をマージし、変更キーの確信度がnull、未変更キーとbase由来の列を維持することを確認する。"""
    base = _run_with_tables(doc_client, fake_analyzer)
    body = {
        "fields": {"TotalAmount": "1,250,000", "DeliveryDate": None},
        "table_cells": [
            {"table_index": 0, "row_index": 1, "column_index": 0, "content": "P-9002"}
        ],
    }

    response = post_correction(doc_client, "doc-001", base["run_id"], body)

    assert response.status_code == 201
    corrected = response.json()
    assert corrected["run_type"] == "corrected"
    assert corrected["status"] == "succeeded"
    assert corrected["error_info"] is None
    assert corrected["run_id"] != base["run_id"]
    assert corrected["base_run_id"] == base["run_id"]
    assert corrected["corrected_by"] == "testuser"
    assert corrected["corrections"] == body
    assert corrected["raw_fields"] == {
        **base["raw_fields"],
        "TotalAmount": "1,250,000",
        "DeliveryDate": None,
    }
    assert corrected["normalized_fields"] == {
        **base["normalized_fields"],
        "TotalAmount": 1250000,
        "DeliveryDate": None,
    }
    assert corrected["confidence"] == {
        **base["confidence"],
        "TotalAmount": None,
        "DeliveryDate": None,
    }
    assert corrected["tables"][0]["cells"][1]["content"] == "P-9002"
    assert corrected["tables"][0]["cells"][1]["polygon"] == [1.0, 3.0, 3.0, 3.0]
    assert corrected["tables"][0]["cells"][0] == base["tables"][0]["cells"][0]
    assert corrected["tables"][1] == base["tables"][1]
    for key in (
        "field_labels",
        "pattern_matches",
        "field_regions",
        "di_api_version",
        "di_model_id",
    ):
        assert corrected[key] == base[key], key
    assert "raw_response_ref" not in corrected


def test_correction_inherits_raw_response_reference(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """修正行からも元のDI生応答を取得できることを確認する。"""
    base = _run_with_tables(doc_client, fake_analyzer)
    corrected = post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {"TotalAmount": "1"}}
    ).json()

    response = doc_client.get(
        f"/api/v1/documents/doc-001/idp-runs/{corrected['run_id']}/raw-response"
    )

    assert response.status_code == 200
    assert response.content == fake_analyzer.raw_response


def test_correction_renormalizes_with_current_config_type(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """再正規化は実行時点でなく現在の設定型で行い、設定に無いキーはstringとして扱うことを確認する。"""
    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [
                {"key": "amount", "label": "金額", "type": "string"},
                {"key": "issued", "label": "発行日", "type": "string"},
            ],
        },
    )
    post_document(doc_client, document_id="idp-cor-1", document_type="quotation")
    fake_analyzer.results = {"amount": ("100", 0.9), "issued": ("2026/01/02", 0.9)}
    base = run_idp(doc_client, "idp-cor-1").json()
    assert base["normalized_fields"] == {"amount": "100", "issued": "2026/01/02"}

    doc_client.put(
        "/api/v1/config/document-types/quotation",
        json={
            "display_name": "見積書",
            "shareable": True,
            "fields": [{"key": "amount", "label": "金額", "type": "number"}],
        },
    )
    corrected = post_correction(
        doc_client,
        "idp-cor-1",
        base["run_id"],
        {"fields": {"amount": "1,500", "issued": "2026/03/04"}},
    ).json()

    assert corrected["normalized_fields"] == {"amount": 1500, "issued": "2026/03/04"}
    assert corrected["field_labels"] == base["field_labels"]


def test_correction_can_chain_on_corrected_run(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """corrected行をbaseにした再修正で、前回の修正が値にも corrections にも引き継がれることを確認する。

    corrections は根の機械実行に対する累積差分。同一キー・同一セルの再修正は後の値が勝つ。
    """
    base = _run_with_tables(doc_client, fake_analyzer)
    cell = {"table_index": 0, "row_index": 1, "column_index": 0}
    first = post_correction(
        doc_client,
        "doc-001",
        base["run_id"],
        {
            "fields": {"TotalAmount": "1", "DeliveryDate": "2026-11-01"},
            "table_cells": [{**cell, "content": "A"}],
        },
    ).json()

    second = post_correction(
        doc_client,
        "doc-001",
        first["run_id"],
        {
            "fields": {"TotalAmount": "2"},
            "table_cells": [
                {**cell, "content": "B"},
                {"table_index": 0, "row_index": 0, "column_index": 0, "content": "C"},
            ],
        },
    ).json()

    assert second["base_run_id"] == first["run_id"]
    assert second["raw_fields"]["TotalAmount"] == "2"
    assert second["raw_fields"]["DeliveryDate"] == "2026-11-01"
    assert second["normalized_fields"]["DeliveryDate"] == "2026-11-01"
    assert second["confidence"]["TotalAmount"] is None
    assert second["tables"][0]["cells"][1]["content"] == "B"
    assert second["corrections"] == {
        "fields": {"TotalAmount": "2", "DeliveryDate": "2026-11-01"},
        "table_cells": [
            {**cell, "content": "B"},
            {"table_index": 0, "row_index": 0, "column_index": 0, "content": "C"},
        ],
    }
    # 1 世代目だけの修正は first の corrections にのみ残る（後から差分を復元できる）
    assert first["corrections"] == {
        "fields": {"TotalAmount": "1", "DeliveryDate": "2026-11-01"},
        "table_cells": [{**cell, "content": "A"}],
    }


def test_correction_appears_in_list_and_latest(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """一覧にcorrected行が追記され、latestが修正行を返しrun_type=correctedで絞れることを確認する。"""
    base = _run_with_tables(doc_client, fake_analyzer)
    corrected = post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {"TotalAmount": "1"}}
    ).json()

    runs = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]
    latest = doc_client.get("/api/v1/documents/doc-001/idp-runs/latest").json()
    only_corrected = doc_client.get(
        "/api/v1/documents/doc-001/idp-runs/latest", params={"run_type": "corrected"}
    ).json()
    only_initial = doc_client.get(
        "/api/v1/documents/doc-001/idp-runs/latest", params={"run_type": "initial"}
    ).json()

    assert [r["run_type"] for r in runs] == ["initial", "corrected"]
    assert runs[1]["base_run_id"] == base["run_id"]
    assert runs[1]["corrected_by"] == "testuser"
    assert latest["run_id"] == corrected["run_id"]
    assert only_corrected["run_id"] == corrected["run_id"]
    assert only_initial["run_id"] == base["run_id"]
    assert latest["corrections"] == corrected["corrections"]


def test_run_after_correction_is_rerun(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """corrected行も既存実行に数え、次の機械実行はrerunになることを確認する。"""
    base = _run_with_tables(doc_client, fake_analyzer)
    post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {"TotalAmount": "1"}}
    )

    response = run_idp(doc_client)

    assert response.json()["run_type"] == "rerun"


def test_correction_rejects_empty_body_and_duplicate_cells(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """両方空・同一セル座標の重複は422 validation-error（Pydantic検証）。"""
    base = _run_with_tables(doc_client, fake_analyzer)
    cell = {"table_index": 0, "row_index": 1, "column_index": 0, "content": "a"}

    empty = post_correction(doc_client, "doc-001", base["run_id"], {})
    both_empty = post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {}, "table_cells": []}
    )
    duplicate = post_correction(
        doc_client,
        "doc-001",
        base["run_id"],
        {"table_cells": [cell, {**cell, "content": "b"}]},
    )
    too_long = post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {"TotalAmount": "x" * 2001}}
    )
    negative = post_correction(
        doc_client,
        "doc-001",
        base["run_id"],
        {"table_cells": [{**cell, "row_index": -1}]},
    )

    for response in (empty, both_empty, duplicate, too_long, negative):
        assert response.status_code == 422
        assert response.json()["type"] == "/errors/validation-error"


def test_correction_rejects_unknown_key_and_cell(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    """baseに無いキー・セル座標は422 unknown-correction-targetで、行は追記されないことを確認する。"""
    base = _run_with_tables(doc_client, fake_analyzer)

    unknown_key = post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {"Bogus": "x"}}
    )
    unknown_cell = post_correction(
        doc_client,
        "doc-001",
        base["run_id"],
        {
            "table_cells": [
                {"table_index": 0, "row_index": 5, "column_index": 0, "content": "x"}
            ]
        },
    )
    unknown_table = post_correction(
        doc_client,
        "doc-001",
        base["run_id"],
        {
            "table_cells": [
                {"table_index": 9, "row_index": 0, "column_index": 0, "content": "x"}
            ]
        },
    )

    for response in (unknown_key, unknown_cell, unknown_table):
        assert response.status_code == 422
        assert response.json()["type"] == "/errors/unknown-correction-target"
    assert len(doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"]) == 1


def test_correction_on_failed_run_returns_409(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    fake_analyzer.error = DiError("timeout")
    post_document(doc_client, document_type="purchase_order")
    run_idp(doc_client)
    failed_id = doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"][0][
        "run_id"
    ]

    response = post_correction(
        doc_client, "doc-001", failed_id, {"fields": {"TotalAmount": "1"}}
    )

    assert response.status_code == 409
    assert response.json()["type"] == "/errors/idp-run-not-correctable"


def test_correction_on_unknown_or_foreign_run_returns_404(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    base = _run_with_tables(doc_client, fake_analyzer, document_id="doc-a")
    post_document(doc_client, document_id="doc-b", document_type="purchase_order")
    body = {"fields": {"TotalAmount": "1"}}

    unknown = post_correction(
        doc_client, "doc-a", "00000000-0000-4000-8000-000000000000", body
    )
    foreign = post_correction(doc_client, "doc-b", base["run_id"], body)
    no_doc = post_correction(doc_client, "no-such-doc", base["run_id"], body)

    assert unknown.status_code == 404
    assert unknown.json()["type"] == "/errors/idp-run-not-found"
    assert foreign.status_code == 404
    assert foreign.json()["type"] == "/errors/idp-run-not-found"
    assert no_doc.status_code == 404
    assert no_doc.json()["type"] == "/errors/document-not-found"


def test_correction_requires_authentication(
    doc_client: TestClient, fake_analyzer: FakeDocumentAnalyzer
) -> None:
    base = _run_with_tables(doc_client, fake_analyzer)
    doc_client.headers.pop("Authorization")

    response = post_correction(
        doc_client, "doc-001", base["run_id"], {"fields": {"TotalAmount": "1"}}
    )

    assert response.status_code == 401


def test_blob_save_failure_returns_500_and_records_no_run(
    doc_client: TestClient,
    fake_analyzer: FakeDocumentAnalyzer,
    blob_storage: InMemoryBlobStorage,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """生応答のBlob保存失敗は500 internal-errorで、実行ログを残さない（#113持ち越し回帰）。"""
    fake_analyzer.results = ORDER_RESULTS
    post_document(doc_client, document_type="purchase_order")

    def fail(ref: str, data: bytes) -> None:
        raise OSError("blob unavailable")

    monkeypatch.setattr(blob_storage, "save", fail)
    client = TestClient(doc_client.app, raise_server_exceptions=False)
    client.headers["Authorization"] = doc_client.headers["Authorization"]

    response = client.post("/api/v1/documents/doc-001/idp-runs")

    assert response.status_code == 500
    assert response.json()["type"] == "/errors/internal-error"
    assert doc_client.get("/api/v1/documents/doc-001/idp-runs").json()["runs"] == []
