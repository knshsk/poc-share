# API

## 役割

FastAPI 製のバックエンド。文書・文書種別設定・IDP 実行・閲覧 URL の管理 API（認証あり、`/api/v1/**`）、閲覧者向けの公開閲覧 API（無認証、`/view/{token}/**`）、Viewer SPA の静的配信を 1 プロセスで担う。PoC では単一レプリカで動かし、コンテナの起動コマンド（`api/Containerfile`）で `alembic upgrade head` を実行してから uvicorn を起動する。

## 構成

```mermaid
flowchart TB
    subgraph core["core/（横断基盤）"]
        config["config.py 設定"]
        auth["auth.py JWT 検証"]
        db["db.py DB セッション"]
        problem["problem.py RFC 9457 エラー応答"]
        static["static_serving.py SPA 配信"]
    end
    subgraph routers["routers/（エンドポイント）"]
        rDoc["documents.py"]
        rRun["idp_runs.py"]
        rUrl["view_urls.py"]
        rCfg["document_type_configs.py"]
    end
    subgraph services["services/（外部連携・変換。FastAPI 非依存）"]
        blob["blob.py BlobStorage"]
        di["di.py DocumentAnalyzer"]
        pdf["pdf_render.py PdfRenderer"]
        extract["idp_extraction.py パース・正規化・修正適用"]
        cfg["document_type_config.py 設定の取得と型付け"]
    end
    models["models.py SQLAlchemy ORM"]
    main["main.py create_app（組み立て）"]
    ext_blob[("Blob")]
    ext_di["Document Intelligence"]
    ext_pg[("PostgreSQL")]

    main --> core
    main --> routers
    main --> services
    routers --> core
    routers --> services
    routers --> models
    cfg --> models
    blob --> ext_blob
    di --> ext_di
    db --> ext_pg
```

- `routers/` はエンドポイントとリクエスト / レスポンスの Pydantic スキーマ。`services/` は外部サービスとのやり取りとデータ変換で、FastAPI に依存しない（`document_type_config.py` の設定取得だけは SQLAlchemy セッションを受け取る）。`core/` は全ルーターが共有する基盤。配置指針は [api/README.md](../../api/README.md)
- 外部境界（Blob・DI・PDF レンダラ・JWT 検証鍵の取得）は `typing.Protocol` で呼出口を定義し、実装を `create_app` の引数で差し替える（[ADR-0004](../adr/0004-external-system-boundary-adapters.md)）。DB セッションファクトリも同様に引数で差し替えられる。実装の組は次のとおり。テストでは各 Protocol をフェイクに差し替える

| 境界 | Protocol | ローカル | Azure |
| --- | --- | --- | --- |
| Blob | `BlobStorage` | `LocalFileBlobStorage`（`FACTONE_BLOB_LOCAL_DIR`） | `AzureBlobStorage`（Managed ID） |
| 抽出エンジン | `DocumentAnalyzer` | `UnconfiguredAnalyzer`（常に失敗 → 502） | `AzureDocumentAnalyzer`（API キーまたは Managed ID） |
| PDF レンダラ | `PdfRenderer` | `PdfiumRenderer`（pypdfium2） | 同左 |
| JWT 検証鍵 | `KeySource` | `JwksKeySource`（Keycloak の JWKS） | 同左 |

- `create_app` が設定を読み、上記の実装を組み立てて `app.state` に載せ、ルーターを登録し、最後に SPA 配信の catch-all を登録する（API ルート優先の担保）
- テナントは JWT のクレーム `tenant_id`（`CurrentUser.tenant_id`）で解決し、文書・文書種別設定・閲覧 URL・実行ログをこの値で絞る（[auth.md](auth.md)）。不一致は 404。クレームが無いトークンは 403 `tenant-unresolved`。文書は `(tenant_id, document_id)` で引き、`document_id` はテナント内でのみ一意（[ADR-0021](../adr/0021-documents-uuid-primary-key.md)）
- ORM モデルは `models.py` に集約し、スキーマ変更は Alembic マイグレーションで管理する

## リソースと操作

個別のパラメータ・応答は [api/openapi.json](../api/openapi.json) が正。ここでは群と役割のみ示す。

| 群 | パス | 操作 |
| --- | --- | --- |
| 文書種別設定 | `/api/v1/config/document-types[/{type_code}]` | 一覧・作成・取得・更新・削除。テナント別。`fields`（key / label / type / visible）と `patterns`（正規表現）と `shareable` を持つ。使用中の種別は削除できない（409）（[ADR-0014](../adr/0014-tenant-document-type-config.md)） |
| 文書 | `/api/v1/documents[/{document_id}]`、`.../pages`、`.../pages/{page}/image`、`.../pdf` | 登録（multipart、冪等）、取得、ページ寸法一覧（インチ）、ページ画像（PNG、都度生成）、原本 PDF |
| IDP 実行 | `/api/v1/documents/{document_id}/idp-runs[/latest | /{run_id} | /{run_id}/raw-response | /{run_id}/corrections]` | 実行、サマリ一覧（`executed_at` 昇順）、最新の成功実行（外部連携システムが結果だけ取る用途。Viewer は使わず一覧末尾を選ぶ）、詳細、DI 生応答、人手修正の追記 |
| 閲覧 URL | `/api/v1/documents/{document_id}/view-urls[/revoke-all]`、`/api/v1/view-urls/{view_url_id}/revoke`、`/api/v1/documents/{document_id}/events`、`/api/v1/view-events` | 発行、一覧、一括失効、失効、文書別イベント一覧、横断差分フィード（[view-url.md](view-url.md)） |
| 公開閲覧 | `/view/{token}/pages`、`.../pages/{page}/image`、`.../pdf` | 無認証。IP のレート制限（429）→ トークン検証（不成立は 404）→ 配信と閲覧イベント記録 |
| その他 | `/health`、`/api/v1/me`、`/{full_path}` | ヘルスチェック、認証確認（sub / username）、SPA 配信（`api/` 始まりは 404） |

- 版は URL パス（`v1`）。破壊的変更の扱いは [api/README.md](../api/README.md)（[ADR-0017](../adr/0017-api-versioning-url-path.md)）
- 全エラーは RFC 9457 Problem Details（`application/problem+json`、`type: /errors/<code>`）。code の一覧は [api/README.md](../api/README.md)（[ADR-0016](../adr/0016-rfc9457-problem-details.md)）
- 他文書の実行 ID・存在しない文書は存在を秘匿するため一律 404

## 主要処理の流れ

### IDP 実行（`POST .../idp-runs`）

1. 文書を取得（テナント違い・不在は 404）
2. 同一文書の既存実行（失敗・修正行を含む）の有無で `initial` / `rerun` を決める
3. 文書種別設定を取得。無ければ 409（`document-type-not-configured`）。`fields[].key` が DI への Query Fields になる
4. 実行 ID を先に採番し、Blob から PDF を読んで `DocumentAnalyzer.analyze(pdf, query_fields)` を呼ぶ。`DiError`（タイムアウト・未設定を含む）なら `failed` 行を保存して 502（`document-analysis-failed`）
5. 生応答を無変換で Blob `{tenant_id}/{document_id}/idp-runs/{run_id}.json` に保存し、DB には参照パスだけ持つ（[ADR-0019](../adr/0019-raw-di-response-in-blob.md)）。この保存で例外が出ると実行ログ行を残さず 500（`internal-error`）になり、DI 失敗時と非対称
6. `parse_analysis` で項目ごとに生値・正規化値・確信度・読取領域を組み立てる。正規化は `fields[].type`（string / number / date）で駆動し、正規化できない値は null。生値と正規化値は分けて保存する（[ADR-0005](../adr/0005-append-only-logs-and-raw-normalized-separation.md)）。規則は [data-model/idp-runs.md](../data-model/idp-runs.md)
7. 実行時点の `fields[].label` をスナップショット、テーブル領域を素通しで JSON 化、`patterns[].regex` を全文テキストに適用して一致値を集める
8. `succeeded` 行を挿入し、`IdpRunResponse` を返す

### 文書登録（`POST /api/v1/documents`）

1. content-type と先頭バイト `%PDF` で PDF 判定（違えば 415）
2. 文書種別がテナントに設定済みか（無ければ 422）
3. 同じ `document_id` の既存行があれば冪等判定: SHA-256 と文書種別が両方一致なら 200、どちらか違えば 409。この経路では Blob に触れない
4. Blob `{tenant_id}/{document_id}.pdf` に保存し、`documents` 行を挿入して 201。挿入競合（同時登録）はロールバックして 3 の判定に戻るが、Blob 保存は挿入より先に行うため 2 本目も Blob へ書きに行く。Azure Blob は上書き不可で保存するので、同時登録の 2 本目は 500 になりうる（PoC 制限）

### 人手修正の追記（`POST .../idp-runs/{run_id}/corrections`）

1. base（`run_id`）を取得。失敗実行なら 409（`idp-run-not-correctable`）
2. `apply_corrections` で base の値に差分（`fields` と `table_cells`）を当てる。修正した項目は現在の文書種別設定の型で再正規化し（設定が無い・キーが設定に無いときは string 扱い）、確信度は null にする。base に無いキー・座標は 422（`unknown-correction-target`）
3. `corrections` は base の累積差分に今回分を重ねる（同一キー・同一セル座標は後勝ち）。結果は根の機械実行に対する全差分になる（[ADR-0018](../adr/0018-corrections-as-appended-idp-runs.md)）
4. `corrected` 行を追記する。`base_run_id`・`corrected_by`（JWT の `preferred_username`、無ければ `sub`）を持ち、読取領域・ラベル・パターン一致・DI 情報・生応答参照は base から引き継ぐ。排他制御はしない

### ページ画像（`GET .../pages/{page}/image`）

Blob から PDF を読み、pypdfium2 で該当ページを 150 dpi の PNG に描画して返す。保存しない。範囲外のページは 404（`page-not-found`）、PDF の処理失敗は 500（`pdf-processing-failed`）。公開閲覧側は `Cache-Control: no-store` を付ける。ページ寸法一覧はポイント値を 72 で割ったインチ単位で返し、Viewer が SVG の `viewBox` にそのまま使う（[viewer/display.md](../viewer/display.md)）。

## 外部依存・設定

設定は `core/config.py` の `Settings`（pydantic-settings）。環境変数のプレフィックスは `FACTONE_`、ローカルはリポジトリルートの `.env` からも読む。

| 設定 | 既定値 | 用途 |
| --- | --- | --- |
| `APP_NAME` | `factone-api` | FastAPI のタイトル |
| `OIDC_ISSUER` / `OIDC_AUDIENCE` | `http://localhost:8080/realms/factone` / `factone-api` | JWT 検証。JWKS URL は issuer から導出 |
| `DATABASE_URL` | ローカルスタック向け | PostgreSQL（SQLAlchemy + psycopg） |
| `BLOB_BACKEND` / `BLOB_LOCAL_DIR` / `BLOB_ACCOUNT_URL` / `BLOB_CONTAINER` | `local` / `.blob-data` / 空 / `documents` | Blob の実装選択と接続先 |
| `DI_ENDPOINT` / `DI_API_KEY` / `DI_TIMEOUT_SECONDS` | 空 / 空 / 120 | DI 接続。endpoint 未設定なら実行は 502。api_key 未設定なら Managed ID |
| `STATIC_DIR` | `static` | Viewer ビルド成果物。存在するときだけ配信する |
| `VIEW_URL_DEFAULT_TTL_DAYS` / `VIEW_URL_MAX_FAILURES` / `VIEW_URL_FAILURE_WINDOW_SECONDS` | 90 / 10 / 60 | 閲覧 URL の既定期限と失敗レート制限 |

外部依存: PostgreSQL、Blob（ローカルファイルまたは Azure Blob）、Document Intelligence（`prebuilt-layout` + Query Fields）、IdP（JWKS）。

## 詳細仕様への導線

- [api/README.md](../api/README.md)（バージョニング・エラー応答・破壊的変更の記録）、[api/openapi.json](../api/openapi.json)（契約の正。pre-commit でドリフト検出）
- [data-model/](../data-model/README.md)（テーブル定義・正規化規則・JSON 列の構造）
- [api/README.md（リポジトリ）](../../api/README.md)（ディレクトリ構成と配置指針）、[develop-guide/api.md](../develop-guide/api.md)（起動・テスト・契約生成）
- ADR-0004 / 0005 / 0014 / 0016 / 0017 / 0018 / 0019
