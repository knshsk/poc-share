import { mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { describe, expect, it, vi } from 'vitest'

const signinCallback = vi.fn()
vi.mock('oidc-client-ts', () => ({
  UserManager: class {
    signinRedirect = vi.fn()
    signinCallback = signinCallback
    signoutRedirect = vi.fn()
  },
  WebStorageStateStore: class {},
  InMemoryWebStorage: class {},
}))
vi.mock('../src/api/client', () => ({
  apiClient: {
    GET: vi.fn().mockResolvedValue({ data: undefined, error: {} }),
  },
}))

import App from '../src/App.vue'
import { createAppVuetify } from '../src/plugins/vuetify'
import { useAuthStore } from '../src/stores/auth'
import { useDocumentStore } from '../src/stores/document'

describe('App', () => {
  // コールバック処理後にログイン前URL（document_id付き）へ復元され、
  // 認証後にマウントされるDocumentViewがその document_id を受け取ることを確認する
  it('コールバック後にログイン前URLのdocument_idをDocumentViewが受け取る', async () => {
    window.history.replaceState(null, '', '/callback?code=abc&state=xyz')
    signinCallback.mockResolvedValue({
      access_token: 'token-abc',
      profile: {},
      state: { returnTo: '/?document_id=doc-1' },
    })
    const pinia = createPinia()

    mount(App, { global: { plugins: [createAppVuetify(), pinia] } })
    await vi.waitFor(() => {
      expect(useDocumentStore(pinia).documentId).toBe('doc-1')
    })

    expect(window.location.pathname + window.location.search).toBe(
      '/?document_id=doc-1',
    )
    window.history.replaceState(null, '', '/')
  })

  // Vuetify・Piniaを組み込んだAppがレンダリングされ、アプリ名が表示されることを確認する
  it('アプリ名を表示する', () => {
    const wrapper = mount(App, {
      global: {
        plugins: [createAppVuetify(), createPinia()],
      },
    })

    expect(wrapper.text()).toContain('FactONE Viewer')
  })

  // 未認証時はログインカードを表示することを確認する
  it('未認証時はログインボタンを表示する', () => {
    const wrapper = mount(App, {
      global: { plugins: [createAppVuetify(), createPinia()] },
    })

    expect(wrapper.text()).toContain('ログイン')
  })

  // 認証済でもデバッグ要素（API呼出・/api/v1/me表示）を持たないことを確認する
  it('認証済時にデバッグ要素を表示しない', async () => {
    window.history.replaceState(null, '', '/')
    const wrapper = mount(App, {
      global: { plugins: [createAppVuetify(), createPinia()] },
    })
    const auth = useAuthStore()
    auth.isAuthenticated = true
    auth.username = 'sales01'
    await wrapper.vm.$nextTick()

    expect(wrapper.text()).not.toContain('API呼出')
    expect(wrapper.text()).not.toContain('/api/v1/me')
  })
})
