<script setup lang="ts">
import { onMounted, ref } from 'vue'

import { apiClient } from '../api/client'

// 定型外フロー向けの手動登録フォーム。送信先は既存の POST /api/v1/documents（Power Automate と同一API）
const emit = defineEmits<{ registered: [documentId: string] }>()

const documentId = ref('')
const documentType = ref<string | null>(null)
const file = ref<File | null>(null)
const typeItems = ref<{ display_name: string; type_code: string }[]>([])
const submitting = ref(false)
const errorMessage = ref<string | null>(null)

onMounted(async () => {
  const { data } = await apiClient.GET('/api/v1/config/document-types')
  typeItems.value = data ?? []
})

async function submit(): Promise<void> {
  if (!documentId.value || !documentType.value || !file.value) return
  errorMessage.value = null
  submitting.value = true
  const form = new FormData()
  form.set('document_id', documentId.value)
  form.set('document_type', documentType.value)
  form.set('file', file.value)
  try {
    const { data, error } = await apiClient.POST('/api/v1/documents', {
      // OpenAPI型はbinary=stringだが実体はFile。multipart化はbodySerializerで行う
      body: {
        document_id: documentId.value,
        document_type: documentType.value,
        file: file.value as unknown as string,
      },
      bodySerializer: () => form,
    })
    if (error || !data) {
      errorMessage.value =
        error?.status === 409
          ? '文書IDは別の内容で登録済みです'
          : (error?.detail ?? '登録に失敗しました')
      return
    }
    // 200（同一内容の再送）も登録済みとして成功扱い
    emit('registered', data.document_id)
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <v-form @submit.prevent="submit">
    <v-text-field
      v-model="documentId"
      label="文書ID"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-document-id"
    />
    <v-select
      v-model="documentType"
      :items="typeItems"
      item-title="display_name"
      item-value="type_code"
      label="書類種別"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-document-type"
    />
    <v-file-input
      v-model="file"
      label="PDFファイル"
      accept="application/pdf"
      density="compact"
      class="mb-3"
      hide-details
      data-testid="register-file"
    />
    <v-alert
      v-if="errorMessage"
      type="error"
      density="compact"
      variant="tonal"
      class="mb-3"
      data-testid="register-error"
    >
      {{ errorMessage }}
    </v-alert>
    <v-btn
      type="submit"
      color="primary"
      block
      :loading="submitting"
      data-testid="register-submit"
    >
      登録
    </v-btn>
  </v-form>
</template>
