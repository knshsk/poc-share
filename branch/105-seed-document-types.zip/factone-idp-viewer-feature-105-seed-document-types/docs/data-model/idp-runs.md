# IDP実行ログ（idp_runs）

Document Intelligenceによる項目抽出の実行履歴。追記型（再実行で過去結果を上書きしない）。

## テーブル定義

| 列 | 型 | 制約 | 説明 |
| --- | --- | --- | --- |
| id | uuid | PK | 実行ID（サーバ採番） |
| document_id | varchar(255) | NOT NULL・FK(documents) | 対象文書 |
| run_type | varchar(20) | NOT NULL・CHECK | `initial`（初回）/ `rerun`（再実行）。同一文書IDの既存実行有無からサーバ側で自動判定（失敗実行も既存実行に数える） |
| status | varchar(20) | NOT NULL・CHECK | `succeeded` / `failed` |
| executed_at | timestamptz | NOT NULL | 実行日時（サーバで記録） |
| raw_fields | jsonb | NULL可 | 項目別の生値（DIが返した文字列そのまま）。失敗時はNULL |
| normalized_fields | jsonb | NULL可 | 項目別の正規化値（数値はカンマ除去して整数化、日付はISO 8601化）。正規化不能な値はnull |
| confidence | jsonb | NULL可 | 項目別確信度（0〜1）。返却・記録のみで閾値判定には使用しない |
| tables | jsonb | NULL可 | DIが認識したテーブル領域（明細仮）の配列。成功時はテーブル未検出でも空配列、失敗時はNULL |
| error_info | varchar(2048) | NULL可 | 失敗時のエラー情報 |

- 生値・正規化値・確信度を分離保持する（生OCR結果と正規化値の分離方針に基づく）
- JSONのキーは文書種別ごとのクエリセット（`api/app/services/idp_extraction.py`）と一致する。未抽出項目もキーを残し、値はnull

### tables（テーブル領域）の構造

- 各要素は `row_count` / `column_count` / `cells` を持つ。複数テーブル認識時は全件保持する
- `cells` の各要素は `row_index` / `column_index` / `content` / `kind`（`columnHeader` 等、無い場合null）/ `page_number` / `polygon`（座標配列。無い場合null）
- DIの認識結果を意味付けせず素通しする。どのテーブルが明細領域か、どの列・行がSAP入力項目の何に相当するかの判断はSaaS側の責務外（利用側で解釈する）

## 抽出方式

- prebuilt-layout+Query Fields（学習・ラベリングなしで項目指定抽出と項目別確信度を取得）
- クエリセットは文書種別ごとに固定。確定抽出項目が未確定のため、検証用サンプルPDFの様式に合わせた仮置き
  - 注文書（案件型・ルート型）: 得意先コード・品目コード・数量・納期・単価
  - 見積: 文書番号・得意先コード・発行日・合計金額
- WBS原価データは様式確定まで対象外
- 同期応答（非同期化の要否は処理時間・サイズ上限の確定後に再検討）。タイムアウトは設定値 `FACTONE_DI_TIMEOUT_SECONDS`（既定120秒）

## API

- `POST /api/v1/documents/{document_id}/idp-runs`（JWT必須）— 登録済文書に対して抽出を実行し、結果を履歴に追記して返す。DI失敗時は502を返し、失敗実行もerror_info付きで記録する
- `GET /api/v1/documents/{document_id}/idp-runs`（JWT必須）— 実行履歴一覧（実行日時昇順）
