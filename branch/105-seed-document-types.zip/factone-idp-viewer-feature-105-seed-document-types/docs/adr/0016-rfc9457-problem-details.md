---
status: accepted
date: 2026-09-09
---

# APIのエラー応答をRFC 9457（Problem Details）に統一する

## 背景

APIのエラー応答は各所で `HTTPException(status_code, detail)` を直接送出しており、FastAPI既定の `{"detail": "..."}` 形式で返していた。OpenAPIには422以外の4xx/5xxが記載されておらず、外部呼出元（Power Automate等）はエラー種別を `detail` の文字列でしか判別できなかった。外部公開契約としてエラー種別を機械判別可能にし、契約書（OpenAPI）に固定する必要があった。

## 決定

- 全エラー応答を RFC 9457 (Problem Details for HTTP APIs) に準拠させ、`Content-Type: application/problem+json` で `{type, title, status, detail}` を返す。
- `type` は `/errors/<code>` 形式の相対URIとする。code は発生箇所ごとの固有名（例: `document-not-found`, `document-type-in-use`）で、HTTPステータス単位ではない。相対URIにするのはドメイン非依存とし、将来同じパスで説明ページを配信できる余地を残すためである。
- `title` は code から機械的に導出し（`document-not-found` → `Document not found`）、対応表を持たない。`detail` は発生箇所の文言で、従来の `detail` をそのまま継承する。
- 拡張メンバは422検証エラーの `errors`（`loc` / `msg` / `type`）のみとし、`instance` は使わない。
- 未捕捉例外は500 `internal-error` とし、`detail` は固定文言で例外内容を本文に出さない。
- 閲覧トークン無効時とSPA配信外パスは存在秘匿のため汎用 `not-found` を維持する。
- 実装はライブラリを追加せず、`app/core/problem.py` の例外ハンドラ3本（`HTTPException` / `RequestValidationError` / `Exception`）と `ProblemException` で行う。OpenAPIにはルータ／ルートの `responses=` で全4xx/5xxを `Problem` スキーマとして明記し、FastAPI既定の `HTTPValidationError` は契約から除く。

## 検討した代替案

- `fastapi-problem` 等のライブラリ導入 — ハンドラ3本で足りる量に依存を追加し、`type` URIや拡張メンバの制御がライブラリ流儀に縛られるため却下。
- `HTTPException` を温存し status → type の自動変換のみ行う — 固有コード方針と矛盾し、`detail` 文面でしか判別できないため却下。
- `type` を `urn:factone:error:<code>` や `about:blank` + 拡張 `code` にする — 説明ページ配信の余地がなく、RFCの意図（typeで種別を識別）からも外れるため却下。

## 影響

- 外部呼出元は `detail` 文字列ではなく `type` でエラー種別を判別する。既存の `{"detail"}` 参照は `detail` フィールドの継承により互換を保つ。
- エラー種別を追加する際は固有 code を命名し、該当ルートの `responses=` にステータスを追加してOpenAPIを再生成する。code 一覧は `docs/api/README.md` に保守する。
- `Content-Type` が `application/json` から `application/problem+json` に変わる。メディアタイプを厳密に判定するクライアントは追随が必要である。
- 422 検証エラーの `errors` は `loc` / `msg` / `type` のみとし、FastAPI 既定応答が含めていた `input`（送信値の反響）を返さなくなる。
