"""reseed document types to purchase_order / quotation

注文書はIDP実行後に案件型・ルート型へ分岐するため、実行前の種別としては
注文書（purchase_order）・見積書（quotation）の2種別に改める（#105）。
downgradeは purchase_order→order_project へ寄せる（案件/ルートの区別は復元不可）。

Revision ID: b7e3d2a9c1f5
Revises: f2a9c7d1e604
Create Date: 2026-09-09 12:00:00.000000

"""

import uuid
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision: str = "b7e3d2a9c1f5"
down_revision: str | None = "f2a9c7d1e604"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLE = sa.table(
    "document_type_configs",
    sa.column("id", UUID(as_uuid=True)),
    sa.column("tenant_id", sa.String),
    sa.column("type_code", sa.String),
    sa.column("display_name", sa.String),
    sa.column("shareable", sa.Boolean),
    sa.column("fields", JSONB),
)

_COMMON_FIELDS = [
    {"key": "SenderCompanyName", "label": "取引先", "type": "string"},
    {
        "key": "ReceiverCompanyName",
        "label": "自社名",
        "type": "string",
        "visible": False,
    },
    {"key": "OrderDate", "label": "注文日", "type": "date"},
    {"key": "TotalAmount", "label": "合計金額", "type": "number"},
    {"key": "DeliveryDate", "label": "納品期限", "type": "date"},
    {"key": "DeliveryLocation", "label": "納品場所", "type": "string"},
    {"key": "CustomerContactPersonName", "label": "取引先担当者", "type": "string"},
    {"key": "QuotationId", "label": "見積書ID", "type": "string"},
]

_NEW_SEED = [
    (
        "purchase_order",
        "注文書",
        False,
        [
            *_COMMON_FIELDS,
            {"key": "PurchaseOrderId", "label": "注文書ID", "type": "string"},
        ],
    ),
    ("quotation", "見積書", True, _COMMON_FIELDS),
]

_OLD_ORDER_FIELDS = [
    {"key": "customer_code", "label": "得意先コード", "type": "string"},
    {"key": "item_code", "label": "品目コード", "type": "string"},
    {"key": "quantity", "label": "数量", "type": "number"},
    {"key": "delivery_date", "label": "納期", "type": "date"},
    {"key": "unit_price", "label": "単価", "type": "number"},
]

_OLD_SEED = [
    (
        "quote",
        "見積書",
        True,
        [
            {"key": "document_no", "label": "文書番号", "type": "string"},
            {"key": "customer_code", "label": "顧客コード", "type": "string"},
            {"key": "issue_date", "label": "発行日", "type": "date"},
            {"key": "total_amount", "label": "合計金額", "type": "number"},
        ],
    ),
    ("order_project", "注文書（プロジェクト）", False, _OLD_ORDER_FIELDS),
    ("order_route", "注文書（ルート）", False, _OLD_ORDER_FIELDS),
]


def _reseed(type_mapping: dict[str, str], seed: list) -> None:
    for old, new in type_mapping.items():
        op.execute(
            sa.text(
                "UPDATE documents SET document_type = :new WHERE document_type = :old"
            ).bindparams(new=new, old=old)
        )
    op.execute(
        _TABLE.delete().where(
            _TABLE.c.tenant_id == "default",
            _TABLE.c.type_code.in_(list(type_mapping)),
        )
    )
    op.bulk_insert(
        _TABLE,
        [
            {
                "id": uuid.uuid4(),
                "tenant_id": "default",
                "type_code": code,
                "display_name": name,
                "shareable": shareable,
                "fields": fields,
            }
            for code, name, shareable, fields in seed
        ],
    )


def upgrade() -> None:
    _reseed(
        {
            "quote": "quotation",
            "order_project": "purchase_order",
            "order_route": "purchase_order",
        },
        _NEW_SEED,
    )


def downgrade() -> None:
    _reseed({"quotation": "quote", "purchase_order": "order_project"}, _OLD_SEED)
