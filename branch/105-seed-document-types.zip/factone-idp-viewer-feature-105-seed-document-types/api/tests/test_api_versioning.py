from fastapi.testclient import TestClient

# 版付与対象は認証あり API のみ。閲覧 URL（顧客配布）とヘルスチェックは無版
ALLOWED_PREFIXES = ("/api/v1/", "/view/", "/health")


def test_all_openapi_paths_are_versioned_or_exempt(client: TestClient) -> None:
    """OpenAPI の全パスが /api/v1/・/view/・/health のいずれかで始まることを確認する。"""
    paths = client.app.openapi()["paths"]  # type: ignore[attr-defined]

    unexpected = [p for p in paths if not p.startswith(ALLOWED_PREFIXES)]

    assert unexpected == []
