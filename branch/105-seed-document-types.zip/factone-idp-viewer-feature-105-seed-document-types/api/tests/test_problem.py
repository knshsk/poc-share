"""RFC 9457 Problem Details 共通エラー応答のテスト。"""

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

from app.core.problem import ProblemException, register_problem_handlers

PROBLEM = "application/problem+json"


@pytest.fixture
def problem_client() -> TestClient:
    """ハンドラ検証用の最小アプリ。DB・認証に依存しない。"""
    app = FastAPI()
    register_problem_handlers(app)

    @app.get("/problem")
    def problem() -> None:
        raise ProblemException(404, "document-not-found", "Document not found")

    @app.get("/with-header")
    def with_header() -> None:
        raise ProblemException(
            401,
            "unauthenticated",
            "Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    @app.get("/plain")
    def plain() -> None:
        raise HTTPException(status_code=404, detail="Not found")

    @app.get("/boom")
    def boom() -> None:
        raise RuntimeError("secret internal state")

    @app.get("/items/{n}")
    def items(n: int) -> dict[str, int]:
        return {"n": n}

    return TestClient(app, raise_server_exceptions=False)


def test_problem_exception_returns_problem_json(problem_client: TestClient) -> None:
    response = problem_client.get("/problem")

    assert response.status_code == 404
    assert response.headers["content-type"] == PROBLEM
    assert response.json() == {
        "type": "/errors/document-not-found",
        "title": "Document not found",
        "status": 404,
        "detail": "Document not found",
    }


def test_problem_exception_keeps_headers(problem_client: TestClient) -> None:
    response = problem_client.get("/with-header")

    assert response.status_code == 401
    assert response.headers["www-authenticate"] == "Bearer"
    assert response.json()["type"] == "/errors/unauthenticated"


def test_plain_http_exception_falls_back_to_status_phrase(
    problem_client: TestClient,
) -> None:
    response = problem_client.get("/plain")

    assert response.status_code == 404
    assert response.headers["content-type"] == PROBLEM
    assert response.json() == {
        "type": "/errors/not-found",
        "title": "Not found",
        "status": 404,
        "detail": "Not found",
    }


def test_method_not_allowed_falls_back(problem_client: TestClient) -> None:
    response = problem_client.post("/plain")

    assert response.status_code == 405
    assert response.json()["type"] == "/errors/method-not-allowed"
    assert response.json()["title"] == "Method not allowed"


def test_validation_error_includes_errors(problem_client: TestClient) -> None:
    response = problem_client.get("/items/abc")

    assert response.status_code == 422
    assert response.headers["content-type"] == PROBLEM
    body = response.json()
    assert body["type"] == "/errors/validation-error"
    assert body["title"] == "Validation error"
    assert body["detail"] == "Request validation failed"
    assert body["errors"][0]["loc"] == ["path", "n"]
    assert body["errors"][0]["type"] == "int_parsing"
    assert set(body["errors"][0]) == {"loc", "msg", "type"}


def test_unhandled_exception_hides_internal_detail(
    problem_client: TestClient,
) -> None:
    response = problem_client.get("/boom")

    assert response.status_code == 500
    assert response.headers["content-type"] == PROBLEM
    assert response.json() == {
        "type": "/errors/internal-error",
        "title": "Internal error",
        "status": 500,
        "detail": "Internal server error",
    }
    assert "secret" not in response.text


def test_unknown_document_returns_document_not_found(doc_client: TestClient) -> None:
    response = doc_client.get("/api/v1/documents/no-such-doc")

    assert response.status_code == 404
    assert response.headers["content-type"] == PROBLEM
    assert response.json()["type"] == "/errors/document-not-found"


def test_missing_token_returns_unauthenticated(doc_client: TestClient) -> None:
    response = doc_client.get(
        "/api/v1/documents/no-such-doc", headers={"Authorization": ""}
    )

    assert response.status_code == 401
    assert response.headers["www-authenticate"] == "Bearer"
    assert response.json()["type"] == "/errors/unauthenticated"


def test_invalid_view_token_returns_generic_not_found(
    doc_client: TestClient,
) -> None:
    response = doc_client.get("/view/invalid-token/pages")

    assert response.status_code == 404
    assert response.json() == {
        "type": "/errors/not-found",
        "title": "Not found",
        "status": 404,
        "detail": "Not found",
    }


def test_openapi_declares_problem_schema(client: TestClient) -> None:
    schema = client.get("/openapi.json").json()
    schemas = schema["components"]["schemas"]

    assert set(schemas["Problem"]["properties"]) == {
        "type",
        "title",
        "status",
        "detail",
        "errors",
    }
    assert "ValidationItem" in schemas
    assert "HTTPValidationError" not in schemas
    assert "ValidationError" not in schemas


def test_openapi_error_responses_use_problem_json(client: TestClient) -> None:
    schema = client.get("/openapi.json").json()

    error_responses = [
        (path, method, status, response)
        for path, methods in schema["paths"].items()
        for method, operation in methods.items()
        for status, response in operation["responses"].items()
        if status[0] in "45"
    ]
    assert error_responses
    for path, method, status, response in error_responses:
        content = response.get("content", {})
        assert list(content) == [PROBLEM], (path, method, status)
        assert content[PROBLEM]["schema"] == {"$ref": "#/components/schemas/Problem"}

    documents_get = schema["paths"]["/api/v1/documents/{document_id}"]["get"][
        "responses"
    ]
    assert {"401", "404", "422"} <= set(documents_get)
    public_pages = schema["paths"]["/view/{token}/pages"]["get"]["responses"]
    assert {"404", "422", "429", "500"} <= set(public_pages)
    assert "401" not in public_pages
