"""IDP実行API（項目抽出の実行と履歴参照）。

実行区分（初回/再実行）は同一文書IDの既存実行有無からサーバ側で判定する。
実行ログは追記型で、DI失敗時もエラー情報付きで記録する。
"""

import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import CurrentUser
from app.core.db import get_db_session
from app.core.problem import ProblemException, problem_responses
from app.models import Document, IdpRun, IdpRunStatus, IdpRunType
from app.routers.documents import _get_document_or_404
from app.services.blob import BlobStorage
from app.services.di import DiError, DocumentAnalyzer
from app.services.document_type_config import config_field_defs, get_config
from app.services.idp_extraction import parse_analysis, tables_to_json

router = APIRouter(responses=problem_responses(401, 422))


class IdpRunResponse(BaseModel):
    run_id: uuid.UUID
    document_id: str
    run_type: IdpRunType
    status: IdpRunStatus
    executed_at: datetime
    raw_fields: dict[str, str | None] | None
    normalized_fields: dict[str, str | int | None] | None
    confidence: dict[str, float | None] | None
    field_labels: dict[str, str] | None
    tables: list[dict[str, object]] | None
    error_info: str | None


class IdpRunListResponse(BaseModel):
    document_id: str
    runs: list[IdpRunResponse]


def _to_response(run: IdpRun) -> IdpRunResponse:
    return IdpRunResponse(
        run_id=run.id,
        document_id=run.document_id,
        run_type=IdpRunType(run.run_type),
        status=IdpRunStatus(run.status),
        executed_at=run.executed_at,
        raw_fields=run.raw_fields,
        normalized_fields=run.normalized_fields,
        confidence=run.confidence,
        field_labels=run.field_labels,
        tables=run.tables,
        error_info=run.error_info,
    )


def _determine_run_type(session: Session, document_id: str) -> IdpRunType:
    exists = session.execute(
        select(IdpRun.id).where(IdpRun.document_id == document_id).limit(1)
    ).first()
    return IdpRunType.RERUN if exists else IdpRunType.INITIAL


@router.post(
    "/api/v1/documents/{document_id}/idp-runs",
    response_model=IdpRunResponse,
    status_code=201,
    responses=problem_responses(404, 409, 502),
)
def execute_idp_run(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunResponse:
    document: Document = _get_document_or_404(request, session, document_id)
    blob_storage: BlobStorage = request.app.state.blob_storage
    analyzer: DocumentAnalyzer = request.app.state.document_analyzer

    run_type = _determine_run_type(session, document_id)
    settings = request.app.state.settings
    config = get_config(session, settings.tenant_id, document.document_type)
    if config is None:
        raise ProblemException(
            409,
            "document-type-not-configured",
            "Document type is not configured for this tenant",
        )
    field_defs = config_field_defs(config)
    query_fields = tuple(f.key for f in field_defs)
    run = IdpRun(
        document_id=document_id,
        run_type=run_type.value,
        executed_at=datetime.now(UTC),
    )
    try:
        results = analyzer.analyze(blob_storage.load(document.blob_ref), query_fields)
    except DiError as exc:
        run.status = IdpRunStatus.FAILED.value
        run.error_info = str(exc)
        session.add(run)
        session.commit()
        raise ProblemException(
            502, "document-analysis-failed", "Document analysis failed"
        ) from exc

    parsed = parse_analysis(field_defs, results.fields)
    run.status = IdpRunStatus.SUCCEEDED.value
    run.raw_fields = parsed.raw
    run.normalized_fields = parsed.normalized
    run.confidence = parsed.confidence
    run.field_labels = {f.key: f.label for f in field_defs}
    run.tables = tables_to_json(results.tables)
    session.add(run)
    session.commit()
    return _to_response(run)


@router.get(
    "/api/v1/documents/{document_id}/idp-runs",
    response_model=IdpRunListResponse,
    responses=problem_responses(404),
)
def list_idp_runs(
    request: Request,
    _user: CurrentUser,
    document_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> IdpRunListResponse:
    _get_document_or_404(request, session, document_id)
    runs = (
        session.execute(
            select(IdpRun)
            .where(IdpRun.document_id == document_id)
            .order_by(IdpRun.executed_at, IdpRun.id)
        )
        .scalars()
        .all()
    )
    return IdpRunListResponse(
        document_id=document_id, runs=[_to_response(run) for run in runs]
    )
