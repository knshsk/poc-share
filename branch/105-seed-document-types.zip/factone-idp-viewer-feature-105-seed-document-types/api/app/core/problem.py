"""RFC 9457 (Problem Details) 準拠の共通エラー応答。

- 全エラーは application/problem+json で {type, title, status, detail} を返す
- type は /errors/<code> の相対URI。title は code から導出（対応表は持たない）
- 422 の検証エラーのみ拡張メンバ errors（loc/msg/type）を付ける
- 未捕捉例外は 500 internal-error。例外内容は本文に出さずログに残す
"""

import logging
from collections.abc import Mapping
from http import HTTPStatus
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.requests import Request

logger = logging.getLogger(__name__)

PROBLEM_MEDIA_TYPE = "application/problem+json"


class ValidationItem(BaseModel):
    loc: list[str | int]
    msg: str
    type: str


class Problem(BaseModel):
    type: str
    title: str
    status: int
    detail: str
    errors: list[ValidationItem] | None = None


class ProblemException(HTTPException):
    """発生箇所ごとの固有 code を持つ HTTPException。"""

    def __init__(
        self,
        status_code: int,
        code: str,
        detail: str,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(status_code=status_code, detail=detail, headers=headers)
        self.code = code


def _title(code: str) -> str:
    return code.replace("-", " ").capitalize()


def problem_response(
    status_code: int,
    code: str,
    detail: str,
    headers: Mapping[str, str] | None = None,
    errors: list[ValidationItem] | None = None,
) -> JSONResponse:
    body = Problem(
        type=f"/errors/{code}",
        title=_title(code),
        status=status_code,
        detail=detail,
        errors=errors,
    )
    return JSONResponse(
        status_code=status_code,
        content=body.model_dump(exclude_none=True),
        media_type=PROBLEM_MEDIA_TYPE,
        headers=headers,
    )


def register_problem_handlers(app: FastAPI) -> None:
    @app.exception_handler(StarletteHTTPException)
    async def _http_exception(
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        code = (
            exc.code
            if isinstance(exc, ProblemException)
            else HTTPStatus(exc.status_code).phrase.lower().replace(" ", "-")
        )
        return problem_response(exc.status_code, code, str(exc.detail), exc.headers)

    @app.exception_handler(RequestValidationError)
    async def _validation_error(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        errors = [
            ValidationItem(loc=list(e["loc"]), msg=e["msg"], type=e["type"])
            for e in exc.errors()
        ]
        return problem_response(
            422, "validation-error", "Request validation failed", errors=errors
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("unhandled exception")
        return problem_response(500, "internal-error", "Internal server error")


def problem_responses(*statuses: int) -> dict[int | str, dict[str, Any]]:
    """ルータ／ルートの responses= に渡す OpenAPI 応答定義。"""
    return {
        status: {
            "description": HTTPStatus(status).phrase,
            "content": {
                PROBLEM_MEDIA_TYPE: {"schema": {"$ref": "#/components/schemas/Problem"}}
            },
        }
        for status in statuses
    }


def install_problem_schema(app: FastAPI) -> None:
    """OpenAPI に Problem スキーマを登録する。"""
    default_openapi = app.openapi

    def openapi() -> dict[str, Any]:
        schema = default_openapi()
        schemas = schema.setdefault("components", {}).setdefault("schemas", {})
        problem = Problem.model_json_schema(ref_template="#/components/schemas/{model}")
        schemas.update(problem.pop("$defs", {}))
        problem["properties"]["errors"].pop("default", None)
        schemas["Problem"] = problem
        return schema

    app.openapi = openapi  # type: ignore[method-assign]
