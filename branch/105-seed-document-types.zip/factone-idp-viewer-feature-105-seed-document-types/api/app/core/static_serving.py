"""フロント同居配信（Container Apps同居配信の決定に基づく）。

viewerビルド成果物ディレクトリが存在する場合のみ有効化する
（ローカル開発はVite devサーバを使うため通常は無効）。
登録済みAPIルートが常に優先され、未マッチのGETのみここへ到達する。
"""

from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse

from app.core.problem import ProblemException


def mount_spa(app: FastAPI, static_dir: str) -> None:
    root = Path(static_dir)
    if not root.is_dir():
        return
    index = root / "index.html"

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str) -> FileResponse:
        # API系プレフィックスはSPAへフォールバックしない（未知のAPIパスは404のまま）
        if full_path.startswith("api/") or full_path == "api":
            raise ProblemException(404, "not-found", "Not found")
        candidate = (root / full_path).resolve()
        # パストラバーサル防止: 配信ディレクトリ外は index へフォールバック
        if (
            full_path
            and candidate.is_file()
            and candidate.is_relative_to(root.resolve())
        ):
            return FileResponse(candidate)
        return FileResponse(index)
