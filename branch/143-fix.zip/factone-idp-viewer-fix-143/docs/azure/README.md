# Azure 構成

IDP/Viewer を Azure 上で動かすためのリソース構成と、各サービスの設計判断。インフラ定義の正は `bicep/` の Bicep モジュールであり、本書は構成の解説と判断の根拠を記す。デプロイ手順は [develop-guide/deploy.md](../develop-guide/deploy.md) を参照。

## 役割

PoC 用の単一環境。リソースグループ 1 つ、リージョン 1 つ（既定 `japaneast`）、各アプリはレプリカ 1 固定で動かす。バックエンドサービスはネットワーク分離をせず、パブリックエンドポイントを認証（Storage・DI・ACR は Managed ID、PostgreSQL はパスワード）・匿名アクセス無効・TLS 強制で守る（ファイアウォール規則を持つのは PostgreSQL のみ。[ADR-0007](../adr/0007-no-network-isolation-for-poc.md)）。Viewer の静的ファイルは API コンテナが同梱配信し、フロント専用のホスティングは持たない（[ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)）。

## トポロジ

```mermaid
flowchart TB
    subgraph rg["リソースグループ（既定 factone-poc-rg）"]
        subgraph cae["Container Apps Environment（CAE: factone-poc-cae）"]
            api["Container App: api<br/>FastAPI + Viewer 静的ファイル<br/>port 8000 / external ingress"]
            kc["Container App: keycloak<br/>realm 焼き込みイメージ<br/>port 8080 / external ingress"]
        end
        log["Log Analytics"]
        pg[("PostgreSQL Flexible Server<br/>DB: factone / keycloak")]
        st[("Storage Account<br/>コンテナ: documents")]
        di["Document Intelligence"]
        kv["Key Vault<br/>postgres-admin-password"]
        acr["Container Registry<br/>factone-api / factone-keycloak"]
        idApi["Managed ID: api"]
        idKc["Managed ID: keycloak"]
    end
    user(["テナント利用者 / 閲覧者 / 外部連携システム"])

    user -- HTTPS --> api
    user -- HTTPS（OIDC） --> kc
    api -- JWKS 取得（HTTPS） --> kc
    api -- SSL / パスワード --> pg
    kc -- SSL / パスワード --> pg
    api -- Managed ID --> st
    api -- Managed ID --> di
    acr -. イメージ pull（Managed ID）.-> api
    acr -. イメージ pull（Managed ID）.-> kc
    cae --> log
    idApi -.-> api
    idKc -.-> kc
```

- デプロイはコアインフラとアプリ層の 2 段階。`main.bicep` は `apiImage` / `keycloakImage` が空のときアプリ層（Container App 2 つ）を作らない。API の OIDC issuer は Keycloak モジュールの出力から組むため、アプリ層は両イメージを同時に指定する。初回は `scripts/deploy-infra.sh`（コアのみ。`FACTONE_POSTGRES_ADMIN_PASSWORD` 必須）→ `scripts/build-images.sh`（ACR クラウドビルド）→ `scripts/deploy-apps.sh`（アプリ層。`FACTONE_POSTGRES_ADMIN_PASSWORD` と `FACTONE_KEYCLOAK_ADMIN_PASSWORD` 必須）の順に実行する
- リソース名は環境名（既定 `poc`）とリソースグループ ID 由来の一意サフィックスを含む。形式（ハイフンの有無・サフィックス長）はリソース種別の命名制約に合わせて異なる。同名リソースグループへの再デプロイで名前が再現する
- Keycloak の公開ホスト名は `factone-<環境名>-keycloak.<Environment の既定ドメイン>` で決定的に決まり、API の OIDC issuer に使う。`build-images.sh` は `bicep/main.bicepparam` の `environmentName` から同じ規則でホスト名を組み、Viewer のビルド引数 `VITE_OIDC_AUTHORITY` に渡す。`VITE_OIDC_CLIENT_ID` は渡さず Viewer の既定値 `factone-viewer`（realm のクライアント ID と同じ）を使う
- 両 Container App のリビジョンはデプロイ時刻をサフィックスにして毎回更新し、同名タグでもイメージを再 pull させる

## サービス別の設計

Bicep モジュール 1 つにつき 1 小節。各小節は「目的 / 主要設定 / ID と権限 / PoC 上の簡略化」の順。

### Storage（`modules/storage.bicep`）

- 目的: PDF 原本と DI 生応答の保存先。コンテナ `documents` に `{tenant_id}/{document_id}.pdf`、`{tenant_id}/{document_id}/idp-runs/{run_id}.json` のパスで置く。ページ画像は保存せず API がオンデマンドで生成する
- 主要設定: StorageV2、Standard_LRS、`allowBlobPublicAccess: false`、TLS 1.2 以上、HTTPS のみ、コンテナの公開アクセス None
- ID と権限: API の Managed ID に Storage Blob Data Contributor。アプリは `DefaultAzureCredential` で接続する（`api/app/services/blob.py`）
- PoC 上の簡略化: 冗長化は LRS。ネットワーク制限なし。ライフサイクル管理・論理削除なし

### PostgreSQL Flexible Server（`modules/postgresql.bicep`）

- 目的: アプリ用 DB `factone` と Keycloak 用 DB `keycloak` を同一サーバに置く
- 主要設定: PostgreSQL 17、Standard_B1ms（Burstable）、ストレージ 32 GB、バックアップ保持 7 日、geo 冗長バックアップ無効。ファイアウォール規則は「Azure サービス許可（0.0.0.0）」の 1 件
- ID と権限: Managed ID は使わず、管理者ユーザーのパスワード認証。API は `FACTONE_DATABASE_URL`（Container App のシークレット）、Keycloak は `KC_DB_URL` / `KC_DB_USERNAME` / `KC_DB_PASSWORD` で接続する。いずれも接続文字列で `sslmode=require` を指定する（サーバ側の SSL 強制設定は Bicep に置かず既定値に依存）
- PoC 上の簡略化: API・Keycloak とも管理者ユーザーで接続する（本番化時は専用 DB ユーザーへ分離）。Container Apps（Consumption）のアウトバウンド IP が非固定のため、ファイアウォール規則が広い。スキーマ適用は API コンテナ起動時の `alembic upgrade head`

### Key Vault（`modules/keyvault.bicep`）

- 目的: PostgreSQL 管理者パスワードをシークレット `postgres-admin-password` として保管する。参照するのは運用者（デプロイ後にパスワードを確認する用途）で、アプリやデプロイスクリプトは読まない
- 主要設定: standard SKU、RBAC 認可（アクセスポリシー不使用）、パブリックアクセス有効
- ID と権限: API の Managed ID に Key Vault Secrets User
- PoC 上の簡略化: アプリは現状 Key Vault を読まない（DB 接続文字列は Bicep が Container App のシークレットに直接渡す）。ロール付与は将来の参照に備えたもの。パージ保護なし（削除後 90 日は名前が予約される。[develop-guide/deploy.md](../develop-guide/deploy.md) の再デプロイ時の注意）

### Document Intelligence（`modules/document-intelligence.bicep`）

- 目的: PDF の文字化・項目抽出（抽出エンジン）
- 主要設定: kind FormRecognizer、S0、カスタムサブドメイン（Managed ID 認証に必須）、パブリックアクセス有効
- ID と権限: API の Managed ID に Cognitive Services User。`FACTONE_DI_API_KEY` を設定せず `DefaultAzureCredential` で認証する（`api/app/services/di.py`）
- PoC 上の簡略化: ネットワーク制限なし。使用モデルは `prebuilt-layout` に Query Fields アドオンを付けたもののみ（アドオン分の課金が加わる）

### Container Registry（`modules/acr.bicep`）

- 目的: `factone-api` と `factone-keycloak` のイメージ保管。ビルドは `az acr build`（クラウドビルド。ローカルにコンテナ基盤を要しない）
- 主要設定: Basic SKU、管理者ユーザー無効
- ID と権限: API と Keycloak の Managed ID それぞれに AcrPull
- PoC 上の簡略化: イメージの脆弱性スキャン・保持ポリシーなし

### Container Apps Environment（`modules/container-apps-env.bicep`）

- 目的: `api` と `keycloak` の実行基盤。コンテナログを Log Analytics へ送る
- 主要設定: Consumption。Log Analytics は PerGB2018、保持 30 日
- ID と権限: Environment から Log Analytics への接続は共有キー方式（Bicep が `listKeys()` で取得して渡す）
- PoC 上の簡略化: VNet 統合なし（[ADR-0007](../adr/0007-no-network-isolation-for-poc.md)）。ログ保持は最短

### Managed Identity（`modules/identities.bicep`）

- 目的: API 用と Keycloak 用のユーザー割当 Managed ID
- 主要設定: 2 つのユーザー割当 ID。API の ID はクライアント ID を `AZURE_CLIENT_ID` としてコンテナに渡し、`DefaultAzureCredential` に選ばせる
- ID と権限: 権限付与は `app-roles.bicep`
- PoC 上の簡略化: システム割当ではなくユーザー割当を使う理由は、ACR pull にアプリ作成前のロール付与が必要で、システム割当（アプリ作成時に生成）では順序が成立しないため

### ロール付与（`modules/app-roles.bicep`）

- 目的: Managed ID への組み込みロール割当をまとめる
- 主要設定: API の ID に Storage Blob Data Contributor（Storage）、Cognitive Services User（DI）、Key Vault Secrets User（Key Vault）、AcrPull（ACR）。Keycloak の ID に AcrPull（ACR）
- ID と権限: すべてリソーススコープの割当
- PoC 上の簡略化: 最小権限の見直しは対象外（Blob は読み書きに Contributor が必要）

### Keycloak Container App（`modules/keycloak-app.bicep`）

- 目的: IdP。realm 定義を焼き込んだイメージ（`keycloak/Containerfile`。`--import-realm` で起動時に投入）を動かす
- 主要設定: external ingress、port 8080、CPU 0.5 / メモリ 1 Gi、レプリカ 1、プローブなし。`KC_HOSTNAME` に `https://<公開 FQDN>`、`KC_PROXY_HEADERS=xforwarded` と `KC_HTTP_ENABLED=true` で ingress の TLS 終端配下で動かす。管理者はブートストラップ環境変数（ユーザー名の既定 `admin`）で作る
- ID と権限: Keycloak の Managed ID（ACR pull のみ）。DB はパスワード認証
- PoC 上の簡略化: 管理者パスワード・DB パスワードは Container App のシークレット。realm 内のクライアントシークレットとテストユーザーのパスワードはデプロイ後に `kcadm` で手動投入する（[develop-guide/deploy.md](../develop-guide/deploy.md)）

### API Container App（`modules/api-app.bicep`）

- 目的: FastAPI 本体と Viewer 静的ファイルの配信
- 主要設定: external ingress、port 8000、CPU 0.5 / メモリ 1 Gi、レプリカ 1 固定、Readiness probe `/health`。環境変数は `FACTONE_DATABASE_URL`（シークレット）、`FACTONE_OIDC_ISSUER`、`FACTONE_BLOB_BACKEND=azure`、`FACTONE_BLOB_ACCOUNT_URL`、`FACTONE_DI_ENDPOINT`、`AZURE_CLIENT_ID`。それ以外の設定（`FACTONE_TENANT_ID=default`、`FACTONE_OIDC_AUDIENCE=factone-api`、`FACTONE_BLOB_CONTAINER=documents`、`FACTONE_DI_TIMEOUT_SECONDS=120`、`FACTONE_VIEW_URL_*`）は Bicep が渡さず `api/app/core/config.py` の既定値で動く。起動時に `alembic upgrade head` を実行してから uvicorn を起動する
- ID と権限: API の Managed ID（Storage / DI / Key Vault / ACR）
- PoC 上の簡略化: レプリカ 1 固定の理由は、閲覧 URL の失敗レート制限がインメモリで、起動時マイグレーションも単一プロセス前提のため。スケールアウト時はレート制限の外部化とマイグレーションの分離が必要

## 通信・認証経路

- API → Storage / Document Intelligence: Managed ID（`DefaultAzureCredential`、`AZURE_CLIENT_ID` でユーザー割当 ID を選択）
- API → Key Vault: ロールは付与済みだが現状は読まない
- API → PostgreSQL: パスワード認証。接続文字列は Container App のシークレット。`sslmode=require`
- API → Keycloak: JWT 検証用の JWKS 取得（HTTPS、公開エンドポイント）
- Keycloak → PostgreSQL: パスワード認証。`sslmode=require`
- Container Apps → ACR: Managed ID の AcrPull
- 外部 → api / keycloak: Container Apps の external ingress（TLS 終端）。ネットワーク制限なし

## 詳細仕様への導線

- `bicep/main.bicep`、`bicep/modules/`（定義の正）、`bicep/main.bicepparam`
- `scripts/deploy-infra.sh` / `build-images.sh` / `deploy-apps.sh`（デプロイの実体）、[develop-guide/deploy.md](../develop-guide/deploy.md)（前提条件・使い方・トラブルシュート）
- `api/Containerfile`（Viewer ビルドの同梱）、`keycloak/Containerfile`（realm 焼き込み）
- [ADR-0007](../adr/0007-no-network-isolation-for-poc.md)（ネットワーク非分離）、[ADR-0008](../adr/0008-frontend-delivery-container-apps-colocation.md)（同居配信）、[ADR-0010](../adr/0010-blob-access-full-api-proxy.md)（Blob の API プロキシ）
- 認証の全体は [architecture/auth.md](../architecture/auth.md)
