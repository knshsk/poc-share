# rikai - Azure AI Content Understandingデモ

Azure AI Content Understandingで見積書や注文書などのPDFを解析し、抽出した項目と、その根拠になった領域をページ画像に重ねて表示するデモアプリです。領域は信頼度で色分けします（0.80以上は緑、0.50以上は黄、0.50未満は赤）。解析にかかった料金の概算も表示します。

## 必要なもの

- Windows 11
- uv（`winget install --id=astral-sh.uv -e`でインストールできます）
- Content Understandingのエンドポイント、APIキー、事前に作成したアナライザーのID

## 起動

```powershell
uv sync
uv run streamlit run app.py
```

- Python 3.14が入っていなければ、uvが取得します。
- 初回にメールアドレスを聞かれたら、何も入力せずにEnterを押します。
- ブラウザで開いた画面のサイドバーに、エンドポイント、APIキー、アナライザーIDを入力します。PDFを選んで「解析」を押すと、結果が表示されます。
- 入力した値と解析結果は保存しません。ページを再読み込みすると消えます。

## テスト

```powershell
uv run pytest
```

実際のAPIを呼ぶテストを行うときは、次の内容の`.env`を作ってから実行します。`.env`はgitの管理対象外で、アプリからは読みません。

```
CU_ENDPOINT=https://<リソース名>.services.ai.azure.com
CU_API_KEY=<APIキー>
CU_ANALYZER_ID=<アナライザーID>
```

```powershell
uv run --env-file .env pytest
```

## 料金の概算

- `cu.py`の`PRICES`に書いた円建ての定価（2026-10-07時点、japaneast）から計算します。割引と税は含みません。
- モデルの単価は、Global Standardのデプロイを前提にしています。
- 単価表にないキーは「単価未登録」と表示し、合計に含めません。価格が変わったときや、別のモデルを使うときは`PRICES`を直します。
