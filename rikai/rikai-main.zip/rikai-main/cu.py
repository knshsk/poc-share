"""Azure AI Content Understanding の呼び出しと、レスポンスの整形。"""

import http.client
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import NamedTuple

type Point = tuple[float, float]
type Region = tuple[int, list[Point]]  # (ページ番号, 4点の多角形)

_SOURCE = re.compile(r"D\(([^)]*)\)")


def parse_source(source: str | None) -> list[Region]:
    """source 文字列（例: "D(1,x1,y1,...,x4,y4);D(1,...)"）を領域の一覧にする。"""
    regions = []
    for part in (source or "").split(";"):
        match = _SOURCE.fullmatch(part.strip())
        if not match:
            continue  # AV(...) など、文書以外の形式
        numbers = [float(v) for v in match.group(1).split(",")]
        page, coords = int(numbers[0]), numbers[1:]
        if len(coords) == 8:
            points = list(zip(coords[0::2], coords[1::2]))
        elif len(coords) == 4:
            left, top, width, height = coords
            points = [(left, top), (left + width, top), (left + width, top + height), (left, top + height)]
        else:
            continue  # D(ページ) には位置がない
        regions.append((page, points))
    return regions


class Band(NamedTuple):
    label: str
    emoji: str
    color: str


TRUSTED = Band("信頼できる", "🟢", "#16a34a")
CAUTION = Band("注意", "🟡", "#eab308")
WARNING = Band("警告", "🔴", "#dc2626")
UNKNOWN = Band("不明", "⚪", "#9ca3af")
BANDS = (TRUSTED, CAUTION, WARNING, UNKNOWN)


def band(confidence: float | None) -> Band:
    if confidence is None:
        return UNKNOWN
    if confidence >= 0.80:
        return TRUSTED
    if confidence >= 0.50:
        return CAUTION
    return WARNING


@dataclass
class Row:
    name: str
    value: str
    confidence: float | None
    regions: list[Region]


def field_rows(result: dict) -> list[Row]:
    """解析結果の fields を展開し、値を持つ項目ごとに1行にする。"""
    rows: list[Row] = []

    def walk(name: str, field: dict) -> None:
        kind = field.get("type")
        if kind == "object":
            for key, child in (field.get("valueObject") or {}).items():
                walk(f"{name}.{key}", child)
        elif kind == "array":
            for i, child in enumerate(field.get("valueArray") or [], start=1):
                walk(f"{name}[{i}]", child)
        else:
            value = next((v for k, v in field.items() if k.startswith("value")), None)
            rows.append(Row(
                name,
                "" if value is None else str(value),
                field.get("confidence"),
                parse_source(field.get("source")),
            ))

    for content in (result.get("result") or {}).get("contents") or []:
        for name, field in (content.get("fields") or {}).items():
            walk(name, field)
    return rows


# 2026-10-07 時点の円建ての定価（japaneast）。モデルは Global Standard のデプロイの単価。
# 円建ての定価はドル建ての 157.55 倍なので、ドル建ての単価×157.55 を丸めずに書いている。
# 出典: https://prices.azure.com/api/retail/prices （productName 'Azure Content Understanding'、
#       serviceName 'Foundry Models'）、https://azure.microsoft.com/pricing/details/content-understanding/
PRICES: dict[str, tuple[float, int, str]] = {  # usage のキー: (単価[円], 何単位あたりか, 単位の表示)
    "documentPagesMinimal": (1.5755, 1_000, "1,000ページ"),
    "documentPagesBasic": (157.55, 1_000, "1,000ページ"),
    "documentPagesStandard": (787.75, 1_000, "1,000ページ"),
    "contextualizationTokens": (157.55, 1_000_000, "100万トークン"),
    "gpt-5.4-mini-input": (118.1625, 1_000_000, "100万トークン"),
    "gpt-5.4-mini-cached-input": (11.81625, 1_000_000, "100万トークン"),  # キー名は公式資料で未確認
    "gpt-5.4-mini-output": (708.975, 1_000_000, "100万トークン"),
}


class CostRow(NamedTuple):
    key: str
    quantity: float
    unit_price: str  # 例: "¥118.1625 / 100万トークン"、単価表になければ "単価未登録"
    amount: float | None  # 円。単価表になければ None


def estimate_cost(usage: dict) -> tuple[list[CostRow], float]:
    """usage の各数値に単価を掛ける。戻り値は (行の一覧, 単価がある行の合計[円])。"""
    items = {k: v for k, v in usage.items() if isinstance(v, (int, float))}
    items.update(usage.get("tokens") or {})
    rows = []
    for key, quantity in items.items():
        if key in PRICES:
            price, per, unit = PRICES[key]
            rows.append(CostRow(key, quantity, f"¥{price:,} / {unit}", quantity * price / per))
        else:
            rows.append(CostRow(key, quantity, "単価未登録", None))
    return rows, sum(r.amount for r in rows if r.amount is not None)


API_VERSION = "2025-11-01"
POLL_SECONDS = 1
TIMEOUT_SECONDS = 300


class CUError(Exception):
    """API の呼び出しに失敗した。メッセージは画面にそのまま表示する。"""


def analyze(endpoint: str, key: str, analyzer_id: str, pdf: bytes) -> dict:
    """PDF を解析し、解析結果の JSON 全体（status, result, usage を含む）を返す。"""
    analyzer = urllib.parse.quote(analyzer_id.strip(), safe="")
    url = (
        f"{endpoint.strip().rstrip('/')}/contentunderstanding/analyzers/"
        f"{analyzer}:analyzeBinary?api-version={API_VERSION}"
    )
    auth = {"Ocp-Apim-Subscription-Key": key.strip()}
    headers, _ = _request(url, {**auth, "Content-Type": "application/octet-stream"}, pdf)
    operation = headers.get("Operation-Location")
    if not operation:
        raise CUError("応答に Operation-Location ヘッダーがありません")

    deadline = time.monotonic() + TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        _, body = _request(operation, auth)
        status = str(body.get("status", "")).lower()
        if status == "succeeded":
            return body
        if status in ("failed", "canceled"):
            raise CUError(f"解析に失敗しました: {_error_text(body) or status}")
        time.sleep(POLL_SECONDS)
    raise CUError(f"{TIMEOUT_SECONDS}秒以内に解析が終わりませんでした")


def _request(url: str, headers: dict, data: bytes | None = None) -> tuple:
    """リクエストを送り、(応答ヘッダー, JSON 本文) を返す。失敗はすべて CUError にする。"""
    try:
        request = urllib.request.Request(url, data=data, headers=headers)
        with urllib.request.urlopen(request, timeout=60) as response:
            return response.headers, _loads(response.read(), strict=True)
    except urllib.error.HTTPError as e:
        raise CUError(f"HTTP {e.code}: {_error_text(_loads(e.read())) or e.reason}") from None
    except (ValueError, http.client.InvalidURL):
        # URL やヘッダーに使えない文字がある。例外の文言に APIキーが入ることがあるので表示しない
        raise CUError(
            "リクエストを送れませんでした。エンドポイント（https:// で始まる URL）と"
            "APIキーに余分な文字が入っていないか確認してください"
        ) from None
    except (OSError, http.client.HTTPException) as e:  # URLError、タイムアウト、SSL、応答の途切れ
        raise CUError(f"通信エラー: {getattr(e, 'reason', e)}") from None


def _loads(raw: bytes, strict: bool = False) -> dict:
    try:
        body = json.loads(raw) if raw else {}
    except ValueError:
        if strict:
            raise CUError("応答を JSON として読めませんでした") from None
        return {}
    return body if isinstance(body, dict) else {}


def _error_text(body: dict) -> str:
    error = body.get("error") or {}
    return ": ".join(str(v) for v in (error.get("code"), error.get("message")) if v)
