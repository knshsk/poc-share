import io
import json
from pathlib import Path

import pypdfium2 as pdfium
from PIL import Image
from streamlit.testing.v1 import AppTest

import app
import cu

TESTS = Path(__file__).parent
SAMPLE = json.loads((TESTS / "sample_result.json").read_text(encoding="utf-8"))
PDF = (TESTS.parent / "data" / "order-project-sample.pdf").read_bytes()
A4 = (8.2639, 11.6806)


# --- page_figure ------------------------------------------------------------

def test_page_figure_draws_every_region_on_the_page():
    rows = cu.field_rows(SAMPLE)
    fig = app.page_figure(Image.new("RGB", (10, 14)), *A4, rows, page_no=1)
    assert len(fig.data) == sum(len(row.regions) for row in rows)  # 42 行 + 2 行ぶんの追加領域
    assert [t.name for t in fig.data if t.showlegend] == ["信頼できる", "注意"]
    trace = next(t for t in fig.data if t.text.startswith("LineItems[2].ProductName<br>"))
    assert trace.text == "LineItems[2].ProductName<br>テスト用ボールペン黒<br>信頼度 0.795（注意）"
    assert trace.line.color == cu.CAUTION.color
    assert trace.hoveron == "fills"


def test_page_figure_skips_other_pages_and_escapes_html():
    rows = [
        cu.Row("Memo", "<b>a&b</b>", None, [(1, [(0, 0), (1, 0), (1, 1), (0, 1)])]),
        cu.Row("Other", "x", 0.9, [(2, [(0, 0), (1, 0), (1, 1), (0, 1)])]),
    ]
    fig = app.page_figure(Image.new("RGB", (10, 14)), *A4, rows, page_no=1)
    [trace] = fig.data
    assert trace.text == "Memo<br>&lt;b&gt;a&amp;b&lt;/b&gt;<br>信頼度 -（不明）"
    assert trace.x == (0, 1, 1, 0, 0)  # 枠線を閉じるため始点に戻る


# --- 画面全体（AppTest）------------------------------------------------------

def new_app() -> AppTest:
    return AppTest.from_file(str(TESTS.parent / "app.py"), default_timeout=30)


def run_app(*, endpoint="https://res", key="k", analyzer="a", pdf=PDF) -> AppTest:
    at = new_app().run()
    at.sidebar.text_input[0].input(endpoint)
    at.sidebar.text_input[1].input(key)
    at.sidebar.text_input[2].input(analyzer)
    if pdf is not None:
        at.file_uploader[0].set_value(("sample.pdf", pdf, "application/pdf"))
    return at.run()


def test_button_disabled_until_all_inputs_present():
    at = new_app().run()
    assert not at.exception
    assert at.button[0].disabled
    assert at.caption[-1].value == "未入力: エンドポイント、APIキー、アナライザーID、PDF"
    at = run_app(pdf=None)
    assert at.button[0].disabled
    assert at.caption[-1].value == "未入力: PDF"


def test_pdf_pages_shown_before_analysis():
    at = run_app()
    assert not at.exception
    assert not at.button[0].disabled
    assert len(at.get("plotly_chart")) == 1
    assert not at.dataframe


def test_analysis_shows_fields_and_cost(monkeypatch):
    calls = []
    monkeypatch.setattr(cu, "analyze", lambda *args: calls.append(args) or SAMPLE)
    at = run_app()
    at.button[0].click().run()
    assert not at.exception
    assert calls == [("https://res", "k", "a", PDF)]
    fields, cost = at.dataframe
    assert len(fields.value) == 42
    assert list(fields.value.columns) == ["項目", "値", "信頼度", "判定"]
    assert fields.value["判定"][0] == "🟢 信頼できる"
    assert list(cost.value["金額"]) == ["¥0.79", "¥0.16", "¥0.60", "¥0.66"]
    assert at.markdown[-1].value == "**合計 ¥2.20**"


def test_analysis_error_is_shown(monkeypatch):
    def fail(*args):
        raise cu.CUError("HTTP 401: Unauthorized: Access denied")

    monkeypatch.setattr(cu, "analyze", fail)
    at = run_app()
    at.button[0].click().run()
    assert not at.exception
    assert at.error[0].value == "HTTP 401: Unauthorized: Access denied"
    assert not at.dataframe


def test_broken_pdf_is_reported():
    at = run_app(pdf=b"not a pdf")
    assert not at.exception
    assert at.error[0].value.startswith("PDF を開けませんでした")


def blank_pdf(pages: int) -> bytes:
    doc = pdfium.PdfDocument.new()
    for _ in range(pages):
        doc.new_page(595, 842)
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def test_identical_pages_each_get_a_chart():
    at = run_app(pdf=blank_pdf(2))
    assert not at.exception
    assert len(at.get("plotly_chart")) == 2


def test_new_pdf_clears_previous_result(monkeypatch):
    monkeypatch.setattr(cu, "analyze", lambda *args: SAMPLE)
    at = run_app()
    at.button[0].click().run()
    assert len(at.dataframe) == 2
    at.file_uploader[0].set_value(("other.pdf", blank_pdf(1), "application/pdf"))
    at.run()
    assert not at.exception
    assert not at.dataframe


def test_result_without_regions_or_prices_shows_notes(monkeypatch):
    result = {
        "status": "Succeeded",
        "result": {"contents": [{"fields": {"Total": {"type": "number", "valueNumber": 5, "confidence": 0.9}}}]},
        "usage": {"tokens": {"gpt-9-input": 100}},
    }
    monkeypatch.setattr(cu, "analyze", lambda *args: result)
    at = run_app()
    at.button[0].click().run()
    assert not at.exception
    assert "根拠の位置を返していません" in at.info[0].value
    assert at.markdown[-1].value == "**合計 ¥0.00**（単価未登録の項目は合計に含めていません）"
