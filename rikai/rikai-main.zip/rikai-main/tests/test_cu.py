import http.client
import io
import json
import os
import urllib.error
from pathlib import Path

import pytest

import cu

ROOT = Path(__file__).parent.parent
SAMPLE =json.loads((Path(__file__).parent / "sample_result.json").read_text(encoding="utf-8"))


# --- parse_source -----------------------------------------------------------

def test_parse_source_reads_polygon():
    assert cu.parse_source("D(1,0.5,1.0,2.5,1.0,2.5,1.5,0.5,1.5)") == [
        (1, [(0.5, 1.0), (2.5, 1.0), (2.5, 1.5), (0.5, 1.5)])
    ]


def test_parse_source_reads_multiple_regions():
    source = SAMPLE["result"]["contents"][0]["fields"]["BuyerAddress"]["source"]
    regions = cu.parse_source(source)
    assert [page for page, _ in regions] == [1, 1]
    assert regions[1][1][0] == (4.8946, 3.79)


def test_parse_source_converts_box_to_polygon():
    assert cu.parse_source("D(2,1,2,3,4)") == [(2, [(1, 2), (4, 2), (4, 6), (1, 6)])]


def test_parse_source_skips_entries_without_position():
    assert cu.parse_source("D(1);AV(1000,1,2,3,4)") == []
    assert cu.parse_source(None) == []


# --- band -------------------------------------------------------------------

@pytest.mark.parametrize("confidence, label", [
    (1.0, "信頼できる"), (0.80, "信頼できる"), (0.795, "注意"), (0.50, "注意"),
    (0.499, "警告"), (0.0, "警告"), (None, "不明"),
])
def test_band_boundaries(confidence, label):
    assert cu.band(confidence).label == label


# --- field_rows -------------------------------------------------------------

def test_field_rows_flattens_sample():
    rows = {row.name: row for row in cu.field_rows(SAMPLE)}
    assert len(rows) == 42  # 明細以外 12 項目 + 明細 5 行 × 6 項目
    item = rows["LineItems[2].ProductName"]
    assert (item.value, item.confidence) == ("テスト用ボールペン黒", 0.795)
    assert rows["OrderDate"].value == "2026-09-04"
    assert rows["GrandTotalAmount"].value == "74800"
    assert len(rows["BuyerAddress"].regions) == 2


def test_field_rows_keeps_fields_without_value_or_source():
    result = {"result": {"contents": [{"fields": {"Note": {"type": "string"}}}]}}
    [row] = cu.field_rows(result)
    assert (row.name, row.value, row.confidence, row.regions) == ("Note", "", None, [])


# --- estimate_cost ----------------------------------------------------------

def test_estimate_cost_sample_total():
    rows, total = cu.estimate_cost(SAMPLE["usage"])
    assert [r.key for r in rows] == [
        "documentPagesStandard", "contextualizationTokens", "gpt-5.4-mini-input", "gpt-5.4-mini-output",
    ]
    assert rows[2].unit_price == "¥118.1625 / 100万トークン"
    # 0.78775 + 0.15755 + 0.6015652875 + 0.6579288
    assert total == pytest.approx(2.2047940875)


def test_estimate_cost_unknown_key_is_excluded():
    rows, total = cu.estimate_cost({"documentPagesStandard": 2, "tokens": {"gpt-9-input": 1000}})
    assert rows[1] == cu.CostRow("gpt-9-input", 1000, "単価未登録", None)
    assert total == pytest.approx(1.5755)


# --- analyze（偽の urlopen で HTTP をまねる）---------------------------------

class FakeResponse(io.BytesIO):
    def __init__(self, body: dict, headers: dict | None = None):
        super().__init__(json.dumps(body).encode())
        self.headers = headers or {}


def http_error(code: int, body: dict) -> urllib.error.HTTPError:
    return urllib.error.HTTPError("https://x", code, "error", {}, io.BytesIO(json.dumps(body).encode()))


@pytest.fixture
def fake_urlopen(monkeypatch):
    """urlopen の戻り値（または例外）を順に返し、受け取ったリクエストを記録する。"""
    calls = []

    def install(*responses):
        queue = list(responses)

        def urlopen(request, timeout):
            calls.append(request)
            response = queue.pop(0)
            if isinstance(response, Exception):
                raise response
            return response

        monkeypatch.setattr(cu.urllib.request, "urlopen", urlopen)
        monkeypatch.setattr(cu.time, "sleep", lambda seconds: None)
        return calls

    return install


def test_analyze_polls_until_succeeded(fake_urlopen):
    calls = fake_urlopen(
        FakeResponse({"status": "NotStarted"}, {"Operation-Location": "https://op"}),
        FakeResponse({"status": "Running"}),
        FakeResponse({"status": "Succeeded", "result": {}, "usage": {}}),
    )
    body = cu.analyze(" https://res.services.ai.azure.com/ ", " key1 ", "my_analyzer", b"%PDF")
    assert body["status"] == "Succeeded"
    post = calls[0]
    assert post.full_url == (
        "https://res.services.ai.azure.com/contentunderstanding/analyzers/"
        "my_analyzer:analyzeBinary?api-version=2025-11-01"
    )
    assert post.get_method() == "POST"
    assert post.data == b"%PDF"
    assert post.get_header("Ocp-apim-subscription-key") == "key1"
    assert post.get_header("Content-type") == "application/octet-stream"
    assert [c.full_url for c in calls[1:]] == ["https://op", "https://op"]
    assert calls[1].get_method() == "GET"


def test_analyze_requires_operation_location(fake_urlopen):
    fake_urlopen(FakeResponse({"status": "NotStarted"}))
    with pytest.raises(cu.CUError, match="Operation-Location"):
        cu.analyze("https://res", "k", "a", b"%PDF")


def test_analyze_reports_http_error_without_key(fake_urlopen):
    fake_urlopen(http_error(401, {"error": {"code": "Unauthorized", "message": "Access denied"}}))
    with pytest.raises(cu.CUError) as e:
        cu.analyze("https://res", "secret-key", "a", b"%PDF")
    assert str(e.value) == "HTTP 401: Unauthorized: Access denied"
    assert "secret-key" not in str(e.value)


def test_analyze_reports_failed_status(fake_urlopen):
    fake_urlopen(
        FakeResponse({}, {"Operation-Location": "https://op"}),
        FakeResponse({"status": "Failed", "error": {"code": "InvalidContent", "message": "bad pdf"}}),
    )
    with pytest.raises(cu.CUError, match="解析に失敗しました: InvalidContent: bad pdf"):
        cu.analyze("https://res", "k", "a", b"%PDF")


def test_analyze_reports_network_error(fake_urlopen):
    fake_urlopen(urllib.error.URLError("Name or service not known"))
    with pytest.raises(cu.CUError, match="通信エラー: Name or service not known"):
        cu.analyze("https://res", "k", "a", b"%PDF")


@pytest.mark.parametrize("endpoint", ["res.services.ai.azure.com", "https://res .services.ai.azure.com"])
def test_analyze_rejects_malformed_endpoint(endpoint):
    with pytest.raises(cu.CUError, match="エンドポイント"):
        cu.analyze(endpoint, "k", "a", b"%PDF")


@pytest.mark.parametrize("key", ["abc\nsecret-key", "secret-keyあ"])
def test_analyze_hides_key_with_invalid_characters(key):
    # ヘッダーの検査は接続前に行われるので、.invalid のホストでも通信は発生しない
    with pytest.raises(cu.CUError) as e:
        cu.analyze("https://res.invalid", key, "a", b"%PDF")
    assert "APIキー" in str(e.value)
    assert "secret-key" not in str(e.value)


def test_analyze_reports_truncated_response(fake_urlopen):
    fake_urlopen(http.client.IncompleteRead(b"partial"))
    with pytest.raises(cu.CUError, match="通信エラー"):
        cu.analyze("https://res", "k", "a", b"%PDF")


def test_analyze_reports_non_json_response(fake_urlopen):
    response = FakeResponse({}, {"Operation-Location": "https://op"})
    page = io.BytesIO(b"<html>proxy login</html>")
    page.headers = {}
    fake_urlopen(response, page)
    with pytest.raises(cu.CUError, match="JSON として読めませんでした"):
        cu.analyze("https://res", "k", "a", b"%PDF")


def test_analyze_times_out(fake_urlopen, monkeypatch):
    monkeypatch.setattr(cu, "TIMEOUT_SECONDS", 0)
    fake_urlopen(FakeResponse({}, {"Operation-Location": "https://op"}))
    with pytest.raises(cu.CUError, match="0秒以内に解析が終わりませんでした"):
        cu.analyze("https://res", "k", "a", b"%PDF")


# --- 実 API（.env がある場合だけ）--------------------------------------------

LIVE = {name: os.environ.get(name) for name in ("CU_ENDPOINT", "CU_API_KEY", "CU_ANALYZER_ID")}


@pytest.mark.skipif(not all(LIVE.values()), reason="CU_ENDPOINT、CU_API_KEY、CU_ANALYZER_ID が未設定")
def test_analyze_live():
    pdf = (ROOT / "data" / "order-project-sample.pdf").read_bytes()
    result = cu.analyze(LIVE["CU_ENDPOINT"], LIVE["CU_API_KEY"], LIVE["CU_ANALYZER_ID"], pdf)
    assert any(row.regions for row in cu.field_rows(result))
