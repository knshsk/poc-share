"""rikai: Azure AI Content Understanding の抽出結果と、その根拠の位置を表示するデモ画面。"""

import html

import plotly.graph_objects as go
import pypdfium2 as pdfium
import streamlit as st

import cu


def _fill(color: str) -> str:
    """#rrggbb を半透明の rgba にする。"""
    r, g, b = (int(color[i:i + 2], 16) for i in (1, 3, 5))
    return f"rgba({r},{g},{b},0.2)"


def page_figure(image, width: float, height: float, rows: list[cu.Row], page_no: int) -> go.Figure:
    """ページ画像を背景に、page_no のページにある領域を判定の色で重ねた図を作る。"""
    fig = go.Figure()
    fig.add_layout_image(
        source=image, x=0, y=0, sizex=width, sizey=height, xref="x", yref="y",
        xanchor="left", yanchor="top", sizing="stretch", layer="below",
    )
    in_legend = set()
    for row in rows:
        band = cu.band(row.confidence)
        confidence = "-" if row.confidence is None else row.confidence
        # 多角形の内側のホバーでは hovertemplate が使われず、text が表示される
        text = "<br>".join([
            html.escape(row.name, quote=False),
            html.escape(row.value, quote=False),
            f"信頼度 {confidence}（{band.label}）",
        ])
        for page, points in row.regions:
            if page != page_no:
                continue
            xs, ys = zip(*(points + points[:1]))  # 始点に戻って枠線を閉じる
            fig.add_trace(go.Scatter(
                x=xs, y=ys, mode="lines", fill="toself", fillcolor=_fill(band.color),
                line=dict(color=band.color, width=2),
                hoveron="fills", hoverinfo="text", text=text,
                hoverlabel=dict(bgcolor="white", bordercolor=band.color, font=dict(color="black")),
                name=band.label, legendgroup=band.label, legendrank=cu.BANDS.index(band),
                showlegend=band.label not in in_legend,
            ))
            in_legend.add(band.label)
    fig.update_xaxes(range=[0, width], visible=False, constrain="domain")
    fig.update_yaxes(range=[height, 0], visible=False, scaleanchor="x")
    fig.update_layout(
        height=round(800 * height / width), margin=dict(l=0, r=0, t=30, b=0),
        legend=dict(orientation="h", y=1, yanchor="bottom"), plot_bgcolor="white",
    )
    return fig


@st.cache_data
def render_pages(pdf: bytes) -> list[tuple]:
    """PDF の各ページを (画像, 幅[インチ], 高さ[インチ]) にする。"""
    pages = []
    for page in pdfium.PdfDocument(pdf):
        width, height = page.get_size()  # ポイント（1/72インチ）
        pages.append((page.render(scale=2).to_pil(), width / 72, height / 72))
    return pages


def show_fields(rows: list[cu.Row]) -> None:
    st.subheader("抽出結果")
    if rows and not any(row.regions for row in rows):
        st.info(
            "このアナライザーは根拠の位置を返していません。"
            "アナライザーの estimateFieldSourceAndConfidence を有効にすると表示できます。"
        )
    table = []
    for row in rows:
        band = cu.band(row.confidence)
        table.append({
            "項目": row.name, "値": row.value, "信頼度": row.confidence,
            "判定": f"{band.emoji} {band.label}",
        })
    st.dataframe(table, hide_index=True)


def show_cost(usage: dict) -> None:
    st.subheader("料金（概算）")
    rows, total = cu.estimate_cost(usage)
    st.dataframe(
        [{
            "項目": row.key, "数量": row.quantity, "単価": row.unit_price,
            "金額": "" if row.amount is None else f"¥{row.amount:,.2f}",
        } for row in rows],
        hide_index=True,
    )
    note = "（単価未登録の項目は合計に含めていません）" if any(r.amount is None for r in rows) else ""
    st.markdown(f"**合計 ¥{total:,.2f}**{note}")


def main() -> None:
    st.set_page_config(page_title="rikai", layout="wide")
    st.title("rikai")
    st.caption("Azure AI Content Understanding の抽出結果と、その根拠の位置を表示します。")

    with st.sidebar:
        st.header("接続設定")
        endpoint = st.text_input("エンドポイント", placeholder="https://<リソース名>.services.ai.azure.com")
        key = st.text_input("APIキー", type="password")
        analyzer_id = st.text_input("アナライザーID")

    pdf = st.file_uploader("PDF", type="pdf")
    inputs = {"エンドポイント": endpoint.strip(), "APIキー": key.strip(), "アナライザーID": analyzer_id.strip(), "PDF": pdf}
    missing = [name for name, value in inputs.items() if not value]
    clicked = st.button("解析", type="primary", disabled=bool(missing))
    if missing:
        st.caption("未入力: " + "、".join(missing))
    if pdf is None:
        return

    if st.session_state.get("file_id") != pdf.file_id:
        st.session_state.file_id = pdf.file_id
        st.session_state.pop("result", None)
    try:
        pages = render_pages(pdf.getvalue())
    except pdfium.PdfiumError as e:
        st.error(f"PDF を開けませんでした: {e}")
        return

    if clicked:
        st.session_state.pop("result", None)
        try:
            with st.spinner("解析中…"):
                st.session_state.result = cu.analyze(endpoint, key, analyzer_id, pdf.getvalue())
        except cu.CUError as e:
            st.error(str(e))

    result = st.session_state.get("result")
    rows = cu.field_rows(result) if result else []
    left, right = st.columns([3, 2])
    with left:
        for page_no, (image, width, height) in enumerate(pages, start=1):
            # key がないと、内容が同じページ（白紙など）で要素 ID が重複してエラーになる
            st.plotly_chart(page_figure(image, width, height, rows, page_no), key=f"page-{page_no}")
    if result:
        with right:
            show_fields(rows)
            show_cost(result.get("usage") or {})


if __name__ == "__main__":
    main()
