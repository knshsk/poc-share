# PDF帳票フォーム定義ビルダー 設計スペック

作成日: 2026-09-06

## 1. 目的

PDF帳票に対するフォーム定義ファイル(DPL / BLOCK / PARAGRAPH / DIV / DEL_BACKWARD_SPACE)を、
PDFを画像化した上に枠を重ねながらGUIで作成し、テキストファイルとしてダウンロードするWebアプリ。

対象外(今回のスコープに含めない):

- PDFからのテキスト抽出、DIV条件の実評価によるパラグラフ分割結果の表示
- 既存の定義ファイルの読込・編集
- 定義やプロジェクト状態のサーバー側永続化
- Undo / Redo

## 2. 前提(フォーム定義ファイル仕様)

仕様の正本は `.ignore/brainstorm.md`。本スペックに必要な要点のみ再掲する。

- UTF-8テキスト。1行1パラメータ。`#` 始まりと空行は無視。各行末には `,` を付ける(仕様の例に合わせる)。
- 座標は画像左上原点のピクセル。X=横、Y=縦。PDF→画像のDPIは定義ファイルに含まれない。
- 全ページ同一様式のPDFのみ対象。
- `DPL,<開始ライン>,<ドット数>[,<ドット数>...]` — 開始ライン以降のライン高をドット数のサイクリックで定義。DPLを使う場合は開始ライン1のDPLが必須。
- `BLOCK,<開始X>,<終了X>,<開始ライン>,<終了ライン>` — 段組みの矩形。順にブロック1,2,...。矩形は重複不可。ライン番号はブロック1先頭からブロックn末尾まで通し番号に振り直される。未指定時はページ全体が1ブロック。
- `PARAGRAPH,<開始ライン>,<終了ライン>,<名前>,<ページ跨り(Y/N)>` — 複数指定で親→子→孫の入れ子。最上位の仮想親はページ(ブロック通し番号の1..N)。開始/終了は親内の相対ライン。終了は `E<n>` で親の最終ラインからの相対指定可(`E1`=親の最終ライン)。未指定時: 開始=1、終了=親の最終ライン、名前=`Paragraph<番号>`、ページ跨り=N。
- `DIV,KEY,<比較値>,<比較条件(M/F/B/A/N/W)>,<開始X>,<終了X>,<同値継続(Y/N)>` — 直前のPARAGRAPHに対して必須、1つのみ。
- `DEL_BACKWARD_SPACE,<Y/N>` — 直前のPARAGRAPHに対して任意、1つのみ。未指定時N。

## 3. 全体構成

```
form-define-builder/
  backend/    FastAPI + pypdfium2 (Python 3.12, uv管理)
  frontend/   Vite + Vue 3 + TypeScript + Pinia
  docs/superpowers/specs/
  README.md
```

責務の分担:

- **バックエンド**: PDFをDPI指定でページごとのPNGに変換して返すだけ。定義に関する知識は一切持たない。
- **フロントエンド**: 定義モデルの保持、ライン座標の算出、ブロック/パラグラフの解決、検証、定義テキスト生成、オーバーレイ描画、ダウンロード。

開発時はVite dev serverから `/api` をFastAPI(既定 `http://localhost:8000`)へプロキシ。
本番相当ではFastAPIが `frontend/dist` を静的配信し、単一プロセスで動く。

## 4. バックエンドAPI

| メソッド | パス | 内容 |
|---|---|---|
| POST | `/api/documents` | multipart: `file`(PDF), `dpi`(int)。戻り値 `{ "id": string, "page_count": int, "pages": [{ "width": int, "height": int }] }` |
| GET | `/api/documents/{id}/pages/{n}` | nページ目(1始まり)を `image/png` で返す |

- 変換は pypdfium2 の `PdfDocument` → `page.render(scale=dpi/72).to_pil()` → PNG保存。幅・高さはレンダリング結果のピクセルサイズ。
- 全ページを変換する(同一様式でも他ページで確認できるように)。
- 出力PNGはサーバーの一時ディレクトリに `id` 単位で保存。プロセス終了時に破棄。永続化しない。
- `id` はUUID4。
- エラー: PDFとして開けない → 400。DPIが範囲外(36〜1200) → 422。存在しない `id` / ページ番号 → 404。
- DPI初期値720ではA4が約6,000×8,400px、PNG1枚が数十MBになりえる。初回読込に数秒かかることは許容する。ページ数上限は設けない。

## 5. ドメインモデル(フロント)

`frontend/src/model/types.ts`:

```ts
interface DplSegment { startLine: number; dots: number[] }
interface Block { startX: number; endX: number; startLine: number; endLine: number }
type LineRef = { kind: 'abs'; n: number } | { kind: 'fromEnd'; n: number }  // 10 / E1
type DivCond = 'M' | 'F' | 'B' | 'A' | 'N' | 'W'
interface Div { value: string; cond: DivCond; startX: number; endX: number; sameContinue: 'Y' | 'N' | null }
interface Paragraph {
  startLine: number | null
  endLine: LineRef | null
  name: string            // 空文字は未指定
  spanPage: boolean
  div: Div
  delBackwardSpace: boolean
}
interface FormDefinition { dpl: DplSegment[]; blocks: Block[]; paragraphs: Paragraph[] }
```

- `null` / 空文字は「未指定」。出力時にその欄を空にする。
- `paragraphs` の配列順がそのまま親→子→孫の入れ子。
- 座標はすべて画像ピクセル基準の整数。表示倍率は描画層でのみ扱う。

## 6. 計算(フロント、純粋関数)

`frontend/src/model/` に置き、すべてモデルと画像サイズから導く。副作用なし。

### 6.1 `computePageLines(dpl, pageHeight): PageLine[]`

`PageLine = { n: number; y0: number; y1: number }`。

- `dpl` を `startLine` 昇順に並べる。開始ライン1のセグメントがなければ空配列を返す(検証で別途エラー)。
- ライン1はY=0から始まる。ライン n の高さは、n を含む最大の `startLine` を持つセグメントの `dots` を、そのセグメント開始からの相対位置でサイクリックに引く。
- `y0 < pageHeight` の間ラインを生成する。最後のラインは `y1` がページ高を超えてもそのまま保持する。

### 6.2 `computeBlockLines(blocks, pageLines, pageWidth): BlockLine[]`

`BlockLine = { n: number; blockIndex: number; x0: number; x1: number; y0: number; y1: number }`。

- `blocks` が空ならページ全体を1ブロック(`x0=0, x1=pageWidth`, 全ページライン)とみなす。
- ブロック順に `startLine..endLine` のページラインを切り出し、X範囲を付ける。`n` は1から通しで振り直す。
- ページラインの範囲外を指すブロックは、範囲内の部分だけ切り出す(検証で別途エラー)。

### 6.3 `resolveParagraphs(paragraphs, blockLines): ResolvedParagraph[]`

`ResolvedParagraph = { index: number; name: string; first: number; last: number; rects: Rect[]; divRects: Rect[]; error?: string }`。

- 最上位の親範囲は `1..blockLines.length`。
- 各パラグラフの `first = parent.first + (startLine ?? 1) - 1`。`last` は `endLine` が `null` なら `parent.last`、`abs` なら `parent.first + n - 1`、`fromEnd` なら `parent.last - n + 1`。
- 解決結果が親をはみ出す/逆転する場合は `error` を付け、描画用矩形は親範囲でクリップしたものを返す。次のパラグラフの親には、この解決結果(クリップ済)を使う。
- `rects` は `first..last` のブロックラインを、ブロックごとに連続するものをまとめた矩形の集合。`divRects` は同じ矩形をDIVの `startX..endX` で横に切ったもの。
- `name` が空なら `Paragraph<index>`(1始まり)。

### 6.4 `validate(def, pageLines, blockLines): ValidationError[]`

`ValidationError = { target: 'dpl' | 'block' | 'paragraph'; index: number | null; message: string }`。

- DPL: セグメントあり かつ 開始ライン1なし / 開始ライン重複 / 開始ラインが1未満 / `dots` が空または正整数でない要素を含む。
- BLOCK: DPL未定義 / `startX >= endX` / `startLine > endLine` / ライン範囲がページラインの範囲外 / 他のブロックと矩形が重複(X区間とY区間の両方が交差)。
- PARAGRAPH: DPL未定義 / `div.startX >= div.endX` / `startLine` が1未満 / `endLine.n` が1未満 / 解決後の範囲が親をはみ出す・逆転。

### 6.5 `serialize(def): string`

- セクション順: ライン定義 → ブロック定義 → パラグラフ定義。各セクションの先頭に `# ライン定義` などのコメント行、空でないセクション間に空行。
- 各行は末尾 `,` 付き。例: `DPL,1,80,` / `BLOCK,0,150,4,11,` / `PARAGRAPH,1,10,支店,N,` / `DIV,KEY,支店,A,200,500,N,` / `DEL_BACKWARD_SPACE,Y,`。
- 未指定欄は空文字(例: `PARAGRAPH,,E1,,N,`)。`endLine.fromEnd` は `E<n>`。
- `spanPage` は常に `Y`/`N` を出力。`delBackwardSpace` が真のときだけ `DEL_BACKWARD_SPACE,Y,` を出力する。
- 空のセクションは見出しごと出力しない。定義が完全に空なら空文字を返す。

## 7. UI

### 7.1 画面構成(1画面、3領域)

- **上部バー**: PDF選択、DPI入力(初期値 **720**、36〜1200)、「読込」ボタン、ページ切替(1 / n)、表示倍率(幅に合わせる / 50〜200%)、「定義ファイルをダウンロード」。読込エラーはこのバー直下に表示。
- **左: キャンバス**: ページPNGの上にSVGオーバーレイを重ねる。マウス位置の画像座標(X, Y)と、その位置のページライン番号・ブロック通し番号を常時表示。
- **右: 編集パネル**: 「ライン」「ブロック」「パラグラフ」のタブ。その下に常時表示の「出力プレビュー」(生成テキスト、読み取り専用)と「検証結果」(エラー一覧)。

オーバーレイは常に全定義を描画するが、選択中タブに対応する要素だけ濃く、他は薄く表示する。

### 7.2 ラインタブ

- DPLセグメントの一覧。各行に開始ライン(整数)と dots(カンマ区切り文字列を入力し整数配列にパース。パース不能なら検証エラー)。追加・削除。
- オーバーレイ: 各ライン境界の水平線と左端にライン番号。セグメント切り替わり位置は色を変える。
- 補助操作: キャンバス上のラインをクリックすると、そのライン番号を開始ラインにした新セグメントを追加(dotsは直前セグメントをコピー)。同じ開始ラインが既にあれば追加しない。

### 7.3 ブロックタブ

- キャンバス上でドラッグして矩形を作成。Xはそのままピクセル、Yはドラッグ範囲に含まれるページラインの先頭/最終ライン番号にスナップ。
- 一覧で数値編集、削除、上下ボタンで並べ替え(順序=ブロック番号)。
- オーバーレイ: 半透明の色付き矩形とブロック番号。矩形内の各ラインに振り直し後の通し番号を表示。重複しているブロックは赤枠。

### 7.4 パラグラフタブ

- 一覧はインデントで入れ子を表現。追加は末尾(最深)に子として追加。削除、上下ボタンで並べ替え。
- フォーム: 開始ライン、終了ライン(空 / 数値 / `E数値` を1つのテキスト欄でパース)、名前、ページ跨り、DIV(比較値、比較条件の選択、開始X、終了X、同値継続 Y/N/未指定)、DEL_BACKWARD_SPACE。
- キャンバス上で横方向にドラッグすると、選択中パラグラフのDIVの開始X/終了Xに入る。
- オーバーレイ: 解決後の行範囲を全幅の帯で、その中にDIVのX範囲を濃い枠で表示し、パラグラフ名をラベルにする。入れ子は深いほど内側に細く描く。

### 7.5 ダウンロード

- 検証エラーがある間はボタンを無効化し、理由は検証結果パネルに出す。
- ファイル名は `<PDFファイル名(拡張子なし)>.txt`。UTF-8、改行LF。ブラウザのダウンロードで保存。

### 7.6 状態管理

Piniaストア1つ(`useDefinitionStore`):

- ドキュメント情報(id, ページ数, 各ページのサイズ, 元ファイル名)、現在ページ、表示倍率
- `FormDefinition`
- 選択中タブと選択中要素(ブロック/パラグラフのインデックス)
- `pageLines` / `blockLines` / `resolvedParagraphs` / `errors` / `outputText` はすべて `computed` で導出

## 8. エラー処理

- 読込失敗(非PDF、DPI範囲外、サーバー停止)は上部バー直下にメッセージ表示。定義は保持したまま再読込できる。
- 定義の不整合は検証結果パネルに集約し、ダウンロードだけを止める。編集途中の一時的な不整合で操作をブロックしない。
- 画像サイズが変わる操作(別PDF、またはDPI変更で再読込)は座標の意味が変わるため、定義が空でなければ確認ダイアログを出し、了承後に定義をクリアする。

## 9. テスト

- **フロント**: Vitest。`computePageLines` / `computeBlockLines` / `resolveParagraphs` / `validate` / `serialize` を仕様の設定例で網羅する。
  - DPL 1→80, 20→85 / DPL 1→55, 17→23,22(サイクリック) / 4ブロック例(0-300 1-3, 0-150 4-11, 150-300 4-11, 0-300 12-14 → 通し番号1..22) / `E1` / 未指定欄の出力 / 重複ブロックの検出。
  - コンポーネントは Vue Test Utils でストアとの結線を最低限確認。
- **バックエンド**: pytest + httpx。pypdfium2で2ページの空PDFをテスト内で生成し、`POST /api/documents` → `GET .../pages/1` の流れと 400 / 404 / 422 を確認。

## 10. ツール

- backend: `uv`。依存: fastapi, uvicorn, python-multipart, pypdfium2, Pillow。dev: pytest, httpx, ruff。
- frontend: npm。Vite, Vue 3, TypeScript, Pinia, Vitest, @vue/test-utils, ESLint(Vue推奨設定)。CSSは素のCSS。UIライブラリは入れない。
- READMEに起動手順(バックエンド・フロント各1コマンド)を記載。
