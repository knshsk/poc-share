# Form Define Builder Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** PDF帳票を画像化した上に枠を重ねながら、DPL / BLOCK / PARAGRAPH / DIV / DEL_BACKWARD_SPACE からなるフォーム定義ファイルをGUIで作成しダウンロードするWebアプリを作る。

**Architecture:** FastAPI バックエンドは pypdfium2 でPDFをページごとのPNGに変換して返すだけ。定義モデル・ライン座標計算・ブロック/パラグラフ解決・検証・テキスト生成はすべてフロント(TypeScript の純粋関数)に置き、Pinia ストアの `computed` で導出する。キャンバスは `<img>` の上に画像ピクセル座標の `viewBox` を持つSVGを重ね、オーバーレイは画像座標のまま描く。

**Tech Stack:** Python 3.12 / uv / FastAPI / pypdfium2 / Pillow / pytest / httpx / ruff。Node 24 / Vite / Vue 3 / TypeScript / Pinia / Vitest / @vue/test-utils / ESLint。

**Spec:** `docs/superpowers/specs/2026-09-06-form-define-builder-design.md`

## Global Constraints

- バックエンドは定義に関する知識を一切持たない。PDF→PNG変換のみ。
- DPI受付範囲は 36〜1200。フロントの初期値は 720。
- 座標はすべて画像左上原点の整数ピクセル。モデルは表示倍率を知らない。
- 出力テキストは UTF-8、改行 LF、各行末に `,`、セクション見出しは `# ライン定義` / `# ブロック定義` / `# パラグラフ定義`。
- `paragraphs` の配列順 = 親→子→孫の入れ子。
- 既存定義ファイルの読込、テキスト抽出、永続化、Undo/Redo はスコープ外。
- UIライブラリは使わない(素のCSS)。
- コミットメッセージ末尾に `Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>` を付ける。
- コマンドは `backend/` では `uv run ...`、`frontend/` では `npm run ...` で実行する。

---

## File Structure

```
.gitignore
README.md
backend/
  pyproject.toml
  app/__init__.py
  app/render.py        render_pdf(): PDF bytes + DPI → PNG群とサイズ。InvalidPdfError。DPI範囲定数
  app/store.py         DocumentStore: 一時ディレクトリ管理、id→サイズ、ページPNGパス解決、cleanup
  app/main.py          FastAPI app: POST /api/documents, GET /api/documents/{id}/pages/{n}, dist静的配信
  tests/conftest.py    テスト用PDF生成フィクスチャ
  tests/test_render.py
  tests/test_api.py
frontend/
  package.json, vite.config.ts, tsconfig.json, eslint.config.js, index.html, src/env.d.ts
  src/main.ts, src/App.vue, src/style.css
  src/model/types.ts       ドメイン型
  src/model/parse.ts       parseDots / parseLineRef / formatLineRef
  src/model/lines.ts       computePageLines
  src/model/blocks.ts      computeBlockLines / blockFromRect / findOverlappingBlocks
  src/model/paragraphs.ts  resolveParagraphs
  src/model/validate.ts    validate
  src/model/serialize.ts   serialize
  src/api/documents.ts     uploadDocument / pageImageUrl
  src/utils/download.ts    downloadText
  src/stores/definition.ts useDefinitionStore
  src/components/TopBar.vue
  src/components/PageCanvas.vue
  src/components/overlay/LinesOverlay.vue
  src/components/overlay/BlocksOverlay.vue
  src/components/overlay/ParagraphsOverlay.vue
  src/components/EditorPanel.vue
  src/components/panels/LinesPanel.vue
  src/components/panels/DplSegmentRow.vue
  src/components/panels/BlocksPanel.vue
  src/components/panels/ParagraphsPanel.vue
  src/components/OutputPreview.vue
  src/components/ValidationPanel.vue
  src/model/*.test.ts, src/stores/definition.test.ts, src/components/*.test.ts
```

---

### Task 1: バックエンド土台と PDF→PNG 変換

**Files:**
- Create: `.gitignore`, `backend/pyproject.toml`, `backend/app/__init__.py`, `backend/app/render.py`
- Test: `backend/tests/conftest.py`, `backend/tests/test_render.py`

**Interfaces:**
- Produces: `render_pdf(pdf_bytes: bytes, dpi: int, out_dir: Path) -> list[tuple[int, int]]`(`out_dir/1.png`, `2.png`... を書き、各ページの `(width, height)` を返す)、`InvalidPdfError(Exception)`、`MIN_DPI = 36`、`MAX_DPI = 1200`

- [ ] **Step 1: ルートの .gitignore を作る**

```gitignore
# python
backend/.venv/
__pycache__/
.pytest_cache/
.ruff_cache/

# node
frontend/node_modules/
frontend/dist/

# local
.ignore/
```

- [ ] **Step 2: pyproject.toml を作る**

`backend/pyproject.toml`:

```toml
[project]
name = "form-define-builder-backend"
version = "0.1.0"
description = "PDF to PNG rendering API for Form Define Builder"
requires-python = ">=3.12"
dependencies = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.30",
    "python-multipart>=0.0.9",
    "pypdfium2>=4.30,<5",
    "Pillow>=10",
]

[dependency-groups]
dev = [
    "pytest>=8",
    "httpx>=0.27",
    "ruff>=0.6",
]

[tool.uv]
package = false

[tool.pytest.ini_options]
testpaths = ["tests"]

[tool.ruff]
line-length = 100
target-version = "py312"
```

`backend/app/__init__.py` は空ファイル。

Run: `cd backend && uv sync`
Expected: `.venv` が作られ、依存がインストールされる。

- [ ] **Step 3: テスト用PDFフィクスチャを書く**

`backend/tests/conftest.py`:

```python
import io

import pypdfium2 as pdfium
import pytest


def make_pdf(page_count: int, width: float = 595, height: float = 842) -> bytes:
    """指定ページ数の空PDF(A4相当、ポイント単位)を生成する。"""
    pdf = pdfium.PdfDocument.new()
    for _ in range(page_count):
        pdf.new_page(width, height)
    buf = io.BytesIO()
    pdf.save(buf)
    pdf.close()
    return buf.getvalue()


@pytest.fixture
def two_page_pdf() -> bytes:
    return make_pdf(2)
```

- [ ] **Step 4: render_pdf の失敗するテストを書く**

`backend/tests/test_render.py`:

```python
from pathlib import Path

import pytest
from PIL import Image

from app.render import InvalidPdfError, render_pdf


def test_render_writes_one_png_per_page(two_page_pdf: bytes, tmp_path: Path):
    sizes = render_pdf(two_page_pdf, dpi=72, out_dir=tmp_path)

    assert len(sizes) == 2
    assert (tmp_path / "1.png").is_file()
    assert (tmp_path / "2.png").is_file()
    with Image.open(tmp_path / "1.png") as im:
        assert im.size == sizes[0]


def test_render_size_scales_with_dpi(two_page_pdf: bytes, tmp_path: Path):
    (w72, h72), _ = render_pdf(two_page_pdf, dpi=72, out_dir=tmp_path / "a")
    (w144, h144), _ = render_pdf(two_page_pdf, dpi=144, out_dir=tmp_path / "b")

    assert w72 == 595 and h72 == 842
    assert w144 == 1190 and h144 == 1684


def test_render_rejects_non_pdf(tmp_path: Path):
    with pytest.raises(InvalidPdfError):
        render_pdf(b"this is not a pdf", dpi=72, out_dir=tmp_path)
```

- [ ] **Step 5: テストが失敗することを確認する**

Run: `cd backend && uv run pytest tests/test_render.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'app.render'`

- [ ] **Step 6: render.py を実装する**

`backend/app/render.py`:

```python
from pathlib import Path

import pypdfium2 as pdfium

MIN_DPI = 36
MAX_DPI = 1200


class InvalidPdfError(Exception):
    """入力がPDFとして開けない。"""


def render_pdf(pdf_bytes: bytes, dpi: int, out_dir: Path) -> list[tuple[int, int]]:
    """PDFの全ページを指定DPIでPNGにして out_dir/<n>.png に書き、各ページの (width, height) を返す。"""
    try:
        pdf = pdfium.PdfDocument(pdf_bytes)
    except pdfium.PdfiumError as e:
        raise InvalidPdfError(str(e)) from e

    out_dir.mkdir(parents=True, exist_ok=True)
    sizes: list[tuple[int, int]] = []
    try:
        for i in range(len(pdf)):
            page = pdf[i]
            bitmap = page.render(scale=dpi / 72)
            image = bitmap.to_pil()
            image.save(out_dir / f"{i + 1}.png")
            sizes.append((image.width, image.height))
            page.close()
    finally:
        pdf.close()
    return sizes
```

- [ ] **Step 7: テストが通ることを確認する**

Run: `cd backend && uv run pytest tests/test_render.py -v`
Expected: 3 PASS

- [ ] **Step 8: lint とコミット**

Run: `cd backend && uv run ruff check .`
Expected: エラーなし

```bash
git add .gitignore backend/pyproject.toml backend/uv.lock backend/app backend/tests
git commit -m "feat(backend): render PDF pages to PNG with pypdfium2

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 2: ドキュメントストアとAPI

**Files:**
- Create: `backend/app/store.py`, `backend/app/main.py`
- Test: `backend/tests/test_api.py`

**Interfaces:**
- Consumes: `render_pdf`, `InvalidPdfError`, `MIN_DPI`, `MAX_DPI`(Task 1)
- Produces: `POST /api/documents`(multipart `file`, `dpi`) → `{id, page_count, pages:[{width,height}]}`、`GET /api/documents/{id}/pages/{n}` → `image/png`。`DocumentStore.new_dir() -> tuple[str, Path]`、`register(doc_id, sizes)`、`discard(doc_id)`、`page_path(doc_id, n) -> Path | None`、`cleanup()`

- [ ] **Step 1: 失敗するAPIテストを書く**

`backend/tests/test_api.py`:

```python
import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def upload(client: TestClient, data: bytes, dpi="72"):
    return client.post(
        "/api/documents",
        files={"file": ("sample.pdf", data, "application/pdf")},
        data={"dpi": dpi},
    )


def test_upload_returns_page_sizes(client, two_page_pdf):
    res = upload(client, two_page_pdf)

    assert res.status_code == 200
    body = res.json()
    assert body["page_count"] == 2
    assert body["pages"] == [{"width": 595, "height": 842}] * 2
    assert isinstance(body["id"], str) and body["id"]


def test_get_page_returns_png(client, two_page_pdf):
    doc_id = upload(client, two_page_pdf).json()["id"]

    res = client.get(f"/api/documents/{doc_id}/pages/2")

    assert res.status_code == 200
    assert res.headers["content-type"] == "image/png"
    assert res.content[:8] == b"\x89PNG\r\n\x1a\n"


def test_get_missing_page_is_404(client, two_page_pdf):
    doc_id = upload(client, two_page_pdf).json()["id"]

    assert client.get(f"/api/documents/{doc_id}/pages/3").status_code == 404
    assert client.get(f"/api/documents/{doc_id}/pages/0").status_code == 404
    assert client.get("/api/documents/no-such-id/pages/1").status_code == 404


def test_upload_non_pdf_is_400(client):
    res = upload(client, b"not a pdf")

    assert res.status_code == 400
    assert "PDF" in res.json()["detail"]


@pytest.mark.parametrize("dpi", ["35", "1201", "abc"])
def test_upload_bad_dpi_is_422(client, two_page_pdf, dpi):
    assert upload(client, two_page_pdf, dpi=dpi).status_code == 422
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd backend && uv run pytest tests/test_api.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'app.main'`

- [ ] **Step 3: store.py を実装する**

`backend/app/store.py`:

```python
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path


@dataclass
class DocumentInfo:
    id: str
    dir: Path
    sizes: list[tuple[int, int]]


class DocumentStore:
    """変換済みPNGを一時ディレクトリに置き、id で引けるようにする。プロセス終了時に破棄。"""

    def __init__(self) -> None:
        self._root = Path(tempfile.mkdtemp(prefix="form-define-builder-"))
        self._docs: dict[str, DocumentInfo] = {}

    def new_dir(self) -> tuple[str, Path]:
        doc_id = uuid.uuid4().hex
        path = self._root / doc_id
        path.mkdir()
        return doc_id, path

    def register(self, doc_id: str, sizes: list[tuple[int, int]]) -> DocumentInfo:
        info = DocumentInfo(id=doc_id, dir=self._root / doc_id, sizes=sizes)
        self._docs[doc_id] = info
        return info

    def discard(self, doc_id: str) -> None:
        self._docs.pop(doc_id, None)
        shutil.rmtree(self._root / doc_id, ignore_errors=True)

    def page_path(self, doc_id: str, n: int) -> Path | None:
        info = self._docs.get(doc_id)
        if info is None or n < 1 or n > len(info.sizes):
            return None
        return info.dir / f"{n}.png"

    def cleanup(self) -> None:
        self._docs.clear()
        shutil.rmtree(self._root, ignore_errors=True)
```

- [ ] **Step 4: main.py を実装する**

`backend/app/main.py`:

```python
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from app.render import MAX_DPI, MIN_DPI, InvalidPdfError, render_pdf
from app.store import DocumentStore

FRONTEND_DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"

store = DocumentStore()


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    store.cleanup()


app = FastAPI(title="Form Define Builder", lifespan=lifespan)


@app.post("/api/documents")
async def create_document(file: UploadFile = File(...), dpi: int = Form(...)):
    if not MIN_DPI <= dpi <= MAX_DPI:
        raise HTTPException(
            status_code=422, detail=f"DPIは{MIN_DPI}〜{MAX_DPI}の範囲で指定してください"
        )
    data = await file.read()
    doc_id, out_dir = store.new_dir()
    try:
        sizes = await run_in_threadpool(render_pdf, data, dpi, out_dir)
    except InvalidPdfError:
        store.discard(doc_id)
        raise HTTPException(status_code=400, detail="PDFとして開けませんでした")
    store.register(doc_id, sizes)
    return {
        "id": doc_id,
        "page_count": len(sizes),
        "pages": [{"width": w, "height": h} for w, h in sizes],
    }


@app.get("/api/documents/{doc_id}/pages/{n}")
def get_page(doc_id: str, n: int):
    path = store.page_path(doc_id, n)
    if path is None:
        raise HTTPException(status_code=404, detail="ページが見つかりません")
    return FileResponse(path, media_type="image/png")


if FRONTEND_DIST.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")
```

- [ ] **Step 5: テストが通ることを確認する**

Run: `cd backend && uv run pytest -v`
Expected: すべて PASS(test_render 3件 + test_api 7件)

- [ ] **Step 6: 手動で起動確認**

Run: `cd backend && uv run uvicorn app.main:app --port 8000`
Expected: 起動ログが出て `http://localhost:8000/docs` が開ける。Ctrl+C で止める。

- [ ] **Step 7: lint とコミット**

Run: `cd backend && uv run ruff check .`

```bash
git add backend/app backend/tests
git commit -m "feat(backend): add document upload and page image API

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 3: フロント土台、ドメイン型、入力パーサ

**Files:**
- Create: `frontend/package.json`, `frontend/vite.config.ts`, `frontend/tsconfig.json`, `frontend/eslint.config.js`, `frontend/index.html`, `frontend/src/env.d.ts`, `frontend/src/main.ts`, `frontend/src/App.vue`, `frontend/src/style.css`, `frontend/src/model/types.ts`, `frontend/src/model/parse.ts`
- Test: `frontend/src/model/parse.test.ts`

**Interfaces:**
- Produces: `types.ts` の型(下記)、`parseDots(text: string): number[] | null`、`parseLineRef(text: string): { ok: true; value: LineRef | null } | { ok: false }`、`formatLineRef(ref: LineRef | null): string`

- [ ] **Step 1: package.json を作る**

`frontend/package.json`:

```json
{
  "name": "form-define-builder-frontend",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vue-tsc --noEmit && vite build",
    "preview": "vite preview",
    "test": "vitest run",
    "test:watch": "vitest",
    "lint": "eslint ."
  },
  "dependencies": {
    "pinia": "^3.0.3",
    "vue": "^3.5.18"
  },
  "devDependencies": {
    "@vitejs/plugin-vue": "^6.0.1",
    "@vue/eslint-config-typescript": "^14.6.0",
    "@vue/test-utils": "^2.4.6",
    "eslint": "^9.33.0",
    "eslint-plugin-vue": "^10.4.0",
    "jsdom": "^26.1.0",
    "typescript": "~5.8.3",
    "vite": "^7.1.2",
    "vitest": "^3.2.4",
    "vue-tsc": "^3.0.5"
  }
}
```

- [ ] **Step 2: 設定ファイル群を作る**

`frontend/vite.config.ts`:

```ts
import { defineConfig } from 'vitest/config'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    proxy: { '/api': 'http://localhost:8000' },
  },
  test: {
    environment: 'jsdom',
  },
})
```

`frontend/tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "skipLibCheck": true,
    "noEmit": true,
    "isolatedModules": true,
    "verbatimModuleSyntax": true,
    "jsx": "preserve",
    "types": ["vite/client"]
  },
  "include": ["src/**/*.ts", "src/**/*.vue", "vite.config.ts"]
}
```

`frontend/eslint.config.js`:

```js
import pluginVue from 'eslint-plugin-vue'
import { defineConfigWithVueTs, vueTsConfigs } from '@vue/eslint-config-typescript'

// 'flat/essential' を使う: 'flat/recommended' に含まれる書式系ルール(1行1属性など)は
// フォーマッタの領分なので採用しない
export default defineConfigWithVueTs(
  { ignores: ['dist/**', 'node_modules/**'] },
  pluginVue.configs['flat/essential'],
  vueTsConfigs.recommended,
)
```

`frontend/index.html`:

```html
<!doctype html>
<html lang="ja">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Form Define Builder</title>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
```

`frontend/src/env.d.ts`:

```ts
/// <reference types="vite/client" />
```

(`.vue` の型は vue-tsc が直接解決するので、`declare module '*.vue'` のシムは置かない。)

`frontend/src/main.ts`:

```ts
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import './style.css'

createApp(App).use(createPinia()).mount('#app')
```

`frontend/src/App.vue`(仮。Task 10 で置き換える):

```vue
<script setup lang="ts"></script>

<template>
  <h1>Form Define Builder</h1>
</template>
```

`frontend/src/style.css`:

```css
:root {
  font-family: system-ui, -apple-system, 'Segoe UI', 'Hiragino Sans', 'Noto Sans JP', sans-serif;
  font-size: 14px;
  color: #222;
  background: #f4f4f4;
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
}

button,
input,
select {
  font: inherit;
}
```

Run: `cd frontend && npm install && npm run build`
Expected: `dist/` が生成される。

- [ ] **Step 3: ドメイン型を書く**

`frontend/src/model/types.ts`:

```ts
/** DPL,<開始ライン>,<ドット数>[,<ドット数>...] */
export interface DplSegment {
  startLine: number
  dots: number[]
}

/** BLOCK,<開始X>,<終了X>,<開始ライン>,<終了ライン> */
export interface Block {
  startX: number
  endX: number
  startLine: number
  endLine: number
}

/** 終了ラインの指定。abs: 親内の絶対ライン番号、fromEnd: E<n>(親の最終ラインから) */
export type LineRef = { kind: 'abs'; n: number } | { kind: 'fromEnd'; n: number }

export type DivCond = 'M' | 'F' | 'B' | 'A' | 'N' | 'W'

export const DIV_CONDS: { value: DivCond; label: string }[] = [
  { value: 'M', label: 'M: 中間一致' },
  { value: 'F', label: 'F: 完全一致' },
  { value: 'B', label: 'B: 前方一致' },
  { value: 'A', label: 'A: 後方一致' },
  { value: 'N', label: 'N: 不一致' },
  { value: 'W', label: 'W: ワイルドカード' },
]

/** DIV,KEY,<比較値>,<比較条件>,<開始X>,<終了X>,<同値継続> */
export interface Div {
  value: string
  cond: DivCond
  startX: number
  endX: number
  sameContinue: 'Y' | 'N' | null
}

/** PARAGRAPH + DIV + DEL_BACKWARD_SPACE の1組 */
export interface Paragraph {
  startLine: number | null
  endLine: LineRef | null
  /** 空文字は未指定(出力側で Paragraph<n> と自動命名される) */
  name: string
  spanPage: boolean
  div: Div
  delBackwardSpace: boolean
}

export interface FormDefinition {
  dpl: DplSegment[]
  blocks: Block[]
  paragraphs: Paragraph[]
}

/** ページ上のライン(DPLから算出)。y は画像ピクセル */
export interface PageLine {
  n: number
  y0: number
  y1: number
}

/** ブロック適用後の通し番号付きライン */
export interface BlockLine {
  n: number
  blockIndex: number
  x0: number
  x1: number
  y0: number
  y1: number
}

export interface Rect {
  x0: number
  y0: number
  x1: number
  y1: number
}

export interface ResolvedParagraph {
  index: number
  name: string
  first: number
  last: number
  rects: Rect[]
  divRects: Rect[]
  error?: string
}

export type ValidationTarget = 'dpl' | 'block' | 'paragraph'

export interface ValidationError {
  target: ValidationTarget
  /** 対象要素のインデックス(0始まり)。要素に紐づかないエラーは null */
  index: number | null
  message: string
}

export function emptyDefinition(): FormDefinition {
  return { dpl: [], blocks: [], paragraphs: [] }
}

export function newParagraph(): Paragraph {
  return {
    startLine: null,
    endLine: null,
    name: '',
    spanPage: false,
    div: { value: '', cond: 'M', startX: 0, endX: 0, sameContinue: null },
    delBackwardSpace: false,
  }
}
```

- [ ] **Step 4: パーサの失敗するテストを書く**

`frontend/src/model/parse.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { formatLineRef, parseDots, parseLineRef } from './parse'

describe('parseDots', () => {
  it('カンマ区切りの正整数を配列にする', () => {
    expect(parseDots('23,22')).toEqual([23, 22])
  })

  it('空白と末尾カンマを許す', () => {
    expect(parseDots(' 80 , ')).toEqual([80])
  })

  it('空文字は null', () => {
    expect(parseDots('')).toBeNull()
  })

  it('0・負数・非数値は null', () => {
    expect(parseDots('0')).toBeNull()
    expect(parseDots('-5')).toBeNull()
    expect(parseDots('12,x')).toBeNull()
    expect(parseDots('1.5')).toBeNull()
  })
})

describe('parseLineRef', () => {
  it('空は未指定', () => {
    expect(parseLineRef('')).toEqual({ ok: true, value: null })
    expect(parseLineRef('  ')).toEqual({ ok: true, value: null })
  })

  it('数値は abs', () => {
    expect(parseLineRef('10')).toEqual({ ok: true, value: { kind: 'abs', n: 10 } })
  })

  it('E<n> は fromEnd(小文字も可)', () => {
    expect(parseLineRef('E1')).toEqual({ ok: true, value: { kind: 'fromEnd', n: 1 } })
    expect(parseLineRef('e3')).toEqual({ ok: true, value: { kind: 'fromEnd', n: 3 } })
  })

  it('不正な文字列は ok: false', () => {
    expect(parseLineRef('E')).toEqual({ ok: false })
    expect(parseLineRef('0')).toEqual({ ok: false })
    expect(parseLineRef('abc')).toEqual({ ok: false })
  })
})

describe('formatLineRef', () => {
  it('parseLineRef の逆変換', () => {
    expect(formatLineRef(null)).toBe('')
    expect(formatLineRef({ kind: 'abs', n: 7 })).toBe('7')
    expect(formatLineRef({ kind: 'fromEnd', n: 2 })).toBe('E2')
  })
})
```

- [ ] **Step 5: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/model/parse.test.ts`
Expected: FAIL — `Failed to resolve import "./parse"`

- [ ] **Step 6: parse.ts を実装する**

`frontend/src/model/parse.ts`:

```ts
import type { LineRef } from './types'

const POSITIVE_INT = /^[1-9]\d*$/

/** "23,22" → [23, 22]。空・不正なら null */
export function parseDots(text: string): number[] | null {
  const parts = text
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s !== '')
  if (parts.length === 0) return null
  if (!parts.every((p) => POSITIVE_INT.test(p))) return null
  return parts.map((p) => Number(p))
}

/** "" → null(未指定)、"10" → abs、"E1" → fromEnd */
export function parseLineRef(text: string): { ok: true; value: LineRef | null } | { ok: false } {
  const t = text.trim()
  if (t === '') return { ok: true, value: null }
  if (POSITIVE_INT.test(t)) return { ok: true, value: { kind: 'abs', n: Number(t) } }
  const m = /^[Ee]([1-9]\d*)$/.exec(t)
  if (m) return { ok: true, value: { kind: 'fromEnd', n: Number(m[1]) } }
  return { ok: false }
}

export function formatLineRef(ref: LineRef | null): string {
  if (ref === null) return ''
  return ref.kind === 'abs' ? String(ref.n) : `E${ref.n}`
}
```

- [ ] **Step 7: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/model/parse.test.ts`
Expected: 10 PASS

- [ ] **Step 8: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit`
Expected: エラーなし

```bash
git add frontend/package.json frontend/package-lock.json frontend/vite.config.ts frontend/tsconfig.json frontend/eslint.config.js frontend/index.html frontend/src
git commit -m "feat(frontend): scaffold Vite/Vue app with domain types and input parsers

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 4: ライン計算 computePageLines

**Files:**
- Create: `frontend/src/model/lines.ts`
- Test: `frontend/src/model/lines.test.ts`

**Interfaces:**
- Consumes: `DplSegment`, `PageLine`(Task 3)
- Produces: `computePageLines(dpl: DplSegment[], pageHeight: number): PageLine[]`、`segmentForLine(dpl: DplSegment[], n: number): DplSegment | null`

- [ ] **Step 1: 失敗するテストを書く**

`frontend/src/model/lines.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { computePageLines, segmentForLine } from './lines'

describe('computePageLines', () => {
  it('DPL 1→80, 20→85: 19行目まで80、20行目以降85', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [80] },
        { startLine: 20, dots: [85] },
      ],
      2000,
    )
    expect(lines[0]).toEqual({ n: 1, y0: 0, y1: 80 })
    expect(lines[18]).toEqual({ n: 19, y0: 1440, y1: 1520 })
    expect(lines[19]).toEqual({ n: 20, y0: 1520, y1: 1605 })
    expect(lines).toHaveLength(25)
    expect(lines[24]).toEqual({ n: 25, y0: 1945, y1: 2030 })
  })

  it('DPL 1→55, 17→23,22: 17行目以降は 23, 22 を繰り返す', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [55] },
        { startLine: 17, dots: [23, 22] },
      ],
      1000,
    )
    expect(lines[15]).toEqual({ n: 16, y0: 825, y1: 880 })
    expect(lines[16]).toEqual({ n: 17, y0: 880, y1: 903 })
    expect(lines[17]).toEqual({ n: 18, y0: 903, y1: 925 })
    expect(lines[18]).toEqual({ n: 19, y0: 925, y1: 948 })
    expect(lines).toHaveLength(22)
  })

  it('セグメントの順序は startLine で並べ替えられる', () => {
    const lines = computePageLines(
      [
        { startLine: 3, dots: [10] },
        { startLine: 1, dots: [20] },
      ],
      100,
    )
    expect(lines.map((l) => l.y1 - l.y0)).toEqual([20, 20, 10, 10, 10, 10, 10, 10])
  })

  it('開始ライン1のセグメントがなければ空', () => {
    expect(computePageLines([{ startLine: 2, dots: [10] }], 100)).toEqual([])
  })

  it('DPLが空、または dots が不正なセグメントしかなければ空', () => {
    expect(computePageLines([], 100)).toEqual([])
    expect(computePageLines([{ startLine: 1, dots: [] }], 100)).toEqual([])
    expect(computePageLines([{ startLine: 1, dots: [0] }], 100)).toEqual([])
  })

  it('不正なセグメントは無視して残りで計算する', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [50] },
        { startLine: 2, dots: [] },
      ],
      100,
    )
    expect(lines).toHaveLength(2)
  })

  it('同じ startLine が重複したら先に現れたものを使う', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [50] },
        { startLine: 1, dots: [25] },
      ],
      100,
    )
    expect(lines).toHaveLength(2)
  })

  it('ページ高さが0以下なら空', () => {
    expect(computePageLines([{ startLine: 1, dots: [10] }], 0)).toEqual([])
  })
})

describe('segmentForLine', () => {
  const dpl = [
    { startLine: 1, dots: [80] },
    { startLine: 20, dots: [85] },
  ]

  it('そのラインを支配するセグメントを返す', () => {
    expect(segmentForLine(dpl, 1)).toBe(dpl[0])
    expect(segmentForLine(dpl, 19)).toBe(dpl[0])
    expect(segmentForLine(dpl, 20)).toBe(dpl[1])
    expect(segmentForLine(dpl, 99)).toBe(dpl[1])
  })

  it('該当がなければ null', () => {
    expect(segmentForLine([], 1)).toBeNull()
    expect(segmentForLine([{ startLine: 5, dots: [1] }], 2)).toBeNull()
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/model/lines.test.ts`
Expected: FAIL — `Failed to resolve import "./lines"`

- [ ] **Step 3: lines.ts を実装する**

`frontend/src/model/lines.ts`:

```ts
import type { DplSegment, PageLine } from './types'

export function isValidSegment(seg: DplSegment): boolean {
  return (
    Number.isInteger(seg.startLine) &&
    seg.startLine >= 1 &&
    seg.dots.length > 0 &&
    seg.dots.every((d) => Number.isInteger(d) && d > 0)
  )
}

/** 有効なセグメントを startLine 昇順に並べ、重複 startLine は先勝ちで1つにする */
function normalize(dpl: DplSegment[]): DplSegment[] {
  const seen = new Set<number>()
  const out: DplSegment[] = []
  for (const seg of dpl) {
    if (!isValidSegment(seg) || seen.has(seg.startLine)) continue
    seen.add(seg.startLine)
    out.push(seg)
  }
  return out.sort((a, b) => a.startLine - b.startLine)
}

/** ライン n を支配するセグメント(startLine <= n の中で最大の startLine を持つもの) */
export function segmentForLine(dpl: DplSegment[], n: number): DplSegment | null {
  let best: DplSegment | null = null
  for (const seg of dpl) {
    if (seg.startLine <= n && (best === null || seg.startLine > best.startLine)) best = seg
  }
  return best
}

/**
 * Y=0 から順にラインを生成する。ライン n の高さは、n を支配するセグメントの dots を
 * セグメント開始からの相対位置でサイクリックに引いたもの。
 * y0 < pageHeight の間生成し、最後のラインは y1 がページ高を超えてもそのまま保持する。
 */
export function computePageLines(dpl: DplSegment[], pageHeight: number): PageLine[] {
  const segs = normalize(dpl)
  if (segs.length === 0 || segs[0].startLine !== 1 || pageHeight <= 0) return []

  const lines: PageLine[] = []
  let y = 0
  let n = 1
  let segIdx = 0
  while (y < pageHeight) {
    while (segIdx + 1 < segs.length && segs[segIdx + 1].startLine <= n) segIdx++
    const seg = segs[segIdx]
    const dots = seg.dots[(n - seg.startLine) % seg.dots.length]
    lines.push({ n, y0: y, y1: y + dots })
    y += dots
    n++
  }
  return lines
}
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/model/lines.test.ts`
Expected: 10 PASS

- [ ] **Step 5: コミット**

```bash
git add frontend/src/model/lines.ts frontend/src/model/lines.test.ts
git commit -m "feat(model): compute page lines from DPL segments

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 5: ブロック計算 computeBlockLines / blockFromRect / findOverlappingBlocks

**Files:**
- Create: `frontend/src/model/blocks.ts`
- Test: `frontend/src/model/blocks.test.ts`

**Interfaces:**
- Consumes: `Block`, `PageLine`, `BlockLine`, `Rect`(Task 3)
- Produces: `computeBlockLines(blocks: Block[], pageLines: PageLine[], pageWidth: number): BlockLine[]`、`blockFromRect(rect: Rect, pageLines: PageLine[]): Block | null`、`findOverlappingBlocks(blocks: Block[]): Set<number>`(重複しているブロックのインデックス集合)

- [ ] **Step 1: 失敗するテストを書く**

`frontend/src/model/blocks.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { blockFromRect, computeBlockLines, findOverlappingBlocks } from './blocks'
import { computePageLines } from './lines'

// 仕様の設定例: DPL,1,25 / BLOCK 0-300 1-3 / 0-150 4-11 / 150-300 4-11 / 0-300 12-14
const pageLines = computePageLines([{ startLine: 1, dots: [25] }], 350)
const blocks = [
  { startX: 0, endX: 300, startLine: 1, endLine: 3 },
  { startX: 0, endX: 150, startLine: 4, endLine: 11 },
  { startX: 150, endX: 300, startLine: 4, endLine: 11 },
  { startX: 0, endX: 300, startLine: 12, endLine: 14 },
]

describe('computeBlockLines', () => {
  it('ブロック未指定ならページ全体を1ブロックとする', () => {
    const out = computeBlockLines([], pageLines, 300)
    expect(out).toHaveLength(14)
    expect(out[0]).toEqual({ n: 1, blockIndex: 0, x0: 0, x1: 300, y0: 0, y1: 25 })
  })

  it('仕様の4ブロック例で通し番号 1..22 になる', () => {
    const out = computeBlockLines(blocks, pageLines, 300)
    expect(out).toHaveLength(22)
    expect(out[3]).toEqual({ n: 4, blockIndex: 1, x0: 0, x1: 150, y0: 75, y1: 100 })
    expect(out[11]).toEqual({ n: 12, blockIndex: 2, x0: 150, x1: 300, y0: 75, y1: 100 })
    expect(out[19]).toEqual({ n: 20, blockIndex: 3, x0: 0, x1: 300, y0: 275, y1: 300 })
    expect(out[21].n).toBe(22)
  })

  it('ページラインの範囲外は切り捨てる', () => {
    const out = computeBlockLines([{ startX: 0, endX: 100, startLine: 13, endLine: 20 }], pageLines, 300)
    expect(out.map((l) => l.y0)).toEqual([300, 325])
  })
})

describe('blockFromRect', () => {
  it('Yはドラッグ範囲に掛かるラインの先頭/最終にスナップし、Xは正規化する', () => {
    const b = blockFromRect({ x0: 120, y0: 80, x1: 10, y1: 130 }, pageLines)
    expect(b).toEqual({ startX: 10, endX: 120, startLine: 4, endLine: 6 })
  })

  it('ラインに掛からない、または幅0なら null', () => {
    expect(blockFromRect({ x0: 0, y0: 400, x1: 10, y1: 410 }, pageLines)).toBeNull()
    expect(blockFromRect({ x0: 5, y0: 0, x1: 5, y1: 10 }, pageLines)).toBeNull()
  })
})

describe('findOverlappingBlocks', () => {
  it('重複がなければ空', () => {
    expect(findOverlappingBlocks(blocks).size).toBe(0)
  })

  it('X区間とライン区間の両方が交差するブロック同士を返す', () => {
    const set = findOverlappingBlocks([
      ...blocks,
      { startX: 100, endX: 200, startLine: 10, endLine: 12 },
    ])
    expect([...set].sort()).toEqual([1, 2, 3, 4])
  })

  it('辺を共有するだけなら重複ではない', () => {
    const set = findOverlappingBlocks([
      { startX: 0, endX: 150, startLine: 1, endLine: 3 },
      { startX: 150, endX: 300, startLine: 1, endLine: 3 },
    ])
    expect(set.size).toBe(0)
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/model/blocks.test.ts`
Expected: FAIL — `Failed to resolve import "./blocks"`

- [ ] **Step 3: blocks.ts を実装する**

`frontend/src/model/blocks.ts`:

```ts
import type { Block, BlockLine, PageLine, Rect } from './types'

/**
 * ブロック順にページラインを切り出し、通し番号を 1 から振り直す。
 * ブロック未指定ならページ全体を1ブロックとみなす。
 */
export function computeBlockLines(
  blocks: Block[],
  pageLines: PageLine[],
  pageWidth: number,
): BlockLine[] {
  if (blocks.length === 0) {
    return pageLines.map((l) => ({ n: l.n, blockIndex: 0, x0: 0, x1: pageWidth, y0: l.y0, y1: l.y1 }))
  }
  const out: BlockLine[] = []
  let n = 1
  blocks.forEach((b, blockIndex) => {
    for (const l of pageLines) {
      if (l.n < b.startLine || l.n > b.endLine) continue
      out.push({ n: n++, blockIndex, x0: b.startX, x1: b.endX, y0: l.y0, y1: l.y1 })
    }
  })
  return out
}

/** ドラッグ矩形からブロックを作る。Yはラインにスナップ。ラインに掛からない/幅0なら null */
export function blockFromRect(rect: Rect, pageLines: PageLine[]): Block | null {
  const startX = Math.min(rect.x0, rect.x1)
  const endX = Math.max(rect.x0, rect.x1)
  const y0 = Math.min(rect.y0, rect.y1)
  const y1 = Math.max(rect.y0, rect.y1)
  if (startX === endX) return null
  const hit = pageLines.filter((l) => l.y1 > y0 && l.y0 < y1)
  if (hit.length === 0) return null
  return { startX, endX, startLine: hit[0].n, endLine: hit[hit.length - 1].n }
}

function overlaps(a: Block, b: Block): boolean {
  return (
    a.startX < b.endX && b.startX < a.endX && a.startLine <= b.endLine && b.startLine <= a.endLine
  )
}

/** 他のブロックと矩形が重複しているブロックのインデックス集合 */
export function findOverlappingBlocks(blocks: Block[]): Set<number> {
  const result = new Set<number>()
  for (let i = 0; i < blocks.length; i++) {
    for (let j = i + 1; j < blocks.length; j++) {
      if (overlaps(blocks[i], blocks[j])) {
        result.add(i)
        result.add(j)
      }
    }
  }
  return result
}
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/model/blocks.test.ts`
Expected: 8 PASS

- [ ] **Step 5: コミット**

```bash
git add frontend/src/model/blocks.ts frontend/src/model/blocks.test.ts
git commit -m "feat(model): compute block lines, snap drag rect to block, detect overlaps

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 6: パラグラフ解決 resolveParagraphs

**Files:**
- Create: `frontend/src/model/paragraphs.ts`
- Test: `frontend/src/model/paragraphs.test.ts`

**Interfaces:**
- Consumes: `Paragraph`, `BlockLine`, `Rect`, `ResolvedParagraph`, `newParagraph()`(Task 3)
- Produces: `resolveParagraphs(paragraphs: Paragraph[], blockLines: BlockLine[]): ResolvedParagraph[]`、`paragraphDisplayName(p: Paragraph, index: number): string`

- [ ] **Step 1: 失敗するテストを書く**

`frontend/src/model/paragraphs.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { computeBlockLines } from './blocks'
import { computePageLines } from './lines'
import { paragraphDisplayName, resolveParagraphs } from './paragraphs'
import { newParagraph, type Paragraph } from './types'

// 4ブロック例。通し番号 1..22。ブロック2 = 4..11 (x 0-150)、ブロック3 = 12..19 (x 150-300)
const pageLines = computePageLines([{ startLine: 1, dots: [25] }], 350)
const blockLines = computeBlockLines(
  [
    { startX: 0, endX: 300, startLine: 1, endLine: 3 },
    { startX: 0, endX: 150, startLine: 4, endLine: 11 },
    { startX: 150, endX: 300, startLine: 4, endLine: 11 },
    { startX: 0, endX: 300, startLine: 12, endLine: 14 },
  ],
  pageLines,
  300,
)

function para(patch: Partial<Paragraph>): Paragraph {
  return { ...newParagraph(), ...patch, div: { ...newParagraph().div, startX: 20, endX: 80 } }
}

describe('resolveParagraphs', () => {
  it('未指定はページ全体(1..N)', () => {
    const [r] = resolveParagraphs([para({})], blockLines)
    expect(r.first).toBe(1)
    expect(r.last).toBe(22)
    expect(r.error).toBeUndefined()
    expect(r.name).toBe('Paragraph1')
  })

  it('開始/終了を親内の相対で解決し、ブロックごとに矩形をまとめる', () => {
    const [r] = resolveParagraphs([para({ startLine: 10, endLine: { kind: 'abs', n: 13 } })], blockLines)
    expect(r.first).toBe(10)
    expect(r.last).toBe(13)
    expect(r.rects).toEqual([
      { x0: 0, y0: 225, x1: 150, y1: 275 },
      { x0: 150, y0: 75, x1: 300, y1: 125 },
    ])
    expect(r.divRects).toEqual([
      { x0: 20, y0: 225, x1: 80, y1: 275 },
      { x0: 20, y0: 75, x1: 80, y1: 125 },
    ])
  })

  it('E<n> は親の最終ラインからの相対', () => {
    const [r] = resolveParagraphs([para({ endLine: { kind: 'fromEnd', n: 3 } })], blockLines)
    expect(r.last).toBe(20)
  })

  it('子は親の解決結果を基準にする', () => {
    const [, child] = resolveParagraphs(
      [
        para({ startLine: 4, endLine: { kind: 'abs', n: 11 } }),
        para({ startLine: 2, endLine: { kind: 'fromEnd', n: 1 }, name: '子' }),
      ],
      blockLines,
    )
    expect(child.first).toBe(5)
    expect(child.last).toBe(11)
    expect(child.name).toBe('子')
  })

  it('親をはみ出す/逆転はエラーを付けてクリップし、次の親にはクリップ結果を使う', () => {
    const [r, child] = resolveParagraphs(
      [
        para({ startLine: 20, endLine: { kind: 'abs', n: 30 } }),
        para({ startLine: 1, endLine: { kind: 'abs', n: 10 } }),
      ],
      blockLines,
    )
    expect(r.error).toBeDefined()
    expect(r.first).toBe(20)
    expect(r.last).toBe(22)
    expect(child.error).toBeDefined()
    expect(child.first).toBe(20)
    expect(child.last).toBe(22)

    const [inv] = resolveParagraphs([para({ startLine: 5, endLine: { kind: 'abs', n: 3 } })], blockLines)
    expect(inv.error).toBeDefined()
    expect(inv.rects).toEqual([])
  })

  it('ブロックラインが無ければ全てエラーで矩形なし', () => {
    const [r] = resolveParagraphs([para({})], [])
    expect(r.error).toBeDefined()
    expect(r.rects).toEqual([])
  })
})

describe('paragraphDisplayName', () => {
  it('空なら Paragraph<n>', () => {
    expect(paragraphDisplayName(para({}), 0)).toBe('Paragraph1')
    expect(paragraphDisplayName(para({ name: '明細' }), 3)).toBe('明細')
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/model/paragraphs.test.ts`
Expected: FAIL — `Failed to resolve import "./paragraphs"`

- [ ] **Step 3: paragraphs.ts を実装する**

`frontend/src/model/paragraphs.ts`:

```ts
import type { BlockLine, Paragraph, Rect, ResolvedParagraph } from './types'

export function paragraphDisplayName(p: Paragraph, index: number): string {
  return p.name.trim() === '' ? `Paragraph${index + 1}` : p.name
}

/** first..last のブロックラインを、blockIndex が連続する区間ごとに1矩形にまとめる */
function rectsForRange(blockLines: BlockLine[], first: number, last: number): Rect[] {
  const rects: Rect[] = []
  let cur: { blockIndex: number; rect: Rect } | null = null
  for (const l of blockLines) {
    if (l.n < first || l.n > last) continue
    if (cur && cur.blockIndex === l.blockIndex) {
      cur.rect.y1 = l.y1
    } else {
      cur = { blockIndex: l.blockIndex, rect: { x0: l.x0, y0: l.y0, x1: l.x1, y1: l.y1 } }
      rects.push(cur.rect)
    }
  }
  return rects
}

/**
 * paragraphs の配列順を親→子→孫として、各パラグラフの行範囲を解決する。
 * 最上位の親は 1..blockLines.length。範囲がはみ出す/逆転する場合は error を付け、
 * 親範囲でクリップした結果を次のパラグラフの親として使う。
 */
export function resolveParagraphs(
  paragraphs: Paragraph[],
  blockLines: BlockLine[],
): ResolvedParagraph[] {
  const out: ResolvedParagraph[] = []
  let parentFirst = 1
  let parentLast = blockLines.length

  paragraphs.forEach((p, index) => {
    const first = parentFirst + (p.startLine ?? 1) - 1
    let last: number
    if (p.endLine === null) last = parentLast
    else if (p.endLine.kind === 'abs') last = parentFirst + p.endLine.n - 1
    else last = parentLast - p.endLine.n + 1

    let error: string | undefined
    if (parentLast < parentFirst) {
      error = 'ラインが定義されていません'
    } else if (first > last) {
      error = `開始ライン(${first})が終了ライン(${last})より後です`
    } else if (first < parentFirst || last > parentLast) {
      error = `範囲 ${first}〜${last} が親の範囲 ${parentFirst}〜${parentLast} をはみ出しています`
    }

    const clampedFirst = Math.max(parentFirst, Math.min(first, parentLast))
    const clampedLast = Math.max(parentFirst, Math.min(last, parentLast))
    const empty = parentLast < parentFirst || clampedFirst > clampedLast
    const rects = empty ? [] : rectsForRange(blockLines, clampedFirst, clampedLast)
    const divRects = rects.map((r) => ({ ...r, x0: p.div.startX, x1: p.div.endX }))

    out.push({
      index,
      name: paragraphDisplayName(p, index),
      first: clampedFirst,
      last: clampedLast,
      rects,
      divRects,
      ...(error !== undefined ? { error } : {}),
    })

    parentFirst = clampedFirst
    parentLast = empty ? clampedFirst - 1 : clampedLast
  })
  return out
}
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/model/paragraphs.test.ts`
Expected: 7 PASS

- [ ] **Step 5: コミット**

```bash
git add frontend/src/model/paragraphs.ts frontend/src/model/paragraphs.test.ts
git commit -m "feat(model): resolve nested paragraph ranges into block rects

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 7: 検証 validate

**Files:**
- Create: `frontend/src/model/validate.ts`
- Test: `frontend/src/model/validate.test.ts`

**Interfaces:**
- Consumes: `findOverlappingBlocks`(Task 5)、`resolveParagraphs`(Task 6)、型(Task 3)
- Produces: `validate(def: FormDefinition, pageLines: PageLine[], blockLines: BlockLine[]): ValidationError[]`

- [ ] **Step 1: 失敗するテストを書く**

`frontend/src/model/validate.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { computeBlockLines } from './blocks'
import { computePageLines } from './lines'
import { emptyDefinition, newParagraph, type FormDefinition } from './types'
import { validate } from './validate'

function run(def: FormDefinition) {
  const pageLines = computePageLines(def.dpl, 350)
  const blockLines = computeBlockLines(def.blocks, pageLines, 300)
  return validate(def, pageLines, blockLines)
}

const dpl25 = [{ startLine: 1, dots: [25] }]

describe('validate: DPL', () => {
  it('空の定義はエラーなし', () => {
    expect(run(emptyDefinition())).toEqual([])
  })

  it('開始ライン1が無い', () => {
    const errs = run({ ...emptyDefinition(), dpl: [{ startLine: 2, dots: [10] }] })
    expect(errs).toContainEqual({ target: 'dpl', index: null, message: '開始ライン1のDPLが必要です' })
  })

  it('開始ライン重複、開始ライン<1、dots不正', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: [
        { startLine: 1, dots: [10] },
        { startLine: 1, dots: [20] },
        { startLine: 0, dots: [5] },
        { startLine: 3, dots: [] },
        { startLine: 4, dots: [0, 5] },
      ],
    })
    expect(errs.map((e) => [e.target, e.index])).toEqual([
      ['dpl', 1],
      ['dpl', 2],
      ['dpl', 3],
      ['dpl', 4],
    ])
  })
})

describe('validate: BLOCK', () => {
  it('DPL未定義', () => {
    const errs = run({ ...emptyDefinition(), blocks: [{ startX: 0, endX: 10, startLine: 1, endLine: 2 }] })
    expect(errs).toEqual([{ target: 'block', index: 0, message: 'ブロックを定義するにはライン定義が必要です' }])
  })

  it('X逆転、ライン逆転、ライン範囲外', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      blocks: [
        { startX: 10, endX: 10, startLine: 1, endLine: 2 },
        { startX: 0, endX: 10, startLine: 3, endLine: 2 },
        { startX: 20, endX: 30, startLine: 13, endLine: 15 },
        { startX: 40, endX: 50, startLine: 0, endLine: 1 },
      ],
    })
    expect(errs.map((e) => e.index)).toEqual([0, 1, 2, 3])
    expect(errs[2].message).toContain('14')
  })

  it('重複は両方にエラー', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      blocks: [
        { startX: 0, endX: 200, startLine: 1, endLine: 5 },
        { startX: 100, endX: 300, startLine: 5, endLine: 8 },
        { startX: 0, endX: 300, startLine: 9, endLine: 14 },
      ],
    })
    expect(errs.map((e) => e.index)).toEqual([0, 1])
    expect(errs[0].message).toContain('重複')
  })
})

describe('validate: PARAGRAPH', () => {
  function p(patch: object) {
    const base = newParagraph()
    return { ...base, div: { ...base.div, startX: 10, endX: 50 }, ...patch }
  }

  it('DPL未定義', () => {
    const errs = run({ ...emptyDefinition(), paragraphs: [p({})] })
    expect(errs).toEqual([
      { target: 'paragraph', index: 0, message: 'パラグラフを定義するにはライン定義が必要です' },
    ])
  })

  it('DIVのX逆転、開始ライン<1、終了ライン<1', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [
        p({ div: { value: '', cond: 'M', startX: 50, endX: 50, sameContinue: null } }),
        p({ startLine: 0 }),
        p({ endLine: { kind: 'fromEnd', n: 0 } }),
      ],
    })
    expect(errs.map((e) => e.index)).toEqual([0, 1, 2])
  })

  it('解決後の範囲が親をはみ出す', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [p({ startLine: 1, endLine: { kind: 'abs', n: 5 } }), p({ startLine: 3, endLine: { kind: 'abs', n: 9 } })],
    })
    expect(errs).toHaveLength(1)
    expect(errs[0].index).toBe(1)
    expect(errs[0].message).toContain('はみ出し')
  })

  it('正しい定義はエラーなし', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [p({ startLine: 1, endLine: { kind: 'fromEnd', n: 1 }, name: '支店' })],
    })
    expect(errs).toEqual([])
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/model/validate.test.ts`
Expected: FAIL — `Failed to resolve import "./validate"`

- [ ] **Step 3: validate.ts を実装する**

`frontend/src/model/validate.ts`:

```ts
import { findOverlappingBlocks } from './blocks'
import { resolveParagraphs } from './paragraphs'
import type { BlockLine, FormDefinition, PageLine, ValidationError } from './types'

function validateDpl(def: FormDefinition): ValidationError[] {
  const errs: ValidationError[] = []
  if (def.dpl.length === 0) return errs
  if (!def.dpl.some((s) => s.startLine === 1)) {
    errs.push({ target: 'dpl', index: null, message: '開始ライン1のDPLが必要です' })
  }
  const seen = new Set<number>()
  def.dpl.forEach((s, i) => {
    if (!Number.isInteger(s.startLine) || s.startLine < 1) {
      errs.push({ target: 'dpl', index: i, message: '開始ラインは1以上の整数で指定してください' })
    } else if (seen.has(s.startLine)) {
      errs.push({ target: 'dpl', index: i, message: `開始ライン${s.startLine}が重複しています` })
    } else {
      seen.add(s.startLine)
    }
    if (s.dots.length === 0 || !s.dots.every((d) => Number.isInteger(d) && d > 0)) {
      errs.push({ target: 'dpl', index: i, message: 'ドット数は1以上の整数をカンマ区切りで指定してください' })
    }
  })
  return errs
}

function validateBlocks(def: FormDefinition, pageLines: PageLine[]): ValidationError[] {
  const errs: ValidationError[] = []
  if (def.blocks.length === 0) return errs
  if (pageLines.length === 0) {
    def.blocks.forEach((_, i) =>
      errs.push({ target: 'block', index: i, message: 'ブロックを定義するにはライン定義が必要です' }),
    )
    return errs
  }
  const maxLine = pageLines.length
  const overlapping = findOverlappingBlocks(def.blocks)
  def.blocks.forEach((b, i) => {
    if (b.startX >= b.endX) {
      errs.push({ target: 'block', index: i, message: '開始Xは終了Xより小さくしてください' })
    }
    if (b.startLine > b.endLine) {
      errs.push({ target: 'block', index: i, message: '開始ラインは終了ライン以下にしてください' })
    } else if (b.startLine < 1 || b.endLine > maxLine) {
      errs.push({ target: 'block', index: i, message: `ライン範囲は1〜${maxLine}の中で指定してください` })
    }
    if (overlapping.has(i)) {
      errs.push({ target: 'block', index: i, message: '他のブロックと矩形が重複しています' })
    }
  })
  return errs
}

function validateParagraphs(def: FormDefinition, blockLines: BlockLine[]): ValidationError[] {
  const errs: ValidationError[] = []
  if (def.paragraphs.length === 0) return errs
  if (blockLines.length === 0) {
    def.paragraphs.forEach((_, i) =>
      errs.push({ target: 'paragraph', index: i, message: 'パラグラフを定義するにはライン定義が必要です' }),
    )
    return errs
  }
  const resolved = resolveParagraphs(def.paragraphs, blockLines)
  def.paragraphs.forEach((p, i) => {
    if (p.div.startX >= p.div.endX) {
      errs.push({ target: 'paragraph', index: i, message: 'DIVの開始Xは終了Xより小さくしてください' })
    }
    // 開始/終了ラインの値そのものが不正なら、解決エラーは重複になるので出さない
    let lineFieldsValid = true
    if (p.startLine !== null && (!Number.isInteger(p.startLine) || p.startLine < 1)) {
      lineFieldsValid = false
      errs.push({ target: 'paragraph', index: i, message: '開始ラインは1以上の整数で指定してください' })
    }
    if (p.endLine !== null && (!Number.isInteger(p.endLine.n) || p.endLine.n < 1)) {
      lineFieldsValid = false
      errs.push({ target: 'paragraph', index: i, message: '終了ラインは1以上の整数(またはE<n>)で指定してください' })
    }
    const r = resolved[i]
    if (lineFieldsValid && r.error !== undefined) {
      errs.push({ target: 'paragraph', index: i, message: r.error })
    }
  })
  return errs
}

/** 定義全体の不整合を列挙する。空配列ならダウンロード可能 */
export function validate(
  def: FormDefinition,
  pageLines: PageLine[],
  blockLines: BlockLine[],
): ValidationError[] {
  return [...validateDpl(def), ...validateBlocks(def, pageLines), ...validateParagraphs(def, blockLines)]
}
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/model/validate.test.ts`
Expected: 10 PASS

「解決後の範囲が親をはみ出す」テストは、親 1..5 に対して子 3..9 なので子だけがエラーになる。テストが `errs.length === 1` で失敗したら、`validateParagraphs` がDIV/開始/終了の条件を誤って重複計上していないか確認する。

- [ ] **Step 5: コミット**

```bash
git add frontend/src/model/validate.ts frontend/src/model/validate.test.ts
git commit -m "feat(model): validate DPL, block and paragraph definitions

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 8: テキスト生成 serialize

**Files:**
- Create: `frontend/src/model/serialize.ts`
- Test: `frontend/src/model/serialize.test.ts`

**Interfaces:**
- Consumes: `FormDefinition`, `newParagraph()`(Task 3)、`formatLineRef`(Task 3)
- Produces: `serialize(def: FormDefinition): string`

- [ ] **Step 1: 失敗するテストを書く**

`frontend/src/model/serialize.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { serialize } from './serialize'
import { emptyDefinition, newParagraph } from './types'

describe('serialize', () => {
  it('空の定義は空文字', () => {
    expect(serialize(emptyDefinition())).toBe('')
  })

  it('仕様の例をそのまま再現する', () => {
    const text = serialize({
      dpl: [
        { startLine: 1, dots: [80] },
        { startLine: 20, dots: [85] },
      ],
      blocks: [
        { startX: 0, endX: 150, startLine: 4, endLine: 11 },
        { startX: 150, endX: 300, startLine: 4, endLine: 11 },
      ],
      paragraphs: [
        {
          startLine: 1,
          endLine: { kind: 'abs', n: 10 },
          name: '支店',
          spanPage: false,
          div: { value: '支店', cond: 'A', startX: 200, endX: 500, sameContinue: 'N' },
          delBackwardSpace: true,
        },
      ],
    })
    expect(text).toBe(
      [
        '# ライン定義',
        'DPL,1,80,',
        'DPL,20,85,',
        '',
        '# ブロック定義',
        'BLOCK,0,150,4,11,',
        'BLOCK,150,300,4,11,',
        '',
        '# パラグラフ定義',
        'PARAGRAPH,1,10,支店,N,',
        'DIV,KEY,支店,A,200,500,N,',
        'DEL_BACKWARD_SPACE,Y,',
        '',
      ].join('\n'),
    )
  })

  it('サイクリックな dots はカンマで並べる', () => {
    expect(serialize({ ...emptyDefinition(), dpl: [{ startLine: 17, dots: [23, 22] }] })).toBe(
      '# ライン定義\nDPL,17,23,22,\n',
    )
  })

  it('未指定欄は空、E<n> は E 付き、DEL_BACKWARD_SPACE は真のときだけ', () => {
    const p = newParagraph()
    p.endLine = { kind: 'fromEnd', n: 1 }
    p.div.startX = 100
    p.div.endX = 900
    const text = serialize({ ...emptyDefinition(), paragraphs: [p] })
    expect(text).toBe('# パラグラフ定義\nPARAGRAPH,,E1,,N,\nDIV,KEY,,M,100,900,,\n')
  })

  it('空のセクションは見出しごと省略する', () => {
    const text = serialize({ ...emptyDefinition(), blocks: [{ startX: 0, endX: 10, startLine: 1, endLine: 2 }] })
    expect(text).toBe('# ブロック定義\nBLOCK,0,10,1,2,\n')
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/model/serialize.test.ts`
Expected: FAIL — `Failed to resolve import "./serialize"`

- [ ] **Step 3: serialize.ts を実装する**

`frontend/src/model/serialize.ts`:

```ts
import { formatLineRef } from './parse'
import type { FormDefinition } from './types'

/**
 * フォーム定義テキストを生成する。各行末に `,`、セクションは空行で区切り、
 * 空のセクションは省略。末尾は改行1つ。定義が空なら空文字。
 */
export function serialize(def: FormDefinition): string {
  const sections: string[][] = []

  if (def.dpl.length > 0) {
    sections.push(['# ライン定義', ...def.dpl.map((s) => `DPL,${s.startLine},${s.dots.join(',')},`)])
  }

  if (def.blocks.length > 0) {
    sections.push([
      '# ブロック定義',
      ...def.blocks.map((b) => `BLOCK,${b.startX},${b.endX},${b.startLine},${b.endLine},`),
    ])
  }

  if (def.paragraphs.length > 0) {
    const lines = ['# パラグラフ定義']
    for (const p of def.paragraphs) {
      lines.push(
        `PARAGRAPH,${p.startLine ?? ''},${formatLineRef(p.endLine)},${p.name},${p.spanPage ? 'Y' : 'N'},`,
      )
      lines.push(
        `DIV,KEY,${p.div.value},${p.div.cond},${p.div.startX},${p.div.endX},${p.div.sameContinue ?? ''},`,
      )
      if (p.delBackwardSpace) lines.push('DEL_BACKWARD_SPACE,Y,')
    }
    sections.push(lines)
  }

  if (sections.length === 0) return ''
  return sections.map((s) => s.join('\n')).join('\n\n') + '\n'
}
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/model/serialize.test.ts`
Expected: 5 PASS

- [ ] **Step 5: コミット**

```bash
git add frontend/src/model/serialize.ts frontend/src/model/serialize.test.ts
git commit -m "feat(model): serialize definition to form definition text

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 9: APIクライアント、ダウンロード、Piniaストア

**Files:**
- Create: `frontend/src/api/documents.ts`, `frontend/src/utils/download.ts`, `frontend/src/stores/definition.ts`
- Test: `frontend/src/stores/definition.test.ts`

**Interfaces:**
- Consumes: Task 3〜8 の全関数
- Produces:
  - `uploadDocument(file: File, dpi: number): Promise<DocumentResponse>`、`pageImageUrl(id: string, n: number): string`、`interface DocumentResponse { id: string; page_count: number; pages: { width: number; height: number }[] }`
  - `downloadText(fileName: string, text: string): void`
  - `useDefinitionStore()` — state: `document: DocumentInfo | null`(`{ id, fileName, pageCount, pages }`)、`currentPage: number`、`zoom: number | 'fit'`、`definition: FormDefinition`、`activeTab: EditorTab`(`'lines' | 'blocks' | 'paragraphs'`)、`selectedBlock: number | null`、`selectedParagraph: number | null`。getters: `pageSize`、`pageLines`、`blockLines`、`resolvedParagraphs`、`errors`、`outputText`、`isDefinitionEmpty`、`canDownload`。actions: `setDocument(info)`、`clearDefinition()`、`setPage(n)`、`addDplSegment()`、`addDplSegmentAtLine(n)`、`updateDplSegment(i, patch)`、`removeDplSegment(i)`、`addBlock(b)`、`addBlockFromRect(rect)`、`updateBlock(i, patch)`、`removeBlock(i)`、`moveBlock(i, dir)`、`addParagraph()`、`updateParagraph(i, patch)`、`updateDiv(i, patch)`、`setDivRange(i, x0, x1)`、`removeParagraph(i)`、`moveParagraph(i, dir)`

- [ ] **Step 1: APIクライアントとダウンロードを書く(テストはストア経由・手動)**

`frontend/src/api/documents.ts`:

```ts
export interface DocumentResponse {
  id: string
  page_count: number
  pages: { width: number; height: number }[]
}

async function errorMessage(res: Response): Promise<string> {
  try {
    const body = (await res.json()) as { detail?: unknown }
    if (typeof body.detail === 'string') return body.detail
  } catch {
    // 本文がJSONでない
  }
  return `サーバーエラー (${res.status})`
}

export async function uploadDocument(file: File, dpi: number): Promise<DocumentResponse> {
  const form = new FormData()
  form.append('file', file)
  form.append('dpi', String(dpi))
  let res: Response
  try {
    res = await fetch('/api/documents', { method: 'POST', body: form })
  } catch {
    throw new Error('サーバーに接続できません')
  }
  if (!res.ok) throw new Error(await errorMessage(res))
  return (await res.json()) as DocumentResponse
}

export function pageImageUrl(id: string, n: number): string {
  return `/api/documents/${id}/pages/${n}`
}
```

`frontend/src/utils/download.ts`:

```ts
/** UTF-8 テキストをブラウザのダウンロードとして保存する */
export function downloadText(fileName: string, text: string): void {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}
```

- [ ] **Step 2: ストアの失敗するテストを書く**

`frontend/src/stores/definition.test.ts`:

```ts
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from './definition'

function loadDoc(store: ReturnType<typeof useDefinitionStore>) {
  store.setDocument({
    id: 'doc1',
    fileName: 'sample.pdf',
    pageCount: 2,
    pages: [
      { width: 300, height: 350 },
      { width: 300, height: 350 },
    ],
  })
}

describe('useDefinitionStore', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('初期状態はドキュメントなし、定義は空、ダウンロード不可', () => {
    const store = useDefinitionStore()
    expect(store.document).toBeNull()
    expect(store.isDefinitionEmpty).toBe(true)
    expect(store.pageLines).toEqual([])
    expect(store.canDownload).toBe(false)
  })

  it('setDocument は定義をクリアしてページを1に戻す', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.setPage(2)
    loadDoc(store)
    expect(store.definition.dpl).toEqual([])
    expect(store.currentPage).toBe(1)
    expect(store.pageSize).toEqual({ width: 300, height: 350 })
  })

  it('addDplSegment は最初は startLine 1 / dots [80]、以降は最大 startLine+1 と直前の dots', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    expect(store.definition.dpl).toEqual([{ startLine: 1, dots: [80] }])
    store.updateDplSegment(0, { dots: [25] })
    store.addDplSegment()
    expect(store.definition.dpl[1]).toEqual({ startLine: 2, dots: [25] })
    expect(store.pageLines).toHaveLength(14)
  })

  it('addDplSegmentAtLine は同じ startLine があれば追加しない', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.addDplSegmentAtLine(5)
    store.addDplSegmentAtLine(5)
    expect(store.definition.dpl.map((s) => s.startLine)).toEqual([1, 5])
    expect(store.definition.dpl[1].dots).toEqual([80])
  })

  it('addBlockFromRect はラインにスナップし、選択状態にする', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.updateDplSegment(0, { dots: [25] })
    store.addBlockFromRect({ x0: 0, y0: 80, x1: 150, y1: 130 })
    expect(store.definition.blocks).toEqual([{ startX: 0, endX: 150, startLine: 4, endLine: 6 }])
    expect(store.selectedBlock).toBe(0)
    expect(store.blockLines).toHaveLength(3)
  })

  it('moveBlock で順序を入れ替え、選択も追従する', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 })
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 })
    store.selectedBlock = 1
    store.moveBlock(1, -1)
    expect(store.definition.blocks[0].startX).toBe(20)
    expect(store.selectedBlock).toBe(0)
    store.moveBlock(0, -1)
    expect(store.definition.blocks[0].startX).toBe(20)
  })

  it('removeBlock 後に選択が範囲外なら null', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 })
    store.selectedBlock = 0
    store.removeBlock(0)
    expect(store.selectedBlock).toBeNull()
  })

  it('addParagraph / setDivRange / updateDiv', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.addParagraph()
    expect(store.selectedParagraph).toBe(0)
    store.setDivRange(0, 300, 100)
    expect(store.definition.paragraphs[0].div).toMatchObject({ startX: 100, endX: 300 })
    store.updateDiv(0, { cond: 'F', value: '本店' })
    expect(store.definition.paragraphs[0].div.cond).toBe('F')
    store.updateParagraph(0, { endLine: { kind: 'fromEnd', n: 1 }, name: '店' })
    expect(store.outputText).toContain('PARAGRAPH,,E1,店,N,')
    expect(store.resolvedParagraphs[0].name).toBe('店')
  })

  it('エラーがあれば canDownload は false、解消すれば true', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.addBlock({ startX: 10, endX: 5, startLine: 1, endLine: 1 })
    expect(store.errors).toHaveLength(1)
    expect(store.canDownload).toBe(false)
    store.updateBlock(0, { endX: 20 })
    expect(store.errors).toEqual([])
    expect(store.canDownload).toBe(true)
  })

  it('ドキュメントが無いときは定義があっても canDownload は false', () => {
    const store = useDefinitionStore()
    store.addDplSegment()
    expect(store.canDownload).toBe(false)
  })
})
```

- [ ] **Step 3: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/stores/definition.test.ts`
Expected: FAIL — `Failed to resolve import "./definition"`

- [ ] **Step 4: ストアを実装する**

`frontend/src/stores/definition.ts`:

```ts
import { defineStore } from 'pinia'
import { computed, reactive, ref } from 'vue'
import { blockFromRect, computeBlockLines } from '../model/blocks'
import { computePageLines, segmentForLine } from '../model/lines'
import { resolveParagraphs } from '../model/paragraphs'
import { serialize } from '../model/serialize'
import {
  emptyDefinition,
  newParagraph,
  type Block,
  type Div,
  type DplSegment,
  type FormDefinition,
  type Paragraph,
  type Rect,
} from '../model/types'
import { validate } from '../model/validate'

export interface DocumentInfo {
  id: string
  fileName: string
  pageCount: number
  pages: { width: number; height: number }[]
}

export type EditorTab = 'lines' | 'blocks' | 'paragraphs'

const DEFAULT_DOTS = [80]

function moveItem<T>(arr: T[], i: number, dir: -1 | 1): number {
  const j = i + dir
  if (i < 0 || i >= arr.length || j < 0 || j >= arr.length) return i
  ;[arr[i], arr[j]] = [arr[j], arr[i]]
  return j
}

export const useDefinitionStore = defineStore('definition', () => {
  const document = ref<DocumentInfo | null>(null)
  const currentPage = ref(1)
  const zoom = ref<number | 'fit'>('fit')
  const definition = reactive<FormDefinition>(emptyDefinition())
  const activeTab = ref<EditorTab>('lines')
  const selectedBlock = ref<number | null>(null)
  const selectedParagraph = ref<number | null>(null)

  const pageSize = computed(
    () => document.value?.pages[currentPage.value - 1] ?? { width: 0, height: 0 },
  )
  const pageLines = computed(() => computePageLines(definition.dpl, pageSize.value.height))
  const blockLines = computed(() =>
    computeBlockLines(definition.blocks, pageLines.value, pageSize.value.width),
  )
  const resolvedParagraphs = computed(() =>
    resolveParagraphs(definition.paragraphs, blockLines.value),
  )
  const errors = computed(() => validate(definition, pageLines.value, blockLines.value))
  const outputText = computed(() => serialize(definition))
  const isDefinitionEmpty = computed(
    () =>
      definition.dpl.length === 0 &&
      definition.blocks.length === 0 &&
      definition.paragraphs.length === 0,
  )
  const canDownload = computed(
    () => document.value !== null && !isDefinitionEmpty.value && errors.value.length === 0,
  )

  function clearDefinition() {
    definition.dpl = []
    definition.blocks = []
    definition.paragraphs = []
    selectedBlock.value = null
    selectedParagraph.value = null
  }

  function setDocument(info: DocumentInfo) {
    document.value = info
    currentPage.value = 1
    clearDefinition()
  }

  function setPage(n: number) {
    const count = document.value?.pageCount ?? 0
    if (n >= 1 && n <= count) currentPage.value = n
  }

  // ---- DPL ----
  function addDplSegment() {
    const last = definition.dpl[definition.dpl.length - 1]
    const maxStart = definition.dpl.reduce((m, s) => Math.max(m, s.startLine), 0)
    definition.dpl.push({
      startLine: maxStart + 1,
      dots: last ? [...last.dots] : [...DEFAULT_DOTS],
    })
  }

  function addDplSegmentAtLine(n: number) {
    if (definition.dpl.some((s) => s.startLine === n)) return
    const governing = segmentForLine(definition.dpl, n)
    definition.dpl.push({ startLine: n, dots: governing ? [...governing.dots] : [...DEFAULT_DOTS] })
  }

  function updateDplSegment(i: number, patch: Partial<DplSegment>) {
    Object.assign(definition.dpl[i], patch)
  }

  function removeDplSegment(i: number) {
    definition.dpl.splice(i, 1)
  }

  // ---- BLOCK ----
  function addBlock(b: Block) {
    definition.blocks.push({ ...b })
    selectedBlock.value = definition.blocks.length - 1
  }

  function addBlockFromRect(rect: Rect) {
    const b = blockFromRect(rect, pageLines.value)
    if (b) addBlock(b)
  }

  function updateBlock(i: number, patch: Partial<Block>) {
    Object.assign(definition.blocks[i], patch)
  }

  function removeBlock(i: number) {
    definition.blocks.splice(i, 1)
    if (selectedBlock.value !== null && selectedBlock.value >= definition.blocks.length) {
      selectedBlock.value = definition.blocks.length === 0 ? null : definition.blocks.length - 1
    }
  }

  function moveBlock(i: number, dir: -1 | 1) {
    const j = moveItem(definition.blocks, i, dir)
    if (selectedBlock.value === i) selectedBlock.value = j
  }

  // ---- PARAGRAPH ----
  function addParagraph() {
    definition.paragraphs.push(newParagraph())
    selectedParagraph.value = definition.paragraphs.length - 1
  }

  function updateParagraph(i: number, patch: Partial<Omit<Paragraph, 'div'>>) {
    Object.assign(definition.paragraphs[i], patch)
  }

  function updateDiv(i: number, patch: Partial<Div>) {
    Object.assign(definition.paragraphs[i].div, patch)
  }

  function setDivRange(i: number, x0: number, x1: number) {
    const startX = Math.min(x0, x1)
    const endX = Math.max(x0, x1)
    if (startX === endX) return
    updateDiv(i, { startX, endX })
  }

  function removeParagraph(i: number) {
    definition.paragraphs.splice(i, 1)
    if (selectedParagraph.value !== null && selectedParagraph.value >= definition.paragraphs.length) {
      selectedParagraph.value =
        definition.paragraphs.length === 0 ? null : definition.paragraphs.length - 1
    }
  }

  function moveParagraph(i: number, dir: -1 | 1) {
    const j = moveItem(definition.paragraphs, i, dir)
    if (selectedParagraph.value === i) selectedParagraph.value = j
  }

  return {
    document,
    currentPage,
    zoom,
    definition,
    activeTab,
    selectedBlock,
    selectedParagraph,
    pageSize,
    pageLines,
    blockLines,
    resolvedParagraphs,
    errors,
    outputText,
    isDefinitionEmpty,
    canDownload,
    setDocument,
    clearDefinition,
    setPage,
    addDplSegment,
    addDplSegmentAtLine,
    updateDplSegment,
    removeDplSegment,
    addBlock,
    addBlockFromRect,
    updateBlock,
    removeBlock,
    moveBlock,
    addParagraph,
    updateParagraph,
    updateDiv,
    setDivRange,
    removeParagraph,
    moveParagraph,
  }
})
```

- [ ] **Step 5: テストが通ることを確認する**

Run: `cd frontend && npm test`
Expected: すべて PASS(parse / lines / blocks / paragraphs / validate / serialize / definition)

- [ ] **Step 6: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit`

```bash
git add frontend/src/api frontend/src/utils frontend/src/stores
git commit -m "feat(frontend): add API client, download helper and definition store

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 10: 画面骨格、上部バー、キャンバス(画像表示・倍率・座標表示)

**Files:**
- Modify: `frontend/src/App.vue`, `frontend/src/style.css`
- Create: `frontend/src/components/TopBar.vue`, `frontend/src/components/PageCanvas.vue`, `frontend/src/components/EditorPanel.vue`
- Test: `frontend/src/components/TopBar.test.ts`

**Interfaces:**
- Consumes: `useDefinitionStore`、`uploadDocument`、`pageImageUrl`、`downloadText`(Task 9)
- Produces: `PageCanvas` は `scale`(表示倍率)を算出し、後続タスクのオーバーレイを `<svg viewBox="0 0 W H">` の中に置く。ドラッグ/クリックは `store.activeTab` に応じて Task 11〜13 のストア操作を呼ぶ(この時点では `lines` のクリックのみ実装)。`EditorPanel` はタブ切替の器で、Task 11〜14 でパネルを差し込む。

- [ ] **Step 1: TopBar の失敗するテストを書く**

`frontend/src/components/TopBar.test.ts`:

```ts
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { useDefinitionStore } from '../stores/definition'
import TopBar from './TopBar.vue'

vi.mock('../api/documents', () => ({
  uploadDocument: vi.fn(async () => ({
    id: 'doc1',
    page_count: 3,
    pages: [
      { width: 100, height: 200 },
      { width: 100, height: 200 },
      { width: 100, height: 200 },
    ],
  })),
  pageImageUrl: (id: string, n: number) => `/api/documents/${id}/pages/${n}`,
}))

describe('TopBar', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('DPI初期値は720で、ファイル未選択なら読込ボタンは無効', () => {
    const w = mount(TopBar)
    expect((w.find('input[type="number"]').element as HTMLInputElement).value).toBe('720')
    expect((w.find('button.load').element as HTMLButtonElement).disabled).toBe(true)
  })

  it('読込成功でストアにドキュメントが入りページ数が表示される', async () => {
    const w = mount(TopBar)
    const store = useDefinitionStore()
    const input = w.find('input[type="file"]')
    const file = new File([new Uint8Array([1, 2, 3])], 'sample.pdf', { type: 'application/pdf' })
    Object.defineProperty(input.element, 'files', { value: [file] })
    await input.trigger('change')
    await w.find('button.load').trigger('click')
    await vi.waitFor(() => expect(store.document?.pageCount).toBe(3))
    expect(store.document?.fileName).toBe('sample.pdf')
    expect(w.text()).toContain('1 / 3')
  })

  it('定義がある状態で再読込するときは確認し、キャンセルなら読み込まない', async () => {
    const w = mount(TopBar)
    const store = useDefinitionStore()
    store.addDplSegment()
    vi.spyOn(window, 'confirm').mockReturnValue(false)
    const input = w.find('input[type="file"]')
    Object.defineProperty(input.element, 'files', { value: [new File([], 'a.pdf')] })
    await input.trigger('change')
    await w.find('button.load').trigger('click')
    expect(store.document).toBeNull()
    expect(store.definition.dpl).toHaveLength(1)
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/components/TopBar.test.ts`
Expected: FAIL — `Failed to resolve import "./TopBar.vue"`

- [ ] **Step 3: TopBar.vue を実装する**

`frontend/src/components/TopBar.vue`:

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { uploadDocument } from '../api/documents'
import { useDefinitionStore } from '../stores/definition'
import { downloadText } from '../utils/download'

const store = useDefinitionStore()
const file = ref<File | null>(null)
const dpi = ref(720)
const loading = ref(false)
const error = ref('')

const ZOOMS = [50, 75, 100, 150, 200]

function onFileChange(e: Event) {
  file.value = (e.target as HTMLInputElement).files?.[0] ?? null
}

async function load() {
  if (!file.value) return
  if (!store.isDefinitionEmpty && !window.confirm('現在の定義をクリアして読み込みます。よろしいですか？')) {
    return
  }
  loading.value = true
  error.value = ''
  try {
    const res = await uploadDocument(file.value, dpi.value)
    store.setDocument({
      id: res.id,
      fileName: file.value.name,
      pageCount: res.page_count,
      pages: res.pages,
    })
  } catch (e) {
    error.value = e instanceof Error ? e.message : String(e)
  } finally {
    loading.value = false
  }
}

function download() {
  const base = store.document?.fileName.replace(/\.[^.]+$/, '') ?? 'form'
  downloadText(`${base}.txt`, store.outputText)
}

function onZoomChange(e: Event) {
  const v = (e.target as HTMLSelectElement).value
  store.zoom = v === 'fit' ? 'fit' : Number(v)
}
</script>

<template>
  <header class="topbar">
    <div class="topbar__row">
      <label class="field">
        <span>PDF</span>
        <input type="file" accept="application/pdf,.pdf" @change="onFileChange">
      </label>
      <label class="field">
        <span>DPI</span>
        <input v-model.number="dpi" type="number" min="36" max="1200" step="1">
      </label>
      <button class="load" :disabled="!file || loading" @click="load">
        {{ loading ? '変換中…' : '読込' }}
      </button>

      <template v-if="store.document">
        <span class="sep" />
        <button :disabled="store.currentPage <= 1" @click="store.setPage(store.currentPage - 1)">
          ◀
        </button>
        <span class="page">{{ store.currentPage }} / {{ store.document.pageCount }}</span>
        <button
          :disabled="store.currentPage >= store.document.pageCount"
          @click="store.setPage(store.currentPage + 1)"
        >
          ▶
        </button>
        <label class="field">
          <span>倍率</span>
          <select :value="String(store.zoom)" @change="onZoomChange">
            <option value="fit">幅に合わせる</option>
            <option v-for="z in ZOOMS" :key="z" :value="String(z)">{{ z }}%</option>
          </select>
        </label>
        <span class="file">{{ store.document.fileName }}</span>
      </template>

      <span class="spacer" />
      <button class="download" :disabled="!store.canDownload" @click="download">
        定義ファイルをダウンロード
      </button>
    </div>
    <div v-if="error" class="topbar__error">{{ error }}</div>
  </header>
</template>

<style scoped>
.topbar {
  background: #fff;
  border-bottom: 1px solid #ddd;
}
.topbar__row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 12px;
  flex-wrap: wrap;
}
.field {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.field input[type='number'] {
  width: 5em;
}
.sep {
  width: 1px;
  height: 20px;
  background: #ddd;
}
.page {
  min-width: 4em;
  text-align: center;
}
.file {
  color: #666;
}
.spacer {
  flex: 1;
}
.download {
  font-weight: 600;
}
.topbar__error {
  padding: 6px 12px;
  background: #fdecea;
  color: #b3261e;
}
</style>
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/components/TopBar.test.ts`
Expected: 3 PASS

- [ ] **Step 5: PageCanvas.vue を実装する**

`frontend/src/components/PageCanvas.vue`:

```vue
<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { pageImageUrl } from '../api/documents'
import { useDefinitionStore } from '../stores/definition'
import type { Rect } from '../model/types'

const store = useDefinitionStore()
const container = ref<HTMLElement | null>(null)
const svg = ref<SVGSVGElement | null>(null)
const containerWidth = ref(0)
let observer: ResizeObserver | null = null

onMounted(() => {
  if (typeof ResizeObserver === 'undefined' || !container.value) return
  observer = new ResizeObserver((entries) => {
    containerWidth.value = entries[0].contentRect.width
  })
  observer.observe(container.value)
})
onBeforeUnmount(() => observer?.disconnect())

const imageUrl = computed(() =>
  store.document ? pageImageUrl(store.document.id, store.currentPage) : '',
)

/** 画像1pxあたりの表示px */
const scale = computed(() => {
  const w = store.pageSize.width
  if (w === 0) return 1
  if (store.zoom === 'fit') return Math.max(containerWidth.value - 24, 100) / w
  return store.zoom / 100
})
const displayWidth = computed(() => store.pageSize.width * scale.value)
const displayHeight = computed(() => store.pageSize.height * scale.value)

// ---- 座標読み取り ----
const hover = ref<{ x: number; y: number } | null>(null)

function toImage(e: MouseEvent): { x: number; y: number } {
  const r = svg.value!.getBoundingClientRect()
  return {
    x: Math.round((e.clientX - r.left) / scale.value),
    y: Math.round((e.clientY - r.top) / scale.value),
  }
}

const hoverPageLine = computed(() => {
  if (!hover.value) return null
  const y = hover.value.y
  return store.pageLines.find((l) => y >= l.y0 && y < l.y1) ?? null
})
const hoverBlockLine = computed(() => {
  if (!hover.value) return null
  const { x, y } = hover.value
  return store.blockLines.find((l) => x >= l.x0 && x < l.x1 && y >= l.y0 && y < l.y1) ?? null
})

// ---- ドラッグ / クリック ----
const dragStart = ref<{ x: number; y: number } | null>(null)
const dragCurrent = ref<{ x: number; y: number } | null>(null)
const dragRect = computed<Rect | null>(() => {
  if (!dragStart.value || !dragCurrent.value) return null
  return {
    x0: Math.min(dragStart.value.x, dragCurrent.value.x),
    y0: Math.min(dragStart.value.y, dragCurrent.value.y),
    x1: Math.max(dragStart.value.x, dragCurrent.value.x),
    y1: Math.max(dragStart.value.y, dragCurrent.value.y),
  }
})

function onMouseDown(e: MouseEvent) {
  if (e.button !== 0 || !store.document) return
  dragStart.value = toImage(e)
  dragCurrent.value = dragStart.value
}

function onMouseMove(e: MouseEvent) {
  if (!store.document) return
  const p = toImage(e)
  hover.value = p
  if (dragStart.value) dragCurrent.value = p
}

function onMouseUp(e: MouseEvent) {
  if (!dragStart.value) return
  const start = dragStart.value
  const end = toImage(e)
  dragStart.value = null
  dragCurrent.value = null
  const moved = Math.abs(end.x - start.x) >= 3 || Math.abs(end.y - start.y) >= 3
  if (moved) onDragEnd({ x0: start.x, y0: start.y, x1: end.x, y1: end.y })
  else onClick(end)
}

function onMouseLeave() {
  hover.value = null
  dragStart.value = null
  dragCurrent.value = null
}

function onClick(p: { x: number; y: number }) {
  if (store.activeTab === 'lines') {
    const line = store.pageLines.find((l) => p.y >= l.y0 && p.y < l.y1)
    if (line) store.addDplSegmentAtLine(line.n)
  }
}

function onDragEnd(rect: Rect) {
  if (store.activeTab === 'blocks') {
    store.addBlockFromRect(rect)
  } else if (store.activeTab === 'paragraphs' && store.selectedParagraph !== null) {
    store.setDivRange(store.selectedParagraph, rect.x0, rect.x1)
  }
}
</script>

<template>
  <section ref="container" class="canvas">
    <div v-if="!store.document" class="canvas__empty">PDFを選択して「読込」を押してください</div>
    <template v-else>
      <div class="canvas__readout">
        <span v-if="hover">X: {{ hover.x }} Y: {{ hover.y }}</span>
        <span v-if="hoverPageLine">ページライン: {{ hoverPageLine.n }}</span>
        <span v-if="hoverBlockLine">ブロック通し: {{ hoverBlockLine.n }}</span>
      </div>
      <div
        class="canvas__page"
        :style="{ width: displayWidth + 'px', height: displayHeight + 'px' }"
      >
        <img :src="imageUrl" :width="displayWidth" :height="displayHeight" draggable="false">
        <svg
          ref="svg"
          class="canvas__overlay"
          :viewBox="`0 0 ${store.pageSize.width} ${store.pageSize.height}`"
          :width="displayWidth"
          :height="displayHeight"
          @mousedown.prevent="onMouseDown"
          @mousemove="onMouseMove"
          @mouseup="onMouseUp"
          @mouseleave="onMouseLeave"
        >
          <slot :scale="scale" />
          <rect
            v-if="dragRect"
            class="canvas__drag"
            :x="dragRect.x0"
            :y="dragRect.y0"
            :width="dragRect.x1 - dragRect.x0"
            :height="dragRect.y1 - dragRect.y0"
            vector-effect="non-scaling-stroke"
          />
        </svg>
      </div>
    </template>
  </section>
</template>

<style scoped>
.canvas {
  position: relative;
  overflow: auto;
  padding: 12px;
  background: #e9e9e9;
}
.canvas__empty {
  color: #666;
  padding: 40px;
  text-align: center;
}
.canvas__readout {
  position: sticky;
  top: 0;
  z-index: 1;
  display: flex;
  gap: 16px;
  padding: 4px 8px;
  margin-bottom: 8px;
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid #ddd;
  font-variant-numeric: tabular-nums;
  min-height: 26px;
}
.canvas__page {
  position: relative;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
}
.canvas__page img {
  display: block;
  user-select: none;
}
.canvas__overlay {
  position: absolute;
  inset: 0;
  cursor: crosshair;
}
.canvas__drag {
  fill: rgba(30, 100, 200, 0.15);
  stroke: #1e64c8;
  stroke-width: 1;
  stroke-dasharray: 4 2;
}
</style>
```

- [ ] **Step 6: EditorPanel.vue(タブの器)と App.vue を実装する**

`frontend/src/components/EditorPanel.vue`:

```vue
<script setup lang="ts">
import { useDefinitionStore, type EditorTab } from '../stores/definition'

const store = useDefinitionStore()
const TABS: { id: EditorTab; label: string }[] = [
  { id: 'lines', label: 'ライン' },
  { id: 'blocks', label: 'ブロック' },
  { id: 'paragraphs', label: 'パラグラフ' },
]
</script>

<template>
  <aside class="panel">
    <nav class="panel__tabs">
      <button
        v-for="t in TABS"
        :key="t.id"
        :class="{ active: store.activeTab === t.id }"
        @click="store.activeTab = t.id"
      >
        {{ t.label }}
      </button>
    </nav>
    <div class="panel__body">
      <slot :name="store.activeTab" />
    </div>
    <div class="panel__footer">
      <slot name="footer" />
    </div>
  </aside>
</template>

<style scoped>
.panel {
  display: flex;
  flex-direction: column;
  background: #fff;
  border-left: 1px solid #ddd;
  min-height: 0;
}
.panel__tabs {
  display: flex;
  border-bottom: 1px solid #ddd;
}
.panel__tabs button {
  flex: 1;
  padding: 8px;
  border: 0;
  background: #f4f4f4;
  cursor: pointer;
}
.panel__tabs button.active {
  background: #fff;
  font-weight: 600;
  border-bottom: 2px solid #1e64c8;
}
.panel__body {
  flex: 1;
  overflow: auto;
  padding: 12px;
  min-height: 0;
}
.panel__footer {
  border-top: 1px solid #ddd;
  max-height: 45%;
  overflow: auto;
}
</style>
```

`frontend/src/App.vue`(Task 3 の仮実装を置き換える):

```vue
<script setup lang="ts">
import EditorPanel from './components/EditorPanel.vue'
import PageCanvas from './components/PageCanvas.vue'
import TopBar from './components/TopBar.vue'
</script>

<template>
  <div class="app">
    <TopBar class="app__top" />
    <PageCanvas class="app__canvas" />
    <EditorPanel class="app__panel" />
  </div>
</template>

<style scoped>
.app {
  display: grid;
  grid-template-rows: auto 1fr;
  grid-template-columns: 1fr 400px;
  grid-template-areas:
    'top top'
    'canvas panel';
  height: 100vh;
}
.app__top {
  grid-area: top;
}
.app__canvas {
  grid-area: canvas;
  min-height: 0;
}
.app__panel {
  grid-area: panel;
  min-height: 0;
}
</style>
```

- [ ] **Step 7: 手動確認**

Run(別ターミナルで2つ):
- `cd backend && uv run uvicorn app.main:app --port 8000`
- `cd frontend && npm run dev`

`http://localhost:5173` を開き、任意のPDFを DPI 100 程度で読込。画像が表示され、倍率切替・ページ切替・座標読み取りが動くこと。720DPI でも読めることを確認(時間がかかる)。

- [ ] **Step 8: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit && npm test`

```bash
git add frontend/src
git commit -m "feat(frontend): app layout, top bar with PDF loading, page canvas with zoom and readout

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 11: ラインタブ(パネル + オーバーレイ)

**Files:**
- Create: `frontend/src/components/panels/LinesPanel.vue`, `frontend/src/components/panels/DplSegmentRow.vue`, `frontend/src/components/overlay/LinesOverlay.vue`
- Modify: `frontend/src/App.vue`
- Test: `frontend/src/components/panels/DplSegmentRow.test.ts`

**Interfaces:**
- Consumes: `useDefinitionStore`(Task 9)、`parseDots`(Task 3)、`PageCanvas` の `scale` スロット、`EditorPanel` の `#lines` スロット(Task 10)
- Produces: `DplSegmentRow` props `{ segment: DplSegment; index: number }`、emits `update:startLine(n)`, `update:dots(dots)`, `remove()`。`LinesOverlay` props `{ scale: number; dim: boolean }`

- [ ] **Step 1: DplSegmentRow の失敗するテストを書く**

`frontend/src/components/panels/DplSegmentRow.test.ts`:

```ts
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import DplSegmentRow from './DplSegmentRow.vue'

describe('DplSegmentRow', () => {
  it('dots を "23,22" のように表示する', () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 17, dots: [23, 22] }, index: 1 } })
    expect((w.find('input.dots').element as HTMLInputElement).value).toBe('23,22')
    expect((w.find('input.start').element as HTMLInputElement).value).toBe('17')
  })

  it('有効な入力は update:dots、無効なら [] を emit し invalid クラスを付ける', async () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 1, dots: [80] }, index: 0 } })
    await w.find('input.dots').setValue('10, 20')
    expect(w.emitted('update:dots')?.at(-1)).toEqual([[10, 20]])
    expect(w.find('input.dots').classes()).not.toContain('invalid')

    await w.find('input.dots').setValue('10,x')
    expect(w.emitted('update:dots')?.at(-1)).toEqual([[]])
    expect(w.find('input.dots').classes()).toContain('invalid')
  })

  it('開始ラインの変更と削除を emit する', async () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 1, dots: [80] }, index: 0 } })
    await w.find('input.start').setValue('5')
    expect(w.emitted('update:startLine')?.at(-1)).toEqual([5])
    await w.find('button.remove').trigger('click')
    expect(w.emitted('remove')).toHaveLength(1)
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/components/panels/DplSegmentRow.test.ts`
Expected: FAIL — `Failed to resolve import "./DplSegmentRow.vue"`

- [ ] **Step 3: DplSegmentRow.vue を実装する**

`frontend/src/components/panels/DplSegmentRow.vue`:

```vue
<script setup lang="ts">
import { ref, watch } from 'vue'
import { parseDots } from '../../model/parse'
import type { DplSegment } from '../../model/types'

const props = defineProps<{ segment: DplSegment; index: number }>()
const emit = defineEmits<{
  'update:startLine': [n: number]
  'update:dots': [dots: number[]]
  remove: []
}>()

const dotsText = ref(props.segment.dots.join(','))
const invalid = ref(false)

// ストア側の dots が(別経路で)変わったら表示を同期する
watch(
  () => props.segment.dots.join(','),
  (joined) => {
    if ((parseDots(dotsText.value) ?? []).join(',') !== joined) {
      dotsText.value = joined
      invalid.value = false
    }
  },
)

function onDotsInput(e: Event) {
  dotsText.value = (e.target as HTMLInputElement).value
  const parsed = parseDots(dotsText.value)
  invalid.value = parsed === null
  emit('update:dots', parsed ?? [])
}

function onStartInput(e: Event) {
  const n = Number((e.target as HTMLInputElement).value)
  if (Number.isInteger(n)) emit('update:startLine', n)
}
</script>

<template>
  <tr class="row">
    <td>{{ index + 1 }}</td>
    <td>
      <input class="start" type="number" min="1" :value="segment.startLine" @input="onStartInput">
    </td>
    <td>
      <input
        class="dots"
        :class="{ invalid }"
        type="text"
        :value="dotsText"
        placeholder="例: 23,22"
        @input="onDotsInput"
      >
    </td>
    <td>
      <button class="remove" title="削除" @click="emit('remove')">✕</button>
    </td>
  </tr>
</template>

<style scoped>
.start {
  width: 5em;
}
.dots {
  width: 100%;
}
.invalid {
  border-color: #b3261e;
  background: #fdecea;
}
</style>
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/components/panels/DplSegmentRow.test.ts`
Expected: 3 PASS

- [ ] **Step 5: LinesPanel.vue を実装する**

`frontend/src/components/panels/LinesPanel.vue`:

```vue
<script setup lang="ts">
import { useDefinitionStore } from '../../stores/definition'
import DplSegmentRow from './DplSegmentRow.vue'

const store = useDefinitionStore()
</script>

<template>
  <div class="lines">
    <p class="hint">
      DPL,&lt;開始ライン&gt;,&lt;ドット数...&gt;。キャンバス上のラインをクリックすると、そのラインから始まる新しいセグメントを追加します。
    </p>
    <table v-if="store.definition.dpl.length" class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>開始ライン</th>
          <th>ドット数(カンマ区切り)</th>
          <th />
        </tr>
      </thead>
      <tbody>
        <DplSegmentRow
          v-for="(seg, i) in store.definition.dpl"
          :key="i"
          :segment="seg"
          :index="i"
          @update:startLine="(n) => store.updateDplSegment(i, { startLine: n })"
          @update:dots="(d) => store.updateDplSegment(i, { dots: d })"
          @remove="store.removeDplSegment(i)"
        />
      </tbody>
    </table>
    <button @click="store.addDplSegment()">セグメントを追加</button>
    <p class="summary">ページ内ライン数: {{ store.pageLines.length }}</p>
  </div>
</template>

<style scoped>
.hint,
.summary {
  color: #666;
  font-size: 12px;
}
.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 8px;
}
.table th,
.table td {
  padding: 4px;
  border-bottom: 1px solid #eee;
  text-align: left;
}
</style>
```

- [ ] **Step 6: LinesOverlay.vue を実装する**

`frontend/src/components/overlay/LinesOverlay.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useDefinitionStore } from '../../stores/definition'

const props = defineProps<{ scale: number; dim: boolean }>()
const store = useDefinitionStore()

const segmentStarts = computed(() => new Set(store.definition.dpl.map((s) => s.startLine)))
const fontSize = computed(() => 12 / props.scale)
const lastLine = computed(() => store.pageLines[store.pageLines.length - 1] ?? null)
</script>

<template>
  <g class="lines" :class="{ dim }">
    <template v-for="l in store.pageLines" :key="l.n">
      <line
        :x1="0"
        :y1="l.y0"
        :x2="store.pageSize.width"
        :y2="l.y0"
        :class="{ seg: segmentStarts.has(l.n) }"
        vector-effect="non-scaling-stroke"
      />
      <text :x="4 / scale" :y="l.y0 + fontSize" :font-size="fontSize">{{ l.n }}</text>
    </template>
    <line
      v-if="lastLine"
      :x1="0"
      :y1="lastLine.y1"
      :x2="store.pageSize.width"
      :y2="lastLine.y1"
      vector-effect="non-scaling-stroke"
    />
  </g>
</template>

<style scoped>
.lines line {
  stroke: #2a7de1;
  stroke-width: 1;
}
.lines line.seg {
  stroke: #d9480f;
  stroke-width: 2;
}
.lines text {
  fill: #2a7de1;
  font-family: monospace;
  pointer-events: none;
}
.lines.dim {
  opacity: 0.3;
}
</style>
```

- [ ] **Step 7: App.vue に組み込む**

`frontend/src/App.vue` の `<script setup>` と `<template>` を次に置き換える(style は変更なし):

```vue
<script setup lang="ts">
import EditorPanel from './components/EditorPanel.vue'
import PageCanvas from './components/PageCanvas.vue'
import TopBar from './components/TopBar.vue'
import LinesOverlay from './components/overlay/LinesOverlay.vue'
import LinesPanel from './components/panels/LinesPanel.vue'
import { useDefinitionStore } from './stores/definition'

const store = useDefinitionStore()
</script>

<template>
  <div class="app">
    <TopBar class="app__top" />
    <PageCanvas class="app__canvas">
      <template #default="{ scale }">
        <LinesOverlay :scale="scale" :dim="store.activeTab !== 'lines'" />
      </template>
    </PageCanvas>
    <EditorPanel class="app__panel">
      <template #lines>
        <LinesPanel />
      </template>
    </EditorPanel>
  </div>
</template>
```

- [ ] **Step 8: 手動確認**

dev サーバーでPDFを読み込み、「セグメントを追加」→ dots を帳票の行の高さに合わせて調整 → ラインが帳票の行に重なること。キャンバスのラインをクリックすると新セグメントが追加され、その位置から色が変わること。

- [ ] **Step 9: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit && npm test`

```bash
git add frontend/src
git commit -m "feat(frontend): lines tab with DPL segment editor and line overlay

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 12: ブロックタブ(パネル + オーバーレイ + ドラッグ作成)

**Files:**
- Create: `frontend/src/components/panels/BlocksPanel.vue`, `frontend/src/components/overlay/BlocksOverlay.vue`
- Modify: `frontend/src/App.vue`
- Test: `frontend/src/components/panels/BlocksPanel.test.ts`

**Interfaces:**
- Consumes: `useDefinitionStore`(`selectedBlock`, `addBlock`, `updateBlock`, `removeBlock`, `moveBlock`, `blockLines`)、`findOverlappingBlocks`(Task 5)
- Produces: `BlocksOverlay` props `{ scale: number; dim: boolean }`

- [ ] **Step 1: BlocksPanel の失敗するテストを書く**

`frontend/src/components/panels/BlocksPanel.test.ts`:

```ts
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../../stores/definition'
import BlocksPanel from './BlocksPanel.vue'

describe('BlocksPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('ブロック一覧を表示し、行クリックで選択、数値編集でストアが更新される', async () => {
    const store = useDefinitionStore()
    store.addBlock({ startX: 0, endX: 150, startLine: 4, endLine: 11 })
    store.addBlock({ startX: 150, endX: 300, startLine: 4, endLine: 11 })
    store.selectedBlock = null
    const w = mount(BlocksPanel)

    const rows = w.findAll('tbody tr')
    expect(rows).toHaveLength(2)
    await rows[1].trigger('click')
    expect(store.selectedBlock).toBe(1)
    expect(rows[1].classes()).toContain('selected')

    await rows[0].find('input.endX').setValue('120')
    expect(store.definition.blocks[0].endX).toBe(120)
  })

  it('上下ボタンと削除', async () => {
    const store = useDefinitionStore()
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 })
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 })
    const w = mount(BlocksPanel)

    await w.findAll('tbody tr')[1].find('button.up').trigger('click')
    expect(store.definition.blocks[0].startX).toBe(20)

    await w.findAll('tbody tr')[0].find('button.remove').trigger('click')
    expect(store.definition.blocks).toHaveLength(1)
    expect(store.definition.blocks[0].startX).toBe(0)
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/components/panels/BlocksPanel.test.ts`
Expected: FAIL — `Failed to resolve import "./BlocksPanel.vue"`

- [ ] **Step 3: BlocksPanel.vue を実装する**

`frontend/src/components/panels/BlocksPanel.vue`:

```vue
<script setup lang="ts">
import type { Block } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const store = useDefinitionStore()

const FIELDS: { key: keyof Block; label: string }[] = [
  { key: 'startX', label: '開始X' },
  { key: 'endX', label: '終了X' },
  { key: 'startLine', label: '開始ライン' },
  { key: 'endLine', label: '終了ライン' },
]

function onInput(i: number, key: keyof Block, e: Event) {
  const n = Number((e.target as HTMLInputElement).value)
  if (Number.isInteger(n)) store.updateBlock(i, { [key]: n })
}
</script>

<template>
  <div class="blocks">
    <p class="hint">
      キャンバス上でドラッグすると矩形からブロックを追加します(Yはラインにスナップ)。順序がブロック番号になります。
    </p>
    <table v-if="store.definition.blocks.length" class="table">
      <thead>
        <tr>
          <th>#</th>
          <th v-for="f in FIELDS" :key="f.key">{{ f.label }}</th>
          <th />
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(b, i) in store.definition.blocks"
          :key="i"
          :class="{ selected: store.selectedBlock === i }"
          @click="store.selectedBlock = i"
        >
          <td>{{ i + 1 }}</td>
          <td v-for="f in FIELDS" :key="f.key">
            <input
              :class="f.key"
              type="number"
              min="0"
              :value="b[f.key]"
              @input="onInput(i, f.key, $event)"
              @click.stop
            >
          </td>
          <td class="actions">
            <button class="up" title="上へ" :disabled="i === 0" @click.stop="store.moveBlock(i, -1)">▲</button>
            <button
              class="down"
              title="下へ"
              :disabled="i === store.definition.blocks.length - 1"
              @click.stop="store.moveBlock(i, 1)"
            >
              ▼
            </button>
            <button class="remove" title="削除" @click.stop="store.removeBlock(i)">✕</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else class="hint">ブロック未指定の場合、ページ全体が1つのブロックになります。</p>
    <p class="summary">ブロック通しライン数: {{ store.blockLines.length }}</p>
  </div>
</template>

<style scoped>
.hint,
.summary {
  color: #666;
  font-size: 12px;
}
.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 8px;
}
.table th,
.table td {
  padding: 4px 2px;
  border-bottom: 1px solid #eee;
  text-align: left;
}
.table tbody tr {
  cursor: pointer;
}
.table tbody tr.selected {
  background: #e8f1fc;
}
.table input {
  width: 4.5em;
}
.actions {
  white-space: nowrap;
}
</style>
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/components/panels/BlocksPanel.test.ts`
Expected: 2 PASS

- [ ] **Step 5: BlocksOverlay.vue を実装する**

`frontend/src/components/overlay/BlocksOverlay.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { findOverlappingBlocks } from '../../model/blocks'
import type { Rect } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const props = defineProps<{ scale: number; dim: boolean }>()
const store = useDefinitionStore()

const fontSize = computed(() => 12 / props.scale)
const overlapping = computed(() => findOverlappingBlocks(store.definition.blocks))

/** 各ブロックの外接矩形(ブロックラインから)。ラインに掛からないブロックは null */
const blockRects = computed<(Rect | null)[]>(() =>
  store.definition.blocks.map((_, bi) => {
    const lines = store.blockLines.filter((l) => l.blockIndex === bi)
    if (lines.length === 0) return null
    return { x0: lines[0].x0, y0: lines[0].y0, x1: lines[0].x1, y1: lines[lines.length - 1].y1 }
  }),
)

const hasBlocks = computed(() => store.definition.blocks.length > 0)
</script>

<template>
  <g class="blocks" :class="{ dim }">
    <template v-for="(r, bi) in blockRects" :key="bi">
      <g v-if="r" :class="{ selected: store.selectedBlock === bi, overlap: overlapping.has(bi) }">
        <rect
          :x="r.x0"
          :y="r.y0"
          :width="r.x1 - r.x0"
          :height="r.y1 - r.y0"
          vector-effect="non-scaling-stroke"
          @click.stop="store.selectedBlock = bi"
        />
        <text class="label" :x="r.x0 + 6 / scale" :y="r.y0 - 4 / scale" :font-size="fontSize * 1.2">
          ブロック{{ bi + 1 }}
        </text>
      </g>
    </template>
    <template v-if="hasBlocks">
      <text
        v-for="l in store.blockLines"
        :key="l.n"
        class="linenum"
        :x="l.x1 - 4 / scale"
        :y="l.y0 + fontSize"
        :font-size="fontSize"
        text-anchor="end"
      >
        {{ l.n }}
      </text>
    </template>
  </g>
</template>

<style scoped>
.blocks rect {
  fill: rgba(46, 160, 67, 0.12);
  stroke: #2ea043;
  stroke-width: 2;
  cursor: pointer;
}
.blocks .selected rect {
  fill: rgba(46, 160, 67, 0.25);
  stroke-width: 3;
}
.blocks .overlap rect {
  stroke: #d0021b;
}
.blocks .label {
  fill: #1f7a33;
  font-weight: 600;
  pointer-events: none;
}
.blocks .linenum {
  fill: #1f7a33;
  font-family: monospace;
  pointer-events: none;
}
.blocks.dim {
  opacity: 0.3;
}
</style>
```

- [ ] **Step 6: App.vue に組み込む**

`frontend/src/App.vue` の import に `BlocksOverlay` と `BlocksPanel` を足し、テンプレートを次にする:

```vue
<script setup lang="ts">
import EditorPanel from './components/EditorPanel.vue'
import PageCanvas from './components/PageCanvas.vue'
import TopBar from './components/TopBar.vue'
import BlocksOverlay from './components/overlay/BlocksOverlay.vue'
import LinesOverlay from './components/overlay/LinesOverlay.vue'
import BlocksPanel from './components/panels/BlocksPanel.vue'
import LinesPanel from './components/panels/LinesPanel.vue'
import { useDefinitionStore } from './stores/definition'

const store = useDefinitionStore()
</script>

<template>
  <div class="app">
    <TopBar class="app__top" />
    <PageCanvas class="app__canvas">
      <template #default="{ scale }">
        <LinesOverlay :scale="scale" :dim="store.activeTab !== 'lines'" />
        <BlocksOverlay :scale="scale" :dim="store.activeTab !== 'blocks'" />
      </template>
    </PageCanvas>
    <EditorPanel class="app__panel">
      <template #lines>
        <LinesPanel />
      </template>
      <template #blocks>
        <BlocksPanel />
      </template>
    </EditorPanel>
  </div>
</template>
```

- [ ] **Step 7: 手動確認**

ブロックタブでキャンバスをドラッグ → 緑の矩形とブロック番号、矩形内に通し番号。仕様の図(ブロック1: 1-3、ブロック2/3: 4-11 を左右、ブロック4: 12-14)を再現し、通し番号が 1..22 になること。重複させると赤枠になること。

- [ ] **Step 8: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit && npm test`

```bash
git add frontend/src
git commit -m "feat(frontend): blocks tab with drag-to-create, list editor and overlay

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 13: パラグラフタブ(パネル + オーバーレイ + DIVドラッグ)

**Files:**
- Create: `frontend/src/components/panels/ParagraphsPanel.vue`, `frontend/src/components/overlay/ParagraphsOverlay.vue`
- Modify: `frontend/src/App.vue`
- Test: `frontend/src/components/panels/ParagraphsPanel.test.ts`

**Interfaces:**
- Consumes: `useDefinitionStore`(`selectedParagraph`, `addParagraph`, `updateParagraph`, `updateDiv`, `removeParagraph`, `moveParagraph`, `resolvedParagraphs`)、`parseLineRef` / `formatLineRef`(Task 3)、`DIV_CONDS`(Task 3)、`paragraphDisplayName`(Task 6)
- Produces: `ParagraphsOverlay` props `{ scale: number; dim: boolean }`

- [ ] **Step 1: ParagraphsPanel の失敗するテストを書く**

`frontend/src/components/panels/ParagraphsPanel.test.ts`:

```ts
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../../stores/definition'
import ParagraphsPanel from './ParagraphsPanel.vue'

describe('ParagraphsPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('追加すると一覧に Paragraph1 が出て選択され、フォームが表示される', async () => {
    const store = useDefinitionStore()
    const w = mount(ParagraphsPanel)
    await w.find('button.add').trigger('click')
    expect(store.definition.paragraphs).toHaveLength(1)
    expect(w.find('li').text()).toContain('Paragraph1')
    expect(w.find('form').exists()).toBe(true)
  })

  it('終了ラインは E<n> をパースし、不正なら invalid でストアを変えない', async () => {
    const store = useDefinitionStore()
    store.addParagraph()
    const w = mount(ParagraphsPanel)

    await w.find('input.endLine').setValue('E2')
    expect(store.definition.paragraphs[0].endLine).toEqual({ kind: 'fromEnd', n: 2 })

    await w.find('input.endLine').setValue('zzz')
    expect(store.definition.paragraphs[0].endLine).toEqual({ kind: 'fromEnd', n: 2 })
    expect(w.find('input.endLine').classes()).toContain('invalid')
  })

  it('名前・比較条件・同値継続・DEL_BACKWARD_SPACE がストアに反映される', async () => {
    const store = useDefinitionStore()
    store.addParagraph()
    const w = mount(ParagraphsPanel)

    await w.find('input.name').setValue('支店')
    await w.find('select.cond').setValue('A')
    await w.find('select.sameContinue').setValue('Y')
    await w.find('input.delBackwardSpace').setValue(true)

    const p = store.definition.paragraphs[0]
    expect(p.name).toBe('支店')
    expect(p.div.cond).toBe('A')
    expect(p.div.sameContinue).toBe('Y')
    expect(p.delBackwardSpace).toBe(true)
    expect(w.find('li').text()).toContain('支店')
  })

  it('入れ子はインデントで表現される', () => {
    const store = useDefinitionStore()
    store.addParagraph()
    store.addParagraph()
    const w = mount(ParagraphsPanel)
    const items = w.findAll('li')
    expect(items[0].attributes('style')).toContain('padding-left: 0px')
    expect(items[1].attributes('style')).toContain('padding-left: 16px')
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/components/panels/ParagraphsPanel.test.ts`
Expected: FAIL — `Failed to resolve import "./ParagraphsPanel.vue"`

- [ ] **Step 3: ParagraphsPanel.vue を実装する**

`frontend/src/components/panels/ParagraphsPanel.vue`:

```vue
<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { paragraphDisplayName } from '../../model/paragraphs'
import { formatLineRef, parseLineRef } from '../../model/parse'
import { DIV_CONDS, type DivCond } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const store = useDefinitionStore()

const selected = computed(() =>
  store.selectedParagraph === null ? null : store.definition.paragraphs[store.selectedParagraph] ?? null,
)
const selectedIndex = computed(() => store.selectedParagraph)

// 終了ラインはテキスト入力をローカルに持ち、パースできたときだけストアへ
const endLineText = ref('')
const endLineInvalid = ref(false)
watch(
  () => [selectedIndex.value, selected.value?.endLine] as const,
  () => {
    endLineText.value = selected.value ? formatLineRef(selected.value.endLine) : ''
    endLineInvalid.value = false
  },
  { immediate: true, deep: true },
)

function num(e: Event): number | null {
  const v = (e.target as HTMLInputElement).value.trim()
  if (v === '') return null
  const n = Number(v)
  return Number.isInteger(n) ? n : null
}

function onStartLine(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, { startLine: num(e) })
}

function onEndLine(e: Event) {
  if (selectedIndex.value === null) return
  endLineText.value = (e.target as HTMLInputElement).value
  const r = parseLineRef(endLineText.value)
  endLineInvalid.value = !r.ok
  if (r.ok) store.updateParagraph(selectedIndex.value, { endLine: r.value })
}

function onName(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, { name: (e.target as HTMLInputElement).value })
}

function onSpanPage(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, { spanPage: (e.target as HTMLInputElement).checked })
}

function onDelBackwardSpace(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, {
    delBackwardSpace: (e.target as HTMLInputElement).checked,
  })
}

function onDivValue(e: Event) {
  if (selectedIndex.value === null) return
  store.updateDiv(selectedIndex.value, { value: (e.target as HTMLInputElement).value })
}

function onDivCond(e: Event) {
  if (selectedIndex.value === null) return
  store.updateDiv(selectedIndex.value, { cond: (e.target as HTMLSelectElement).value as DivCond })
}

function onDivX(key: 'startX' | 'endX', e: Event) {
  if (selectedIndex.value === null) return
  const n = num(e)
  if (n !== null) store.updateDiv(selectedIndex.value, { [key]: n })
}

function onSameContinue(e: Event) {
  if (selectedIndex.value === null) return
  const v = (e.target as HTMLSelectElement).value
  store.updateDiv(selectedIndex.value, { sameContinue: v === '' ? null : (v as 'Y' | 'N') })
}
</script>

<template>
  <div class="paragraphs">
    <p class="hint">
      配列順がそのまま親→子→孫の入れ子になります。選択中のパラグラフに対して、キャンバス上を横にドラッグするとDIVのX範囲が入ります。
    </p>
    <ul class="list">
      <li
        v-for="(p, i) in store.definition.paragraphs"
        :key="i"
        :class="{ selected: store.selectedParagraph === i, error: store.resolvedParagraphs[i]?.error }"
        :style="{ paddingLeft: i * 16 + 'px' }"
        @click="store.selectedParagraph = i"
      >
        <span class="name">{{ paragraphDisplayName(p, i) }}</span>
        <span class="range">
          {{ store.resolvedParagraphs[i]?.first }}〜{{ store.resolvedParagraphs[i]?.last }}
        </span>
        <span class="actions">
          <button title="上へ" :disabled="i === 0" @click.stop="store.moveParagraph(i, -1)">▲</button>
          <button
            title="下へ"
            :disabled="i === store.definition.paragraphs.length - 1"
            @click.stop="store.moveParagraph(i, 1)"
          >
            ▼
          </button>
          <button title="削除" @click.stop="store.removeParagraph(i)">✕</button>
        </span>
      </li>
    </ul>
    <button class="add" @click="store.addParagraph()">パラグラフを追加</button>

    <form v-if="selected && selectedIndex !== null" class="form" @submit.prevent>
      <h3>{{ paragraphDisplayName(selected, selectedIndex) }}</h3>
      <label>
        <span>開始ライン(親内)</span>
        <input class="startLine" type="number" min="1" :value="selected.startLine ?? ''" placeholder="1" @input="onStartLine">
      </label>
      <label>
        <span>終了ライン(親内 / E<n>)</span>
        <input
          class="endLine"
          :class="{ invalid: endLineInvalid }"
          type="text"
          :value="endLineText"
          placeholder="親の最終ライン"
          @input="onEndLine"
        >
      </label>
      <label>
        <span>パラグラフ名</span>
        <input class="name" type="text" :value="selected.name" :placeholder="`Paragraph${selectedIndex + 1}`" @input="onName">
      </label>
      <label class="check">
        <input type="checkbox" :checked="selected.spanPage" @change="onSpanPage">
        <span>ページ跨り(Y)</span>
      </label>

      <fieldset>
        <legend>DIV</legend>
        <label>
          <span>比較値</span>
          <input class="divValue" type="text" :value="selected.div.value" @input="onDivValue">
        </label>
        <label>
          <span>比較条件</span>
          <select class="cond" :value="selected.div.cond" @change="onDivCond">
            <option v-for="c in DIV_CONDS" :key="c.value" :value="c.value">{{ c.label }}</option>
          </select>
        </label>
        <label>
          <span>開始X</span>
          <input class="divStartX" type="number" min="0" :value="selected.div.startX" @input="onDivX('startX', $event)">
        </label>
        <label>
          <span>終了X</span>
          <input class="divEndX" type="number" min="0" :value="selected.div.endX" @input="onDivX('endX', $event)">
        </label>
        <label>
          <span>同値継続</span>
          <select class="sameContinue" :value="selected.div.sameContinue ?? ''" @change="onSameContinue">
            <option value="">未指定(N)</option>
            <option value="Y">Y: 同じパラグラフ</option>
            <option value="N">N: 別パラグラフ</option>
          </select>
        </label>
      </fieldset>

      <label class="check">
        <input class="delBackwardSpace" type="checkbox" :checked="selected.delBackwardSpace" @change="onDelBackwardSpace">
        <span>DEL_BACKWARD_SPACE(末尾の空白ラインを除く)</span>
      </label>
    </form>
  </div>
</template>

<style scoped>
.hint {
  color: #666;
  font-size: 12px;
}
.list {
  list-style: none;
  margin: 0 0 8px;
  padding: 0;
}
.list li {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
}
.list li.selected {
  background: #fdf1e3;
}
.list li.error .name {
  color: #b3261e;
}
.list .name {
  flex: 1;
}
.list .range {
  color: #666;
  font-size: 12px;
}
.form {
  margin-top: 12px;
  display: grid;
  gap: 8px;
}
.form h3 {
  margin: 0;
  font-size: 14px;
}
.form label {
  display: grid;
  grid-template-columns: 9em 1fr;
  align-items: center;
  gap: 6px;
}
.form label.check {
  grid-template-columns: auto 1fr;
}
.form fieldset {
  display: grid;
  gap: 6px;
  border: 1px solid #ddd;
}
.invalid {
  border-color: #b3261e;
  background: #fdecea;
}
</style>
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/components/panels/ParagraphsPanel.test.ts`
Expected: 4 PASS

- [ ] **Step 5: ParagraphsOverlay.vue を実装する**

`frontend/src/components/overlay/ParagraphsOverlay.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import type { Rect } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const props = defineProps<{ scale: number; dim: boolean }>()
const store = useDefinitionStore()

const fontSize = computed(() => 12 / props.scale)

/** 入れ子の深さぶんだけ内側に寄せる */
function inset(r: Rect, depth: number): Rect {
  const d = (depth * 4) / props.scale
  return { x0: r.x0 + d, y0: r.y0 + d, x1: r.x1 - d, y1: r.y1 - d }
}
</script>

<template>
  <g class="paragraphs" :class="{ dim }">
    <g
      v-for="rp in store.resolvedParagraphs"
      :key="rp.index"
      :class="{ selected: store.selectedParagraph === rp.index, error: rp.error }"
      @click.stop="store.selectedParagraph = rp.index"
    >
      <rect
        v-for="(r, i) in rp.rects.map((x) => inset(x, rp.index))"
        :key="'band' + i"
        class="band"
        :x="r.x0"
        :y="r.y0"
        :width="Math.max(r.x1 - r.x0, 0)"
        :height="Math.max(r.y1 - r.y0, 0)"
        vector-effect="non-scaling-stroke"
      />
      <rect
        v-for="(r, i) in rp.divRects.map((x) => inset(x, rp.index))"
        :key="'div' + i"
        class="div"
        :x="r.x0"
        :y="r.y0"
        :width="Math.max(r.x1 - r.x0, 0)"
        :height="Math.max(r.y1 - r.y0, 0)"
        vector-effect="non-scaling-stroke"
      />
      <text
        v-if="rp.rects[0]"
        class="label"
        :x="rp.rects[0].x0 + (6 + rp.index * 4) / scale"
        :y="rp.rects[0].y0 + fontSize * 1.2 + (rp.index * 4) / scale"
        :font-size="fontSize"
      >
        {{ rp.name }} ({{ rp.first }}〜{{ rp.last }})
      </text>
    </g>
  </g>
</template>

<style scoped>
.paragraphs .band {
  fill: rgba(217, 119, 6, 0.1);
  stroke: #d97706;
  stroke-width: 1.5;
  cursor: pointer;
}
.paragraphs .div {
  fill: rgba(217, 119, 6, 0.15);
  stroke: #b45309;
  stroke-width: 2.5;
  pointer-events: none;
}
.paragraphs .selected .band {
  fill: rgba(217, 119, 6, 0.2);
  stroke-width: 3;
}
.paragraphs .error .band,
.paragraphs .error .div {
  stroke: #d0021b;
}
.paragraphs .label {
  fill: #92400e;
  font-weight: 600;
  pointer-events: none;
}
.paragraphs.dim {
  opacity: 0.3;
}
</style>
```

- [ ] **Step 6: App.vue に組み込む**

`frontend/src/App.vue` の import に `ParagraphsOverlay` と `ParagraphsPanel` を足し、テンプレートを次にする:

```vue
<script setup lang="ts">
import EditorPanel from './components/EditorPanel.vue'
import PageCanvas from './components/PageCanvas.vue'
import TopBar from './components/TopBar.vue'
import BlocksOverlay from './components/overlay/BlocksOverlay.vue'
import LinesOverlay from './components/overlay/LinesOverlay.vue'
import ParagraphsOverlay from './components/overlay/ParagraphsOverlay.vue'
import BlocksPanel from './components/panels/BlocksPanel.vue'
import LinesPanel from './components/panels/LinesPanel.vue'
import ParagraphsPanel from './components/panels/ParagraphsPanel.vue'
import { useDefinitionStore } from './stores/definition'

const store = useDefinitionStore()
</script>

<template>
  <div class="app">
    <TopBar class="app__top" />
    <PageCanvas class="app__canvas">
      <template #default="{ scale }">
        <LinesOverlay :scale="scale" :dim="store.activeTab !== 'lines'" />
        <BlocksOverlay :scale="scale" :dim="store.activeTab !== 'blocks'" />
        <ParagraphsOverlay :scale="scale" :dim="store.activeTab !== 'paragraphs'" />
      </template>
    </PageCanvas>
    <EditorPanel class="app__panel">
      <template #lines>
        <LinesPanel />
      </template>
      <template #blocks>
        <BlocksPanel />
      </template>
      <template #paragraphs>
        <ParagraphsPanel />
      </template>
    </EditorPanel>
  </div>
</template>
```

- [ ] **Step 7: 手動確認**

パラグラフタブで追加 → 全ブロック行に橙の帯。キャンバスを横にドラッグ → DIVのX範囲の濃い枠。2つ目を追加して開始/終了を設定 → 内側に細い帯。`E1` 指定と範囲外指定(赤)を確認。

- [ ] **Step 8: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit && npm test`

```bash
git add frontend/src
git commit -m "feat(frontend): paragraphs tab with nested editor, DIV drag and overlay

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 14: 出力プレビューと検証結果パネル

**Files:**
- Create: `frontend/src/components/OutputPreview.vue`, `frontend/src/components/ValidationPanel.vue`
- Modify: `frontend/src/App.vue`
- Test: `frontend/src/components/ValidationPanel.test.ts`

**Interfaces:**
- Consumes: `useDefinitionStore`(`outputText`, `errors`, `activeTab`, `selectedBlock`, `selectedParagraph`)、`ValidationError`(Task 3)
- Produces: `EditorPanel` の `#footer` スロットに両パネルを差し込む

- [ ] **Step 1: ValidationPanel の失敗するテストを書く**

`frontend/src/components/ValidationPanel.test.ts`:

```ts
import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../stores/definition'
import ValidationPanel from './ValidationPanel.vue'

describe('ValidationPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('エラーが無ければ「問題ありません」', () => {
    const w = mount(ValidationPanel)
    expect(w.text()).toContain('問題ありません')
  })

  it('エラーを対象ラベル付きで列挙し、クリックで対象タブと要素を選択する', async () => {
    const store = useDefinitionStore()
    store.setDocument({ id: 'd', fileName: 'a.pdf', pageCount: 1, pages: [{ width: 300, height: 350 }] })
    store.addDplSegment()
    store.addBlock({ startX: 10, endX: 5, startLine: 1, endLine: 1 })
    store.selectedBlock = null
    store.activeTab = 'lines'
    const w = mount(ValidationPanel)

    const items = w.findAll('li')
    expect(items).toHaveLength(1)
    expect(items[0].text()).toContain('ブロック1')
    expect(items[0].text()).toContain('開始X')

    await items[0].trigger('click')
    expect(store.activeTab).toBe('blocks')
    expect(store.selectedBlock).toBe(0)
  })
})
```

- [ ] **Step 2: テストが失敗することを確認する**

Run: `cd frontend && npm test -- src/components/ValidationPanel.test.ts`
Expected: FAIL — `Failed to resolve import "./ValidationPanel.vue"`

- [ ] **Step 3: ValidationPanel.vue と OutputPreview.vue を実装する**

`frontend/src/components/ValidationPanel.vue`:

```vue
<script setup lang="ts">
import type { ValidationError } from '../model/types'
import { useDefinitionStore } from '../stores/definition'

const store = useDefinitionStore()

function label(e: ValidationError): string {
  const n = e.index === null ? '' : String(e.index + 1)
  if (e.target === 'dpl') return e.index === null ? 'DPL' : `DPL ${n}`
  if (e.target === 'block') return `ブロック${n}`
  return `パラグラフ${n}`
}

function focus(e: ValidationError) {
  if (e.target === 'dpl') store.activeTab = 'lines'
  if (e.target === 'block') {
    store.activeTab = 'blocks'
    store.selectedBlock = e.index
  }
  if (e.target === 'paragraph') {
    store.activeTab = 'paragraphs'
    store.selectedParagraph = e.index
  }
}
</script>

<template>
  <section class="validation">
    <h3>検証結果</h3>
    <p v-if="store.errors.length === 0" class="ok">問題ありません</p>
    <ul v-else>
      <li v-for="(e, i) in store.errors" :key="i" @click="focus(e)">
        <span class="target">{{ label(e) }}</span>
        <span>{{ e.message }}</span>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.validation {
  padding: 8px 12px;
}
.validation h3 {
  margin: 0 0 4px;
  font-size: 13px;
}
.ok {
  color: #1f7a33;
  margin: 0;
}
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
li {
  display: flex;
  gap: 8px;
  padding: 3px 0;
  color: #b3261e;
  cursor: pointer;
}
.target {
  font-weight: 600;
  white-space: nowrap;
}
</style>
```

`frontend/src/components/OutputPreview.vue`:

```vue
<script setup lang="ts">
import { useDefinitionStore } from '../stores/definition'

const store = useDefinitionStore()
</script>

<template>
  <section class="preview">
    <h3>出力プレビュー</h3>
    <pre>{{ store.outputText || '(定義なし)' }}</pre>
  </section>
</template>

<style scoped>
.preview {
  padding: 8px 12px;
  border-bottom: 1px solid #eee;
}
.preview h3 {
  margin: 0 0 4px;
  font-size: 13px;
}
pre {
  margin: 0;
  padding: 8px;
  background: #f7f7f7;
  font-family: ui-monospace, Menlo, Consolas, monospace;
  font-size: 12px;
  white-space: pre;
  overflow: auto;
  max-height: 200px;
}
</style>
```

- [ ] **Step 4: テストが通ることを確認する**

Run: `cd frontend && npm test -- src/components/ValidationPanel.test.ts`
Expected: 2 PASS

- [ ] **Step 5: App.vue の EditorPanel に footer を差し込む**

`frontend/src/App.vue` の import に次を足す:

```ts
import OutputPreview from './components/OutputPreview.vue'
import ValidationPanel from './components/ValidationPanel.vue'
```

`<EditorPanel>` の中に次を追加する(`#paragraphs` の後):

```vue
      <template #footer>
        <OutputPreview />
        <ValidationPanel />
      </template>
```

- [ ] **Step 6: 手動確認**

定義を編集するたびにプレビューが更新され、エラーがある間はダウンロードボタンが無効。エラー行をクリックすると該当タブ・要素が選択される。エラーを直してダウンロードし、保存されたファイルの内容がプレビューと同じで、仕様の書式(行末 `,`、`#` 見出し)になっていること。

- [ ] **Step 7: lint、型チェック、コミット**

Run: `cd frontend && npm run lint && npx vue-tsc --noEmit && npm test`

```bash
git add frontend/src
git commit -m "feat(frontend): output preview and validation panel with error focus

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

### Task 15: 本番相当の起動と README

**Files:**
- Modify: `README.md`
- Test: 手動(ビルド成果物を FastAPI が配信すること)

**Interfaces:**
- Consumes: `FRONTEND_DIST` の静的配信(Task 2)、`npm run build`(Task 3)

- [ ] **Step 1: ビルドして単一プロセスで動くことを確認する**

Run:
- `cd frontend && npm run build`
- `cd backend && uv run uvicorn app.main:app --port 8000`

`http://localhost:8000/` を開き、Vite dev server なしでアプリが動き、PDF読込〜ダウンロードまで通ること。

- [ ] **Step 2: README を書く**

`README.md`:

````markdown
# Form Define Builder

PDF帳票のフォーム定義ファイル(DPL / BLOCK / PARAGRAPH / DIV / DEL_BACKWARD_SPACE)を、
PDFを画像化した上に枠を重ねながらGUIで作成し、テキストファイルとしてダウンロードするWebアプリです。

- バックエンド: FastAPI + pypdfium2(PDF→PNG変換のみ)
- フロントエンド: Vite + Vue 3 + TypeScript + Pinia(定義の編集・検証・テキスト生成)

設計: `docs/superpowers/specs/2026-09-06-form-define-builder-design.md`

## 必要なもの

- Python 3.12 と [uv](https://docs.astral.sh/uv/)
- Node.js 24 と npm

## 開発時の起動

ターミナル1(バックエンド、`http://localhost:8000`):

```bash
cd backend && uv sync && uv run uvicorn app.main:app --reload --port 8000
```

ターミナル2(フロントエンド、`http://localhost:5173`。`/api` は 8000 にプロキシ):

```bash
cd frontend && npm install && npm run dev
```

## 単一プロセスでの起動

フロントをビルドすると FastAPI が `frontend/dist` を配信します。

```bash
cd frontend && npm run build
```

```bash
cd backend && uv run uvicorn app.main:app --port 8000
```

`http://localhost:8000/` を開きます。

## テスト

```bash
cd backend && uv run pytest
```

```bash
cd frontend && npm test
```

## 使い方

1. PDF を選び、DPI(初期値 720)を指定して「読込」。
2. **ライン** タブで DPL セグメントを追加し、ドット数を帳票の行の高さに合わせる。キャンバスのラインをクリックすると、その位置から始まる新しいセグメントを追加できる。
3. **ブロック** タブでキャンバス上をドラッグして段組みの矩形を作る(Y はラインにスナップ)。
4. **パラグラフ** タブでパラグラフを追加し、開始/終了ライン(`E1` = 親の最終ライン)と DIV を設定する。選択中のパラグラフに対してキャンバスを横にドラッグすると DIV の X 範囲が入る。
5. 検証結果にエラーがなければ「定義ファイルをダウンロード」で `<PDF名>.txt` を保存する。

DPI は定義ファイルに含まれないため、別途控えておいてください。
````

- [ ] **Step 3: 全テストを通してコミット**

Run: `cd backend && uv run pytest && cd ../frontend && npm test && npm run lint`

```bash
git add README.md
git commit -m "docs: add README with setup, run and usage instructions

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>"
```

---

## Self-Review Notes

- **スペック対応**: §4 API → Task 1–2。§5 型 → Task 3。§6.1〜6.5 → Task 4–8。§7.1 上部バー/キャンバス/パネル → Task 10。§7.2 → Task 11。§7.3 → Task 12。§7.4 → Task 13。§7.5 ダウンロード → Task 10(ボタン)+ Task 14(無効化の根拠表示)。§7.6 ストア → Task 9。§8 エラー処理 → Task 10(読込エラー表示・確認ダイアログ)+ Task 14。§9 テスト → 各タスク。§10 ツール → Task 1, 3。§3 静的配信 → Task 2, 15。
- **既知の判断**: 最初のDPLセグメントの既定 dots は `[80]`(仕様例の値)。ラインクリックで追加するセグメントの dots は、そのラインを支配するセグメントをコピー。
