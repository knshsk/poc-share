import shutil
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path


@dataclass
class DocumentInfo:
    id: str
    dir: Path
    sizes: list[tuple[int, int]]


class DocumentStore:
    """変換済みPNGを一時ディレクトリに置き、id で引けるようにする。プロセス終了時に破棄。"""

    def __init__(self) -> None:
        self._root = Path(tempfile.mkdtemp(prefix="form-define-builder-"))
        self._docs: dict[str, DocumentInfo] = {}

    def new_dir(self) -> tuple[str, Path]:
        self._root.mkdir(parents=True, exist_ok=True)
        doc_id = uuid.uuid4().hex
        path = self._root / doc_id
        path.mkdir()
        return doc_id, path

    def register(self, doc_id: str, sizes: list[tuple[int, int]]) -> DocumentInfo:
        info = DocumentInfo(id=doc_id, dir=self._root / doc_id, sizes=sizes)
        self._docs[doc_id] = info
        return info

    def discard(self, doc_id: str) -> None:
        self._docs.pop(doc_id, None)
        shutil.rmtree(self._root / doc_id, ignore_errors=True)

    def page_path(self, doc_id: str, n: int) -> Path | None:
        info = self._docs.get(doc_id)
        if info is None or n < 1 or n > len(info.sizes):
            return None
        path = info.dir / f"{n}.png"
        if not path.is_file():
            return None
        return path

    def cleanup(self) -> None:
        self._docs.clear()
        shutil.rmtree(self._root, ignore_errors=True)
