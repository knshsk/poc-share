from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from app.render import MAX_DPI, MIN_DPI, InvalidPdfError, render_pdf
from app.store import DocumentStore

FRONTEND_DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"

store = DocumentStore()


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    store.cleanup()


app = FastAPI(title="Form Define Builder", lifespan=lifespan)


@app.post("/api/documents")
async def create_document(file: UploadFile = File(...), dpi: int = Form(...)):
    if not MIN_DPI <= dpi <= MAX_DPI:
        raise HTTPException(
            status_code=422, detail=f"DPIは{MIN_DPI}〜{MAX_DPI}の範囲で指定してください"
        )
    data = await file.read()
    doc_id, out_dir = store.new_dir()
    try:
        sizes = await run_in_threadpool(render_pdf, data, dpi, out_dir)
    except InvalidPdfError:
        store.discard(doc_id)
        raise HTTPException(status_code=400, detail="PDFとして開けませんでした")
    store.register(doc_id, sizes)
    return {
        "id": doc_id,
        "page_count": len(sizes),
        "pages": [{"width": w, "height": h} for w, h in sizes],
    }


@app.get("/api/documents/{doc_id}/pages/{n}")
def get_page(doc_id: str, n: int):
    path = store.page_path(doc_id, n)
    if path is None:
        raise HTTPException(status_code=404, detail="ページが見つかりません")
    return FileResponse(path, media_type="image/png")


if FRONTEND_DIST.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")
