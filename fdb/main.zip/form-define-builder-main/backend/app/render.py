from pathlib import Path

import pypdfium2 as pdfium

MIN_DPI = 36
MAX_DPI = 1200


class InvalidPdfError(Exception):
    """入力がPDFとして開けない。"""


def render_pdf(pdf_bytes: bytes, dpi: int, out_dir: Path) -> list[tuple[int, int]]:
    """PDFの全ページを指定DPIでPNGにして out_dir/<n>.png に書き、各ページの (width, height) を返す。"""
    try:
        pdf = pdfium.PdfDocument(pdf_bytes)
    except pdfium.PdfiumError as e:
        raise InvalidPdfError(str(e)) from e

    out_dir.mkdir(parents=True, exist_ok=True)
    sizes: list[tuple[int, int]] = []
    try:
        for i in range(len(pdf)):
            page = pdf[i]
            bitmap = page.render(scale=dpi / 72)
            image = bitmap.to_pil()
            image.save(out_dir / f"{i + 1}.png")
            sizes.append((image.width, image.height))
            page.close()
    finally:
        pdf.close()
    return sizes
