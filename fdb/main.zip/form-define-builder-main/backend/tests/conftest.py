import io

import pypdfium2 as pdfium
import pytest


def make_pdf(page_count: int, width: float = 595, height: float = 842) -> bytes:
    """指定ページ数の空PDF(A4相当、ポイント単位)を生成する。"""
    pdf = pdfium.PdfDocument.new()
    for _ in range(page_count):
        pdf.new_page(width, height)
    buf = io.BytesIO()
    pdf.save(buf)
    pdf.close()
    return buf.getvalue()


@pytest.fixture
def two_page_pdf() -> bytes:
    return make_pdf(2)
