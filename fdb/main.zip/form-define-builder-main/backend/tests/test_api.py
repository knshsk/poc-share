import pytest
from fastapi.testclient import TestClient

from app.main import app, store


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def upload(client: TestClient, data: bytes, dpi="72"):
    return client.post(
        "/api/documents",
        files={"file": ("sample.pdf", data, "application/pdf")},
        data={"dpi": dpi},
    )


def test_upload_returns_page_sizes(client, two_page_pdf):
    res = upload(client, two_page_pdf)

    assert res.status_code == 200
    body = res.json()
    assert body["page_count"] == 2
    assert body["pages"] == [{"width": 595, "height": 842}] * 2
    assert isinstance(body["id"], str) and body["id"]


def test_get_page_returns_png(client, two_page_pdf):
    doc_id = upload(client, two_page_pdf).json()["id"]

    res = client.get(f"/api/documents/{doc_id}/pages/2")

    assert res.status_code == 200
    assert res.headers["content-type"] == "image/png"
    assert res.content[:8] == b"\x89PNG\r\n\x1a\n"


def test_get_page_404_when_png_missing_from_disk(client, two_page_pdf):
    doc_id = upload(client, two_page_pdf).json()["id"]
    path = store.page_path(doc_id, 1)
    assert path is not None
    path.unlink()

    assert client.get(f"/api/documents/{doc_id}/pages/1").status_code == 404


def test_get_missing_page_is_404(client, two_page_pdf):
    doc_id = upload(client, two_page_pdf).json()["id"]

    assert client.get(f"/api/documents/{doc_id}/pages/3").status_code == 404
    assert client.get(f"/api/documents/{doc_id}/pages/0").status_code == 404
    assert client.get("/api/documents/no-such-id/pages/1").status_code == 404


def test_upload_non_pdf_is_400(client):
    res = upload(client, b"not a pdf")

    assert res.status_code == 400
    assert "PDF" in res.json()["detail"]


@pytest.mark.parametrize("dpi", ["35", "1201", "abc"])
def test_upload_bad_dpi_is_422(client, two_page_pdf, dpi):
    assert upload(client, two_page_pdf, dpi=dpi).status_code == 422
