from pathlib import Path

import pytest
from PIL import Image

from app.render import InvalidPdfError, render_pdf


def test_render_writes_one_png_per_page(two_page_pdf: bytes, tmp_path: Path):
    sizes = render_pdf(two_page_pdf, dpi=72, out_dir=tmp_path)

    assert len(sizes) == 2
    assert (tmp_path / "1.png").is_file()
    assert (tmp_path / "2.png").is_file()
    with Image.open(tmp_path / "1.png") as im:
        assert im.size == sizes[0]


def test_render_size_scales_with_dpi(two_page_pdf: bytes, tmp_path: Path):
    (w72, h72), _ = render_pdf(two_page_pdf, dpi=72, out_dir=tmp_path / "a")
    (w144, h144), _ = render_pdf(two_page_pdf, dpi=144, out_dir=tmp_path / "b")

    assert w72 == 595 and h72 == 842
    assert w144 == 1190 and h144 == 1684


def test_render_rejects_non_pdf(tmp_path: Path):
    with pytest.raises(InvalidPdfError):
        render_pdf(b"this is not a pdf", dpi=72, out_dir=tmp_path)
