import pluginVue from 'eslint-plugin-vue'
import { defineConfigWithVueTs, vueTsConfigs } from '@vue/eslint-config-typescript'

// 'flat/essential' を使う: 'flat/recommended' に含まれる書式系ルール(1行1属性など)は
// フォーマッタの領分なので採用しない
export default defineConfigWithVueTs(
  { ignores: ['dist/**', 'node_modules/**'] },
  pluginVue.configs['flat/essential'],
  vueTsConfigs.recommended,
)
