export interface DocumentResponse {
  id: string
  page_count: number
  pages: { width: number; height: number }[]
}

async function errorMessage(res: Response): Promise<string> {
  try {
    const body = (await res.json()) as { detail?: unknown }
    if (typeof body.detail === 'string') return body.detail
    if (Array.isArray(body.detail)) {
      const msgs = body.detail
        .map((item) => (item && typeof item === 'object' && 'msg' in item ? String(item.msg) : null))
        .filter((m): m is string => m !== null)
      if (msgs.length > 0) return msgs.join('; ')
    }
  } catch {
    // 本文がJSONでない
  }
  return `サーバーエラー (${res.status})`
}

export async function uploadDocument(file: File, dpi: number): Promise<DocumentResponse> {
  const form = new FormData()
  form.append('file', file)
  form.append('dpi', String(dpi))
  let res: Response
  try {
    res = await fetch('/api/documents', { method: 'POST', body: form })
  } catch {
    throw new Error('サーバーに接続できません')
  }
  if (!res.ok) throw new Error(await errorMessage(res))
  return (await res.json()) as DocumentResponse
}

export function pageImageUrl(id: string, n: number): string {
  return `/api/documents/${id}/pages/${n}`
}
