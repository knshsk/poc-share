import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../stores/definition'
import PageCanvas from './PageCanvas.vue'

if (typeof globalThis.ResizeObserver === 'undefined') {
  class MockResizeObserver {
    observe() {}
    unobserve() {}
    disconnect() {}
  }
  globalThis.ResizeObserver = MockResizeObserver as unknown as typeof ResizeObserver
}

function setup() {
  const w = mount(PageCanvas)
  const store = useDefinitionStore()
  store.setDocument({
    id: 'doc1',
    fileName: 'sample.pdf',
    pageCount: 1,
    pages: [{ width: 300, height: 350 }],
  })
  store.addDplSegment()
  store.updateDplSegment(0, { dots: [25] })
  store.zoom = 100
  return { w, store }
}

async function stubSvgRect(w: ReturnType<typeof mount>) {
  await w.vm.$nextTick()
  const svgEl = w.find('svg').element as SVGSVGElement
  svgEl.getBoundingClientRect = () =>
    ({
      left: 0,
      top: 0,
      width: 300,
      height: 350,
      right: 300,
      bottom: 350,
      x: 0,
      y: 0,
      toJSON() {},
    }) as DOMRect
  return svgEl
}

describe('PageCanvas', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('画像端を越えるドラッグはページ境界にクランプしてブロックを作る', async () => {
    const { w, store } = setup()
    store.activeTab = 'blocks'
    const svgEl = await stubSvgRect(w)

    svgEl.dispatchEvent(new MouseEvent('mousedown', { clientX: 10, clientY: 80, button: 0 }))
    await w.vm.$nextTick()
    window.dispatchEvent(new MouseEvent('mousemove', { clientX: 400, clientY: 500 }))
    window.dispatchEvent(new MouseEvent('mouseup', { clientX: 400, clientY: 500 }))
    await w.vm.$nextTick()

    expect(store.definition.blocks).toHaveLength(1)
    expect(store.definition.blocks[0]).toEqual({
      startX: 10,
      endX: 300,
      startLine: 4,
      endLine: 14,
    })
  })

  it('3px未満の移動はクリック扱いでラインタブならDPLセグメントを追加する', async () => {
    const { w, store } = setup()
    store.activeTab = 'lines'
    const svgEl = await stubSvgRect(w)

    svgEl.dispatchEvent(new MouseEvent('mousedown', { clientX: 10, clientY: 80, button: 0 }))
    await w.vm.$nextTick()
    window.dispatchEvent(new MouseEvent('mousemove', { clientX: 11, clientY: 81 }))
    window.dispatchEvent(new MouseEvent('mouseup', { clientX: 11, clientY: 81 }))
    await w.vm.$nextTick()

    expect(store.definition.blocks).toHaveLength(0)
    expect(store.definition.dpl).toHaveLength(2)
    expect(store.definition.dpl.some((s) => s.startLine === 4)).toBe(true)
  })
})

describe('PageCanvas: コンテナ計測と倍率', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('スクロール領域の内寸をストアに報告し、fit-width の倍率で描画する', async () => {
    const original = globalThis.ResizeObserver
    class ImmediateResizeObserver {
      private cb: ResizeObserverCallback
      constructor(cb: ResizeObserverCallback) {
        this.cb = cb
      }
      observe() {
        this.cb(
          [{ contentRect: { width: 624, height: 724 } } as ResizeObserverEntry],
          this as unknown as ResizeObserver,
        )
      }
      unobserve() {}
      disconnect() {}
    }
    globalThis.ResizeObserver = ImmediateResizeObserver as unknown as typeof ResizeObserver
    try {
      const w = mount(PageCanvas)
      const store = useDefinitionStore()
      store.setDocument({
        id: 'doc1',
        fileName: 'sample.pdf',
        pageCount: 1,
        pages: [{ width: 300, height: 350 }],
      })
      store.zoom = 'fit-width'
      await w.vm.$nextTick()
      expect(store.containerSize).toEqual({ width: 600, height: 700 })
      expect(store.scale).toBe(2)
      expect(w.find('svg').attributes('width')).toBe('600')
      expect(w.find('.canvas__readout').element.parentElement).not.toBe(
        w.find('.canvas__scroll').element,
      )
    } finally {
      globalThis.ResizeObserver = original
    }
  })
})
