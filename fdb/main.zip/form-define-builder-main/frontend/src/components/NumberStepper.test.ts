import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import NumberStepper from './NumberStepper.vue'

describe('NumberStepper', () => {
  it('±1 / ±10 のボタンで update:modelValue を emit する', async () => {
    const w = mount(NumberStepper, { props: { modelValue: 20 } })
    await w.find('button.minus10').trigger('click')
    await w.find('button.minus1').trigger('click')
    await w.find('button.plus1').trigger('click')
    await w.find('button.plus10').trigger('click')
    expect(w.emitted('update:modelValue')).toEqual([[10], [19], [21], [30]])
  })

  it('min 未満にはクランプし、直接入力も反映する', async () => {
    const w = mount(NumberStepper, { props: { modelValue: 5, min: 1 } })
    await w.find('button.minus10').trigger('click')
    expect(w.emitted('update:modelValue')?.at(-1)).toEqual([1])
    await w.find('input').setValue('7')
    expect(w.emitted('update:modelValue')?.at(-1)).toEqual([7])
    await w.find('input').setValue('')
    expect(w.emitted('update:modelValue')).toHaveLength(2)
  })
})
