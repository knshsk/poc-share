import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../stores/definition'
import ValidationPanel from './ValidationPanel.vue'

describe('ValidationPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('エラーが無ければ「問題ありません」', () => {
    const w = mount(ValidationPanel)
    expect(w.text()).toContain('問題ありません')
  })

  it('エラーを対象ラベル付きで列挙し、クリックで対象タブと要素を選択する', async () => {
    const store = useDefinitionStore()
    store.setDocument({ id: 'd', fileName: 'a.pdf', pageCount: 1, pages: [{ width: 300, height: 350 }] })
    store.addDplSegment()
    store.addBlock({ startX: 10, endX: 5, startLine: 1, endLine: 1 })
    store.selectedBlock = null
    store.activeTab = 'lines'
    const w = mount(ValidationPanel)

    const items = w.findAll('li')
    expect(items).toHaveLength(1)
    expect(items[0].text()).toContain('ブロック1')
    expect(items[0].text()).toContain('開始X')

    await items[0].trigger('click')
    expect(store.activeTab).toBe('blocks')
    expect(store.selectedBlock).toBe(0)
  })

  it('パラグラフのエラーは表示名でラベル付けする', () => {
    const store = useDefinitionStore()
    store.setDocument({ id: 'd', fileName: 'a.pdf', pageCount: 1, pages: [{ width: 300, height: 350 }] })
    store.addDplSegment()
    store.addParagraph()
    store.updateParagraph(0, { name: '支店' })
    store.updateDiv(0, { startX: 50, endX: 10 }) // startX >= endX -> エラー
    const w = mount(ValidationPanel)

    const items = w.findAll('li')
    expect(items.some((i) => i.text().includes('支店'))).toBe(true)
  })
})
