<script setup lang="ts">
import { useDefinitionStore, type EditorTab } from '../stores/definition'

const store = useDefinitionStore()
const TABS: { id: EditorTab; label: string }[] = [
  { id: 'lines', label: 'ライン' },
  { id: 'blocks', label: 'ブロック' },
  { id: 'paragraphs', label: 'パラグラフ' },
]
</script>

<template>
  <aside class="panel">
    <nav class="panel__tabs">
      <button
        v-for="t in TABS"
        :key="t.id"
        :class="{ active: store.activeTab === t.id }"
        @click="store.activeTab = t.id"
      >
        {{ t.label }}
      </button>
    </nav>
    <div class="panel__body">
      <slot :name="store.activeTab" />
    </div>
    <div class="panel__footer">
      <slot name="footer" />
    </div>
  </aside>
</template>

<style scoped>
.panel {
  display: flex;
  flex-direction: column;
  background: #fff;
  border-left: 1px solid #ddd;
  min-height: 0;
}
.panel__tabs {
  display: flex;
  border-bottom: 1px solid #ddd;
}
.panel__tabs button {
  flex: 1;
  padding: 8px;
  border: 0;
  background: #f4f4f4;
  cursor: pointer;
}
.panel__tabs button.active {
  background: #fff;
  font-weight: 600;
  border-bottom: 2px solid #1e64c8;
}
.panel__body {
  flex: 1;
  overflow: auto;
  padding: 12px;
  min-height: 0;
}
.panel__footer {
  border-top: 1px solid #ddd;
  max-height: 45%;
  overflow: auto;
}
</style>
