<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { pageImageUrl } from '../api/documents'
import { useDefinitionStore } from '../stores/definition'
import type { Rect } from '../model/types'

const store = useDefinitionStore()
const scroll = ref<HTMLElement | null>(null)
const svg = ref<SVGSVGElement | null>(null)
let observer: ResizeObserver | null = null

/** ページの周囲に確保する余白(表示px、片側) */
const PAGE_MARGIN = 12

// スクロール領域はドキュメント読込後に現れるので、要素の出現/消滅に合わせて観測する
watch(scroll, (el) => {
  observer?.disconnect()
  observer = null
  if (!el || typeof ResizeObserver === 'undefined') return
  observer = new ResizeObserver((entries) => {
    const { width, height } = entries[0].contentRect
    store.setContainerSize(
      Math.max(width - PAGE_MARGIN * 2, 0),
      Math.max(height - PAGE_MARGIN * 2, 0),
    )
  })
  observer.observe(el)
})
onBeforeUnmount(() => {
  observer?.disconnect()
  window.removeEventListener('mousemove', onWindowMouseMove)
  window.removeEventListener('mouseup', onWindowMouseUp)
})

const imageUrl = computed(() =>
  store.document ? pageImageUrl(store.document.id, store.currentPage) : '',
)

/** 画像1pxあたりの表示px(ストアが倍率モードとコンテナ内寸から算出) */
const scale = computed(() => store.scale)
const displayWidth = computed(() => store.pageSize.width * scale.value)
const displayHeight = computed(() => store.pageSize.height * scale.value)

// ---- 座標読み取り ----
const hover = ref<{ x: number; y: number } | null>(null)

function toImage(e: MouseEvent): { x: number; y: number } {
  const r = svg.value!.getBoundingClientRect()
  return {
    x: Math.round((e.clientX - r.left) / scale.value),
    y: Math.round((e.clientY - r.top) / scale.value),
  }
}

const hoverPageLine = computed(() => {
  if (!hover.value) return null
  const y = hover.value.y
  return store.pageLines.find((l) => y >= l.y0 && y < l.y1) ?? null
})
const hoverBlockLine = computed(() => {
  if (!hover.value) return null
  const { x, y } = hover.value
  return store.blockLines.find((l) => x >= l.x0 && x < l.x1 && y >= l.y0 && y < l.y1) ?? null
})

// ---- ドラッグ / クリック ----
const dragStart = ref<{ x: number; y: number } | null>(null)
const dragCurrent = ref<{ x: number; y: number } | null>(null)
const dragRect = computed<Rect | null>(() => {
  if (!dragStart.value || !dragCurrent.value) return null
  return {
    x0: Math.min(dragStart.value.x, dragCurrent.value.x),
    y0: Math.min(dragStart.value.y, dragCurrent.value.y),
    x1: Math.max(dragStart.value.x, dragCurrent.value.x),
    y1: Math.max(dragStart.value.y, dragCurrent.value.y),
  }
})

/** ドラッグ用: 画像範囲外に出てもページ境界にクランプした整数座標を返す */
function toImageClamped(e: MouseEvent): { x: number; y: number } {
  const p = toImage(e)
  return {
    x: Math.min(Math.max(p.x, 0), store.pageSize.width),
    y: Math.min(Math.max(p.y, 0), store.pageSize.height),
  }
}

function onMouseDown(e: MouseEvent) {
  if (e.button !== 0 || !store.document) return
  const p = toImageClamped(e)
  dragStart.value = p
  dragCurrent.value = p
  window.addEventListener('mousemove', onWindowMouseMove)
  window.addEventListener('mouseup', onWindowMouseUp)
}

function onMouseMove(e: MouseEvent) {
  if (!store.document) return
  hover.value = toImage(e)
}

function onWindowMouseMove(e: MouseEvent) {
  if (!dragStart.value) return
  dragCurrent.value = toImageClamped(e)
}

function onWindowMouseUp(e: MouseEvent) {
  window.removeEventListener('mousemove', onWindowMouseMove)
  window.removeEventListener('mouseup', onWindowMouseUp)
  if (!dragStart.value) return
  const start = dragStart.value
  const end = toImageClamped(e)
  dragStart.value = null
  dragCurrent.value = null
  const moved = Math.abs(end.x - start.x) >= 3 || Math.abs(end.y - start.y) >= 3
  if (moved) onDragEnd({ x0: start.x, y0: start.y, x1: end.x, y1: end.y })
  else onClick(end)
}

function onMouseLeave() {
  hover.value = null
}

function onClick(p: { x: number; y: number }) {
  if (store.activeTab === 'lines') {
    const line = store.pageLines.find((l) => p.y >= l.y0 && p.y < l.y1)
    if (line) store.addDplSegmentAtLine(line.n)
  }
}

function onDragEnd(rect: Rect) {
  if (store.activeTab === 'blocks') {
    store.addBlockFromRect(rect)
  } else if (store.activeTab === 'paragraphs' && store.selectedParagraph !== null) {
    store.setDivRange(store.selectedParagraph, rect.x0, rect.x1)
  }
}
</script>

<template>
  <section class="canvas">
    <div v-if="!store.document" class="canvas__empty">PDFを選択して「読込」を押してください</div>
    <template v-else>
      <div class="canvas__readout">
        <span v-if="hover">X: {{ hover.x }} Y: {{ hover.y }}</span>
        <span v-if="hoverPageLine">ページライン: {{ hoverPageLine.n }}</span>
        <span v-if="hoverBlockLine">ブロック通し: {{ hoverBlockLine.n }}</span>
      </div>
      <div ref="scroll" class="canvas__scroll">
      <div
        class="canvas__page"
        :style="{ width: displayWidth + 'px', height: displayHeight + 'px' }"
      >
        <img :src="imageUrl" :width="displayWidth" :height="displayHeight" draggable="false">
        <svg
          ref="svg"
          class="canvas__overlay"
          :viewBox="`0 0 ${store.pageSize.width} ${store.pageSize.height}`"
          :width="displayWidth"
          :height="displayHeight"
          @mousedown.prevent="onMouseDown"
          @mousemove="onMouseMove"
          @mouseleave="onMouseLeave"
        >
          <slot :scale="scale" />
          <rect
            v-if="dragRect"
            class="canvas__drag"
            :x="dragRect.x0"
            :y="dragRect.y0"
            :width="dragRect.x1 - dragRect.x0"
            :height="dragRect.y1 - dragRect.y0"
            vector-effect="non-scaling-stroke"
          />
        </svg>
      </div>
      </div>
    </template>
  </section>
</template>

<style scoped>
.canvas {
  display: flex;
  flex-direction: column;
  min-height: 0;
  background: #e9e9e9;
}
.canvas__scroll {
  flex: 1;
  min-height: 0;
  overflow: auto;
}
.canvas__empty {
  color: #666;
  padding: 40px;
  text-align: center;
}
.canvas__readout {
  display: flex;
  gap: 16px;
  padding: 4px 8px;
  background: rgba(255, 255, 255, 0.9);
  border-bottom: 1px solid #ddd;
  font-variant-numeric: tabular-nums;
  min-height: 26px;
}
.canvas__page {
  position: relative;
  margin: 12px;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
}
.canvas__page img {
  display: block;
  user-select: none;
}
.canvas__overlay {
  position: absolute;
  inset: 0;
  cursor: crosshair;
}
.canvas__drag {
  fill: rgba(30, 100, 200, 0.15);
  stroke: #1e64c8;
  stroke-width: 1;
  stroke-dasharray: 4 2;
}
</style>
