<script setup lang="ts">
const props = withDefaults(defineProps<{ modelValue: number; min?: number }>(), {
  min: Number.NEGATIVE_INFINITY,
})
const emit = defineEmits<{ 'update:modelValue': [value: number] }>()

function set(value: number) {
  emit('update:modelValue', Math.max(props.min, value))
}

function onInput(e: Event) {
  const raw = (e.target as HTMLInputElement).value.trim()
  if (raw === '') return
  const n = Number(raw)
  if (Number.isInteger(n)) set(n)
}
</script>

<template>
  <span class="stepper">
    <button class="minus10" type="button" title="-10" @click="set(modelValue - 10)">−10</button>
    <button class="minus1" type="button" title="-1" @click="set(modelValue - 1)">−1</button>
    <input type="number" :value="modelValue" :min="Number.isFinite(min) ? min : undefined" @input="onInput">
    <button class="plus1" type="button" title="+1" @click="set(modelValue + 1)">+1</button>
    <button class="plus10" type="button" title="+10" @click="set(modelValue + 10)">+10</button>
  </span>
</template>

<style scoped>
.stepper {
  display: inline-flex;
  align-items: center;
  gap: 2px;
}
.stepper input {
  width: 4.5em;
  text-align: right;
}
.stepper button {
  padding: 2px 4px;
  font-size: 11px;
  line-height: 1.2;
}
</style>
