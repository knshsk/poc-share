<script setup lang="ts">
import { paragraphDisplayName } from '../model/paragraphs'
import type { ValidationError } from '../model/types'
import { useDefinitionStore } from '../stores/definition'

const store = useDefinitionStore()

function label(e: ValidationError): string {
  const n = e.index === null ? '' : String(e.index + 1)
  if (e.target === 'dpl') return e.index === null ? 'DPL' : `DPL ${n}`
  if (e.target === 'block') return `ブロック${n}`
  const p = e.index !== null ? store.definition.paragraphs[e.index] : undefined
  if (p !== undefined && e.index !== null) return paragraphDisplayName(p, e.index)
  return `パラグラフ${n}`
}

function focus(e: ValidationError) {
  if (e.target === 'dpl') store.activeTab = 'lines'
  if (e.target === 'block') {
    store.activeTab = 'blocks'
    store.selectedBlock = e.index
  }
  if (e.target === 'paragraph') {
    store.activeTab = 'paragraphs'
    store.selectedParagraph = e.index
  }
}
</script>

<template>
  <section class="validation">
    <h3>検証結果</h3>
    <p v-if="store.errors.length === 0" class="ok">問題ありません</p>
    <ul v-else>
      <li v-for="(e, i) in store.errors" :key="i" @click="focus(e)">
        <span class="target">{{ label(e) }}</span>
        <span>{{ e.message }}</span>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.validation {
  padding: 8px 12px;
}
.validation h3 {
  margin: 0 0 4px;
  font-size: 13px;
}
.ok {
  color: #1f7a33;
  margin: 0;
}
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
li {
  display: flex;
  gap: 8px;
  padding: 3px 0;
  color: #b3261e;
  cursor: pointer;
}
.target {
  font-weight: 600;
  white-space: nowrap;
}
</style>
