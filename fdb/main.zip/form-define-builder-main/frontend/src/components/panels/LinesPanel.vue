<script setup lang="ts">
import { useDefinitionStore } from '../../stores/definition'
import DplSegmentRow from './DplSegmentRow.vue'

const store = useDefinitionStore()

</script>

<template>
  <div class="lines">
    <p class="hint">
      DPL,&lt;開始ライン&gt;,&lt;ドット数...&gt;。キャンバス上のラインをクリックすると、そのラインから始まる新しいDPL行を追加します。ラインの下辺をドラッグするとドット数を調整できます。
    </p>
    <table v-if="store.definition.dpl.length" class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>開始ライン</th>
          <th>ドット数(複数あればサイクリック)</th>
          <th />
        </tr>
      </thead>
      <tbody>
        <DplSegmentRow
          v-for="(seg, i) in store.definition.dpl"
          :key="i"
          :segment="seg"
          :index="i"
          @update:startLine="(n) => store.updateDplSegment(i, { startLine: n })"
          @update:dots="(d) => store.updateDplSegment(i, { dots: d })"
          @remove="store.removeDplSegment(i)"
        />
      </tbody>
    </table>
    <button @click="store.addDplSegment()">DPL行を追加</button>
    <p class="summary">ページ内ライン数: {{ store.pageLines.length }}</p>
  </div>
</template>

<style scoped>
.hint,
.summary {
  color: #666;
  font-size: 12px;
}
.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 8px;
}
.table th,
.table td {
  padding: 4px;
  border-bottom: 1px solid #eee;
  text-align: left;
}
</style>
