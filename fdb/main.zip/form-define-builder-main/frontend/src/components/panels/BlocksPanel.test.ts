import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../../stores/definition'
import BlocksPanel from './BlocksPanel.vue'

describe('BlocksPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('ブロック一覧を表示し、行クリックで選択、数値編集でストアが更新される', async () => {
    const store = useDefinitionStore()
    store.addBlock({ startX: 0, endX: 150, startLine: 4, endLine: 11 })
    store.addBlock({ startX: 150, endX: 300, startLine: 4, endLine: 11 })
    store.selectedBlock = null
    const w = mount(BlocksPanel)

    const rows = w.findAll('tbody tr')
    expect(rows).toHaveLength(2)
    await rows[1].trigger('click')
    expect(store.selectedBlock).toBe(1)
    expect(rows[1].classes()).toContain('selected')

    await rows[0].find('input.endX').setValue('120')
    expect(store.definition.blocks[0].endX).toBe(120)
  })

  it('上下ボタンと削除', async () => {
    const store = useDefinitionStore()
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 })
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 })
    const w = mount(BlocksPanel)

    await w.findAll('tbody tr')[1].find('button.up').trigger('click')
    expect(store.definition.blocks[0].startX).toBe(20)

    await w.findAll('tbody tr')[0].find('button.remove').trigger('click')
    expect(store.definition.blocks).toHaveLength(1)
    expect(store.definition.blocks[0].startX).toBe(0)
  })
})
