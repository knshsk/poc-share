<script setup lang="ts">
import type { DplSegment } from '../../model/types'
import NumberStepper from '../NumberStepper.vue'

const props = defineProps<{ segment: DplSegment; index: number }>()
const emit = defineEmits<{
  'update:startLine': [n: number]
  'update:dots': [dots: number[]]
  remove: []
}>()

function setDot(i: number, value: number) {
  const dots = [...props.segment.dots]
  dots[i] = value
  emit('update:dots', dots)
}

function addDot() {
  const dots = props.segment.dots
  emit('update:dots', [...dots, dots[dots.length - 1] ?? 1])
}

function removeDot(i: number) {
  if (props.segment.dots.length <= 1) return
  emit('update:dots', props.segment.dots.filter((_, k) => k !== i))
}

function onStartInput(e: Event) {
  const n = Number((e.target as HTMLInputElement).value)
  if (Number.isInteger(n)) emit('update:startLine', n)
}
</script>

<template>
  <tr class="row">
    <td>{{ index + 1 }}</td>
    <td>
      <input class="start" type="number" min="1" :value="segment.startLine" @input="onStartInput">
    </td>
    <td>
      <div class="dots">
        <span v-for="(d, i) in segment.dots" :key="i" class="dot">
          <NumberStepper :model-value="d" :min="1" @update:model-value="(v) => setDot(i, v)" />
          <button
            class="remove-dot"
            type="button"
            title="この要素を削除"
            :disabled="segment.dots.length <= 1"
            @click="removeDot(i)"
          >
            ×
          </button>
        </span>
        <button class="add-dot" type="button" title="要素を追加(サイクリック)" @click="addDot">
          +
        </button>
      </div>
    </td>
    <td>
      <button class="remove" title="削除" @click="emit('remove')">✕</button>
    </td>
  </tr>
</template>

<style scoped>
.start {
  width: 5em;
}
.dots {
  display: flex;
  flex-direction: column;
  gap: 4px;
  align-items: flex-start;
}
.dot {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.remove-dot,
.add-dot {
  padding: 2px 6px;
  font-size: 11px;
}
</style>
