import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../../stores/definition'
import ParagraphsPanel from './ParagraphsPanel.vue'

describe('ParagraphsPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('追加すると一覧に Paragraph1 が出て選択され、フォームが表示される', async () => {
    const store = useDefinitionStore()
    const w = mount(ParagraphsPanel)
    await w.find('button.add').trigger('click')
    expect(store.definition.paragraphs).toHaveLength(1)
    expect(w.find('li').text()).toContain('Paragraph1')
    expect(w.find('form').exists()).toBe(true)
  })

  it('終了ラインは E<n> をパースし、不正なら invalid でストアを変えない', async () => {
    const store = useDefinitionStore()
    store.addParagraph()
    const w = mount(ParagraphsPanel)

    await w.find('input.endLine').setValue('E2')
    expect(store.definition.paragraphs[0].endLine).toEqual({ kind: 'fromEnd', n: 2 })

    await w.find('input.endLine').setValue('zzz')
    expect(store.definition.paragraphs[0].endLine).toEqual({ kind: 'fromEnd', n: 2 })
    expect(w.find('input.endLine').classes()).toContain('invalid')
  })

  it('名前・比較条件・同値継続・DEL_BACKWARD_SPACE がストアに反映される', async () => {
    const store = useDefinitionStore()
    store.addParagraph()
    const w = mount(ParagraphsPanel)

    await w.find('input.name').setValue('支店')
    await w.find('select.cond').setValue('A')
    await w.find('select.sameContinue').setValue('Y')
    await w.find('input.delBackwardSpace').setValue(true)

    const p = store.definition.paragraphs[0]
    expect(p.name).toBe('支店')
    expect(p.div.cond).toBe('A')
    expect(p.div.sameContinue).toBe('Y')
    expect(p.delBackwardSpace).toBe(true)
    expect(w.find('li').text()).toContain('支店')
  })

  it('入れ子はインデントで表現される', () => {
    const store = useDefinitionStore()
    store.addParagraph()
    store.addParagraph()
    const w = mount(ParagraphsPanel)
    const items = w.findAll('li')
    expect(items[0].attributes('style')).toContain('padding-left: 0px')
    expect(items[1].attributes('style')).toContain('padding-left: 16px')
  })
})

describe('ParagraphsPanel: DIV X のステッパー', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('開始X / 終了X の ±ボタンがストアに反映され、0 未満にならない', async () => {
    const store = useDefinitionStore()
    store.addParagraph()
    store.updateDiv(0, { startX: 5, endX: 100 })
    const w = mount(ParagraphsPanel)

    await w.find('.divStartX button.plus10').trigger('click')
    expect(store.definition.paragraphs[0].div.startX).toBe(15)
    await w.find('.divEndX button.minus1').trigger('click')
    expect(store.definition.paragraphs[0].div.endX).toBe(99)
    await w.find('.divStartX button.minus10').trigger('click')
    await w.find('.divStartX button.minus10').trigger('click')
    expect(store.definition.paragraphs[0].div.startX).toBe(0)
    await w.find('.divEndX input').setValue('250')
    expect(store.definition.paragraphs[0].div.endX).toBe(250)
  })
})
