import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../../stores/definition'
import LinesPanel from './LinesPanel.vue'

describe('LinesPanel', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('行の ±ボタンがストアの dots を更新し、削除後も残りの行が正しいセグメントを指す', async () => {
    const store = useDefinitionStore()
    store.addDplSegment()
    store.addDplSegment()
    store.updateDplSegment(1, { dots: [23, 22] })

    const w = mount(LinesPanel)
    const rows = () => w.findAll('tbody tr')
    expect(rows()).toHaveLength(2)

    await rows()[1].findAll('.dot')[1].find('button.plus1').trigger('click')
    expect(store.definition.dpl[1].dots).toEqual([23, 23])

    await rows()[0].find('button.remove').trigger('click')
    expect(rows()).toHaveLength(1)
    expect(store.definition.dpl).toEqual([{ startLine: 2, dots: [23, 23] }])
    await rows()[0].findAll('.dot')[0].find('button.minus10').trigger('click')
    expect(store.definition.dpl[0].dots).toEqual([13, 23])
  })
})
