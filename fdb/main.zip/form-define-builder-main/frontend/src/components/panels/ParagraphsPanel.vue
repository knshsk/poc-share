<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { paragraphDisplayName } from '../../model/paragraphs'
import { formatLineRef, parseLineRef } from '../../model/parse'
import { DIV_CONDS, type DivCond } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'
import NumberStepper from '../NumberStepper.vue'

const store = useDefinitionStore()

const selected = computed(() =>
  store.selectedParagraph === null ? null : store.definition.paragraphs[store.selectedParagraph] ?? null,
)
const selectedIndex = computed(() => store.selectedParagraph)

// 終了ラインはテキスト入力をローカルに持ち、パースできたときだけストアへ
const endLineText = ref('')
const endLineInvalid = ref(false)
watch(
  () => [selectedIndex.value, selected.value?.endLine] as const,
  () => {
    endLineText.value = selected.value ? formatLineRef(selected.value.endLine) : ''
    endLineInvalid.value = false
  },
  { immediate: true, deep: true },
)

function num(e: Event): number | null {
  const v = (e.target as HTMLInputElement).value.trim()
  if (v === '') return null
  const n = Number(v)
  return Number.isInteger(n) ? n : null
}

function onStartLine(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, { startLine: num(e) })
}

function onEndLine(e: Event) {
  if (selectedIndex.value === null) return
  endLineText.value = (e.target as HTMLInputElement).value
  const r = parseLineRef(endLineText.value)
  endLineInvalid.value = !r.ok
  if (r.ok) store.updateParagraph(selectedIndex.value, { endLine: r.value })
}

function onName(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, { name: (e.target as HTMLInputElement).value })
}

function onSpanPage(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, { spanPage: (e.target as HTMLInputElement).checked })
}

function onDelBackwardSpace(e: Event) {
  if (selectedIndex.value === null) return
  store.updateParagraph(selectedIndex.value, {
    delBackwardSpace: (e.target as HTMLInputElement).checked,
  })
}

function onDivValue(e: Event) {
  if (selectedIndex.value === null) return
  store.updateDiv(selectedIndex.value, { value: (e.target as HTMLInputElement).value })
}

function onDivCond(e: Event) {
  if (selectedIndex.value === null) return
  store.updateDiv(selectedIndex.value, { cond: (e.target as HTMLSelectElement).value as DivCond })
}

function onDivX(key: 'startX' | 'endX', value: number) {
  if (selectedIndex.value === null) return
  store.updateDiv(selectedIndex.value, { [key]: value })
}

function onSameContinue(e: Event) {
  if (selectedIndex.value === null) return
  const v = (e.target as HTMLSelectElement).value
  store.updateDiv(selectedIndex.value, { sameContinue: v === '' ? null : (v as 'Y' | 'N') })
}
</script>

<template>
  <div class="paragraphs">
    <p class="hint">
      配列順がそのまま親→子→孫の入れ子になります。選択中のパラグラフに対して、キャンバス上を横にドラッグするとDIVのX範囲が入ります。
    </p>
    <ul class="list">
      <li
        v-for="(p, i) in store.definition.paragraphs"
        :key="i"
        :class="{ selected: store.selectedParagraph === i, error: store.resolvedParagraphs[i]?.error }"
        :style="{ paddingLeft: i * 16 + 'px' }"
        @click="store.selectedParagraph = i"
      >
        <span class="name">{{ paragraphDisplayName(p, i) }}</span>
        <span class="range">
          {{ store.resolvedParagraphs[i]?.first }}〜{{ store.resolvedParagraphs[i]?.last }}
        </span>
        <span class="actions">
          <button title="上へ" :disabled="i === 0" @click.stop="store.moveParagraph(i, -1)">▲</button>
          <button
            title="下へ"
            :disabled="i === store.definition.paragraphs.length - 1"
            @click.stop="store.moveParagraph(i, 1)"
          >
            ▼
          </button>
          <button title="削除" @click.stop="store.removeParagraph(i)">✕</button>
        </span>
      </li>
    </ul>
    <button class="add" @click="store.addParagraph()">パラグラフを追加</button>

    <form v-if="selected && selectedIndex !== null" class="form" @submit.prevent>
      <h3>{{ paragraphDisplayName(selected, selectedIndex) }}</h3>
      <label>
        <span>開始ライン(親内)</span>
        <input class="startLine" type="number" min="1" :value="selected.startLine ?? ''" placeholder="1" @input="onStartLine">
      </label>
      <label>
        <span>終了ライン(親内 / E&lt;n&gt;)</span>
        <input
          class="endLine"
          :class="{ invalid: endLineInvalid }"
          type="text"
          :value="endLineText"
          placeholder="親の最終ライン"
          @input="onEndLine"
        >
      </label>
      <label>
        <span>パラグラフ名</span>
        <input class="name" type="text" :value="selected.name" :placeholder="`Paragraph${selectedIndex + 1}`" @input="onName">
      </label>
      <label class="check">
        <input type="checkbox" :checked="selected.spanPage" @change="onSpanPage">
        <span>ページ跨り(Y)</span>
      </label>

      <fieldset>
        <legend>DIV</legend>
        <label>
          <span>比較値</span>
          <input class="divValue" type="text" :value="selected.div.value" @input="onDivValue">
        </label>
        <label>
          <span>比較条件</span>
          <select class="cond" :value="selected.div.cond" @change="onDivCond">
            <option v-for="c in DIV_CONDS" :key="c.value" :value="c.value">{{ c.label }}</option>
          </select>
        </label>
        <label>
          <span>開始X</span>
          <NumberStepper class="divStartX" :model-value="selected.div.startX" :min="0" @update:model-value="(v) => onDivX('startX', v)" />
        </label>
        <label>
          <span>終了X</span>
          <NumberStepper class="divEndX" :model-value="selected.div.endX" :min="0" @update:model-value="(v) => onDivX('endX', v)" />
        </label>
        <label>
          <span>同値継続</span>
          <select class="sameContinue" :value="selected.div.sameContinue ?? ''" @change="onSameContinue">
            <option value="">未指定(N)</option>
            <option value="Y">Y: 同じパラグラフ</option>
            <option value="N">N: 別パラグラフ</option>
          </select>
        </label>
      </fieldset>

      <label class="check">
        <input class="delBackwardSpace" type="checkbox" :checked="selected.delBackwardSpace" @change="onDelBackwardSpace">
        <span>DEL_BACKWARD_SPACE(末尾の空白ラインを除く)</span>
      </label>
    </form>
  </div>
</template>

<style scoped>
.hint {
  color: #666;
  font-size: 12px;
}
.list {
  list-style: none;
  margin: 0 0 8px;
  padding: 0;
}
.list li {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
}
.list li.selected {
  background: #fdf1e3;
}
.list li.error .name {
  color: #b3261e;
}
.list .name {
  flex: 1;
}
.list .range {
  color: #666;
  font-size: 12px;
}
.form {
  margin-top: 12px;
  display: grid;
  gap: 8px;
}
.form h3 {
  margin: 0;
  font-size: 14px;
}
.form label {
  display: grid;
  grid-template-columns: 9em 1fr;
  align-items: center;
  gap: 6px;
}
.form label.check {
  grid-template-columns: auto 1fr;
}
.form fieldset {
  display: grid;
  gap: 6px;
  border: 1px solid #ddd;
}
.invalid {
  border-color: #b3261e;
  background: #fdecea;
}
</style>
