<script setup lang="ts">
import type { Block } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const store = useDefinitionStore()

const FIELDS: { key: keyof Block; label: string }[] = [
  { key: 'startX', label: '開始X' },
  { key: 'endX', label: '終了X' },
  { key: 'startLine', label: '開始ライン' },
  { key: 'endLine', label: '終了ライン' },
]

function onInput(i: number, key: keyof Block, e: Event) {
  const n = Number((e.target as HTMLInputElement).value)
  if (Number.isInteger(n)) store.updateBlock(i, { [key]: n })
}
</script>

<template>
  <div class="blocks">
    <p class="hint">
      キャンバス上でドラッグすると矩形からブロックを追加します(Yはラインにスナップ)。順序がブロック番号になります。
    </p>
    <table v-if="store.definition.blocks.length" class="table">
      <thead>
        <tr>
          <th>#</th>
          <th v-for="f in FIELDS" :key="f.key">{{ f.label }}</th>
          <th />
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(b, i) in store.definition.blocks"
          :key="i"
          :class="{ selected: store.selectedBlock === i }"
          @click="store.selectedBlock = i"
        >
          <td>{{ i + 1 }}</td>
          <td v-for="f in FIELDS" :key="f.key">
            <input
              :class="f.key"
              type="number"
              min="0"
              :value="b[f.key]"
              @input="onInput(i, f.key, $event)"
              @click.stop
            >
          </td>
          <td class="actions">
            <button class="up" title="上へ" :disabled="i === 0" @click.stop="store.moveBlock(i, -1)">▲</button>
            <button
              class="down"
              title="下へ"
              :disabled="i === store.definition.blocks.length - 1"
              @click.stop="store.moveBlock(i, 1)"
            >
              ▼
            </button>
            <button class="remove" title="削除" @click.stop="store.removeBlock(i)">✕</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else class="hint">ブロック未指定の場合、ページ全体が1つのブロックになります。</p>
    <p class="summary">ブロック通しライン数: {{ store.blockLines.length }}</p>
  </div>
</template>

<style scoped>
.hint,
.summary {
  color: #666;
  font-size: 12px;
}
.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 8px;
}
.table th,
.table td {
  padding: 4px 2px;
  border-bottom: 1px solid #eee;
  text-align: left;
}
.table tbody tr {
  cursor: pointer;
}
.table tbody tr.selected {
  background: #e8f1fc;
}
.table input {
  width: 4.5em;
}
.actions {
  white-space: nowrap;
}
</style>
