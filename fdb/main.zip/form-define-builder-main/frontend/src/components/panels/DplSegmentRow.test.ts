import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import DplSegmentRow from './DplSegmentRow.vue'

describe('DplSegmentRow', () => {
  it('dots の要素ごとに数値欄を表示する', () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 17, dots: [23, 22] }, index: 1 } })
    const inputs = w.findAll('.dot input')
    expect(inputs.map((i) => (i.element as HTMLInputElement).value)).toEqual(['23', '22'])
    expect((w.find('input.start').element as HTMLInputElement).value).toBe('17')
  })

  it('要素の ±ボタンは その要素だけを変えた配列を emit する', async () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 17, dots: [23, 22] }, index: 1 } })
    await w.findAll('.dot')[1].find('button.plus10').trigger('click')
    expect(w.emitted('update:dots')?.at(-1)).toEqual([[23, 32]])
    await w.findAll('.dot')[0].find('button.minus1').trigger('click')
    expect(w.emitted('update:dots')?.at(-1)).toEqual([[22, 22]])
  })

  it('要素は 1 未満にならない', async () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 1, dots: [5] }, index: 0 } })
    await w.find('.dot button.minus10').trigger('click')
    expect(w.emitted('update:dots')?.at(-1)).toEqual([[1]])
  })

  it('要素の追加は末尾の値を複製し、削除は1要素のときは不可', async () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 1, dots: [80] }, index: 0 } })
    expect((w.find('.dot button.remove-dot').element as HTMLButtonElement).disabled).toBe(true)
    await w.find('button.add-dot').trigger('click')
    expect(w.emitted('update:dots')?.at(-1)).toEqual([[80, 80]])

    const w2 = mount(DplSegmentRow, { props: { segment: { startLine: 1, dots: [23, 22] }, index: 0 } })
    await w2.findAll('.dot')[0].find('button.remove-dot').trigger('click')
    expect(w2.emitted('update:dots')?.at(-1)).toEqual([[22]])
  })

  it('開始ラインの変更と削除を emit する', async () => {
    const w = mount(DplSegmentRow, { props: { segment: { startLine: 1, dots: [80] }, index: 0 } })
    await w.find('input.start').setValue('5')
    expect(w.emitted('update:startLine')?.at(-1)).toEqual([5])
    await w.find('button.remove').trigger('click')
    expect(w.emitted('remove')).toHaveLength(1)
  })
})
