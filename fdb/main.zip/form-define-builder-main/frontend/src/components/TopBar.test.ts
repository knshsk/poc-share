import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { uploadDocument } from '../api/documents'
import { useDefinitionStore } from '../stores/definition'
import TopBar from './TopBar.vue'

vi.mock('../api/documents', () => ({
  uploadDocument: vi.fn(async () => ({
    id: 'doc1',
    page_count: 3,
    pages: [
      { width: 100, height: 200 },
      { width: 100, height: 200 },
      { width: 100, height: 200 },
    ],
  })),
  pageImageUrl: (id: string, n: number) => `/api/documents/${id}/pages/${n}`,
}))

describe('TopBar', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('DPI初期値は720で、ファイル未選択なら読込ボタンは無効', () => {
    const w = mount(TopBar)
    expect((w.find('input[type="number"]').element as HTMLInputElement).value).toBe('720')
    expect((w.find('button.load').element as HTMLButtonElement).disabled).toBe(true)
  })

  it('読込成功でストアにドキュメントが入りページ数が表示される', async () => {
    const w = mount(TopBar)
    const store = useDefinitionStore()
    const input = w.find('input[type="file"]')
    const file = new File([new Uint8Array([1, 2, 3])], 'sample.pdf', { type: 'application/pdf' })
    Object.defineProperty(input.element, 'files', { value: [file] })
    await input.trigger('change')
    await w.find('button.load').trigger('click')
    await vi.waitFor(() => expect(store.document?.pageCount).toBe(3))
    expect(store.document?.fileName).toBe('sample.pdf')
    expect(w.text()).toContain('1 / 3')
  })

  it('画像サイズが変わる再読込は確認し、キャンセルなら元の定義とドキュメントを保つ', async () => {
    const w = mount(TopBar)
    const store = useDefinitionStore()
    store.setDocument({ id: 'doc0', fileName: 'orig.pdf', pageCount: 1, pages: [{ width: 100, height: 200 }] })
    store.addDplSegment()
    vi.mocked(uploadDocument).mockResolvedValueOnce({
      id: 'doc1',
      page_count: 1,
      pages: [{ width: 999, height: 999 }],
    })
    vi.spyOn(window, 'confirm').mockReturnValue(false)
    const input = w.find('input[type="file"]')
    Object.defineProperty(input.element, 'files', { value: [new File([], 'a.pdf')] })
    await input.trigger('change')
    await w.find('button.load').trigger('click')
    await vi.waitFor(() => expect(uploadDocument).toHaveBeenCalled())
    expect(store.document?.id).toBe('doc0')
    expect(store.definition.dpl).toHaveLength(1)
  })
})

describe('TopBar: 倍率', () => {
  beforeEach(() => setActivePinia(createPinia()))

  async function loaded() {
    const w = mount(TopBar)
    const store = useDefinitionStore()
    store.setDocument({ id: 'd', fileName: 'a.pdf', pageCount: 1, pages: [{ width: 200, height: 400 }] })
    store.setContainerSize(100, 100)
    await w.vm.$nextTick()
    return { w, store }
  }

  it('プリセットボタンで幅/高さに合わせる・100% を切り替える', async () => {
    const { w, store } = await loaded()
    await w.find('button.zoom-fit-height').trigger('click')
    expect(store.zoom).toBe('fit-height')
    await w.find('button.zoom-100').trigger('click')
    expect(store.zoom).toBe(100)
    await w.find('button.zoom-fit-width').trigger('click')
    expect(store.zoom).toBe('fit-width')
  })

  it('スライダーと数値欄は実効倍率を表示し、操作すると数値モードになる', async () => {
    const { w, store } = await loaded()
    // 既定は高さに合わせる: 100 / 400 = 25%
    expect((w.find('input.zoom-slider').element as HTMLInputElement).value).toBe('25')
    expect((w.find('input.zoom-value').element as HTMLInputElement).value).toBe('25')
    await w.find('input.zoom-slider').setValue('35')
    expect(store.zoom).toBe(35)
    await w.find('input.zoom-value').setValue('120')
    expect(store.zoom).toBe(100)
    expect(w.find('select').exists()).toBe(false)
  })
})
