<script setup lang="ts">
import { ref } from 'vue'
import { uploadDocument } from '../api/documents'
import { useDefinitionStore, ZOOM_MAX, ZOOM_MIN } from '../stores/definition'
import { downloadText } from '../utils/download'

const store = useDefinitionStore()
const file = ref<File | null>(null)
const dpi = ref(720)
const loading = ref(false)
const error = ref('')

function onFileChange(e: Event) {
  file.value = (e.target as HTMLInputElement).files?.[0] ?? null
}

async function load() {
  if (!file.value) return
  loading.value = true
  error.value = ''
  try {
    const res = await uploadDocument(file.value, dpi.value)
    const proceed =
      store.sameGeometry(res.pages) ||
      store.isDefinitionEmpty ||
      window.confirm('画像サイズが変わるため、現在の定義をクリアして読み込みます。よろしいですか？')
    if (!proceed) return
    store.setDocument({
      id: res.id,
      fileName: file.value.name,
      pageCount: res.page_count,
      pages: res.pages,
    })
  } catch (e) {
    error.value = e instanceof Error ? e.message : String(e)
  } finally {
    loading.value = false
  }
}

function download() {
  const base = store.document?.fileName.replace(/\.[^.]+$/, '') ?? 'form'
  downloadText(`${base}.txt`, store.outputText)
}

function onZoomInput(e: Event) {
  const v = Number((e.target as HTMLInputElement).value)
  if (Number.isFinite(v)) store.setZoomPercent(v)
}
</script>

<template>
  <header class="topbar">
    <div class="topbar__row">
      <label class="field">
        <span>PDF</span>
        <input type="file" accept="application/pdf,.pdf" @change="onFileChange">
      </label>
      <label class="field">
        <span>DPI</span>
        <input v-model.number="dpi" type="number" min="36" max="1200" step="1">
      </label>
      <button class="load" :disabled="!file || loading" @click="load">
        {{ loading ? '変換中…' : '読込' }}
      </button>

      <template v-if="store.document">
        <span class="sep" />
        <button :disabled="store.currentPage <= 1" @click="store.setPage(store.currentPage - 1)">
          ◀
        </button>
        <span class="page">{{ store.currentPage }} / {{ store.document.pageCount }}</span>
        <button
          :disabled="store.currentPage >= store.document.pageCount"
          @click="store.setPage(store.currentPage + 1)"
        >
          ▶
        </button>
        <span class="field zoom">
          <span>倍率</span>
          <button
            class="zoom-fit-width"
            :class="{ active: store.zoom === 'fit-width' }"
            @click="store.zoom = 'fit-width'"
          >
            幅に合わせる
          </button>
          <button
            class="zoom-fit-height"
            :class="{ active: store.zoom === 'fit-height' }"
            @click="store.zoom = 'fit-height'"
          >
            高さに合わせる
          </button>
          <button class="zoom-100" :class="{ active: store.zoom === 100 }" @click="store.zoom = 100">
            100%
          </button>
          <input
            class="zoom-slider"
            type="range"
            :min="ZOOM_MIN"
            :max="ZOOM_MAX"
            step="1"
            :value="store.zoomPercent"
            @input="onZoomInput"
          >
          <input
            class="zoom-value"
            type="number"
            :min="ZOOM_MIN"
            :max="ZOOM_MAX"
            step="1"
            :value="store.zoomPercent"
            @change="onZoomInput"
          >
          <span>%</span>
        </span>
        <span class="file">{{ store.document.fileName }}</span>
      </template>

      <span class="spacer" />
      <button class="download" :disabled="!store.canDownload" @click="download">
        定義ファイルをダウンロード
      </button>
    </div>
    <div v-if="error" class="topbar__error">{{ error }}</div>
  </header>
</template>

<style scoped>
.topbar {
  background: #fff;
  border-bottom: 1px solid #ddd;
}
.topbar__row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 12px;
  flex-wrap: wrap;
}
.field {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.field input[type='number'] {
  width: 5em;
}
.zoom button.active {
  font-weight: 600;
  border-color: #1e64c8;
}
.zoom-slider {
  width: 120px;
}
.sep {
  width: 1px;
  height: 20px;
  background: #ddd;
}
.page {
  min-width: 4em;
  text-align: center;
}
.file {
  color: #666;
}
.spacer {
  flex: 1;
}
.download {
  font-weight: 600;
}
.topbar__error {
  padding: 6px 12px;
  background: #fdecea;
  color: #b3261e;
}
</style>
