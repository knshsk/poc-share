<script setup lang="ts">
import { computed } from 'vue'
import type { Rect } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const props = defineProps<{ scale: number; dim: boolean }>()
const store = useDefinitionStore()

const fontSize = computed(() => 12 / props.scale)

/** 入れ子の深さぶんだけ内側に寄せる */
function inset(r: Rect, depth: number): Rect {
  const d = (depth * 4) / props.scale
  return { x0: r.x0 + d, y0: r.y0 + d, x1: r.x1 - d, y1: r.y1 - d }
}
</script>

<template>
  <g class="paragraphs" :class="{ dim }">
    <g
      v-for="rp in store.resolvedParagraphs"
      :key="rp.index"
      :class="{ selected: store.selectedParagraph === rp.index, error: rp.error }"
      @click.stop="store.selectedParagraph = rp.index"
    >
      <rect
        v-for="(r, i) in rp.rects.map((x) => inset(x, rp.index))"
        :key="'band' + i"
        class="band"
        :x="r.x0"
        :y="r.y0"
        :width="Math.max(r.x1 - r.x0, 0)"
        :height="Math.max(r.y1 - r.y0, 0)"
        vector-effect="non-scaling-stroke"
      />
      <rect
        v-for="(r, i) in rp.divRects.map((x) => inset(x, rp.index))"
        :key="'div' + i"
        class="div"
        :x="r.x0"
        :y="r.y0"
        :width="Math.max(r.x1 - r.x0, 0)"
        :height="Math.max(r.y1 - r.y0, 0)"
        vector-effect="non-scaling-stroke"
      />
      <text
        v-if="rp.rects[0]"
        class="label"
        :x="rp.rects[0].x0 + (6 + rp.index * 4) / scale"
        :y="rp.rects[0].y0 + fontSize * 1.2 + (rp.index * 4) / scale"
        :font-size="fontSize"
      >
        {{ rp.name }} ({{ rp.first }}〜{{ rp.last }})
      </text>
    </g>
  </g>
</template>

<style scoped>
.paragraphs .band {
  fill: rgba(217, 119, 6, 0.1);
  stroke: #d97706;
  stroke-width: 1.5;
  cursor: pointer;
}
.paragraphs .div {
  fill: rgba(217, 119, 6, 0.15);
  stroke: #b45309;
  stroke-width: 2.5;
  pointer-events: none;
}
.paragraphs .selected .band {
  fill: rgba(217, 119, 6, 0.2);
  stroke-width: 3;
}
.paragraphs .error .band,
.paragraphs .error .div {
  stroke: #d0021b;
}
.paragraphs .label {
  fill: #92400e;
  font-weight: 600;
  pointer-events: none;
}
.paragraphs.dim {
  opacity: 0.3;
  pointer-events: none;
}
</style>
