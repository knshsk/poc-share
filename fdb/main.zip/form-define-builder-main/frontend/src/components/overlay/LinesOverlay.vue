<script setup lang="ts">
import { computed, onBeforeUnmount } from 'vue'
import type { PageLine } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const props = defineProps<{ scale: number; dim: boolean }>()
const store = useDefinitionStore()

const segmentStarts = computed(() => new Set(store.definition.dpl.map((s) => s.startLine)))
const fontSize = computed(() => 12 / props.scale)
const lastLine = computed(() => store.pageLines[store.pageLines.length - 1] ?? null)

// ---- ライン下辺のドラッグ(ドット数の調整) ----
let drag: { n: number; y0: number; svgTop: number } | null = null

function startDrag(line: PageLine, e: MouseEvent) {
  if (e.button !== 0) return
  const svg = (e.target as Element).closest('svg')
  if (!svg) return
  drag = { n: line.n, y0: line.y0, svgTop: svg.getBoundingClientRect().top }
  window.addEventListener('mousemove', onDragMove)
  window.addEventListener('mouseup', endDrag)
}

function onDragMove(e: MouseEvent) {
  if (!drag) return
  const y = Math.round((e.clientY - drag.svgTop) / props.scale)
  store.setLineHeight(drag.n, y - drag.y0)
}

function endDrag() {
  drag = null
  window.removeEventListener('mousemove', onDragMove)
  window.removeEventListener('mouseup', endDrag)
}

onBeforeUnmount(endDrag)
</script>

<template>
  <g class="lines" :class="{ dim }">
    <template v-for="l in store.pageLines" :key="l.n">
      <line
        :x1="0"
        :y1="l.y0"
        :x2="store.pageSize.width"
        :y2="l.y0"
        :class="{ seg: segmentStarts.has(l.n) }"
        vector-effect="non-scaling-stroke"
      />
      <text :x="4 / scale" :y="l.y0 + fontSize" :font-size="fontSize">{{ l.n }}</text>
    </template>
    <line
      v-if="lastLine"
      :x1="0"
      :y1="lastLine.y1"
      :x2="store.pageSize.width"
      :y2="lastLine.y1"
      vector-effect="non-scaling-stroke"
    />
    <template v-if="!dim">
      <line
        v-for="l in store.pageLines"
        :key="'h' + l.n"
        class="handle"
        :data-line="l.n"
        :x1="0"
        :y1="l.y1"
        :x2="store.pageSize.width"
        :y2="l.y1"
        vector-effect="non-scaling-stroke"
        @mousedown.stop.prevent="startDrag(l, $event)"
      />
    </template>
  </g>
</template>

<style scoped>
.lines line {
  stroke: #2a7de1;
  stroke-width: 1;
}
.lines line.seg {
  stroke: #d9480f;
  stroke-width: 2;
}
.lines line.handle {
  stroke: transparent;
  stroke-width: 8;
  cursor: ns-resize;
  pointer-events: stroke;
}
.lines line.handle:hover {
  stroke: rgba(42, 125, 225, 0.25);
}
.lines text {
  fill: #2a7de1;
  font-family: monospace;
  pointer-events: none;
}
.lines.dim {
  opacity: 0.3;
}
</style>
