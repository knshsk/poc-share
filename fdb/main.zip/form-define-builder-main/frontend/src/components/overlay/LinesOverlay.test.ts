import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { defineComponent } from 'vue'
import { useDefinitionStore } from '../../stores/definition'
import LinesOverlay from './LinesOverlay.vue'

const Host = defineComponent({
  components: { LinesOverlay },
  props: { dim: { type: Boolean, default: false } },
  template: '<svg><LinesOverlay :scale="1" :dim="dim" /></svg>',
})

function setup(dim = false) {
  const store = useDefinitionStore()
  store.setDocument({ id: 'd', fileName: 'a.pdf', pageCount: 1, pages: [{ width: 300, height: 350 }] })
  store.addDplSegment()
  store.updateDplSegment(0, { dots: [25] })
  const w = mount(Host, { props: { dim } })
  const svg = w.find('svg').element as SVGSVGElement
  svg.getBoundingClientRect = () =>
    ({ left: 0, top: 0, width: 300, height: 350, right: 300, bottom: 350, x: 0, y: 0, toJSON() {} }) as DOMRect
  return { w, store }
}

describe('LinesOverlay: ライン境界のドラッグ', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('ライン n の下辺をドラッグすると、そのラインの高さが更新される', async () => {
    const { w, store } = setup()
    const handle = w.find('line.handle[data-line="3"]')
    expect(handle.exists()).toBe(true)
    handle.element.dispatchEvent(new MouseEvent('mousedown', { clientY: 75, button: 0, bubbles: true }))
    window.dispatchEvent(new MouseEvent('mousemove', { clientY: 90 }))
    await w.vm.$nextTick()
    expect(store.definition.dpl[0].dots).toEqual([40])
    window.dispatchEvent(new MouseEvent('mouseup', { clientY: 90 }))
    await w.vm.$nextTick()
    expect(store.definition.dpl[0].dots).toEqual([40])
  })

  it('ライン1の上辺(Y=0)にはつかみ線がなく、dim のときはつかみ線を出さない', () => {
    const { w } = setup()
    expect(w.find('line.handle[data-line="0"]').exists()).toBe(false)
    const { w: dimmed } = setup(true)
    expect(dimmed.findAll('line.handle')).toHaveLength(0)
  })

  it('つかみ線の mousedown は親(キャンバス)へ伝播しない', () => {
    const { w } = setup()
    const svg = w.find('svg').element
    let reached = false
    svg.addEventListener('mousedown', () => {
      reached = true
    })
    w.find('line.handle[data-line="2"]').element.dispatchEvent(
      new MouseEvent('mousedown', { clientY: 50, button: 0, bubbles: true, cancelable: true }),
    )
    expect(reached).toBe(false)
    window.dispatchEvent(new MouseEvent('mouseup', { clientY: 50 }))
  })
})
