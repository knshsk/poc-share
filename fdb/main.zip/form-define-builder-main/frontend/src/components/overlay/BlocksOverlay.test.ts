import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from '../../stores/definition'
import BlocksOverlay from './BlocksOverlay.vue'

describe('BlocksOverlay', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('block starting at line 1 has label positioned inside rect (y >= 0)', async () => {
    const store = useDefinitionStore()

    // Set up document
    store.setDocument({
      id: 'd',
      fileName: 'a.pdf',
      pageCount: 1,
      pages: [{ width: 300, height: 350 }],
    })

    // Add DPL segment
    store.addDplSegment()
    store.updateDplSegment(0, { dots: [25] })

    // Add a block starting at line 1
    store.addBlock({ startX: 0, endX: 300, startLine: 1, endLine: 3 })

    // Mount BlocksOverlay wrapped in SVG
    const wrapper = mount(
      {
        components: { BlocksOverlay },
        template: '<svg><BlocksOverlay :scale="1" :dim="false" /></svg>',
      },
      {
        global: {
          stubs: {
            BlocksOverlay: false,
          },
        },
      },
    )

    // Find the label text element
    const label = wrapper.find('text.label')
    expect(label.exists()).toBe(true)
    expect(label.text()).toContain('ブロック1')

    // Assert that y attribute is a number >= 0 (not clipped by viewBox)
    const yAttr = label.attributes('y')
    const yValue = Number(yAttr)
    expect(yValue).toBeGreaterThanOrEqual(0)

    // Assert that a rect exists with y="0" and appropriate height
    const rect = wrapper.find('rect')
    expect(rect.exists()).toBe(true)
    expect(rect.attributes('y')).toBe('0')
    // height should be 75 (3 lines * 25 pixels per line)
    expect(Number(rect.attributes('height'))).toBe(75)
  })

  it('dim: true のとき、ルートの <g> に dim クラスが付く', () => {
    const store = useDefinitionStore()
    store.setDocument({
      id: 'd',
      fileName: 'a.pdf',
      pageCount: 1,
      pages: [{ width: 300, height: 350 }],
    })

    const wrapper = mount(
      {
        components: { BlocksOverlay },
        template: '<svg><BlocksOverlay :scale="1" :dim="true" /></svg>',
      },
      {
        global: {
          stubs: {
            BlocksOverlay: false,
          },
        },
      },
    )

    const root = wrapper.find('g.blocks')
    expect(root.exists()).toBe(true)
    expect(root.classes()).toContain('dim')
  })
})
