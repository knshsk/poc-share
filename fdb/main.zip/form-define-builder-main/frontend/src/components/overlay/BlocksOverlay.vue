<script setup lang="ts">
import { computed } from 'vue'
import { findOverlappingBlocks } from '../../model/blocks'
import type { Rect } from '../../model/types'
import { useDefinitionStore } from '../../stores/definition'

const props = defineProps<{ scale: number; dim: boolean }>()
const store = useDefinitionStore()

const fontSize = computed(() => 12 / props.scale)
const overlapping = computed(() => findOverlappingBlocks(store.definition.blocks))

/** 各ブロックの外接矩形(ブロックラインから)。ラインに掛からないブロックは null */
const blockRects = computed<(Rect | null)[]>(() =>
  store.definition.blocks.map((_, bi) => {
    const lines = store.blockLines.filter((l) => l.blockIndex === bi)
    if (lines.length === 0) return null
    return { x0: lines[0].x0, y0: lines[0].y0, x1: lines[0].x1, y1: lines[lines.length - 1].y1 }
  }),
)

const hasBlocks = computed(() => store.definition.blocks.length > 0)
</script>

<template>
  <g class="blocks" :class="{ dim }">
    <template v-for="(r, bi) in blockRects" :key="bi">
      <g v-if="r" :class="{ selected: store.selectedBlock === bi, overlap: overlapping.has(bi) }">
        <rect
          :x="r.x0"
          :y="r.y0"
          :width="r.x1 - r.x0"
          :height="r.y1 - r.y0"
          vector-effect="non-scaling-stroke"
          @click.stop="store.selectedBlock = bi"
        />
        <text class="label" :x="r.x0 + 6 / scale" :y="r.y0 + fontSize * 1.2 + 2 / scale" :font-size="fontSize * 1.2">
          ブロック{{ bi + 1 }}
        </text>
      </g>
    </template>
    <template v-if="hasBlocks">
      <text
        v-for="l in store.blockLines"
        :key="l.n"
        class="linenum"
        :x="l.x1 - 4 / scale"
        :y="l.y0 + fontSize"
        :font-size="fontSize"
        text-anchor="end"
      >
        {{ l.n }}
      </text>
    </template>
  </g>
</template>

<style scoped>
.blocks rect {
  fill: rgba(46, 160, 67, 0.12);
  stroke: #2ea043;
  stroke-width: 2;
  cursor: pointer;
}
.blocks .selected rect {
  fill: rgba(46, 160, 67, 0.25);
  stroke-width: 3;
}
.blocks .overlap rect {
  stroke: #d0021b;
}
.blocks .label {
  fill: #1f7a33;
  font-weight: 600;
  pointer-events: none;
}
.blocks .linenum {
  fill: #1f7a33;
  font-family: monospace;
  pointer-events: none;
}
.blocks.dim {
  opacity: 0.3;
  pointer-events: none;
}
</style>
