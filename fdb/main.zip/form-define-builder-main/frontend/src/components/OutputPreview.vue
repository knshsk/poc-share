<script setup lang="ts">
import { useDefinitionStore } from '../stores/definition'

const store = useDefinitionStore()
</script>

<template>
  <section class="preview">
    <h3>出力プレビュー</h3>
    <pre>{{ store.outputText || '(定義なし)' }}</pre>
  </section>
</template>

<style scoped>
.preview {
  padding: 8px 12px;
  border-bottom: 1px solid #eee;
}
.preview h3 {
  margin: 0 0 4px;
  font-size: 13px;
}
pre {
  margin: 0;
  padding: 8px;
  background: #f7f7f7;
  font-family: ui-monospace, Menlo, Consolas, monospace;
  font-size: 12px;
  white-space: pre;
  overflow: auto;
  max-height: 200px;
}
</style>
