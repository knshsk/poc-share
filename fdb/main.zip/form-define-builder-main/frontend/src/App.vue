<script setup lang="ts">
import EditorPanel from './components/EditorPanel.vue'
import OutputPreview from './components/OutputPreview.vue'
import PageCanvas from './components/PageCanvas.vue'
import TopBar from './components/TopBar.vue'
import ValidationPanel from './components/ValidationPanel.vue'
import BlocksOverlay from './components/overlay/BlocksOverlay.vue'
import LinesOverlay from './components/overlay/LinesOverlay.vue'
import ParagraphsOverlay from './components/overlay/ParagraphsOverlay.vue'
import BlocksPanel from './components/panels/BlocksPanel.vue'
import LinesPanel from './components/panels/LinesPanel.vue'
import ParagraphsPanel from './components/panels/ParagraphsPanel.vue'
import { useDefinitionStore } from './stores/definition'

const store = useDefinitionStore()
</script>

<template>
  <div class="app">
    <TopBar class="app__top" />
    <PageCanvas class="app__canvas">
      <template #default="{ scale }">
        <LinesOverlay :scale="scale" :dim="store.activeTab !== 'lines'" />
        <BlocksOverlay :scale="scale" :dim="store.activeTab !== 'blocks'" />
        <ParagraphsOverlay :scale="scale" :dim="store.activeTab !== 'paragraphs'" />
      </template>
    </PageCanvas>
    <EditorPanel class="app__panel">
      <template #lines>
        <LinesPanel />
      </template>
      <template #blocks>
        <BlocksPanel />
      </template>
      <template #paragraphs>
        <ParagraphsPanel />
      </template>
      <template #footer>
        <OutputPreview />
        <ValidationPanel />
      </template>
    </EditorPanel>
  </div>
</template>

<style scoped>
.app {
  display: grid;
  grid-template-rows: auto 1fr;
  grid-template-columns: 1fr 400px;
  grid-template-areas:
    'top top'
    'canvas panel';
  height: 100vh;
}
.app__top {
  grid-area: top;
}
.app__canvas {
  grid-area: canvas;
  min-height: 0;
  /* ページ幅がキャンバス幅を超えても列を広げず、キャンバス内で横スクロールさせる */
  min-width: 0;
}
.app__panel {
  grid-area: panel;
  min-height: 0;
}
</style>
