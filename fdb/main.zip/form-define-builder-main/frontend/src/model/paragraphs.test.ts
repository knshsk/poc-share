import { describe, expect, it } from 'vitest'
import { computeBlockLines } from './blocks'
import { computePageLines } from './lines'
import { paragraphDisplayName, resolveParagraphs } from './paragraphs'
import { newParagraph, type Paragraph } from './types'

// 4ブロック例。通し番号 1..22。ブロック2 = 4..11 (x 0-150)、ブロック3 = 12..19 (x 150-300)
const pageLines = computePageLines([{ startLine: 1, dots: [25] }], 350)
const blockLines = computeBlockLines(
  [
    { startX: 0, endX: 300, startLine: 1, endLine: 3 },
    { startX: 0, endX: 150, startLine: 4, endLine: 11 },
    { startX: 150, endX: 300, startLine: 4, endLine: 11 },
    { startX: 0, endX: 300, startLine: 12, endLine: 14 },
  ],
  pageLines,
  300,
)

function para(patch: Partial<Paragraph>): Paragraph {
  return { ...newParagraph(), ...patch, div: { ...newParagraph().div, startX: 20, endX: 80 } }
}

describe('resolveParagraphs', () => {
  it('未指定はページ全体(1..N)', () => {
    const [r] = resolveParagraphs([para({})], blockLines)
    expect(r.first).toBe(1)
    expect(r.last).toBe(22)
    expect(r.error).toBeUndefined()
    expect(r.name).toBe('Paragraph1')
  })

  it('開始/終了を親内の相対で解決し、ブロックごとに矩形をまとめる', () => {
    const [r] = resolveParagraphs([para({ startLine: 10, endLine: { kind: 'abs', n: 13 } })], blockLines)
    expect(r.first).toBe(10)
    expect(r.last).toBe(13)
    expect(r.rects).toEqual([
      { x0: 0, y0: 225, x1: 150, y1: 275 },
      { x0: 150, y0: 75, x1: 300, y1: 125 },
    ])
    expect(r.divRects).toEqual([
      { x0: 20, y0: 225, x1: 80, y1: 275 },
      { x0: 20, y0: 75, x1: 80, y1: 125 },
    ])
  })

  it('E<n> は親の最終ラインからの相対', () => {
    const [r] = resolveParagraphs([para({ endLine: { kind: 'fromEnd', n: 3 } })], blockLines)
    expect(r.last).toBe(20)
  })

  it('子は親の解決結果を基準にする', () => {
    const [, child] = resolveParagraphs(
      [
        para({ startLine: 4, endLine: { kind: 'abs', n: 11 } }),
        para({ startLine: 2, endLine: { kind: 'fromEnd', n: 1 }, name: '子' }),
      ],
      blockLines,
    )
    expect(child.first).toBe(5)
    expect(child.last).toBe(11)
    expect(child.name).toBe('子')
  })

  it('親をはみ出す/逆転はエラーを付けてクリップし、次の親にはクリップ結果を使う', () => {
    const [r, child] = resolveParagraphs(
      [
        para({ startLine: 20, endLine: { kind: 'abs', n: 30 } }),
        para({ startLine: 1, endLine: { kind: 'abs', n: 10 } }),
      ],
      blockLines,
    )
    expect(r.error).toBeDefined()
    expect(r.first).toBe(20)
    expect(r.last).toBe(22)
    expect(child.error).toBeDefined()
    expect(child.first).toBe(20)
    expect(child.last).toBe(22)

    const [inv] = resolveParagraphs([para({ startLine: 5, endLine: { kind: 'abs', n: 3 } })], blockLines)
    expect(inv.error).toBeDefined()
    expect(inv.rects).toEqual([])
  })

  it('ブロックラインが無ければ全てエラーで矩形なし', () => {
    const [r] = resolveParagraphs([para({})], [])
    expect(r.error).toBeDefined()
    expect(r.rects).toEqual([])
  })
})

describe('paragraphDisplayName', () => {
  it('空なら Paragraph<n>', () => {
    expect(paragraphDisplayName(para({}), 0)).toBe('Paragraph1')
    expect(paragraphDisplayName(para({ name: '明細' }), 3)).toBe('明細')
  })
})
