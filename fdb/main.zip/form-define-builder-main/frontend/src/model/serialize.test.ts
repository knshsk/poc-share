import { describe, expect, it } from 'vitest'
import { serialize } from './serialize'
import { emptyDefinition, newParagraph } from './types'

describe('serialize', () => {
  it('空の定義は空文字', () => {
    expect(serialize(emptyDefinition())).toBe('')
  })

  it('仕様の例をそのまま再現する', () => {
    const text = serialize({
      dpl: [
        { startLine: 1, dots: [80] },
        { startLine: 20, dots: [85] },
      ],
      blocks: [
        { startX: 0, endX: 150, startLine: 4, endLine: 11 },
        { startX: 150, endX: 300, startLine: 4, endLine: 11 },
      ],
      paragraphs: [
        {
          startLine: 1,
          endLine: { kind: 'abs', n: 10 },
          name: '支店',
          spanPage: false,
          div: { value: '支店', cond: 'A', startX: 200, endX: 500, sameContinue: 'N' },
          delBackwardSpace: true,
        },
      ],
    })
    expect(text).toBe(
      [
        '# ライン定義',
        'DPL,1,80,',
        'DPL,20,85,',
        '',
        '# ブロック定義',
        'BLOCK,0,150,4,11,',
        'BLOCK,150,300,4,11,',
        '',
        '# パラグラフ定義',
        'PARAGRAPH,1,10,支店,N,',
        'DIV,KEY,支店,A,200,500,N,',
        'DEL_BACKWARD_SPACE,Y,',
        '',
      ].join('\n'),
    )
  })

  it('サイクリックな dots はカンマで並べる', () => {
    expect(serialize({ ...emptyDefinition(), dpl: [{ startLine: 17, dots: [23, 22] }] })).toBe(
      '# ライン定義\nDPL,17,23,22,\n',
    )
  })

  it('未指定欄は空、E<n> は E 付き、DEL_BACKWARD_SPACE は真のときだけ', () => {
    const p = newParagraph()
    p.endLine = { kind: 'fromEnd', n: 1 }
    p.div.startX = 100
    p.div.endX = 900
    const text = serialize({ ...emptyDefinition(), paragraphs: [p] })
    expect(text).toBe('# パラグラフ定義\nPARAGRAPH,,E1,,N,\nDIV,KEY,,M,100,900,,\n')
  })

  it('DPL は入力順によらず startLine 昇順で出力し、元の配列は変更しない', () => {
    const dpl = [
      { startLine: 20, dots: [85] },
      { startLine: 1, dots: [80] },
      { startLine: 10, dots: [30] },
    ]
    const text = serialize({ ...emptyDefinition(), dpl })
    expect(text).toBe('# ライン定義\nDPL,1,80,\nDPL,10,30,\nDPL,20,85,\n')
    expect(dpl.map((s) => s.startLine)).toEqual([20, 1, 10])
  })

  it('空のセクションは見出しごと省略する', () => {
    const text = serialize({ ...emptyDefinition(), blocks: [{ startX: 0, endX: 10, startLine: 1, endLine: 2 }] })
    expect(text).toBe('# ブロック定義\nBLOCK,0,10,1,2,\n')
  })
})
