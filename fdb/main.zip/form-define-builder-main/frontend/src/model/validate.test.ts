import { describe, expect, it } from 'vitest'
import { computeBlockLines } from './blocks'
import { computePageLines } from './lines'
import { emptyDefinition, newParagraph, type FormDefinition } from './types'
import { validate } from './validate'

function run(def: FormDefinition) {
  const pageLines = computePageLines(def.dpl, 350)
  const blockLines = computeBlockLines(def.blocks, pageLines, 300)
  return validate(def, pageLines, blockLines)
}

const dpl25 = [{ startLine: 1, dots: [25] }]

describe('validate: DPL', () => {
  it('空の定義はエラーなし', () => {
    expect(run(emptyDefinition())).toEqual([])
  })

  it('開始ライン1が無い', () => {
    const errs = run({ ...emptyDefinition(), dpl: [{ startLine: 2, dots: [10] }] })
    expect(errs).toContainEqual({ target: 'dpl', index: null, message: '開始ライン1のDPLが必要です' })
  })

  it('開始ライン重複、開始ライン<1、dots不正', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: [
        { startLine: 1, dots: [10] },
        { startLine: 1, dots: [20] },
        { startLine: 0, dots: [5] },
        { startLine: 3, dots: [] },
        { startLine: 4, dots: [0, 5] },
      ],
    })
    expect(errs.map((e) => [e.target, e.index])).toEqual([
      ['dpl', 1],
      ['dpl', 2],
      ['dpl', 3],
      ['dpl', 4],
    ])
  })
})

describe('validate: BLOCK', () => {
  it('DPL未定義', () => {
    const errs = run({ ...emptyDefinition(), blocks: [{ startX: 0, endX: 10, startLine: 1, endLine: 2 }] })
    expect(errs).toEqual([{ target: 'block', index: 0, message: 'ブロックを定義するにはライン定義が必要です' }])
  })

  it('X逆転、ライン逆転、ライン範囲外', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      blocks: [
        { startX: 10, endX: 10, startLine: 1, endLine: 2 },
        { startX: 0, endX: 10, startLine: 3, endLine: 2 },
        { startX: 20, endX: 30, startLine: 13, endLine: 15 },
        { startX: 40, endX: 50, startLine: 0, endLine: 1 },
      ],
    })
    expect(errs.map((e) => e.index)).toEqual([0, 1, 2, 3])
    expect(errs[2].message).toContain('14')
  })

  it('重複は両方にエラー', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      blocks: [
        { startX: 0, endX: 200, startLine: 1, endLine: 5 },
        { startX: 100, endX: 300, startLine: 5, endLine: 8 },
        { startX: 0, endX: 300, startLine: 9, endLine: 14 },
      ],
    })
    expect(errs.map((e) => e.index)).toEqual([0, 1])
    expect(errs[0].message).toContain('重複')
  })
})

describe('validate: PARAGRAPH', () => {
  function p(patch: object) {
    const base = newParagraph()
    return { ...base, div: { ...base.div, startX: 10, endX: 50 }, ...patch }
  }

  it('DPL未定義', () => {
    const errs = run({ ...emptyDefinition(), paragraphs: [p({})] })
    expect(errs).toEqual([
      { target: 'paragraph', index: 0, message: 'パラグラフを定義するにはライン定義が必要です' },
    ])
  })

  it('DIVのX逆転、開始ライン<1、終了ライン<1', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [
        p({ div: { value: '', cond: 'M', startX: 50, endX: 50, sameContinue: null } }),
        p({ startLine: 0 }),
        p({ endLine: { kind: 'fromEnd', n: 0 } }),
      ],
    })
    expect(errs.map((e) => e.index)).toEqual([0, 1, 2])
  })

  it('解決後の範囲が親をはみ出す', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [p({ startLine: 1, endLine: { kind: 'abs', n: 5 } }), p({ startLine: 3, endLine: { kind: 'abs', n: 9 } })],
    })
    expect(errs).toHaveLength(1)
    expect(errs[0].index).toBe(1)
    expect(errs[0].message).toContain('はみ出し')
  })

  it('正しい定義はエラーなし', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [p({ startLine: 1, endLine: { kind: 'fromEnd', n: 1 }, name: '支店' })],
    })
    expect(errs).toEqual([])
  })

  it('パラグラフ名・比較値にカンマ/改行が含まれるとエラー', () => {
    const errs = run({
      ...emptyDefinition(),
      dpl: dpl25,
      paragraphs: [
        p({ startLine: 1, endLine: { kind: 'fromEnd', n: 1 }, name: '支店,本店' }),
        p({
          startLine: 1,
          endLine: { kind: 'fromEnd', n: 1 },
          div: { value: '本店\n支店', cond: 'M', startX: 10, endX: 50, sameContinue: null },
        }),
      ],
    })
    expect(errs).toContainEqual({
      target: 'paragraph',
      index: 0,
      message: 'パラグラフ名にカンマ・改行は使えません',
    })
    expect(errs).toContainEqual({
      target: 'paragraph',
      index: 1,
      message: '比較値にカンマ・改行は使えません',
    })
  })
})
