import { describe, expect, it } from 'vitest'
import { blockFromRect, computeBlockLines, findOverlappingBlocks } from './blocks'
import { computePageLines } from './lines'

// 仕様の設定例: DPL,1,25 / BLOCK 0-300 1-3 / 0-150 4-11 / 150-300 4-11 / 0-300 12-14
const pageLines = computePageLines([{ startLine: 1, dots: [25] }], 350)
const blocks = [
  { startX: 0, endX: 300, startLine: 1, endLine: 3 },
  { startX: 0, endX: 150, startLine: 4, endLine: 11 },
  { startX: 150, endX: 300, startLine: 4, endLine: 11 },
  { startX: 0, endX: 300, startLine: 12, endLine: 14 },
]

describe('computeBlockLines', () => {
  it('ブロック未指定ならページ全体を1ブロックとする', () => {
    const out = computeBlockLines([], pageLines, 300)
    expect(out).toHaveLength(14)
    expect(out[0]).toEqual({ n: 1, blockIndex: 0, x0: 0, x1: 300, y0: 0, y1: 25 })
  })

  it('仕様の4ブロック例で通し番号 1..22 になる', () => {
    const out = computeBlockLines(blocks, pageLines, 300)
    expect(out).toHaveLength(22)
    expect(out[3]).toEqual({ n: 4, blockIndex: 1, x0: 0, x1: 150, y0: 75, y1: 100 })
    expect(out[11]).toEqual({ n: 12, blockIndex: 2, x0: 150, x1: 300, y0: 75, y1: 100 })
    expect(out[19]).toEqual({ n: 20, blockIndex: 3, x0: 0, x1: 300, y0: 275, y1: 300 })
    expect(out[21].n).toBe(22)
  })

  it('ページラインの範囲外は切り捨てる', () => {
    const out = computeBlockLines([{ startX: 0, endX: 100, startLine: 13, endLine: 20 }], pageLines, 300)
    expect(out.map((l) => l.y0)).toEqual([300, 325])
  })
})

describe('blockFromRect', () => {
  it('Yはドラッグ範囲に掛かるラインの先頭/最終にスナップし、Xは正規化する', () => {
    const b = blockFromRect({ x0: 120, y0: 80, x1: 10, y1: 130 }, pageLines)
    expect(b).toEqual({ startX: 10, endX: 120, startLine: 4, endLine: 6 })
  })

  it('ラインに掛からない、または幅0なら null', () => {
    expect(blockFromRect({ x0: 0, y0: 400, x1: 10, y1: 410 }, pageLines)).toBeNull()
    expect(blockFromRect({ x0: 5, y0: 0, x1: 5, y1: 10 }, pageLines)).toBeNull()
  })
})

describe('findOverlappingBlocks', () => {
  it('重複がなければ空', () => {
    expect(findOverlappingBlocks(blocks).size).toBe(0)
  })

  it('X区間とライン区間の両方が交差するブロック同士を返す', () => {
    const set = findOverlappingBlocks([
      ...blocks,
      { startX: 100, endX: 200, startLine: 10, endLine: 12 },
    ])
    expect([...set].sort()).toEqual([1, 2, 3, 4])
  })

  it('辺を共有するだけなら重複ではない', () => {
    const set = findOverlappingBlocks([
      { startX: 0, endX: 150, startLine: 1, endLine: 3 },
      { startX: 150, endX: 300, startLine: 1, endLine: 3 },
    ])
    expect(set.size).toBe(0)
  })
})
