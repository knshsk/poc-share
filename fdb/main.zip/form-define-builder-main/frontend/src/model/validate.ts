import { findOverlappingBlocks } from './blocks'
import { resolveParagraphs } from './paragraphs'
import type { BlockLine, FormDefinition, PageLine, ValidationError } from './types'

function validateDpl(def: FormDefinition): ValidationError[] {
  const errs: ValidationError[] = []
  if (def.dpl.length === 0) return errs
  if (!def.dpl.some((s) => s.startLine === 1)) {
    errs.push({ target: 'dpl', index: null, message: '開始ライン1のDPLが必要です' })
  }
  const seen = new Set<number>()
  def.dpl.forEach((s, i) => {
    if (!Number.isInteger(s.startLine) || s.startLine < 1) {
      errs.push({ target: 'dpl', index: i, message: '開始ラインは1以上の整数で指定してください' })
    } else if (seen.has(s.startLine)) {
      errs.push({ target: 'dpl', index: i, message: `開始ライン${s.startLine}が重複しています` })
    } else {
      seen.add(s.startLine)
    }
    if (s.dots.length === 0 || !s.dots.every((d) => Number.isInteger(d) && d > 0)) {
      errs.push({ target: 'dpl', index: i, message: 'ドット数は1以上の整数をカンマ区切りで指定してください' })
    }
  })
  return errs
}

function validateBlocks(def: FormDefinition, pageLines: PageLine[]): ValidationError[] {
  const errs: ValidationError[] = []
  if (def.blocks.length === 0) return errs
  if (pageLines.length === 0) {
    def.blocks.forEach((_, i) =>
      errs.push({ target: 'block', index: i, message: 'ブロックを定義するにはライン定義が必要です' }),
    )
    return errs
  }
  const maxLine = pageLines.length
  const overlapping = findOverlappingBlocks(def.blocks)
  def.blocks.forEach((b, i) => {
    if (b.startX >= b.endX) {
      errs.push({ target: 'block', index: i, message: '開始Xは終了Xより小さくしてください' })
    }
    if (b.startLine > b.endLine) {
      errs.push({ target: 'block', index: i, message: '開始ラインは終了ライン以下にしてください' })
    } else if (b.startLine < 1 || b.endLine > maxLine) {
      errs.push({ target: 'block', index: i, message: `ライン範囲は1〜${maxLine}の中で指定してください` })
    }
    if (overlapping.has(i)) {
      errs.push({ target: 'block', index: i, message: '他のブロックと矩形が重複しています' })
    }
  })
  return errs
}

function validateParagraphs(def: FormDefinition, blockLines: BlockLine[]): ValidationError[] {
  const errs: ValidationError[] = []
  if (def.paragraphs.length === 0) return errs
  if (blockLines.length === 0) {
    def.paragraphs.forEach((_, i) =>
      errs.push({ target: 'paragraph', index: i, message: 'パラグラフを定義するにはライン定義が必要です' }),
    )
    return errs
  }
  const resolved = resolveParagraphs(def.paragraphs, blockLines)
  def.paragraphs.forEach((p, i) => {
    if (p.div.startX >= p.div.endX) {
      errs.push({ target: 'paragraph', index: i, message: 'DIVの開始Xは終了Xより小さくしてください' })
    }
    if (/[,\r\n]/.test(p.name)) {
      errs.push({ target: 'paragraph', index: i, message: 'パラグラフ名にカンマ・改行は使えません' })
    }
    if (/[,\r\n]/.test(p.div.value)) {
      errs.push({ target: 'paragraph', index: i, message: '比較値にカンマ・改行は使えません' })
    }
    // 開始/終了ラインの値そのものが不正なら、解決エラーは重複になるので出さない
    let lineFieldsValid = true
    if (p.startLine !== null && (!Number.isInteger(p.startLine) || p.startLine < 1)) {
      lineFieldsValid = false
      errs.push({ target: 'paragraph', index: i, message: '開始ラインは1以上の整数で指定してください' })
    }
    if (p.endLine !== null && (!Number.isInteger(p.endLine.n) || p.endLine.n < 1)) {
      lineFieldsValid = false
      errs.push({ target: 'paragraph', index: i, message: '終了ラインは1以上の整数(またはE<n>)で指定してください' })
    }
    const r = resolved[i]
    if (lineFieldsValid && r.error !== undefined) {
      errs.push({ target: 'paragraph', index: i, message: r.error })
    }
  })
  return errs
}

/** 定義全体の不整合を列挙する。空配列ならダウンロード可能 */
export function validate(
  def: FormDefinition,
  pageLines: PageLine[],
  blockLines: BlockLine[],
): ValidationError[] {
  return [...validateDpl(def), ...validateBlocks(def, pageLines), ...validateParagraphs(def, blockLines)]
}
