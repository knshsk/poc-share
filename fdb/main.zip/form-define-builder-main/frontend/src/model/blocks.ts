import type { Block, BlockLine, PageLine, Rect } from './types'

/**
 * ブロック順にページラインを切り出し、通し番号を 1 から振り直す。
 * ブロック未指定ならページ全体を1ブロックとみなす。
 */
export function computeBlockLines(
  blocks: Block[],
  pageLines: PageLine[],
  pageWidth: number,
): BlockLine[] {
  if (blocks.length === 0) {
    return pageLines.map((l) => ({ n: l.n, blockIndex: 0, x0: 0, x1: pageWidth, y0: l.y0, y1: l.y1 }))
  }
  const out: BlockLine[] = []
  let n = 1
  blocks.forEach((b, blockIndex) => {
    for (const l of pageLines) {
      if (l.n < b.startLine || l.n > b.endLine) continue
      out.push({ n: n++, blockIndex, x0: b.startX, x1: b.endX, y0: l.y0, y1: l.y1 })
    }
  })
  return out
}

/** ドラッグ矩形からブロックを作る。Yはラインにスナップ。ラインに掛からない/幅0なら null */
export function blockFromRect(rect: Rect, pageLines: PageLine[]): Block | null {
  const startX = Math.min(rect.x0, rect.x1)
  const endX = Math.max(rect.x0, rect.x1)
  const y0 = Math.min(rect.y0, rect.y1)
  const y1 = Math.max(rect.y0, rect.y1)
  if (startX === endX) return null
  const hit = pageLines.filter((l) => l.y1 > y0 && l.y0 < y1)
  if (hit.length === 0) return null
  return { startX, endX, startLine: hit[0].n, endLine: hit[hit.length - 1].n }
}

function overlaps(a: Block, b: Block): boolean {
  return (
    a.startX < b.endX && b.startX < a.endX && a.startLine <= b.endLine && b.startLine <= a.endLine
  )
}

/** 他のブロックと矩形が重複しているブロックのインデックス集合 */
export function findOverlappingBlocks(blocks: Block[]): Set<number> {
  const result = new Set<number>()
  for (let i = 0; i < blocks.length; i++) {
    for (let j = i + 1; j < blocks.length; j++) {
      if (overlaps(blocks[i], blocks[j])) {
        result.add(i)
        result.add(j)
      }
    }
  }
  return result
}
