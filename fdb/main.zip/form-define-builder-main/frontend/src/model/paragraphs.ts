import type { BlockLine, Paragraph, Rect, ResolvedParagraph } from './types'

export function paragraphDisplayName(p: Paragraph, index: number): string {
  return p.name.trim() === '' ? `Paragraph${index + 1}` : p.name
}

/** first..last のブロックラインを、blockIndex が連続する区間ごとに1矩形にまとめる */
function rectsForRange(blockLines: BlockLine[], first: number, last: number): Rect[] {
  const rects: Rect[] = []
  let cur: { blockIndex: number; rect: Rect } | null = null
  for (const l of blockLines) {
    if (l.n < first || l.n > last) continue
    if (cur && cur.blockIndex === l.blockIndex) {
      cur.rect.y1 = l.y1
    } else {
      cur = { blockIndex: l.blockIndex, rect: { x0: l.x0, y0: l.y0, x1: l.x1, y1: l.y1 } }
      rects.push(cur.rect)
    }
  }
  return rects
}

/**
 * paragraphs の配列順を親→子→孫として、各パラグラフの行範囲を解決する。
 * 最上位の親は 1..blockLines.length。範囲がはみ出す/逆転する場合は error を付け、
 * 親範囲でクリップした結果を次のパラグラフの親として使う。
 */
export function resolveParagraphs(
  paragraphs: Paragraph[],
  blockLines: BlockLine[],
): ResolvedParagraph[] {
  const out: ResolvedParagraph[] = []
  let parentFirst = 1
  let parentLast = blockLines.length

  paragraphs.forEach((p, index) => {
    const first = parentFirst + (p.startLine ?? 1) - 1
    let last: number
    if (p.endLine === null) last = parentLast
    else if (p.endLine.kind === 'abs') last = parentFirst + p.endLine.n - 1
    else last = parentLast - p.endLine.n + 1

    let error: string | undefined
    if (parentLast < parentFirst) {
      error = 'ラインが定義されていません'
    } else if (first > last) {
      error = `開始ライン(${first})が終了ライン(${last})より後です`
    } else if (first < parentFirst || last > parentLast) {
      error = `範囲 ${first}〜${last} が親の範囲 ${parentFirst}〜${parentLast} をはみ出しています`
    }

    const clampedFirst = Math.max(parentFirst, Math.min(first, parentLast))
    const clampedLast = Math.max(parentFirst, Math.min(last, parentLast))
    const empty = parentLast < parentFirst || clampedFirst > clampedLast
    const rects = empty ? [] : rectsForRange(blockLines, clampedFirst, clampedLast)
    const divRects = rects.map((r) => ({ ...r, x0: p.div.startX, x1: p.div.endX }))

    out.push({
      index,
      name: paragraphDisplayName(p, index),
      first: clampedFirst,
      last: clampedLast,
      rects,
      divRects,
      ...(error !== undefined ? { error } : {}),
    })

    parentFirst = clampedFirst
    parentLast = empty ? clampedFirst - 1 : clampedLast
  })
  return out
}
