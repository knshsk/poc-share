import type { DplSegment, PageLine } from './types'

export function isValidSegment(seg: DplSegment): boolean {
  return (
    Number.isInteger(seg.startLine) &&
    seg.startLine >= 1 &&
    seg.dots.length > 0 &&
    seg.dots.every((d) => Number.isInteger(d) && d > 0)
  )
}

/** 有効なセグメントを startLine 昇順に並べ、重複 startLine は先勝ちで1つにする */
function normalize(dpl: DplSegment[]): DplSegment[] {
  const seen = new Set<number>()
  const out: DplSegment[] = []
  for (const seg of dpl) {
    if (!isValidSegment(seg) || seen.has(seg.startLine)) continue
    seen.add(seg.startLine)
    out.push(seg)
  }
  return out.sort((a, b) => a.startLine - b.startLine)
}

/** ライン n を支配するセグメント(startLine <= n の中で最大の startLine を持つもの) */
export function segmentForLine(dpl: DplSegment[], n: number): DplSegment | null {
  let best: DplSegment | null = null
  for (const seg of dpl) {
    if (seg.startLine <= n && (best === null || seg.startLine > best.startLine)) best = seg
  }
  return best
}

/**
 * Y=0 から順にラインを生成する。ライン n の高さは、n を支配するセグメントの dots を
 * セグメント開始からの相対位置でサイクリックに引いたもの。
 * y0 < pageHeight の間生成し、最後のラインは y1 がページ高を超えてもそのまま保持する。
 */
export function computePageLines(dpl: DplSegment[], pageHeight: number): PageLine[] {
  const segs = normalize(dpl)
  if (segs.length === 0 || segs[0].startLine !== 1 || pageHeight <= 0) return []

  const lines: PageLine[] = []
  let y = 0
  let n = 1
  let segIdx = 0
  while (y < pageHeight) {
    while (segIdx + 1 < segs.length && segs[segIdx + 1].startLine <= n) segIdx++
    const seg = segs[segIdx]
    const dots = seg.dots[(n - seg.startLine) % seg.dots.length]
    lines.push({ n, y0: y, y1: y + dots })
    y += dots
    n++
  }
  return lines
}

/** ライン n の高さに使われる seg.dots のインデックス(セグメント開始からサイクリック) */
export function dotsIndexForLine(seg: DplSegment, n: number): number {
  return (n - seg.startLine) % seg.dots.length
}
