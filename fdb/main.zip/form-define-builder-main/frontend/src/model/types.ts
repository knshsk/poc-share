/** DPL,<開始ライン>,<ドット数>[,<ドット数>...] */
export interface DplSegment {
  startLine: number
  dots: number[]
}

/** BLOCK,<開始X>,<終了X>,<開始ライン>,<終了ライン> */
export interface Block {
  startX: number
  endX: number
  startLine: number
  endLine: number
}

/** 終了ラインの指定。abs: 親内の絶対ライン番号、fromEnd: E<n>(親の最終ラインから) */
export type LineRef = { kind: 'abs'; n: number } | { kind: 'fromEnd'; n: number }

export type DivCond = 'M' | 'F' | 'B' | 'A' | 'N' | 'W'

export const DIV_CONDS: { value: DivCond; label: string }[] = [
  { value: 'M', label: 'M: 中間一致' },
  { value: 'F', label: 'F: 完全一致' },
  { value: 'B', label: 'B: 前方一致' },
  { value: 'A', label: 'A: 後方一致' },
  { value: 'N', label: 'N: 不一致' },
  { value: 'W', label: 'W: ワイルドカード' },
]

/** DIV,KEY,<比較値>,<比較条件>,<開始X>,<終了X>,<同値継続> */
export interface Div {
  value: string
  cond: DivCond
  startX: number
  endX: number
  sameContinue: 'Y' | 'N' | null
}

/** PARAGRAPH + DIV + DEL_BACKWARD_SPACE の1組 */
export interface Paragraph {
  startLine: number | null
  endLine: LineRef | null
  /** 空文字は未指定(出力側で Paragraph<n> と自動命名される) */
  name: string
  spanPage: boolean
  div: Div
  delBackwardSpace: boolean
}

export interface FormDefinition {
  dpl: DplSegment[]
  blocks: Block[]
  paragraphs: Paragraph[]
}

/** ページ上のライン(DPLから算出)。y は画像ピクセル */
export interface PageLine {
  n: number
  y0: number
  y1: number
}

/** ブロック適用後の通し番号付きライン */
export interface BlockLine {
  n: number
  blockIndex: number
  x0: number
  x1: number
  y0: number
  y1: number
}

export interface Rect {
  x0: number
  y0: number
  x1: number
  y1: number
}

export interface ResolvedParagraph {
  index: number
  name: string
  first: number
  last: number
  rects: Rect[]
  divRects: Rect[]
  error?: string
}

export type ValidationTarget = 'dpl' | 'block' | 'paragraph'

export interface ValidationError {
  target: ValidationTarget
  /** 対象要素のインデックス(0始まり)。要素に紐づかないエラーは null */
  index: number | null
  message: string
}

export function emptyDefinition(): FormDefinition {
  return { dpl: [], blocks: [], paragraphs: [] }
}

export function newParagraph(): Paragraph {
  return {
    startLine: null,
    endLine: null,
    name: '',
    spanPage: false,
    div: { value: '', cond: 'M', startX: 0, endX: 0, sameContinue: null },
    delBackwardSpace: false,
  }
}
