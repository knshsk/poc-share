import { describe, expect, it } from 'vitest'
import { computePageLines, dotsIndexForLine, segmentForLine } from './lines'

describe('computePageLines', () => {
  it('DPL 1→80, 20→85: 19行目まで80、20行目以降85', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [80] },
        { startLine: 20, dots: [85] },
      ],
      2000,
    )
    expect(lines[0]).toEqual({ n: 1, y0: 0, y1: 80 })
    expect(lines[18]).toEqual({ n: 19, y0: 1440, y1: 1520 })
    expect(lines[19]).toEqual({ n: 20, y0: 1520, y1: 1605 })
    expect(lines).toHaveLength(25)
    expect(lines[24]).toEqual({ n: 25, y0: 1945, y1: 2030 })
  })

  it('DPL 1→55, 17→23,22: 17行目以降は 23, 22 を繰り返す', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [55] },
        { startLine: 17, dots: [23, 22] },
      ],
      1000,
    )
    expect(lines[15]).toEqual({ n: 16, y0: 825, y1: 880 })
    expect(lines[16]).toEqual({ n: 17, y0: 880, y1: 903 })
    expect(lines[17]).toEqual({ n: 18, y0: 903, y1: 925 })
    expect(lines[18]).toEqual({ n: 19, y0: 925, y1: 948 })
    expect(lines).toHaveLength(22)
  })

  it('セグメントの順序は startLine で並べ替えられる', () => {
    const lines = computePageLines(
      [
        { startLine: 3, dots: [10] },
        { startLine: 1, dots: [20] },
      ],
      100,
    )
    expect(lines.map((l) => l.y1 - l.y0)).toEqual([20, 20, 10, 10, 10, 10, 10, 10])
  })

  it('開始ライン1のセグメントがなければ空', () => {
    expect(computePageLines([{ startLine: 2, dots: [10] }], 100)).toEqual([])
  })

  it('DPLが空、または dots が不正なセグメントしかなければ空', () => {
    expect(computePageLines([], 100)).toEqual([])
    expect(computePageLines([{ startLine: 1, dots: [] }], 100)).toEqual([])
    expect(computePageLines([{ startLine: 1, dots: [0] }], 100)).toEqual([])
  })

  it('不正なセグメントは無視して残りで計算する', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [50] },
        { startLine: 2, dots: [] },
      ],
      100,
    )
    expect(lines).toHaveLength(2)
  })

  it('同じ startLine が重複したら先に現れたものを使う', () => {
    const lines = computePageLines(
      [
        { startLine: 1, dots: [50] },
        { startLine: 1, dots: [25] },
      ],
      100,
    )
    expect(lines).toHaveLength(2)
  })

  it('ページ高さが0以下なら空', () => {
    expect(computePageLines([{ startLine: 1, dots: [10] }], 0)).toEqual([])
  })
})

describe('segmentForLine', () => {
  const dpl = [
    { startLine: 1, dots: [80] },
    { startLine: 20, dots: [85] },
  ]

  it('そのラインを支配するセグメントを返す', () => {
    expect(segmentForLine(dpl, 1)).toBe(dpl[0])
    expect(segmentForLine(dpl, 19)).toBe(dpl[0])
    expect(segmentForLine(dpl, 20)).toBe(dpl[1])
    expect(segmentForLine(dpl, 99)).toBe(dpl[1])
  })

  it('該当がなければ null', () => {
    expect(segmentForLine([], 1)).toBeNull()
    expect(segmentForLine([{ startLine: 5, dots: [1] }], 2)).toBeNull()
  })
})

describe('dotsIndexForLine', () => {
  it('セグメント開始からの相対位置を dots 長でサイクリックに折り返す', () => {
    const seg = { startLine: 17, dots: [23, 22] }
    expect(dotsIndexForLine(seg, 17)).toBe(0)
    expect(dotsIndexForLine(seg, 18)).toBe(1)
    expect(dotsIndexForLine(seg, 19)).toBe(0)
  })

  it('単一 dots なら常に 0', () => {
    expect(dotsIndexForLine({ startLine: 1, dots: [80] }, 99)).toBe(0)
  })
})
