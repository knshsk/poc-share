import { describe, expect, it } from 'vitest'
import { formatLineRef, parseLineRef } from './parse'

describe('parseLineRef', () => {
  it('空は未指定', () => {
    expect(parseLineRef('')).toEqual({ ok: true, value: null })
    expect(parseLineRef('  ')).toEqual({ ok: true, value: null })
  })

  it('数値は abs', () => {
    expect(parseLineRef('10')).toEqual({ ok: true, value: { kind: 'abs', n: 10 } })
  })

  it('E<n> は fromEnd(小文字も可)', () => {
    expect(parseLineRef('E1')).toEqual({ ok: true, value: { kind: 'fromEnd', n: 1 } })
    expect(parseLineRef('e3')).toEqual({ ok: true, value: { kind: 'fromEnd', n: 3 } })
  })

  it('不正な文字列は ok: false', () => {
    expect(parseLineRef('E')).toEqual({ ok: false })
    expect(parseLineRef('0')).toEqual({ ok: false })
    expect(parseLineRef('abc')).toEqual({ ok: false })
  })
})

describe('formatLineRef', () => {
  it('parseLineRef の逆変換', () => {
    expect(formatLineRef(null)).toBe('')
    expect(formatLineRef({ kind: 'abs', n: 7 })).toBe('7')
    expect(formatLineRef({ kind: 'fromEnd', n: 2 })).toBe('E2')
  })
})
