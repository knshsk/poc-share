import type { LineRef } from './types'

const POSITIVE_INT = /^[1-9]\d*$/

/** "" → null(未指定)、"10" → abs、"E1" → fromEnd */
export function parseLineRef(text: string): { ok: true; value: LineRef | null } | { ok: false } {
  const t = text.trim()
  if (t === '') return { ok: true, value: null }
  if (POSITIVE_INT.test(t)) return { ok: true, value: { kind: 'abs', n: Number(t) } }
  const m = /^[Ee]([1-9]\d*)$/.exec(t)
  if (m) return { ok: true, value: { kind: 'fromEnd', n: Number(m[1]) } }
  return { ok: false }
}

export function formatLineRef(ref: LineRef | null): string {
  if (ref === null) return ''
  return ref.kind === 'abs' ? String(ref.n) : `E${ref.n}`
}
