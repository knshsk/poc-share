import { formatLineRef } from './parse'
import type { FormDefinition } from './types'

/**
 * フォーム定義テキストを生成する。各行末に `,`、セクションは空行で区切り、
 * 空のセクションは省略。末尾は改行1つ。定義が空なら空文字。
 */
export function serialize(def: FormDefinition): string {
  const sections: string[][] = []

  if (def.dpl.length > 0) {
    const sortedDpl = [...def.dpl].sort((a, b) => a.startLine - b.startLine)
    sections.push(['# ライン定義', ...sortedDpl.map((s) => `DPL,${s.startLine},${s.dots.join(',')},`)])
  }

  if (def.blocks.length > 0) {
    sections.push([
      '# ブロック定義',
      ...def.blocks.map((b) => `BLOCK,${b.startX},${b.endX},${b.startLine},${b.endLine},`),
    ])
  }

  if (def.paragraphs.length > 0) {
    const lines = ['# パラグラフ定義']
    for (const p of def.paragraphs) {
      lines.push(
        `PARAGRAPH,${p.startLine ?? ''},${formatLineRef(p.endLine)},${p.name},${p.spanPage ? 'Y' : 'N'},`,
      )
      lines.push(
        `DIV,KEY,${p.div.value},${p.div.cond},${p.div.startX},${p.div.endX},${p.div.sameContinue ?? ''},`,
      )
      if (p.delBackwardSpace) lines.push('DEL_BACKWARD_SPACE,Y,')
    }
    sections.push(lines)
  }

  if (sections.length === 0) return ''
  return sections.map((s) => s.join('\n')).join('\n\n') + '\n'
}
