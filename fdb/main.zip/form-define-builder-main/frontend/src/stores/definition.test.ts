import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { useDefinitionStore } from './definition'

function loadDoc(store: ReturnType<typeof useDefinitionStore>) {
  store.setDocument({
    id: 'doc1',
    fileName: 'sample.pdf',
    pageCount: 2,
    pages: [
      { width: 300, height: 350 },
      { width: 300, height: 350 },
    ],
  })
}

describe('useDefinitionStore', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('初期状態はドキュメントなし、定義は空、ダウンロード不可', () => {
    const store = useDefinitionStore()
    expect(store.document).toBeNull()
    expect(store.isDefinitionEmpty).toBe(true)
    expect(store.pageLines).toEqual([])
    expect(store.canDownload).toBe(false)
  })

  it('setDocument はページサイズが変われば定義をクリアしてページを1に戻す', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.setPage(2)
    store.setDocument({
      id: 'doc2',
      fileName: 'other.pdf',
      pageCount: 1,
      pages: [{ width: 400, height: 500 }],
    })
    expect(store.definition.dpl).toEqual([])
    expect(store.currentPage).toBe(1)
    expect(store.pageSize).toEqual({ width: 400, height: 500 })
  })

  it('sameGeometry / setDocument: ページサイズが同じ再読み込みは定義を保持する', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.setPage(2)
    expect(store.sameGeometry([
      { width: 300, height: 350 },
      { width: 300, height: 350 },
    ])).toBe(true)
    store.setDocument({
      id: 'doc2',
      fileName: 'sample.pdf',
      pageCount: 2,
      pages: [
        { width: 300, height: 350 },
        { width: 300, height: 350 },
      ],
    })
    expect(store.document?.id).toBe('doc2')
    expect(store.definition.dpl).toHaveLength(1)
    expect(store.currentPage).toBe(1)
  })

  it('sameGeometry / setDocument: ページサイズが異なる再読み込みは定義をクリアする', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    expect(store.sameGeometry([{ width: 300, height: 999 }, { width: 300, height: 350 }])).toBe(
      false,
    )
    store.setDocument({
      id: 'doc2',
      fileName: 'sample.pdf',
      pageCount: 1,
      pages: [{ width: 300, height: 999 }],
    })
    expect(store.document?.id).toBe('doc2')
    expect(store.definition.dpl).toEqual([])
  })

  it('addDplSegment は最初は startLine 1 / dots [80]、以降は最大 startLine+1 と直前の dots', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    expect(store.definition.dpl).toEqual([{ startLine: 1, dots: [80] }])
    store.updateDplSegment(0, { dots: [25] })
    store.addDplSegment()
    expect(store.definition.dpl[1]).toEqual({ startLine: 2, dots: [25] })
    expect(store.pageLines).toHaveLength(14)
  })

  it('addDplSegmentAtLine は同じ startLine があれば追加しない', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.addDplSegmentAtLine(5)
    store.addDplSegmentAtLine(5)
    expect(store.definition.dpl.map((s) => s.startLine)).toEqual([1, 5])
    expect(store.definition.dpl[1].dots).toEqual([80])
  })

  it('addDplSegment は配列順ではなく startLine が最大のセグメントから dots を継承する', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegmentAtLine(5) // {startLine: 5, dots: [80]} (no governing segment yet, falls back)
    store.updateDplSegment(0, { dots: [40] }) // segment at startLine 5 now has dots [40]
    store.addDplSegmentAtLine(1) // startLine 1 < 5, no governing segment, falls back to [80]; pushed AFTER the line-5 segment
    // Array order is now [ {startLine:5, dots:[40]}, {startLine:1, dots:[80]} ] -
    // last-in-array is startLine 1, but startLine 5 is still the max/governing segment.
    expect(store.definition.dpl.map((s) => s.startLine)).toEqual([5, 1])
    store.addDplSegment() // maxStart = 5, must inherit dots from the segment whose startLine === 5, i.e. [40]
    expect(store.definition.dpl[2]).toEqual({ startLine: 6, dots: [40] })
  })

  it('addBlockFromRect はラインにスナップし、選択状態にする', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.updateDplSegment(0, { dots: [25] })
    store.addBlockFromRect({ x0: 0, y0: 80, x1: 150, y1: 130 })
    expect(store.definition.blocks).toEqual([{ startX: 0, endX: 150, startLine: 4, endLine: 6 }])
    expect(store.selectedBlock).toBe(0)
    expect(store.blockLines).toHaveLength(3)
  })

  it('moveBlock で順序を入れ替え、選択も追従する', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 })
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 })
    store.selectedBlock = 1
    store.moveBlock(1, -1)
    expect(store.definition.blocks[0].startX).toBe(20)
    expect(store.selectedBlock).toBe(0)
    store.moveBlock(0, -1)
    expect(store.definition.blocks[0].startX).toBe(20)
  })

  it('removeBlock 後に選択が範囲外なら null', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 })
    store.selectedBlock = 0
    store.removeBlock(0)
    expect(store.selectedBlock).toBeNull()
  })

  it('moveBlock で選択されていない側が動いた場合も選択インデックスを追従させる', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 }) // A
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 }) // B
    store.addBlock({ startX: 40, endX: 50, startLine: 1, endLine: 1 }) // C
    store.selectedBlock = 0 // A selected
    store.moveBlock(1, -1) // swap B(1) and A(0) -> [B, A, C]
    expect(store.definition.blocks.map((b) => b.startX)).toEqual([20, 0, 40])
    expect(store.selectedBlock).toBe(1) // still pointing at A
  })

  it('removeBlock で選択より前のインデックスを削除すると選択が1つ前へずれる', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 }) // A
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 }) // B
    store.addBlock({ startX: 40, endX: 50, startLine: 1, endLine: 1 }) // C
    store.addBlock({ startX: 60, endX: 70, startLine: 1, endLine: 1 }) // D
    store.addBlock({ startX: 80, endX: 90, startLine: 1, endLine: 1 }) // E
    store.selectedBlock = 2 // C selected
    store.removeBlock(0) // remove A -> [B, C, D, E]
    expect(store.definition.blocks.map((b) => b.startX)).toEqual([20, 40, 60, 80])
    expect(store.selectedBlock).toBe(1) // still pointing at C
  })

  it('removeBlock で選択中のブロック自体を削除すると同じインデックス(クランプ済み)を保つ', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addBlock({ startX: 0, endX: 10, startLine: 1, endLine: 1 }) // A
    store.addBlock({ startX: 20, endX: 30, startLine: 1, endLine: 1 }) // B
    store.addBlock({ startX: 40, endX: 50, startLine: 1, endLine: 1 }) // C
    store.selectedBlock = 1 // B selected
    store.removeBlock(1) // remove B -> [A, C]
    expect(store.definition.blocks.map((b) => b.startX)).toEqual([0, 40])
    expect(store.selectedBlock).toBe(1) // now points at C
  })

  it('addParagraph / setDivRange / updateDiv', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.addParagraph()
    expect(store.selectedParagraph).toBe(0)
    store.setDivRange(0, 300, 100)
    expect(store.definition.paragraphs[0].div).toMatchObject({ startX: 100, endX: 300 })
    store.updateDiv(0, { cond: 'F', value: '本店' })
    expect(store.definition.paragraphs[0].div.cond).toBe('F')
    store.updateParagraph(0, { endLine: { kind: 'fromEnd', n: 1 }, name: '店' })
    expect(store.outputText).toContain('PARAGRAPH,,E1,店,N,')
    expect(store.resolvedParagraphs[0].name).toBe('店')
  })

  it('エラーがあれば canDownload は false、解消すれば true', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.addBlock({ startX: 10, endX: 5, startLine: 1, endLine: 1 })
    expect(store.errors).toHaveLength(1)
    expect(store.canDownload).toBe(false)
    store.updateBlock(0, { endX: 20 })
    expect(store.errors).toEqual([])
    expect(store.canDownload).toBe(true)
  })

  it('moveParagraph で選択されていない側が動いた場合も選択インデックスを追従させる', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addParagraph()
    store.updateParagraph(0, { name: 'A' })
    store.addParagraph()
    store.updateParagraph(1, { name: 'B' })
    store.addParagraph()
    store.updateParagraph(2, { name: 'C' })
    store.selectedParagraph = 0 // A selected
    store.moveParagraph(1, -1) // swap B(1) and A(0) -> [B, A, C]
    expect(store.definition.paragraphs.map((p) => p.name)).toEqual(['B', 'A', 'C'])
    expect(store.selectedParagraph).toBe(1) // still pointing at A
  })

  it('removeParagraph で選択より前のインデックスを削除すると選択が1つ前へずれる', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    ;['A', 'B', 'C', 'D', 'E'].forEach((name, idx) => {
      store.addParagraph()
      store.updateParagraph(idx, { name })
    })
    store.selectedParagraph = 2 // C selected
    store.removeParagraph(0) // remove A -> [B, C, D, E]
    expect(store.definition.paragraphs.map((p) => p.name)).toEqual(['B', 'C', 'D', 'E'])
    expect(store.selectedParagraph).toBe(1) // still pointing at C
  })

  it('removeParagraph で選択中の段落自体を削除すると同じインデックス(クランプ済み)を保つ', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    ;['A', 'B', 'C'].forEach((name, idx) => {
      store.addParagraph()
      store.updateParagraph(idx, { name })
    })
    store.selectedParagraph = 1 // B selected
    store.removeParagraph(1) // remove B -> [A, C]
    expect(store.definition.paragraphs.map((p) => p.name)).toEqual(['A', 'C'])
    expect(store.selectedParagraph).toBe(1) // now points at C
  })

  it('ドキュメントが無いときは定義があっても canDownload は false', () => {
    const store = useDefinitionStore()
    store.addDplSegment()
    expect(store.canDownload).toBe(false)
  })
})

describe('useDefinitionStore: zoom / scale', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('初期は高さに合わせるで、コンテナ高 / ページ高が scale になる', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    expect(store.zoom).toBe('fit-height')
    store.setContainerSize(600, 700)
    expect(store.scale).toBe(2)
  })

  it('幅に合わせるはコンテナ幅 / ページ幅', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.setContainerSize(600, 1000)
    store.zoom = 'fit-width'
    expect(store.scale).toBe(2)
  })

  it('数値倍率は % をそのまま使い、zoomPercent は実効倍率を丸めて返す', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.setContainerSize(100, 100)
    store.zoom = 50
    expect(store.scale).toBe(0.5)
    expect(store.zoomPercent).toBe(50)
    store.zoom = 'fit-width'
    expect(store.zoomPercent).toBe(33)
  })

  it('setZoomPercent は 10〜100 にクランプして数値モードにする', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.setZoomPercent(150)
    expect(store.zoom).toBe(100)
    store.setZoomPercent(3)
    expect(store.zoom).toBe(10)
    store.setZoomPercent(42.7)
    expect(store.zoom).toBe(43)
  })

  it('ドキュメント未読込やコンテナ未計測なら scale は 1', () => {
    const store = useDefinitionStore()
    expect(store.scale).toBe(1)
    loadDoc(store)
    expect(store.scale).toBe(1)
  })
})

describe('useDefinitionStore: setLineHeight', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('ライン n を支配するセグメントの該当 dots 要素を書き換える', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.addDplSegment()
    store.updateDplSegment(0, { dots: [25] })
    store.addDplSegmentAtLine(5)
    store.updateDplSegment(1, { dots: [23, 22] })

    store.setLineHeight(2, 30)
    expect(store.definition.dpl[0].dots).toEqual([30])

    store.setLineHeight(6, 40)
    expect(store.definition.dpl[1].dots).toEqual([23, 40])
    expect(store.pageLines[5]).toEqual({ n: 6, y0: 4 * 30 + 23, y1: 4 * 30 + 23 + 40 })
  })

  it('高さは 1 未満にならず、支配セグメントが無ければ何もしない', () => {
    const store = useDefinitionStore()
    loadDoc(store)
    store.setLineHeight(1, 10)
    expect(store.definition.dpl).toEqual([])
    store.addDplSegment()
    store.setLineHeight(3, 0)
    expect(store.definition.dpl[0].dots).toEqual([1])
  })
})
