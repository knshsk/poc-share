import { defineStore } from 'pinia'
import { computed, reactive, ref } from 'vue'
import { blockFromRect, computeBlockLines } from '../model/blocks'
import { computePageLines, dotsIndexForLine, segmentForLine } from '../model/lines'
import { resolveParagraphs } from '../model/paragraphs'
import { serialize } from '../model/serialize'
import {
  emptyDefinition,
  newParagraph,
  type Block,
  type Div,
  type DplSegment,
  type FormDefinition,
  type Paragraph,
  type Rect,
} from '../model/types'
import { validate } from '../model/validate'

export interface DocumentInfo {
  id: string
  fileName: string
  pageCount: number
  pages: { width: number; height: number }[]
}

export type EditorTab = 'lines' | 'blocks' | 'paragraphs'

/** 表示倍率: 幅/高さに合わせる、または 10〜100 の % */
export type ZoomMode = 'fit-width' | 'fit-height' | number

export const ZOOM_MIN = 10
export const ZOOM_MAX = 100

const DEFAULT_DOTS = [80]

function moveItem<T>(arr: T[], i: number, dir: -1 | 1): number {
  const j = i + dir
  if (i < 0 || i >= arr.length || j < 0 || j >= arr.length) return i
  ;[arr[i], arr[j]] = [arr[j], arr[i]]
  return j
}

export const useDefinitionStore = defineStore('definition', () => {
  const document = ref<DocumentInfo | null>(null)
  const currentPage = ref(1)
  const zoom = ref<ZoomMode>('fit-height')
  /** キャンバスのスクロール領域の内寸(表示px)。PageCanvas が計測して報告する */
  const containerSize = ref({ width: 0, height: 0 })
  const definition = reactive<FormDefinition>(emptyDefinition())
  const activeTab = ref<EditorTab>('lines')
  const selectedBlock = ref<number | null>(null)
  const selectedParagraph = ref<number | null>(null)

  const pageSize = computed(
    () => document.value?.pages[currentPage.value - 1] ?? { width: 0, height: 0 },
  )
  const pageLines = computed(() => computePageLines(definition.dpl, pageSize.value.height))
  const blockLines = computed(() =>
    computeBlockLines(definition.blocks, pageLines.value, pageSize.value.width),
  )
  const resolvedParagraphs = computed(() =>
    resolveParagraphs(definition.paragraphs, blockLines.value),
  )
  const errors = computed(() => validate(definition, pageLines.value, blockLines.value))
  const outputText = computed(() => serialize(definition))
  const isDefinitionEmpty = computed(
    () =>
      definition.dpl.length === 0 &&
      definition.blocks.length === 0 &&
      definition.paragraphs.length === 0,
  )
  const canDownload = computed(
    () => document.value !== null && !isDefinitionEmpty.value && errors.value.length === 0,
  )

  /** 画像1pxあたりの表示px */
  const scale = computed(() => {
    const { width, height } = pageSize.value
    const z = zoom.value
    if (typeof z === 'number') return z / 100
    if (z === 'fit-width') {
      return width > 0 && containerSize.value.width > 0 ? containerSize.value.width / width : 1
    }
    return height > 0 && containerSize.value.height > 0 ? containerSize.value.height / height : 1
  })
  /** 実効倍率(%、整数) */
  const zoomPercent = computed(() => Math.round(scale.value * 100))

  function setContainerSize(width: number, height: number) {
    containerSize.value = { width, height }
  }

  /** 数値倍率モードにして、10〜100 の整数 % を設定する */
  function setZoomPercent(percent: number) {
    zoom.value = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(percent)))
  }

  function clearDefinition() {
    definition.dpl = []
    definition.blocks = []
    definition.paragraphs = []
    selectedBlock.value = null
    selectedParagraph.value = null
  }

  /** 現在のドキュメントと、指定した各ページの幅・高さが完全一致するか */
  function sameGeometry(pages: { width: number; height: number }[]): boolean {
    const current = document.value
    if (!current) return false
    if (current.pages.length !== pages.length) return false
    return current.pages.every(
      (p, i) => p.width === pages[i].width && p.height === pages[i].height,
    )
  }

  function setDocument(info: DocumentInfo) {
    const keepDefinition = sameGeometry(info.pages)
    document.value = info
    currentPage.value = 1
    if (!keepDefinition) clearDefinition()
  }

  function setPage(n: number) {
    const count = document.value?.pageCount ?? 0
    if (n >= 1 && n <= count) currentPage.value = n
  }

  // ---- DPL ----
  function addDplSegment() {
    const maxStart = definition.dpl.reduce((m, s) => Math.max(m, s.startLine), 0)
    const governing = segmentForLine(definition.dpl, maxStart)
    definition.dpl.push({
      startLine: maxStart + 1,
      dots: governing ? [...governing.dots] : [...DEFAULT_DOTS],
    })
  }

  function addDplSegmentAtLine(n: number) {
    if (definition.dpl.some((s) => s.startLine === n)) return
    const governing = segmentForLine(definition.dpl, n)
    definition.dpl.push({ startLine: n, dots: governing ? [...governing.dots] : [...DEFAULT_DOTS] })
  }

  function updateDplSegment(i: number, patch: Partial<DplSegment>) {
    Object.assign(definition.dpl[i], patch)
  }

  function removeDplSegment(i: number) {
    definition.dpl.splice(i, 1)
  }

  /** ライン n の高さ(ドット数)を、n を支配するセグメントの該当 dots 要素に書き込む。最小 1 */
  function setLineHeight(n: number, height: number) {
    const seg = segmentForLine(definition.dpl, n)
    if (!seg || seg.dots.length === 0) return
    seg.dots[dotsIndexForLine(seg, n)] = Math.max(1, Math.round(height))
  }

  // ---- BLOCK ----
  function addBlock(b: Block) {
    definition.blocks.push({ ...b })
    selectedBlock.value = definition.blocks.length - 1
  }

  function addBlockFromRect(rect: Rect) {
    const b = blockFromRect(rect, pageLines.value)
    if (b) addBlock(b)
  }

  function updateBlock(i: number, patch: Partial<Block>) {
    Object.assign(definition.blocks[i], patch)
  }

  function removeBlock(i: number) {
    definition.blocks.splice(i, 1)
    const selected = selectedBlock.value
    if (selected !== null) {
      if (i < selected) {
        selectedBlock.value = selected - 1
      } else if (i === selected) {
        selectedBlock.value =
          definition.blocks.length === 0 ? null : Math.min(selected, definition.blocks.length - 1)
      }
    }
  }

  function moveBlock(i: number, dir: -1 | 1) {
    const selected = selectedBlock.value
    const j = moveItem(definition.blocks, i, dir)
    if (j === i) return
    if (selected === i) selectedBlock.value = j
    else if (selected === j) selectedBlock.value = i
  }

  // ---- PARAGRAPH ----
  function addParagraph() {
    definition.paragraphs.push(newParagraph())
    selectedParagraph.value = definition.paragraphs.length - 1
  }

  function updateParagraph(i: number, patch: Partial<Omit<Paragraph, 'div'>>) {
    Object.assign(definition.paragraphs[i], patch)
  }

  function updateDiv(i: number, patch: Partial<Div>) {
    Object.assign(definition.paragraphs[i].div, patch)
  }

  function setDivRange(i: number, x0: number, x1: number) {
    const startX = Math.min(x0, x1)
    const endX = Math.max(x0, x1)
    if (startX === endX) return
    updateDiv(i, { startX, endX })
  }

  function removeParagraph(i: number) {
    definition.paragraphs.splice(i, 1)
    const selected = selectedParagraph.value
    if (selected !== null) {
      if (i < selected) {
        selectedParagraph.value = selected - 1
      } else if (i === selected) {
        selectedParagraph.value =
          definition.paragraphs.length === 0
            ? null
            : Math.min(selected, definition.paragraphs.length - 1)
      }
    }
  }

  function moveParagraph(i: number, dir: -1 | 1) {
    const selected = selectedParagraph.value
    const j = moveItem(definition.paragraphs, i, dir)
    if (j === i) return
    if (selected === i) selectedParagraph.value = j
    else if (selected === j) selectedParagraph.value = i
  }

  return {
    document,
    currentPage,
    zoom,
    definition,
    activeTab,
    selectedBlock,
    selectedParagraph,
    pageSize,
    pageLines,
    blockLines,
    resolvedParagraphs,
    errors,
    outputText,
    isDefinitionEmpty,
    canDownload,
    containerSize,
    scale,
    zoomPercent,
    setContainerSize,
    setZoomPercent,
    sameGeometry,
    setDocument,
    clearDefinition,
    setPage,
    addDplSegment,
    addDplSegmentAtLine,
    updateDplSegment,
    removeDplSegment,
    setLineHeight,
    addBlock,
    addBlockFromRect,
    updateBlock,
    removeBlock,
    moveBlock,
    addParagraph,
    updateParagraph,
    updateDiv,
    setDivRange,
    removeParagraph,
    moveParagraph,
  }
})
