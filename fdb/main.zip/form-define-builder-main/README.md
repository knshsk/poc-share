# Form Define Builder

PDF帳票のフォーム定義ファイル(DPL / BLOCK / PARAGRAPH / DIV / DEL_BACKWARD_SPACE)を、
PDFを画像化した上に枠を重ねながらGUIで作成し、テキストファイルとしてダウンロードするWebアプリです。

- バックエンド: FastAPI + pypdfium2(PDF→PNG変換のみ)
- フロントエンド: Vite + Vue 3 + TypeScript + Pinia(定義の編集・検証・テキスト生成)

設計: `docs/superpowers/specs/2026-09-06-form-define-builder-design.md`

## 必要なもの

- Python 3.12 と [uv](https://docs.astral.sh/uv/)
- Node.js 24 と npm

## 開発時の起動

ターミナル1(バックエンド、`http://localhost:8000`):

```bash
cd backend && uv sync && uv run uvicorn app.main:app --reload --port 8000
```

ターミナル2(フロントエンド、`http://localhost:5173`。`/api` は 8000 にプロキシ):

```bash
cd frontend && npm install && npm run dev
```

## 単一プロセスでの起動

フロントをビルドすると FastAPI が `frontend/dist` を配信します。

```bash
cd frontend && npm run build
```

```bash
cd backend && uv run uvicorn app.main:app --port 8000
```

`http://localhost:8000/` を開きます。`frontend/dist` の配信有無は起動時に判定されるため、`frontend/dist` は uvicorn を起動する前にビルドしておく必要があります。また、読み込んだPDFは一時ディレクトリに保存されるだけなのでバックエンドを再起動すると失われ、再度PDFを読み込み直す必要があります。

## テスト

```bash
cd backend && uv run pytest
```

```bash
cd frontend && npm test
```

## 使い方

1. PDF を選び、DPI(初期値 720)を指定して「読込」。
2. **ライン** タブで DPL セグメントを追加し、ドット数を帳票の行の高さに合わせる。キャンバスのラインをクリックすると、その位置から始まる新しいセグメントを追加できる。
3. **ブロック** タブでキャンバス上をドラッグして段組みの矩形を作る(Y はラインにスナップ)。
4. **パラグラフ** タブでパラグラフを追加し、開始/終了ライン(`E1` = 親の最終ライン)と DIV を設定する。選択中のパラグラフに対してキャンバスを横にドラッグすると DIV の X 範囲が入る。
5. 検証結果にエラーがなければ「定義ファイルをダウンロード」で `<PDF名>.txt` を保存する。

DPI は定義ファイルに含まれないため、別途控えておいてください。
